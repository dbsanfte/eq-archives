EQCharInfo Ver 1.0

Thank you for using EQCharInfo.  I hope this program gives you the 
information you can use and that you find useful to your race and
class and gives you useful information about your playstyle, etc.

Note:  This is just the first release of this program and I still
have more changes and upgrades planned.  Besides some additional
information that I have planned, there are many skills and attacks
which are specific to certain classes and only gained at certain
levels.  For this purpose, I would ask that if there is anything
that I have not included about your class that you would like to
see, please let me know.  Also, it would help if you would send me
your log file showing you using the skill or other item you want
added.

If you are not aware of how to create the log file that this program
reads, while you are in Everquest, type "/log on" to start logging.

Send any comments, suggestions, or bugs to: blood@gralin.com

Thank you and enjoy,
 Jason Blood
