EQ MANA AND WEAPON DAMAGE CALCULATOR
By: Kannin Ironballz, AKA Nathan Buczacz
email: crosfadr@gwi.net

Version 3.5
----------------------------------------

Written in VB 6.0

-----------------
IMPORTANT
---------

The required DLL's msvbvm50.dll and msvbvm60.dll NEED to be in your
c:/windows/system directory.
The DLL's are on the site at http://www.gwi.net/~buzz37/mwdc/home.html
They are relatively large files, so are not included in the zip file so you don't waste
time downloading them if you already have them.

To replace Oleaut32.dll, which is used by windows at run time, follow these directions, not
using quotes (Privided by Ascii on Tunare):

1. From the start button, go to "Restart the computer in MS-DOS mode"
2. Type  "cd \" to get to the "C:\" folder.
3. Type "move oleaut32.dll c:\windows\system"  to move the file to the
	right folder, responding yes to the dialog about overwriting the file.
4. Type "exit" to restart the computer in Windows mode.


-----------------------------------------------------------------------------------
About:
------

OK, what i've tried to do here is conglomerate most of the calculations you will need
playing EQ into one program, as well as add maybe a couple of things you might not have
seen in the other programs. I will be making revisions and if you encounter any bugs
or have any ideas, please don't hesitate to send them to me at nbuczacz@hotmail.com

-------------------------------------------------------------------------
Instructions:
-------------

Mana calculator:
----------------
I'm lazy, and you can probably figure this out by yourself ) If not, email me.


Weapon damage calculator:
-------------------------
Pick the weapons you want to compare from the list and click "Show" to show the stats
for that weapon.

You can also perfrom searches in the list. Simply type the first few letters of the weapon
and press the down arrow key.

Do this for all three weapons if you wish to compare duel weild to double attack. Make sure
you click "Show" for each weapon before you proceed. You can put in weapon stats in manually
(damage and delay), but you must click "Calculate manual Input" to calculate for those stats.
 
Input the level of your character, and the number of secondsyou want to calculate for. 
Click calculate to get your result. 

The program calculates the number of double attacks and duel weilds you are likely to get 
for your level (assuming your skill is maxed for your level). This figure will change just 
as you actual number of double attacks and duel weilds will differ for any two given 
amounts of time.

-------------------------------------------------------------------------
Version History
---------------

Changes 3.0-3.5

-Added ability to view hit % for duel weild and double attack and actual number of duel
weilds and double attacks

-Added Weapon Info Viewer, which allows you to view the stats for all the weapons in the
database


Changes 2.3-3.0

-Database functionality added (woohoo!)


Changes 2.2-2.3

-Revised calculations for duel weild/double attack probablility.


Changes 2.1-2.2

-Calculator now calculates averages of duel weild and double attack based on your level
and uses that to calculate max average damage for a given amount of time
-Changed all non-input fields to labels instead of text fields



Changes 2.0-2.1

-Added ability to calculate max damage for weps accounting for duel weild and double attack
-Ability to compare duel weild to a 2 naded weapon
-Added display of previous and next two levels to mana calculator
-Fixed a couple error-correction problems with mana calculator
-"Fixed" calculations for duel class characters


Changes 1.0-2.0

-Mana calculations and Weapon damage calculations now are in seperate windows.
-There is now a menu bar which provides access to both calculation windows and an about box.

------------------------------------------------------------------------
BUGS:
-----

See web site at http://www.gwi.net/~buzz37/mwdc/home.html for current known bugs

-------------------------------------------------------------------------
Credits:
--------
I got the mana calculations and some ideas from the Offline Mana Calculator by Kyle Paulette.
You can find this program at: http://eq.stratics.com/game_files.shtml

Here are the calculations, as they appear in the readme for the Offline Mana Calculator:
INTELLIGENCE: ((INTELLIGENCE/5)+2)*(LEVEL)
WISDOM      : ((WISDOM/5)+2)*(LEVEL-(STARTING CASTING LEVEL - 1))

The Mana Calculation Spreadsheet By Ziskin that can be found at the same URL was also
a -great- source of ideas.

www.equalizer.com for stats on all the weapons.
