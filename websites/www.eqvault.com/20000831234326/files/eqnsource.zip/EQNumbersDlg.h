// EQNumbersDlg.h : header file
// By Strom Stillwater

#include "SimDlg.h"

#if !defined(AFX_EQNUMBERSDLG_H__4FFCA866_493C_11D3_94F6_004033A056DE__INCLUDED_)
#define AFX_EQNUMBERSDLG_H__4FFCA866_493C_11D3_94F6_004033A056DE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CEQNumbersDlg dialog

class CEQNumbersDlg : public CDialog
{
// Construction
public:
	SimDlg *simdlg;
	CEQNumbersDlg(CWnd* pParent = NULL);	// standard constructor
	void Simulate();
	int manaCalc(int level);
	void GreyStuff(int dwflag, int daflag, int mflag);
	void SimDone();
// Dialog Data
	//{{AFX_DATA(CEQNumbersDlg)
	enum { IDD = IDD_EQNUMBERS_DIALOG };
	CSpinButtonCtrl	m_lvlspin;
	CComboBox	m_class;
	int		m_basestat;
	CString	m_basetitle;
	int		m_manamod;
	CString	m_levm1;
	CString	m_levm1title;
	CString	m_levm2;
	CString	m_levm2title;
	CString	m_levp1;
	CString	m_levp1title;
	CString	m_levp2;
	CString	m_levp2title;
	CString	m_levtitle;
	CString	m_lev;
	CString	m_note;
	int		m_wdel1;
	int		m_wdel2;
	int		m_wdel3;
	int		m_wdel4;
	int		m_wdmg1;
	int		m_wdmg2;
	int		m_wdmg3;
	int		m_wdmg4;
	CString	m_dps3;
	CString	m_dps4;
	CString	m_bestweap;
	int		m_daskill;
	int		m_dwskill;
	BOOL	m_dack;
	BOOL	m_dwck;
	int		m_cth;
	CString	m_foursp;
	CString	m_fivesp;
	CString	m_lvl;
	CString	m_dacap;
	CString	m_dwcap;
	int		m_smin;
	int		m_ssec;
	int		m_dmgmult;
	BOOL	m_showtime;
	CString	m_threesp;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEQNumbersDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CEQNumbersDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSelchangeClass();
	afx_msg void OnCalcbut();
	afx_msg void OnCalcbutw();
	afx_msg void OnAboutbut();
	afx_msg void OnNotes();
	afx_msg void OnDack();
	afx_msg void OnDwck();
	afx_msg void OnSimbut();
	afx_msg void OnChangeLevel();
	afx_msg void OnDeltaposLvlspin(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnKillfocusDwskill();
	afx_msg void OnKillfocusDaskill();
	afx_msg void OnWpick1();
	afx_msg void OnWpick2();
	afx_msg void OnWpick3();
	afx_msg void OnWpick4();
	afx_msg void OnUpdateWdel1();
	afx_msg void OnUpdateWdmg1();
	afx_msg void OnMailme();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EQNUMBERSDLG_H__4FFCA866_493C_11D3_94F6_004033A056DE__INCLUDED_)
