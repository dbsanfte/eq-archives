// SimDlg.cpp : implementation file
// By Strom Stillwater

// Sorry about the TOTAL lack of comments in this file, I honestly don't
// remember what half this stuff does!  Gimme a break, I was trying to
// learn MFC at the time =)

#include "stdafx.h"
#include "EQNumbers.h"
#include "SimDlg.h"
#include "EQNumbersDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CEQNumbersApp theApp;
/////////////////////////////////////////////////////////////////////////////
// SimDlg dialog

BEGIN_MESSAGE_MAP(CGraphWnd, CFrameWnd )
	//{{AFX_MSG_MAP( CMainWindow )
	ON_BN_CLICKED(IDC_UPDATE, OnUpdateGraph)
	ON_BN_CLICKED(IDC_ADD, OnGraphAdd)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

SimDlg::SimDlg(CWnd* pParent /*=NULL*/)
	: CDialog(SimDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(SimDlg)
	m_tlpd = _T("");
	m_tlpda = _T("");
	m_tlsd = _T("");
	m_tlsda = _T("");
	m_tltl = _T("");
	m_tlatk = _T("");
	m_interations = 0;
	m_totaldamage = _T("");
	//}}AFX_DATA_INIT
	ASSERT(pParent != NULL);
	m_pParent = pParent;
	m_nID = SimDlg::IDD;
}


void SimDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(SimDlg)
	DDX_Control(pDX, IDC_ACTION, m_listbox);
	DDX_Text(pDX, IDC_TLPD, m_tlpd);
	DDX_Text(pDX, IDC_TLPDA, m_tlpda);
	DDX_Text(pDX, IDC_TLSD, m_tlsd);
	DDX_Text(pDX, IDC_TLSDA, m_tlsda);
	DDX_Text(pDX, IDC_TLTL, m_tltl);
	DDX_Text(pDX, IDC_TLATK, m_tlatk);
	DDX_Text(pDX, IDC_ITERATIONS, m_interations);
	DDX_Text(pDX, IDC_TOTALDAMAGE, m_totaldamage);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(SimDlg, CDialog)
	//{{AFX_MSG_MAP(SimDlg)
	ON_BN_CLICKED(IDC_GRAPHBUT, OnGraphbut)
	ON_BN_CLICKED(IDC_RESIM, OnResim)
	ON_BN_CLICKED(IDC_ADD2GRAPH, OnAdd2graph)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// SimDlg message handlers

BOOL SimDlg::Create() 
{
	return CDialog::Create(m_nID, m_pParent);
}

void SimDlg::PostNcDestroy() 
{
	delete this;
}

void SimDlg::OnCancel() 
{
	((CEQNumbersDlg *)m_pParent)->SimDone();
	DestroyWindow();
}

CGraphWnd::CGraphWnd()
{
	CRect myRect;
	int xsize = ::GetSystemMetrics(SM_CXSCREEN);
	int ysize = ::GetSystemMetrics(SM_CYSCREEN);
	theApp.curGraph = 0;
	aFlag = 0;
	myRect.SetRect(xsize/2-250,ysize/2-160,xsize/2+250,ysize/2+160);
	Create(NULL,"Graph",WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE,myRect,NULL,
		MAKEINTRESOURCE(IDR_MAINFRAME),0,NULL);
}

void CGraphWnd::UpdateGraph(CPaintDC *dc)
{
	int i, max, longest = 0, dnum;
	CString s;
	CFont *myFont = new CFont;
	CPen *myPen = new CPen;

	COLORREF clist[5];
	clist[0] = RGB(255,255,255);
	clist[1] = RGB(0,255,0);
	clist[2] = RGB(255,0,0);
	clist[3] = RGB(0,0,255);
	clist[4] = RGB(127,127,127);
	
	// Draw the Area
	myPen->CreatePen(PS_SOLID,1,RGB(255,255,255));
	myFont->CreatePointFont(85,"Times New Roman");
	dc->SelectObject(myFont);
	dc->SelectObject(myPen);
	i = 0; max = -1;
	while(i<=aFlag) {
		if(theApp.graphArray[200][i] > max) {
			longest = i; max = theApp.graphArray[200][i];
		}
		i++;
	}
	max = theApp.graphArray[200][longest];
	max = max + (11 - (max % 11));
	dc->FillSolidRect(0,0,500,320,RGB(0,0,0));
	dc->SetTextAlign(TA_BASELINE | TA_CENTER);
	dc->SetTextColor(::GetSysColor(COLOR_WINDOWTEXT));
	dc->SetBkMode(TRANSPARENT);
	dc->MoveTo(60,10);
	dc->LineTo(60, 230);
	dc->LineTo(460,230);
	for(i = 20; i < 221; i+=20) {
		dc->MoveTo(55,230-i);
		dc->LineTo(65,230-i);
	}
	for(i = 20; i < 401; i+=20) {
		dc->MoveTo(60+i,225);
		dc->LineTo(60+i,235);
	}
	dc->SetTextAlign(TA_RIGHT);
	dnum = max / 11;
	if(dnum == 0) dnum = 1;
	for(i=0;i<12;i++) {
		s.Format("%d",dnum*i);
		dc->TextOut(55,224-i*20,s);
	}
	dnum = theApp.sectime[longest];
	if(dnum % 20 != 0) dnum = dnum + (20 - (dnum % 20));
	dnum = dnum / 20;
	if(dnum == 0) dnum = 1;
	dc->SetTextAlign(TA_RIGHT);
	dc->TextOut(56,235,"min");
	dc->TextOut(56,245,"sec");
	dc->SetTextAlign(TA_CENTER);
	dc->TextOut(10,100,"D");
	dc->TextOut(10,110,"a");
	dc->TextOut(10,120,"m");
	dc->TextOut(10,130,"a");
	dc->TextOut(10,140,"g");
	dc->TextOut(10,150,"e");	
	bool pflag = FALSE; int p;
	for(i=0;i<21;i++) {
		s.Format("%d",dnum*i/60);
		dc->TextOut(60+i*20,236,s);
		s.Format("%d",dnum*i-(dnum*i/60)*60);
		dc->TextOut(60+i*20,246,s);
	}
	int v, v2, j; double tmp, tmp2, mult;
	for(j=0; j<=aFlag; j++) {
		pflag = FALSE;
		myPen->DeleteObject();
		myPen->CreatePen(PS_SOLID,1,clist[j]);
		dc->SelectObject(myPen);
		dnum = theApp.sectime[longest];
		if(dnum % 20 != 0) dnum = dnum + (20 - (dnum % 20));
		dnum = dnum / 20;
		for(i=0;i<21;i++) {
			if(dnum*i > theApp.sectime[j] && !pflag) {
				p = i*20; pflag = TRUE;
			}
		}
		if(!pflag) p = 400;
		mult = double(p) / 200.0;
		dc->MoveTo(60,230);
		for(i=1;i<201;i++) {
			tmp = theApp.graphArray[i][j] / double(max);
			v = 224 - int(tmp * 200.0);
			tmp2 = i*mult;
			v2 = int(tmp2);
			dc->LineTo(v2+60,v);
		}
	}
}

void CGraphWnd::OnPaint()
{
	CPaintDC dc(this);
	UpdateGraph(&dc);
}

void CGraphWnd::OnUpdateGraph()
{
	for(int i = 0; i < 201; i++)
		theApp.graphArray[i][0] = theApp.graphArray[i][theApp.curGraph];
	theApp.sectime[0] = theApp.sectime[theApp.curGraph];
	theApp.curGraph = 0; theApp.graphWnd->aFlag = 0;
	InvalidateRgn(NULL);
	OnPaint();
}

void CGraphWnd::OnGraphAdd()
{
	if(aFlag <= 8) {
		aFlag++; 
		for(int i = 0; i < 201; i++)
			theApp.graphArray[i][aFlag] = theApp.graphArray[i][theApp.curGraph];
		InvalidateRgn(NULL,FALSE);
		OnPaint();
	} else 
		AfxMessageBox("You have reached the limit on this graph.", MB_OK | MB_ICONSTOP);
}

BOOL CGraphWnd::DestroyWindow() 
{
	theApp.graphWnd = NULL;
	return CWnd::DestroyWindow();
}

void SimDlg::OnGraphbut() 
{
	int tmp = theApp.curGraph;
	if(theApp.graphWnd == NULL) {
		theApp.graphWnd = new CGraphWnd;
		theApp.graphWnd->ShowWindow(SW_SHOWNORMAL);
		theApp.graphWnd->SetIcon(*theApp.mainIcon, TRUE);
		theApp.graphWnd->SetIcon(*theApp.mainIcon, FALSE);
	}
	theApp.curGraph = tmp;
	for(int i = 0; i < 201; i++)
		theApp.graphArray[i][0] = theApp.graphArray[i][theApp.curGraph];
	theApp.sectime[0] = theApp.sectime[theApp.curGraph];
	theApp.curGraph = 0; theApp.graphWnd->aFlag = 0;
	theApp.graphWnd->InvalidateRgn(NULL,TRUE);
	theApp.graphWnd->UpdateWindow();
	theApp.graphWnd->SetFocus();
}

void SimDlg::OnResim() 
{
	UpdateData(TRUE);
	theApp.iterations = m_interations;
	((CEQNumbersDlg *)m_pParent)->Simulate();
}

void SimDlg::OnAdd2graph() 
{
	if(theApp.graphWnd==NULL) {
		OnGraphbut();
	} else {
		theApp.graphWnd->SetFocus();
		theApp.graphWnd->OnGraphAdd();
	}
}

BOOL SimDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	m_totaldamage = "Total Damage:";
	m_interations = theApp.iterations;	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
