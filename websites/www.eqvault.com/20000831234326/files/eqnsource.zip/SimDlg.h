#if !defined(AFX_SIMDLG_H__F23AC8A0_4F90_11D3_94F6_004033A056DE__INCLUDED_)
#define AFX_SIMDLG_H__F23AC8A0_4F90_11D3_94F6_004033A056DE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SimDlg.h : header file
// By Strom Stillwater

/////////////////////////////////////////////////////////////////////////////
// SimDlg dialog

class CGraphWnd : public CFrameWnd
{
public:
	CGraphWnd();
	int aFlag;
	void UpdateGraph(CPaintDC *dc);
	//{{AFX_MSG(CGraphWnd)
	afx_msg void OnPaint();
	afx_msg void OnUpdateGraph();
	afx_msg void OnGraphAdd();
	//}}AFX_MSG

	public:
	virtual BOOL DestroyWindow();

	DECLARE_MESSAGE_MAP()
};

class SimDlg : public CDialog
{
// Construction
public:
	SimDlg(CWnd* pParent);   // standard constructor
	BOOL Create();
// Dialog Data
	//{{AFX_DATA(SimDlg)
	enum { IDD = IDD_SIMDLG };
	CListBox	m_listbox;
	CString	m_tlpd;
	CString	m_tlpda;
	CString	m_tlsd;
	CString	m_tlsda;
	CString	m_tltl;
	CString	m_tlatk;
	int		m_interations;
	CString	m_totaldamage;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(SimDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

// Implementation
protected:
	CWnd* m_pParent;
	int m_nID;
	// Generated message map functions
	//{{AFX_MSG(SimDlg)
	virtual void OnCancel();
	afx_msg void OnGraphbut();
	afx_msg void OnResim();
	afx_msg void OnAdd2graph();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIMDLG_H__F23AC8A0_4F90_11D3_94F6_004033A056DE__INCLUDED_)
