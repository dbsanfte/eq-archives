Maendark's Magic Mod Spell Rebalance for Dungeon Siege 10/7/02
Version 1.4
author email: j_bakert@hotmail.com
Installation: Place this mod in your dungeon siege resources directory. Probably only works for multiplayer games.
Download: Site 1

About MMM Rebalance:

This mod modified various skrit to balance the spells in dungeon siege. Great care was takent to make each spell enticing to use, as well as have its own niche. This mod does not make you into a god - but it makes Dungeon Siege fun again! (at least it did for me) 

All aspects of a spell were considered as well as it's relation to other spells of both magic classes in order to rebalance them. Some useless spells are now pretty good (the impetous for making this mod in the first place) and those that you wouldn't think of ever using were given a purpose (debuff spells, faster casting spells, heavier hitting spells, etc).

I've played a caster several times now to level 100 or so, and being a fairly active gamer, as well as designer, I thought it would be a great idea to resurrect this game by making magic spells how they were supposed to be. Unique, purposeful, and fun to look at ;)

The mod is still a work in progress as I haven't completed the damage dealing nature spells for the most part. I hope to get this done soon. 

-Maendark

-----------
Changelog v1.4:
* 1-150 - All Buffs - All buffs are now single cast, and have their durations greatly increased to scale to level 150.  Depending on the power of the spell, the scaling is larger or smaller.
* 1-150 - All Summons - ALl summon durations now increase with level.
* 8  - Iron fist now scales correctly, like the group version "Blood and Iron"
* 18 - Regeneration - Increased regen rate
* 24 - Death Blast - Blast radius increased
* 26 - Fire Ring - Lowered duration and damage
* 46 - Nurture - Fixed mana cost (was always 0)
* 66 - Meteor - Increased damage, increased blast radius
* 102 - Meteor Storm - Increased damage, increased blast radius


Changelog v1.3:
* 44 - Clean Strike - Decreased mana cost
* 46 - Mana Balance - Increased duration
* 46 - Nurture - Scaled to 150, decreased mana cost, increased xp for casting
* 50 - Frigid Armor - Increased duration, scaled to 150
* 50 - Shared Pain - Increased duration, and effect, scaled to 150
* 55 - Ambivilence - Decreased mana cost, scaled to 150
* 55 - Eagle Eye - Increased duration, and effect, scaled to 150
* 58 - Party Recharge - Increased radius, scaled to 150, increased effect
* 58 - Return Summoned - Decreased mana cost, increased range
* 60 - Battle Rally - Increased effect, scaled to 150 (is now group Clean Strike)
* 66 - Life Balance - Increased duration
* 66 - Polymorph - Lowered mana cost
* 69 - Freeze - Lowered mana cost, scaled duration to 150
* 70 - Merick's Windfall - Increased duration, increased effect, scaled to 150 (now group Ogres Strength, group Accuracy, and Group Focused Mind)
* 80 - Harmony - Increased duration
* 84 - Mystic Aid - Increased duration, radius, and scaled to 150

Changelog v1.2:

Nature Magic:
* 14 - Accuracy - Increased duration, increased effect, scaled to 150
* 18 - Regeneration - Increased duration, increased xp from buffing, scaled to 150
* 20 - Anchored Shot - Increased duration, increased xp from buffing, scaled to 150
* 22 - Oversight - Increased duration, sharply decreased mana cost, scaled duration to 150
* 24 - Focused Mind - Increased duration, increased effect, decreased mana cost, scaled to 150
* 28 - Stoneskin - Increased duration, increased effect, scaled to 150 (is now group Magic Armor)
* 29 - Charm - Decreased mana cost, increased xp from casting
* 30 - Lightfoot - Increased mana cost, increased duration, increased effect and scaled to 150 (is now group Accuracy)
* 34 - Shock Armor - Increased duration, scaled to 150
* 38 - Mind Spring - Increased mana cost, increased duration, increased effect and scaled to 150 (is now group Focused Mind)
* 40 - Stumble - Sharply decreased mana cost, increased effect, scaled to 150
* 41 - Draw Near - Increased range, decreased mana, scaled to 150 (experience gained increases with level)
* 44 - Clean Strike - Increased mana cost, increased duration, increased effect and scaled to 150
* 45 - Convert - Increased duration, scaled to 150
* 45 - Inspiration - Increased duration, increased effect, decreased mana cost
* 46 - Blood and Iron - Increased duration, increased effect, and scaled to 150 (is now group Iron Fist)
* 46 - Invincibility - Increased duration, increased effect, and scaled to 150


Changelog v1.1:

Combat Magic:

* 84 - Fireball Rain - Increased fireballs, increased frequency of rain.
* 90 - Fireblast - Lowered recast time
* 96 - Cluster Bomb - Added 1 more bomb
* 98 - Blaster - Lowered Recast, slightly lowered mana
* 100 - Bombard - Decreased Recast, Increased Range
* 102 - Meteor Storm - Lowered mana cost
* 108 - Tremor - Lowered mana cost


Changelog v1.0:

Combat Magic

* 1 to 150 - Summons - Doubled duration
* 0 - Rip Mana - Increased range
* 1 - Acid Gas - Increased Duration
* 1 - Burn Body - Mana cost always 1
* 2 - Leech Life - Set Mana to Health/Damage ratio to 1:1 from 2:1 as DD spells are usually 1:3 (Increased damage)
* 3 - Rage - Doubled duration, removed HP damage to target, increased benefits, scaled to 150
* 5 - Revive - Slightly lowered mana cost
* 7 - Weaken - reduced mana cost and scaled spell to level 150
* 7 - Soul Lance - increased lance speed
* 8 - Flame - Lowered mana cost slightly
* 12 - Acid Cloud - Increased duration
* 12 - Spirit Armor - doubled duration, improved AC benefit per level of combat magic
* 16 - Fire Skull - increased recast, range, and mana cost
* 20 - Explode Body - Increased range, blast radius, and decreased mana cost slightly
* 20 - Fireball - Increased range and blast radius slightly
* 22 - Triple Strike - increased xp from buffing, increased duration, lowered mana cost
* 24 - Death blast - Increased duration
* 26 - Curse - Greatly lowered mana cost
* 26 - Fire Ring - Lowered mana cost, lowered and scaled duration to 150
* 32 - Fire Wall - halved mana cost, increased duration and scaled to 150
* 32 - Flame Shield - Decreased mana cost, increased duration, increased AC benefit per level
* 34 - Ogres Might - Increased effect and duration
* 36 - Metal Shards - Increased shard count to 4, increased range, increased projectile speed
* 38 - Pain Reflux - Increased duration
* 42 - Pestilence - Increased duration
* 44 - Corpse Transmutation - lowered recast time
* 45 - Sharg's Revical - Lowered casting cost slightly
* 48 - Fire Rain - Increased rain particles, decreased time between particles
* 52 - Flame blades - Decreased recast time greatly, increased mana cost
* 54 - Inferno - Increased range and duration
* 63 - Fireshot Armor - Increased duration, lowered mana cost, scaled to 150, and increased AC benefit
* 66 - Meteor - Decreased mana cost, increased blast radius
* 70 - Fire Bomb - Increased blast radius, range, and mana cost
* 78 - Pestilence Cloud - Increased duration, scaled to 150
* 80 - Malign - Reduced mana cost greatly, increased strength reduction benefits, scaled to 150


Nature Magic:

* 8 - Iron Fist - Increased strength bonus, scaled to 150, changed mana cost formula
* 9 - Healing Wind - Lowered recast
* 11 - Hold creature - increased duration, decreased mana cost, scaled to 150




 
