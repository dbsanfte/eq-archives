@ECHO OFF
REM Modify the line after the REM's with the correct path and name of your 
REM log file.  Append your characters name and change the 0's to 1's if you
REM wish to see HitCount and Defensive information.
REM
REM Example:
REM ConsoleParser "C:\Program Files\Everquest\eqlog_74_Kelt.txt" Kelt 0 1

ConsoleParser.exe "C:\Program Files\Everquest\eqlog_XX_Name.txt" Name 0 0


