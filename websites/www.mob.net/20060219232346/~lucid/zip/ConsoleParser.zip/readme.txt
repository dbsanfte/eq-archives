Edit the file Parse.bat with the correct information for your EQ install.
This can be done by right clicking on Parse.bat and choosing "Edit".

-Tari

Comments, Bugs, Suggestions: tarissadr@hotmail.com
