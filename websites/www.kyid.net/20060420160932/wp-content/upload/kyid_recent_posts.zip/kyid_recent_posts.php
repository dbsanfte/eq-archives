<?php
/*
Plugin Name: Recent Posts
Plugin URI: http://www.kyid.net/archives/2005/04/07/recent-posts/
Description: Simple plugin to return the X amount of most recent posts (defaults to 10)
Version: 0.1
Author: Keith Young
Author URI: http://www.kyid.net/
*/

/*  Copyright 2004  Keith Young  (email : youngka@N0_SP4M.shaw.ca)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @version $Id$
* @copyright 2005
* @param integer $returnPostCount Number of posts to return hyperlinks for
* @return void
*/
function kyid_recent_posts($returnPostCount=10){
  global $wpdb;
  $retval='';
  //ensure that $returnPostCount is an integer
  $returnPostCount=(int)$returnPostCount;
  
  $results=$wpdb->get_results("SELECT ID,post_title FROM wp_posts ORDER BY post_date_gmt DESC LIMIT $returnPostCount");
  foreach($results as $rObj){
    $retval.='<li><a href="'.get_permalink($rObj->ID).'" title="'.$rObj->post_title.'">'.$rObj->post_title.'</a></li>'."\r\n";
  }
  echo $retval;
}
?>