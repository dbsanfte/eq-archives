=================================================================================================

UO Trace Ver. 1.00 beta 6c

=================================================================================================


GENERAL INFO


What is UOTrace?

UOTrace is an Internet utility for Windows 95 similar to the standard UNIX 
utilities Ping and Traceroute. It is used to see the route by which Internet 
data packets travel between your computer and another and shows how long each 
data packet takes to travel to the other computer and back.

Unlike Traceroute, UOTrace will continue to Ping each router found during the 
initial trace and so will help to pinpoint trouble spots on the route more 
easily.

Note that it has only been tested using the built-in Windows 95 Winsock 
stack and may not work correctly on other TCP/IP stacks. It utilizes the 
Microsoft proprietary DLL ICMP.DLL which also may cause problems on other 
Winsock stacks.

Please only use UOTrace when absolutely necessary. The Internet is already 
overcrowded and slow enough without people sending Ping packets all over 
the world!

=================================================================================================

How does UOTrace work?

Computers directly connected to the Internet have Internet addresses associated 
with them that uniquely identify themselves to the rest of the world. An example 
Internet address (IP address) is often expressed in the form of four numbers as 
in 205.214.55.58 but because these are awkward to deal with for most humans, many 
well known computers have an alternative method of identifying themselves in the 
form of a name such as rob.vie.com. In simple terms, these names are translated 
into the four-number IP addresses by computers known as Domain Name Servers (DNS) 
before you attempt to communicate to another computer. Given an IP address, the 
DNS servers can also perform a reverse lookup to obtain the human-readble name 
from an IP number.

Data packets sent from one computer to another over the Internet generally do 
not go directly from machine to machine. Instead, they travel through routers - 
computers dedicated to passing on the data to the next router that is hopefully 
nearer to the final destination computer.

If you imagine an Internet address as an international telephone number then 
routers act like telephone exchanges. For example, imagine my computer in 
California trying to talk to another computer in Great Britain. Imagine also 
that the computer in Britain has the telephone number (i.e. IP address) 
222111666444. My Californian computer sends out some data that has the 
destination address tagged onto it. The first place it goes to is the nearest 
physical router. This looks at the IP address and says "hmm, I don't know this 
destination computer directly but I do know where to send data if the number 
begins with 222 - that's along this wire...", and so off goes the data to the 
next (hopefully) closer router to Great Britain. The data arrives there and this 
router says "OK, I'm known as 222 so the next place this data must go is to 111, 
and that's along this wire...".  The journey continues in a similar fashion until 
finally the data arrives at the router in Great Britain which says "I'm known as 
222111666  so the next place this data must go is to 444. I know exactly which 
computer this is, the data goes along this wire..." and so the data has finally 
arrived. Using this kind of technique, routers don't need to store details of 
every computer in the World in order to get data to them, they just need to know 
which is the next closest one to the final address and let the next router handle it.

Problems can occur along the journey if a router is misconfigured in some way, if 
it is overloaded with data or if it is not functioning at all. Usually the data can 
be passed on to other routers but they are not necessarily closer the to final 
destination and can increase the time the data spends in it's journey. This time is 
known as latency. Generally, the more hops (i.e. the more routers the data has to 
travel through) the data packet takes to get to it's destination, then the longer the 
journey will take. The total journey time for a data packet to travel to the destination 
and return to it's origin again is known as the Round Trip Time, or RTT for short.

Sometimes, a router will be so busy forwarding and directing data that it can't cope 
and so some data packets will simply be discarded. If this happens to a data packet 
then it is said to have been dropped by the router. It is up the the sending and 
receiving computers to work out if some data has gone missing along the route and 
re-transmit it.

What happens if many routers along the journey from one computer to another are 
overloaded, mis-configured or just plain dead, so much so that the data never 
gets any closer to it's destination and just bounces back and forth between 
routers? How do these data packets ever disappear? The answer lies in a piece of 
information carried with the data called the Time To Live (TTL). 

When the data is first transmitted, the TTL is set to a number, for example 
32. Whenever the data passes through a router this number is decremented by 1. 
If the resulting number ever becomes zero (or 1 with some routers) then the router 
will know that this data packet has been bouncing around the Internet for a while 
and should have reached it's destination by now, but hasn't for whatever reason. 
In this case the router will drop the packet and send a special message back to 
the originating computer saying that the data never made it and how far it had 
got when the packet was dropped. These special messages are transmitted using a 
low-level Internet data format knwon as ICMP (Internet Control Message Protocol).

UOTrace uses ICMP messages and the TTL information to determine the route made 
by a data packet. Starting off with a TTL of 1, the data is sent. The first router 
it goes through will subtract one from the TTL, bringing the TTL to zero and thus 
causing the packet to be dropped and a message sent back saying "hey! the data got 
this far (the router IP address) and was dropped". So now the program knows the 
first router on the journey. The TTL is now set to 2 and the data sent again. This 
time it will pass through the first router because the TTL only went down to 1, but 
when it reaches the second router a sililar destination not reached  message will be 
sent back. Now we know the second router on the journey. We continue adding to the 
TTL until the data eventually arrives at the destination.

=================================================================================================

QUICK START INSTRUCTIONS

For its simplest use, merely run UOTrace, select the server you wish to test your 
connection to via the pull-down bar which appears, then click on "Link Test" to begin 
pinging the UO World Server you have selected.  A progress bar will indicated the 
status of the test as each ping makes its way toward the server.  After it is 
finished, a status window will appear with the results of the test.  Results will 
range from Excellent to Extremely Poor.  Below average results will cause UOTrace 
to display a new dialogue box which informs you of the below-average results, and 
asks if you wish to perform extended diagnostics.  

If you choose "Yes", UOTrace will begin its diagnostics, which may take a great 
deal of time.  Be patient while it works, as it is painstakingly pinging each router 
along your route to find any troublespots.  After it is finished, a new window will 
be displayed which explains, roughly, why your route to the indicated destination is 
below average.  Specific, heavily-trafficked routers which may be slowing you down 
will be displayed.  For each router with a text DNS entry, you can right-click on it 
and select "Who is.." to display Whois information for that specific router.  This 
will enable you to contact the sysadmin of each router for assistance, or you may 
want to contact your ISP with the information for possible action.  You can also 
click on "View Report" to see the actual trace route yourself, or click on each 
troubled router, then click on "E-Mail Report" to send this report to the sysadmin 
of each router via e-mail.

=================================================================================================

ADVANCED MODE

UO Trace also comes with an advanced mode which will allow you to display extended 
trace routes and judge their results for yourself.  To access it, simply click on 
the "Options" menu, then select "Advanced"

The Menu

FILE:   All you can do from here is Exit UOTrace

EDIT:  All you can select from this menu is Copy.  This will copy a selected 
IP address into the windows clipboard.

OPTIONS:

	ADVANCED:  Select this option to put you back into "Simple" mode

	SETTINGS:  Allows you to change various configuration options in UOTrace

Operation Timeout Value
The time in milliseconds after which the program will give up when waiting for 
a response from a machine.

Continuous Ping Delay
The time delay in milliseconds that the program will wait in-between each hop.

Ping Buffer - Do not use this.

Ping TTL
The Time to Live value used by the program when initially contacting a computer or 
router.

Trace Route Ping Retries
The maximum number of times the program will attempt to contact a single machine during 
the initial trace.
If, after this number of tries the machine can still not be contacted the trace will be 
aborted and a message box will appear telling you that the maximum number of tries has 
been attempted.

Trace Route Max hops
The maximum number of hops the program will allow before giving up on trying to reach a machine.

Reverse DNS Lookups
Looks up the host and domain name, rather than the IP address

Ignore first hop
Sometimes it may be necessary to prevent the program from pinging the first hop of a trace. 
On some routes the first hop will be the default gateway or terminal server which may be 
configured to not respond to ping requests and so the program would never be able to continue 
past this point. If this happens you can select this option to prevent the program trying to 
contact the first hop.

ABOUT:  Provides you with the version number and contact information for the author.

=================================================================================================

The Tool Bar

LINK TEST - Basically, performs the same operation here as in "Simple Mode", except it 
displays the results as the test proceeds.

DNS - DNS lookup for the selected site.  

WHOIS - Provides Whois info for the selected site

PING - Sends a single Ping to the selected site.

TRACE ROUTE - Performs a single trace route to the selected site, displaying the results 
below.

POLL - After a DNS, Ping, or Trace Route is performed, you can click on Poll to continually 
ping each listed server.

ULTIMA ONLINE HOMEPAGE - If your browser is correctly configured, this will take you to the 
Ultima Online Home Page (http://www.owo.com).

=================================================================================================

