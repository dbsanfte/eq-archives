<html>
<head>
	<title>EverQuest Roster: Roster Footer</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<link rel="stylesheet" href="roster.css" type="text/css">
</head>

<body>


<?php
// Includes
require_once( './config.php' );
require_once( './includes/form.inc' );
require_once( './includes/functions.inc' );

// Main PHP code
{
	// Declare variables
	$strFormName		= $_GET['FormName'];
	$strUserName		= $_GET['UserName'];
	$strPassword		= $_GET['Password'];
	$strSortOrder		= $_GET['SortOrder'];
	$strSortDirection	= $_GET['SortDirection'];
	$strShowAlts		= $_GET['ShowAlts'];
	$strClassFilter		= $_GET['ClassFilter'];

	// Create the Form object
	$theForm		= new $strFormName;

	// Check if we're on the User_Create
	if( ( $strFormName == "User_Modify" ) &&
		( !IsUserVerified( $strUserName ) ) )
	{
		// Show the Form Footer
		$theForm->ShowFooter( $strUserName, $strPassword );
	}
	else
	{
		// NEVER pass the UserName and Password to ...
		if( $strFormName == "User_Verify" )		// The User_Verify page
		{
			$strUserName	= "";
			$strPassword	= "";
		}

		// Show the footer
		ShowFooter( $strUserName, $strPassword, $strFormName, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter );
	}
}



// Show the footer
function ShowFooter( $strUserName, $strPassword, $strFormName, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
{
	// Check if we should show the User link
	$strUserLink	= "";
	if( ( isset( $strUserName ) ) &&
		( $strUserName != "Guest" ) &&
		( $strUserName != "" ) )
	{
		$strUserLink		= '<a href="form.php?FormName=User_Modify&UserName='			. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '&ModifyUserName=' . $strUserName . '"	OnMouseOver="window.status=\'Modify ' . $strUserName . '\\\'s settings\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Modify ' . $strUserName . '\'s settings"><img src="images/modify.gif" border="0" /></a>';
		
		// Check if the user has Administrator rights
		if( IsAdministrator( $strUserName ) )
		{
			$strUserLink	= '<a href="form.php?FormName=Characters_Delete&UserName='		. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Delete characters\';return true;"						OnMouseOut="window.status=\'\'"	target=Body title="Delete characters"><img src="images/delete_large.gif" border="0" /></a>' .
							  '<a href="guildtool_update.php?UserName='						. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Update the roster from a guild dump\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Update the roster from a guild dump"><img src="images/import.gif" border="0" /></a>' .
							  $strUserLink .
							  '<a href="form.php?FormName=Users&UserName='					. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Show all Roster Users\';return true;"					OnMouseOut="window.status=\'\'"	target=Body title="Show all Roster Users"><img src="images/users.gif" border="0" /></a>';
		}
		$strUserLink		.= '<a href="form.php?FormName=Magelo_Batch_Import&UserName='	. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Batch Import character magelos\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Batch Import character magelos"><img src="images/magelo.gif" border="0" /></a>';
	}

	// Check if we should show the Login or Logoff
	$strLastLink	= "";
	if( ( !isset( $strUserName ) ) ||
		( $strUserName == "" ) )
	{
		$strLogInOutLink	= '<a href="form.php?FormName=User_Login&UserName='	. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Log in\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Log in">Log in</a>';
	}
	else
	{
		$strLogInOutLink	= '<a href="form.php?FormName=Characters&UserName=&Password=&CookieAction=DELETE&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Log ' . $strUserName . ' out\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Log ' . $strUserName . ' out">Log out</a>';
	}

	// Create the class filter select
	$strSelectClassFilter	= '<select name="cmbClassFilter" id="cmbClassFilter" onChange="SetClassFilter();" class="SelectBox" title="Select a class filter"><br />
		      <option class="OptionOdd"  value="<<All>>"		title="Show all classes"			><< All >></option><br />
		      <option class="OptionEven" value="Bard"			title="Only show Bards"				>Bard</option>
		      <option class="OptionOdd"  value="Beastlord"		title="Only show Beastlords"		>Beastlord</option>
		      <option class="OptionEven" value="Berserker"		title="Only show Berserkers"		>Berserker</option>
		      <option class="OptionOdd"  value="Cleric"			title="Only show Clerics"			>Cleric</option>
		      <option class="OptionEven" value="Druid"			title="Only show Druids"			>Druid</option>
		      <option class="OptionOdd"  value="Enchanter"		title="Only show Enchanters"		>Enchanter</option>
		      <option class="OptionEven" value="Magician"		title="Only show Magicians"			>Magician</option>
		      <option class="OptionOdd"  value="Monk"			title="Only show Monks"				>Monk</option>
		      <option class="OptionEven" value="Necromancer"	title="Only show Necromancers"		>Necromancer</option>
		      <option class="OptionOdd"  value="Paladin"		title="Only show Paladins"			>Paladin</option>
		      <option class="OptionEven" value="Ranger"			title="Only show Rangers"			>Ranger</option>
		      <option class="OptionOdd"  value="Rogue"			title="Only show Rogues"			>Rogue</option>
		      <option class="OptionEven" value="Shadow Knight"	title="Only show Shadow Knights"	>Shadow Knight</option>
		      <option class="OptionOdd"  value="Shaman"			title="Only show Shamans"			>Shaman</option>
		      <option class="OptionEven" value="Warrior"		title="Only show Warriors"			>Warrior</option>
		      <option class="OptionOdd"  value="Wizard"			title="Only show Wizards"			>Wizard</option>
		  </select>';
	// Select the current value
	$strSelectClassFilter	= str_replace( '"' . $strClassFilter . '"', '"' . $strClassFilter . '" selected="selected"', $strSelectClassFilter );


	echo '
	<script language="JavaScript">
	<!-- Filter on the selected class -->
	function SetClassFilter()
	{
		// Submit the form
		parent.location = "form.php?FormName=' . $strFormName . '&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection . '&ShowAlts=' . $strShowAlts . '&ClassFilter=" + document.all.cmbClassFilter.value;

		// Done
		return true;
	};
	</script>

	<!-- Start of Footer -->
	<div id="Footer" align="center">
	<table width="98%" border="0" cellspacing="0" cellpadding="0">
	  <tr>
		<td align="center">
		  ' . $strUserLink . '
		  <a href="form.php?FormName=Statistics'			. '&UserName='	. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"					OnMouseOver="window.status=\'Show Roster/Guild Statistics\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Show Roster/Guild Statistics"><img src="images/question.gif" border="0" /></a> | 
		  <a href="form.php?FormName=Characters'			. '&UserName='	. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '&CookieAction=READ"	OnMouseOver="window.status=\'Show all Characters\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Show all Characters">Characters</a> | 
		  <a href="form.php?FormName=Character_Statistics'	. '&UserName='	. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"					OnMouseOver="window.status=\'Show all Character Statistics\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Show all Character Statistics">Stats</a> | 
		  <a href="form.php?FormName=TradeSkills'			. '&UserName='	. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"					OnMouseOver="window.status=\'Show all TradeSkills\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Show all TradeSkills">TradeSkills</a> | 
		  <a href="form.php?FormName=Keys'					. '&UserName='	. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"					OnMouseOver="window.status=\'Show all Keys and Flags\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Show all Keys and Flags">Keys</a> | 
		  <a href="form.php?FormName=SSRA_Keys'				. '&UserName='	. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"					OnMouseOver="window.status=\'Show the SSRA Emperor key parts\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Show the SSRA Emperor key parts">SSRA Emperor key</a> | 
		  <a href="form.php?FormName=Veeshans_Peak_Keys'	. '&UserName='	. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"					OnMouseOver="window.status=\'Show the Veeshans Peak key parts\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Show the Veeshans Peak key parts">Veeshans Peak key</a> | 
		  <a href="form.php?FormName=Vex_Thal_Keys'			. '&UserName='	. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"					OnMouseOver="window.status=\'Show the Vex Thal key parts\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Show the Vex Thal key parts">Vex Thal key</a> | 
		  ' . $strLogInOutLink . '
		</td>
	  </tr>
	  <tr>
		<td align="center">
		  <font color="#CCCCCC">Flags: </font>
		  <a href="form.php?FormName=PoP_Tier_1_Flags'		. '&UserName='	. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"					OnMouseOver="window.status=\'Show all Planes of Power: Tier 1 Flags\';return true;"								OnMouseOut="window.status=\'\'"	target=Body title="Show all Planes of Power: Tier 1 Flags">PoP Tier 1</a> | 
		  <a href="form.php?FormName=PoP_Tier_2_Flags'		. '&UserName='	. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"					OnMouseOver="window.status=\'Show all Planes of Power: Tier 2 Flags\';return true;"								OnMouseOut="window.status=\'\'"	target=Body title="Show all Planes of Power: Tier 2 Flags">PoP Tier 2</a> | 
		  <a href="form.php?FormName=PoP_Tier_3_Flags'		. '&UserName='	. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"					OnMouseOver="window.status=\'Show all Planes of Power: Tier 3 Flags\';return true;"								OnMouseOut="window.status=\'\'"	target=Body title="Show all Planes of Power: Tier 3 Flags">PoP Tier 3</a> | 
		  <a href="form.php?FormName=PoP_Tier_4_Flags'		. '&UserName='	. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"					OnMouseOver="window.status=\'Show all Planes of Power: Tier 4 Flags\';return true;"								OnMouseOut="window.status=\'\'"	target=Body title="Show all Planes of Power: Tier 4 Flags">PoP Tier 4</a> | 
		  <a href="form.php?FormName=GoD_Flags'				. '&UserName='	. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"					OnMouseOver="window.status=\'Show all Gates of Discord Flags\';return true;"									OnMouseOut="window.status=\'\'"	target=Body title="Show all Gates of Discord Flags">GoD</a> | 
		  <a href="form.php?FormName=OoW_CoA'				. '&UserName='	. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"					OnMouseOver="window.status=\'Show all Omens of War: Citadel of Anguish Flags\';return true;"					OnMouseOut="window.status=\'\'"	target=Body title="Show all Omens of War: Citadel of Anguish Flags">OoW</a> | 
		  <a href="form.php?FormName=DoN_Flags'				. '&UserName='	. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"					OnMouseOver="window.status=\'Show all Dragons of Norrath Flags\';return true;"									OnMouseOut="window.status=\'\'"	target=Body title="Show all Dragons of Norrath Flags">DoN</a> | 
		  <a href="form.php?FormName=DoD_Spells'			. '&UserName='	. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"					OnMouseOver="window.status=\'Show the Depths of Darkhollow: Spells progression\';return true;"					OnMouseOut="window.status=\'\'"	target=Body title="Show the Depths of Darkhollow Spells progression">DoD</a> | 
		  <a href="form.php?FormName=PoS_Askr_Quest'		. '&UserName='	. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"					OnMouseOver="window.status=\'Show the Plane of Storms: Askr Quest progression (for BoT Flag)\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Show the Plane of Storms: Askr Quest progression (for BoT Flag)">PoS Askr Quest</a> | 
		  <font color="#CCCCCC">Class: </font>
		  ' . $strSelectClassFilter . '
		</td>
	  </tr>
	  <tr>
		<td align="center">
		  <font size="-1" color="#8CC8F6">
		    EverQuest Roster v3.4.0 &#160&#160&#160 
		  </font>
		  <font size="-1">
		    ( <a href="http://eqroster.gameplayheaven.com/history.html"	OnMouseOver="window.status=\'Show the history of the EverQuest Roster\';return true;"	OnMouseOut="window.status=\'\'"	target=_blank title="Show the history of the EverQuest Roster">History</a>
		    / <a href="http://forums.gameplayheaven.com"				OnMouseOver="window.status=\'Go to the official EverQuest Roster forums\';return true;"	OnMouseOut="window.status=\'\'"	target=_blank title="Go to the official EverQuest Roster forums">Forums</a> )
		  </font>
		  <font size="-1" color="#8CC8F6">
		     &#160&#160&#160 &#169 GamePlayHeaven
		  </font>
		</td>
	  </tr>
	</table>
	</div>
	<!-- End of Footer -->
	';
}



?>

</body>
</html>
