<html>
<head>
	<title>EverQuest Roster: Modify Character</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<link rel="stylesheet" type="text/css" href="roster.css">
	<style>
		body
		{
			height:							101%;
		}

		div #Statistics
		{
			margin:		0px 0px 0px 0px;
			display:	none;
		}

		div #Tradeskills
		{
			margin:		0px 0px 0px 0px;
			display:	none;
		}

		div #Keys_Progression
		{
			margin:		0px 0px 0px 0px;
			display:	none;
		}

		div #PoP_Progression
		{
			margin:		0px 0px 0px 0px;
			display:	none;
		}

		div #GoD_Progression
		{
			margin:		0px 0px 0px 0px;
			display:	none;
		}

		div #OoW_CoA_Progression
		{
			margin:		0px 0px 0px 0px;
			display:	none;
		}

		div #DoN_Progression
		{
			margin:		0px 0px 0px 0px;
			display:	none;
		}

		div #DoN_Progression_Good
		{
			margin:		0px 0px 0px 0px;
			display:	none;
		}

		div #DoN_Progression_Evil
		{
			margin:		0px 0px 0px 0px;
			display:	none;
		}

		div #DoD_Progression
		{
			margin:		0px 0px 0px 0px;
			display:	none;
		}
	</style>
</head>

<body>
	<p>&nbsp;</p>


<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );
require_once( './includes/functions_database.inc' );
require_once( './includes/class.magelo.inc' );

// Main PHP code
{
	// Retrieve parameters
	$strUserName						= $_GET['UserName'];
	$strPassword						= $_GET['Password'];
	$strCharName						= $_GET['CharName'];
	$strPreviousForm					= $_GET['PreviousForm'];
	$strSortOrder						= $_GET['SortOrder'];
	$strSortDirection					= $_GET['SortDirection'];
	$strShowAlts						= $_GET['ShowAlts'];
	$strClassFilter						= $_GET['ClassFilter'];
		// Character info
	$strLastName						= $_POST['editLastName'];
	$strNameMain						= $_POST['cmbNameMain'];
	$strGuildStatus						= $_POST['cmbGuildStatus'];
	$strClass							= $_POST['editClass'];
	$nLevel								= $_POST['editLevel'];
	$nAA								= $_POST['editAA'];
	$nGLP								= $_POST['editGLP'];
	$strRace							= $_POST['cmbRace'];
	$strGender							= $_POST['cmbGender'];
	$nMageloNr							= $_POST['editMageloNr'];
		// Character Statistics
	$nHP								= $_POST['editHP'];
	$nMana								= $_POST['editMana'];
	$nAC								= $_POST['editAC'];
	$nFT								= $_POST['editFT'];
	$nRegen								= $_POST['editRegen'];
	$nAtk								= $_POST['editAtk'];
	$nStr								= $_POST['editStr'];
	$nSta								= $_POST['editSta'];
	$nAgi								= $_POST['editAgi'];
	$nDex								= $_POST['editDex'];
	$nWis								= $_POST['editWis'];
	$nInt								= $_POST['editInt'];
	$nCha								= $_POST['editCha'];
	$nPR								= $_POST['editPR'];
	$nMR								= $_POST['editMR'];
	$nDR								= $_POST['editDR'];
	$nFR								= $_POST['editFR'];
	$nCR								= $_POST['editCR'];
		// Trade Skills
	$nAlchemy							= $_POST['editAlchemy'];
	$nBaking							= $_POST['editBaking'];
	$nBrewing							= $_POST['editBrewing'];
	$nFishing							= $_POST['editFishing'];
	$nFletching							= $_POST['editFletching'];
	$nForaging							= $_POST['editForaging'];
	$nJewelcraft						= $_POST['editJewelcraft'];
	$nPoison							= $_POST['editPoison'];
	$nPottery							= $_POST['editPottery'];
	$nResearch							= $_POST['editResearch'];
	$nSmithing							= $_POST['editSmithing'];
	$nTailoring							= $_POST['editTailoring'];
	$nTinkering							= $_POST['editTinkering'];
		// Keys
	$nBoT_Tower_Key						= $_POST['cbBoT_Tower_Key'];
	$nHowling_Stones_Key				= $_POST['cbHowling_Stones_Key'];
	$nSebilis_Key						= $_POST['cbSebilis_Key'];
	$nSleepers_Tomb_Key					= $_POST['cbSleepers_Tomb_Key'];
	$nSSRA_Emperor_Key					= $_POST['cbSSRA_Emperor_Key'];
	$nVeeshans_Peak_Key					= $_POST['cbVeeshans_Peak_Key'];
	$nVex_Thal_Key						= $_POST['cbVex_Thal_Key'];
		// BoT flag
	$nHead								= $_POST['cbHead'];
	$nBeard								= $_POST['cbBeard'];
	$nBone								= $_POST['cbBone'];
	$nSash								= $_POST['cbSash'];
	$nOceanMedal						= $_POST['cbOceanMedal'];
	$nDesertMedal						= $_POST['cbDesertMedal'];
	$nForestMedal						= $_POST['cbForestMedal'];
		// SSRA Emperor key
	$nTaskmasters_Pouch					= $_POST['cbTaskmasters_Pouch'];
	$nZazuzhs_Idol						= $_POST['cbZazuzhs_Idol'];
	$nRing								= $_POST['cbRing'];
	$nInsignia							= $_POST['cbInsignia'];
		// Veeshan's Peek key
	$nKylongMedal_Top					= $_POST['cbKylongMedal_Top'];
	$nKylongMedal_Middle				= $_POST['cbKylongMedal_Middle'];
	$nKylongMedal_Bottom				= $_POST['cbKylongMedal_Bottom'];
	$nJarsathMedal_Top					= $_POST['cbJarsathMedal_Top'];
	$nJarsathMedal_Middle				= $_POST['cbJarsathMedal_Middle'];
	$nJarsathMedal_Bottom				= $_POST['cbJarsathMedal_Bottom'];
	$nObulusMedal_Top					= $_POST['cbObulusMedal_Top'];
	$nObulusMedal_Middle				= $_POST['cbObulusMedal_Middle'];
	$nObulusMedal_Bottom				= $_POST['cbObulusMedal_Bottom'];
	$nTrak_Tooth						= $_POST['cbTrak_Tooth'];
		// Vex Thal key
	$nGlowing_Orb						= $_POST['cbGlowing_Orb'];
	$nCelestial_Rift					= $_POST['cbCelestial_Rift'];
	$nShard_Dat							= $_POST['cbShard_Dat'];
	$nShard_Dax							= $_POST['cbShard_Dax'];
	$nShard_Kel							= $_POST['cbShard_Kel'];
	$nShard_Kelara						= $_POST['cbShard_Kelara'];
	$nShard_Lor							= $_POST['cbShard_Lor'];
	$nShard_Raf							= $_POST['cbShard_Raf'];
	$nShard_Set							= $_POST['cbShard_Set'];
	$nShard_Tak							= $_POST['cbShard_Tak'];
	$nShard_Ved							= $_POST['cbShard_Ved'];
	$nShard_Vin							= $_POST['cbShard_Vin'];
		// Pop Tier 1 Flags
	$nAny_PoJ_Trial						= $_POST['cbAny_PoJ_Trial'];
	$nAll_PoJ_Trials					= $_POST['cbAll_PoJ_Trials'];
	$nPoI_Xanamech						= $_POST['cbPoI_Xanamech'];
	$nPoI_Behemoth						= $_POST['cbPoI_Behemoth'];
	$nPoD_Grimror_Quest					= $_POST['cbPoD_Grimror_Quest'];
	$nPoD_Grummus						= $_POST['cbPoD_Grummus'];
	$nPoN_Hedge_Quest					= $_POST['cbPoN_Hedge_Quest'];
	$nPoNb_Terris_Thule					= $_POST['cbPoNb_Terris_Thule'];
		// Pop Tier 2 Flags
	$nPoS_Askr_Quest					= $_POST['cbPoS_Askr_Quest'];
	$nPoV_Grenic_Quest					= $_POST['cbPoV_Grenic_Quest'];
	$nPoV_AerinDar						= $_POST['cbPoV_AerinDar'];
	$nCoD_Carprin_Event					= $_POST['cbCoD_Carprin_Event'];
	$nCoD_Bertoxxulous					= $_POST['cbCoD_Bertoxxulous'];
	$nPoTorment_Saryrn					= $_POST['cbPoTorment_Saryrn'];
	$nPoS_Wembly_Quest					= $_POST['cbPoS_Wembly_Quest'];
		// Pop Tier 3 Flags
	$nHoH_Trial1_RyddaDar				= $_POST['cbHoH_Trial1_RyddaDar'];
	$nHoH_Trial2_Ogre					= $_POST['cbHoH_Trial2_Ogre'];
	$nHoH_Trial3_Madmen					= $_POST['cbHoH_Trial3_Madmen'];
	$nHoHb_Mithanial_Marr				= $_POST['cbHoHb_Mithanial_Marr'];
	$nPoTactics_Tallon_Zek				= $_POST['cbPoTactics_Tallon_Zek'];
	$nPoTactics_Vallon_Zek				= $_POST['cbPoTactics_Vallon_Zek'];
	$nPoTactics_Rallos_Zek_Quest		= $_POST['cbPoTactics_Rallos_Zek_Quest'];
	$nBoT_Rescue_Karana_Quest			= $_POST['cbBoT_Rescue_Karana_Quest'];
	$nSolRoTower_Jiva					= $_POST['cbSolRoTower_Jiva'];
	$nSolRoTower_Xuzl					= $_POST['cbSolRoTower_Xuzl'];
	$nSolRoTower_Arlyxir				= $_POST['cbSolRoTower_Arlyxir'];
	$nSolRoTower_Rizlona				= $_POST['cbSolRoTower_Rizlona'];
	$nSolRoTower_Protector_of_Dresolik	= $_POST['cbSolRoTower_Protector_of_Dresolik'];
	$nSolRoTower_Solusek_Ro				= $_POST['cbSolRoTower_Solusek_Ro'];
		// Pop Tier 4 Flags
	$nPoAir_Xegony						= $_POST['cbPoAir_Xegony'];
	$nPoFire_Fennin_Ro					= $_POST['cbPoFire_Fennin_Ro'];
	$nPoWater_Coirnav					= $_POST['cbPoWater_Coirnav'];
	$nPoEarthb_The_Rathe				= $_POST['cbPoEarthb_The_Rathe'];
	$nPoTime_Time_Phased_Quintessence	= $_POST['cbPoTime_Time_Phased_Quintessence'];
		// GoD Flags
	$nPurifying_Plant					= $_POST['cbPurifying_Plant'];
	$nEmanating_Furnace					= $_POST['cbEmanating_Furnace'];
	$nLair_of_Trapped_Ones				= $_POST['cbLair_of_Trapped_Ones'];
	$nPool_of_Sludge					= $_POST['cbPool_of_Sludge'];
	$nSmith_Rondo						= $_POST['cbSmith_Rondo'];
	$nVxed								= $_POST['cbVxed'];
	$nTipt								= $_POST['cbTipt'];
	$nVrex_Barxt_Qurat					= $_POST['cbVrex_Barxt_Qurat'];
	$nKeeper_of_the_Altar				= $_POST['cbKeeper_of_the_Altar'];
	$nNoqufiel_in_Inktuta				= $_POST['cbNoqufiel_in_Inktuta'];
	$nCynosure_Kvanjji					= $_POST['cbCynosure_Kvanjji'];
	$nIxt_Hsek_Syat						= $_POST['cbIxt_Hsek_Syat'];
	$nHigh_Priest_Nkosi_Bakari			= $_POST['cbHigh_Priest_Nkosi_Bakari'];
	$nZunMuram_Tkarish_Zyk				= $_POST['cbZunMuram_Tkarish_Zyk'];
		// OoW CoA
	$nMastery_of_Adaptation				= $_POST['cbMastery_of_Adaptation'];
	$nMastery_of_Corruption				= $_POST['cbMastery_of_Corruption'];
	$nMastery_of_Endurance				= $_POST['cbMastery_of_Endurance'];
	$nMastery_of_Foresight				= $_POST['cbMastery_of_Foresight'];
	$nMastery_of_Hate					= $_POST['cbMastery_of_Hate'];
	$nMastery_of_Specialization			= $_POST['cbMastery_of_Specialization'];
	$nSeal_Mastery_of_All				= $_POST['cbSeal_Mastery_of_All'];
	$nSignet_Crystal_Gemmed				= $_POST['cbSignet_Crystal_Gemmed'];
	$nSignet_Discolored					= $_POST['cbSignet_Discolored'];
	$nSignet_Dust_Marred				= $_POST['cbSignet_Dust_Marred'];
	$nSignet_Glimmering					= $_POST['cbSignet_Glimmering'];
	$nSignet_Tarnished					= $_POST['cbSignet_Tarnished'];
	$nSignet_Two_Toned					= $_POST['cbSignet_Two_Toned'];
	$nSignet_Weather_Worn				= $_POST['cbSignet_Weather_Worn'];
		// DoN Flags
	$nT1_Create_an_Antidote				= $_POST['cbT1_Create_an_Antidote'];
	$nT1_Greed_of_the_Goblins			= $_POST['cbT1_Greed_of_the_Goblins'];
	$nT1_Burning_Arrows					= $_POST['cbT1_Burning_Arrows'];
	$nT1_Children_of_Gimblax			= $_POST['cbT1_Children_of_Gimblax'];
	$nT2_Defend_the_Kirin_Contact		= $_POST['cbT2_Defend_the_Kirin_Contact'];
	$nT2_Recover_the_Lost_Map			= $_POST['cbT2_Recover_the_Lost_Map'];
	$nT2_Turn_the_Tides_of_the_Sand		= $_POST['cbT2_Turn_the_Tides_of_the_Sand'];
	$nT2_Sickness_of_the_Spirit			= $_POST['cbT2_Sickness_of_the_Spirit'];
	$nT2_Calling_Emoush					= $_POST['cbT2_Calling_Emoush'];
	$nT3_Protect_the_Waters				= $_POST['cbT3_Protect_the_Waters'];
	$nT3_Snowfoots_Revenge				= $_POST['cbT3_Snowfoots_Revenge'];
	$nT3_The_Sacred_Scrolls				= $_POST['cbT3_The_Sacred_Scrolls'];
	$nT3_History_of_the_Isle			= $_POST['cbT3_History_of_the_Isle'];
	$nT3_Trial_of_Perserverance			= $_POST['cbT3_Trial_of_Perserverance'];
	$nT3_Volkaras_Bite					= $_POST['cbT3_Volkaras_Bite'];
	$nT4_Goblin_Dojo					= $_POST['cbT4_Goblin_Dojo'];
	$nT4_Guardian_of_the_Sands			= $_POST['cbT4_Guardian_of_the_Sands'];
	$nT4_An_End_to_the_Storms			= $_POST['cbT4_An_End_to_the_Storms'];
	$nT5_Origins_of_the_Curse			= $_POST['cbT5_Origins_of_the_Curse'];
	$nT5_The_Curse_of_JuRek				= $_POST['cbT5_The_Curse_of_JuRek'];
	$nT5_In_the_Shadows					= $_POST['cbT5_In_the_Shadows'];
		// DoD Spells
	$nA_Rogues_Trust					= $_POST['cbA_Rogues_Trust'];
	$nScouting_the_City					= $_POST['cbScouting_the_City'];
	$nBuilding_the_Disguise				= $_POST['cbBuilding_the_Disguise'];
	$nThe_Search_for_Illsuras			= $_POST['cbThe_Search_for_Illsuras'];
	$nThe_Rage_of_Kelliad				= $_POST['cbThe_Rage_of_Kelliad'];
	$nThe_Lost_Notebook					= $_POST['cbThe_Lost_Notebook'];
	$nCavern_Botany						= $_POST['cbCavern_Botany'];
	$nThe_Search_for_Clues				= $_POST['cbThe_Search_for_Clues'];
	$nRescue_Cicero						= $_POST['cbRescue_Cicero'];
	$nPreemptive_Strike					= $_POST['cbPreemptive_Strike'];
	$nPraetorian_Guard					= $_POST['cbPraetorian_Guard'];
	$nThe_Fall_of_Illsalin				= $_POST['cbThe_Fall_of_Illsalin'];
	$nFlights_of_the_Seeker				= $_POST['cbFlights_of_the_Seeker'];
	$nInto_the_Shadows					= $_POST['cbInto_the_Shadows'];
		// Validation tag
	$bValidated							= $_POST['cbValidated'];
		// CancelModify tag
	$bCancelModify						= $_POST['cbCancelModify'];
		// ImportMagelo tag
	$bImportMagelo						= $_POST['cbImportMagelo'];
		// Show Progression tags
	$bShowStatistics					= $_POST['cbDisplayStatistics'];
	$bShowTradeskills					= $_POST['cbDisplayTradeskills'];
	$bShowKeysProgression				= $_POST['cbDisplayKeysProgression'];
	$bShowPoPProgression				= $_POST['cbDisplayPoPProgression'];
	$bShowGoDProgression				= $_POST['cbDisplayGoDProgression'];
	$bShowOoW_CoAProgression			= $_POST['cbDisplayOoW_CoAProgression'];
	$bShowDoNProgression				= $_POST['cbDisplayDoNProgression'];
	$bShowDoDProgression				= $_POST['cbDisplayDoDProgression'];
		// DoN Progression Good/Evil tag
	$strDoNProgression					= $_POST['DoN_Progression'];
	if( $strDoNProgression == "Good" )
	{
		$bDoNProgressionGood			= true;
	}
	else
	{
		$bDoNProgressionGood			= false;
	}

	// Default Progression tags
	if( !isset( $nLevel ) )
	{
		$bShowStatistics				= true;
		$bShowTradeskills				= false;
		$bShowKeysProgression			= false;
		$bShowPoPProgression			= false;
		$bShowGoDProgression			= false;
		$bShowOoW_CoAProgression		= false;
		$bShowDoNProgression			= false;
		$bDoNProgressionGood			= false;
		$bShowDoDProgression			= false;
	}

	// We can't do anything if the CharName is unkown
	if( !isset( $strCharName ) )
	{
		// Show error message
		print( "	<center><font size=+2 color=\"#FF3300\">\n" );
		print( "	  Illegal call to Modify Character page... <br />\n" );
		print( "	  Contact the board admin!\n" );
		print( "	</font></center>\n\n" );
	}
	// Check if the user cancelled the modify
	else if( ( isset( $bCancelModify ) ) &&
			 ( $bCancelModify == "true" ) )
	{
		// redirect the user back to page he clicked modify on
		echo '<meta http-equiv="Refresh" content="0; url=form.php?FormName=' . $strPreviousForm . '&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&ClassFilter=' . $strClassFilter . '">';
	}
	// Check if the page has been validated
	else if( ( isset( $bValidated ) ) &&
			 ( $bValidated == true ) )
	{
		// Re-check the password, to prevent hacking
		if( CheckPassword( $strUserName, $strPassword ) == false )
		{
			// Wrong password, warn the user
			print( "	<center><font size=+2 color=\"#FF3300\">\n" );
			print( "	  Incorrect password detected... <br />\n" );
			print( "	  You will be logged out and returned to the main page!\n" );
			print( "	</font></center>\n\n" );

			// Show main page
			echo '<meta http-equiv="Refresh" content="5; url=form.php?FormName=Characters&UserName=&Password="; target=Body>';    
			// Abort page
			exit;
		}
		
		// Make sure the Last Name is properly formatted (Names start with capital etc.)
		$strLastName	= FormatName( $strLastName );

		// Update the Character
		$nCharID	= UpdateCharacter( $strCharName, $strLastName, $strNameMain, $strGuildStatus, $nAA, $nGLP, $strRace, $strGender, $nMageloNr, $nHP, $nMana, $nAC, $nFT, $nRegen, $nAtk, $nStr, $nSta, $nAgi, $nDex, $nWis, $nInt, $nCha, $nPR, $nMR, $nDR, $nFR, $nCR );
		if( $nCharID > 0 )
		{
			// Update the Tradeskill record
			$strResult	= UpdateTradeskills( $nCharID, $strCharName, $nAlchemy, $nBaking, $nBrewing, $nFishing, $nFletching, $nForaging, $nJewelcraft, $nPoison, $nPottery, $nResearch, $nSmithing, $nTailoring, $nTinkering );
			// Update the Keys record
			$strResult	= UpdateKeys( $nCharID, $strCharName, $nBoT_Tower_Key, $nHowling_Stones_Key, $nSebilis_Key, $nSleepers_Tomb_Key, $nSSRA_Emperor_Key, $nVeeshans_Peak_Key, $nVex_Thal_Key );
			// Update the PoS_Askr_Quest record
			$strResult	= UpdatePoS_Askr_Quest( $nCharID, $strCharName, $nHead, $nBeard, $nBone, $nSash, $nOceanMedal, $nDesertMedal, $nForestMedal );
			// Update the SSRA_Emperor_Key record
			$strResult	= UpdateSSRAEmperorKey( $nCharID, $strCharName, $nTaskmasters_Pouch, $nZazuzhs_Idol, $nRing, $nInsignia );
			// Update the Veeshans_Peak_Key record
			$strResult	= UpdateVeeshansPeakKey( $nCharID, $strCharName, $nKylongMedal_Top, $nKylongMedal_Middle, $nKylongMedal_Bottom, $nJarsathMedal_Top, $nJarsathMedal_Middle, $nJarsathMedal_Bottom, $nObulusMedal_Top, $nObulusMedal_Middle, $nObulusMedal_Bottom, $nTrak_Tooth );
			// Update the Vex_Thal_Key record
			$strResult	= UpdateVexThalKey( $nCharID, $strCharName, $nGlowing_Orb, $nCelestial_Rift, $nShard_Dat, $nShard_Dax, $nShard_Kel, $nShard_Kelara, $nShard_Lor, $nShard_Raf, $nShard_Set, $nShard_Tak, $nShard_Ved, $nShard_Vin );
			// Update the Pop Tier 1 Flags record
			$strResult	= UpdatePoPTier1( $nCharID, $strCharName, $nAny_PoJ_Trial, $nAll_PoJ_Trials, $nPoI_Xanamech, $nPoI_Behemoth, $nPoD_Grimror_Quest, $nPoD_Grummus, $nPoN_Hedge_Quest, $nPoNb_Terris_Thule );
			// Update the Pop Tier 2 Flags record
			$strResult	= UpdatePoPTier2( $nCharID, $strCharName, $nPoS_Askr_Quest, $nPoV_Grenic_Quest, $nPoV_AerinDar, $nCoD_Carprin_Event, $nCoD_Bertoxxulous, $nPoTorment_Saryrn, $nPoS_Wembly_Quest );
			// Update the Pop Tier 3 Flags record
			$strResult	= UpdatePoPTier3( $nCharID, $strCharName, $nHoH_Trial1_RyddaDar, $nHoH_Trial2_Ogre, $nHoH_Trial3_Madmen, $nHoHb_Mithanial_Marr, $nPoTactics_Tallon_Zek, $nPoTactics_Vallon_Zek, $nPoTactics_Rallos_Zek_Quest, $nBoT_Rescue_Karana_Quest, $nSolRoTower_Jiva, $nSolRoTower_Xuzl, $nSolRoTower_Arlyxir, $nSolRoTower_Rizlona, $nSolRoTower_Protector_of_Dresolik, $nSolRoTower_Solusek_Ro );
			// Update the Pop Tier 4 Flags record
			$strResult	= UpdatePoPTier4( $nCharID, $strCharName, $nPoAir_Xegony, $nPoFire_Fennin_Ro, $nPoWater_Coirnav, $nPoEarthb_The_Rathe, $nPoTime_Time_Phased_Quintessence );
			// Update the GoD Flags record
			$strResult	= UpdateGoDFlags( $nCharID, $strCharName, $nPurifying_Plant, $nEmanating_Furnace, $nLair_of_Trapped_Ones, $nPool_of_Sludge, $nSmith_Rondo, $nVxed, $nTipt, $nVrex_Barxt_Qurat, $nKeeper_of_the_Altar, $nNoqufiel_in_Inktuta, $nCynosure_Kvanjji, $nIxt_Hsek_Syat, $nHigh_Priest_Nkosi_Bakari, $nZunMuram_Tkarish_Zyk );
			// Update the OoW CoA record
			$strResult	= UpdateOoW_CoA( $nCharID, $strCharName, $nMastery_of_Adaptation, $nMastery_of_Corruption, $nMastery_of_Endurance, $nMastery_of_Foresight, $nMastery_of_Hate, $nMastery_of_Specialization, $nSeal_Mastery_of_All, $nSignet_Crystal_Gemmed, $nSignet_Discolored, $nSignet_Dust_Marred, $nSignet_Glimmering, $nSignet_Tarnished, $nSignet_Two_Toned, $nSignet_Weather_Worn );
			// Update the DoN Flags record
			$strResult	= UpdateDoNFlags( $nCharID, $strCharName, $nT1_Create_an_Antidote, $nT1_Greed_of_the_Goblins, $nT1_Burning_Arrows, $nT1_Children_of_Gimblax, $nT2_Defend_the_Kirin_Contact, $nT2_Recover_the_Lost_Map, $nT2_Turn_the_Tides_of_the_Sand, $nT2_Sickness_of_the_Spirit, $nT2_Calling_Emoush, $nT3_Protect_the_Waters, $nT3_Snowfoots_Revenge, $nT3_The_Sacred_Scrolls, $nT3_History_of_the_Isle, $nT3_Trial_of_Perserverance, $nT3_Volkaras_Bite, $nT4_Goblin_Dojo, $nT4_Guardian_of_the_Sands, $nT4_An_End_to_the_Storms, $nT5_Origins_of_the_Curse, $nT5_The_Curse_of_JuRek, $nT5_In_the_Shadows );
			// Update the DoD Spells record
			$strResult	= UpdateDoDSpells( $nCharID, $strCharName, $nA_Rogues_Trust, $nScouting_the_City, $nBuilding_the_Disguise, $nThe_Search_for_Illsuras, $nThe_Rage_of_Kelliad, $nThe_Lost_Notebook, $nCavern_Botany, $nThe_Search_for_Clues, $nRescue_Cicero, $nPreemptive_Strike, $nPraetorian_Guard, $nThe_Fall_of_Illsalin, $nFlights_of_the_Seeker, $nInto_the_Shadows );

			// redirect the user back to page he clicked modify on
			echo '<meta http-equiv="Refresh" content="0; url=form.php?FormName=' . $strPreviousForm . '&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&ClassFilter=' . $strClassFilter . '">';
		}
	}
	// If we're not importing the magelo, retrieve all the Character data from the tables
	else if( !$bImportMagelo )
	{
		// Retrieve all Character data from the tables and show the Modify Character page
		ShowModifyCharacterPageFromTable( $strUserName, $strPassword, $strCharName, $strPreviousForm, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter, $bShowStatistics, $bShowTradeskills, $bShowKeysProgression, $bShowPoPProgression, $bShowGoDProgression, $bShowOoW_CoAProgression, $bShowDoNProgression, $bDoNProgressionGood, $bShowDoDProgression );
	}
	else
	{
		// Show the Modify Character page
		ShowModifyCharacterPage(	$strUserName, $strPassword, $strCharName, $strPreviousForm, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter, 
									// Character info
									$strCharName, $strLastName, $strNameMain, $strGuildStatus, $strClass, $nLevel, $nAA, $nGLP, $strRace, $strGender, $nMageloNr, 
									// Character Statistics
									$nHP, $nMana, $nAC, $nFT, $nRegen, $nAtk, $nStr, $nSta, $nAgi, $nDex, $nWis, $nInt, $nCha, $nPR, $nMR, $nDR, $nFR, $nCR, 
									// Trade Skills
									$nAlchemy, $nBaking, $nBrewing, $nFishing, $nFletching, $nForaging, $nJewelcraft, $nPoison, $nPottery, $nResearch, $nSmithing, $nTailoring, $nTinkering,
									// Keys
									$nBoT_Tower_Key, $nHowling_Stones_Key, $nSebilis_Key, $nSleepers_Tomb_Key, $nSSRA_Emperor_Key, $nVeeshans_Peak_Key, $nVex_Thal_Key, 
									// BoT flag
									$nHead, $nBeard, $nBone, $nSash, $nOceanMedal, $nDesertMedal, $nForestMedal, 
									// SSRA Emperor key
									$nTaskmasters_Pouch, $nZazuzhs_Idol, $nRing, $nInsignia, 
									// Veeshan's Peek key
									$nKylongMedal_Top, $nKylongMedal_Middle, $nKylongMedal_Bottom, $nJarsathMedal_Top, $nJarsathMedal_Middle, $nJarsathMedal_Bottom, $nObulusMedal_Top, $nObulusMedal_Middle, $nObulusMedal_Bottom, $nTrak_Tooth, 
									// Vex Thal key
									$nGlowing_Orb, $nCelestial_Rift, $nShard_Dat, $nShard_Dax, $nShard_Kel, $nShard_Kelara, $nShard_Lor, $nShard_Raf, $nShard_Set, $nShard_Tak, $nShard_Ved, $nShard_Vin, 
									// Pop Tier 1 Flags
									$nAny_PoJ_Trial, $nAll_PoJ_Trials, $nPoI_Xanamech, $nPoI_Behemoth, $nPoD_Grimror_Quest, $nPoD_Grummus, $nPoN_Hedge_Quest, $nPoNb_Terris_Thule, 
									// Pop Tier 2 Flags
									$nPoS_Askr_Quest, $nPoV_Grenic_Quest, $nPoV_AerinDar, $nCoD_Carprin_Event, $nCoD_Bertoxxulous, $nPoTorment_Saryrn, $nPoS_Wembly_Quest, 
									// Pop Tier 3 Flags
									$nHoH_Trial1_RyddaDar, $nHoH_Trial2_Ogre, $nHoH_Trial3_Madmen, $nHoHb_Mithanial_Marr, $nPoTactics_Tallon_Zek, $nPoTactics_Vallon_Zek, $nPoTactics_Rallos_Zek_Quest, $nBoT_Rescue_Karana_Quest, $nSolRoTower_Jiva, $nSolRoTower_Xuzl, $nSolRoTower_Arlyxir, $nSolRoTower_Rizlona, $nSolRoTower_Protector_of_Dresolik, $nSolRoTower_Solusek_Ro, 
									// Pop Tier 4 Flags
									$nPoAir_Xegony, $nPoFire_Fennin_Ro, $nPoWater_Coirnav, $nPoEarthb_The_Rathe, $nPoTime_Time_Phased_Quintessence, 
									// GoD Flags
									$nPurifying_Plant, $nEmanating_Furnace, $nLair_of_Trapped_Ones, $nPool_of_Sludge, $nSmith_Rondo, $nVxed, $nTipt, $nVrex_Barxt_Qurat, $nKeeper_of_the_Altar, $nNoqufiel_in_Inktuta, $nCynosure_Kvanjji, $nIxt_Hsek_Syat, $nHigh_Priest_Nkosi_Bakari, $nZunMuram_Tkarish_Zyk, 
									// OoW CoA
									$nMastery_of_Adaptation, $nMastery_of_Corruption, $nMastery_of_Endurance, $nMastery_of_Foresight, $nMastery_of_Hate, $nMastery_of_Specialization, $nSeal_Mastery_of_All, $nSignet_Crystal_Gemmed, $nSignet_Discolored, $nSignet_Dust_Marred, $nSignet_Glimmering, $nSignet_Tarnished, $nSignet_Two_Toned, $nSignet_Weather_Worn,
									// DoN Flags
									$nT1_Create_an_Antidote, $nT1_Greed_of_the_Goblins, $nT1_Burning_Arrows, $nT1_Children_of_Gimblax, $nT2_Defend_the_Kirin_Contact, $nT2_Recover_the_Lost_Map, $nT2_Turn_the_Tides_of_the_Sand, $nT2_Sickness_of_the_Spirit, $nT2_Calling_Emoush, $nT3_Protect_the_Waters, $nT3_Snowfoots_Revenge, $nT3_The_Sacred_Scrolls, $nT3_History_of_the_Isle, $nT3_Trial_of_Perserverance, $nT3_Volkaras_Bite, $nT4_Goblin_Dojo, $nT4_Guardian_of_the_Sands, $nT4_An_End_to_the_Storms, $nT5_Origins_of_the_Curse, $nT5_The_Curse_of_JuRek, $nT5_In_the_Shadows, 
									// DoD Spells
									$strNameMain, $nA_Rogues_Trust, $nScouting_the_City, $nBuilding_the_Disguise, $nThe_Search_for_Illsuras, $nThe_Rage_of_Kelliad, $nThe_Lost_Notebook, $nCavern_Botany, $nThe_Search_for_Clues, $nRescue_Cicero, $nPreemptive_Strike, $nPraetorian_Guard, $nThe_Fall_of_Illsalin, $nFlights_of_the_Seeker, $nInto_the_Shadows,
									// Validation tag
									$bValidated, $bImportMagelo, $bShowStatistics, $bShowTradeskills, $bShowKeysProgression, $bShowPoPProgression, $bShowGoDProgression, $bShowOoW_CoAProgression, $bShowDoNProgression, $bDoNProgressionGood, $bShowDoDProgression );
	}
}



// Retrieve all Character data from the tables and show the Modify Character page
function ShowModifyCharacterPageFromTable( $strUserName, $strPassword, $strCharName, $strPreviousForm, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter, $bShowStatistics, $bShowTradeskills, $bShowKeysProgression, $bShowPoPProgression, $bShowGoDProgression, $bShowOoW_CoAProgression, $bShowDoNProgression, $bDoNProgressionGood, $bShowDoDProgression )
{
	// Declare variables
	$strFontColorLight	= "#CCCCCC";
	$strFontColorDark	= "#999999";
	$strFontColor		= $strFontColorLight;
	$strSelectQuery		= "SELECT	Characters.CharID, LastName, NameMain, Class, Race, Gender, Level, AA, GLP, MageloNr, GuildStatus, \n" .
						  "         HP, Mana, AC, FlowingThought, Regen, Atk, Str, Sta, Agi, Dex, Wis, `Int`, Cha, PR, MR, DR, FR, CR, \n" .
						  "         Alchemy, Baking, Brewing, Fishing, Fletching, Foraging, Jewelcraft, Poison, Pottery, Research, Smithing, Tailoring, Tinkering, \n" .
						  "         BoT_Tower_Key, Howling_Stones_Key, Sebilis_Key, Sleepers_Tomb_Key, SSRA_Emperor_Key, Veeshans_Peak_Key, Vex_Thal_Key, \n" .
						  "         Head, Beard, Bone, Sash, OceanMedal, DesertMedal, ForestMedal, \n" .
						  "         Taskmasters_Pouch, Zazuzhs_Idol, Ring, Insignia, \n" .
						  "         KylongMedal_Top, KylongMedal_Middle, KylongMedal_Bottom, JarsathMedal_Top, JarsathMedal_Middle, JarsathMedal_Bottom, ObulusMedal_Top, ObulusMedal_Middle, ObulusMedal_Bottom, Trak_Tooth, \n" .
						  "         Glowing_Orb, Celestial_Rift, Shard_Dat, Shard_Dax, Shard_Kel, Shard_Kelara, Shard_Lor, Shard_Raf, Shard_Set, Shard_Tak, Shard_Ved, Shard_Vin, \n" .
						  "         Any_PoJ_Trial, All_PoJ_Trials, PoI_Xanamech, PoI_Behemoth, PoD_Grimror_Quest, PoD_Grummus, PoN_Hedge_Quest, PoNb_Terris_Thule, \n" .
						  "         PoS_Askr_Quest, PoV_Grenic_Quest, PoV_AerinDar, CoD_Carprin_Event, CoD_Bertoxxulous, PoTorment_Saryrn, PoS_Wembly_Quest, \n" .
						  "         HoH_Trial1_RyddaDar, HoH_Trial2_Ogre, HoH_Trial3_Madmen, HoHb_Mithanial_Marr, PoTactics_Tallon_Zek, PoTactics_Vallon_Zek, PoTactics_Rallos_Zek_Quest, BoT_Rescue_Karana_Quest, SolRoTower_Jiva, SolRoTower_Xuzl, SolRoTower_Arlyxir, SolRoTower_Rizlona, SolRoTower_Protector_of_Dresolik, SolRoTower_Solusek_Ro, \n" .
						  "         PoAir_Xegony, PoFire_Fennin_Ro, PoWater_Coirnav, PoEarthb_The_Rathe, PoTime_Time_Phased_Quintessence, \n" .
						  "         Purifying_Plant, Emanating_Furnace, Lair_of_Trapped_Ones, Pool_of_Sludge, Smith_Rondo, Vxed, Tipt, Vrex_Barxt_Qurat, Keeper_of_the_Altar, Noqufiel_in_Inktuta, Cynosure_Kvanjji, Ixt_Hsek_Syat, High_Priest_Nkosi_Bakari, ZunMuram_Tkarish_Zyk, \n" .
						  "         Mastery_of_Adaptation, Mastery_of_Corruption, Mastery_of_Endurance, Mastery_of_Foresight, Mastery_of_Hate, Mastery_of_Specialization, Seal_Mastery_of_All, Signet_Crystal_Gemmed, Signet_Discolored, Signet_Dust_Marred, Signet_Glimmering, Signet_Tarnished, Signet_Two_Toned, Signet_Weather_Worn, \n" .
						  "         T1_Create_an_Antidote, T1_Greed_of_the_Goblins, T1_Burning_Arrows, T1_Children_of_Gimblax, T2_Defend_the_Kirin_Contact, T2_Recover_the_Lost_Map, T2_Turn_the_Tides_of_the_Sand, T2_Sickness_of_the_Spirit, T2_Calling_Emoush, T3_Protect_the_Waters, T3_Snowfoots_Revenge, T3_The_Sacred_Scrolls, T3_History_of_the_Isle, T3_Trial_of_Perserverance, T3_Volkaras_Bite, T4_Goblin_Dojo, T4_Guardian_of_the_Sands, T4_An_End_to_the_Storms, T5_Origins_of_the_Curse, T5_The_Curse_of_JuRek, T5_In_the_Shadows, \n" .
						  "			A_Rogues_Trust, Scouting_the_City, Building_the_Disguise, The_Search_for_Illsuras, The_Rage_of_Kelliad, The_Lost_Notebook, Cavern_Botany, The_Search_for_Clues, Rescue_Cicero, Preemptive_Strike, Praetorian_Guard, The_Fall_of_Illsalin, Flights_of_the_Seeker, Into_the_Shadows \n" .
						  "FROM Characters \n" .
						  "LEFT JOIN TradeSkills		ON (Characters.CharID = TradeSkills.CharID) \n" .
						  "LEFT JOIN `Keys`				ON (Characters.CharID = `Keys`.CharID) \n" .
						  "LEFT JOIN PoS_Askr_Quest		ON (Characters.CharID = PoS_Askr_Quest.CharID) \n" .
						  "LEFT JOIN SSRA_Emperor_Key	ON (Characters.CharID = SSRA_Emperor_Key.CharID) \n" .
						  "LEFT JOIN Veeshans_Peak_Key	ON (Characters.CharID = Veeshans_Peak_Key.CharID) \n" .
						  "LEFT JOIN Vex_Thal_Key		ON (Characters.CharID = Vex_Thal_Key.CharID) \n" .
						  "LEFT JOIN PoP_Tier_1_Flags	ON (Characters.CharID = PoP_Tier_1_Flags.CharID) \n" .
						  "LEFT JOIN PoP_Tier_2_Flags	ON (Characters.CharID = PoP_Tier_2_Flags.CharID) \n" .
						  "LEFT JOIN PoP_Tier_3_Flags	ON (Characters.CharID = PoP_Tier_3_Flags.CharID) \n" .
						  "LEFT JOIN PoP_Tier_4_Flags	ON (Characters.CharID = PoP_Tier_4_Flags.CharID) \n" .
						  "LEFT JOIN GoD_Flags			ON (Characters.CharID = GoD_Flags.CharID) \n" .
						  "LEFT JOIN OoW_CoA			ON (Characters.CharID = OoW_CoA.CharID) \n" .
						  "LEFT JOIN DoN_Flags			ON (Characters.CharID = DoN_Flags.CharID) \n" .
						  "LEFT JOIN DoD_Spells			ON (Characters.CharID = DoD_Spells.CharID) \n" .
						  "WHERE CharName = '$strCharName' \n";

	// Connect to the database
	$nLinkID	= DBConnect();

	// Retrieve the record
	$nResult	= mysql_query( $strSelectQuery, $nLinkID );
	if( $nResult == FALSE )
	{
		print( "	<font color=\"#FF3300\"><a>Couldn't select data for char '$strCharName'! (" . mysql_error() . ")</a></font><br />\n" );
	}
	else
	{
		// Fetch the record
		$aResult	= mysql_fetch_row( $nResult );
	}

	// Close the connection
	DBDisconnect( $nLinkID );

    if( $aResult ) 
	{
		// Retrieve the variables out of the array
		$nIndex								= 0;
			// Characters
		$strCharID							= $aResult[$nIndex++];
		$strLastName						= $aResult[$nIndex++];
		$strNameMain						= $aResult[$nIndex++];
		$strClass							= $aResult[$nIndex++];
		$strRace							= $aResult[$nIndex++];
		$strGender							= $aResult[$nIndex++];
		$nLevel								= $aResult[$nIndex++];
		$nAA								= $aResult[$nIndex++];
		$nGLP								= $aResult[$nIndex++];
		$nMageloNr							= $aResult[$nIndex++];
		$strGuildStatus						= $aResult[$nIndex++];
			// Character Statistics
		$nHP								= $aResult[$nIndex++];
		$nMana								= $aResult[$nIndex++];
		$nAC								= $aResult[$nIndex++];
		$nFT								= $aResult[$nIndex++];
		$nRegen								= $aResult[$nIndex++];
		$nAtk								= $aResult[$nIndex++];
		$nStr								= $aResult[$nIndex++];
		$nSta								= $aResult[$nIndex++];
		$nAgi								= $aResult[$nIndex++];
		$nDex								= $aResult[$nIndex++];
		$nWis								= $aResult[$nIndex++];
		$nInt								= $aResult[$nIndex++];
		$nCha								= $aResult[$nIndex++];
		$nPR								= $aResult[$nIndex++];
		$nMR								= $aResult[$nIndex++];
		$nDR								= $aResult[$nIndex++];
		$nFR								= $aResult[$nIndex++];
		$nCR 								= $aResult[$nIndex++];
			// Trade Skills
		$nAlchemy							= $aResult[$nIndex++]; 
		$nBaking							= $aResult[$nIndex++]; 
		$nBrewing							= $aResult[$nIndex++]; 
		$nFishing							= $aResult[$nIndex++]; 
		$nFletching							= $aResult[$nIndex++]; 
		$nForaging							= $aResult[$nIndex++]; 
		$nJewelcraft						= $aResult[$nIndex++]; 
		$nPoison							= $aResult[$nIndex++]; 
		$nPottery							= $aResult[$nIndex++]; 
		$nResearch							= $aResult[$nIndex++]; 
		$nSmithing							= $aResult[$nIndex++]; 
		$nTailoring							= $aResult[$nIndex++]; 
		$nTinkering							= $aResult[$nIndex++]; 
			// Keys
		$nBoT_Tower_Key						= $aResult[$nIndex++]; 
		$nHowling_Stones_Key				= $aResult[$nIndex++]; 
		$nSebilis_Key						= $aResult[$nIndex++]; 
		$nSleepers_Tomb_Key					= $aResult[$nIndex++]; 
		$nSSRA_Emperor_Key					= $aResult[$nIndex++]; 
		$nVeeshans_Peak_Key					= $aResult[$nIndex++]; 
		$nVex_Thal_Key						= $aResult[$nIndex++]; 
			// BoT flag
		$nHead								= $aResult[$nIndex++]; 
		$nBeard								= $aResult[$nIndex++]; 
		$nBone								= $aResult[$nIndex++]; 
		$nSash								= $aResult[$nIndex++]; 
		$nOceanMedal						= $aResult[$nIndex++]; 
		$nDesertMedal						= $aResult[$nIndex++]; 
		$nForestMedal						= $aResult[$nIndex++]; 
			// SSRA Emperor key
		$nTaskmasters_Pouch					= $aResult[$nIndex++]; 
		$nZazuzhs_Idol						= $aResult[$nIndex++]; 
		$nRing								= $aResult[$nIndex++]; 
		$nInsignia							= $aResult[$nIndex++]; 
			// Veeshan's Peek key
		$nKylongMedal_Top					= $aResult[$nIndex++]; 
		$nKylongMedal_Middle				= $aResult[$nIndex++]; 
		$nKylongMedal_Bottom				= $aResult[$nIndex++]; 
		$nJarsathMedal_Top					= $aResult[$nIndex++]; 
		$nJarsathMedal_Middle				= $aResult[$nIndex++]; 
		$nJarsathMedal_Bottom				= $aResult[$nIndex++]; 
		$nObulusMedal_Top					= $aResult[$nIndex++]; 
		$nObulusMedal_Middle				= $aResult[$nIndex++]; 
		$nObulusMedal_Bottom				= $aResult[$nIndex++]; 
		$nTrak_Tooth						= $aResult[$nIndex++]; 
			// Vex Thal key
		$nGlowing_Orb						= $aResult[$nIndex++]; 
		$nCelestial_Rift					= $aResult[$nIndex++]; 
		$nShard_Dat							= $aResult[$nIndex++]; 
		$nShard_Dax							= $aResult[$nIndex++]; 
		$nShard_Kel							= $aResult[$nIndex++]; 
		$nShard_Kelara						= $aResult[$nIndex++]; 
		$nShard_Lor							= $aResult[$nIndex++]; 
		$nShard_Raf							= $aResult[$nIndex++]; 
		$nShard_Set							= $aResult[$nIndex++]; 
		$nShard_Tak							= $aResult[$nIndex++]; 
		$nShard_Ved							= $aResult[$nIndex++]; 
		$nShard_Vin							= $aResult[$nIndex++]; 
			// Pop Tier 1 Flags
		$nAny_PoJ_Trial						= $aResult[$nIndex++];
		$nAll_PoJ_Trials					= $aResult[$nIndex++];
		$nPoI_Xanamech						= $aResult[$nIndex++];
		$nPoI_Behemoth						= $aResult[$nIndex++];
		$nPoD_Grimror_Quest					= $aResult[$nIndex++];
		$nPoD_Grummus						= $aResult[$nIndex++];
		$nPoN_Hedge_Quest					= $aResult[$nIndex++];
		$nPoNb_Terris_Thule					= $aResult[$nIndex++];
			// Pop Tier 2 Flags
		$nPoS_Askr_Quest					= $aResult[$nIndex++];
		$nPoV_Grenic_Quest					= $aResult[$nIndex++];
		$nPoV_AerinDar						= $aResult[$nIndex++];
		$nCoD_Carprin_Event					= $aResult[$nIndex++];
		$nCoD_Bertoxxulous					= $aResult[$nIndex++];
		$nPoTorment_Saryrn					= $aResult[$nIndex++];
		$nPoS_Wembly_Quest					= $aResult[$nIndex++];
			// Pop Tier 3 Flags
		$nHoH_Trial1_RyddaDar				= $aResult[$nIndex++];
		$nHoH_Trial2_Ogre					= $aResult[$nIndex++];
		$nHoH_Trial3_Madmen					= $aResult[$nIndex++];
		$nHoHb_Mithanial_Marr				= $aResult[$nIndex++];
		$nPoTactics_Tallon_Zek				= $aResult[$nIndex++];
		$nPoTactics_Vallon_Zek				= $aResult[$nIndex++];
		$nPoTactics_Rallos_Zek_Quest		= $aResult[$nIndex++];
		$nBoT_Rescue_Karana_Quest			= $aResult[$nIndex++];
		$nSolRoTower_Jiva					= $aResult[$nIndex++];
		$nSolRoTower_Xuzl					= $aResult[$nIndex++];
		$nSolRoTower_Arlyxir				= $aResult[$nIndex++];
		$nSolRoTower_Rizlona				= $aResult[$nIndex++];
		$nSolRoTower_Protector_of_Dresolik	= $aResult[$nIndex++];
		$nSolRoTower_Solusek_Ro				= $aResult[$nIndex++];
			// Pop Tier 4 Flags
		$nPoAir_Xegony						= $aResult[$nIndex++];
		$nPoFire_Fennin_Ro					= $aResult[$nIndex++];
		$nPoWater_Coirnav					= $aResult[$nIndex++];
		$nPoEarthb_The_Rathe				= $aResult[$nIndex++];
		$nPoTime_Time_Phased_Quintessence	= $aResult[$nIndex++];
			// GoD Flags
		$nPurifying_Plant					= $aResult[$nIndex++];
		$nEmanating_Furnace					= $aResult[$nIndex++];
		$nLair_of_Trapped_Ones				= $aResult[$nIndex++];
		$nPool_of_Sludge					= $aResult[$nIndex++];
		$nSmith_Rondo						= $aResult[$nIndex++];
		$nVxed								= $aResult[$nIndex++];
		$nTipt								= $aResult[$nIndex++];
		$nVrex_Barxt_Qurat					= $aResult[$nIndex++];
		$nKeeper_of_the_Altar				= $aResult[$nIndex++];
		$nNoqufiel_in_Inktuta				= $aResult[$nIndex++];
		$nCynosure_Kvanjji					= $aResult[$nIndex++];
		$nIxt_Hsek_Syat						= $aResult[$nIndex++];
		$nHigh_Priest_Nkosi_Bakari			= $aResult[$nIndex++];
		$nZunMuram_Tkarish_Zyk				= $aResult[$nIndex++];
		// OoW CoA
		$nMastery_of_Adaptation				= $aResult[$nIndex++];
		$nMastery_of_Corruption				= $aResult[$nIndex++];
		$nMastery_of_Endurance				= $aResult[$nIndex++];
		$nMastery_of_Foresight				= $aResult[$nIndex++];
		$nMastery_of_Hate					= $aResult[$nIndex++];
		$nMastery_of_Specialization			= $aResult[$nIndex++];
		$nSeal_Mastery_of_All				= $aResult[$nIndex++];
		$nSignet_Crystal_Gemmed				= $aResult[$nIndex++];
		$nSignet_Discolored					= $aResult[$nIndex++];
		$nSignet_Dust_Marred				= $aResult[$nIndex++];
		$nSignet_Glimmering					= $aResult[$nIndex++];
		$nSignet_Tarnished					= $aResult[$nIndex++];
		$nSignet_Two_Toned					= $aResult[$nIndex++];
		$nSignet_Weather_Worn				= $aResult[$nIndex++];
			// DoN Flags
		$nT1_Create_an_Antidote				= $aResult[$nIndex++];
		$nT1_Greed_of_the_Goblins			= $aResult[$nIndex++];
		$nT1_Burning_Arrows					= $aResult[$nIndex++];
		$nT1_Children_of_Gimblax			= $aResult[$nIndex++];
		$nT2_Defend_the_Kirin_Contact		= $aResult[$nIndex++];
		$nT2_Recover_the_Lost_Map			= $aResult[$nIndex++];
		$nT2_Turn_the_Tides_of_the_Sand		= $aResult[$nIndex++];
		$nT2_Sickness_of_the_Spirit			= $aResult[$nIndex++];
		$nT2_Calling_Emoush					= $aResult[$nIndex++];
		$nT3_Protect_the_Waters				= $aResult[$nIndex++];
		$nT3_Snowfoots_Revenge				= $aResult[$nIndex++];
		$nT3_The_Sacred_Scrolls				= $aResult[$nIndex++];
		$nT3_History_of_the_Isle			= $aResult[$nIndex++];
		$nT3_Trial_of_Perserverance			= $aResult[$nIndex++];
		$nT3_Volkaras_Bite					= $aResult[$nIndex++];
		$nT4_Goblin_Dojo					= $aResult[$nIndex++];
		$nT4_Guardian_of_the_Sands			= $aResult[$nIndex++];
		$nT4_An_End_to_the_Storms			= $aResult[$nIndex++];
		$nT5_Origins_of_the_Curse			= $aResult[$nIndex++];
		$nT5_The_Curse_of_JuRek				= $aResult[$nIndex++];
		$nT5_In_the_Shadows					= $aResult[$nIndex++];
		// DoD Spells
		$nA_Rogues_Trust					= $aResult[$nIndex++];
		$nScouting_the_City					= $aResult[$nIndex++];
		$nBuilding_the_Disguise				= $aResult[$nIndex++];
		$nThe_Search_for_Illsuras			= $aResult[$nIndex++];
		$nThe_Rage_of_Kelliad				= $aResult[$nIndex++];
		$nThe_Lost_Notebook					= $aResult[$nIndex++];
		$nCavern_Botany						= $aResult[$nIndex++];
		$nThe_Search_for_Clues				= $aResult[$nIndex++];
		$nRescue_Cicero						= $aResult[$nIndex++];
		$nPreemptive_Strike					= $aResult[$nIndex++];
		$nPraetorian_Guard					= $aResult[$nIndex++];
		$nThe_Fall_of_Illsalin				= $aResult[$nIndex++];
		$nFlights_of_the_Seeker				= $aResult[$nIndex++];
		$nInto_the_Shadows					= $aResult[$nIndex++];

		// Show the Modify Character page
		ShowModifyCharacterPage(	$strUserName, $strPassword, $strCharName, $strPreviousForm, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter, 
									// Character info
									$strCharName, $strLastName, $strNameMain, $strGuildStatus, $strClass, $nLevel, $nAA, $nGLP, $strRace, $strGender, $nMageloNr, 
									// Character Statistics
									$nHP, $nMana, $nAC, $nFT, $nRegen, $nAtk, $nStr, $nSta, $nAgi, $nDex, $nWis, $nInt, $nCha, $nPR, $nMR, $nDR, $nFR, $nCR, 
									// Trade Skills
									$nAlchemy, $nBaking, $nBrewing, $nFishing, $nFletching, $nForaging, $nJewelcraft, $nPoison, $nPottery, $nResearch, $nSmithing, $nTailoring, $nTinkering, 
									// Keys and Flags
									$nBoT_Tower_Key, $nHowling_Stones_Key, $nSebilis_Key, $nSleepers_Tomb_Key, $nSSRA_Emperor_Key, $nVeeshans_Peak_Key, $nVex_Thal_Key, 
									// BoT flag
									$nHead, $nBeard, $nBone, $nSash, $nOceanMedal, $nDesertMedal, $nForestMedal, 
									// SSRA Emperor key
									$nTaskmasters_Pouch, $nZazuzhs_Idol, $nRing, $nInsignia, 
									// Veeshan's Peek key
									$nKylongMedal_Top, $nKylongMedal_Middle, $nKylongMedal_Bottom, $nJarsathMedal_Top, $nJarsathMedal_Middle, $nJarsathMedal_Bottom, $nObulusMedal_Top, $nObulusMedal_Middle, $nObulusMedal_Bottom, $nTrak_Tooth, 
									// Vex Thal key
									$nGlowing_Orb, $nCelestial_Rift, $nShard_Dat, $nShard_Dax, $nShard_Kel, $nShard_Kelara, $nShard_Lor, $nShard_Raf, $nShard_Set, $nShard_Tak, $nShard_Ved, $nShard_Vin, 
									// Pop Tier 1 Flags
									$nAny_PoJ_Trial, $nAll_PoJ_Trials, $nPoI_Xanamech, $nPoI_Behemoth, $nPoD_Grimror_Quest, $nPoD_Grummus, $nPoN_Hedge_Quest, $nPoNb_Terris_Thule, 
									// Pop Tier 2 Flags
									$nPoS_Askr_Quest, $nPoV_Grenic_Quest, $nPoV_AerinDar, $nCoD_Carprin_Event, $nCoD_Bertoxxulous, $nPoTorment_Saryrn, $nPoS_Wembly_Quest, 
									// Pop Tier 3 Flags
									$nHoH_Trial1_RyddaDar, $nHoH_Trial2_Ogre, $nHoH_Trial3_Madmen, $nHoHb_Mithanial_Marr, $nPoTactics_Tallon_Zek, $nPoTactics_Vallon_Zek, $nPoTactics_Rallos_Zek_Quest, $nBoT_Rescue_Karana_Quest, $nSolRoTower_Jiva, $nSolRoTower_Xuzl, $nSolRoTower_Arlyxir, $nSolRoTower_Rizlona, $nSolRoTower_Protector_of_Dresolik, $nSolRoTower_Solusek_Ro, 
									// Pop Tier 4 Flags
									$nPoAir_Xegony, $nPoFire_Fennin_Ro, $nPoWater_Coirnav, $nPoEarthb_The_Rathe, $nPoTime_Time_Phased_Quintessence, 
									// GoD Flags
									$nPurifying_Plant, $nEmanating_Furnace, $nLair_of_Trapped_Ones, $nPool_of_Sludge, $nSmith_Rondo, $nVxed, $nTipt, $nVrex_Barxt_Qurat, $nKeeper_of_the_Altar, $nNoqufiel_in_Inktuta, $nCynosure_Kvanjji, $nIxt_Hsek_Syat, $nHigh_Priest_Nkosi_Bakari, $nZunMuram_Tkarish_Zyk,
									// OoW CoA
									$nMastery_of_Adaptation, $nMastery_of_Corruption, $nMastery_of_Endurance, $nMastery_of_Foresight, $nMastery_of_Hate, $nMastery_of_Specialization, $nSeal_Mastery_of_All, $nSignet_Crystal_Gemmed, $nSignet_Discolored, $nSignet_Dust_Marred, $nSignet_Glimmering, $nSignet_Tarnished, $nSignet_Two_Toned, $nSignet_Weather_Worn,
									// DoN Flags
									$nT1_Create_an_Antidote, $nT1_Greed_of_the_Goblins, $nT1_Burning_Arrows, $nT1_Children_of_Gimblax, $nT2_Defend_the_Kirin_Contact, $nT2_Recover_the_Lost_Map, $nT2_Turn_the_Tides_of_the_Sand, $nT2_Sickness_of_the_Spirit, $nT2_Calling_Emoush, $nT3_Protect_the_Waters, $nT3_Snowfoots_Revenge, $nT3_The_Sacred_Scrolls, $nT3_History_of_the_Isle, $nT3_Trial_of_Perserverance, $nT3_Volkaras_Bite, $nT4_Goblin_Dojo, $nT4_Guardian_of_the_Sands, $nT4_An_End_to_the_Storms, $nT5_Origins_of_the_Curse, $nT5_The_Curse_of_JuRek, $nT5_In_the_Shadows, 
									// DoD Spells
									$strNameMain, $nA_Rogues_Trust, $nScouting_the_City, $nBuilding_the_Disguise, $nThe_Search_for_Illsuras, $nThe_Rage_of_Kelliad, $nThe_Lost_Notebook, $nCavern_Botany, $nThe_Search_for_Clues, $nRescue_Cicero, $nPreemptive_Strike, $nPraetorian_Guard, $nThe_Fall_of_Illsalin, $nFlights_of_the_Seeker, $nInto_the_Shadows,
									// Validation tag
									0, 0, $bShowStatistics, $bShowTradeskills, $bShowKeysProgression, $bShowPoPProgression, $bShowGoDProgression, $bShowOoW_CoAProgression, $bShowDoNProgression, $bDoNProgressionGood, $bShowDoDProgression );
	}
	else if( IsAdministrator( $strUserName ) )
	{
		// Show error message
		print( "    <hr />$strSelectQuery\n" );
	}
}



// Show the Modify Character page
function ShowModifyCharacterPage(	$strUserName, $strPassword, $strCharName, $strPreviousForm, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter, 
									// Character info
									$strCharName, $strLastName, $strNameMain, $strGuildStatus, $strClass, $nLevel, $nAA, $nGLP, $strRace, $strGender, $nMageloNr, 
									// Character Statistics
									$nHP, $nMana, $nAC, $nFT, $nRegen, $nAtk, $nStr, $nSta, $nAgi, $nDex, $nWis, $nInt, $nCha, $nPR, $nMR, $nDR, $nFR, $nCR, 
									// Trade Skills
									$nAlchemy, $nBaking, $nBrewing, $nFishing, $nFletching, $nForaging, $nJewelcraft, $nPoison, $nPottery, $nResearch, $nSmithing, $nTailoring, $nTinkering, 
									// Keys and Flags
									$nBoT_Tower_Key, $nHowling_Stones_Key, $nSebilis_Key, $nSleepers_Tomb_Key, $nSSRA_Emperor_Key, $nVeeshans_Peak_Key, $nVex_Thal_Key, 
									// BoT flag
									$nHead, $nBeard, $nBone, $nSash, $nOceanMedal, $nDesertMedal, $nForestMedal, 
									// SSRA Emperor key
									$nTaskmasters_Pouch, $nZazuzhs_Idol, $nRing, $nInsignia, 
									// Veeshan's Peek key
									$nKylongMedal_Top, $nKylongMedal_Middle, $nKylongMedal_Bottom, $nJarsathMedal_Top, $nJarsathMedal_Middle, $nJarsathMedal_Bottom, $nObulusMedal_Top, $nObulusMedal_Middle, $nObulusMedal_Bottom, $nTrak_Tooth, 
									// Vex Thal key
									$nGlowing_Orb, $nCelestial_Rift, $nShard_Dat, $nShard_Dax, $nShard_Kel, $nShard_Kelara, $nShard_Lor, $nShard_Raf, $nShard_Set, $nShard_Tak, $nShard_Ved, $nShard_Vin, 
									// Pop Tier 1 Flags
									$nAny_PoJ_Trial, $nAll_PoJ_Trials, $nPoI_Xanamech, $nPoI_Behemoth, $nPoD_Grimror_Quest, $nPoD_Grummus, $nPoN_Hedge_Quest, $nPoNb_Terris_Thule, 
									// Pop Tier 2 Flags
									$nPoS_Askr_Quest, $nPoV_Grenic_Quest, $nPoV_AerinDar, $nCoD_Carprin_Event, $nCoD_Bertoxxulous, $nPoTorment_Saryrn, $nPoS_Wembly_Quest, 
									// Pop Tier 3 Flags
									$nHoH_Trial1_RyddaDar, $nHoH_Trial2_Ogre, $nHoH_Trial3_Madmen, $nHoHb_Mithanial_Marr, $nPoTactics_Tallon_Zek, $nPoTactics_Vallon_Zek, $nPoTactics_Rallos_Zek_Quest, $nBoT_Rescue_Karana_Quest, $nSolRoTower_Jiva, $nSolRoTower_Xuzl, $nSolRoTower_Arlyxir, $nSolRoTower_Rizlona, $nSolRoTower_Protector_of_Dresolik, $nSolRoTower_Solusek_Ro, 
									// Pop Tier 4 Flags
									$nPoAir_Xegony, $nPoFire_Fennin_Ro, $nPoWater_Coirnav, $nPoEarthb_The_Rathe, $nPoTime_Time_Phased_Quintessence, 
									// GoD Flags
									$nPurifying_Plant, $nEmanating_Furnace, $nLair_of_Trapped_Ones, $nPool_of_Sludge, $nSmith_Rondo, $nVxed, $nTipt, $nVrex_Barxt_Qurat, $nKeeper_of_the_Altar, $nNoqufiel_in_Inktuta, $nCynosure_Kvanjji, $nIxt_Hsek_Syat, $nHigh_Priest_Nkosi_Bakari, $nZunMuram_Tkarish_Zyk,
									// OoW CoA
									$nMastery_of_Adaptation, $nMastery_of_Corruption, $nMastery_of_Endurance, $nMastery_of_Foresight, $nMastery_of_Hate, $nMastery_of_Specialization, $nSeal_Mastery_of_All, $nSignet_Crystal_Gemmed, $nSignet_Discolored, $nSignet_Dust_Marred, $nSignet_Glimmering, $nSignet_Tarnished, $nSignet_Two_Toned, $nSignet_Weather_Worn,
									// DoN Flags
									$nT1_Create_an_Antidote, $nT1_Greed_of_the_Goblins, $nT1_Burning_Arrows, $nT1_Children_of_Gimblax, $nT2_Defend_the_Kirin_Contact, $nT2_Recover_the_Lost_Map, $nT2_Turn_the_Tides_of_the_Sand, $nT2_Sickness_of_the_Spirit, $nT2_Calling_Emoush, $nT3_Protect_the_Waters, $nT3_Snowfoots_Revenge, $nT3_The_Sacred_Scrolls, $nT3_History_of_the_Isle, $nT3_Trial_of_Perserverance, $nT3_Volkaras_Bite, $nT4_Goblin_Dojo, $nT4_Guardian_of_the_Sands, $nT4_An_End_to_the_Storms, $nT5_Origins_of_the_Curse, $nT5_The_Curse_of_JuRek, $nT5_In_the_Shadows, 
									// DoD Spells
									$strNameMain, $nA_Rogues_Trust, $nScouting_the_City, $nBuilding_the_Disguise, $nThe_Search_for_Illsuras, $nThe_Rage_of_Kelliad, $nThe_Lost_Notebook, $nCavern_Botany, $nThe_Search_for_Clues, $nRescue_Cicero, $nPreemptive_Strike, $nPraetorian_Guard, $nThe_Fall_of_Illsalin, $nFlights_of_the_Seeker, $nInto_the_Shadows,
									// Validation tag
									$bValidated, $bImportMagelo, $bShowStatistics, $bShowTradeskills, $bShowKeysProgression, $bShowPoPProgression, $bShowGoDProgression, $bShowOoW_CoAProgression, $bShowDoNProgression, $bDoNProgressionGood, $bShowDoDProgression )
{
	// Declare variables
	$strImportMagelo	= "";
	$strFooterMessage	= "";

	// Check if we should import the data from magelo
	if( $bImportMagelo )
	{
		// Create the magelo object
		$theMagelo	= new Magelo( $nMageloNr, $strCharName, $strClass );
		// Import the magelo
		if( $theMagelo->Import() )
		{
			// Set the footer message
			$strFooterMessage					= "<br />Magelo imported...";

			// Retrieve character info
			if( $strLastName == "" )
			{
				$strLastName					= $theMagelo->strLastName;
			}
			if( $theMagelo->nLevel > $nLevel )
			{
				$nLevel							= $theMagelo->nLevel;
			}
			if( $theMagelo->nAA > $nAA )
			{
				$nAA							= $theMagelo->nAA;
			}
			if( $theMagelo->nNrOfGLPs > $nGLP )
			{
				$nGLP							= $theMagelo->nNrOfGLPs;
			}
			$strRace							= $theMagelo->strRace;
			// Magelo returns "Half Elf" as "Half-Elf", so we convert it back.
			if( $strRace == "Half-Elf" )
			{
				$strRace	= "Half Elf";
			}
//			$strGender							= $theMagelo->strGender;
			// Keys
			if( $theMagelo->nVexThalKey == 1 )
			{
				$nVex_Thal_Key					= $theMagelo->nVexThalKey;
				// Set all key flags to true as well
				$nGlowing_Orb					= 1;
				$nCelestial_Rift				= 1;
				$nShard_Dat						= 1;
				$nShard_Dax						= 1;
				$nShard_Kel						= 1;
				$nShard_Kelara					= 1;
				$nShard_Lor						= 1;
				$nShard_Raf						= 1;
				$nShard_Set						= 1;
				$nShard_Tak						= 1;
				$nShard_Ved						= 1;
				$nShard_Vin						= 1;
			}
			$nSebilis_Key						= $theMagelo->nSebilisKey;
			if( $theMagelo->nVeeshansPeakKey == 1 )
			{
				$nVeeshans_Peak_Key				= $theMagelo->nVeeshansPeakKey;
				// Set all key flags to true as well
				$nKylongMedal_Top				= 1;
				$nKylongMedal_Middle			= 1;
				$nKylongMedal_Bottom			= 1;
				$nJarsathMedal_Top				= 1;
				$nJarsathMedal_Middle			= 1;
				$nJarsathMedal_Bottom			= 1;
				$nObulusMedal_Top				= 1;
				$nObulusMedal_Middle			= 1;
				$nObulusMedal_Bottom			= 1;
				$nTrak_Tooth					= 1;
			}
			$nHowling_Stones_Key				= $theMagelo->nHowlingStonesKey;
			$nSleepers_Tomb_Key					= $theMagelo->nSleepersTombKey;
			if( $theMagelo->nSSRAEmperorKey == 1 )
			{
				$nSSRA_Emperor_Key				= $theMagelo->nSSRAEmperorKey;
				// Set all key flags to true as well
				$nTaskmasters_Pouch				= 1;
				$nZazuzhs_Idol					= 1;
				$nRing							= 1;
				$nInsignia						= 1;
			}
			if( $theMagelo->nPoS_Askr_Quest == 1 )
			{
				$nHead							= 1;
				$nBeard							= 1;
				$nBone							= 1;
				$nSash							= 1;
			}
			// Retrieve the statistics
			$nHP								= $theMagelo->nHP;
			$nMana								= $theMagelo->nMana;
			$nAC								= $theMagelo->nAC;
			$nFT								= $theMagelo->nFT;
			$nRegen								= $theMagelo->nRegen;
			$nAtk								= $theMagelo->nAtk;
			$nStr								= $theMagelo->nStr;
			$nSta								= $theMagelo->nSta;
			$nAgi								= $theMagelo->nAgi;
			$nDex								= $theMagelo->nDex;
			$nWis								= $theMagelo->nWis;
			$nInt								= $theMagelo->nInt;
			$nCha								= $theMagelo->nCha;
			$nPR								= $theMagelo->nPR;
			$nMR								= $theMagelo->nMR;
			$nDR								= $theMagelo->nDR;
			$nFR								= $theMagelo->nFR;
			$nCR								= $theMagelo->nCR;
			// Retrieve the tradeskills
			$nAlchemy							= $theMagelo->nAlchemy;
			$nBaking							= $theMagelo->nBaking;
			$nBrewing							= $theMagelo->nBrewing;
			$nFishing							= $theMagelo->nFishing;
			$nFletching							= $theMagelo->nFletching;
			$nForaging							= $theMagelo->nForaging;
			$nJewelcraft						= $theMagelo->nJewelry;
			$nPoison							= $theMagelo->nPosionMaking;
			$nPottery							= $theMagelo->nPottery;
			$nResearch							= $theMagelo->nResearch;
			$nSmithing							= $theMagelo->nSmithing;
			$nTailoring							= $theMagelo->nTailoring;
			$nTinkering							= $theMagelo->nTinkering;
			// Pop Tier 1 Flags
			$nAny_PoJ_Trial						= $theMagelo->nAny_PoJ_Trial;
			$nAll_PoJ_Trials					= $theMagelo->nAll_PoJ_Trials;
			$nPoI_Xanamech						= $theMagelo->nPoI_Xanamech;
			$nPoI_Behemoth						= $theMagelo->nPoI_Behemoth;
			$nPoD_Grimror_Quest					= $theMagelo->nPoD_Grimror_Quest;
			$nPoD_Grummus						= $theMagelo->nPoD_Grummus;
			$nPoN_Hedge_Quest					= $theMagelo->nPoN_Hedge_Quest;
			$nPoNb_Terris_Thule					= $theMagelo->nPoNb_Terris_Thule;
			// Pop Tier 2 Flags
			$nPoS_Askr_Quest					= $theMagelo->nPoS_Askr_Quest;
			$nPoV_Grenic_Quest					= $theMagelo->nPoV_Grenic_Quest;
			$nPoV_AerinDar						= $theMagelo->nPoV_AerinDar;
			$nCoD_Bertoxxulous					= $theMagelo->nCoD_Bertoxxulous;
			$nPoTorment_Saryrn					= $theMagelo->nPoTorment_Saryrn;
			$nPoS_Wembly_Quest					= $theMagelo->nPoS_Wembly_Quest;
			// Pop Tier 3 Flags
			$nHoH_Trial1_RyddaDar				= $theMagelo->nHoH_Trial1_RyddaDar;
			$nHoH_Trial2_Ogre					= $theMagelo->nHoH_Trial2_Ogre;
			$nHoH_Trial3_Madmen					= $theMagelo->nHoH_Trial3_Madmen;
			$nHoHb_Mithanial_Marr				= $theMagelo->nHoHb_Mithanial_Marr;
			$nPoTactics_Tallon_Zek				= $theMagelo->nPoTactics_Tallon_Zek;
			$nPoTactics_Vallon_Zek				= $theMagelo->nPoTactics_Vallon_Zek;
			$nPoTactics_Rallos_Zek_Quest		= $theMagelo->nPoTactics_Rallos_Zek_Quest;
			$nBoT_Rescue_Karana_Quest			= $theMagelo->nBoT_Rescue_Karana_Quest;
			$nSolRoTower_Jiva					= $theMagelo->nSolRoTower_Jiva;
			$nSolRoTower_Xuzl					= $theMagelo->nSolRoTower_Xuzl;
			$nSolRoTower_Arlyxir				= $theMagelo->nSolRoTower_Arlyxir;
			$nSolRoTower_Rizlona				= $theMagelo->nSolRoTower_Rizlona;
			$nSolRoTower_Protector_of_Dresolik	= $theMagelo->nSolRoTower_Protector_of_Dresolik;
			$nSolRoTower_Solusek_Ro				= $theMagelo->nSolRoTower_Solusek_Ro;
			// Pop Tier 4 Flags
			$nPoAir_Xegony						= $theMagelo->nPoAir_Xegony;
			$nPoFire_Fennin_Ro					= $theMagelo->nPoFire_Fennin_Ro;
			$nPoWater_Coirnav					= $theMagelo->nPoWater_Coirnav;
			$nPoEarthb_The_Rathe				= $theMagelo->nPoEarthb_The_Rathe;
			if( $theMagelo->nPoTime_Time_Phased_Quintessence == 1 )
			{
				$nPoTime_Time_Phased_Quintessence	= 1;
			}
			// GoD Flags
			$nPurifying_Plant					= $theMagelo->nPurifying_Plant;
			$nEmanating_Furnace					= $theMagelo->nEmanating_Furnace;
			$nLair_of_Trapped_Ones				= $theMagelo->nLair_of_Trapped_Ones;
			$nPool_of_Sludge					= $theMagelo->nPool_of_Sludge;
			$nSmith_Rondo						= $theMagelo->nSmith_Rondo;
			$nVxed								= $theMagelo->nVxed;
			$nTipt								= $theMagelo->nTipt;
			$nVrex_Barxt_Qurat					= $theMagelo->nVrex_Barxt_Qurat;
			$nCynosure_Kvanjji					= $theMagelo->nCynosure_Kvanjji;
			$nNoqufiel_in_Inktuta				= $theMagelo->nNoqufiel_in_Inktuta;
			$nZunMuram_Tkarish_Zyk				= $theMagelo->nZunMuram_Tkarish_Zyk;
			// DoN Flags
			if( $theMagelo->nDoN_Tier1_Done == 1 )
			{
				$nT1_Create_an_Antidote			= 1;
				$nT1_Greed_of_the_Goblins		= 1;
				$nT1_Burning_Arrows				= 1;
				$nT1_Children_of_Gimblax		= 1;
			}
			if( $theMagelo->nDoN_Tier2_Done == 1 )
			{
				$nT2_Defend_the_Kirin_Contact	= 1;
				$nT2_Recover_the_Lost_Map		= 1;
				$nT2_Turn_the_Tides_of_the_Sand	= 1;
				$nT2_Sickness_of_the_Spirit		= 1;
				$nT2_Calling_Emoush				= 1;
			}
			if( $theMagelo->nDoN_Tier3_Done == 1 )
			{
				$nT3_Protect_the_Waters			= 1;
				$nT3_Snowfoots_Revenge			= 1;
				$nT3_The_Sacred_Scrolls			= 1;
				$nT3_History_of_the_Isle		= 1;
				$nT3_Trial_of_Perserverance		= 1;
				$nT3_Volkaras_Bite				= 1;
			}
			if( $theMagelo->nDoN_Tier4_Done == 1 )
			{
				$nT4_Goblin_Dojo				= 1;
				$nT4_Guardian_of_the_Sands		= 1;
				$nT4_An_End_to_the_Storms		= 1;
			}
			if( $theMagelo->nDoN_Tier5_Done == 1 )
			{
				$nT5_Origins_of_the_Curse		= 1;
				$nT5_The_Curse_of_JuRek			= 1;
				$nT5_In_the_Shadows				= 1;
			}
		}
		else
		{
			echo '<br /><br /><center><font size="+1" color="#FF3300">' . $strClass . ' ' . $strCharName . '`s magelo (' . $nMageloNr . ') could not be imported!</font><br /><br /><br />Click back in your browser to return to the Character Modify page.</center>';
			return;
		}
	}
	else
	{
		// Check if magelo nr is filled in
		if( ( isset( $nMageloNr ) ) &&
			( $nMageloNr > 0 ) )
		{
			$strImportMagelo	= '<a href="character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&PreviousForm=' . $strPreviousForm . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&ClassFilter=' . $strClassFilter . '&Action=ImportMagelo" OnMouseOver="window.status=\'Import data from ' . $strCharName . '\\\'s magelo\';return true;"	OnMouseOut="window.status=\'\'"	target="Body" title="Import data from ' . $strCharName . '\'s magelo">' .
								  '					<img src="images/magelo.gif" border="0" />' .
								  '					<!-- Show/Hide the image on page load -->' .
								  '					<script language="JavaScript">' .
								  '						CheckMageloNr();' .
								  '					</script>' .
								  '</a>';
		}
	}

	// Admin can edit NameMain and GuildStatus
	if( IsAdministrator( $strUserName ) )
	{
		$strFieldNameMain		= 	'  <tr>
			<td width="10%"><font color="#FFFFFF">Name Main:</font></td>
			<td width="20%">' . CreateNameMainSelect( $strNameMain, "							" ) . '</td>
			<td width="10%"></td>
			<td width= "8%"></td>
			<td width= "4%"></td>
			<td width= "4%"></td>
			<td width= "4%"></td>
			<td width="10%"></td>
			<td width= "8%"></td>
			<td width="12%"></td>
		  </tr>';
		$strFieldGuildStatus	= CreateSelectFromEnum( "Characters", "GuildStatus", $strGuildStatus, "							" );
	}
	else
	{
		$strFieldNameMain		= '<input type="hidden"	name="cmbNameMain"	value="' . $strNameMain . '">';
		$strFieldGuildStatus	= $strGuildStatus . '<input type="hidden"	name="cmbGuildStatus"	value="' . $strGuildStatus . '">';
	}

	echo '
	<!-- JavaScript block has been added here instead of in the header on purpose -->
	<script language="JavaScript">
	<!-- Show/Hide an element on the Form -->
	function ShowElement( strElement, bShow )
	{
		// Try the standard method
		if( document.getElementById )
		{
			document.poppedLayer	= eval("document.getElementById(\'" + strElement + "\')");
		}
		// Try the old MSIE method
		else if( document.all )
		{
			document.poppedLayer	= eval("document.all[\'" + strElement + "\']");
		}
		// Try the Netscape method
		else if( document.layers )
		{
			document.poppedLayer	= eval("document.layers[\'`" + strElement + "\']");
		}
		
		if( bShow == true )
		{
			document.poppedLayer.style.visibility	= "visible";
		}
		else
		{
			document.poppedLayer.style.visibility	= "hidden";
		}
	}
	
	<!-- Show/Hide a layer on the form -->
	function ShowLayer( theLayer, bShow )
	{
		// Try the standard method
		if( document.getElementById )
		{
			var style2		= document.getElementById(theLayer).style;
		}
		// Try the old MSIE method
		else if( document.all )
		{
			var style2		= document.all[theLayer].style;
		}
		// Try the Netscape method
		else if( document.layers )
		{
			var style2		= document.layers[theLayer].style;
		}

		if( bShow == true )
		{
			style2.display	= "block";
		}
		else
		{
			style2.display	= "";
		}
	}

	<!-- Check if Statistics should be shown -->
	function DisplayStatistics()
	{
		if( document.formModifyCharacter.cbDisplayStatistics.checked == true )
		{
			document.formModifyCharacter.cbDisplayStatistics.value	= true;
			ShowLayer( "Statistics", true );
		}
		else
		{
			document.formModifyCharacter.cbDisplayStatistics.value	= false;
			ShowLayer( "Statistics", false );
		}
	};

	<!-- Check if Tradeskills should be shown -->
	function DisplayTradeskills()
	{
		if( document.formModifyCharacter.cbDisplayTradeskills.checked == true )
		{
			document.formModifyCharacter.cbDisplayTradeskills.value	= true;
			ShowLayer( "Tradeskills", true );
		}
		else
		{
			document.formModifyCharacter.cbDisplayTradeskills.value	= false;
			ShowLayer( "Tradeskills", false );
		}
	};

	<!-- Check if Keys progression should be shown -->
	function DisplayKeysProgression()
	{
		if( document.formModifyCharacter.cbDisplayKeysProgression.checked == true )
		{
			document.formModifyCharacter.cbDisplayKeysProgression.value	= true;
			ShowLayer( "Keys_Progression", true );
		}
		else
		{
			document.formModifyCharacter.cbDisplayKeysProgression.value	= false;
			ShowLayer( "Keys_Progression", false );
		}
	};

	<!-- Check if PoP progression should be shown -->
	function DisplayPoPProgression()
	{
		if( document.formModifyCharacter.cbDisplayPoPProgression.checked == true )
		{
			document.formModifyCharacter.cbDisplayPoPProgression.value	= true;
			ShowLayer( "PoP_Progression", true );
		}
		else
		{
			document.formModifyCharacter.cbDisplayPoPProgression.value	= false;
			ShowLayer( "PoP_Progression", false );
		}
	};

	<!-- Check if GoD progression should be shown -->
	function DisplayGoDProgression()
	{
		if( document.formModifyCharacter.cbDisplayGoDProgression.checked == true )
		{
			document.formModifyCharacter.cbDisplayGoDProgression.value	= true;
			ShowLayer( "GoD_Progression", true );
		}
		else
		{
			document.formModifyCharacter.cbDisplayGoDProgression.value	= false;
			ShowLayer( "GoD_Progression", false );
		}
	};

	<!-- Check if OoW CoA progression should be shown -->
	function DisplayOoW_CoAProgression()
	{
		if( document.formModifyCharacter.cbDisplayOoW_CoAProgression.checked == true )
		{
			document.formModifyCharacter.cbDisplayOoW_CoAProgression.value	= true;
			ShowLayer( "OoW_CoA_Progression", true );
		}
		else
		{
			document.formModifyCharacter.cbDisplayOoW_CoAProgression.value	= false;
			ShowLayer( "OoW_CoA_Progression", false );
		}
	};

	<!-- Check if DoN progression should be shown -->
	function DisplayDoNProgression()
	{
		if( document.formModifyCharacter.cbDisplayDoNProgression.checked == true )
		{
			document.formModifyCharacter.cbDisplayDoNProgression.value	= true;
			ShowLayer( "DoN_Progression", true );
			DisplayDoNProgressionType();
		}
		else
		{
			document.formModifyCharacter.cbDisplayDoNProgression.value	= false;
			ShowLayer( "DoN_Progression", false );
		}
	};

	<!-- Check which DoN Progression should be shown -->
	function DisplayDoNProgressionType()
	{
		if( document.formModifyCharacter.rbDoN_Progression_Good.checked == true )
		{
			ShowLayer( "DoN_Progression_Evil", false );
			ShowLayer( "DoN_Progression_Good", true );
		}
		else
		{
			ShowLayer( "DoN_Progression_Good", false );
			ShowLayer( "DoN_Progression_Evil", true );
			// If I don`t hide/show the whole layer, I get a space where the good table was... weird bug!
			ShowLayer( "DoN_Progression", false );
			ShowLayer( "DoN_Progression", true );
		}
	};

	<!-- Check if DoD progression should be shown -->
	function DisplayDoDProgression()
	{
		if( document.formModifyCharacter.cbDisplayDoDProgression.checked == true )
		{
			document.formModifyCharacter.cbDisplayDoDProgression.value	= true;
			ShowLayer( "DoD_Progression", true );
		}
		else
		{
			document.formModifyCharacter.cbDisplayDoDProgression.value	= false;
			ShowLayer( "DoD_Progression", false );
		}
	};

	<!-- Check the MageloNr to see if we should hide/show the image -->
	function CheckMageloNr()
	{
		if( (document.formModifyCharacter.editMageloNr.value * 1) > 0 )
		{
			ShowElement( "MageloLink", true );
		}
		else
		{
			ShowElement( "MageloLink", false );
		}
	};

	<!-- Check if all the fields on the form are valid -->
	function ValidateFields()
	{
		// We do not really do any validation, because there are no invalid fields possible
		// But we do set the Validation flag of the form, so that the PHP knows that it should
		// update all the records (instead of show this form)

		// Validation complete, all fields are valid
		document.formModifyCharacter.cbValidated.value		= true;
		document.formModifyCharacter.cbValidated.checked	= true;

		// Submit the form
		document.formModifyCharacter.submit();

		// Done
		return true;
	};

	<!-- Cancel the modify -->
	function CancelModify()
	{
		// Validation complete, all fields are valid
		document.formModifyCharacter.cbCancelModify.value	= true;
		document.formModifyCharacter.cbCancelModify.checked	= true;

		// Submit the form
		document.formModifyCharacter.submit();

		// Done
		return true;
	};

	<!-- Perform the Magelo Import -->
	function PerformMageloImport()
	{
		// Validation complete, all fields are valid
		document.formModifyCharacter.cbImportMagelo.value	= true;
		document.formModifyCharacter.cbImportMagelo.checked	= true;

		// Submit the form
		document.formModifyCharacter.submit();

		// Done
		return true;
	};
	</script>


	<!-- Start of Modify CHaracter -->
	<form name="formModifyCharacter" method="post" action="character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&PreviousForm=' . $strPreviousForm . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection . '&ShowAlts=' . $strShowAlts . '&ClassFilter=' . $strClassFilter . '">
		<div id="Body">
		<center>
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="#777777">
		  <tr>
			<td width="10%"><font color="#FFFFFF"><i>Name</i></font></td>
			<td width="20%"><font color="#FFFFFF"><i>Last Name</i></font></td>
			<td width="10%"><font color="#FFFFFF"><i>Title</i></font></td>
			<td width= "8%"><font color="#FFFFFF"><i>Class</i></font></td>
			<td width= "4%"><font color="#FFFFFF"><i>Level</i></font></td>
			<td width= "4%"><font color="#FFFFFF"><i>AA</i></font></td>
			<td width= "4%"><font color="#FFFFFF"><i>GLP</i></font></td>
			<td width="10%"><font color="#FFFFFF"><i>Race</i></font></td>
			<td width= "8%"><font color="#FFFFFF"><i>Gender</i></font></td>
			<td width="12%"><font color="#FFFFFF"><i>MageloNr</i></font></td>
		  </tr>
		</table>
		<table width="98%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td width="10%">' . $strCharName . '</td>
			<td width="20%"><input type="text"		name="editLastName"	size="20"	value="' . $strLastName . '"	maxlength="30"></td>
			<td width="10%">' . $strFieldGuildStatus . '</td>
			<td width= "8%"><input type="hidden"	name="editClass"				value="' . $strClass . '">'	. $strClass . '</td>
			<td width= "4%"><input type="hidden"	name="editLevel"				value="' . $nLevel . '">'	. $nLevel . '</td>
			<td width= "4%"><input type="number"	name="editAA"		size="2"	value="' . $nAA . '"			maxlength="4"></td>
			<td width= "4%"><input type="number"	name="editGLP"		size="2"	value="' . $nGLP . '"			maxlength="3"></td>
			<td width="10%">' . CreateSelectFromEnum( "Characters", "Race",   $strRace,   "							" ) . '</td>
			<td width= "8%">' . CreateSelectFromEnum( "Characters", "Gender", $strGender, "							" ) . '</td>
			<td width="12%"><input type="text"		name="editMageloNr"	size="10"	value="' . $nMageloNr . '"		maxlength="10"	onKeyUp="CheckMageloNr();"><img src="images/magelo.gif" border="0" id="MageloLink" OnMouseOver="window.status=\'Import data from ' . $strCharName . '\\\'s magelo\';return true;"	OnMouseOut="window.status=\'\'" onClick="PerformMageloImport();" title="Import data from ' . $strCharName . '\'s magelo"/></a>
				<!-- Show/Hide the image on page load -->
				<script language="JavaScript">
					CheckMageloNr();
				</script>
			</td>
		  </tr>
		' . $strFieldNameMain . '
		</table>
			
		<!-- Character Statistics -->
		<br />
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="#777777">
		  <tr>
			<td width= "8%"></td>
			<td width="84%" align="center"><font color="#FFFFFF"><i>Statistics</i></font></td>
			<td width= "8%" align="right"><font color="#FFFFFF"><i>Show</i></font><input type="checkbox" name="cbDisplayStatistics" id="cbDisplayStatistics" onClick="DisplayStatistics();" value="' . $bShowStatistics . '" ' . GetCheckboxValue( $bShowStatistics ) . ' title="Show/hide the Statistics"></td>
		  </tr>
		</table>

		<div id="Statistics">
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="#777777">
		  <tr>
			<td width= "4%"></td>
			<td width= "5%" align="center"><font color="#FFFFFF"><i>HP</i></font></td>
			<td width= "5%" align="center"><font color="#FFFFFF"><i>Mana</i></font></td>
			<td width= "5%" align="center"><font color="#FFFFFF"><i>AC</i></font></td>
			<td width= "5%" align="center"><font color="#FFFFFF"><i>FT</i></font></td>
			<td width= "5%" align="center"><font color="#FFFFFF"><i>Regen</i></font></td>
			<td width= "5%" align="center"><font color="#FFFFFF"><i>Atk</i></font></td>
			<td width= "5%" align="center"><font color="#FFFFFF"><i>Str</i></font></td>
			<td width= "5%" align="center"><font color="#FFFFFF"><i>Sta</i></font></td>
			<td width= "5%" align="center"><font color="#FFFFFF"><i>Agi</i></font></td>
			<td width= "5%" align="center"><font color="#FFFFFF"><i>Dex</i></font></td>
			<td width= "5%" align="center"><font color="#FFFFFF"><i>Wis</i></font></td>
			<td width= "5%" align="center"><font color="#FFFFFF"><i>Int</i></font></td>
			<td width= "5%" align="center"><font color="#FFFFFF"><i>Cha</i></font></td>
			<td width= "5%" align="center"><font color="#FFFFFF"><i>PR</i></font></td>
			<td width= "5%" align="center"><font color="#FFFFFF"><i>MR</i></font></td>
			<td width= "5%" align="center"><font color="#FFFFFF"><i>DR</i></font></td>
			<td width= "5%" align="center"><font color="#FFFFFF"><i>FR</i></font></td>
			<td width= "5%" align="center"><font color="#FFFFFF"><i>CR</i></font></td>
			<td width= "4%"></td>
		  </tr>
		</table>
		<table width="98%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td width= "4%"></td>
			<td width= "5%" align="center"><input type="number" name="editHP"		size="2" value="' . $nHP . '"		maxlength="5"></td>
			<td width= "5%" align="center"><input type="number" name="editMana"		size="2" value="' . $nMana . '"		maxlength="5"></td>
			<td width= "5%" align="center"><input type="number" name="editAC"		size="2" value="' . $nAC . '"		maxlength="4"></td>
			<td width= "5%" align="center"><input type="number" name="editFT"		size="2" value="' . $nFT . '"		maxlength="2"></td>
			<td width= "5%" align="center"><input type="number" name="editRegen"	size="2" value="' . $nRegen . '"	maxlength="2"></td>
			<td width= "5%" align="center"><input type="number" name="editAtk"		size="2" value="' . $nAtk . '"		maxlength="4"></td>
			<td width= "5%" align="center"><input type="number" name="editStr"		size="2" value="' . $nStr . '"		maxlength="3"></td>
			<td width= "5%" align="center"><input type="number" name="editSta"		size="2" value="' . $nSta . '"		maxlength="3"></td>
			<td width= "5%" align="center"><input type="number" name="editAgi"		size="2" value="' . $nAgi . '"		maxlength="3"></td>
			<td width= "5%" align="center"><input type="number" name="editDex"		size="2" value="' . $nDex . '"		maxlength="3"></td>
			<td width= "5%" align="center"><input type="number" name="editWis"		size="2" value="' . $nWis . '"		maxlength="3"></td>
			<td width= "5%" align="center"><input type="number" name="editInt"		size="2" value="' . $nInt . '"		maxlength="3"></td>
			<td width= "5%" align="center"><input type="number" name="editCha"		size="2" value="' . $nCha . '"		maxlength="3"></td>
			<td width= "5%" align="center"><input type="number" name="editPR"		size="2" value="' . $nPR . '"		maxlength="3"></td>
			<td width= "5%" align="center"><input type="number" name="editMR"		size="2" value="' . $nMR . '"		maxlength="3"></td>
			<td width= "5%" align="center"><input type="number" name="editDR"		size="2" value="' . $nDR . '"		maxlength="3"></td>
			<td width= "5%" align="center"><input type="number" name="editFR"		size="2" value="' . $nFR . '"		maxlength="3"></td>
			<td width= "5%" align="center"><input type="number" name="editCR"		size="2" value="' . $nCR . '"		maxlength="3"></td>
			<td width= "4%"></td>
		  </tr>
		</table>
		</div>


		<!-- Tradeskills -->
		<br />
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="#777777">
		  <tr>
			<td width= "8%"></td>
			<td width="84%" align="center"><font color="#FFFFFF"><i>Tradeskills</i></font></td>
			<td width= "8%" align="right"><font color="#FFFFFF"><i>Show</i></font><input type="checkbox" name="cbDisplayTradeskills" id="cbDisplayTradeskills" onClick="DisplayTradeskills();" value="' . $bShowTradeskills . '" ' . GetCheckboxValue( $bShowTradeskills ) . ' title="Show/hide the Tradeskills"></td>
		  </tr>
		</table>

		<div id="Tradeskills">
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="#777777">
		  <tr>
			<td width= "1%"></td>
			<td width= "7%" align="center"><font color="#FFFFFF"><i>Alchemy</i></font></td>
			<td width= "7%" align="center"><font color="#FFFFFF"><i>Baking</i></font></td>
			<td width= "7%" align="center"><font color="#FFFFFF"><i>Brewing</i></font></td>
			<td width= "7%" align="center"><font color="#FFFFFF"><i>Fishing</i></font></td>
			<td width= "7%" align="center"><font color="#FFFFFF"><i>Fletching</i></font></td>
			<td width= "7%" align="center"><font color="#FFFFFF"><i>Foraging</i></font></td>
			<td width= "7%" align="center"><font color="#FFFFFF"><i>Jewelcraft</i></font></td>
			<td width= "7%" align="center"><font color="#FFFFFF"><i>Poison</i></font></td>
			<td width= "7%" align="center"><font color="#FFFFFF"><i>Pottery</i></font></td>
			<td width= "7%" align="center"><font color="#FFFFFF"><i>Research</i></font></td>
			<td width= "7%" align="center"><font color="#FFFFFF"><i>Smithing</i></font></td>
			<td width= "7%" align="center"><font color="#FFFFFF"><i>Tailoring</i></font></td>
			<td width= "7%" align="center"><font color="#FFFFFF"><i>Tinkering</i></font></td>
			<td width= "1%"></td>
		  </tr>
		</table>
		<table width="98%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td width= "1%"></td>
			<td width= "7%" align="center"><input type="number" name="editAlchemy"		size="2" value="' . $nAlchemy . '"		maxlength="3"></td>
			<td width= "7%" align="center"><input type="number" name="editBaking"		size="2" value="' . $nBaking . '"		maxlength="3"></td>
			<td width= "7%" align="center"><input type="number" name="editBrewing"		size="2" value="' . $nBrewing . '"		maxlength="3"></td>
			<td width= "7%" align="center"><input type="number" name="editFishing"		size="2" value="' . $nFishing . '"		maxlength="3"></td>
			<td width= "7%" align="center"><input type="number" name="editFletching"	size="2" value="' . $nFletching . '"	maxlength="3"></td>
			<td width= "7%" align="center"><input type="number" name="editForaging"		size="2" value="' . $nForaging . '"		maxlength="3"></td>
			<td width= "7%" align="center"><input type="number" name="editJewelcraft"	size="2" value="' . $nJewelcraft . '"	maxlength="3"></td>
			<td width= "7%" align="center"><input type="number" name="editPoison"		size="2" value="' . $nPoison . '"		maxlength="3"></td>
			<td width= "7%" align="center"><input type="number" name="editPottery"		size="2" value="' . $nPottery . '"		maxlength="3"></td>
			<td width= "7%" align="center"><input type="number" name="editResearch"		size="2" value="' . $nResearch . '"		maxlength="3"></td>
			<td width= "7%" align="center"><input type="number" name="editSmithing"		size="2" value="' . $nSmithing . '"		maxlength="3"></td>
			<td width= "7%" align="center"><input type="number" name="editTailoring"	size="2" value="' . $nTailoring . '"	maxlength="3"></td>
			<td width= "7%" align="center"><input type="number" name="editTinkering"	size="2" value="' . $nTinkering . '"	maxlength="3"></td>
			<td width= "1%"></td>
		  </tr>
		</table>
		</div>


		<!-- Keys -->
		<br />
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="#777777">
		  <tr>
			<td width= "8%"></td>
			<td width="84%" align="center"><font color="#FFFFFF"><i>Keys</i></font></td>
			<td width= "8%" align="right"><font color="#FFFFFF"><i>Show</i></font><input type="checkbox" name="cbDisplayKeysProgression" id="cbDisplayKeysProgression" onClick="DisplayKeysProgression();" value="' . $bShowKeysProgression . '" ' . GetCheckboxValue( $bShowKeysProgression ) . ' title="Show/hide the Keys"></td>
		  </tr>
		</table>

		<div id="Keys_Progression">
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="#777777">
		  <tr>
			<td width="10%"></td>
			<td width="20%"><font color="#FFFFFF"><i>&nbsp Keys</i></font></td>
			<td width="20%"><font color="#FFFFFF"><i>&nbsp SSRA Emperor key</i></font></td>
			<td width="20%"><font color="#FFFFFF"><i>&nbsp Veeshan\'s Peak key</i></font></td>
			<td width="20%"><font color="#FFFFFF"><i>&nbsp Vex Thal key</i></font></td>
			<td width="10%"></td>
		  </tr>
		</table>

		<table width="98%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td width="10%"></td>
			<td width="20%"><input type="checkbox" name="cbBoT_Tower_Key"		value="1" ' . GetCheckboxValue( $nBoT_Tower_Key ) . '>BoT Tower Key</td>
			<td width="20%"><input type="checkbox" name="cbTaskmasters_Pouch"	value="1" ' . GetCheckboxValue( $nTaskmasters_Pouch ) . '>Taskm.\'s Pouch</td>
			<td width="20%"><input type="checkbox" name="cbKylongMedal_Top"		value="1" ' . GetCheckboxValue( $nKylongMedal_Top ) . '>Kylong Medal. Top</td>
			<td width="20%"><input type="checkbox" name="cbGlowing_Orb"			value="1" ' . GetCheckboxValue( $nGlowing_Orb ) . '>Glowing Orb</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"><input type="checkbox" name="cbHowling_Stones_Key"	value="1" ' . GetCheckboxValue( $nHowling_Stones_Key ) . '>Howling Stones Key</td>
			<td width="20%"><input type="checkbox" name="cbZazuzhs_Idol"		value="1" ' . GetCheckboxValue( $nZazuzhs_Idol ) . '>Zazuzh\'s Idol</td>
			<td width="20%"><input type="checkbox" name="cbKylongMedal_Middle"	value="1" ' . GetCheckboxValue( $nKylongMedal_Middle ) . '>Kylong Medal. Mid.</td>
			<td width="20%"><input type="checkbox" name="cbCelestial_Rift"		value="1" ' . GetCheckboxValue( $nCelestial_Rift ) . '>Celestial Rift</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"><input type="checkbox" name="cbSebilis_Key"			value="1" ' . GetCheckboxValue( $nSebilis_Key ) . '>Sebilis Key</td>
			<td width="20%"><input type="checkbox" name="cbRing"				value="1" ' . GetCheckboxValue( $nRing ) . '>Ring</td>
			<td width="20%"><input type="checkbox" name="cbKylongMedal_Bottom"	value="1" ' . GetCheckboxValue( $nKylongMedal_Bottom ) . '>Kylong Medal. Bot.</td>
			<td width="20%"><input type="checkbox" name="cbShard_Dat"			value="1" ' . GetCheckboxValue( $nShard_Dat ) . '>Shard: Dat (FG)</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"><input type="checkbox" name="cbSleepers_Tomb_Key"	value="1" ' . GetCheckboxValue( $nSleepers_Tomb_Key ) . '>Sleepers Tomb Key</td>
			<td width="20%"><input type="checkbox" name="cbInsignia"			value="1" ' . GetCheckboxValue( $nInsignia ) . '>Insignia</td>
			<td width="20%"><input type="checkbox" name="cbJarsathMedal_Top"	value="1" ' . GetCheckboxValue( $nJarsathMedal_Top ) . '>Jarsath Medal. Top</td>
			<td width="20%"><input type="checkbox" name="cbShard_Dax"			value="1" ' . GetCheckboxValue( $nShard_Dax ) . '>Shard: Dax (AR)</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"><input type="checkbox" name="cbSSRA_Emperor_Key"	value="1" ' . GetCheckboxValue( $nSSRA_Emperor_Key ) . '>SSRA Emperor Key</td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbJarsathMedal_Middle"	value="1" ' . GetCheckboxValue( $nJarsathMedal_Middle ) . '>Jarsath Medal. Mid.</td>
			<td width="20%"><input type="checkbox" name="cbShard_Kel"			value="1" ' . GetCheckboxValue( $nShard_Kel ) . '>Shard: Kel (TG)</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"><input type="checkbox" name="cbVeeshans_Peak_Key"	value="1" ' . GetCheckboxValue( $nVeeshans_Peak_Key ) . '>Veeshan\'s Peak Key</td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbJarsathMedal_Bottom"	value="1" ' . GetCheckboxValue( $nJarsathMedal_Bottom ) . '>Jarsath Medal. Bot.</td>
			<td width="20%"><input type="checkbox" name="cbShard_Kelara"		value="1" ' . GetCheckboxValue( $nShard_Kelara ) . '>Shard: Kelara (SS)</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"><input type="checkbox" name="cbVex_Thal_Key"		value="1" ' . GetCheckboxValue( $nVex_Thal_Key ) . '>Vex Thal Key</td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbObulusMedal_Top"		value="1" ' . GetCheckboxValue( $nObulusMedal_Top ) . '>Obulus Medal. Top</td>
			<td width="20%"><input type="checkbox" name="cbShard_Lor"			value="1" ' . GetCheckboxValue( $nShard_Lor ) . '>Shard: Lor (DP)</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbObulusMedal_Middle"	value="1" ' . GetCheckboxValue( $nObulusMedal_Middle ) . '>Obulus Medal. Mid.</td>
			<td width="20%"><input type="checkbox" name="cbShard_Raf"			value="1" ' . GetCheckboxValue( $nShard_Raf ) . '>Shard: Raf (TD)</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbObulusMedal_Bottom"	value="1" ' . GetCheckboxValue( $nObulusMedal_Bottom ) . '>Obulus Medal. Bot.</td>
			<td width="20%"><input type="checkbox" name="cbShard_Set"			value="1" ' . GetCheckboxValue( $nShard_Set ) . '>Shard: Set (SD)</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbTrak_Tooth"			value="1" ' . GetCheckboxValue( $nTrak_Tooth ) . '>Trakanon\'s Tooth</td>
			<td width="20%"><input type="checkbox" name="cbShard_Tak"			value="1" ' . GetCheckboxValue( $nShard_Tak ) . '>Shard: Tak (ME)</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbShard_Ved"			value="1" ' . GetCheckboxValue( $nShard_Ved ) . '>Shard: Ved (AC)</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbShard_Vin"			value="1" ' . GetCheckboxValue( $nShard_Vin ) . '>Shard: Vin (SSRA)</td>
			<td width="10%"></td>
		  </tr>
		</table>
		</div>


		<!-- PoP -->
		<br />
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="#777777">
		  <tr>
			<td width= "8%"></td>
			<td width="84%" align="center"><font color="#FFFFFF"><i>Planes of Power</i></font></td>
			<td width= "8%" align="right"><font color="#FFFFFF"><i>Show</i></font><input type="checkbox" name="cbDisplayPoPProgression" id="cbDisplayPoPProgression" onClick="DisplayPoPProgression();" value="' . $bShowPoPProgression . '" ' . GetCheckboxValue( $bShowPoPProgression ) . ' title="Show/hide the Planes of Power progress"></td>
		  </tr>
		</table>

		<div id="PoP_Progression">
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="#777777">
		  <tr>
			<td width="20%"><font color="#FFFFFF"><i>&nbsp PoP Tier 1 Flags</i></font></td>
			<td width="20%"><font color="#FFFFFF"><i>&nbsp PoP Tier 2 Flags</i></font></td>
			<td width="20%"><font color="#FFFFFF"><i>&nbsp PoP Tier 3 Flags</i></font></td>
			<td width="20%"><font color="#FFFFFF"><i>&nbsp PoP Tier 4 Flags</i></font></td>
			<td width="20%"><font color="#FFFFFF"><i>&nbsp BoT (PoS Quest)</i></font></td>
		  </tr>
		</table>

		<table width="98%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td width="20%"><input type="checkbox" name="cbAny_PoJ_Trial"						value="1" ' . GetCheckboxValue( $nAny_PoJ_Trial )						. '>Any PoJ Trial</td>
			<td width="20%"><input type="checkbox" name="cbPoS_Askr_Quest"						value="1" ' . GetCheckboxValue( $nPoS_Askr_Quest )						. '>PoS Askr Quest</td>
			<td width="20%"><input type="checkbox" name="cbHoH_Trial1_RyddaDar"					value="1" ' . GetCheckboxValue( $nHoH_Trial1_RyddaDar )					. '>HoH Trial1 RyddaDar</td>
			<td width="20%"><input type="checkbox" name="cbPoAir_Xegony"						value="1" ' . GetCheckboxValue( $nPoAir_Xegony )						. '>PoAir Xegony</td>
			<td width="20%"><input type="checkbox" name="cbHead"								value="1" ' . GetCheckboxValue( $nHead )								. '>Giant head</td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbAll_PoJ_Trials"						value="1" ' . GetCheckboxValue( $nAll_PoJ_Trials )						. '>All PoJ Trials</td>
			<td width="20%"><input type="checkbox" name="cbPoV_Grenic_Quest"					value="1" ' . GetCheckboxValue( $nPoV_Grenic_Quest )					. '>PoV Grenic Quest</td>
			<td width="20%"><input type="checkbox" name="cbHoH_Trial2_Ogre"						value="1" ' . GetCheckboxValue( $nHoH_Trial2_Ogre )						. '>HoH Trial2 Ogre</td>
			<td width="20%"><input type="checkbox" name="cbPoFire_Fennin_Ro"					value="1" ' . GetCheckboxValue( $nPoFire_Fennin_Ro )					. '>PoFire Fennin Ro</td>
			<td width="20%"><input type="checkbox" name="cbBeard"								value="1" ' . GetCheckboxValue( $nBeard )								. '>Beard (Ocean)</td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbPoI_Xanamech"						value="1" ' . GetCheckboxValue( $nPoI_Xanamech )						. '>PoI Xanamech</td>
			<td width="20%"><input type="checkbox" name="cbPoV_AerinDar"						value="1" ' . GetCheckboxValue( $nPoV_AerinDar )						. '>PoV AerinDar</td>
			<td width="20%"><input type="checkbox" name="cbHoH_Trial3_Madmen"					value="1" ' . GetCheckboxValue( $nHoH_Trial3_Madmen )					. '>HoH Trial3 Madmen</td>
			<td width="20%"><input type="checkbox" name="cbPoWater_Coirnav"						value="1" ' . GetCheckboxValue( $nPoWater_Coirnav )						. '>PoWater Coirnav</td>
			<td width="20%"><input type="checkbox" name="cbBone"								value="1" ' . GetCheckboxValue( $nBone )								. '>Bone (Desert)</td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbPoI_Behemoth"						value="1" ' . GetCheckboxValue( $nPoI_Behemoth )						. '>PoI Behemoth</td>
			<td width="20%"><input type="checkbox" name="cbCoD_Carprin_Event"					value="1" ' . GetCheckboxValue( $nCoD_Carprin_Event )					. '>CoD Carprin Event</td>
			<td width="20%"><input type="checkbox" name="cbHoHb_Mithanial_Marr"					value="1" ' . GetCheckboxValue( $nHoHb_Mithanial_Marr )					. '>HoHb Mithanial Marr</td>
			<td width="20%"><input type="checkbox" name="cbPoEarthb_The_Rathe"					value="1" ' . GetCheckboxValue( $nPoEarthb_The_Rathe )					. '>PoEarthb The Rathe</td>
			<td width="20%"><input type="checkbox" name="cbSash"								value="1" ' . GetCheckboxValue( $nSash )								. '>Sash (Forest)</td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbPoD_Grimror_Quest"					value="1" ' . GetCheckboxValue( $nPoD_Grimror_Quest )					. '>PoD Grimror Quest</td>
			<td width="20%"><input type="checkbox" name="cbCoD_Bertoxxulous"					value="1" ' . GetCheckboxValue( $nCoD_Bertoxxulous )					. '>CoD Bertoxxulous</td>
			<td width="20%"><input type="checkbox" name="cbPoTactics_Tallon_Zek"				value="1" ' . GetCheckboxValue( $nPoTactics_Tallon_Zek )				. '>PoTactics Tallon Zek</td>
			<td width="20%"><input type="checkbox" name="cbPoTime_Time_Phased_Quintessence"		value="1" ' . GetCheckboxValue( $nPoTime_Time_Phased_Quintessence )		. '>Time Phased Quintessence</td>
			<td width="20%"><input type="checkbox" name="cbOceanMedal"							value="1" ' . GetCheckboxValue( $nOceanMedal )							. '>Ocean Medalion </td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbPoD_Grummus"							value="1" ' . GetCheckboxValue( $nPoD_Grummus )							. '>PoD Grummus</td>
			<td width="20%"><input type="checkbox" name="cbPoTorment_Saryrn"					value="1" ' . GetCheckboxValue( $nPoTorment_Saryrn )					. '>PoTorment Saryrn</td>
			<td width="20%"><input type="checkbox" name="cbPoTactics_Vallon_Zek"				value="1" ' . GetCheckboxValue( $nPoTactics_Vallon_Zek )				. '>PoTactics Vallon Zek</td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbDesertMedal"							value="1" ' . GetCheckboxValue( $nDesertMedal )							. '>Desert Medalion </td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbPoN_Hedge_Quest"						value="1" ' . GetCheckboxValue( $nPoN_Hedge_Quest )						. '>PoN Hedge Quest</td>
			<td width="20%"><input type="checkbox" name="cbPoS_Wembly_Quest"					value="1" ' . GetCheckboxValue( $nPoS_Wembly_Quest )					. '>PoS Wembly Quest</td>
			<td width="20%"><input type="checkbox" name="cbPoTactics_Rallos_Zek_Quest"			value="1" ' . GetCheckboxValue( $nPoTactics_Rallos_Zek_Quest )			. '>PoTactics Rallos Zek Quest</td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbForestMedal"							value="1" ' . GetCheckboxValue( $nForestMedal )							. '>Forest Medalion</td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbPoNb_Terris_Thule"					value="1" ' . GetCheckboxValue( $nPoNb_Terris_Thule )					. '>PoNb Terris Thule</td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbBoT_Rescue_Karana_Quest"				value="1" ' . GetCheckboxValue( $nBoT_Rescue_Karana_Quest )				. '>BoT Rescue Karana Quest</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		  <tr>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbSolRoTower_Jiva"						value="1" ' . GetCheckboxValue( $nSolRoTower_Jiva )						. '>SolRoTower Jiva</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		  <tr>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbSolRoTower_Xuzl"						value="1" ' . GetCheckboxValue( $nSolRoTower_Xuzl )						. '>SolRoTower Xuzl</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		  <tr>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbSolRoTower_Arlyxir"					value="1" ' . GetCheckboxValue( $nSolRoTower_Arlyxir )					. '>SolRoTower Arlyxir</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		  <tr>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbSolRoTower_Rizlona"					value="1" ' . GetCheckboxValue( $nSolRoTower_Rizlona )					. '>SolRoTower Rizlona</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		  <tr>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbSolRoTower_Protector_of_Dresolik"	value="1" ' . GetCheckboxValue( $nSolRoTower_Protector_of_Dresolik )	. '>SolRoTower Dresolik</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		  <tr>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbSolRoTower_Solusek_Ro"				value="1" ' . GetCheckboxValue( $nSolRoTower_Solusek_Ro )				. '>SolRoTower Solusek Ro</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		</table>
		</div>


		<!-- GoD progress -->
		<br />
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="#777777">
		  <tr>
			<td width= "8%"></td>
			<td width="84%" align="center"><font color="#FFFFFF"><i>Gates of Discord</i></font></td>
			<td width= "8%" align="right"><font color="#FFFFFF"><i>Show</i></font><input type="checkbox" name="cbDisplayGoDProgression" id="cbDisplayGoDProgression" onClick="DisplayGoDProgression();" value="' . $bShowGoDProgression . '" ' . GetCheckboxValue( $bShowGoDProgression ) . ' title="Show/hide the Gates of Discord progress"></td>
		  </tr>
		</table>

		<div id="GoD_Progression">
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="#777777">
		  <tr>
			<td width="10%"></td>
			<td width="20%"><font color="#FFFFFF"><i>&nbsp Tier 1</i></font></td>
			<td width="20%"><font color="#FFFFFF"><i>&nbsp Tier 2</i></font></td>
			<td width="20%"><font color="#FFFFFF"><i>&nbsp Tier 3</i></font></td>
			<td width="20%"><font color="#FFFFFF"><i>&nbsp Tacvi</i></font></td>
			<td width="10%"></td>
		  </tr>
		</table>

		<table width="98%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td width="10%"></td>
			<td width="20%"><input type="checkbox" name="cbPurifying_Plant"						value="1" ' . GetCheckboxValue( $nPurifying_Plant )						. '>Purifying Plant</td>
			<td width="20%"><input type="checkbox" name="cbVxed"								value="1" ' . GetCheckboxValue( $nVxed )								. '>Vxed</td>
			<td width="20%"><input type="checkbox" name="cbVrex_Barxt_Qurat"					value="1" ' . GetCheckboxValue( $nVrex_Barxt_Qurat )					. '>Vrex Barxt Qurat</td>
			<td width="20%"><input type="checkbox" name="cbIxt_Hsek_Syat"						value="1" ' . GetCheckboxValue( $nIxt_Hsek_Syat )						. '>Ixt Hsek Syat</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"><input type="checkbox" name="cbEmanating_Furnace"					value="1" ' . GetCheckboxValue( $nEmanating_Furnace )					. '>Emanating Furnace</td>
			<td width="20%"><input type="checkbox" name="cbTipt"								value="1" ' . GetCheckboxValue( $nTipt )								. '>Tipt</td>
			<td width="20%"><input type="checkbox" name="cbKeeper_of_the_Altar"					value="1" ' . GetCheckboxValue( $nKeeper_of_the_Altar )					. '>Keeper of the Altar</td>
			<td width="20%"><input type="checkbox" name="cbHigh_Priest_Nkosi_Bakari"			value="1" ' . GetCheckboxValue( $nHigh_Priest_Nkosi_Bakari )			. '>High Priest Nkosi Bakari</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"><input type="checkbox" name="cbLair_of_Trapped_Ones"				value="1" ' . GetCheckboxValue( $nLair_of_Trapped_Ones )				. '>Lair of Trapped Ones</td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbNoqufiel_in_Inktuta"					value="1" ' . GetCheckboxValue( $nNoqufiel_in_Inktuta )					. '>Noqufiel in Inktuta</td>
			<td width="20%"><input type="checkbox" name="cbZunMuram_Tkarish_Zyk"				value="1" ' . GetCheckboxValue( $nZunMuram_Tkarish_Zyk )				. '>Zun\'Muram Tkarish Zyk</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"><input type="checkbox" name="cbPool_of_Sludge"						value="1" ' . GetCheckboxValue( $nPool_of_Sludge )						. '>Pool of Sludge</td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbCynosure_Kvanjji"					value="1" ' . GetCheckboxValue( $nCynosure_Kvanjji )					. '>Cynosure Kvanjji</td>
			<td width="20%"></td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"><input type="checkbox" name="cbSmith_Rondo"							value="1" ' . GetCheckboxValue( $nSmith_Rondo )							. '>Smith Rondo</td>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="10%"></td>
		  </tr>
		</table>
		</div>


		<!-- OoW CoA progress -->
		<br />
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="#777777">
		  <tr>
			<td width= "8%"></td>
			<td width="84%" align="center"><font color="#FFFFFF"><i>Omens of War - Citadel of Anguish</i></font></td>
			<td width= "8%" align="right"><font color="#FFFFFF"><i>Show</i></font><input type="checkbox" name="cbDisplayOoW_CoAProgression" id="cbDisplayOoW_CoAProgression" onClick="DisplayOoW_CoAProgression();" value="' . $bShowOoW_CoAProgression . '" ' . GetCheckboxValue( $bShowOoW_CoAProgression ) . ' title="Show/hide the Omens of War: Citadel of Anguish progress"></td>
		  </tr>
		</table>

		<div id="OoW_CoA_Progression">
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="#777777">
		  <tr>
			<td width="30%"></td>
			<td width="20%" align="left"><font color="#FFFFFF"><i>&nbsp Access</i></font></td>
			<td width="20%" align="left"><font color="#FFFFFF"><i>&nbsp Immunisation</i></font></td>
			<td width="30%"></td>
		  </tr>
		</table>

		<table width="98%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td width="30%"></td>
			<td width="20%"><input type="checkbox" name="cbMastery_of_Adaptation"		value="1" ' . GetCheckboxValue( $nMastery_of_Adaptation )		. '>Mastery of Adaptation</td>
			<td width="20%"><input type="checkbox" name="cbSignet_Crystal_Gemmed"		value="1" ' . GetCheckboxValue( $nSignet_Crystal_Gemmed )		. '>Crystal Gemmed Signet</td>
			<td width="30%"></td>
		  </tr>
		  <tr>
			<td width="30%"></td>
			<td width="20%"><input type="checkbox" name="cbMastery_of_Corruption"		value="1" ' . GetCheckboxValue( $nMastery_of_Corruption )		. '>Mastery of Corruption</td>
			<td width="20%"><input type="checkbox" name="cbSignet_Discolored"			value="1" ' . GetCheckboxValue( $nSignet_Discolored )			. '>Discolored Signet</td>
			<td width="30%"></td>
		  </tr>
		  <tr>
			<td width="30%"></td>
			<td width="20%"><input type="checkbox" name="cbMastery_of_Endurance"		value="1" ' . GetCheckboxValue( $nMastery_of_Endurance )		. '>Mastery of Endurance</td>
			<td width="20%"><input type="checkbox" name="cbSignet_Dust_Marred"			value="1" ' . GetCheckboxValue( $nSignet_Dust_Marred )			. '>Dust Marred Signet</td>
			<td width="30%"></td>
		  </tr>
		  <tr>
			<td width="30%"></td>
			<td width="20%"><input type="checkbox" name="cbMastery_of_Foresight"		value="1" ' . GetCheckboxValue( $nMastery_of_Foresight )		. '>Mastery of Foresight</td>
			<td width="20%"><input type="checkbox" name="cbSignet_Glimmering"			value="1" ' . GetCheckboxValue( $nSignet_Glimmering )			. '>Glimmering Signet</td>
			<td width="30%"></td>
		  </tr>
		  <tr>
			<td width="30%"></td>
			<td width="20%"><input type="checkbox" name="cbMastery_of_Hate"				value="1" ' . GetCheckboxValue( $nMastery_of_Hate )				. '>Mastery of Hate</td>
			<td width="20%"><input type="checkbox" name="cbSignet_Tarnished"			value="1" ' . GetCheckboxValue( $nSignet_Tarnished )			. '>Tarnished Signet</td>
			<td width="30%"></td>
		  </tr>
		  <tr>
			<td width="30%"></td>
			<td width="20%"><input type="checkbox" name="cbMastery_of_Specialization"	value="1" ' . GetCheckboxValue( $nMastery_of_Specialization )	. '>Mastery of Specialization</td>
			<td width="20%"><input type="checkbox" name="cbSignet_Two_Toned"			value="1" ' . GetCheckboxValue( $nSignet_Two_Toned )			. '>Two Toned Signet</td>
			<td width="30%"></td>
		  </tr>
		  <tr>
			<td width="30%"></td>
			<td width="20%"><input type="checkbox" name="cbSeal_Mastery_of_All"			value="1" ' . GetCheckboxValue( $nSeal_Mastery_of_All )			. '>Seal: Mastery of All</td>
			<td width="20%"><input type="checkbox" name="cbSignet_Weather_Worn"			value="1" ' . GetCheckboxValue( $nSignet_Weather_Worn )			. '>Weather Worn Signet</td>
			<td width="30%"></td>
		  </tr>
		</table>
		</div>


		<!-- DoN progress -->
		<br />
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="#777777">
		  <tr>
			<td width= "8%"></td>
			<td width="84%" align="center"><font color="#FFFFFF"><i>Dragons of Norrath</i></font></td>
			<td width= "8%" align="right"><font color="#FFFFFF"><i>Show</i></font><input type="checkbox" name="cbDisplayDoNProgression" id="cbDisplayDoNProgression" onClick="DisplayDoNProgression();" value="' . $bShowDoNProgression . '" ' . GetCheckboxValue( $bShowDoNProgression ) . ' title="Show/hide the Dragons of Norrath progress"></td>
		  </tr>
		</table>

		<div id="DoN_Progression">
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="#777777">
		  <tr>
			<td width="20%"><font color="#FFFFFF"><i>&nbsp Tier 1</i></font></td>
			<td width="20%"><font color="#FFFFFF"><i>&nbsp Tier 2</i></font></td>
			<td width="20%"><font color="#FFFFFF"><i>&nbsp Tier 3</i></font></td>
			<td width="20%"><font color="#FFFFFF"><i>&nbsp Tier 4</i></font></td>
			<td width="20%"><font color="#FFFFFF"><i>&nbsp Tier 5</i></font></td>
		  </tr>
		</table>

		<div id="DoN_Progression_Good">
		<table width="98%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td width="20%"><input type="checkbox" name="cbT1_Create_an_Antidote"			value="1" ' . GetCheckboxValue( $nT1_Create_an_Antidote )			. '>Create an Antidote</td>
			<td width="20%"><input type="checkbox" name="cbT2_Defend_the_Kirin_Contact"		value="1" ' . GetCheckboxValue( $nT2_Defend_the_Kirin_Contact )		. '>Defend the Kirin Contact</td>
			<td width="20%"><input type="checkbox" name="cbT3_Protect_the_Waters"			value="1" ' . GetCheckboxValue( $nT3_Protect_the_Waters )			. '>Protect the Waters</td>
			<td width="20%"><input type="checkbox" name="cbT4_Goblin_Dojo"					value="1" ' . GetCheckboxValue( $nT4_Goblin_Dojo )					. '>Goblin Dojo</td>
			<td width="20%"><input type="checkbox" name="cbT5_Origins_of_the_Curse"			value="1" ' . GetCheckboxValue( $nT5_Origins_of_the_Curse )			. '>Origins of the Curse</td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbT1_Greed_of_the_Goblins"			value="1" ' . GetCheckboxValue( $nT1_Greed_of_the_Goblins )			. '>Greed of the Goblins</td>
			<td width="20%"><input type="checkbox" name="cbT2_Recover_the_Lost_Map"			value="1" ' . GetCheckboxValue( $nT2_Recover_the_Lost_Map )			. '>Recover the Lost Map</td>
			<td width="20%"><input type="checkbox" name="cbT3_Snowfoots_Revenge"			value="1" ' . GetCheckboxValue( $nT3_Snowfoots_Revenge )			. '>Snowfoots Revenge</td>
			<td width="20%"><input type="checkbox" name="cbT4_Guardian_of_the_Sands"		value="1" ' . GetCheckboxValue( $nT4_Guardian_of_the_Sands )		. '>Guardian of the Sands</td>
			<td width="20%"><input type="checkbox" name="cbT5_The_Curse_of_JuRek"			value="1" ' . GetCheckboxValue( $nT5_The_Curse_of_JuRek )			. '>The Curse of Ju\'Rek</td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbT1_Burning_Arrows"				value="1" ' . GetCheckboxValue( $nT1_Burning_Arrows )				. '>Burning Arrows</td>
			<td width="20%"><input type="checkbox" name="cbT2_Turn_the_Tides_of_the_Sand"	value="1" ' . GetCheckboxValue( $nT2_Turn_the_Tides_of_the_Sand )	. '>Turn the Tides of the Sand</td>
			<td width="20%"><input type="checkbox" name="cbT3_The_Sacred_Scrolls"			value="1" ' . GetCheckboxValue( $nT3_The_Sacred_Scrolls )			. '>The Sacred Scrolls</td>
			<td width="20%"><input type="checkbox" name="cbT4_An_End_to_the_Storms"			value="1" ' . GetCheckboxValue( $nT4_An_End_to_the_Storms )			. '>An End to the Storms</td>
			<td width="20%"><input type="checkbox" name="cbT5_In_the_Shadows"				value="1" ' . GetCheckboxValue( $nT5_In_the_Shadows )				. '>In the Shadows</td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbT1_Children_of_Gimblax"			value="1" ' . GetCheckboxValue( $nT1_Children_of_Gimblax )			. '>Children of Gimblax</td>
			<td width="20%"><input type="checkbox" name="cbT2_Sickness_of_the_Spirit"		value="1" ' . GetCheckboxValue( $nT2_Sickness_of_the_Spirit )		. '>Sickness of the Spirit</td>
			<td width="20%"><input type="checkbox" name="cbT3_History_of_the_Isle"			value="1" ' . GetCheckboxValue( $nT3_History_of_the_Isle )			. '>History of the Isle</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		  <tr>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbT2_Calling_Emoush"				value="1" ' . GetCheckboxValue( $nT2_Calling_Emoush )				. '>Calling Emoush</td>
			<td width="20%"><input type="checkbox" name="cbT3_Trial_of_Perserverance"		value="1" ' . GetCheckboxValue( $nT3_Trial_of_Perserverance )		. '>Trial of Perserverance</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		  <tr>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbT3_Volkaras_Bite"				value="1" ' . GetCheckboxValue( $nT3_Volkaras_Bite )				. '>Volkara\'s Bite</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		</table>
		</div>

		<div id="DoN_Progression_Evil">
		<table width="98%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td width="20%"><input type="checkbox" name="cbT1_Create_an_Antidote"			value="1" ' . GetCheckboxValue( $nT1_Create_an_Antidote )			. '>Blood of the Basilisk</td>
			<td width="20%"><input type="checkbox" name="cbT2_Defend_the_Kirin_Contact"		value="1" ' . GetCheckboxValue( $nT2_Defend_the_Kirin_Contact )		. '>Reap the Kirin Mind</td>
			<td width="20%"><input type="checkbox" name="cbT3_Protect_the_Waters"			value="1" ' . GetCheckboxValue( $nT3_Protect_the_Waters )			. '>Muddy the Waters</td>
			<td width="20%"><input type="checkbox" name="cbT4_Goblin_Dojo"					value="1" ' . GetCheckboxValue( $nT4_Goblin_Dojo )					. '>Goblin Dojo</td>
			<td width="20%"><input type="checkbox" name="cbT5_Origins_of_the_Curse"			value="1" ' . GetCheckboxValue( $nT5_Origins_of_the_Curse )			. '>Origins of the Curse</td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbT1_Greed_of_the_Goblins"			value="1" ' . GetCheckboxValue( $nT1_Greed_of_the_Goblins )			. '>Clearing the Path</td>
			<td width="20%"><input type="checkbox" name="cbT2_Recover_the_Lost_Map"			value="1" ' . GetCheckboxValue( $nT2_Recover_the_Lost_Map )			. '>Army of Stone</td>
			<td width="20%"><input type="checkbox" name="cbT3_Snowfoots_Revenge"			value="1" ' . GetCheckboxValue( $nT3_Snowfoots_Revenge )			. '>Snowfoot Attack</td>
			<td width="20%"><input type="checkbox" name="cbT4_Guardian_of_the_Sands"		value="1" ' . GetCheckboxValue( $nT4_Guardian_of_the_Sands )		. '>Guardian of the Sands</td>
			<td width="20%"><input type="checkbox" name="cbT5_The_Curse_of_JuRek"			value="1" ' . GetCheckboxValue( $nT5_The_Curse_of_JuRek )			. '>The Curse of Ju\'Rek</td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbT1_Burning_Arrows"				value="1" ' . GetCheckboxValue( $nT1_Burning_Arrows )				. '>The Burning Poison</td>
			<td width="20%"><input type="checkbox" name="cbT2_Turn_the_Tides_of_the_Sand"	value="1" ' . GetCheckboxValue( $nT2_Turn_the_Tides_of_the_Sand )	. '>Blood from the Sand</td>
			<td width="20%"><input type="checkbox" name="cbT3_The_Sacred_Scrolls"			value="1" ' . GetCheckboxValue( $nT3_The_Sacred_Scrolls )			. '>The Gilded Scroll</td>
			<td width="20%"><input type="checkbox" name="cbT4_An_End_to_the_Storms"			value="1" ' . GetCheckboxValue( $nT4_An_End_to_the_Storms )			. '>An End to the Storms</td>
			<td width="20%"><input type="checkbox" name="cbT5_In_the_Shadows"				value="1" ' . GetCheckboxValue( $nT5_In_the_Shadows )				. '>In the Shadows</td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbT1_Children_of_Gimblax"			value="1" ' . GetCheckboxValue( $nT1_Children_of_Gimblax )			. '>Have Note Will Travel</td>
			<td width="20%"><input type="checkbox" name="cbT2_Sickness_of_the_Spirit"		value="1" ' . GetCheckboxValue( $nT2_Sickness_of_the_Spirit )		. '>Drake Egg</td>
			<td width="20%"><input type="checkbox" name="cbT3_History_of_the_Isle"			value="1" ' . GetCheckboxValue( $nT3_History_of_the_Isle )			. '>Knowledge is Power</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		  <tr>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbT2_Calling_Emoush"				value="1" ' . GetCheckboxValue( $nT2_Calling_Emoush )				. '>Calling Emoush</td>
			<td width="20%"><input type="checkbox" name="cbT3_Trial_of_Perserverance"		value="1" ' . GetCheckboxValue( $nT3_Trial_of_Perserverance )		. '>Trial of Perserverance</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		  <tr>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbT3_Volkaras_Bite"				value="1" ' . GetCheckboxValue( $nT3_Volkaras_Bite )				. '>Volkara\'s Bite</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		</table>
		</div>

		<table width="60%" border="0" cellspacing="0" cellpadding="0" bgcolor="#777777">
		  <tr>
			<td width="30%" align="right"><font color="#FFFFFF"><i>Show DoN progression:</i></font></td>
			<td width="30%"><font color="#FFFFFF"><i>
				<input type="radio" id="rbDoN_Progression_Good" name="DoN_Progression" onClick="DisplayDoNProgressionType();" value="Good" ' . GetCheckboxValue( $bDoNProgressionGood )  . '>Good
				<input type="radio" id="rbDoN_Progression_Evil" name="DoN_Progression" onClick="DisplayDoNProgressionType();" value="Evil" ' . GetCheckboxValue( !$bDoNProgressionGood ) . '>Evil
				</i></font>
			</td>
		  </tr>
		</table>
		</div>

		<!-- DoD Spell Missions -->
		<br />
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="#777777">
		  <tr>
			<td width= "8%"></td>
			<td width="84%" align="center"><font color="#FFFFFF"><i>Depths of Darkhollow</i></font></td>
			<td width= "8%" align="right"><font color="#FFFFFF"><i>Show</i></font><input type="checkbox" name="cbDisplayDoDProgression" id="cbDisplayDoDProgression" onClick="DisplayDoDProgression();" value="' . $bShowDoDProgression . '" ' . GetCheckboxValue( $bShowDoDProgression ) . ' title="Show/hide the Depths of Darkhollow progress"></td>
		  </tr>
		</table>

		<div id="DoD_Progression">
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="#777777">
		  <tr>
			<td width="20%"></td>
			<td width="20%"><font color="#FFFFFF"><i>&nbsp Level 68 Spell</i></font></td>
			<td width="20%"><font color="#FFFFFF"><i>&nbsp Level 69 Spell</i></font></td>
			<td width="20%"><font color="#FFFFFF"><i>&nbsp Level 70 Spell</i></font></td>
			<td width="20%"></td>
		  </tr>
		</table>

		<table width="98%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbA_Rogues_Trust"			value="1" ' . GetCheckboxValue( $nA_Rogues_Trust ) . '>A Rogue`s Trust</td>
			<td width="20%"><input type="checkbox" name="cbThe_Lost_Notebook"		value="1" ' . GetCheckboxValue( $nThe_Lost_Notebook ) . '>The Lost Notebook</td>
			<td width="20%"><input type="checkbox" name="cbPreemptive_Strike"		value="1" ' . GetCheckboxValue( $nPreemptive_Strike ) . '>Preemptive Strike</td>
			<td width="20%"></td>
		  </tr>
		  <tr>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbScouting_the_City"		value="1" ' . GetCheckboxValue( $nScouting_the_City ) . '>Scouting the City</td>
			<td width="20%"><input type="checkbox" name="cbCavern_Botany"			value="1" ' . GetCheckboxValue( $nCavern_Botany ) . '>Cavern Botany</td>
			<td width="20%"><input type="checkbox" name="cbPraetorian_Guard"		value="1" ' . GetCheckboxValue( $nPraetorian_Guard ) . '>Praetorian Guard</td>
			<td width="20%"></td>
		  </tr>
		  <tr>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbBuilding_the_Disguise"	value="1" ' . GetCheckboxValue( $nBuilding_the_Disguise ) . '>Building the Disguise</td>
			<td width="20%"><input type="checkbox" name="cbThe_Search_for_Clues"	value="1" ' . GetCheckboxValue( $nThe_Search_for_Clues ) . '>The Search for Clues</td>
			<td width="20%"><input type="checkbox" name="cbThe_Fall_of_Illsalin"	value="1" ' . GetCheckboxValue( $nThe_Fall_of_Illsalin ) . '>The Fall of Illsalin</td>
			<td width="20%"></td>
		  </tr>
		  <tr>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbThe_Search_for_Illsuras"	value="1" ' . GetCheckboxValue( $nThe_Search_for_Illsuras ) . '>The Search for Illsuras</td>
			<td width="20%"><input type="checkbox" name="cbRescue_Cicero"			value="1" ' . GetCheckboxValue( $nRescue_Cicero ) . '>Rescue Cicero</td>
			<td width="20%"><input type="checkbox" name="cbFlights_of_the_Seeker"	value="1" ' . GetCheckboxValue( $nFlights_of_the_Seeker ) . '>Flights of the Seeker</td>
			<td width="20%"></td>
		  </tr>
		  <tr>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbThe_Rage_of_Kelliad"		value="1" ' . GetCheckboxValue( $nThe_Rage_of_Kelliad ) . '>The Rage of Kelliad</td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbInto_the_Shadows"		value="1" ' . GetCheckboxValue( $nInto_the_Shadows ) . '>Into the Shadows</td>
			<td width="20%"></td>
		  </tr>
		</table>
		</div>


		<!-- Show/Hide the correct progressions -->
		<script language="JavaScript">
		  DisplayStatistics();
		  DisplayTradeskills();
		  DisplayKeysProgression();
		  DisplayPoPProgression();
		  DisplayGoDProgression();
		  DisplayOoW_CoAProgression();
		  DisplayDoNProgressionType();
		  DisplayDoNProgression();
		  DisplayDoDProgression();
		</script>

		<font color="#C0C0FF">
			' . $strFooterMessage . '
		</font>
		<br />

		<br />
		<input type="submit" name="pbCancel" value="Cancel" onclick="CancelModify();">
		<input type="submit" name="pbModifyRecord" value="Modify Record" onclick="ValidateFields();">

		<!-- Hidden field to store CancelModify status -->
	    <input name="cbCancelModify" type="hidden" id="cbCancelModify" value="false">
		<!-- Hidden field to store Validation status -->
	    <input name="cbValidated" type="hidden" id="cbValidated" value="' . $bValidated . '">
		<!-- Hidden field to store MageloImport status -->
	    <input name="cbImportMagelo" type="hidden" id="cbImportMagelo" value="false" />

		</center>
		</div>
		<br />
	</form>
	<!-- End of Modify Character -->';
	print( "\n\n\n" );
}



// =============================================================================
// Create a select box on a the Name Main field for all Mains
// =============================================================================
// Out:	$strResult	= The html code to create the select box
function CreateNameMainSelect( $strSelectedNameMain, $strOffSet )
{
	// Declare variables
	$strResult			= "";
	$strSelectQuery		= "SELECT DISTINCT NameMain \n" .
						  "FROM Characters \n" .
						  "WHERE NameMain = CharName \n" .
						  "   OR GuildStatus != 'Alt' \n" .
						  "ORDER BY NameMain \n";

	// Check if no default value was passed
	if( !isset( $strSelectedNameMain ) )
	{
		// Empty the field
		$strSelectedNameMain	= "";
	}

	// Connect to the database
	$nLinkID			= DBConnect();

	// Get the database fields
	$nResult			= mysql_query( $strSelectQuery, $nLinkID );

	// Create the combobox
	$strResult			= "<select name=\"cmbNameMain\" id=\"cmbNameMain\"><br />\n";	// $strOffSet is not used here, because we expect this function to be called at that offset.

	// Show the records one by one
    while( $aResult	= mysql_fetch_row( $nResult ) ) 
	{
		// Retrieve the variables out of the array
		$strNameMain	= $aResult[0];

		// Create the option
		$strResult		.= "$strOffSet	<option value=\"" . $strNameMain . "\"";
		// Check if this is the default option
		if( $strNameMain == $strSelectedNameMain )
		{
			$strResult	.= " selected=\"selected\"";
		}
		// Finish the option
		$strResult		.= ">" . $strNameMain . "</option>\n";
	}

	// Finish the combobox
	$strResult			.= "$strOffSet</select>";

	// Close the connection
	DBDisconnect( $nLinkID );

	// Done, return the result
	return $strResult;
}

?>


</body>
</html>
            