<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );
require_once( './includes/functions_database.inc' );
require_once( './includes/class.magelo.inc' );


// ============================================================================
// The Users class
// ============================================================================
// This class handles the Magelo_Batch_Import procedure
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class Magelo_Batch_Import
{
	// Variables
	var	$nNrOfImportChars	= 0;	// Nr of characters to import
	// String used to flush the page to the client
	var $strFlusher			= '                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ';

	// ========================================================================
	// Constructor
	// ========================================================================
	function Magelo_Batch_Import()
	{
		// No code yet
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "Magelo Batch Import";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<font size="-3"><br /></font>
		<center><b><font size="+2" color="#00FF33">
		  Import multiple character Magelo\'s...
		</font></b></center>
		<!-- End of Header -->
		';
	}
	
	
	
	// ========================================================================
	// Show the body
	// ========================================================================
	// This function will show the Magelo Batch Import page
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS	= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName	= $_GET['UserName'];
		$strPassword	= $_GET['Password'];
		$strClassFilter	= $_GET['ClassFilter'];
		$bPerformImport	= $_GET['cbPerformImport'];
		$aCharacters[0]	= "";

		// Check if the UserName is an admin
		if( ( isset( $strUserName ) ) &&
			( $strUserName != "" ) )
		{
			// Check if the user clicked Import
			if( ( isset( $bPerformImport ) ) &&
				( $bPerformImport == "true" ) )
			{
				// Loop through the array with VARS to find the check boxes
				if( !empty($aHTTP_GET_VARS) )
				{
					foreach( $aHTTP_GET_VARS as $strVarName => $strValue )
					{
						// Check if it's an import checkbox
						if( substr( $strVarName, 0, 8 ) == "cbImport" )
						{
							// Check if the checkbox was clicked
							if( $strValue == true )
							{
								// Import this char
								$aCharacters[$this->nNrOfImportChars]	= substr( $strVarName, 8 );
	
								// Raise the nr of imported chars
								$this->nNrOfImportChars++;
							}
						}
					}
	
					// Check if any chars where imported
					if( $this->nNrOfImportChars > 0 )
					{
						// Import the character
						$this->ImportMagelos( $strUserName, $strPassword, $strClassFilter, $aCharacters );
					}
					else
					{
						// Show a message telling the user to select some chars first
						echo'
						<center>Select some characters before pressing Import.</center><br />
						';
	
						// Show the import magelo's page
						$this->ShowImportMagelosPage( $strUserName, $strPassword, $strClassFilter, $bPerformImport );
					}
				}
				else
				{
					print( "<font color='#FF3300'>Error: Empty HTTP_GET_VARS array!</font>" );
				}
			}
			else
			{
				// Show the import magelo's page
				$this->ShowImportMagelosPage( $strUserName, $strPassword, $strClassFilter, $bPerformImport );
			}
		}
		else
		{
			// Show error
			print( "<font color='#FF3300'>Unkown user...</font>" );
		}
	}
	
	
	
	// ========================================================================
	// Import a character's magelo
	// ========================================================================
	function ImportMagelos( $strUserName, $strPassword, $strClassFilter, $aCharacters )
	{
		// Declare variables
		$strRowType				= "EvenRow";
		$nNrOfImportedMagelos	= 0;

		// Set the execution time limit off
		@set_time_limit( 0 );

		// Start the form
		echo '
		<form name="formImportMagelos" method="post" action="form.php?FormName=Characters&UserName=' . $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '&CookieAction=READ" target=Body>
		  <div id="Body" align="center">
		    <br />
		';

		// Show the loading image
		ShowLoadingImage();

		// Create the header table
		echo '
			<table id="RosterTable" width="50%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="30%" class="HeaderRow">Name<br /><hr /></td>
				<td width="20%" class="HeaderRow" align="center">Magelo<br /><hr /></td>
				<td width="50%" class="HeaderRow">Status<br /><hr /></td>
			  </tr>
			</table>
		';		

		// Flush the PHP page
		print( $this->strFlusher );
		print( $this->strFlusher );
		print( $this->strFlusher );
		print( $this->strFlusher );
		print( $this->strFlusher );
		flush();
		sleep(1);

		// Loop through the array with VARS to find the check boxes
		foreach( $aCharacters as $strCharName )
		{
			// Import this character's magelo
			if( $this->ImportMagelo( $strCharName, $strRowType ) == true )
			{
				$nNrOfImportedMagelos++;
			}

			// Switch RowType, so the rows alternate	
			if( $strRowType == "OddRow" )
			{
				$strRowType	= "EvenRow";
			}
			else
			{
				$strRowType	= "OddRow";
			}
		}

		// Close the form
		echo '
			<table id="RosterTable" width="50%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="30%"><hr /></td>
				<td width="20%"><hr /></td>
				<td width="50%"><hr /></td>
			  </tr>
			</table>

			<br />
			<font color="#00FF33">' . $nNrOfImportedMagelos . ' Magelo(s) imported.</font><br />
			<font color="#FF3300">' . (count( $aCharacters ) - $nNrOfImportedMagelos) . ' Error(s) encountered.</font><br />
			<br />
		    <input type="submit" name="pbDone" value="Done">
		  </div>
		';

		// Hide the loading image
		HideLoadingImage();

		// Close the form
		echo '
		</form>
		';
	}



	// ========================================================================
	// Import a characters magelo
	// ========================================================================
	function ImportMagelo( $strCharName, $strRowType )
	{
		// Declare variables
		$nDelay				= 1;
		$bSucces			= false;
		$nNrOfRecords		= 0;
		$strSelectQuery		= "SELECT	Characters.CharID, LastName, NameMain, Class, Race, Gender, Level, AA, GLP, MageloNr, GuildStatus, \n" .
							  "         HP, Mana, AC, FlowingThought, Regen, Atk, Str, Sta, Agi, Dex, Wis, `Int`, Cha, PR, MR, DR, FR, CR, \n" .
							  "         Alchemy, Baking, Brewing, Fishing, Fletching, Foraging, Jewelcraft, Poison, Pottery, Research, Smithing, Tailoring, Tinkering, \n" .
							  "         BoT_Tower_Key, Howling_Stones_Key, Sebilis_Key, Sleepers_Tomb_Key, SSRA_Emperor_Key, Veeshans_Peak_Key, Vex_Thal_Key, \n" .
							  "         Head, Beard, Bone, Sash, OceanMedal, DesertMedal, ForestMedal, \n" .
							  "         Taskmasters_Pouch, Zazuzhs_Idol, Ring, Insignia, \n" .
							  "         KylongMedal_Top, KylongMedal_Middle, KylongMedal_Bottom, JarsathMedal_Top, JarsathMedal_Middle, JarsathMedal_Bottom, ObulusMedal_Top, ObulusMedal_Middle, ObulusMedal_Bottom, Trak_Tooth, \n" .
							  "         Glowing_Orb, Celestial_Rift, Shard_Dat, Shard_Dax, Shard_Kel, Shard_Kelara, Shard_Lor, Shard_Raf, Shard_Set, Shard_Tak, Shard_Ved, Shard_Vin, \n" .
							  "         Any_PoJ_Trial, All_PoJ_Trials, PoI_Xanamech, PoI_Behemoth, PoD_Grimror_Quest, PoD_Grummus, PoN_Hedge_Quest, PoNb_Terris_Thule, \n" .
							  "         PoS_Askr_Quest, PoV_Grenic_Quest, PoV_AerinDar, CoD_Carprin_Event, CoD_Bertoxxulous, PoTorment_Saryrn, PoS_Wembly_Quest, \n" .
							  "         HoH_Trial1_RyddaDar, HoH_Trial2_Ogre, HoH_Trial3_Madmen, HoHb_Mithanial_Marr, PoTactics_Tallon_Zek, PoTactics_Vallon_Zek, PoTactics_Rallos_Zek_Quest, BoT_Rescue_Karana_Quest, SolRoTower_Jiva, SolRoTower_Xuzl, SolRoTower_Arlyxir, SolRoTower_Rizlona, SolRoTower_Protector_of_Dresolik, SolRoTower_Solusek_Ro, \n" .
							  "         PoAir_Xegony, PoFire_Fennin_Ro, PoWater_Coirnav, PoEarthb_The_Rathe, PoTime_Time_Phased_Quintessence, \n" .
							  "         Purifying_Plant, Emanating_Furnace, Lair_of_Trapped_Ones, Pool_of_Sludge, Smith_Rondo, Vxed, Tipt, Vrex_Barxt_Qurat, Cynosure_Kvanjji, Noqufiel_in_Inktuta, ZunMuram_Tkarish_Zyk, \n" .
							  "         T1_Create_an_Antidote, T1_Greed_of_the_Goblins, T1_Burning_Arrows, T1_Children_of_Gimblax, T2_Defend_the_Kirin_Contact, T2_Recover_the_Lost_Map, T2_Turn_the_Tides_of_the_Sand, T2_Sickness_of_the_Spirit, T2_Calling_Emoush, T3_Protect_the_Waters, T3_Snowfoots_Revenge, T3_The_Sacred_Scrolls, T3_History_of_the_Isle, T3_Trial_of_Perserverance, T3_Volkaras_Bite, T4_Goblin_Dojo, T4_Guardian_of_the_Sands, T4_An_End_to_the_Storms, T5_Origins_of_the_Curse, T5_The_Curse_of_JuRek, T5_In_the_Shadows \n" .
							  "FROM Characters \n" .
							  "LEFT JOIN TradeSkills		ON (Characters.CharID = TradeSkills.CharID) \n" .
							  "LEFT JOIN `Keys`				ON (Characters.CharID = `Keys`.CharID) \n" .
							  "LEFT JOIN PoS_Askr_Quest		ON (Characters.CharID = PoS_Askr_Quest.CharID) \n" .
							  "LEFT JOIN SSRA_Emperor_Key	ON (Characters.CharID = SSRA_Emperor_Key.CharID) \n" .
							  "LEFT JOIN Veeshans_Peak_Key	ON (Characters.CharID = Veeshans_Peak_Key.CharID) \n" .
							  "LEFT JOIN Vex_Thal_Key		ON (Characters.CharID = Vex_Thal_Key.CharID) \n" .
							  "LEFT JOIN PoP_Tier_1_Flags	ON (Characters.CharID = PoP_Tier_1_Flags.CharID) \n" .
							  "LEFT JOIN PoP_Tier_2_Flags	ON (Characters.CharID = PoP_Tier_2_Flags.CharID) \n" .
							  "LEFT JOIN PoP_Tier_3_Flags	ON (Characters.CharID = PoP_Tier_3_Flags.CharID) \n" .
							  "LEFT JOIN PoP_Tier_4_Flags	ON (Characters.CharID = PoP_Tier_4_Flags.CharID) \n" .
							  "LEFT JOIN GoD_Flags			ON (Characters.CharID = GoD_Flags.CharID) \n" .
							  "LEFT JOIN DoN_Flags			ON (Characters.CharID = DoN_Flags.CharID) \n" .
							  "WHERE CharName = '$strCharName' \n";

		// Start a new table
		echo'
			<table id="RosterTable" width="50%" border="0" cellpadding="0" cellspacing="0">
			  <tr	onMouseOver="this.bgColor=\'' . GetRowHighLightColor() . '\'" onMouseOut="this.bgColor=\'\'">
				<td width="30%" class="' . $strRowType . '">' . $strCharName . '</td>
		';

		// Connect to the database
		$nLinkID	= DBConnect();

		// Retrieve the record
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Fetch the record
		$aResult	= mysql_fetch_row( $nResult );

		// Close the connection
		DBDisconnect( $nLinkID );

	    if( $aResult ) 
		{
			// Retrieve the variables out of the array
			$nIndex								= 0;
				// Characters
			$strCharID							= $aResult[$nIndex++];
			$strLastName						= $aResult[$nIndex++];
			$strNameMain						= $aResult[$nIndex++];
			$strClass							= $aResult[$nIndex++];
			$strRace							= $aResult[$nIndex++];
			$strGender							= $aResult[$nIndex++];
			$nLevel								= $aResult[$nIndex++];
			$nAA								= $aResult[$nIndex++];
			$nGLP								= $aResult[$nIndex++];
			$nMageloNr							= $aResult[$nIndex++];
			$strGuildStatus						= $aResult[$nIndex++];
				// Character Statistics
			$nHP								= $aResult[$nIndex++];
			$nMana								= $aResult[$nIndex++];
			$nAC								= $aResult[$nIndex++];
			$nFT								= $aResult[$nIndex++];
			$nRegen								= $aResult[$nIndex++];
			$nAtk								= $aResult[$nIndex++];
			$nStr								= $aResult[$nIndex++];
			$nSta								= $aResult[$nIndex++];
			$nAgi								= $aResult[$nIndex++];
			$nDex								= $aResult[$nIndex++];
			$nWis								= $aResult[$nIndex++];
			$nInt								= $aResult[$nIndex++];
			$nCha								= $aResult[$nIndex++];
			$nPR								= $aResult[$nIndex++];
			$nMR								= $aResult[$nIndex++];
			$nDR								= $aResult[$nIndex++];
			$nFR								= $aResult[$nIndex++];
			$nCR 								= $aResult[$nIndex++];
				// Trade Skills
			$nAlchemy							= $aResult[$nIndex++]; 
			$nBaking							= $aResult[$nIndex++]; 
			$nBrewing							= $aResult[$nIndex++]; 
			$nFishing							= $aResult[$nIndex++]; 
			$nFletching							= $aResult[$nIndex++]; 
			$nForaging							= $aResult[$nIndex++]; 
			$nJewelcraft						= $aResult[$nIndex++]; 
			$nPoison							= $aResult[$nIndex++]; 
			$nPottery							= $aResult[$nIndex++]; 
			$nResearch							= $aResult[$nIndex++]; 
			$nSmithing							= $aResult[$nIndex++]; 
			$nTailoring							= $aResult[$nIndex++]; 
			$nTinkering							= $aResult[$nIndex++]; 
				// Keys
			$nBoT_Tower_Key						= $aResult[$nIndex++]; 
			$nHowling_Stones_Key				= $aResult[$nIndex++]; 
			$nSebilis_Key						= $aResult[$nIndex++]; 
			$nSleepers_Tomb_Key					= $aResult[$nIndex++]; 
			$nSSRA_Emperor_Key					= $aResult[$nIndex++]; 
			$nVeeshans_Peak_Key					= $aResult[$nIndex++]; 
			$nVex_Thal_Key						= $aResult[$nIndex++]; 
				// BoT flag
			$nHead								= $aResult[$nIndex++]; 
			$nBeard								= $aResult[$nIndex++]; 
			$nBone								= $aResult[$nIndex++]; 
			$nSash								= $aResult[$nIndex++]; 
			$nOceanMedal						= $aResult[$nIndex++]; 
			$nDesertMedal						= $aResult[$nIndex++]; 
			$nForestMedal						= $aResult[$nIndex++]; 
				// SSRA Emperor key
			$nTaskmasters_Pouch					= $aResult[$nIndex++]; 
			$nZazuzhs_Idol						= $aResult[$nIndex++]; 
			$nRing								= $aResult[$nIndex++]; 
			$nInsignia							= $aResult[$nIndex++]; 
				// Veeshan's Peek key
			$nKylongMedal_Top					= $aResult[$nIndex++]; 
			$nKylongMedal_Middle				= $aResult[$nIndex++]; 
			$nKylongMedal_Bottom				= $aResult[$nIndex++]; 
			$nJarsathMedal_Top					= $aResult[$nIndex++]; 
			$nJarsathMedal_Middle				= $aResult[$nIndex++]; 
			$nJarsathMedal_Bottom				= $aResult[$nIndex++]; 
			$nObulusMedal_Top					= $aResult[$nIndex++]; 
			$nObulusMedal_Middle				= $aResult[$nIndex++]; 
			$nObulusMedal_Bottom				= $aResult[$nIndex++]; 
			$nTrak_Tooth						= $aResult[$nIndex++]; 
				// Vex Thal key
			$nGlowing_Orb						= $aResult[$nIndex++]; 
			$nCelestial_Rift					= $aResult[$nIndex++]; 
			$nShard_Dat							= $aResult[$nIndex++]; 
			$nShard_Dax							= $aResult[$nIndex++]; 
			$nShard_Kel							= $aResult[$nIndex++]; 
			$nShard_Kelara						= $aResult[$nIndex++]; 
			$nShard_Lor							= $aResult[$nIndex++]; 
			$nShard_Raf							= $aResult[$nIndex++]; 
			$nShard_Set							= $aResult[$nIndex++]; 
			$nShard_Tak							= $aResult[$nIndex++]; 
			$nShard_Ved							= $aResult[$nIndex++]; 
			$nShard_Vin							= $aResult[$nIndex++]; 
				// Pop Tier 1 Flags
			$nAny_PoJ_Trial						= $aResult[$nIndex++];
			$nAll_PoJ_Trials					= $aResult[$nIndex++];
			$nPoI_Xanamech						= $aResult[$nIndex++];
			$nPoI_Behemoth						= $aResult[$nIndex++];
			$nPoD_Grimror_Quest					= $aResult[$nIndex++];
			$nPoD_Grummus						= $aResult[$nIndex++];
			$nPoN_Hedge_Quest					= $aResult[$nIndex++];
			$nPoNb_Terris_Thule					= $aResult[$nIndex++];
				// Pop Tier 2 Flags
			$nPoS_Askr_Quest					= $aResult[$nIndex++];
			$nPoV_Grenic_Quest					= $aResult[$nIndex++];
			$nPoV_AerinDar						= $aResult[$nIndex++];
			$nCoD_Carprin_Event					= $aResult[$nIndex++];
			$nCoD_Bertoxxulous					= $aResult[$nIndex++];
			$nPoTorment_Saryrn					= $aResult[$nIndex++];
			$nPoS_Wembly_Quest					= $aResult[$nIndex++];
				// Pop Tier 3 Flags
			$nHoH_Trial1_RyddaDar				= $aResult[$nIndex++];
			$nHoH_Trial2_Ogre					= $aResult[$nIndex++];
			$nHoH_Trial3_Madmen					= $aResult[$nIndex++];
			$nHoHb_Mithanial_Marr				= $aResult[$nIndex++];
			$nPoTactics_Tallon_Zek				= $aResult[$nIndex++];
			$nPoTactics_Vallon_Zek				= $aResult[$nIndex++];
			$nPoTactics_Rallos_Zek_Quest		= $aResult[$nIndex++];
			$nBoT_Rescue_Karana_Quest			= $aResult[$nIndex++];
			$nSolRoTower_Jiva					= $aResult[$nIndex++];
			$nSolRoTower_Xuzl					= $aResult[$nIndex++];
			$nSolRoTower_Arlyxir				= $aResult[$nIndex++];
			$nSolRoTower_Rizlona				= $aResult[$nIndex++];
			$nSolRoTower_Protector_of_Dresolik	= $aResult[$nIndex++];
			$nSolRoTower_Solusek_Ro				= $aResult[$nIndex++];
				// Pop Tier 4 Flags
			$nPoAir_Xegony						= $aResult[$nIndex++];
			$nPoFire_Fennin_Ro					= $aResult[$nIndex++];
			$nPoWater_Coirnav					= $aResult[$nIndex++];
			$nPoEarthb_The_Rathe				= $aResult[$nIndex++];
			$nPoTime_Time_Phased_Quintessence	= $aResult[$nIndex++];
				// GoD Flags
			$nPurifying_Plant					= $aResult[$nIndex++];
			$nEmanating_Furnace					= $aResult[$nIndex++];
			$nLair_of_Trapped_Ones				= $aResult[$nIndex++];
			$nPool_of_Sludge					= $aResult[$nIndex++];
			$nSmith_Rondo						= $aResult[$nIndex++];
			$nVxed								= $aResult[$nIndex++];
			$nTipt								= $aResult[$nIndex++];
			$nVrex_Barxt_Qurat					= $aResult[$nIndex++];
			$nCynosure_Kvanjji					= $aResult[$nIndex++];
			$nNoqufiel_in_Inktuta				= $aResult[$nIndex++];
			$nZunMuram_Tkarish_Zyk				= $aResult[$nIndex++];
				// DoN Flags
			$nT1_Create_an_Antidote				= $aResult[$nIndex++];
			$nT1_Greed_of_the_Goblins			= $aResult[$nIndex++];
			$nT1_Burning_Arrows					= $aResult[$nIndex++];
			$nT1_Children_of_Gimblax			= $aResult[$nIndex++];
			$nT2_Defend_the_Kirin_Contact		= $aResult[$nIndex++];
			$nT2_Recover_the_Lost_Map			= $aResult[$nIndex++];
			$nT2_Turn_the_Tides_of_the_Sand		= $aResult[$nIndex++];
			$nT2_Sickness_of_the_Spirit			= $aResult[$nIndex++];
			$nT2_Calling_Emoush					= $aResult[$nIndex++];
			$nT3_Protect_the_Waters				= $aResult[$nIndex++];
			$nT3_Snowfoots_Revenge				= $aResult[$nIndex++];
			$nT3_The_Sacred_Scrolls				= $aResult[$nIndex++];
			$nT3_History_of_the_Isle			= $aResult[$nIndex++];
			$nT3_Trial_of_Perserverance			= $aResult[$nIndex++];
			$nT3_Volkaras_Bite					= $aResult[$nIndex++];
			$nT4_Goblin_Dojo					= $aResult[$nIndex++];
			$nT4_Guardian_of_the_Sands			= $aResult[$nIndex++];
			$nT4_An_End_to_the_Storms			= $aResult[$nIndex++];
			$nT5_Origins_of_the_Curse			= $aResult[$nIndex++];
			$nT5_The_Curse_of_JuRek				= $aResult[$nIndex++];
			$nT5_In_the_Shadows					= $aResult[$nIndex++];

			// Store the magelo nr in the table cell
			echo '		<td width="20%" class="' . $strRowType . '" align="center">' . $nMageloNr . '</td>
				';

			// Create the magelo object
			$theMagelo	= new Magelo( $nMageloNr, $strCharName, $strClass );
			// Import the magelo
			if( $theMagelo->Import() )
			{
				// Retrieve character info
				$strLastName					= $theMagelo->strLastName;
				// Make sure the Last Name is properly formatted (Names start with capital etc.)
				$strLastName	= FormatName( $strLastName );

				if( $theMagelo->nLevel > $nLevel )
				{
					$nLevel							= $theMagelo->nLevel;
				}
				if( $theMagelo->nAA > $nAA )
				{
					$nAA							= $theMagelo->nAA;
				}
				if( $theMagelo->nNrOfGLPs > $nGLP )
				{
					$nGLP							= $theMagelo->nNrOfGLPs;
				}
				$strRace							= $theMagelo->strRace;
				// Magelo returns "Half Elf" as "Half-Elf", so we convert it back.
				if( $strRace == "Half-Elf" )
				{
					$strRace	= "Half Elf";
				}
//				$strGender							= $theMagelo->strGender;
				// Keys
				if( $theMagelo->nVexThalKey == 1 )
				{
					$nVex_Thal_Key					= $theMagelo->nVexThalKey;
					// Set all key flags to true as well
					$nGlowing_Orb					= 1;
					$nCelestial_Rift				= 1;
					$nShard_Dat						= 1;
					$nShard_Dax						= 1;
					$nShard_Kel						= 1;
					$nShard_Kelara					= 1;
					$nShard_Lor						= 1;
					$nShard_Raf						= 1;
					$nShard_Set						= 1;
					$nShard_Tak						= 1;
					$nShard_Ved						= 1;
					$nShard_Vin						= 1;
				}
				$nSebilis_Key						= $theMagelo->nSebilisKey;
				if( $theMagelo->nVeeshansPeakKey == 1 )
				{
					$nVeeshans_Peak_Key				= $theMagelo->nVeeshansPeakKey;
					// Set all key flags to true as well
					$nKylongMedal_Top				= 1;
					$nKylongMedal_Middle			= 1;
					$nKylongMedal_Bottom			= 1;
					$nJarsathMedal_Top				= 1;
					$nJarsathMedal_Middle			= 1;
					$nJarsathMedal_Bottom			= 1;
					$nObulusMedal_Top				= 1;
					$nObulusMedal_Middle			= 1;
					$nObulusMedal_Bottom			= 1;
					$nTrak_Tooth					= 1;
				}
				$nHowling_Stones_Key				= $theMagelo->nHowlingStonesKey;
				$nSleepers_Tomb_Key					= $theMagelo->nSleepersTombKey;
				if( $theMagelo->nSSRAEmperorKey == 1 )
				{
					$nSSRA_Emperor_Key				= $theMagelo->nSSRAEmperorKey;
					// Set all key flags to true as well
					$nTaskmasters_Pouch				= 1;
					$nZazuzhs_Idol					= 1;
					$nRing							= 1;
					$nInsignia						= 1;
				}
				if( $theMagelo->nPoS_Askr_Quest == 1 )
				{
					$nHead							= 1;
					$nBeard							= 1;
					$nBone							= 1;
					$nSash							= 1;
				}
				// Retrieve the statistics
				$nHP								= $theMagelo->nHP;
				$nMana								= $theMagelo->nMana;
				$nAC								= $theMagelo->nAC;
				$nFT								= $theMagelo->nFT;
				$nRegen								= $theMagelo->nRegen;
				$nAtk								= $theMagelo->nAtk;
				$nStr								= $theMagelo->nStr;
				$nSta								= $theMagelo->nSta;
				$nAgi								= $theMagelo->nAgi;
				$nDex								= $theMagelo->nDex;
				$nWis								= $theMagelo->nWis;
				$nInt								= $theMagelo->nInt;
				$nCha								= $theMagelo->nCha;
				$nPR								= $theMagelo->nPR;
				$nMR								= $theMagelo->nMR;
				$nDR								= $theMagelo->nDR;
				$nFR								= $theMagelo->nFR;
				$nCR								= $theMagelo->nCR;
				// Retrieve the tradeskills
				$nAlchemy							= $theMagelo->nAlchemy;
				$nBaking							= $theMagelo->nBaking;
				$nBrewing							= $theMagelo->nBrewing;
				$nFishing							= $theMagelo->nFishing;
				$nFletching							= $theMagelo->nFletching;
				$nForaging							= $theMagelo->nForaging;
				$nJewelcraft						= $theMagelo->nJewelry;
				$nPoison							= $theMagelo->nPosionMaking;
				$nPottery							= $theMagelo->nPottery;
				$nResearch							= $theMagelo->nResearch;
				$nSmithing							= $theMagelo->nSmithing;
				$nTailoring							= $theMagelo->nTailoring;
				$nTinkering							= $theMagelo->nTinkering;
				// Pop Tier 1 Flags
				$nAny_PoJ_Trial						= $theMagelo->nAny_PoJ_Trial;
				$nAll_PoJ_Trials					= $theMagelo->nAll_PoJ_Trials;
				$nPoI_Xanamech						= $theMagelo->nPoI_Xanamech;
				$nPoI_Behemoth						= $theMagelo->nPoI_Behemoth;
				$nPoD_Grimror_Quest					= $theMagelo->nPoD_Grimror_Quest;
				$nPoD_Grummus						= $theMagelo->nPoD_Grummus;
				$nPoN_Hedge_Quest					= $theMagelo->nPoN_Hedge_Quest;
				$nPoNb_Terris_Thule					= $theMagelo->nPoNb_Terris_Thule;
				// Pop Tier 2 Flags
				$nPoS_Askr_Quest					= $theMagelo->nPoS_Askr_Quest;
				$nPoV_Grenic_Quest					= $theMagelo->nPoV_Grenic_Quest;
				$nPoV_AerinDar						= $theMagelo->nPoV_AerinDar;
				$nCoD_Bertoxxulous					= $theMagelo->nCoD_Bertoxxulous;
				$nPoTorment_Saryrn					= $theMagelo->nPoTorment_Saryrn;
				$nPoS_Wembly_Quest					= $theMagelo->nPoS_Wembly_Quest;
				// Pop Tier 3 Flags
				$nHoH_Trial1_RyddaDar				= $theMagelo->nHoH_Trial1_RyddaDar;
				$nHoH_Trial2_Ogre					= $theMagelo->nHoH_Trial2_Ogre;
				$nHoH_Trial3_Madmen					= $theMagelo->nHoH_Trial3_Madmen;
				$nHoHb_Mithanial_Marr				= $theMagelo->nHoHb_Mithanial_Marr;
				$nPoTactics_Tallon_Zek				= $theMagelo->nPoTactics_Tallon_Zek;
				$nPoTactics_Vallon_Zek				= $theMagelo->nPoTactics_Vallon_Zek;
				$nPoTactics_Rallos_Zek_Quest		= $theMagelo->nPoTactics_Rallos_Zek_Quest;
				$nBoT_Rescue_Karana_Quest			= $theMagelo->nBoT_Rescue_Karana_Quest;
				$nSolRoTower_Jiva					= $theMagelo->nSolRoTower_Jiva;
				$nSolRoTower_Xuzl					= $theMagelo->nSolRoTower_Xuzl;
				$nSolRoTower_Arlyxir				= $theMagelo->nSolRoTower_Arlyxir;
				$nSolRoTower_Rizlona				= $theMagelo->nSolRoTower_Rizlona;
				$nSolRoTower_Protector_of_Dresolik	= $theMagelo->nSolRoTower_Protector_of_Dresolik;
				$nSolRoTower_Solusek_Ro				= $theMagelo->nSolRoTower_Solusek_Ro;
				// Pop Tier 4 Flags
				$nPoAir_Xegony						= $theMagelo->nPoAir_Xegony;
				$nPoFire_Fennin_Ro					= $theMagelo->nPoFire_Fennin_Ro;
				$nPoWater_Coirnav					= $theMagelo->nPoWater_Coirnav;
				$nPoEarthb_The_Rathe				= $theMagelo->nPoEarthb_The_Rathe;
				if( $theMagelo->nPoTime_Time_Phased_Quintessence == 1 )
				{
					$nPoTime_Time_Phased_Quintessence	= 1;
				}
				// GoD Flags
				$nPurifying_Plant					= $theMagelo->nPurifying_Plant;
				$nEmanating_Furnace					= $theMagelo->nEmanating_Furnace;
				$nLair_of_Trapped_Ones				= $theMagelo->nLair_of_Trapped_Ones;
				$nPool_of_Sludge					= $theMagelo->nPool_of_Sludge;
				$nSmith_Rondo						= $theMagelo->nSmith_Rondo;
				$nVxed								= $theMagelo->nVxed;
				$nTipt								= $theMagelo->nTipt;
				$nVrex_Barxt_Qurat					= $theMagelo->nVrex_Barxt_Qurat;
				$nCynosure_Kvanjji					= $theMagelo->nCynosure_Kvanjji;
				$nNoqufiel_in_Inktuta				= $theMagelo->nNoqufiel_in_Inktuta;
				$nZunMuram_Tkarish_Zyk				= $theMagelo->nZunMuram_Tkarish_Zyk;
				// DoN Flags
				if( $theMagelo->nDoN_Tier1_Done == 1 )
				{
					$nT1_Create_an_Antidote			= 1;
					$nT1_Greed_of_the_Goblins		= 1;
					$nT1_Burning_Arrows				= 1;
					$nT1_Children_of_Gimblax		= 1;
				}
				if( $theMagelo->nDoN_Tier2_Done == 1 )
				{
					$nT2_Defend_the_Kirin_Contact	= 1;
					$nT2_Recover_the_Lost_Map		= 1;
					$nT2_Turn_the_Tides_of_the_Sand	= 1;
					$nT2_Sickness_of_the_Spirit		= 1;
					$nT2_Calling_Emoush				= 1;
				}
				if( $theMagelo->nDoN_Tier3_Done == 1 )
				{
					$nT3_Protect_the_Waters			= 1;
					$nT3_Snowfoots_Revenge			= 1;
					$nT3_The_Sacred_Scrolls			= 1;
					$nT3_History_of_the_Isle		= 1;
					$nT3_Trial_of_Perserverance		= 1;
					$nT3_Volkaras_Bite				= 1;
				}
				if( $theMagelo->nDoN_Tier4_Done == 1 )
				{
					$nT4_Goblin_Dojo				= 1;
					$nT4_Guardian_of_the_Sands		= 1;
					$nT4_An_End_to_the_Storms		= 1;
				}
				if( $theMagelo->nDoN_Tier5_Done == 1 )
				{
					$nT5_Origins_of_the_Curse		= 1;
					$nT5_The_Curse_of_JuRek			= 1;
					$nT5_In_the_Shadows				= 1;
				}

				// Update all the tables for this user
				// Update the Character
				$nCharID	= UpdateCharacter( $strCharName, $strLastName, $strNameMain, $strGuildStatus, $nAA, $nGLP, $strRace, $strGender, $nMageloNr, $nHP, $nMana, $nAC, $nFT, $nRegen, $nAtk, $nStr, $nSta, $nAgi, $nDex, $nWis, $nInt, $nCha, $nPR, $nMR, $nDR, $nFR, $nCR );
				if( $nCharID > 0 )
				{
					// Update the Tradeskill record
					$strResult	= UpdateTradeskills( $nCharID, $strCharName, $nAlchemy, $nBaking, $nBrewing, $nFishing, $nFletching, $nForaging, $nJewelcraft, $nPoison, $nPottery, $nResearch, $nSmithing, $nTailoring, $nTinkering );
					// Update the Keys record
					$strResult	= UpdateKeys( $nCharID, $strCharName, $nBoT_Tower_Key, $nHowling_Stones_Key, $nSebilis_Key, $nSleepers_Tomb_Key, $nSSRA_Emperor_Key, $nVeeshans_Peak_Key, $nVex_Thal_Key );
					// Update the PoS_Askr_Quest record
					$strResult	= UpdatePoS_Askr_Quest( $nCharID, $strCharName, $nHead, $nBeard, $nBone, $nSash, $nOceanMedal, $nDesertMedal, $nForestMedal );
					// Update the SSRA_Emperor_Key record
					$strResult	= UpdateSSRAEmperorKey( $nCharID, $strCharName, $nTaskmasters_Pouch, $nZazuzhs_Idol, $nRing, $nInsignia );
					// Update the Veeshans_Peak_Key record
					$strResult	= UpdateVeeshansPeakKey( $nCharID, $strCharName, $nKylongMedal_Top, $nKylongMedal_Middle, $nKylongMedal_Bottom, $nJarsathMedal_Top, $nJarsathMedal_Middle, $nJarsathMedal_Bottom, $nObulusMedal_Top, $nObulusMedal_Middle, $nObulusMedal_Bottom, $nTrak_Tooth );
					// Update the Vex_Thal_Key record
					$strResult	= UpdateVexThalKey( $nCharID, $strCharName, $nGlowing_Orb, $nCelestial_Rift, $nShard_Dat, $nShard_Dax, $nShard_Kel, $nShard_Kelara, $nShard_Lor, $nShard_Raf, $nShard_Set, $nShard_Tak, $nShard_Ved, $nShard_Vin );
					// Update the Pop Tier 1 Flags record
					$strResult	= UpdatePoPTier1( $nCharID, $strCharName, $nAny_PoJ_Trial, $nAll_PoJ_Trials, $nPoI_Xanamech, $nPoI_Behemoth, $nPoD_Grimror_Quest, $nPoD_Grummus, $nPoN_Hedge_Quest, $nPoNb_Terris_Thule );
					// Update the Pop Tier 2 Flags record
					$strResult	= UpdatePoPTier2( $nCharID, $strCharName, $nPoS_Askr_Quest, $nPoV_Grenic_Quest, $nPoV_AerinDar, $nCoD_Carprin_Event, $nCoD_Bertoxxulous, $nPoTorment_Saryrn, $nPoS_Wembly_Quest );
					// Update the Pop Tier 3 Flags record
					$strResult	= UpdatePoPTier3( $nCharID, $strCharName, $nHoH_Trial1_RyddaDar, $nHoH_Trial2_Ogre, $nHoH_Trial3_Madmen, $nHoHb_Mithanial_Marr, $nPoTactics_Tallon_Zek, $nPoTactics_Vallon_Zek, $nPoTactics_Rallos_Zek_Quest, $nBoT_Rescue_Karana_Quest, $nSolRoTower_Jiva, $nSolRoTower_Xuzl, $nSolRoTower_Arlyxir, $nSolRoTower_Rizlona, $nSolRoTower_Protector_of_Dresolik, $nSolRoTower_Solusek_Ro );
					// Update the Pop Tier 4 Flags record
					$strResult	= UpdatePoPTier4( $nCharID, $strCharName, $nPoAir_Xegony, $nPoFire_Fennin_Ro, $nPoWater_Coirnav, $nPoEarthb_The_Rathe, $nPoTime_Time_Phased_Quintessence );
					// Update the GoD Flags record
					$strResult	= UpdateGoDFlags( $nCharID, $strCharName, $nPurifying_Plant, $nEmanating_Furnace, $nLair_of_Trapped_Ones, $nPool_of_Sludge, $nSmith_Rondo, $nVxed, $nTipt, $nVrex_Barxt_Qurat, $nCynosure_Kvanjji, $nNoqufiel_in_Inktuta, $nZunMuram_Tkarish_Zyk );
					// Update the DoN Flags record
					$strResult	= UpdateDoNFlags( $nCharID, $strCharName, $nT1_Create_an_Antidote, $nT1_Greed_of_the_Goblins, $nT1_Burning_Arrows, $nT1_Children_of_Gimblax, $nT2_Defend_the_Kirin_Contact, $nT2_Recover_the_Lost_Map, $nT2_Turn_the_Tides_of_the_Sand, $nT2_Sickness_of_the_Spirit, $nT2_Calling_Emoush, $nT3_Protect_the_Waters, $nT3_Snowfoots_Revenge, $nT3_The_Sacred_Scrolls, $nT3_History_of_the_Isle, $nT3_Trial_of_Perserverance, $nT3_Volkaras_Bite, $nT4_Goblin_Dojo, $nT4_Guardian_of_the_Sands, $nT4_An_End_to_the_Storms, $nT5_Origins_of_the_Curse, $nT5_The_Curse_of_JuRek, $nT5_In_the_Shadows );
				}

				// Import/Update succesfull
				$bSucces	= true;
				
				// Fill the status cell in the table
				echo '<td width="50%"><font color="#00FF33">Magelo imported...</font></td>';
			}
			else
			{
				// Couldn't import magelo
				echo '<td width="50%"><font color="#FF3300">Failed to import magelo!</font></td>';
			}
			
			// Set the Sleep delay to 2 minutes (120 seconds)
			$nDelay	= 120;	// DO NOT REMOVE THIS LINE OR LOWER THE NR, OR WWW.MAGELO.COM WILL BAN YOUR IP!!!!!
		}
		else
		{
			// Couldn't find the character record
			echo '<td width="20%" align="center"><font color="#FF3300">Unkown</font></td>
					<td width="50%"><font color="#FF3300">Database query failed!</font></td>';
		}

		// End the table
		echo '
			  </tr>
			</table>
			';

	
		// Flush the PHP page
		print( $this->strFlusher );
		print( $this->strFlusher );
		print( $this->strFlusher );
		print( $this->strFlusher );
		print( $this->strFlusher );
		flush();
		// Only sleep if more then 3 magelo's are being imported
		if( $this->nNrOfImportChars > 3 )
		{
			sleep( $nDelay );
		}

		return $bSucces;
	}



	// ========================================================================
	// Show the Magelos Import page
	// ========================================================================
	function ShowImportMagelosPage( $strUserName, $strPassword, $strClassFilter, $bPerformImport )
	{
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT CharName, LastName, MageloNr \n" .
							  " FROM Characters \n" .
							  " WHERE OldMember = 0 \n" .
							  "   AND MageloNr > 0 \n";
		$nNrOfCharacters	= 0;

		// Users can only edit their own characters
		if( !IsAdministrator( $strUserName ) )
		{
			$strSelectQuery	.= "   AND NameMain = '" . $strUserName . "' \n";
		}
		else
		{
			// Check if we should set a class filter (only for Admins)
			if( ( isset( $strClassFilter ) ) &&
				( $strClassFilter != "" ) &&
				( $strClassFilter != "<<All>>" ) )
			{
				$strSelectQuery	.= "   AND Class = '" . $strClassFilter . "' \n";
			}
		}
		
		// Add sort order
		$strSelectQuery		.= " ORDER BY CharName ";

		echo '
		<!-- JavaScript block has been added here instead of in the header on purpose -->
		<script language="JavaScript">

		<!-- Perform the Import -->
		function PerformImport()
		{
			// Declare variables
			var aControls		= document.getElementsByTagName( "input" )
			var nNrOfCharacters	= 0;

			// Loop through each checkbox in the array
			for( var nControl = 0; nControl < aControls.length; nControl++ )
			{
				// Check if it is a checkbox
				if( ( aControls[nControl].type == "checkbox" ) &&
					( aControls[nControl].checked == true ) )
				{
					nNrOfCharacters++;
				}
			}

			// Check if any characters are marked for deletion
			if( nNrOfCharacters > 0 )
			{
				// Validation complete, all fields are valid
				document.formImportMagelos.cbPerformImport.value	= true;
				document.formImportMagelos.cbPerformImport.checked	= true;

				// submit the form				
				document.formImportMagelos.submit();
			}
			else
			{
				// Show warning
				alert( "You must select some characters first..." );
			}
		};


		// Toggle the value of a checkbox when it is clicked
		function ClickCheckBox( cbClicked )
		{
			// Validation complete, all fields are valid
			cbClicked.value	= cbClicked.checked;
		};


		// Set all checkboxes ON (bChecked = true) or OFF (bChecked = false)
		function SetAllCheckBoxes( bChecked )
		{
			// Declare variables
			var aControls		= document.getElementsByTagName( "input" )
			var objControl		= null;
			var strControlName	= "";

			// Loop through each checkbox in the array
			for( var nControl = 0; nControl < aControls.length; nControl++ )
			{
				// Check if it is a checkbox
				if( ( aControls[nControl].type == "checkbox" ) &&
					( ((aControls[nControl].name).match( "cbImport" )).length > 0 ) )
				{
					// turn the checkbox on
					aControls[nControl].value	= bChecked;
					aControls[nControl].checked	= bChecked;
				}
			}
		};
		
		</script>


		<form name="formImportMagelos" method="post" action="form.php?FormName=Magelo_Batch_Import&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&PreviousForm=' . $strPreviousForm . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&ClassFilter=' . $strClassFilter . '" target=Body>
		  <br />
		  <div id="Body" align="center"> 
		';

		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
			<table id="RosterTable" width="33%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width= "5%"></td>
				<td width="20%">Name</td>
				<td width="8%" align="center">Magelo</td>
			  </tr>
			  <tr>
				<td width= "5%"><hr /></td>
				<td width="20%"><hr /></td>
				<td width= "8%"><hr /></td>
			  </tr>
		';

		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex				= 0;
			$strCharName		= $aResult[$nIndex++];
			$strLastName		= $aResult[$nIndex++];
			$nMageloNr			= $aResult[$nIndex++];
			$strCheckBoxValue	= '"false"';

			// Character's Main is selected by default
			if( $strCharName == $strUserName )
			{
				$strCheckBoxValue	= '"true" checked';
			}
	
			// Check if the last name is filled
			$strFullName	= $strCharName;
			if( isset( $strLastName ) )
			{
				$strFullName	.=  " " . $strLastName;
			}

			echo'
			  <tr	onMouseOver="this.bgColor=\'' . GetRowHighLightColor() . '\'" onMouseOut="this.bgColor=\'\'">
				<td width= "5%" class="' . $strRowType . '" align="center"><input name="cbImport' . $strCharName . '" type="checkbox" id="cbImport' . $strCharName . '" value=' . $strCheckBoxValue . '" onClick="ClickCheckBox(this);">
				<td width="20%" class="' . $strRowType . '">'					. $strFullName	. '</td>
				<td width= "8%" class="' . $strRowType . '" align="center">'	. $nMageloNr	. '</td>
			  </tr>
			';

			// Switch RowType, so the rows alternate	
			if( $strRowType == "OddRow" )
			{
				$strRowType	= "EvenRow";
			}
			else
			{
				$strRowType	= "OddRow";
			}
			
			// Raise the OldMember counter
			$nNrOfCharacters++;
		}
	
		// End the character table
		echo '
			</table>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );

		// Print the end of the page
		if( $nNrOfCharacters > 0 )
		{
			echo '
			<br />
			<input type="button" name="pbDeselectAllCharacters" value="Select None" onclick="SetAllCheckBoxes( false );">
			<input type="button" name="pbSelectAllCharacters"   value="Select All"  onclick="SetAllCheckBoxes( true );">
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		    <input type="button" name="pbImport"                value="Import"      onclick="PerformImport();">
		    <!-- Hidden field to store Import status -->
	        <input name="cbPerformImport" type="hidden" id="cbPerformImport" value="' . $bPerformImport . '">
	        ';
	    }
	    else
	    {
			echo '
			<br />
			<br />
			<center><font size=+2 color="#FF3300">
			No characters with a MageloNr present on the roster.
			</font></center>
			';
	    }
	    
	    echo '
		  </div>
		</form>
		';
	}

}

?>
