<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );


// ============================================================================
// The PoP Tier 2 Flags class
// ============================================================================
// This class provides an interface to the PoP_Tier_2_Flags table
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class PoP_Tier_2_Flags
{
	var $bShowVerticalScrollbars	= true;

	// ========================================================================
	// Constructor
	// ========================================================================
	function PoP_Tier_2_Flags()
	{
		// No code yet
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "PoP Tier 2 Flags";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<div id="Header">
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td width= "5%"></td>
			<td width="18%">				<b><a href="form.php?FormName=PoP_Tier_2_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=CharName&SortDirection='			. GetSortDirection( $strSortOrder, "CharName",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Name\';return true;"								OnMouseOut="window.status=\'\'"	target=Body title="Name"							>Name</a></b></td>
			<td width="11%" align="center">	<b><a href="form.php?FormName=PoP_Tier_2_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=PoS_Askr_Quest&SortDirection='		. GetSortDirection( $strSortOrder, "PoS_Askr_Quest",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Plane of Storms: Askr Quest\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Plane of Storms: Askr Quest"		>PoS<br />Askr Quest</a></b></td>
			<td width="11%" align="center">	<b><a href="form.php?FormName=PoP_Tier_2_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=PoV_Grenic_Quest&SortDirection='	. GetSortDirection( $strSortOrder, "PoV_Grenic_Quest",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Plane of Valor: Grenic Quest\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Plane of Valor: Grenic Quest"	>PoV<br />Grenic Quest</a></b></td>
			<td width="11%" align="center">	<b><a href="form.php?FormName=PoP_Tier_2_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=PoV_AerinDar&SortDirection='		. GetSortDirection( $strSortOrder, "PoV_AerinDar",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Plane of Valor: AerinDar\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Plane of Valor: AerinDar"		>PoV<br />AerinDar</a></b></td>
			<td width="11%" align="center">	<b><a href="form.php?FormName=PoP_Tier_2_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=CoD_Carprin_Event&SortDirection='	. GetSortDirection( $strSortOrder, "CoD_Carprin_Event",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Crypt of Disease: Carprin Event\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Crypt of Disease: Carprin Event"	>CoD<br />Carprin Event</a></b></td>
			<td width="11%" align="center">	<b><a href="form.php?FormName=PoP_Tier_2_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=CoD_Bertoxxulous&SortDirection='	. GetSortDirection( $strSortOrder, "CoD_Bertoxxulous",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Crypt of Disease: Bertoxxulous\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Crypt of Disease: Bertoxxulous"	>CoD<br />Bertoxxulous</a></b></td>
			<td width="11%" align="center">	<b><a href="form.php?FormName=PoP_Tier_2_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=PoTorment_Saryrn&SortDirection='	. GetSortDirection( $strSortOrder, "PoTorment_Saryrn",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Plane of Torment: Saryrn\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Plane of Torment: Saryrn"		>PoTorment<br />Saryrn</a></b></td>
			<td width="11%" align="center">	<b><a href="form.php?FormName=PoP_Tier_2_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=PoS_Wembly_Quest&SortDirection='	. GetSortDirection( $strSortOrder, "PoS_Wembly_Quest",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Plane of Storms: Wembly Quest\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Plane of Storms: Wembly Quest"	>PoS<br />Wembly Quest</a></b></td>
		  </tr>
		</table>
		</div>
		<!-- End of Header -->
		';
	}
	
	
	
	// ========================================================================
	// Show all the records on screen
	// ========================================================================
	// This function will loop through all the records in the database table,
	// and create a html table entry for each one of them.
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS		= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];
		$strClassFilter		= $_GET['ClassFilter'];

		// Declare variables
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT CharName, NameMain, PoS_Askr_Quest, PoV_Grenic_Quest, PoV_AerinDar, CoD_Carprin_Event, CoD_Bertoxxulous, PoTorment_Saryrn, PoS_Wembly_Quest, OldMember \n" .
							  "FROM PoP_Tier_2_Flags \n" .
							  "LEFT JOIN Characters ON (PoP_Tier_2_Flags.CharID = Characters.CharID) \n" .
							  "WHERE (	PoS_Askr_Quest > 0		OR \n" .
							  "			PoV_Grenic_Quest > 0	OR \n" .
							  "			PoV_AerinDar > 0		OR \n" .
							  "			CoD_Carprin_Event > 0	OR \n" .
							  "			CoD_Bertoxxulous > 0	OR \n" .
							  "			PoTorment_Saryrn > 0	OR \n" .
							  "			PoS_Wembly_Quest > 0 )	   \n";	
	
		// Check if we should set a class filter
		if( ( isset( $strClassFilter ) ) &&
			( $strClassFilter != "" ) &&
			( $strClassFilter != "<<All>>" ) )
		{
			$strSelectQuery	.= "AND Class = '" . $strClassFilter . "'";
		} 

		// Check if we should use the default sort order
		if( ( !isset( $strSortOrder ) ) ||
			( $strSortOrder == "" ) )
		{
			// Default sort on Character name
			$strSortOrder	= "CharName"; 
		}

		// Sorting on all numbers should be reversed (Desc first, then Asc)
		$strModifiedSortDirection	= $strSortDirection;
		if( $strSortOrder != "CharName" )
		{
			// Switch the sort order around
			if( $strModifiedSortDirection == "DESC" )
			{
				$strModifiedSortDirection	= "";
			}
			else
			{
				$strModifiedSortDirection	= "DESC";
			}
		}
	
		// Add the sort order
		$strSelectQuery		.= "ORDER BY " . $strSortOrder . " " . $strModifiedSortDirection . ", CharName";
	
		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
		<div id="Body">
		<table id="RosterTable" width="100%" border="0" cellpadding="0" cellspacing="0">
		';
	
		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex				= 0;
			$strCharName		= $aResult[$nIndex++];
			$strNameMain		= $aResult[$nIndex++];
			$nPoS_Askr_Quest	= $aResult[$nIndex++];
			$nPoV_Grenic_Quest	= $aResult[$nIndex++];
			$nPoV_AerinDar		= $aResult[$nIndex++];
			$nCoD_Carprin_Event	= $aResult[$nIndex++];
			$nCoD_Bertoxxulous	= $aResult[$nIndex++];
			$nPoTorment_Saryrn	= $aResult[$nIndex++];
			$nPoS_Wembly_Quest	= $aResult[$nIndex++];
			$nOldMember			= $aResult[$nIndex++];
	
			// Only show old members for the administrator
			if( ( $strCharName != "" ) &&
				( ( $nOldMember == 0 ) ||
				  ( IsAdministrator( $strUserName ) ) ) )
			{
				// Show the BoT Flag parts
				$this->ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nPoS_Askr_Quest, $nPoV_Grenic_Quest, $nPoV_AerinDar, $nCoD_Carprin_Event, $nCoD_Bertoxxulous, $nPoTorment_Saryrn, $nPoS_Wembly_Quest, $nOldMember, $strRowType );
		
				// Switch RowType, so the rows alternate	
				if( $strRowType == "OddRow" )
				{
					$strRowType	= "EvenRow";
				}
				else
				{
					$strRowType	= "OddRow";
				}
			}
		}
	
		// End the table
		echo '
		</table>
		</div>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );
	}
	
	
	
	// ========================================================================
	// Show a record
	// ========================================================================
	// This function will create a html table row for a record in the table
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// In:  Variables containing the data to show 
	// ========================================================================
	function ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nPoS_Askr_Quest, $nPoV_Grenic_Quest, $nPoV_AerinDar, $nCoD_Carprin_Event, $nCoD_Bertoxxulous, $nPoTorment_Saryrn, $nPoS_Wembly_Quest, $nOldMember, $strRowType )
	{
		// Declare variables
		$strImageCheck			= '<img src="images/check.gif" border="0" />';
		$strDeleteChar			= "";
		$strPoS_Askr_Quest		= "";
		$strPoV_Grenic_Quest	= "";
		$strPoV_AerinDar		= "";
		$strCoD_Carprin_Event	= "";
		$strCoD_Bertoxxulous	= "";
		$strPoTorment_Saryrn	= "";
		$strPoS_Wembly_Quest	= "";

		// Set the check-image for all filled variables
		if( $nPoS_Askr_Quest > 0 )		{	$strPoS_Askr_Quest		= $strImageCheck;	}
		if( $nPoV_Grenic_Quest > 0 )	{	$strPoV_Grenic_Quest	= $strImageCheck;	}
		if( $nPoV_AerinDar > 0 )		{	$strPoV_AerinDar		= $strImageCheck;	}
		if( $nCoD_Carprin_Event > 0 )	{	$strCoD_Carprin_Event	= $strImageCheck;	}
		if( $nCoD_Bertoxxulous > 0 )	{	$strCoD_Bertoxxulous	= $strImageCheck;	}
		if( $nPoTorment_Saryrn > 0 )	{	$strPoTorment_Saryrn	= $strImageCheck;	}
		if( $nPoS_Wembly_Quest > 0 )	{	$strPoS_Wembly_Quest	= $strImageCheck;	}
	
		// Check if it's an old member
		if( $nOldMember == 1 )
		{
			$strRowType		= "DeletedRow";

			// Allow the deletion of old members
			$strDeleteChar	= ' <a href="form.php?FormName=Character_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=PoP_Tier_2_Flags&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Delete ' . $strCharName . '\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Delete ' . $strCharName . '"><img src="images/delete.gif" border="0" /></a>';
		}
	
		// Check if this character belongs to the logged in User
		$strModify	= "";
		if( ( isset( $strUserName ) ) &&
			( isset( $strNameMain ) ) &&
			( $strUserName == $strNameMain ) )
		{
			$strModify	= '<a href="character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=PoP_Tier_2_Flags&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="images/modify.gif" border="0" />';
		}
		else if( IsAdministrator( $strUserName ) )
		{
			$strModify	= '<a href="character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=PoP_Tier_2_Flags&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="images/modify_others.gif" border="0" />';
		}
	
		echo '
		  <tr	onMouseOver="this.bgColor=\'' . GetRowHighLightColor() . '\'" onMouseOut="this.bgColor=\'\'">
			<td width= "5%" align="center">'				. $strModify			. '</td>
			<td width="18%" class="' . $strRowType . '">'	. $strCharName			. $strDeleteChar . '</td>
			<td width="11%" align="center">'				. $strPoS_Askr_Quest	. '</td>
			<td width="11%" align="center">'				. $strPoV_Grenic_Quest	. '</td>
			<td width="11%" align="center">'				. $strPoV_AerinDar		. '</td>
			<td width="11%" align="center">'				. $strCoD_Carprin_Event	. '</td>
			<td width="11%" align="center">'				. $strCoD_Bertoxxulous	. '</td>
			<td width="11%" align="center">'				. $strPoTorment_Saryrn	. '</td>
			<td width="11%" align="center">'				. $strPoS_Wembly_Quest	. '</td>
		  </tr>
		';
	}
}

?>
