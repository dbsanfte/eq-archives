<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );


// ============================================================================
// The Character Statistics class
// ============================================================================
// This class provides an interface to the statistics fiels in the Character table
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class Character_Statistics
{
	// Member variables
	var $bShowVerticalScrollbars	= true;
	// Max values
	var $nMaxHP						= 99999;
	var $nMaxMana					= 99999;
	var $nMaxAC						= 99999;
	var $nMaxFT						= 99999;
	var $nMaxRegen					= 99999;
	var $nMaxAtk					= 99999;
	var $nMaxStr					= 99999;
	var $nMaxSta					= 99999;
	var $nMaxAgi					= 99999;
	var $nMaxDex					= 99999;
	var $nMaxWis					= 99999;
	var $nMaxInt					= 99999;
	var $nMaxCha					= 99999;
	var $nMaxPR						= 99999;
	var $nMaxMR						= 99999;
	var $nMaxDR						= 99999;
	var $nMaxFR						= 99999;
	var $nMaxCR						= 99999;


	// ========================================================================
	// Constructor
	// ========================================================================
	function Character_Statistics()
	{
		// No code yet
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "Character Statistics";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		// Set the Show Alts variables
		if( $strShowAlts == "Yes" )
		{
			$strShowAltsToggled	= "No";
			$strShowAltsDesc	= "Hide Alts and Inactive characters";
			$strShowAltsImg		= '<img src="images/show_no_alts.gif" border="0" alt="' . $strShowAltsDesc . '" />';
		}
		else
		{
			$strShowAltsToggled	= "Yes";
			$strShowAltsDesc	= "Show Alts and Inactive characters";
			$strShowAltsImg		= '<img src="images/show_all.gif" border="0" alt="' . $strShowAltsDesc . '" />';
		}

		echo '
		<!-- Start of Header -->
		<div id="Header">
		<br />
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td width= "5%" align="center">	<b><a href="form.php?FormName=Character_Statistics&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAltsToggled .	'&SortOrder=' . $strSortOrder				. '&SortDirection=' . $strSortDirection										. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'' . $strShowAltsDesc . '\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="' . $strShowAltsDesc . '"	>' . $strShowAltsImg . '</a></b></td>
			<td width="11%">				<b><a href="form.php?FormName=Character_Statistics&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 			'&SortOrder=CharName&SortDirection='		. GetSortDirection( $strSortOrder, "CharName",			$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Name\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Name"						>Name</a></b></td>
			<td width= "2%" align="center">	<b><a href="form.php?FormName=Character_Statistics&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 			'&SortOrder=MageloNr&SortDirection='		. GetSortDirection( $strSortOrder, "MageloNr",			$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Magelo Nr.\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Magelo Nr."					><img src="images/magelo.gif" border="0" alt="MageloNr"></a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=Character_Statistics&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 			'&SortOrder=HP&SortDirection='				. GetSortDirection( $strSortOrder, "HP",				$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Hit Points\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Hit Points"					>HP</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=Character_Statistics&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 			'&SortOrder=Mana&SortDirection='			. GetSortDirection( $strSortOrder, "Mana",				$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Mana\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Mana"						>Mana</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=Character_Statistics&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 			'&SortOrder=AC&SortDirection='				. GetSortDirection( $strSortOrder, "AC",				$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Armor Class\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Armor Class"					>AC</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=Character_Statistics&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 			'&SortOrder=FlowingThought&SortDirection='	. GetSortDirection( $strSortOrder, "FlowingThought",	$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Flowing Thought\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Flowing Thought"				>FT</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=Character_Statistics&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 			'&SortOrder=Regen&SortDirection='			. GetSortDirection( $strSortOrder, "Regen",				$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Regen\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Regen"						>Regen</a></b></td>
			<td width= "4%" align="center">	<b><a href="form.php?FormName=Character_Statistics&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 			'&SortOrder=Atk&SortDirection='				. GetSortDirection( $strSortOrder, "Atk",				$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Attack\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Attack"						>Atk</a></b></td>
			<td width= "4%" align="center">	<b><a href="form.php?FormName=Character_Statistics&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 			'&SortOrder=Str&SortDirection='				. GetSortDirection( $strSortOrder, "Str",				$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Strength\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Strength"					>Str</a></b></td>
			<td width= "4%" align="center">	<b><a href="form.php?FormName=Character_Statistics&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 			'&SortOrder=Sta&SortDirection='				. GetSortDirection( $strSortOrder, "Sta",				$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Stamina\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Stamina"						>Sta</a></b></td>
			<td width= "4%" align="center">	<b><a href="form.php?FormName=Character_Statistics&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 			'&SortOrder=Agi&SortDirection='				. GetSortDirection( $strSortOrder, "Agi",				$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Agility\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Agility"						>Agi</a></b></td>
			<td width= "4%" align="center">	<b><a href="form.php?FormName=Character_Statistics&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 			'&SortOrder=Dex&SortDirection='				. GetSortDirection( $strSortOrder, "Dex",				$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Dexterty\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Dexterty"					>Dex</a></b></td>
			<td width= "4%" align="center">	<b><a href="form.php?FormName=Character_Statistics&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 			'&SortOrder=Wis&SortDirection='				. GetSortDirection( $strSortOrder, "Wis",				$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Wisdom\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Wisdom"						>Wis</a></b></td>
			<td width= "4%" align="center">	<b><a href="form.php?FormName=Character_Statistics&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 			'&SortOrder=Int&SortDirection='				. GetSortDirection( $strSortOrder, "Int",				$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Intelligence\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Intelligence"				>Int</a></b></td>
			<td width= "4%" align="center">	<b><a href="form.php?FormName=Character_Statistics&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 			'&SortOrder=Cha&SortDirection='				. GetSortDirection( $strSortOrder, "Cha",				$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Charisma\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Charisma"					>Cha</a></b></td>
			<td width= "4%" align="center">	<b><a href="form.php?FormName=Character_Statistics&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 			'&SortOrder=PR&SortDirection='				. GetSortDirection( $strSortOrder, "PR",				$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Posion Resist\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Posion Resist"				>PR</a></b></td>
			<td width= "4%" align="center">	<b><a href="form.php?FormName=Character_Statistics&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 			'&SortOrder=MR&SortDirection='				. GetSortDirection( $strSortOrder, "MR",				$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Magic Resist\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Magic Resist"				>MR</a></b></td>
			<td width= "4%" align="center">	<b><a href="form.php?FormName=Character_Statistics&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 			'&SortOrder=DR&SortDirection='				. GetSortDirection( $strSortOrder, "DR",				$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Disease Resist\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Disease Resist"				>DR</a></b></td>
			<td width= "4%" align="center">	<b><a href="form.php?FormName=Character_Statistics&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 			'&SortOrder=FR&SortDirection='				. GetSortDirection( $strSortOrder, "FR",				$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Fire Resist\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Fire Resist"					>FR</a></b></td>
			<td width= "4%" align="center">	<b><a href="form.php?FormName=Character_Statistics&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 			'&SortOrder=CR&SortDirection='				. GetSortDirection( $strSortOrder, "CR",				$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Cold Resist\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Cold Resist"					>CR</a></b></td>
		  </tr>
		</table>
		</div>
		<!-- End of Header -->
		';
	}
	
	
	
	// ========================================================================
	// Show all the records on screen
	// ========================================================================
	// This function will loop through all the records in the database table,
	// and create a html table entry for each one of them.
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS		= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];
		$strClassFilter		= $_GET['ClassFilter'];

		// Declare variables
		$bAdministrator		= IsAdministrator( $strUserName );
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT CharName, NameMain, MageloNr, HP, Mana, AC, FlowingThought, Regen, Atk, Str, Sta, Agi, Dex, Wis, `Int`, Cha, PR, MR, DR, FR, CR, OldMember \n" .
							  "FROM Characters \n" .
							  "WHERE (	HP > 0				OR \n" .
							  "			Mana > 0			OR \n" .
							  "			AC > 0				OR \n" .
							  "			FlowingThought > 0	OR \n" .
							  "			Regen > 0			OR \n" .
							  "			Atk > 0				OR \n" .
							  "			Str > 0				OR \n" .
							  "			Sta > 0				OR \n" .
							  "			Agi > 0				OR \n" .
							  "			Dex > 0				OR \n" .
							  "			Wis > 0				OR \n" .
							  "			`Int` > 0			OR \n" .
							  "			Cha > 0				OR \n" .
							  "			PR > 0				OR \n" .
							  "			MR > 0				OR \n" .
							  "			DR > 0				OR \n" .
							  "			FR > 0				OR \n" .
							  "			CR > 0				) \n";
		$strSelectMaxQuery	= "SELECT MAX(HP), MAX(Mana), MAX(AC), MAX(FlowingThought), MAX(Regen), MAX(Atk), MAX(Str), MAX(Sta), MAX(Agi), MAX(Dex), MAX(Wis), MAX(`Int`), MAX(Cha), MAX(PR), MAX(MR), MAX(DR), MAX(FR), MAX(CR) \n" .
							  "FROM Characters WHERE OldMember = 0 \n";

		// Check if we should show alts
		if( $strShowAlts != "Yes" )
		{
			$strSelectQuery	.= "AND ((GuildStatus != 'Alt' AND GuildStatus != 'Inactive') OR NameMain = '" . $strUserName . "') \n";
		}
		
		// Check if we should set a class filter
		if( ( isset( $strClassFilter ) ) &&
			( $strClassFilter != "" ) &&
			( $strClassFilter != "<<All>>" ) )
		{
			$strSelectQuery	.= "AND Class = '" . $strClassFilter . "'";
		} 

		// Check if we should use the default sort order
		if( ( !isset( $strSortOrder ) ) ||
			( $strSortOrder == "" ) )
		{
			// Default sort on Character name
			$strSortOrder	= "CharName"; 
		}

		// Sorting on Level, AA, GLP, MageloNr, LastOn and E-Mail Address should be reversed (Desc first, then Asc)
		$strModifiedSortDirection	= $strSortDirection;

		if( $strSortOrder != "CharName" )
		{
			// Switch the sort order around
			if( $strModifiedSortDirection == "DESC" )
			{
				$strModifiedSortDirection	= "";
			}
			else
			{
				$strModifiedSortDirection	= "DESC";
			}
		}
	
		// Add the sort order
		$strSelectQuery		.= "ORDER BY '" . $strSortOrder . "' " . $strModifiedSortDirection . ", CharName \n";
	
		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
		<div id="Body">
		<table id="RosterTable" width="100%" border="0" cellpadding="0" cellspacing="0">
		';
	
		// Retrieve all the maximum values
		$nResult	= mysql_query( $strSelectMaxQuery, $nLinkID );
		// Store the values
	    if( $aResult = mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex				= 0;
			$this->nMaxHP		= $aResult[$nIndex++];
			$this->nMaxMana		= $aResult[$nIndex++];
			$this->nMaxAC		= $aResult[$nIndex++];
			$this->nMaxFT		= $aResult[$nIndex++];
			$this->nMaxRegen	= $aResult[$nIndex++];
			$this->nMaxAtk		= $aResult[$nIndex++];
			$this->nMaxStr		= $aResult[$nIndex++];
			$this->nMaxSta		= $aResult[$nIndex++];
			$this->nMaxAgi		= $aResult[$nIndex++];
			$this->nMaxDex		= $aResult[$nIndex++];
			$this->nMaxWis		= $aResult[$nIndex++];
			$this->nMaxInt		= $aResult[$nIndex++];
			$this->nMaxCha		= $aResult[$nIndex++];
			$this->nMaxPR		= $aResult[$nIndex++];
			$this->nMaxMR		= $aResult[$nIndex++];
			$this->nMaxDR		= $aResult[$nIndex++];
			$this->nMaxFR		= $aResult[$nIndex++];
			$this->nMaxCR		= $aResult[$nIndex++];
		}

		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex			= 0;
			$strCharName	= $aResult[$nIndex++];
			$strNameMain	= $aResult[$nIndex++];
			$nMageloNr		= $aResult[$nIndex++];
			$nHP			= $aResult[$nIndex++];
			$nMana			= $aResult[$nIndex++];
			$nAC			= $aResult[$nIndex++];
			$nFT			= $aResult[$nIndex++];
			$nRegen			= $aResult[$nIndex++];
			$nAtk			= $aResult[$nIndex++];
			$nStr			= $aResult[$nIndex++];
			$nSta			= $aResult[$nIndex++];
			$nAgi			= $aResult[$nIndex++];
			$nDex			= $aResult[$nIndex++];
			$nWis			= $aResult[$nIndex++];
			$nInt			= $aResult[$nIndex++];
			$nCha			= $aResult[$nIndex++];
			$nPR			= $aResult[$nIndex++];
			$nMR			= $aResult[$nIndex++];
			$nDR			= $aResult[$nIndex++];
			$nFR			= $aResult[$nIndex++];
			$nCR			= $aResult[$nIndex++];
			$nOldMember		= $aResult[$nIndex++];

			// Only show old members for the administrator
			if( ( $nOldMember == 0 ) ||
				( $bAdministrator == true ) )
			{
				// Show the character
				$this->ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter, $strOwnerName, $strCharName, $strNameMain, $nMageloNr, $nHP, $nMana, $nAC, $nFT, $nRegen, $nAtk, $nStr, $nSta, $nAgi, $nDex, $nWis, $nInt, $nCha, $nPR, $nMR, $nDR, $nFR, $nCR, $nOldMember, $strRowType, $bAdministrator );
	
				// Switch RowType, so the rows alternate	
				if( $strRowType == "OddRow" )
				{
					$strRowType	= "EvenRow";
				}
				else
				{
					$strRowType	= "OddRow";
				}
			}
		}
	
		// End the character table
		echo '
		</table>
		</div>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );
	}
	
	
	
	// ========================================================================
	// Show a record
	// ========================================================================
	// This function will create a html table row for a record in the table
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// In:  Variables containing the data to show 
	// ========================================================================
	function ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter, $strOwnerName, $strCharName, $strNameMain, $nMageloNr, $nHP, $nMana, $nAC, $nFT, $nRegen, $nAtk, $nStr, $nSta, $nAgi, $nDex, $nWis, $nInt, $nCha, $nPR, $nMR, $nDR, $nFR, $nCR, $nOldMember, $strRowType, $bAdministrator )
	{
		// Declare variables
		$strDeleteChar		= "";

		// Check if it's an old member
		if( $nOldMember == 1 )
		{
			$strRowType			= "DeletedRow";

			// Allow the deletion of old members
			$strDeleteChar		= ' <a href="form.php?FormName=Character_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=Character_Statistics&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Delete ' . $strCharName . '\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Delete ' . $strCharName . '"><img src="images/delete.gif" border="0" /></a>';
		}

		// Check if magelo nr is filled in
		$strFullMagelo		= '';
		if( ( isset( $nMageloNr ) ) &&
			( $nMageloNr > 0 ) )
		{
			$strFullMagelo	= '<a href="http://www.magelo.com/eq_view_profile.html?num=' . $nMageloNr . '"	OnMouseOver="window.status=\'Show ' . $strCharName . '\\\'s magelo\';return true;"	OnMouseOut="window.status=\'\'"	target="_blank" title="Show ' . $strCharName . '\'s magelo"><img src="images/magelo.gif" border="0" />';
		}

		// Check if this character belongs to the logged in User
		$strModify	= "";
		if( ( isset( $strUserName ) ) &&
			( isset( $strNameMain ) ) &&
			( $strUserName == $strNameMain ) )
		{
			$strModify	= '<a href="character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=Character_Statistics&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="images/modify.gif" border="0" /></a>';
		}
		else if( $bAdministrator == true )
		{
			$strModify	= '<a href="character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=Character_Statistics&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="images/modify_others.gif" border="0" /></a>';
		}

		echo '
		  <tr	onMouseOver="this.bgColor=\'' . GetRowHighLightColor() . '\'" onMouseOut="this.bgColor=\'\'">
			<td width= "5%" align="center">'																					. $strModify		. '</td>
			<td width="11%" class="' . $strRowType . '">'																		. $strCharName		. $strDeleteChar . '</td>
			<td width= "2%" class="' . $strRowType . '" align="center">'														. $strFullMagelo	. '</td>
			<td width= "6%" class="' . $this->GetCellClass( $nHP, $this->nMaxHP, $strRowType )			. '" align="center">'	. $nHP				. '</td>
			<td width= "6%" class="' . $this->GetCellClass( $nMana, $this->nMaxMana, $strRowType )		. '" align="center">'	. $nMana			. '</td>
			<td width= "6%" class="' . $this->GetCellClass( $nAC, $this->nMaxAC, $strRowType )			. '" align="center">'	. $nAC				. '</td>
			<td width= "6%" class="' . $this->GetCellClass( $nFT, $this->nMaxFT, $strRowType )			. '" align="center">'	. $nFT				. '</td>
			<td width= "6%" class="' . $this->GetCellClass( $nRegen, $this->nMaxRegen, $strRowType )	. '" align="center">'	. $nRegen			. '</td>
			<td width= "4%" class="' . $this->GetCellClass( $nAtk, $this->nMaxAtk, $strRowType )		. '" align="center">'	. $nAtk				. '</td>
			<td width= "4%" class="' . $this->GetCellClass( $nStr, $this->nMaxStr, $strRowType )		. '" align="center">'	. $nStr				. '</td>
			<td width= "4%" class="' . $this->GetCellClass( $nSta, $this->nMaxSta, $strRowType )		. '" align="center">'	. $nSta				. '</td>
			<td width= "4%" class="' . $this->GetCellClass( $nAgi, $this->nMaxAgi, $strRowType )		. '" align="center">'	. $nAgi				. '</td>
			<td width= "4%" class="' . $this->GetCellClass( $nDex, $this->nMaxDex, $strRowType )		. '" align="center">'	. $nDex				. '</td>
			<td width= "4%" class="' . $this->GetCellClass( $nWis, $this->nMaxWis, $strRowType )		. '" align="center">'	. $nWis				. '</td>
			<td width= "4%" class="' . $this->GetCellClass( $nInt, $this->nMaxInt, $strRowType )		. '" align="center">'	. $nInt				. '</td>
			<td width= "4%" class="' . $this->GetCellClass( $nCha, $this->nMaxCha, $strRowType )		. '" align="center">'	. $nCha				. '</td>
			<td width= "4%" class="' . $this->GetCellClass( $nPR, $this->nMaxPR, $strRowType )			. '" align="center">'	. $nPR				. '</td>
			<td width= "4%" class="' . $this->GetCellClass( $nMR, $this->nMaxMR, $strRowType )			. '" align="center">'	. $nMR				. '</td>
			<td width= "4%" class="' . $this->GetCellClass( $nDR, $this->nMaxDR, $strRowType )			. '" align="center">'	. $nDR				. '</td>
			<td width= "4%" class="' . $this->GetCellClass( $nFR, $this->nMaxFR, $strRowType )			. '" align="center">'	. $nFR				. '</td>
			<td width= "4%" class="' . $this->GetCellClass( $nCR, $this->nMaxCR, $strRowType )			. '" align="center">'	. $nCR				. '</td>
		  </tr>
		';
	}



	// ========================================================================
	// Get the font color for a statistic
	// ========================================================================
	// This function will determine (and return) the font color for a skill
	// All highest skills will receive a different color.
	// ========================================================================
	// In:	$nValue			= Value of skill
	// In:	$nMaxValue		= Max Value for the category
	// In:	$strRowType		= Default RowType
	// Out:	RowType to use
	// ========================================================================
	function GetCellClass( $nValue, $nMaxValue, $strRowType )
	{
		// If the tradeskill has a high value
		if( $nValue >= $nMaxValue )
		{
			// Check which RowType was in use
			if( $strRowType == "EvenRow" )
			{
				return "EvenRowHighSkill";
			}
			else if( $strRowType == "OddRow" )
			{
				return "OddRowHighSkill";
			}
		}
		// Otherwise return the defautl font color
		return $strRowType;
	}
}

?>
