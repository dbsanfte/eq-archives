<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );


// ============================================================================
// The Users class
// ============================================================================
// This class handles the Characters_Delete procedure
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class Characters_Delete
{

	// ========================================================================
	// Constructor
	// ========================================================================
	function Characters_Delete()
	{
		// No code yet
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "Characters Delete";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<font size="-3"><br /></font>
		<center><b><font size="+2" color="#FF3300">
		  Delete characters...
		</font></b></center>
		<!-- End of Header -->
		';
	}
	
	
	
	// ========================================================================
	// Show the body
	// ========================================================================
	// This function will show the characters delete page
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS	= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$bPerformDelete		= $_GET['cbPerformDelete'];
		$strClassFilter		= $_GET['ClassFilter'];
		$nDeletedChars		= 0;
		$aCharacters[0]		= "";

		// Check if the UserName is an admin
		if( ( isset( $strUserName ) ) &&
			( $strUserName != "" ) && 
			( IsAdministrator( $strUserName ) ) )
		{
			// Check if the user clicked delete
			if( ( isset( $bPerformDelete ) ) &&
				( $bPerformDelete == "true" ) )
			{
				// Loop through the array with VARS to find the check boxes
				foreach( $aHTTP_GET_VARS as $strVarName => $strValue )
				{
					// Check if it's a delete checkbox
					if( substr( $strVarName, 0, 8 ) == "cbDelete" )
					{
						// Check if the checkbox was clicked
						if( $strValue == true )
						{
							// Delete this char
							$aCharacters[$nDeletedChars]	= substr( $strVarName, 8 );

							// Raise the nr of deleted chars
							$nDeletedChars++;
						}
					}
				}

				// Check if any chars where deleted
				if( $nDeletedChars > 0 )
				{
					// Delete the character
					$this->DeleteCharacters( $strUserName, $strPassword, $aCharacters );
				}
				else
				{
					// Show a message telling the user to select some chars first
					echo'
					<center>Select some characters before pressing Delete.</center><br />
					';

					// Show the delete characters page
					$this->ShowCharactersDeletePage( $strUserName, $strPassword, $bPerformDelete, $strClassFilter );
				}
			}
			else
			{
				// Show the delete characters page
				$this->ShowCharactersDeletePage( $strUserName, $strPassword, $bPerformDelete, $strClassFilter );
			}
		}
		else
		{
			// Show error
			print( "Only administators can delete characters..." );
		}
	}
	
	
	
	// ========================================================================
	// Delete a character
	// ========================================================================
	function DeleteCharacters( $strUserName, $strPassword, $aCharacters )
	{
		// Declare variables
		$strRowType	= "EvenRow";

		// Start the form
		echo '
		<form name="formDeletingCharacters" method="post" action="form.php?FormName=Characters&UserName=' . $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '&CookieAction=READ" target=Body>
		  <div id="Body" align="center">
		    <br />
			<table id="RosterTable" width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width= "1%"></td>
				<td width="14%" class="HeaderRow">Name<br /><hr /></td>
				<td width= "7%" class="HeaderRow" align="center">Chars<br /><hr /></td>
				<td width= "7%" class="HeaderRow" align="center">T-Skills<br /><hr /></td>
				<td width= "7%" class="HeaderRow" align="center">Keys<br /><hr /></td>
				<td width= "7%" class="HeaderRow" align="center">PoS<br /><hr /></td>
				<td width= "7%" class="HeaderRow" align="center">SSRA<br /><hr /></td>
				<td width= "7%" class="HeaderRow" align="center">VP<br /><hr /></td>
				<td width= "7%" class="HeaderRow" align="center">VT<br /><hr /></td>
				<td width= "7%" class="HeaderRow" align="center">PoP 1<br /><hr /></td>
				<td width= "7%" class="HeaderRow" align="center">PoP 2<br /><hr /></td>
				<td width= "7%" class="HeaderRow" align="center">PoP 3<br /><hr /></td>
				<td width= "7%" class="HeaderRow" align="center">PoP 4<br /><hr /></td>
				<td width= "7%" class="HeaderRow" align="center">GoD<br /><hr /></td>
				<td width= "1%"></td>
			  </tr>
		';		

		// Loop through the array with VARS to find the check boxes
		foreach( $aCharacters as $strCharName )
		{
			// Start a new table row
			echo'
			  <tr	onMouseOver="this.bgColor=\'' . GetRowHighLightColor() . '\'" onMouseOut="this.bgColor=\'\'">
				<td width= "1%"></td>
				<td width="14%" class="' . $strRowType . '">' . $strCharName . '</td>
			';

			// Get the CharID
			$nCharID	= $this->GetCharID( $strCharName );
			if( $nCharID > 0 )
			{
				// Delete the character
				$this->DeleteCharacterRecord( 'Characters', $nCharID );
				// Delete the Tradeskill record
				$this->DeleteCharacterRecord( 'TradeSkills', $nCharID );
				// Delete the Keys record
				$this->DeleteCharacterRecord( 'Keys', $nCharID );
				// Delete the PoS_Askr_Quest record
				$this->DeleteCharacterRecord( 'PoS_Askr_Quest', $nCharID );
				// Delete the SSRA_Emperor_Key record
				$this->DeleteCharacterRecord( 'SSRA_Emperor_Key', $nCharID );
				// Delete the Veeshans_Peak_Key record
				$this->DeleteCharacterRecord( 'Veeshans_Peak_Key', $nCharID );
				// Delete the Vex_Thal_Key record
				$this->DeleteCharacterRecord( 'Vex_Thal_Key', $nCharID );
				// Delete the Pop Tier 1 Flags record
				$this->DeleteCharacterRecord( 'PoP_Tier_1_Flags', $nCharID );
				// Delete the Pop Tier 2 Flags record
				$this->DeleteCharacterRecord( 'PoP_Tier_2_Flags', $nCharID );
				// Delete the Pop Tier 3 Flags record
				$this->DeleteCharacterRecord( 'PoP_Tier_3_Flags', $nCharID );
				// Delete the Pop Tier 4 Flags record
				$this->DeleteCharacterRecord( 'PoP_Tier_4_Flags', $nCharID );
				// Delete the GoD Flags record
				$this->DeleteCharacterRecord( 'GoD_Flags', $nCharID );
			}
			else
			{
				echo '<td width= "7%" align="center"><img src="images/delete.gif" border="0" /></td>
				';
				echo '<td width= "7%" align="center"><img src="images/delete.gif" border="0" /></td>
				';
				echo '<td width= "7%" align="center"><img src="images/delete.gif" border="0" /></td>
				';
				echo '<td width= "7%" align="center"><img src="images/delete.gif" border="0" /></td>
				';
				echo '<td width= "7%" align="center"><img src="images/delete.gif" border="0" /></td>
				';
				echo '<td width= "7%" align="center"><img src="images/delete.gif" border="0" /></td>
				';
				echo '<td width= "7%" align="center"><img src="images/delete.gif" border="0" /></td>
				';
				echo '<td width= "7%" align="center"><img src="images/delete.gif" border="0" /></td>
				';
				echo '<td width= "7%" align="center"><img src="images/delete.gif" border="0" /></td>
				';
				echo '<td width= "7%" align="center"><img src="images/delete.gif" border="0" /></td>
				';
				echo '<td width= "7%" align="center"><img src="images/delete.gif" border="0" /></td>
				';
				echo '<td width= "7%" align="center"><img src="images/delete.gif" border="0" /></td>
				';
			}

			// End the table row
			echo'
				<td width= "1%"></td>
			  </tr>
			';

			// Switch RowType, so the rows alternate	
			if( $strRowType == "OddRow" )
			{
				$strRowType	= "EvenRow";
			}
			else
			{
				$strRowType	= "OddRow";
			}
		}

		// Close the form
		echo '
			  <tr>
				<td width= "1%"></td>
				<td width="14%"><hr /></td>
				<td width= "7%" align="center"><hr /></td>
				<td width= "7%" align="center"><hr /></td>
				<td width= "7%" align="center"><hr /></td>
				<td width= "7%" align="center"><hr /></td>
				<td width= "7%" align="center"><hr /></td>
				<td width= "7%" align="center"><hr /></td>
				<td width= "7%" align="center"><hr /></td>
				<td width= "7%" align="center"><hr /></td>
				<td width= "7%" align="center"><hr /></td>
				<td width= "7%" align="center"><hr /></td>
				<td width= "7%" align="center"><hr /></td>
				<td width= "7%" align="center"><hr /></td>
				<td width= "1%"></td>
			  </tr>
			</table>

			<br />
			' . count( $aCharacters ) . ' characters deleted.<br />
			<br />
		    <input type="submit" name="pbDone" value="Done">
		  </div>
		</form>
		';
	}



	// ========================================================================
	// Get a character's CharID
	// ========================================================================
	function GetCharID( $strCharName )
	{
		// Declare variables
		$nCharID		= -1;
		$strSelectQuery	= "SELECT CharID FROM Characters WHERE CharName = '$strCharName'";

		// Connect to the database
		$nLinkID		= DBConnect();

		// Retrieve the CharID for this character
		$nResult		= mysql_query( $strSelectQuery, $nLinkID );
		$aResult		= mysql_fetch_row( $nResult );
		// Store the CharID
		if( isset( $aResult[0] ) )
		{
			$nCharID	= $aResult[0];
		}

		// Close the connection
		DBDisconnect( $nLinkID );

		return $nCharID;
	}



	// ========================================================================
	// Delete a character record from a table
	// ========================================================================
	function DeleteCharacterRecord( $strTableName, $nCharID )
	{
		// Connect to the database
		$nLinkID		= DBConnect();
		$nNrOfRecords	= 0;

		// Declare variables
		$strDeleteQuery	= "DELETE FROM `$strTableName` WHERE CharID = '$nCharID'";
		// Delete the record
		$nResult		= mysql_query( $strDeleteQuery, $nLinkID );

		// Start the table cell
		echo '<td width="7%" align="center">';

		// Check if the delete was succesfull
		if( $nResult == 1 )
		{
			// Check ho wmany rows where deleted
			if( mysql_affected_rows() == 1 )
			{
				echo '<img src="images/check.gif" border="0" />';
			}
			else if( mysql_affected_rows() == 0 )
			{
				// new image?
			}
			else
			{
				echo '<img src="images/check.gif" border="0" />';
			}
		}
		else
		{
			echo '<img src="images/delete.gif" border="0" OnMouseOver="window.status=\'' . mysql_error() . '\';return true;"	OnMouseOut="window.status=\'\'" />';
			// Show error message
//			print( "			<font color=\"#FF3300\">\"$strTableName\" record delete FAILED!<br /></font>\n" );
//			print( "			$strDeleteQuery<br />\n" );
//			print( "			" . mysql_error() . "<br />\n" );
		}

		// End the table cell
		echo '</td>';
	
		// Close the connection
		DBDisconnect( $nLinkID );
	
		return $nCharID;
	}



	// ========================================================================
	// Show the characters delete page
	// ========================================================================
	function ShowCharactersDeletePage( $strUserName, $strPassword, $bPerformDelete, $strClassFilter )
	{
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT CharName, LastName, NameMain, Class, Level \n" .
							  " FROM Characters \n" .
							  " WHERE OldMember = 1 \n" .
							  " ORDER BY CharName ";
		$nNrOfOldMembers	= 0;

		echo '
		<!-- JavaScript block has been added here instead of in the header on purpose -->
		<script language="JavaScript">

		<!-- Perform the Delete -->
		function PerformDelete()
		{
			// Declare variables
			var aControls		= document.getElementsByTagName( "input" )
			var nNrOfCharacters	= 0;

			// Loop through each checkbox in the array
			for( var nControl = 0; nControl < aControls.length; nControl++ )
			{
				// Check if it is a checkbox
				if( ( aControls[nControl].type == "checkbox" ) &&
					( aControls[nControl].checked == true ) )
				{
					nNrOfCharacters++;
				}
			}

			// Check if any characters are marked for deletion
			if( nNrOfCharacters > 0 )
			{
				// Validation complete, all fields are valid
				document.formDeleteCharacters.cbPerformDelete.value		= true;
				document.formDeleteCharacters.cbPerformDelete.checked	= true;

				// submit the form				
				document.formDeleteCharacters.submit();
			}
			else
			{
				// Show warning
				alert( "You must select some characters first..." );
			}
		};


		// Toggle the value of a checkbox when it is clicked
		function ClickCheckBox( cbClicked )
		{
			// Validation complete, all fields are valid
			cbClicked.value	= cbClicked.checked;
		};


		// Set all checkboxes ON (bChecked = true) or OFF (bChecked = false)
		function SetAllCheckBoxes( bChecked )
		{
			// Declare variables
			var aControls		= document.getElementsByTagName( "input" )
			var objControl		= null;
			var strControlName	= "";

			// Loop through each checkbox in the array
			for( var nControl = 0; nControl < aControls.length; nControl++ )
			{
				// Check if it is a checkbox
				if( ( aControls[nControl].type == "checkbox" ) &&
					( ((aControls[nControl].name).match( "cbDelete" )).length > 0 ) )
				{
					// turn the checkbox on
					aControls[nControl].value	= bChecked;
					aControls[nControl].checked	= bChecked;
				}
			}
		};
		
		</script>


		<form name="formDeleteCharacters" method="post" action="form.php?FormName=Characters_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&PreviousForm=' . $strPreviousForm . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&ClassFilter=' . $strClassFilter . '" target=Body>
		  <br />
		  <div id="Body" align="center"> 
		';

		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
			<table id="RosterTable" width="60%" border="0" cellpadding="0" cellspacing="0">
		';

		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex				= 0;
			$strCharName		= $aResult[$nIndex++];
			$strLastName		= $aResult[$nIndex++];
			$strNameMain		= $aResult[$nIndex++];
			$strClass			= $aResult[$nIndex++];
			$nLevel				= $aResult[$nIndex++];
	
			// Check if the last name is filled
			$strFullName	= $strCharName;
			if( isset( $strLastName ) )
			{
				$strFullName	.=  " " . $strLastName;
			}

			echo'
			  <tr	onMouseOver="this.bgColor=\'' . GetRowHighLightColor() . '\'" onMouseOut="this.bgColor=\'\'">
				<td width="10%"></td>
				<td width="5%" class="' . $strRowType . '" align="center"><input name="cbDelete' . $strCharName . '" type="checkbox" id="cbDelete' . $strCharName . '" value="false" onClick="ClickCheckBox(this);">
				<td width="20%" class="' . $strRowType . '">' . $strFullName . '</td>
				<td width="25%" class="' . $strRowType . '">Level ' . $nLevel . ' ' . $strClass . '</td>
			  </tr>
			';

			// Switch RowType, so the rows alternate	
			if( $strRowType == "OddRow" )
			{
				$strRowType	= "EvenRow";
			}
			else
			{
				$strRowType	= "OddRow";
			}
			
			// Raise the OldMember counter
			$nNrOfOldMembers++;
		}
	
		// End the character table
		echo '
			</table>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );

		// Print the end of the page
		if( $nNrOfOldMembers > 0 )
		{
			echo '
			<br />
			<input type="button" name="pbDeselectAllCharacters" value="Select None" onclick="SetAllCheckBoxes( false );">
			<input type="button" name="pbSelectAllCharacters"   value="Select All"  onclick="SetAllCheckBoxes( true );">
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		    <input type="button" name="pbDelete"                value="Delete"      onclick="PerformDelete();">
		    <!-- Hidden field to store Delete status -->
	        <input name="cbPerformDelete" type="hidden" id="cbPerformDelete" value="' . $bPerformDelete . '">
	        ';
	    }
	    else
	    {
			echo '
			<br />
			<br />
			<center><font size=+2 color="#FF3300">
			No old characters present on the roster.
			</font></center>
			';
	    }
	    
	    echo '
		  </div>
		</form>
		';
	}

}

?>
