<?php
////////////////////////////////////////////////////////////////////////////////
//
//	Author:	Micha�l Schoonbrood
//	Date:	Oktober 6, 2006
//
//	Description:
//	This script provides some default database functions that are used in the EQRoster
//
//	Usage:
//	Add the following line under the "<?php" tag:
//	require_once( './includes/functions_database.inc' );
//
////////////////////////////////////////////////////////////////////////////////

// Includes
require_once( './config.php' );



// =============================================================================
// Update a character
// =============================================================================
// Out:	$nCharID	= The CharID of the updated record
function UpdateCharacter( $strCharName, $strLastName, $strNameMain, $strGuildStatus, $nAA, $nGLP, $strRace, $strGender, $nMageloNr, $nHP, $nMana, $nAC, $nFT, $nRegen, $nAtk, $nStr, $nSta, $nAgi, $nDex, $nWis, $nInt, $nCha, $nPR, $nMR, $nDR, $nFR, $nCR )
{
	// Make sure all parameters have a value
	if( !isset( $nAA ) )	{ $nAA	= 0; }
	if( !isset( $nGLP ) )	{ $nGLP	= 0; }

	// Declare variables
	$nUserID				= -1;
	$nCharID				= -1;
	$strSelectUserIDQuery	= "SELECT UserID FROM Users WHERE UserName = '$strNameMain'";
	$strSelectCharIDQuery	= "SELECT CharID FROM Characters WHERE CharName = '$strCharName'";

	// Connect to the database
	$nLinkID	= DBConnect();

	// Retrieve the UserID for this user
	$nResult	= mysql_query( $strSelectUserIDQuery, $nLinkID );
	$aResult	= mysql_fetch_row( $nResult );
	// Store the UserID
	if( isset( $aResult[0] ) )
	{
		$nUserID	= $aResult[0];
	}

	// Define the Update statement
	$strUpdateQuery			= "UPDATE Characters \n" .
	                          "SET LastName       = '$strLastName', \n" .
	                          "    NameMain       = '$strNameMain', \n" .
	                          "    GuildStatus    = '$strGuildStatus', \n" .
							  "    AA             = '$nAA', \n" .
							  "    GLP            = '$nGLP', \n" .
							  "    Race           = '$strRace', \n" .
							  "    Gender         = '$strGender', \n" .
							  "    MageloNr       = '$nMageloNr', \n" .
							  "    UserID         = '$nUserID', \n" .
							  "    HP             = '$nHP', \n" .
							  "    Mana           = '$nMana', \n" .
							  "    AC             = '$nAC', \n" .
							  "    FlowingThought = '$nFT', \n" .
							  "    Regen          = '$nRegen', \n" .
							  "    Atk            = '$nAtk', \n" .
							  "    Str            = '$nStr', \n" .
							  "    Sta            = '$nSta', \n" .
							  "    Agi            = '$nAgi', \n" .
							  "    Dex            = '$nDex', \n" .
							  "    Wis            = '$nWis', \n" .
							  "    `Int`          = '$nInt', \n" .
							  "    Cha            = '$nCha', \n" .
							  "    PR             = '$nPR', \n" .
							  "    MR             = '$nMR', \n" .
							  "    DR             = '$nDR', \n" .
							  "    FR             = '$nFR', \n" .
							  "    CR             = '$nCR' \n" .
							  "WHERE CharName = '$strCharName'";
	// Update the character
	$nResult	= mysql_query( $strUpdateQuery, $nLinkID );
	// Check if the update was succesfull
	if( $nResult == 1 )
	{
		// Retrieve the CharID for this character
		$nResult	= mysql_query( $strSelectCharIDQuery, $nLinkID );
		$aResult	= mysql_fetch_row( $nResult );
		// Store the CharID
		if( isset( $aResult[0] ) )
		{
			$nCharID	= $aResult[0];
		}
		else
		{
			print( "	<font color=\"#FF3300\"><a>Update Succeeded, but no CharID found for Char " . $strCharName . " FAILED!<br /></a></font>\n" );
		}
	}
	else
	{
		// Show error message
		print( "	<font color=\"#FF3300\"><a>Update Char " . $strCharName . " FAILED!<br /></a></font>\n" );
		print( "    $strUpdateQuery<br />\n" );
		print( "    " . mysql_error() . "<br />\n" );
	}

	// Close the connection
	DBDisconnect( $nLinkID );

	return $nCharID;
}



// =============================================================================
// Update Tradeskills
// =============================================================================
function UpdateTradeskills( $nCharID, $strCharName, $nAlchemy, $nBaking, $nBrewing, $nFishing, $nFletching, $nForaging, $nJewelcraft, $nPoison, $nPottery, $nResearch, $nSmithing, $nTailoring, $nTinkering )
{
	// Make sure all parameters have a value
	if( !isset( $nAlchemy ) )		{ $nAlchemy		= 0; }
	if( !isset( $nBaking ) )		{ $nBaking		= 0; }
	if( !isset( $nBrewing ) )		{ $nBrewing		= 0; }
	if( !isset( $nFishing ) )		{ $nFishing		= 0; }
	if( !isset( $nFletching ) )		{ $nFletching	= 0; }
	if( !isset( $nForaging ) )		{ $nForaging	= 0; }
	if( !isset( $nJewelcraft ) )	{ $nJewelcraft	= 0; }
	if( !isset( $nPoison ) )		{ $nPoison		= 0; }
	if( !isset( $nPottery ) )		{ $nPottery		= 0; }
	if( !isset( $nResearch ) )		{ $nResearch	= 0; }
	if( !isset( $nSmithing ) )		{ $nSmithing	= 0; }
	if( !isset( $nTailoring ) )		{ $nTailoring	= 0; }
	if( !isset( $nTinkering ) )		{ $nTinkering	= 0; }

	// Declare variables
	$strResult		= "UPDATE_FAILED";
	$strTableName	= "TradeSkills";
	$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
					  "(CharID, Alchemy, Baking, Brewing, Fishing, Fletching, Foraging, Jewelcraft, Poison, Pottery, Research, Smithing, Tailoring, Tinkering) \n" .
					  "VALUES ($nCharID, '$nAlchemy', '$nBaking', '$nBrewing', '$nFishing', '$nFletching', '$nForaging', '$nJewelcraft', '$nPoison', '$nPottery', '$nResearch', '$nSmithing', '$nTailoring', '$nTinkering')";
	$strUpdateQuery	= "UPDATE `$strTableName` \n" .
					  "SET Alchemy    = '$nAlchemy', \n" .
					  "    Baking     = '$nBaking', \n" .
					  "    Brewing    = '$nBrewing', \n" .
					  "    Fishing    = '$nFishing', \n" .
					  "    Fletching  = '$nFletching', \n" .
					  "    Foraging   = '$nForaging', \n" .
					  "    Jewelcraft = '$nJewelcraft', \n" .
					  "    Poison     = '$nPoison', \n" .
					  "    Pottery    = '$nPottery', \n" .
					  "    Research   = '$nResearch', \n" .
					  "    Smithing   = '$nSmithing', \n" .
					  "    Tailoring  = '$nTailoring', \n" .
					  "    Tinkering  = '$nTinkering' \n" .
					  "WHERE CharID = $nCharID ";

	// Check if all the values are empty (delete record)
	if( ( $nAlchemy == 0 ) &&
		( $nBaking == 0 ) &&
		( $nBrewing == 0 ) &&
		( $nFishing == 0 ) &&
		( $nFletching == 0 ) &&
		( $nForaging == 0 ) &&
		( $nJewelcraft == 0 ) &&
		( $nPoison == 0 ) &&
		( $nPottery == 0 ) &&
		( $nResearch == 0 ) &&
		( $nSmithing == 0 ) &&
		( $nTailoring == 0 ) &&
		( $nTinkering == 0 ) )
	{
		// Delete the record
		$strResult	= DeleteRecord( $strTableName, $nCharID, $strCharName );
	}
	else
	{
		// Save the record
		$strResult	= SaveRecord( $strTableName, $nCharID, $strCharName, $strInsertQuery, $strUpdateQuery );
	}

	// Done
	return $strResult;
}



// =============================================================================
// Update the Keys
// =============================================================================
function UpdateKeys( $nCharID, $strCharName, $nBoT_Tower_Key, $nHowling_Stones_Key, $nSebilis_Key, $nSleepers_Tomb_Key, $nSSRA_Emperor_Key, $nVeeshans_Peak_Key, $nVex_Thal_Key )
{
	// Make sure all parameters have a value
	if( !isset( $nBoT_Tower_Key ) )			{ $nBoT_Tower_Key		= 0; }
	if( !isset( $nHowling_Stones_Key ) )	{ $nHowling_Stones_Key	= 0; }
	if( !isset( $nSebilis_Key ) )			{ $nSebilis_Key			= 0; }
	if( !isset( $nSleepers_Tomb_Key ) )		{ $nSleepers_Tomb_Key	= 0; }
	if( !isset( $nSSRA_Emperor_Key ) )		{ $nSSRA_Emperor_Key	= 0; }
	if( !isset( $nVeeshans_Peak_Key ) )		{ $nVeeshans_Peak_Key	= 0; }
	if( !isset( $nVex_Thal_Key ) )			{ $nVex_Thal_Key		= 0; }

	// Declare variables
	$strResult		= "UPDATE_FAILED";
	$strTableName	= "Keys";
	$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
					  "(CharID, BoT_Tower_Key, Howling_Stones_Key, Sebilis_Key, Sleepers_Tomb_Key, SSRA_Emperor_Key, Veeshans_Peak_Key, Vex_Thal_Key) \n" .
					  "VALUES ($nCharID, '$nBoT_Tower_Key', '$nHowling_Stones_Key', '$nSebilis_Key', '$nSleepers_Tomb_Key', '$nSSRA_Emperor_Key', '$nVeeshans_Peak_Key', '$nVex_Thal_Key')";
	$strUpdateQuery	= "UPDATE `$strTableName` \n" .
					  "SET BoT_Tower_Key       = '$nBoT_Tower_Key', \n" .
					  "    Howling_Stones_Key  = '$nHowling_Stones_Key', \n" .
					  "    Sebilis_Key         = '$nSebilis_Key', \n" .
					  "    Sleepers_Tomb_Key   = '$nSleepers_Tomb_Key', \n" .
					  "    SSRA_Emperor_Key    = '$nSSRA_Emperor_Key', \n" .
					  "    Veeshans_Peak_Key   = '$nVeeshans_Peak_Key', \n" .
					  "    Vex_Thal_Key        = '$nVex_Thal_Key'\n" .
					  "WHERE CharID = $nCharID ";

	// Check if all the values are empty (delete record)
	if( ( $nBoT_Tower_Key == 0 ) &&
		( $nHowling_Stones_Key == 0 ) &&
		( $nSebilis_Key == 0 ) &&
		( $nSleepers_Tomb_Key == 0 ) &&
		( $nSSRA_Emperor_Key == 0 ) &&
		( $nVeeshans_Peak_Key == 0 ) &&
		( $nVex_Thal_Key == 0 ) )
	{
		// Delete the record
		$strResult	= DeleteRecord( $strTableName, $nCharID, $strCharName );
	}
	else
	{
		// Save the record
		$strResult	= SaveRecord( $strTableName, $nCharID, $strCharName, $strInsertQuery, $strUpdateQuery );
	}

	// Done
	return $strResult;
}



// =============================================================================
// Update the PoS_Askr_Quest
// =============================================================================
function UpdatePoS_Askr_Quest( $nCharID, $strCharName, $nHead, $nBeard, $nBone, $nSash, $nOceanMedal, $nDesertMedal, $nForestMedal )
{
	// Make sure all parameters have a value
	if( !isset( $nHead ) )			{ $nHead		= 0; }
	if( !isset( $nBeard ) )			{ $nBeard		= 0; }
	if( !isset( $nBone ) )			{ $nBone		= 0; }
	if( !isset( $nSash ) )			{ $nSash		= 0; }
	if( !isset( $nOceanMedal ) )	{ $nOceanMedal	= 0; }
	if( !isset( $nDesertMedal ) )	{ $nDesertMedal	= 0; }
	if( !isset( $nForestMedal ) )	{ $nForestMedal	= 0; }

	// Declare variables
	$strResult		= "UPDATE_FAILED";
	$strTableName	= "PoS_Askr_Quest";
	$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
					  "(CharID, Head, Beard, Bone, Sash, OceanMedal, DesertMedal, ForestMedal) \n" .
					  "VALUES ($nCharID, '$nHead', '$nBeard', '$nBone', '$nSash', '$nOceanMedal', '$nDesertMedal', '$nForestMedal')";
	$strUpdateQuery	= "UPDATE `$strTableName` \n" .
					  "SET Head         = '$nHead', \n" .
					  "    Beard        = '$nBeard', \n" .
					  "    Bone         = '$nBone', \n" .
					  "    Sash         = '$nSash', \n" .
					  "    OceanMedal   = '$nOceanMedal', \n" .
					  "    DesertMedal  = '$nDesertMedal', \n" .
					  "    ForestMedal  = '$nForestMedal' \n" .
					  "WHERE CharID = $nCharID ";

	// Check if all the values are empty (delete record)
	if( ( $nHead == 0 ) &&
		( $nBeard == 0 ) &&
		( $nBone == 0 ) &&
		( $nSash == 0 ) &&
		( $nOceanMedal == 0 ) &&
		( $nDesertMedal == 0 ) &&
		( $nForestMedal == 0 ) )
	{
		// Delete the record
		$strResult	= DeleteRecord( $strTableName, $nCharID, $strCharName );
	}
	else
	{
		// Save the record
		$strResult	= SaveRecord( $strTableName, $nCharID, $strCharName, $strInsertQuery, $strUpdateQuery );
	}

	// Done
	return $strResult;
}



// =============================================================================
// Update the SSRA_Emperor_Key
// =============================================================================
function UpdateSSRAEmperorKey( $nCharID, $strCharName, $nTaskmasters_Pouch, $nZazuzhs_Idol, $nRing, $nInsignia )
{
	// Make sure all parameters have a value
	if( !isset( $nTaskmasters_Pouch ) )	{ $nTaskmasters_Pouch	= 0; }
	if( !isset( $nZazuzhs_Idol ) )		{ $nZazuzhs_Idol		= 0; }
	if( !isset( $nRing ) )				{ $nRing				= 0; }
	if( !isset( $nInsignia ) )			{ $nInsignia			= 0; }

	// Declare variables
	$strResult		= "UPDATE_FAILED";
	$strTableName	= "SSRA_Emperor_Key";
	$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
					  "(CharID, Taskmasters_Pouch, Zazuzhs_Idol, Ring, Insignia) \n" .
					  "VALUES ($nCharID, '$nTaskmasters_Pouch', '$nZazuzhs_Idol', '$nRing', '$nInsignia')";
	$strUpdateQuery	= "UPDATE `$strTableName` \n" .
					  "SET Taskmasters_Pouch  = '$nTaskmasters_Pouch', \n" .
					  "    Zazuzhs_Idol       = '$nZazuzhs_Idol', \n" .
					  "    Ring               = '$nRing', \n" .
					  "    Insignia           = '$nInsignia' \n" .
					  "WHERE CharID = $nCharID ";

	// Check if all the values are empty (delete record)
	if( ( $nTaskmasters_Pouch == 0 ) &&
		( $nZazuzhs_Idol == 0 ) &&
		( $nRing == 0 ) &&
		( $nInsignia == 0 ) )
	{
		// Delete the record
		$strResult	= DeleteRecord( $strTableName, $nCharID, $strCharName );
	}
	else
	{
		// Save the record
		$strResult	= SaveRecord( $strTableName, $nCharID, $strCharName, $strInsertQuery, $strUpdateQuery );
	}

	// Done
	return $strResult;
}



// =============================================================================
// Update the Veeshans_Peak_Key
// =============================================================================
function UpdateVeeshansPeakKey( $nCharID, $strCharName, $nKylongMedal_Top, $nKylongMedal_Middle, $nKylongMedal_Bottom, $nJarsathMedal_Top, $nJarsathMedal_Middle, $nJarsathMedal_Bottom, $nObulusMedal_Top, $nObulusMedal_Middle, $nObulusMedal_Bottom, $nTrak_Tooth )
{
	// Make sure all parameters have a value
	if( !isset( $nKylongMedal_Top ) )		{ $nKylongMedal_Top		= 0; }
	if( !isset( $nKylongMedal_Middle ) )	{ $nKylongMedal_Middle	= 0; }
	if( !isset( $nKylongMedal_Bottom ) )	{ $nKylongMedal_Bottom	= 0; }
	if( !isset( $nJarsathMedal_Top ) )		{ $nJarsathMedal_Top	= 0; }
	if( !isset( $nJarsathMedal_Middle ) )	{ $nJarsathMedal_Middle	= 0; }
	if( !isset( $nJarsathMedal_Bottom ) )	{ $nJarsathMedal_Bottom	= 0; }
	if( !isset( $nObulusMedal_Top ) )		{ $nObulusMedal_Top		= 0; }
	if( !isset( $nObulusMedal_Middle ) )	{ $nObulusMedal_Middle	= 0; }
	if( !isset( $nObulusMedal_Bottom ) )	{ $nObulusMedal_Bottom	= 0; }
	if( !isset( $nTrak_Tooth ) )			{ $nTrak_Tooth			= 0; }

	// Declare variables
	$strResult		= "UPDATE_FAILED";
	$strTableName	= "Veeshans_Peak_Key";
	$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
					  "(CharID, KylongMedal_Top, KylongMedal_Middle, KylongMedal_Bottom, JarsathMedal_Top, JarsathMedal_Middle, JarsathMedal_Bottom, ObulusMedal_Top, ObulusMedal_Middle, ObulusMedal_Bottom, Trak_Tooth) \n" .
					  "VALUES ($nCharID, '$nKylongMedal_Top', '$nKylongMedal_Middle', '$nKylongMedal_Bottom', '$nJarsathMedal_Top', '$nJarsathMedal_Middle', '$nJarsathMedal_Bottom', '$nObulusMedal_Top', '$nObulusMedal_Middle', '$nObulusMedal_Bottom', '$nTrak_Tooth')";
	$strUpdateQuery	= "UPDATE `$strTableName` \n" .
					  "SET KylongMedal_Top      = '$nKylongMedal_Top', \n" .
					  "    KylongMedal_Middle   = '$nKylongMedal_Middle', \n" .
					  "    KylongMedal_Bottom   = '$nKylongMedal_Bottom', \n" .
					  "    JarsathMedal_Top     = '$nJarsathMedal_Top', \n" .
					  "    JarsathMedal_Middle  = '$nJarsathMedal_Middle', \n" .
					  "    JarsathMedal_Bottom  = '$nJarsathMedal_Bottom', \n" .
					  "    ObulusMedal_Top      = '$nObulusMedal_Top', \n" .
					  "    ObulusMedal_Middle   = '$nObulusMedal_Middle', \n" .
					  "    ObulusMedal_Bottom   = '$nObulusMedal_Bottom', \n" .
					  "    Trak_Tooth           = '$nTrak_Tooth' \n" .
					  "WHERE CharID = $nCharID ";

	// Check if all the values are empty (delete record)
	if( ( $nKylongMedal_Top == 0 ) &&
		( $nKylongMedal_Middle == 0 ) &&
		( $nKylongMedal_Bottom == 0 ) &&
		( $nJarsathMedal_Top == 0 ) &&
		( $nJarsathMedal_Middle == 0 ) &&
		( $nJarsathMedal_Bottom == 0 ) &&
		( $nObulusMedal_Top == 0 ) &&
		( $nObulusMedal_Middle == 0 ) &&
		( $nObulusMedal_Bottom == 0 ) &&
		( $nTrak_Tooth == 0 ) )
	{
		// Delete the record
		$strResult	= DeleteRecord( $strTableName, $nCharID, $strCharName );
	}
	else
	{
		// Save the record
		$strResult	= SaveRecord( $strTableName, $nCharID, $strCharName, $strInsertQuery, $strUpdateQuery );
	}

	// Done
	return $strResult;
}



// =============================================================================
// Update the Vex_Thal_Key
// =============================================================================
function UpdateVexThalKey( $nCharID, $strCharName, $nGlowing_Orb, $nCelestial_Rift, $nShard_Dat, $nShard_Dax, $nShard_Kel, $nShard_Kelara, $nShard_Lor, $nShard_Raf, $nShard_Set, $nShard_Tak, $nShard_Ved, $nShard_Vin )
{
	// Make sure all parameters have a value
	if( !isset( $nGlowing_Orb ) )		{ $nGlowing_Orb		= 0; }
	if( !isset( $nCelestial_Rift ) )	{ $nCelestial_Rift	= 0; }
	if( !isset( $nShard_Dat ) )			{ $nShard_Dat		= 0; }
	if( !isset( $nShard_Dax ) )			{ $nShard_Dax		= 0; }
	if( !isset( $nShard_Kel ) )			{ $nShard_Kel		= 0; }
	if( !isset( $nShard_Kelara ) )		{ $nShard_Kelara	= 0; }
	if( !isset( $nShard_Lor ) )			{ $nShard_Lor		= 0; }
	if( !isset( $nShard_Raf ) )			{ $nShard_Raf		= 0; }
	if( !isset( $nShard_Set ) )			{ $nShard_Set		= 0; }
	if( !isset( $nShard_Tak ) )			{ $nShard_Tak		= 0; }
	if( !isset( $nShard_Ved ) )			{ $nShard_Ved		= 0; }
	if( !isset( $nShard_Vin ) )			{ $nShard_Vin		= 0; }

	// Declare variables
	$strResult		= "UPDATE_FAILED";
	$strTableName	= "Vex_Thal_Key";
	$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
					  "(CharID, Glowing_Orb, Celestial_Rift, Shard_Dat, Shard_Dax, Shard_Kel, Shard_Kelara, Shard_Lor, Shard_Raf, Shard_Set, Shard_Tak, Shard_Ved, Shard_Vin) \n" .
					  "VALUES ($nCharID, '$nGlowing_Orb', '$nCelestial_Rift', '$nShard_Dat', '$nShard_Dax', '$nShard_Kel', '$nShard_Kelara', '$nShard_Lor', '$nShard_Raf', '$nShard_Set', '$nShard_Tak', '$nShard_Ved', '$nShard_Vin')";
	$strUpdateQuery	= "UPDATE `$strTableName` \n" .
					  "SET Glowing_Orb     = '$nGlowing_Orb', \n" .
					  "    Celestial_Rift  = '$nCelestial_Rift', \n" .
					  "    Shard_Dat       = '$nShard_Dat', \n" .
					  "    Shard_Dax       = '$nShard_Dax', \n" .
					  "    Shard_Kel       = '$nShard_Kel', \n" .
					  "    Shard_Kelara    = '$nShard_Kelara', \n" .
					  "    Shard_Lor       = '$nShard_Lor', \n" .
					  "    Shard_Raf       = '$nShard_Raf', \n" .
					  "    Shard_Set       = '$nShard_Set', \n" .
					  "    Shard_Tak       = '$nShard_Tak', \n" .
					  "    Shard_Ved       = '$nShard_Ved', \n" .
					  "    Shard_Vin       = '$nShard_Vin' \n" .
					  "WHERE CharID = $nCharID ";

	// Check if all the values are empty (delete record)
	if( ( $nGlowing_Orb == 0 ) &&
		( $nCelestial_Rift == 0 ) &&
		( $nShard_Dat == 0 ) &&
		( $nShard_Dax == 0 ) &&
		( $nShard_Kel == 0 ) &&
		( $nShard_Kelara == 0 ) &&
		( $nShard_Lor == 0 ) &&
		( $nShard_Raf == 0 ) &&
		( $nShard_Set == 0 ) &&
		( $nShard_Tak == 0 ) &&
		( $nShard_Ved == 0 ) &&
		( $nShard_Vin == 0 ) )
	{
		// Delete the record
		$strResult	= DeleteRecord( $strTableName, $nCharID, $strCharName );
	}
	else
	{
		// Save the record
		$strResult	= SaveRecord( $strTableName, $nCharID, $strCharName, $strInsertQuery, $strUpdateQuery );
	}

	// Done
	return $strResult;
}



// =============================================================================
// Update the Pop Tier 1 Flags record
// =============================================================================
function UpdatePoPTier1( $nCharID, $strCharName, $nAny_PoJ_Trial, $nAll_PoJ_Trials, $nPoI_Xanamech, $nPoI_Behemoth, $nPoD_Grimror_Quest, $nPoD_Grummus, $nPoN_Hedge_Quest, $nPoNb_Terris_Thule )
{
	// Make sure all parameters have a value
	if( !isset( $nAny_PoJ_Trial ) )		{ $nAny_PoJ_Trial		= 0; }
	if( !isset( $nAll_PoJ_Trials ) )	{ $nAll_PoJ_Trials		= 0; }
	if( !isset( $nPoI_Xanamech ) )		{ $nPoI_Xanamech		= 0; }
	if( !isset( $nPoI_Behemoth ) )		{ $nPoI_Behemoth		= 0; }
	if( !isset( $nPoD_Grimror_Quest ) )	{ $nPoD_Grimror_Quest	= 0; }
	if( !isset( $nPoD_Grummus ) )		{ $nPoD_Grummus			= 0; }
	if( !isset( $nPoN_Hedge_Quest ) )	{ $nPoN_Hedge_Quest		= 0; }
	if( !isset( $nPoNb_Terris_Thule ) )	{ $nPoNb_Terris_Thule	= 0; }

	// Declare variables
	$strResult		= "UPDATE_FAILED";
	$strTableName	= "PoP_Tier_1_Flags";
	$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
					  "(CharID, Any_PoJ_Trial, All_PoJ_Trials, PoI_Xanamech, PoI_Behemoth, PoD_Grimror_Quest, PoD_Grummus, PoN_Hedge_Quest, PoNb_Terris_Thule) \n" .
					  "VALUES ($nCharID, '$nAny_PoJ_Trial', '$nAll_PoJ_Trials', '$nPoI_Xanamech', '$nPoI_Behemoth', '$nPoD_Grimror_Quest', '$nPoD_Grummus', '$nPoN_Hedge_Quest', '$nPoNb_Terris_Thule')";
	$strUpdateQuery	= "UPDATE `$strTableName` \n" .
					  "SET Any_PoJ_Trial     = '$nAny_PoJ_Trial', \n" .
					  "    All_PoJ_Trials    = '$nAll_PoJ_Trials', \n" .
					  "    PoI_Xanamech      = '$nPoI_Xanamech', \n" .
					  "    PoI_Behemoth      = '$nPoI_Behemoth', \n" .
					  "    PoD_Grimror_Quest = '$nPoD_Grimror_Quest', \n" .
					  "    PoD_Grummus       = '$nPoD_Grummus', \n" .
					  "    PoN_Hedge_Quest   = '$nPoN_Hedge_Quest', \n" .
					  "    PoNb_Terris_Thule = '$nPoNb_Terris_Thule' \n" .
					  "WHERE CharID = $nCharID ";

	// Check if all the values are empty (delete record)
	if( ( $nAny_PoJ_Trial == 0 ) &&
		( $nAll_PoJ_Trials == 0 ) &&
		( $nPoI_Xanamech == 0 ) &&
		( $nPoI_Behemoth == 0 ) &&
		( $nPoD_Grimror_Quest == 0 ) &&
		( $nPoD_Grummus == 0 ) &&
		( $nPoN_Hedge_Quest == 0 ) &&
		( $nPoNb_Terris_Thule == 0 ) )
	{
		// Delete the record
		$strResult	= DeleteRecord( $strTableName, $nCharID, $strCharName );
	}
	else
	{
		// Save the record
		$strResult	= SaveRecord( $strTableName, $nCharID, $strCharName, $strInsertQuery, $strUpdateQuery );
	}

	// Done
	return $strResult;
}



// =============================================================================
// Update the Pop Tier 2 Flags record
// =============================================================================
function UpdatePoPTier2( $nCharID, $strCharName, $nPoS_Askr_Quest, $nPoV_Grenic_Quest, $nPoV_AerinDar, $nCoD_Carprin_Event, $nCoD_Bertoxxulous, $nPoTorment_Saryrn, $nPoS_Wembly_Quest )
{
	// Make sure all parameters have a value
	if( !isset( $nPoS_Askr_Quest ) )	{ $nPoS_Askr_Quest		= 0; }
	if( !isset( $nPoV_Grenic_Quest ) )	{ $nPoV_Grenic_Quest	= 0; }
	if( !isset( $nPoV_AerinDar ) )		{ $nPoV_AerinDar		= 0; }
	if( !isset( $nCoD_Carprin_Event ) )	{ $nCoD_Carprin_Event	= 0; }
	if( !isset( $nCoD_Bertoxxulous ) )	{ $nCoD_Bertoxxulous	= 0; }
	if( !isset( $nPoTorment_Saryrn ) )	{ $nPoTorment_Saryrn	= 0; }
	if( !isset( $nPoS_Wembly_Quest ) )	{ $nPoS_Wembly_Quest	= 0; }

	// Declare variables
	$strResult		= "UPDATE_FAILED";
	$strTableName	= "PoP_Tier_2_Flags";
	$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
					  "(CharID, PoS_Askr_Quest, PoV_Grenic_Quest, PoV_AerinDar, CoD_Carprin_Event, CoD_Bertoxxulous, PoTorment_Saryrn, PoS_Wembly_Quest) \n" .
					  "VALUES ($nCharID, '$nPoS_Askr_Quest', '$nPoV_Grenic_Quest', '$nPoV_AerinDar', '$nCoD_Carprin_Event', '$nCoD_Bertoxxulous', '$nPoTorment_Saryrn', '$nPoS_Wembly_Quest')";
	$strUpdateQuery	= "UPDATE `$strTableName` \n" .
					  "SET PoS_Askr_Quest    = '$nPoS_Askr_Quest', \n" .
					  "    PoV_Grenic_Quest  = '$nPoV_Grenic_Quest', \n" .
					  "    PoV_AerinDar      = '$nPoV_AerinDar', \n" .
					  "    CoD_Carprin_Event = '$nCoD_Carprin_Event', \n" .
					  "    CoD_Bertoxxulous  = '$nCoD_Bertoxxulous', \n" .
					  "    PoTorment_Saryrn  = '$nPoTorment_Saryrn', \n" .
					  "    PoS_Wembly_Quest  = '$nPoS_Wembly_Quest' \n" .
					  "WHERE CharID = $nCharID ";

	// Check if all the values are empty (delete record)
	if( ( $nPoS_Askr_Quest == 0 ) &&
		( $nPoV_Grenic_Quest == 0 ) &&
		( $nPoV_AerinDar == 0 ) &&
		( $nCoD_Carprin_Event == 0 ) &&
		( $nCoD_Bertoxxulous == 0 ) &&
		( $nPoTorment_Saryrn == 0 ) &&
		( $nPoS_Wembly_Quest == 0 ) )
	{
		// Delete the record
		$strResult	= DeleteRecord( $strTableName, $nCharID, $strCharName );
	}
	else
	{
		// Save the record
		$strResult	= SaveRecord( $strTableName, $nCharID, $strCharName, $strInsertQuery, $strUpdateQuery );
	}

	// Done
	return $strResult;
}



// =============================================================================
// Update the Pop Tier 3 Flags record
// =============================================================================
function UpdatePoPTier3( $nCharID, $strCharName, $nHoH_Trial1_RyddaDar, $nHoH_Trial2_Ogre, $nHoH_Trial3_Madmen, $nHoHb_Mithanial_Marr, $nPoTactics_Tallon_Zek, $nPoTactics_Vallon_Zek, $nPoTactics_Rallos_Zek_Quest, $nBoT_Rescue_Karana_Quest, $nSolRoTower_Jiva, $nSolRoTower_Xuzl, $nSolRoTower_Arlyxir, $nSolRoTower_Rizlona, $nSolRoTower_Protector_of_Dresolik, $nSolRoTower_Solusek_Ro )
{
	// Make sure all parameters have a value
	if( !isset( $nHoH_Trial1_RyddaDar ) )				{ $nHoH_Trial1_RyddaDar					= 0; }
	if( !isset( $nHoH_Trial2_Ogre ) )					{ $nHoH_Trial2_Ogre						= 0; }
	if( !isset( $nHoH_Trial3_Madmen ) )					{ $nHoH_Trial3_Madmen					= 0; }
	if( !isset( $nHoHb_Mithanial_Marr ) )				{ $nHoHb_Mithanial_Marr					= 0; }
	if( !isset( $nPoTactics_Tallon_Zek ) )				{ $nPoTactics_Tallon_Zek				= 0; }
	if( !isset( $nPoTactics_Vallon_Zek ) )				{ $nPoTactics_Vallon_Zek				= 0; }
	if( !isset( $nPoTactics_Rallos_Zek_Quest ) )		{ $nPoTactics_Rallos_Zek_Quest			= 0; }
	if( !isset( $nBoT_Rescue_Karana_Quest ) )			{ $nBoT_Rescue_Karana_Quest				= 0; }
	if( !isset( $nSolRoTower_Jiva ) )					{ $nSolRoTower_Jiva						= 0; }
	if( !isset( $nSolRoTower_Xuzl ) )					{ $nSolRoTower_Xuzl						= 0; }
	if( !isset( $nSolRoTower_Arlyxir ) )				{ $nSolRoTower_Arlyxir					= 0; }
	if( !isset( $nSolRoTower_Rizlona ) )				{ $nSolRoTower_Rizlona					= 0; }
	if( !isset( $nSolRoTower_Protector_of_Dresolik ) )	{ $nSolRoTower_Protector_of_Dresolik	= 0; }
	if( !isset( $nSolRoTower_Solusek_Ro ) )				{ $nSolRoTower_Solusek_Ro				= 0; }

	// Declare variables
	$strResult		= "UPDATE_FAILED";
	$strTableName	= "PoP_Tier_3_Flags";
	$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
					  "(CharID, HoH_Trial1_RyddaDar, HoH_Trial2_Ogre, HoH_Trial3_Madmen, HoHb_Mithanial_Marr, PoTactics_Tallon_Zek, PoTactics_Vallon_Zek, PoTactics_Rallos_Zek_Quest, BoT_Rescue_Karana_Quest, SolRoTower_Jiva, SolRoTower_Xuzl, SolRoTower_Arlyxir, SolRoTower_Rizlona, SolRoTower_Protector_of_Dresolik, SolRoTower_Solusek_Ro) \n" .
					  "VALUES ($nCharID, '$nHoH_Trial1_RyddaDar', '$nHoH_Trial2_Ogre', '$nHoH_Trial3_Madmen', '$nHoHb_Mithanial_Marr', '$nPoTactics_Tallon_Zek', '$nPoTactics_Vallon_Zek', '$nPoTactics_Rallos_Zek_Quest', '$nBoT_Rescue_Karana_Quest', '$nSolRoTower_Jiva', '$nSolRoTower_Xuzl', '$nSolRoTower_Arlyxir', '$nSolRoTower_Rizlona', '$nSolRoTower_Protector_of_Dresolik', '$nSolRoTower_Solusek_Ro')";
	$strUpdateQuery	= "UPDATE `$strTableName` \n" .
					  "SET HoH_Trial1_RyddaDar              = '$nHoH_Trial1_RyddaDar', \n" .
					  "    HoH_Trial2_Ogre                  = '$nHoH_Trial2_Ogre', \n" .
					  "    HoH_Trial3_Madmen                = '$nHoH_Trial3_Madmen', \n" .
					  "    HoHb_Mithanial_Marr              = '$nHoHb_Mithanial_Marr', \n" .
					  "    PoTactics_Tallon_Zek             = '$nPoTactics_Tallon_Zek', \n" .
					  "    PoTactics_Vallon_Zek             = '$nPoTactics_Vallon_Zek', \n" .
					  "    PoTactics_Rallos_Zek_Quest       = '$nPoTactics_Rallos_Zek_Quest', \n" .
					  "    BoT_Rescue_Karana_Quest          = '$nBoT_Rescue_Karana_Quest', \n" .
					  "    SolRoTower_Jiva                  = '$nSolRoTower_Jiva', \n" .
					  "    SolRoTower_Xuzl                  = '$nSolRoTower_Xuzl', \n" .
					  "    SolRoTower_Arlyxir               = '$nSolRoTower_Arlyxir', \n" .
					  "    SolRoTower_Rizlona               = '$nSolRoTower_Rizlona', \n" .
					  "    SolRoTower_Protector_of_Dresolik = '$nSolRoTower_Protector_of_Dresolik', \n" .
					  "    SolRoTower_Solusek_Ro            = '$nSolRoTower_Solusek_Ro' \n" .
					  "WHERE CharID = $nCharID ";

	// Check if all the values are empty (delete record)
	if( ( $nHoH_Trial1_RyddaDar == 0 ) &&
		( $nHoH_Trial2_Ogre == 0 ) &&
		( $nHoH_Trial3_Madmen == 0 ) &&
		( $nHoHb_Mithanial_Marr == 0 ) &&
		( $nPoTactics_Tallon_Zek == 0 ) &&
		( $nPoTactics_Vallon_Zek == 0 ) &&
		( $nPoTactics_Rallos_Zek_Quest == 0 ) &&
		( $nBoT_Rescue_Karana_Quest == 0 ) &&
		( $nSolRoTower_Jiva == 0 ) &&
		( $nSolRoTower_Xuzl == 0 ) &&
		( $nSolRoTower_Arlyxir == 0 ) &&
		( $nSolRoTower_Rizlona == 0 ) &&
		( $nSolRoTower_Protector_of_Dresolik == 0 ) &&
		( $nSolRoTower_Solusek_Ro == 0 ) )
	{
		// Delete the record
		$strResult	= DeleteRecord( $strTableName, $nCharID, $strCharName );
	}
	else
	{
		// Save the record
		$strResult	= SaveRecord( $strTableName, $nCharID, $strCharName, $strInsertQuery, $strUpdateQuery );
	}

	// Done
	return $strResult;
}



// =============================================================================
// Update the Pop Tier 4 Flags record
// =============================================================================
function UpdatePoPTier4( $nCharID, $strCharName, $nPoAir_Xegony, $nPoFire_Fennin_Ro, $nPoWater_Coirnav, $nPoEarthb_The_Rathe, $nPoTime_Time_Phased_Quintessence )
{
	// Make sure all parameters have a value
	if( !isset( $nPoAir_Xegony ) )						{ $nPoAir_Xegony					= 0; }
	if( !isset( $nPoFire_Fennin_Ro ) )					{ $nPoFire_Fennin_Ro				= 0; }
	if( !isset( $nPoWater_Coirnav ) )					{ $nPoWater_Coirnav					= 0; }
	if( !isset( $nPoEarthb_The_Rathe ) )				{ $nPoEarthb_The_Rathe				= 0; }
	if( !isset( $nPoTime_Time_Phased_Quintessence ) )	{ $nPoTime_Time_Phased_Quintessence	= 0; }

	// Declare variables
	$strResult		= "UPDATE_FAILED";
	$strTableName	= "PoP_Tier_4_Flags";
	$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
					  "(CharID, PoAir_Xegony, PoFire_Fennin_Ro, PoWater_Coirnav, PoEarthb_The_Rathe, PoTime_Time_Phased_Quintessence) \n" .
					  "VALUES ($nCharID, '$nPoAir_Xegony', '$nPoFire_Fennin_Ro', '$nPoWater_Coirnav', '$nPoEarthb_The_Rathe', '$nPoTime_Time_Phased_Quintessence')";
	$strUpdateQuery	= "UPDATE `$strTableName` \n" .
					  "SET PoAir_Xegony                    = '$nPoAir_Xegony', \n" .
					  "    PoFire_Fennin_Ro                = '$nPoFire_Fennin_Ro', \n" .
					  "    PoWater_Coirnav                 = '$nPoWater_Coirnav', \n" .
					  "    PoEarthb_The_Rathe              = '$nPoEarthb_The_Rathe', \n" .
					  "    PoTime_Time_Phased_Quintessence = '$nPoTime_Time_Phased_Quintessence' \n" .
					  "WHERE CharID = $nCharID ";

	// Check if all the values are empty (delete record)
	if( ( $nPoAir_Xegony == 0 ) &&
		( $nPoFire_Fennin_Ro == 0 ) &&
		( $nPoWater_Coirnav == 0 ) &&
		( $nPoEarthb_The_Rathe == 0 ) &&
		( $nPoTime_Time_Phased_Quintessence == 0 ) )
	{
		// Delete the record
		$strResult	= DeleteRecord( $strTableName, $nCharID, $strCharName );
	}
	else
	{
		// Save the record
		$strResult	= SaveRecord( $strTableName, $nCharID, $strCharName, $strInsertQuery, $strUpdateQuery );
	}

	// Done
	return $strResult;
}



// =============================================================================
// Update the GoD Flags record
// =============================================================================
function UpdateGoDFlags( $nCharID, $strCharName, $nPurifying_Plant, $nEmanating_Furnace, $nLair_of_Trapped_Ones, $nPool_of_Sludge, $nSmith_Rondo, $nVxed, $nTipt, $nVrex_Barxt_Qurat, $nKeeper_of_the_Altar, $nNoqufiel_in_Inktuta, $nCynosure_Kvanjji, $nIxt_Hsek_Syat, $nHigh_Priest_Nkosi_Bakari, $nZunMuram_Tkarish_Zyk )
{
	// Make sure all parameters have a value
	if( !isset( $nPurifying_Plant ) )			{ $nPurifying_Plant				= 0; }
	if( !isset( $nEmanating_Furnace ) )			{ $nEmanating_Furnace			= 0; }
	if( !isset( $nLair_of_Trapped_Ones ) )		{ $nLair_of_Trapped_Ones		= 0; }
	if( !isset( $nPool_of_Sludge ) )			{ $nPool_of_Sludge				= 0; }
	if( !isset( $nSmith_Rondo ) )				{ $nSmith_Rondo					= 0; }
	if( !isset( $nVxed ) )						{ $nVxed						= 0; }
	if( !isset( $nTipt ) )						{ $nTipt						= 0; }
	if( !isset( $nVrex_Barxt_Qurat ) )			{ $nVrex_Barxt_Qurat			= 0; }
	if( !isset( $nKeeper_of_the_Altar ) )		{ $nKeeper_of_the_Altar			= 0; }
	if( !isset( $nNoqufiel_in_Inktuta ) )		{ $nNoqufiel_in_Inktuta			= 0; }
	if( !isset( $nCynosure_Kvanjji ) )			{ $nCynosure_Kvanjji			= 0; }
	if( !isset( $nIxt_Hsek_Syat ) )				{ $nIxt_Hsek_Syat				= 0; }
	if( !isset( $nHigh_Priest_Nkosi_Bakari ) )	{ $nHigh_Priest_Nkosi_Bakari	= 0; }
	if( !isset( $nZunMuram_Tkarish_Zyk ) )		{ $nZunMuram_Tkarish_Zyk		= 0; }

	// Declare variables
	$strResult		= "UPDATE_FAILED";
	$strTableName	= "GoD_Flags";
	$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
					  "(CharID, Purifying_Plant, Emanating_Furnace, Lair_of_Trapped_Ones, Pool_of_Sludge, Smith_Rondo, Vxed, Tipt, Vrex_Barxt_Qurat, Keeper_of_the_Altar, Noqufiel_in_Inktuta, Cynosure_Kvanjji, Ixt_Hsek_Syat, High_Priest_Nkosi_Bakari, ZunMuram_Tkarish_Zyk) \n" .
					  "VALUES ($nCharID, '$nPurifying_Plant', '$nEmanating_Furnace', '$nLair_of_Trapped_Ones', '$nPool_of_Sludge', '$nSmith_Rondo', '$nVxed', '$nTipt', '$nVrex_Barxt_Qurat', '$nKeeper_of_the_Altar', '$nNoqufiel_in_Inktuta', '$nCynosure_Kvanjji', '$nIxt_Hsek_Syat', '$nHigh_Priest_Nkosi_Bakari', '$nZunMuram_Tkarish_Zyk')";
	$strUpdateQuery	= "UPDATE `$strTableName` \n" .
					  "SET Purifying_Plant           = '$nPurifying_Plant', \n" .
					  "    Emanating_Furnace         = '$nEmanating_Furnace', \n" .
					  "    Lair_of_Trapped_Ones      = '$nLair_of_Trapped_Ones', \n" .
					  "    Pool_of_Sludge            = '$nPool_of_Sludge', \n" .
					  "    Smith_Rondo               = '$nSmith_Rondo', \n" .
					  "    Vxed                      = '$nVxed', \n" .
					  "    Tipt                      = '$nTipt', \n" .
					  "    Vrex_Barxt_Qurat          = '$nVrex_Barxt_Qurat', \n" .
					  "    Keeper_of_the_Altar       = '$nKeeper_of_the_Altar', \n" .
					  "    Noqufiel_in_Inktuta       = '$nNoqufiel_in_Inktuta', \n" .
					  "    Cynosure_Kvanjji          = '$nCynosure_Kvanjji', \n" .
					  "    Ixt_Hsek_Syat             = '$nIxt_Hsek_Syat', \n" .
					  "    High_Priest_Nkosi_Bakari  = '$nHigh_Priest_Nkosi_Bakari', \n" .
					  "    ZunMuram_Tkarish_Zyk      = '$nZunMuram_Tkarish_Zyk' \n" .
					  "WHERE CharID = $nCharID ";

	// Check if all the values are empty (delete record)
	if( ( $nPurifying_Plant == 0 ) &&
		( $nEmanating_Furnace == 0 ) &&
		( $nLair_of_Trapped_Ones == 0 ) &&
		( $nPool_of_Sludge == 0 ) &&
		( $nSmith_Rondo == 0 ) &&
		( $nVxed == 0 ) &&
		( $nTipt == 0 ) &&
		( $nVrex_Barxt_Qurat == 0 ) &&
		( $nKeeper_of_the_Altar == 0 ) &&
		( $nNoqufiel_in_Inktuta == 0 ) &&
		( $nCynosure_Kvanjji == 0 ) &&
		( $nIxt_Hsek_Syat == 0 ) &&
		( $nHigh_Priest_Nkosi_Bakari == 0 ) &&
		( $nZunMuram_Tkarish_Zyk == 0 ) )
	{
		// Delete the record
		$strResult	= DeleteRecord( $strTableName, $nCharID, $strCharName );
	}
	else
	{
		// Save the record
		$strResult	= SaveRecord( $strTableName, $nCharID, $strCharName, $strInsertQuery, $strUpdateQuery );
	}

	// Done
	return $strResult;
}



// =============================================================================
// Update the OoW CoA record
// =============================================================================
function UpdateOoW_CoA( $nCharID, $strCharName, $nMastery_of_Adaptation, $nMastery_of_Corruption, $nMastery_of_Endurance, $nMastery_of_Foresight, $nMastery_of_Hate, $nMastery_of_Specialization, $nSeal_Mastery_of_All, $nSignet_Crystal_Gemmed, $nSignet_Discolored, $nSignet_Dust_Marred, $nSignet_Glimmering, $nSignet_Tarnished, $nSignet_Two_Toned, $nSignet_Weather_Worn )
{
	// Make sure all parameters have a value
	if( !isset( $nMastery_of_Adaptation ) )		{ $nMastery_of_Adaptation		= 0; }
	if( !isset( $nMastery_of_Corruption ) )		{ $nMastery_of_Corruption		= 0; }
	if( !isset( $nMastery_of_Endurance ) )		{ $nMastery_of_Endurance		= 0; }
	if( !isset( $nMastery_of_Foresight ) )		{ $nMastery_of_Foresight		= 0; }
	if( !isset( $nMastery_of_Hate ) )			{ $nMastery_of_Hate				= 0; }
	if( !isset( $nMastery_of_Specialization ) )	{ $nMastery_of_Specialization	= 0; }
	if( !isset( $nSeal_Mastery_of_All ) )		{ $nSeal_Mastery_of_All			= 0; }
	if( !isset( $nSignet_Crystal_Gemmed ) )		{ $nSignet_Crystal_Gemmed		= 0; }
	if( !isset( $nSignet_Discolored ) )			{ $nSignet_Discolored			= 0; }
	if( !isset( $nSignet_Dust_Marred ) )		{ $nSignet_Dust_Marred			= 0; }
	if( !isset( $nSignet_Glimmering ) )			{ $nSignet_Glimmering			= 0; }
	if( !isset( $nSignet_Tarnished ) )			{ $nSignet_Tarnished			= 0; }
	if( !isset( $nSignet_Two_Toned ) )			{ $nSignet_Two_Toned			= 0; }
	if( !isset( $nSignet_Weather_Worn ) )		{ $nSignet_Weather_Worn			= 0; }

	// Declare variables
	$strResult		= "UPDATE_FAILED";
	$strTableName	= "OoW_CoA";
	$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
					  "(CharID, Mastery_of_Adaptation, Mastery_of_Corruption, Mastery_of_Endurance, Mastery_of_Foresight, Mastery_of_Hate, Mastery_of_Specialization, Seal_Mastery_of_All, Signet_Crystal_Gemmed, Signet_Discolored, Signet_Dust_Marred, Signet_Glimmering, Signet_Tarnished, Signet_Two_Toned, Signet_Weather_Worn) \n" .
					  "VALUES ($nCharID, '$nMastery_of_Adaptation', '$nMastery_of_Corruption', '$nMastery_of_Endurance', '$nMastery_of_Foresight', '$nMastery_of_Hate', '$nMastery_of_Specialization', '$nSeal_Mastery_of_All', '$nSignet_Crystal_Gemmed', '$nSignet_Discolored', '$nSignet_Dust_Marred', '$nSignet_Glimmering', '$nSignet_Tarnished', '$nSignet_Two_Toned', '$nSignet_Weather_Worn')";
	$strUpdateQuery	= "UPDATE `$strTableName` \n" .
					  "SET Mastery_of_Adaptation		= '$nMastery_of_Adaptation', \n" .
					  "    Mastery_of_Corruption		= '$nMastery_of_Corruption', \n" .
					  "    Mastery_of_Endurance			= '$nMastery_of_Endurance', \n" .
					  "    Mastery_of_Foresight			= '$nMastery_of_Foresight', \n" .
					  "    Mastery_of_Hate				= '$nMastery_of_Hate', \n" .
					  "    Mastery_of_Specialization	= '$nMastery_of_Specialization', \n" .
					  "    Seal_Mastery_of_All			= '$nSeal_Mastery_of_All', \n" .
					  "    Signet_Crystal_Gemmed		= '$nSignet_Crystal_Gemmed', \n" .
					  "    Signet_Discolored			= '$nSignet_Discolored', \n" .
					  "    Signet_Dust_Marred			= '$nSignet_Dust_Marred', \n" .
					  "    Signet_Glimmering			= '$nSignet_Glimmering', \n" .
					  "    Signet_Tarnished				= '$nSignet_Tarnished', \n" .
					  "    Signet_Two_Toned				= '$nSignet_Two_Toned', \n" .
					  "    Signet_Weather_Worn			= '$nSignet_Weather_Worn' \n" .
					  "WHERE CharID = $nCharID ";

	// Check if all the values are empty (delete record)
	if( ( $nMastery_of_Adaptation == 0 ) &&
		( $nMastery_of_Corruption == 0 ) &&
		( $nMastery_of_Endurance == 0 ) &&
		( $nMastery_of_Foresight == 0 ) &&
		( $nMastery_of_Hate == 0 ) &&
		( $nMastery_of_Specialization == 0 ) &&
		( $nSeal_Mastery_of_All == 0 ) &&
		( $nSignet_Crystal_Gemmed == 0 ) &&
		( $nSignet_Discolored == 0 ) &&
		( $nSignet_Dust_Marred == 0 ) &&
		( $nSignet_Glimmering == 0 ) &&
		( $nSignet_Tarnished == 0 ) &&
		( $nSignet_Two_Toned == 0 ) &&
		( $nSignet_Weather_Worn == 0 ) )
	{
		// Delete the record
		$strResult	= DeleteRecord( $strTableName, $nCharID, $strCharName );
	}
	else
	{
		// Save the record
		$strResult	= SaveRecord( $strTableName, $nCharID, $strCharName, $strInsertQuery, $strUpdateQuery );
	}

	// Done
	return $strResult;
}



// =============================================================================
// Update the DoN Flags record
// =============================================================================
function UpdateDoNFlags( $nCharID, $strCharName, $nT1_Create_an_Antidote, $nT1_Greed_of_the_Goblins, $nT1_Burning_Arrows, $nT1_Children_of_Gimblax, $nT2_Defend_the_Kirin_Contact, $nT2_Recover_the_Lost_Map, $nT2_Turn_the_Tides_of_the_Sand, $nT2_Sickness_of_the_Spirit, $nT2_Calling_Emoush, $nT3_Protect_the_Waters, $nT3_Snowfoots_Revenge, $nT3_The_Sacred_Scrolls, $nT3_History_of_the_Isle, $nT3_Trial_of_Perserverance, $nT3_Volkaras_Bite, $nT4_Goblin_Dojo, $nT4_Guardian_of_the_Sands, $nT4_An_End_to_the_Storms, $nT5_Origins_of_the_Curse, $nT5_The_Curse_of_JuRek, $nT5_In_the_Shadows )
{
	// Make sure all parameters have a value
	if( !isset( $nT1_Create_an_Antidote ) )			{ $nT1_Create_an_Antidote			= 0; }
	if( !isset( $nT1_Greed_of_the_Goblins ) )		{ $nT1_Greed_of_the_Goblins			= 0; }
	if( !isset( $nT1_Burning_Arrows ) )				{ $nT1_Burning_Arrows				= 0; }
	if( !isset( $nT1_Children_of_Gimblax ) )		{ $nT1_Children_of_Gimblax			= 0; }
	if( !isset( $nT2_Defend_the_Kirin_Contact ) )	{ $nT2_Defend_the_Kirin_Contact		= 0; }
	if( !isset( $nT2_Recover_the_Lost_Map ) )		{ $nT2_Recover_the_Lost_Map			= 0; }
	if( !isset( $nT2_Turn_the_Tides_of_the_Sand ) )	{ $nT2_Turn_the_Tides_of_the_Sand	= 0; }
	if( !isset( $nT2_Sickness_of_the_Spirit ) )		{ $nT2_Sickness_of_the_Spirit		= 0; }
	if( !isset( $nT2_Calling_Emoush ) )				{ $nT2_Calling_Emoush				= 0; }
	if( !isset( $nT3_Protect_the_Waters ) )			{ $nT3_Protect_the_Waters			= 0; }
	if( !isset( $nT3_Snowfoots_Revenge ) )			{ $nT3_Snowfoots_Revenge			= 0; }
	if( !isset( $nT3_The_Sacred_Scrolls ) )			{ $nT3_The_Sacred_Scrolls			= 0; }
	if( !isset( $nT3_History_of_the_Isle ) )		{ $nT3_History_of_the_Isle			= 0; }
	if( !isset( $nT3_Trial_of_Perserverance ) )		{ $nT3_Trial_of_Perserverance		= 0; }
	if( !isset( $nT3_Volkaras_Bite ) )				{ $nT3_Volkaras_Bite				= 0; }
	if( !isset( $nT4_Goblin_Dojo ) )				{ $nT4_Goblin_Dojo					= 0; }
	if( !isset( $nT4_Guardian_of_the_Sands ) )		{ $nT4_Guardian_of_the_Sands		= 0; }
	if( !isset( $nT4_An_End_to_the_Storms ) )		{ $nT4_An_End_to_the_Storms			= 0; }
	if( !isset( $nT5_Origins_of_the_Curse ) )		{ $nT5_Origins_of_the_Curse			= 0; }
	if( !isset( $nT5_The_Curse_of_JuRek ) )			{ $nT5_The_Curse_of_JuRek			= 0; }
	if( !isset( $nT5_In_the_Shadows ) )				{ $nT5_In_the_Shadows				= 0; }

	// Declare variables
	$strResult		= "UPDATE_FAILED";
	$strTableName	= "DoN_Flags";
	$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
					  "(CharID, T1_Create_an_Antidote, T1_Greed_of_the_Goblins, T1_Burning_Arrows, T1_Children_of_Gimblax, T2_Defend_the_Kirin_Contact, T2_Recover_the_Lost_Map, T2_Turn_the_Tides_of_the_Sand, T2_Sickness_of_the_Spirit, T2_Calling_Emoush, T3_Protect_the_Waters, T3_Snowfoots_Revenge, T3_The_Sacred_Scrolls, T3_History_of_the_Isle, T3_Trial_of_Perserverance, T3_Volkaras_Bite, T4_Goblin_Dojo, T4_Guardian_of_the_Sands, T4_An_End_to_the_Storms, T5_Origins_of_the_Curse, T5_The_Curse_of_JuRek, T5_In_the_Shadows) \n" .
					  "VALUES ($nCharID, '$nT1_Create_an_Antidote', '$nT1_Greed_of_the_Goblins', '$nT1_Burning_Arrows', '$nT1_Children_of_Gimblax', '$nT2_Defend_the_Kirin_Contact', '$nT2_Recover_the_Lost_Map', '$nT2_Turn_the_Tides_of_the_Sand', '$nT2_Sickness_of_the_Spirit', '$nT2_Calling_Emoush', '$nT3_Protect_the_Waters', '$nT3_Snowfoots_Revenge', '$nT3_The_Sacred_Scrolls', '$nT3_History_of_the_Isle', '$nT3_Trial_of_Perserverance', '$nT3_Volkaras_Bite', '$nT4_Goblin_Dojo', '$nT4_Guardian_of_the_Sands', '$nT4_An_End_to_the_Storms', '$nT5_Origins_of_the_Curse', '$nT5_The_Curse_of_JuRek', '$nT5_In_the_Shadows')";
	$strUpdateQuery	= "UPDATE `$strTableName` \n" .
					  "SET T1_Create_an_Antidote         = '$nT1_Create_an_Antidote', \n" .
					  "    T1_Greed_of_the_Goblins       = '$nT1_Greed_of_the_Goblins', \n" .
					  "    T1_Burning_Arrows             = '$nT1_Burning_Arrows', \n" .
					  "    T1_Children_of_Gimblax        = '$nT1_Children_of_Gimblax', \n" .
					  "    T2_Defend_the_Kirin_Contact   = '$nT2_Defend_the_Kirin_Contact', \n" .
					  "    T2_Recover_the_Lost_Map       = '$nT2_Recover_the_Lost_Map', \n" .
					  "    T2_Turn_the_Tides_of_the_Sand = '$nT2_Turn_the_Tides_of_the_Sand', \n" .
					  "    T2_Sickness_of_the_Spirit     = '$nT2_Sickness_of_the_Spirit', \n" .
					  "    T2_Calling_Emoush             = '$nT2_Calling_Emoush', \n" .
					  "    T3_Protect_the_Waters         = '$nT3_Protect_the_Waters', \n" .
					  "    T3_Snowfoots_Revenge          = '$nT3_Snowfoots_Revenge', \n" .
					  "    T3_The_Sacred_Scrolls         = '$nT3_The_Sacred_Scrolls', \n" .
					  "    T3_History_of_the_Isle        = '$nT3_History_of_the_Isle', \n" .
					  "    T3_Trial_of_Perserverance     = '$nT3_Trial_of_Perserverance', \n" .
					  "    T3_Volkaras_Bite              = '$nT3_Volkaras_Bite', \n" .
					  "    T4_Goblin_Dojo                = '$nT4_Goblin_Dojo', \n" .
					  "    T4_Guardian_of_the_Sands      = '$nT4_Guardian_of_the_Sands', \n" .
					  "    T4_An_End_to_the_Storms       = '$nT4_An_End_to_the_Storms', \n" .
					  "    T5_Origins_of_the_Curse       = '$nT5_Origins_of_the_Curse', \n" .
					  "    T5_The_Curse_of_JuRek         = '$nT5_The_Curse_of_JuRek', \n" .
					  "    T5_In_the_Shadows             = '$nT5_In_the_Shadows' \n" .
					  "WHERE CharID = $nCharID ";


	// Check if all the values are empty (delete record)
	if( ( $nT1_Create_an_Antidote == 0 ) &&
		( $nT1_Greed_of_the_Goblins == 0 ) &&
		( $nT1_Burning_Arrows == 0 ) &&
		( $nT1_Children_of_Gimblax == 0 ) &&
		( $nT2_Defend_the_Kirin_Contact == 0 ) &&
		( $nT2_Recover_the_Lost_Map == 0 ) &&
		( $nT2_Turn_the_Tides_of_the_Sand == 0 ) &&
		( $nT2_Sickness_of_the_Spirit == 0 ) &&
		( $nT2_Calling_Emoush == 0 ) &&
		( $nT3_Protect_the_Waters == 0 ) &&
		( $nT3_Snowfoots_Revenge == 0 ) &&
		( $nT3_The_Sacred_Scrolls == 0 ) &&
		( $nT3_History_of_the_Isle == 0 ) &&
		( $nT3_Trial_of_Perserverance == 0 ) &&
		( $nT3_Volkaras_Bite == 0 ) &&
		( $nT4_Goblin_Dojo == 0 ) &&
		( $nT4_Guardian_of_the_Sands == 0 ) &&
		( $nT4_An_End_to_the_Storms == 0 ) &&
		( $nT5_Origins_of_the_Curse == 0 ) &&
		( $nT5_The_Curse_of_JuRek == 0 ) &&
		( $nT5_In_the_Shadows == 0 ) )
	{
		// Delete the record
		$strResult	= DeleteRecord( $strTableName, $nCharID, $strCharName );
	}
	else
	{
		// Save the record
		$strResult	= SaveRecord( $strTableName, $nCharID, $strCharName, $strInsertQuery, $strUpdateQuery );
	}

	// Done
	return $strResult;
}



// =============================================================================
// Update the SSRA_Emperor_Key
// =============================================================================
function UpdateDoDSpells( $nCharID, $strCharName, $nA_Rogues_Trust, $nScouting_the_City, $nBuilding_the_Disguise, $nThe_Search_for_Illsuras, $nThe_Rage_of_Kelliad, $nThe_Lost_Notebook, $nCavern_Botany, $nThe_Search_for_Clues, $nRescue_Cicero, $nPreemptive_Strike, $nPraetorian_Guard, $nThe_Fall_of_Illsalin, $nFlights_of_the_Seeker, $nInto_the_Shadows )
{
	// Make sure all parameters have a value
	if( !isset( $nA_Rogues_Trust ) )			{ $nA_Rogues_Trust			= 0; }
	if( !isset( $nScouting_the_City ) )			{ $nScouting_the_City		= 0; }
	if( !isset( $nBuilding_the_Disguise ) )		{ $nBuilding_the_Disguise	= 0; }
	if( !isset( $nThe_Search_for_Illsuras ) )	{ $nThe_Search_for_Illsuras	= 0; }
	if( !isset( $nThe_Rage_of_Kelliad ) )		{ $nThe_Rage_of_Kelliad		= 0; }
	if( !isset( $nThe_Lost_Notebook ) )			{ $nThe_Lost_Notebook		= 0; }
	if( !isset( $nCavern_Botany ) )				{ $nCavern_Botany			= 0; }
	if( !isset( $nThe_Search_for_Clues ) )		{ $nThe_Search_for_Clues	= 0; }
	if( !isset( $nRescue_Cicero ) )				{ $nRescue_Cicero			= 0; }
	if( !isset( $nPreemptive_Strike ) )			{ $nPreemptive_Strike		= 0; }
	if( !isset( $nPraetorian_Guard ) )			{ $nPraetorian_Guard		= 0; }
	if( !isset( $nThe_Fall_of_Illsalin ) )		{ $nThe_Fall_of_Illsalin	= 0; }
	if( !isset( $nFlights_of_the_Seeker ) )		{ $nFlights_of_the_Seeker	= 0; }
	if( !isset( $nInto_the_Shadows ) )			{ $nInto_the_Shadows		= 0; }

	// Declare variables
	$strResult		= "UPDATE_FAILED";
	$strTableName	= "DoD_Spells";
	$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
					  "(CharID, A_Rogues_Trust, Scouting_the_City, Building_the_Disguise, The_Search_for_Illsuras, The_Rage_of_Kelliad, The_Lost_Notebook, Cavern_Botany, The_Search_for_Clues, Rescue_Cicero, Preemptive_Strike, Praetorian_Guard, The_Fall_of_Illsalin, Flights_of_the_Seeker, Into_the_Shadows) \n" .
					  "VALUES ($nCharID, '$nA_Rogues_Trust', '$nScouting_the_City', '$nBuilding_the_Disguise', '$nThe_Search_for_Illsuras', '$nThe_Rage_of_Kelliad', '$nThe_Lost_Notebook', '$nCavern_Botany', '$nThe_Search_for_Clues', '$nRescue_Cicero', '$nPreemptive_Strike', '$nPraetorian_Guard', '$nThe_Fall_of_Illsalin', '$nFlights_of_the_Seeker', '$nInto_the_Shadows')";
	$strUpdateQuery	= "UPDATE `$strTableName` \n" .
					  "SET A_Rogues_Trust			= '$nA_Rogues_Trust', \n" .
					  "    Scouting_the_City		= '$nScouting_the_City', \n" .
					  "    Building_the_Disguise	= '$nBuilding_the_Disguise', \n" .
					  "    The_Search_for_Illsuras	= '$nThe_Search_for_Illsuras', \n" .
					  "    The_Rage_of_Kelliad		= '$nThe_Rage_of_Kelliad', \n" .
					  "    The_Lost_Notebook		= '$nThe_Lost_Notebook', \n" .
					  "    Cavern_Botany			= '$nCavern_Botany', \n" .
					  "    The_Search_for_Clues		= '$nThe_Search_for_Clues', \n" .
					  "    Rescue_Cicero			= '$nRescue_Cicero', \n" .
					  "    Preemptive_Strike		= '$nPreemptive_Strike', \n" .
					  "    Praetorian_Guard			= '$nPraetorian_Guard', \n" .
					  "    The_Fall_of_Illsalin		= '$nThe_Fall_of_Illsalin', \n" .
					  "    Flights_of_the_Seeker	= '$nFlights_of_the_Seeker', \n" .
					  "    Into_the_Shadows			= '$nInto_the_Shadows' \n" .
					  "WHERE CharID = $nCharID ";

	// Check if all the values are empty (delete record)
	if( ( $nA_Rogues_Trust == 0 ) &&
		( $nScouting_the_City == 0 ) &&
		( $nBuilding_the_Disguise == 0 ) &&
		( $nThe_Search_for_Illsuras == 0 ) &&
		( $nThe_Rage_of_Kelliad == 0 ) &&
		( $nThe_Lost_Notebook == 0 ) &&
		( $nCavern_Botany == 0 ) &&
		( $nThe_Search_for_Clues == 0 ) &&
		( $nRescue_Cicero == 0 ) &&
		( $nPreemptive_Strike == 0 ) &&
		( $nPraetorian_Guard == 0 ) &&
		( $nThe_Fall_of_Illsalin == 0 ) &&
		( $nFlights_of_the_Seeker == 0 ) &&
		( $nInto_the_Shadows == 0 ) )
	{
		// Delete the record
		$strResult	= DeleteRecord( $strTableName, $nCharID, $strCharName );
	}
	else
	{
		// Save the record
		$strResult	= SaveRecord( $strTableName, $nCharID, $strCharName, $strInsertQuery, $strUpdateQuery );
	}

	// Done
	return $strResult;
}



// =============================================================================
// Delete a record
// =============================================================================
function DeleteRecord( $strTableName, $nCharID, $strCharName )
{
	// Declare variables
	$strResult		= "DELETE_FAILED";
	$strDeleteQuery	= "DELETE FROM `$strTableName` WHERE CharID = $nCharID";

	// Connect to the database
	$nLinkID	= DBConnect();

	// Delete the record
	$nResult		= mysql_query( $strDeleteQuery, $nLinkID );

	// Set the status
	$strResult		= "RECORD_DELETED";

	// Close the connection
	DBDisconnect( $nLinkID );
	
	// Done
	return $strResult;
}



// =============================================================================
// Save a record to a table, either by Inserting or Updating it.
// =============================================================================
function SaveRecord( $strTableName, $nCharID, $strCharName, $strInsertQuery, $strUpdateQuery )
{
	// Declare variables
	$strResult		= "DELETE_FAILED";
	$strCountQuery	= "SELECT COUNT(*) FROM `$strTableName` WHERE CharID = $nCharID";

	// Connect to the database
	$nLinkID	= DBConnect();

	// Check if the Char already exists
	$nResult	= mysql_query( $strCountQuery, $nLinkID );
	$aResult	= mysql_fetch_row( $nResult );
	if( ( isset( $aResult[0] ) ) &&
		( $aResult[0] >= 1 ) )
	{
		// Update the record
		$nResult	= mysql_query( $strUpdateQuery, $nLinkID );
		// Check if the update was succesfull
		if( $nResult == 1 )
		{
			$strResult	= "RECORD_UPDATED";
		}
		else
		{
			// Show error message
			print( "	<font color=\"#FF3300\"><a> - Update `$strTableName` record FAILED (Char=" . $strCharName . ")!<br /></a></font>\n" );
			print( "    $strUpdateQuery<br />\n" );
			print( "    " . mysql_error() . "<br />\n" );
		}
	}
	else
	{
		// Insert the record
		$nResult	= mysql_query( $strInsertQuery, $nLinkID );
		// Check if the update was succesfull
		if( $nResult == 1 )
		{
			$strResult	= "RECORD_INSERTED";
		}
		else
		{
			// Show error message
			print( "	<font color=\"#FF3300\"><a> - Insert of `$strTableName` record FAILED (Char=" . $strCharName . ")!<br /></a></font>\n" );
			print( "    $strUpdateQuery<br />\n" );
			print( "    " . mysql_error() . "<br />\n" );
		}
	}

	// Close the connection
	DBDisconnect( $nLinkID );

	// Done
	return $strResult;
}



?>