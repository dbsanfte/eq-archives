<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );


// ============================================================================
// The Users class
// ============================================================================
// This class handles the User_Verify procedure
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class User_Verify
{

	// ========================================================================
	// Constructor
	// ========================================================================
	function User_Verify()
	{
		// No code yet
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "User Verify";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<!-- End of Header -->
		';
	}
	
	
	
	// ========================================================================
	// Show the body
	// ========================================================================
	// This function will show the user verify page
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS			= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName			= $_GET['UserName'];
		$strPassword			= $_GET['Password'];
		$strSortOrder			= $_GET['SortOrder'];
		$strSortDirection		= $_GET['SortDirection'];
		$strShowAlts			= $_GET['ShowAlts'];
		// Declare variables
		$strVerifyUserName		= $_GET['VerifyUserName'];
		$strVerificationCode	= $_GET['editVerificationCode'];
		$strAction				= $_GET['Action'];
		$bShowResendMessage		= true;
		$strEMailAddress		= $this->GetEMailAddress( $strUserName );
		$strResultCode			= "";
	
		// Check if the UserName is not set
		if( !isset( $strUserName ) )
		{
			// Show error message
			print( "	<p>&nbsp<p>\n" );
			print( "	<center><font color=\"#FF3300\">\n" );
			print( "	  Illegal call to page...\n" );
			print( "	  ERROR 01: Unkown user!)\n" );
			print( "	</font></center>\n\n" );
			// Abort page
			return;
		}

		// Check if the user can't click "Resend Verification Code"
		if( ( $strAction == "ResendVerificationCode" ) ||
			( $strAction == "DisableVerificationCodeResend" ) )
		{
			$bShowResendMessage	= false;
		}
	
		// Check if the verification code is set
		if( ( isset( $strVerificationCode ) ) &&
			( $strVerificationCode != "" ) )
		{
			// Check if an admin is verifying the account
			if( isset( $strVerifyUserName ) )
			{
				// Check if the user exists and the password is correct
				$strResultCode	= $this->VerifyUser( $strVerifyUserName, $this->GetEMailAddress( $strVerifyUserName ), $strVerificationCode );
				// Switch to roster
				LoadForm( "Users", "&UserName=" . $strUserName . "&Password=" . $strPassword . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts );
				// Abort page
				return;
			}
			else
			{
				// Check if the user exists and the password is correct
				$strResultCode	= $this->VerifyUser( $strUserName, $strEMailAddress, $strVerificationCode );
		
				// Check if the user was verified
				if( $strResultCode == "USER_VERIFIED" )
				{
					// Switch to roster
					LoadForm( "Characters", "&UserName=" . $strUserName . "&Password=" . Encrypt( $strPassword ) . "&CookieAction=WRITE" );
					// Abort page
					return;
				}
			}
		}

		// Show the Verify User page
		$this->ShowVerifyUserPage( $strUserName, $strPassword, $strVerificationCode, $strEMailAddress, $bShowResendMessage );

		// Check if there was an error
		if( $strResultCode != "" )
		{
			// Show error message
			print( "	<strong><center>\n" );
			print( "	  <font color=\"#FF3300\"><a>\n" );
			print( "	    Wrong verification code!<br />\n" );
			print( "	  </a></font>\n" );
			print( "	</center></strong>\n\n" );
		}
	
		// Check if we have to undertake an action
		if( $strAction == "ResendVerificationCode" )
		{
			// Fill the E-mail fields
			$strAddresse	= $strEMailAddress;
			$strSubject		= GetRosterName() . " Verification";
			$strContents	= "Hello $strUserName,\n" .
							  "\n" .
							  "Here is your verification code as requested: \"" . Encrypt( strtoupper($strUserName . $strEMailAddress) ) . "\" (without the quotes).\n" .
							  "You will be asked for this code if you try to login.\n" .
							  "\n" .
							  "The " . GetRosterName() . " crew.\n";
			$strFromSender	= "From: " . GetAdminEmail();
			// Send the verification E-mail
			$bMailed		= mail( $strAddresse, $strSubject, $strContents, $strFromSender );

			if( $bMailed )
			{
				// Show resend message on screen
				print( "	<center><font color=\"#C0C0FF\">\n" );
				print( "	  The verification code has been resend.\n" );
				print( "	</font></center>\n\n" );
			}
			else
			{
				// Show contact admin on screen
				print( "	<center><font color=\"#FF3300\">\n" );
				print( "	  The verification code could not be resend.<br />\n" );
				print( "	</font>\n\n" );
				print( "	<font color=\"#C0C0FF\">\n" );
				print( "	  Please E-Mail your <a href=\"mailto:" . GetAdminEmail() . "?subject=EQRoster verification request for `$strUserName`&body=Could you please verify `$strUserName`?%0a%0aThanks\">Administrator</a> and ask him to verify you manually.\n" );
				print( "	</font></center>\n\n" );
			}
		}
	}



	// ========================================================================
	// Validate a user
	// ========================================================================
	function VerifyUser( $strUserName, $strEMailAddress, $strVerificationCode )
	{
		// Declare variables
		$strResult	= "VERIFICATION_FAILED";
	
		// Check if the entered code matches the MD5 on the UserName
		if( ( isset( $strVerificationCode ) ) &&
			( $strVerificationCode == Encrypt( strtoupper($strUserName . $strEMailAddress) ) ) )
		{
			// The verification code is valid
			$strResult	= "VERIFICATIONCODE_IS_VALID";
	
			// Open the database connection	
			$nLinkID	= DBConnect();
	
			// Update the record
			$nResult	= mysql_query( "update Users set Verified='Yes' where UserName = '$strUserName'", $nLinkID );//	or die( "Query failed (" . mysql_error() . ")" );
	
			// Close the database connection
			DBDisconnect( $nLinkID );
	
			// Check if the query was succesful
			if( $nResult == 1 )
			{
				$strResult	= "USER_VERIFIED";
			}
		}
	
		return $strResult;
	}
	
	
	
	// ========================================================================
	// Retrieve the users E-mail address from the database
	// ========================================================================
	function GetEMailAddress( $strUserName )
	{
		// Declare variables
		$strEMailAddress	= "NOT_FOUND";
	
		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Retrieve the users E-mail address
	 	$nResult	= mysql_query( "select EMailAddress from Users where UserName = '$strUserName'", $nLinkID );//	or die( "Query failed (" . mysql_error() . ")" );
		$aResult	= mysql_fetch_row( $nResult );//								or die( "FetchRow failed (" . mysql_error() . ")" );
	
		// Close the database connection
		DBDisconnect( $nLinkID );
	
		// Check if the E-mail address is filled
		if( isset( $strEMailAddress ) )
		{
			// Store the E-mail address
			$strEMailAddress	= $aResult[0];
		}
	
		// Return the result
		return $strEMailAddress;
	}



	// ========================================================================
	// Show the Verify User page
	// ========================================================================
	function ShowVerifyUserPage( $strUserName, $strPassword, $strVerificationCode, $strEMailAddress, $bShowResendMessage )
	{
		// Declare variables
		$strAction			= "Action=DisableVerificationCodeResend";	// Default no resend message
		$strResendMessage	= "";
	
		// Check if the resend message is shown
		if( $bShowResendMessage == true )
		{
			$strAction			= "Action=";
			$strResendMessage	= '<a href="form.php?FormName=User_Verify&UserName=' . $strUserName . '&Password=' . $strPassword . '&Action=ResendVerificationCode" OnMouseOver="window.status=\'Resend the verification code\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Resend the verification code">Resend</a> the verification code or ';
		}
	
		// Create the page
		echo '
		<form name="formVerifyUser" method="post" action="form.php?FormName=User_Verify&UserName=' . $strUserName . '&Password=' . $strPassword . '&' . $strAction . '" target=Body>
		  <div id="Body" align="center"> 
		  <p><strong><font color="#CCCCCC" size="+3"><em>Verify User  "' . $strUserName . '"</em></font></strong></p>
			<p>&nbsp;</p>
			<table width="33%" border="0">
			  <tr> 
				<td width="35%">Verification code:</td>
				<td width="65%" align="center"><input name="editVerificationCode" type="text" id="editVerificationCode" value="' . $strVerificationCode . '"></td>
			  </tr>
			</table>
			<br />
			<p>
			  <input name="pbVerify" type="submit" id="pbVerify" value="Verify">
			</p>
		    <p>&nbsp;</p>
		    <p><font color="#33FF00">
		      This verification code has been E-Mailed to your E-mail address: "' . $strEMailAddress . '"<br />
		      </font>
		    </p>
		      ' . $strResendMessage . ' <a href="form.php?FormName=User_Modify&UserName=' . $strUserName . '&Password=' . $strPassword . '&ModifyUserName=' . $strUserName . '" OnMouseOver="window.status=\'Edit your user settings (Password/E-Mail etc...)\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Edit your user settings (Password/E-Mail etc...)">Edit</a> your user settings.
		  </div>
		</form>';
		print( "\n\n\n" );
	}

}

?>
