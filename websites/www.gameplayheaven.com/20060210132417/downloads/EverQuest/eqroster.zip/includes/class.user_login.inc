<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );


// ============================================================================
// The Users class
// ============================================================================
// This class handles the User_Login procedure
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class User_Login
{

	// ========================================================================
	// Constructor
	// ========================================================================
	function User_Login()
	{
		// No code yet
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "User Login";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<!-- End of Header -->
		';
	}
	
	
	
	// ========================================================================
	// Show the body
	// ========================================================================
	// This function will show the login page
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS	= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName	= $_GET['editUserName'];
		$strPassword	= $_GET['editPassword'];
		// Declare variables
		$strResultCode	= "";
		
		// Check if the UserName is set
		if( ( isset( $strUserName ) ) &&
			( $strUserName != "" ) )
		{
			// Make sure the name is properly formatted
			$strUserName	= FormatName( $strUserName );
	
			// Check if the user exists and the password is correct
			$strResultCode	= $this->ValidateUser( $strUserName, $strPassword );
	
			if( $strResultCode == "VALID_USER" )
			{
				// Switch to roster
				LoadForm( "Characters", "&UserName=" . $strUserName . "&Password=" . Encrypt( $strPassword ) . "&CookieAction=WRITE" );
				// Abort page
				return;
			}
			else if( $strResultCode == "UNVERIFIED_USER" )
			{
				// Switch to verify_user
				LoadForm( "User_Verify", "&UserName=" . $strUserName . "&Password=" . Encrypt( $strPassword ) );
				// Abort page
				return;
			}
		}
	
		// Show the login page
		$this->ShowLoginUserPage( $strUserName, $strPassword );

		// Show error
		if( $strResultCode != "" )
		{
			// Show error message
			print( "	<strong><center>\n" );
			print( "	  <font color=\"#FF3300\"><a>\n" );
			print( "	    Cannot log in user \"" . $strUserName . "\"!<br />\n" );
			print( "	    Unkown UserName or wrong password.<br />\n" );
			print( "	  </a></font>\n" );
			print( "	</center></strong>" );
		}
	}
	
	
	
	// ========================================================================
	// Validate a user
	// ========================================================================
	function ValidateUser( $strUserName, $strPassword )
	{
		// Declare variables
		$strValidateUserResult	= "INVALID_USERNAME_PASSWORD";
	
		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Retrieve the users password and verification status
	 	$nResult	= mysql_query( "select Password, Verified from Users where UserName = '$strUserName'", $nLinkID );//	or die( "Query failed (" . mysql_error() . ")" );
		$aResult	= mysql_fetch_row( $nResult );
	
		// Close the database connection
		DBDisconnect( $nLinkID );
	
		// Check if the password is correct
		if( ( isset( $strPassword ) ) &&
			( $aResult[0] == Encrypt( $strPassword ) ) )
		{
			// Check if the user has verified his account
			if( $aResult[1] == "Yes" )
			{
				$strValidateUserResult	= "VALID_USER";
			}
			else
			{
				$strValidateUserResult	= "UNVERIFIED_USER";
			}
		}
	
		return $strValidateUserResult;
	}



	// ========================================================================
	// Show the login page
	// ========================================================================
	function ShowLoginUserPage( $strUserName, $strPassword )
	{
		echo '
		<form name="formLogin" method="post" action="form.php?FormName=User_Login" target=Body>
		  <div id="Body" align="center"> 
		  <p><strong><font color="#CCCCCC" size="+3"><em>Log in</em></font></strong></p>
			<p>&nbsp;</p>
			<table width="33%" border="0">
			  <tr> 
				<td width="35%">UserName:</td>
				<td width="65%"><div align="center"> 
					<input name="editUserName" type="text" id="editUserName" value="' . $strUserName . '">
				  </div></td>
			  </tr>
			  <tr> 
				<td>Password:</td>
				<td><div align="center"> 
					<input name="editPassword" type="password" id="editPassword" value="' . $strPassword . '">
				  </div></td>
			  </tr>
			</table>
			<br />
			<p>
			  <input name="pbLogin" type="submit" id="pbLogin" value="Log in">
			</p>
		    <p>Click <a href="form.php?FormName=User_Create" target=Body>here</a> to register a new user.</p>
		  </div>
		</form>';
		print( "\n\n\n" );
	}

}

?>
