<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );


// ============================================================================
// The User_Delete class
// ============================================================================
// This class handles the User_Delete procedure
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class User_Delete
{

	// ========================================================================
	// Constructor
	// ========================================================================
	function User_Delete()
	{
		// No code yet
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "User Delete";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<!-- End of Header -->
		';
	}
	
	
	
	// ========================================================================
	// Show the body
	// ========================================================================
	// This function will show the User delete page
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS	= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strDeleteUserName	= $_GET['DeleteUserName'];
		$strPreviousForm	= $_GET['PreviousForm'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];
		$strClassFilter		= $_GET['ClassFilter'];
		$bDeleteUser		= $_GET['cbDeleteUser'];
		$bCancelDelete		= $_GET['cbCancelDelete'];

		// Check if the user cancelled
		if( ( isset( $bCancelDelete ) ) &&
			( $bCancelDelete == "true" ) )
		{
			// Go back to the previous form
			LoadForm( $strPreviousForm, "&UserName=" . $strUserName . "&Password=" . $strPassword . "&SortOrder=" . $strSortOrder . "&SortDirection=" . $strSortDirection  . "&ShowAlts=" . $strShowAlts . "&ClassFilter=" . $strClassFilter );
		}

		// Check if the UserName is an admin
		if( ( isset( $strUserName ) ) &&
			( $strUserName != "" ) && 
			( IsAdministrator( $strUserName ) ) )
		{
			// Check if the user cancelled
			if( ( isset( $bDeleteUser ) ) &&
				( $bDeleteUser == "true" ) )
			{
				// Delete the User
				$this->DeleteUser( $strUserName, $strPassword, $strDeleteUserName, $strPreviousForm, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter, $bDeleteUser );
			}
			else
			{
				// Show the delete user page
				$this->ShowUserDeletePage( $strUserName, $strPassword, $strDeleteUserName, $strPreviousForm, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter, $bDeleteUser );
			}
		}
		else
		{
			// Show error
			print( "Only administators can delete Users..." );
		}
	}
	
	
	
	// ========================================================================
	// Delete a User
	// ========================================================================
	function DeleteUser( $strUserName, $strPassword, $strDeleteUserName, $strPreviousForm, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter, $bDeleteChar )
	{
		// Declare variables
		$nUserID				= -1;
		$strSelectUserIDQuery	= "SELECT UserID FROM `Users` WHERE UserName = '$strDeleteUserName'";
		$strDeleteQuery			= "DELETE FROM `Users` WHERE UserName = '$strDeleteUserName'";
		$nNrOfUpdateRecords		= 0;

		// Start the form
		echo '
		<form name="formDeletingUser" method="post" action="form.php?FormName=' . $strPreviousForm . '&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&ClassFilter=' . $strClassFilter . '" target=Body>
		  <div id="Body" align="center"> 
		    <p><strong><font color="#CCCCCC" size="+3"><em>
		      Deleting user "' . $strDeleteUserName . '"
		    </em></font></strong></p>
			<br />
		';		
		print( "\n" );

		// Connect to the database
		$nLinkID	= DBConnect();

		// Retrieve the UserID for this character
		$nResult	= mysql_query( $strSelectUserIDQuery, $nLinkID );
		$aResult	= mysql_fetch_row( $nResult );
		// Store the UserID
		if( isset( $aResult[0] ) )
		{
			// Store the UserID
			$nUserID			= $aResult[0];

			// Create the Update query
			$strUpdateQuery	= "UPDATE `Characters` SET UserID = 0 WHERE UserID = '$nUserID'";
			
			// Perform the update
			$nResult			= mysql_query( $strUpdateQuery, $nLinkID );
			$nNrOfUpdateRecords	= mysql_affected_rows();
		}

		// Delete the record
		$nResult		= mysql_query( $strDeleteQuery, $nLinkID );

		// Check if the delete was succesfull
		if( $nResult == 1 )
		{
			// Check how many rows where deleted
			if( mysql_affected_rows() == 1 )
			{
				print( "			<font color=\"#33FF00\">User '$strDeleteUserName' deleted ($nNrOfUpdateRecords characters updated).<br /></font>\n" );
			}
			else if( mysql_affected_rows() == 0 )
			{
				print( "			<font color=\"#C0C0FF\">User '$strDeleteUserName' not found.<br /></font>\n" );
			}
			else
			{
				print( "			<font color=\"#FF3300\">" . mysql_affected_rows() . " users '$strDeleteUserName' records deleted (and $nNrOfUpdateRecords characters updated)!<br /></font>\n" );
			}
		}
		else
		{
			// Show error message
			print( "			<font color=\"#FF3300\">\User '$strDeleteUserName' delete FAILED!<br /></font>\n" );
			print( "			$strDeleteQuery<br />\n" );
			print( "			" . mysql_error() . "<br />\n" );
		}
	
		// Close the connection
		DBDisconnect( $nLinkID );

		// Close the form
		echo '
			<br />
		    <input type="submit" name="pbDone" value="Done">
		  </div>
		</form>
		';
	}



	// ========================================================================
	// Show the user delete page
	// ========================================================================
	function ShowUserDeletePage( $strUserName, $strPassword, $strDeleteUserName, $strPreviousForm, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter, $bDeleteChar )
	{
		echo '
		<!-- JavaScript block has been added here instead of in the header on purpose -->
		<script language="JavaScript">

		<!-- Delete the Char -->
		function DeleteUser()
		{
			// Validation complete, all fields are valid
			document.formDeleteUser.cbDeleteUser.value		= true;
			document.formDeleteUser.cbDeleteUser.checked	= true;

			// Submit the form
			document.formDeleteUser.submit();

			// Done
			return true;
		};

		<!-- Cancel the delete -->
		function CancelDelete()
		{
			// Cancel
			document.formDeleteUser.cbCancelDelete.value	= true;
			document.formDeleteUser.cbCancelDelete.checked	= true;

			// Submit the form
			document.formDeleteUser.submit();

			// Done
			return true;
		};
		</script>


		<form name="formDeleteUser" method="post" action="form.php?FormName=User_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&DeleteUserName=' . $strDeleteUserName . '&PreviousForm=' . $strPreviousForm . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&ClassFilter=' . $strClassFilter . '" target=Body>
		  <div id="Body" align="center"> 
			<br />
			<br />
			<font size="+2" color="#FF3300">
			  Are you sure you want to delete the user "' . $strDeleteUserName . '"?<br />
			</font>
			<br />
		    <input type="submit" name="pbCancel" value="Cancel" onclick="CancelDelete();">
		    <input type="submit" name="pbDelete" value="Delete" onclick="DeleteUser();">
		    <!-- Hidden field to store CancelModify status -->
	        <input name="cbCancelDelete" type="hidden" id="cbCancelDelete" value="false">
		    <!-- Hidden field to store Delete status -->
	        <input name="cbDeleteUser" type="hidden" id="cbDeleteUser" value="' . $bDeleteChar . '">
		  </div>
		</form>
		';
	}

}

?>
