<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );


// ============================================================================
// The PoP Tier 1 Flags class
// ============================================================================
// This class provides an interface to the PoP_Tier_1_Flags table
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class PoP_Tier_1_Flags
{
	var $bShowVerticalScrollbars	= true;

	// ========================================================================
	// Constructor
	// ========================================================================
	function PoP_Tier_1_Flags()
	{
		// No code yet
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "PoP Tier 1 Flags";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<div id="Header">
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td width= "5%"></td>
			<td width="15%">				<b><a href="form.php?FormName=PoP_Tier_1_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=CharName&SortDirection='			. GetSortDirection( $strSortOrder, "CharName",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Name\';return true;"									OnMouseOut="window.status=\'\'"	target=Body title="Name"								>Name</a></b></td>
			<td width="10%" align="center">	<b><a href="form.php?FormName=PoP_Tier_1_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Any_PoJ_Trial&SortDirection='		. GetSortDirection( $strSortOrder, "Any_PoJ_Trial",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Plane of Justice: Any Trial\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Plane of Justice: Any Trial"			>PoJ<br />Any Trial</a></b></td>
			<td width="10%" align="center">	<b><a href="form.php?FormName=PoP_Tier_1_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=All_PoJ_Trials&SortDirection='		. GetSortDirection( $strSortOrder, "All_PoJ_Trials",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Plane of Justice: All Trials\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Plane of Justice: All Trials"		>PoJ<br />All Trials</a></b></td>
			<td width="10%" align="center">	<b><a href="form.php?FormName=PoP_Tier_1_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=PoI_Xanamech&SortDirection='		. GetSortDirection( $strSortOrder, "PoI_Xanamech",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Plane of Innovation: Xanamech\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Plane of Innovation: Xanamech"		>PoI<br />Xanamech</a></b></td>
			<td width="10%" align="center">	<b><a href="form.php?FormName=PoP_Tier_1_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=PoI_Behemoth&SortDirection='		. GetSortDirection( $strSortOrder, "PoI_Behemoth",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Plane of Innovation: Behemoth\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Plane of Innovation: Behemoth"		>PoI<br />Behemoth</a></b></td>
			<td width="10%" align="center">	<b><a href="form.php?FormName=PoP_Tier_1_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=PoD_Grimror_Quest&SortDirection='	. GetSortDirection( $strSortOrder, "PoD_Grimror_Quest",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Plane of Disease: Grimror Quest\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Plane of Disease: Grimror Quest"		>PoD<br />Grimror Quest</a></b></td>
			<td width="10%" align="center">	<b><a href="form.php?FormName=PoP_Tier_1_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=PoD_Grummus&SortDirection='		. GetSortDirection( $strSortOrder, "PoD_Grummus",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Plane of Disease: Grummus\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Plane of Disease: Grummus"			>PoD<br />Grummus</a></b></td>
			<td width="10%" align="center">	<b><a href="form.php?FormName=PoP_Tier_1_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=PoN_Hedge_Quest&SortDirection='	. GetSortDirection( $strSortOrder, "PoN_Hedge_Quest",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Plane of Nightmares: Hedge Quest\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Plane of Nightmares: Hedge Quest"	>PoN<br />Hedge Quest</a></b></td>
			<td width="10%" align="center">	<b><a href="form.php?FormName=PoP_Tier_1_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=PoNb_Terris_Thule&SortDirection='	. GetSortDirection( $strSortOrder, "PoNb_Terris_Thule",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Plane of Nightmares-b: Terris Thule\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Plane of Nightmares-b: Terris Thule"	>PoNb<br />Terris Thule</a></b></td>
		  </tr>
		</table>
		</div>
		<!-- End of Header -->
		';
	}
	
	
	
	// ========================================================================
	// Show all the records on screen
	// ========================================================================
	// This function will loop through all the records in the database table,
	// and create a html table entry for each one of them.
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS		= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];
		$strClassFilter		= $_GET['ClassFilter'];

		// Declare variables
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT CharName, NameMain, Any_PoJ_Trial, All_PoJ_Trials, PoI_Xanamech, PoI_Behemoth, PoD_Grimror_Quest, PoD_Grummus, PoN_Hedge_Quest, PoNb_Terris_Thule, OldMember \n" .
							  "FROM PoP_Tier_1_Flags \n" .
							  "LEFT JOIN Characters ON (PoP_Tier_1_Flags.CharID = Characters.CharID) \n" .
							  "WHERE (	Any_PoJ_Trial > 0		OR \n" .
							  "			All_PoJ_Trials > 0		OR \n" .
							  "			PoI_Xanamech > 0		OR \n" .
							  "			PoI_Behemoth > 0		OR \n" .
							  "			PoD_Grimror_Quest > 0	OR \n" .
							  "			PoD_Grummus > 0			OR \n" .
							  "			PoN_Hedge_Quest > 0		OR \n" .
							  "			PoNb_Terris_Thule > 0 )	   \n";	
	
		// Check if we should set a class filter
		if( ( isset( $strClassFilter ) ) &&
			( $strClassFilter != "" ) &&
			( $strClassFilter != "<<All>>" ) )
		{
			$strSelectQuery	.= "AND Class = '" . $strClassFilter . "'";
		} 

		// Check if we should use the default sort order
		if( ( !isset( $strSortOrder ) ) ||
			( $strSortOrder == "" ) )
		{
			// Default sort on Character name
			$strSortOrder	= "CharName"; 
		}

		// Sorting on all numbers should be reversed (Desc first, then Asc)
		$strModifiedSortDirection	= $strSortDirection;
		if( $strSortOrder != "CharName" )
		{
			// Switch the sort order around
			if( $strModifiedSortDirection == "DESC" )
			{
				$strModifiedSortDirection	= "";
			}
			else
			{
				$strModifiedSortDirection	= "DESC";
			}
		}
	
		// Add the sort order
		$strSelectQuery		.= "ORDER BY " . $strSortOrder . " " . $strModifiedSortDirection . ", CharName";
	
		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
		<div id="Body">
		<table id="RosterTable" width="100%" border="0" cellpadding="0" cellspacing="0">
		';
	
		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex				= 0;
			$strCharName		= $aResult[$nIndex++];
			$strNameMain		= $aResult[$nIndex++];
			$nAny_PoJ_Trial		= $aResult[$nIndex++];
			$nAll_PoJ_Trials	= $aResult[$nIndex++];
			$nPoI_Xanamech		= $aResult[$nIndex++];
			$nPoI_Behemoth		= $aResult[$nIndex++];
			$nPoD_Grimror_Quest	= $aResult[$nIndex++];
			$nPoD_Grummus		= $aResult[$nIndex++];
			$nPoN_Hedge_Quest	= $aResult[$nIndex++];
			$nPoNb_Terris_Thule	= $aResult[$nIndex++];
			$nOldMember			= $aResult[$nIndex++];
	
			// Only show old members for the administrator
			if( ( $strCharName != "" ) &&
				( ( $nOldMember == 0 ) ||
				  ( IsAdministrator( $strUserName ) ) ) )
			{
				// Show the BoT Flag parts
				$this->ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nAny_PoJ_Trial, $nAll_PoJ_Trials, $nPoI_Xanamech, $nPoI_Behemoth, $nPoD_Grimror_Quest, $nPoD_Grummus, $nPoN_Hedge_Quest, $nPoNb_Terris_Thule, $nOldMember, $strRowType );
		
				// Switch RowType, so the rows alternate	
				if( $strRowType == "OddRow" )
				{
					$strRowType	= "EvenRow";
				}
				else
				{
					$strRowType	= "OddRow";
				}
			}
		}
	
		// End the table
		echo '
		</table>
		</div>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );
	}
	
	
	
	// ========================================================================
	// Show a record
	// ========================================================================
	// This function will create a html table row for a record in the table
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// In:  Variables containing the data to show 
	// ========================================================================
	function ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nAny_PoJ_Trial, $nAll_PoJ_Trials, $nPoI_Xanamech, $nPoI_Behemoth, $nPoD_Grimror_Quest, $nPoD_Grummus, $nPoN_Hedge_Quest, $nPoNb_Terris_Thule, $nOldMember, $strRowType )
	{
		// Declare variables
		$strImageCheck			= '<img src="images/check.gif" border="0" />';
		$strDeleteChar			= "";
		$strAny_PoJ_Trial		= "";
		$strAll_PoJ_Trials		= "";
		$strPoI_Xanamech		= "";
		$strPoI_Behemoth		= "";
		$strPoD_Grimror_Quest	= "";
		$strPoD_Grummus			= "";
		$strPoN_Hedge_Quest		= "";
		$strPoNb_Terris_Thule	= "";

		// Set the check-image for all filled variables
		if( $nAny_PoJ_Trial > 0 )		{	$strAny_PoJ_Trial		= $strImageCheck;	}
		if( $nAll_PoJ_Trials > 0 )		{	$strAll_PoJ_Trials		= $strImageCheck;	}
		if( $nPoI_Xanamech > 0 )		{	$strPoI_Xanamech		= $strImageCheck;	}
		if( $nPoI_Behemoth > 0 )		{	$strPoI_Behemoth		= $strImageCheck;	}
		if( $nPoD_Grimror_Quest > 0 )	{	$strPoD_Grimror_Quest	= $strImageCheck;	}
		if( $nPoD_Grummus > 0 )			{	$strPoD_Grummus			= $strImageCheck;	}
		if( $nPoN_Hedge_Quest > 0 )		{	$strPoN_Hedge_Quest		= $strImageCheck;	}
		if( $nPoNb_Terris_Thule > 0 )	{	$strPoNb_Terris_Thule	= $strImageCheck;	}
	
		// Check if it's an old member
		if( $nOldMember == 1 )
		{
			$strRowType		= "DeletedRow";

			// Allow the deletion of old members
			$strDeleteChar	= ' <a href="form.php?FormName=Character_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=PoP_Tier_1_Flags&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Delete ' . $strCharName . '\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Delete ' . $strCharName . '"><img src="images/delete.gif" border="0" /></a>';
		}
	
		// Check if this character belongs to the logged in User
		$strModify	= "";
		if( ( isset( $strUserName ) ) &&
			( isset( $strNameMain ) ) &&
			( $strUserName == $strNameMain ) )
		{
			$strModify	= '<a href="character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=PoP_Tier_1_Flags&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="images/modify.gif" border="0" />';
		}
		else if( IsAdministrator( $strUserName ) )
		{
			$strModify	= '<a href="character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=PoP_Tier_1_Flags&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="images/modify_others.gif" border="0" />';
		}
	
		echo '
		  <tr	onMouseOver="this.bgColor=\'' . GetRowHighLightColor() . '\'" onMouseOut="this.bgColor=\'\'">
			<td width= "5%" align="center">'				. $strModify			. '</td>
			<td width="15%" class="' . $strRowType . '">'	. $strCharName			. $strDeleteChar . '</td>
			<td width="10%" align="center">'				. $strAny_PoJ_Trial		. '</td>
			<td width="10%" align="center">'				. $strAll_PoJ_Trials	. '</td>
			<td width="10%" align="center">'				. $strPoI_Xanamech		. '</td>
			<td width="10%" align="center">'				. $strPoI_Behemoth		. '</td>
			<td width="10%" align="center">'				. $strPoD_Grimror_Quest	. '</td>
			<td width="10%" align="center">'				. $strPoD_Grummus		. '</td>
			<td width="10%" align="center">'				. $strPoN_Hedge_Quest	. '</td>
			<td width="10%" align="center">'				. $strPoNb_Terris_Thule	. '</td>
		  </tr>
		';
	}
}

?>
