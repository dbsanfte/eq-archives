<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );


// ============================================================================
// The Users class
// ============================================================================
// This class handles the User_Create procedure
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class User_Create
{

	// ========================================================================
	// Constructor
	// ========================================================================
	function User_Create()
	{
		// No code yet
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "User Create";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<!-- End of Header -->
		';
	}
	
	
	
	// ========================================================================
	// Show the body
	// ========================================================================
	// This function will show the user create page
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS		= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['editUserName'];
		$strPassword		= $_GET['editPassword'];
		$strPasswordCheck	= $_GET['editPasswordCheck'];
		$strEMailAddress	= $_GET['editEMailAddress'];
		$strShowEMail		= $_GET['cmbShowEMail'];
		$strTimeZone		= $_GET['cmbTimeZone'];
		$bValidated			= $_GET['cbValidated'];
		// Declare variables
		$strResultCode		= "";

		// Check if the UserName is set
		if( ( isset( $strUserName ) ) &&
			( $strUserName != "" ) )
		{
			// Make sure the UserName is properly formatted (Names start with capital etc.)
			$strUserName	= FormatName( $strUserName );
	
			// Create the user
			$strResultCode	= $this->CreateUser( $strUserName, $strPassword, $strEMailAddress, $strShowEMail, $strTimeZone );
	
			// Check if the user was created
			if( $strResultCode == "USER_CREATED" )
			{
				// Fill the E-mail fields
				$strAddresse	= $strEMailAddress;
				$strSubject		= GetRosterName() . " Verification";
				$strContents	= "Welcome $strUserName,\n" .
								  "\n" .
								  "We thank you for registering to the Guild Roster.\n" .
								  "Your verification code is: \"" . Encrypt( strtoupper($strUserName . $strEMailAddress) ) . "\" (without the quotes).\n" .
								  "You will be asked for this code if you try to login.\n" .
								  "\n" .
								  "Thank you for registering,\n" .
								  "\n" .
								  "The " . GetRosterName() . " crew.\n";
				$strFromSender	= "From: " . GetAdminEmail();
				// Send the verification E-mail
				$bMailed		= mail( $strAddresse, $strSubject, $strContents, $strFromSender );

				// Show the User Created form
				$this->ShowUserCreatedPage( $strUserName, Encrypt( $strPassword ), $strEMailAddress, $bMailed );

				// Abort page
				return;
			}
		}
	
		// Show the create user page
		$this->ShowCreateUserPage( $strUserName, $strPassword, $strPasswordCheck, $strEMailAddress, $strShowEMail, $strTimeZone, $bValidated );

		// Check if there was an error
		if( $strResultCode != "" )
		{
			// Show error message
			print( "	<strong><center>\n" );
			print( "	  <font color=\"#FF3300\"><a>\n" );
			print( "	    Cannot create user \"" . $strUserName . "\"!<br />\n" );
			if( $strResultCode == "USER_EXISTS" )
			{
				print( "	    (User already exists)<br />\n" );
			}
			print( "	  </a></font>\n" );
			print( "	</center></strong>" );
		}
	}



	// ========================================================================
	// Insert a user
	// ========================================================================
	function CreateUser( $strUserName, $strPassword, $strEMailAddress, $strShowEMail, $strTimeZone )
	{
		// Declare variables
		$strResult				= "INSERT_FAILED";
		$strEncryptedPassword	= Encrypt( $strPassword );		// Encrypt the password
		$nUserID				= -1;
		$strSelectUserIDQuery	= "SELECT UserID FROM Users WHERE UserName = '$strUserName'";
		$strInsertQuery			= "INSERT INTO Users \n" .
								  "(UserName, Password, EMailAddress, ShowEMail, TimeZone, Verified) \n" .
								  "VALUES ('$strUserName', '$strEncryptedPassword', '$strEMailAddress', '$strShowEMail', '$strTimeZone', 'No') ";
	
		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Retrieve the UserID for this user
		$nResult	= mysql_query( $strSelectUserIDQuery, $nLinkID );
		$aResult	= mysql_fetch_row( $nResult );
		// Store the UserID
		if( isset( $aResult[0] ) )
		{
			$nUserID	= $aResult[0];
		}
	
		// Check the User already exists
		if( $nUserID >= 0 )
		{
			$strResult	= "USER_EXISTS";
		}
		else
		{
			// Insert the user
			$nResult	= mysql_query( $strInsertQuery, $nLinkID );
			// Check if the insert was succesfull
			if( $nResult == 1 )
			{
				// Retrieve the UserID for this user
				$nResult	= mysql_query( $strSelectUserIDQuery, $nLinkID );
				$aResult	= mysql_fetch_row( $nResult );
				// Store the UserID
				if( isset( $aResult[0] ) )
				{
					$nUserID	= $aResult[0];
				}
	
				// Create the update characters query
				$strUpdateCharactersQuery	= "UPDATE Characters SET UserID = $nUserID WHERE NameMain = '$strUserName'";
				// Update the characters
				$nResult	= mysql_query( $strUpdateCharactersQuery, $nLinkID );
	
				$strResult	= "USER_CREATED";
			}
		}
	
		// Close the connection
		DBDisconnect( $nLinkID );
	
		return $strResult;
	}



	// ========================================================================
	// Show the Create User page
	// ========================================================================
	function ShowCreateUserPage( $strUserName, $strPassword, $strPasswordCheck, $strEMailAddress, $strShowEMail, $strTimeZone, $bValidated )
	{
		echo '
		<!-- JavaScript block has been added here instead of in the header on purpose -->
		<script language="JavaScript">
		<!-- Check if all the fields on the form are valid -->
		function ValidateFields()
		{
			// Check if the UserName is empty
			if( document.formCreateUser.editUserName.value == "" )
			{
				alert( "The UserName is required." );
				document.formCreateUser.editUserName.focus();
				return false;
			}
	
			// Check if the password is empty
			if( document.formCreateUser.editPassword.value == "" )
			{
				alert( "The password is required" );
				document.formCreateUser.editPassword.focus();
				return false;
			}
			// Check if both passwords are the same
			if( document.formCreateUser.editPassword.value != document.formCreateUser.editPasswordCheck.value )
			{
				alert( "The passwords don\'t match, make sure they\'re both the same!" );
				document.formCreateUser.editPassword.focus();
				return false;
			}
	
			// Check if the E-mail address does not contain the @ and .
			var	strEMailFilter	= /^.+@.+\..{2,3}$/;
			if( !( strEMailFilter.test( document.formCreateUser.editEMailAddress.value ) ) )
			{ 
				alert( "Please enter a valid E-mail address." );
				document.formCreateUser.editEMailAddress.focus();
				return false;
			}
			// Check if the E-mail address contains any invalid characters
			var	strIllegalChars	= /[\(\)\<\>\,\;\:\\/\"\[\]]/;
			if( document.formCreateUser.editEMailAddress.value.match( strIllegalChars ) )
			{
				alert( "The E-mail address contains illegal characters." );
				document.formCreateUser.editEMailAddress.focus();
				return false;
			}
	
	
			// Check if the time zone is empty
			if( document.formCreateUser.cmbTimeZone.value == "" )
			{
				alert( "The time zone is required" );
				document.formCreateUser.cmbTimeZone.focus();
				return false;
			}
	
			// Validation complete, all fields are valid
			document.formCreateUser.cbValidated.value	= true;
	
			// Submit the form
			document.formCreateUser.submit();
	
			// Done
			return true;
		};
		</script>
	
		<form name="formCreateUser" method="post" action="form.php?FormName=User_Create" target=Body>
		  <div id="Body" align="center"> 
		  <p><strong><font color="#CCCCCC" size="+3"><em>Create User</em></font></strong></p>
			<p>&nbsp;</p>
			<font color="#FF3300"><b>
			  You are required to use the name of your Main (without the lastname) as your UserName!
			</b></font>
			<table width="60%" border="0">
			  <tr> 
				<td width="20%"></td>
				<td width="30%">User Name:</td>
				<td width="50%"><input name="editUserName" type="text" id="editUserName" value="' . $strUserName . '"></td>
			  </tr>
			  <tr> 
				<td></td>
				<td>Password:</td>
				<td><input name="editPassword" type="password" id="editPassword" value="' . $strPassword . '"></td>
			  </tr>
			  <tr> 
				<td></td>
				<td>Verify Password:</td>
				<td><input name="editPasswordCheck" type="password" id="editPasswordCheck" value="' . $strPasswordCheck . '"></td>
			  </tr>
			  <tr> 
				<td></td>
				<td>E-mail address:</td>
				<td><input name="editEMailAddress" type="text" id="editEMailAddress" value="' . $strEMailAddress . '"  size="40"></td>
			  </tr>
			  <tr> 
				<td width="20%"></td>
				<td width="30%">Show E-Mail address:</td>
				<td width="50%">' . CreateSelectFromEnum( "Users", "ShowEMail", $strShowEMail, "					" ) . '</td>
			  </tr>
			  <tr> 
				<td></td>
				<td>Time zone:</td>
				<td>' . CreateSelectFromEnum( "Users", "TimeZone", $strTimeZone, "					" ) . '</td>
			  </tr>
			</table>
			<br />
			<p>
			  <input name="pbCreate" type="button" id="pbCreate" value="Create" onclick="ValidateFields()">
			</p>
	
		    <!-- Hidden field to store Validation status -->
		    <input name="cbValidated" type="hidden" id="cbValidated" value="' . $bValidated . '">
		  </div>
		</form>
		';
	}



	// ========================================================================
	// Show the Create User page
	// ========================================================================
	function ShowUserCreatedPage( $strUserName, $strPassword, $strEMailAddress, $bMailed )
	{
		echo '
		<form name="formUserCreated" method="post" action="form.php?FormName=User_Verify&UserName=' . $strUserName . '&Password=' . $strPassword . '" target=Body>
		  <div id="Body" align="center"> 
		    <br />
		    <br />
			<strong>
			  <font size="+2" color="#33FF00">
			    User ' . $strUserName . ' created succesfully.<br />
			  </font>
			</strong>
			<br />';
			
		if( !$bMailed )
		{
			echo '
			<font color="#FF3300">
			  The verification E-mail could not be send to ' . $strEMailAddress . '.<br />
			</font>
			<font color="#33FF00">
			  Please E-Mail your <a href="mailto:' . GetAdminEmail() . '?subject=EQRoster verification request for `' . $strUserName . '`&body=Could you please verify `' . $strUserName . '`?%0a%0aThanks">Administrator</a> and ask him to verify you manually.<br />';
		}
		else
		{
			echo '
			<font color="#33FF00">
			  A verification E-mail has been send to ' . $strEMailAddress . '.<br />
			  Verification is required, and you will need the verification code on the next page.<br />';
		}

		echo '
			</font>
			<br />
			<input name="pbContinue" type="submit" id="pbContinue" value="Continue"> <br />
		  </div>
		</form>
		';
	}

}

?>
