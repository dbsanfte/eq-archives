<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );


// ============================================================================
// The PoP Tier 4 Flags class
// ============================================================================
// This class provides an interface to the PoP_Tier_4_Flags table
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class PoP_Tier_4_Flags
{
	var $bShowVerticalScrollbars	= true;

	// ========================================================================
	// Constructor
	// ========================================================================
	function PoP_Tier_4_Flags()
	{
		// No code yet
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "PoP Tier 4 Flags";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<div id="Header">
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td width= "5%"></td>
			<td width="11%">				<b><a href="form.php?FormName=PoP_Tier_4_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=CharName&SortDirection='							. GetSortDirection( $strSortOrder, "CharName",							$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Name\';return true;"													OnMouseOut="window.status=\'\'"	target=Body title="Name"													>Name</a></b></td>
			<td width="14%" align="center">	<b><a href="form.php?FormName=PoP_Tier_4_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=PoAir_Xegony&SortDirection='						. GetSortDirection( $strSortOrder, "PoAir_Xegony",						$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Plane of Air: Xegony\';return true;"									OnMouseOut="window.status=\'\'"	target=Body title="Plane of Air: Xegony"									>Plane of Air<br />Xegony</a></b></td>
			<td width="14%" align="center">	<b><a href="form.php?FormName=PoP_Tier_4_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=PoFire_Fennin_Ro&SortDirection='					. GetSortDirection( $strSortOrder, "PoFire_Fennin_Ro",					$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Plane of Fire: Fennin Ro\';return true;"								OnMouseOut="window.status=\'\'"	target=Body title="Plane of Fire: Fennin Ro"								>Plane of Fire<br />Fennin Ro</a></b></td>
			<td width="14%" align="center">	<b><a href="form.php?FormName=PoP_Tier_4_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=PoWater_Coirnav&SortDirection='					. GetSortDirection( $strSortOrder, "PoWater_Coirnav",					$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Plane of Water: Coirnav\';return true;"								OnMouseOut="window.status=\'\'"	target=Body title="Plane of Water: Coirnav"									>Plane of Water<br />Coirnav</a></b></td>
			<td width="14%" align="center">	<b><a href="form.php?FormName=PoP_Tier_4_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=PoEarthb_The_Rathe&SortDirection='					. GetSortDirection( $strSortOrder, "PoEarthb_The_Rathe",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Plane of Earth-b: The Rathe\';return true;"							OnMouseOut="window.status=\'\'"	target=Body title="Plane of Earth-b: The Rathe"								>Plane of Earth-b<br />The Rathe</a></b></td>
			<td width="14%" align="center">	<b><a href="form.php?FormName=PoP_Tier_4_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=PoTime_Time_Phased_Quintessence&SortDirection='	. GetSortDirection( $strSortOrder, "PoTime_Time_Phased_Quintessence",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Plane of Time: Alt. Access (Time Phased Quintessence)\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Plane of Time: Alt. Access (Time Phased Quintessence)"	>Plane of Time<br />Alt. Access</a></b></td>
			<td width="14%" align="center">	<b><a href="form.php?FormName=PoP_Tier_4_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=PoTime_Access&SortDirection='						. GetSortDirection( $strSortOrder, "PoTime_Access",						$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Plane of Time: Access\';return true;"									OnMouseOut="window.status=\'\'"	target=Body title="Plane of Time: Access"									>Plane of Time<br />Access</a></b></td>
		  </tr>
		</table>
		</div>
		<!-- End of Header -->
		';
	}
	
	
	
	// ========================================================================
	// Show all the records on screen
	// ========================================================================
	// This function will loop through all the records in the database table,
	// and create a html table entry for each one of them.
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS		= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];
		$strClassFilter		= $_GET['ClassFilter'];

		// Declare variables
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT CharName, NameMain, PoAir_Xegony, PoFire_Fennin_Ro, PoWater_Coirnav, PoEarthb_The_Rathe, PoTime_Time_Phased_Quintessence, OldMember \n" .
							  "FROM PoP_Tier_4_Flags \n" .
							  "LEFT JOIN Characters ON (PoP_Tier_4_Flags.CharID = Characters.CharID) \n" .
							  "WHERE (	PoAir_Xegony > 0                    OR \n" .
							  "			PoFire_Fennin_Ro > 0                OR \n" .
							  "			PoWater_Coirnav > 0                 OR \n" .
							  "			PoEarthb_The_Rathe > 0              OR \n" .
							  "         PoTime_Time_Phased_Quintessence > 0 )  \n";

		// Check if we should set a class filter
		if( ( isset( $strClassFilter ) ) &&
			( $strClassFilter != "" ) &&
			( $strClassFilter != "<<All>>" ) )
		{
			$strSelectQuery	.= "AND Class = '" . $strClassFilter . "'";
		} 

		// Check if we should use the default sort order
		if( ( !isset( $strSortOrder ) ) ||
			( $strSortOrder == "" ) )
		{
			// Default sort on Character name
			$strSortOrder	= "CharName"; 
		}
		
		// Check if we're sorting on PoTime_Access
		if( $strSortOrder == "PoTime_Access" )
		{
			// Default sort on Character name
			$strSortOrder	= "(PoAir_Xegony + PoFire_Fennin_Ro + PoWater_Coirnav + PoEarthb_The_Rathe + (4*PoTime_Time_Phased_Quintessence))"; 
		}

		// Sorting on all numbers should be reversed (Desc first, then Asc)
		$strModifiedSortDirection	= $strSortDirection;
		if( $strSortOrder != "CharName" )
		{
			// Switch the sort order around
			if( $strModifiedSortDirection == "DESC" )
			{
				$strModifiedSortDirection	= "";
			}
			else
			{
				$strModifiedSortDirection	= "DESC";
			}
		}
	
		// Add the sort order
		$strSelectQuery		.= "ORDER BY " . $strSortOrder . " " . $strModifiedSortDirection . ", CharName";
	
		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
		<div id="Body">
		<table id="RosterTable" width="100%" border="0" cellpadding="0" cellspacing="0">
		';
	
		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex								= 0;
			$strCharName						= $aResult[$nIndex++];
			$strNameMain						= $aResult[$nIndex++];
			$nPoAir_Xegony						= $aResult[$nIndex++];
			$nPoFire_Fennin_Ro					= $aResult[$nIndex++];
			$nPoWater_Coirnav					= $aResult[$nIndex++];
			$nPoEarthb_The_Rathe				= $aResult[$nIndex++];
			$nPoTime_Time_Phased_Quintessence	= $aResult[$nIndex++];
			$nOldMember							= $aResult[$nIndex++];
	
			// Only show old members for the administrator
			if( ( $strCharName != "" ) &&
				( ( $nOldMember == 0 ) ||
				  ( IsAdministrator( $strUserName ) ) ) )
			{
				// Show the BoT Flag parts
				$this->ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nPoAir_Xegony, $nPoFire_Fennin_Ro, $nPoWater_Coirnav, $nPoEarthb_The_Rathe, $nPoTime_Time_Phased_Quintessence, $nOldMember, $strRowType );
		
				// Switch RowType, so the rows alternate	
				if( $strRowType == "OddRow" )
				{
					$strRowType	= "EvenRow";
				}
				else
				{
					$strRowType	= "OddRow";
				}
			}
		}
	
		// End the table
		echo '
		</table>
		</div>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );
	}
	
	
	
	// ========================================================================
	// Show a record
	// ========================================================================
	// This function will create a html table row for a record in the table
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// In:  Variables containing the data to show 
	// ========================================================================
	function ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nPoAir_Xegony, $nPoFire_Fennin_Ro, $nPoWater_Coirnav, $nPoEarthb_The_Rathe, $nPoTime_Time_Phased_Quintessence, $nOldMember, $strRowType )
	{
		// Declare variables
		$strImageCheck						= '<img src="images/check.gif" border="0" />';
		$strDeleteChar						= "";
		$strPoAir_Xegony					= "";
		$strPoFire_Fennin_Ro				= "";
		$strPoWater_Coirnav					= "";
		$strPoEarthb_The_Rathe				= "";
		$strPoTime_Access					= "";
		$strPoTime_Time_Phased_Quintessence	= "";
	
		// Set the check-image for all filled variables
		if( $nPoAir_Xegony > 0 )					{	$strPoAir_Xegony					= $strImageCheck;	}
		if( $nPoFire_Fennin_Ro > 0 )				{	$strPoFire_Fennin_Ro				= $strImageCheck;	}
		if( $nPoWater_Coirnav > 0 )					{	$strPoWater_Coirnav					= $strImageCheck;	}
		if( $nPoEarthb_The_Rathe > 0 )				{	$strPoEarthb_The_Rathe				= $strImageCheck;	}
		if( $nPoTime_Time_Phased_Quintessence > 0 )	{	$strPoTime_Time_Phased_Quintessence	= $strImageCheck;	}

		// Check for PoTime Access
		if( ( ( $nPoAir_Xegony > 0 ) &&
			  ( $nPoFire_Fennin_Ro > 0 ) &&
			  ( $nPoWater_Coirnav > 0 ) &&
			  ( $nPoEarthb_The_Rathe > 0 ) ) ||
			( $nPoTime_Time_Phased_Quintessence > 0 ) )
		{
			$strPoTime_Access	= $strImageCheck;
		}

		// Check if it's an old member
		if( $nOldMember == 1 )
		{
			$strRowType		= "DeletedRow";

			// Allow the deletion of old members
			$strDeleteChar	= ' <a href="form.php?FormName=Character_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=PoP_Tier_4_Flags&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Delete ' . $strCharName . '\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Delete ' . $strCharName . '"><img src="images/delete.gif" border="0" /></a>';
		}
	
		// Check if this character belongs to the logged in User
		$strModify	= "";
		if( ( isset( $strUserName ) ) &&
			( isset( $strNameMain ) ) &&
			( $strUserName == $strNameMain ) )
		{
			$strModify	= '<a href="character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=PoP_Tier_4_Flags&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="images/modify.gif" border="0" />';
		}
		else if( IsAdministrator( $strUserName ) )
		{
			$strModify	= '<a href="character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=PoP_Tier_4_Flags&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="images/modify_others.gif" border="0" />';
		}
	
		echo '
		  <tr	onMouseOver="this.bgColor=\'' . GetRowHighLightColor() . '\'" onMouseOut="this.bgColor=\'\'">
			<td width= "5%" align="center">'				. $strModify							. '</td>
			<td width="11%" class="' . $strRowType . '">'	. $strCharName							. $strDeleteChar . '</td>
			<td width="14%" align="center">'				. $strPoAir_Xegony						. '</td>
			<td width="14%" align="center">'				. $strPoFire_Fennin_Ro					. '</td>
			<td width="14%" align="center">'				. $strPoWater_Coirnav					. '</td>
			<td width="14%" align="center">'				. $strPoEarthb_The_Rathe				. '</td>
			<td width="14%" align="center">'				. $strPoTime_Time_Phased_Quintessence	. '</td>
			<td width="14%" align="center">'				. $strPoTime_Access						. '</td>
		  </tr>
		';
	}
}

?>
