<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );


// ============================================================================
// The PoP Tier 3 Flags class
// ============================================================================
// This class provides an interface to the PoP_Tier_3_Flags table
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class PoP_Tier_3_Flags
{
	var $bShowVerticalScrollbars	= true;

	// ========================================================================
	// Constructor
	// ========================================================================
	function PoP_Tier_3_Flags()
	{
		// No code yet
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "PoP Tier 3 Flags";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<div id="Header">
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td width= "5%"></td>
			<td width="11%">				<b><a href="form.php?FormName=PoP_Tier_3_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=CharName&SortDirection='							. GetSortDirection( $strSortOrder, "CharName",							$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Name\';return true;"										OnMouseOut="window.status=\'\'"	target=Body title="Name"										>Name</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=PoP_Tier_3_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=HoH_Trial1_RyddaDar&SortDirection='				. GetSortDirection( $strSortOrder, "HoH_Trial1_RyddaDar",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Halls of Honor Trial1: RyddaDar (Dragon)\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Halls of Honor Trial1: RyddaDar (Dragon)"	>HoH<br />Trial1</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=PoP_Tier_3_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=HoH_Trial2_Ogre&SortDirection='					. GetSortDirection( $strSortOrder, "HoH_Trial2_Ogre",					$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Halls of Honor Trial2: Ogre (Villagers)\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Halls of Honor Trial2: Ogre (Villagers)"		>HoH<br />Trial2</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=PoP_Tier_3_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=HoH_Trial3_Madmen&SortDirection='					. GetSortDirection( $strSortOrder, "HoH_Trial3_Madmen",					$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Halls of Honor Trial3: Madmen (Virgins)\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Halls of Honor Trial3: Madmen (Virgins)"		>HoH<br />Trial3</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=PoP_Tier_3_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=HoHb_Mithanial_Marr&SortDirection='				. GetSortDirection( $strSortOrder, "HoHb_Mithanial_Marr",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Halls of Honor-b: Mithanial Marr\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Halls of Honor-b: Mithanial Marr"			>HoHb<br />M.Marr</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=PoP_Tier_3_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=PoTactics_Tallon_Zek&SortDirection='				. GetSortDirection( $strSortOrder, "PoTactics_Tallon_Zek",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Plane of Tactics: Tallon Zek\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Plane of Tactics: Tallon Zek"				>Tactics<br />T.Zek</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=PoP_Tier_3_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=PoTactics_Vallon_Zek&SortDirection='				. GetSortDirection( $strSortOrder, "PoTactics_Vallon_Zek",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Plane of Tactics: Vallon Zek\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Plane of Tactics: Vallon Zek"				>Tactics<br />V.Zek</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=PoP_Tier_3_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=PoTactics_Rallos_Zek_Quest&SortDirection='			. GetSortDirection( $strSortOrder, "PoTactics_Rallos_Zek_Quest",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Plane of Tactics: Rallos Zek Quest\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Plane of Tactics: Rallos Zek Quest"			>Tactics<br />R.Zek</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=PoP_Tier_3_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=BoT_Rescue_Karana_Quest&SortDirection='			. GetSortDirection( $strSortOrder, "BoT_Rescue_Karana_Quest",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Bastion of Thunder: Rescue Karana Quest\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Bastion of Thunder: Rescue Karana Quest"		>BoT<br />Karana</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=PoP_Tier_3_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=SolRoTower_Jiva&SortDirection='					. GetSortDirection( $strSortOrder, "SolRoTower_Jiva",					$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Sol-Ro Tower: Jiva\';return true;"							OnMouseOut="window.status=\'\'"	target=Body title="Sol-Ro Tower: Jiva"							>SolRo<br />Jiva</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=PoP_Tier_3_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=SolRoTower_Xuzl&SortDirection='					. GetSortDirection( $strSortOrder, "SolRoTower_Xuzl",					$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Sol-Ro Tower: Xuzl\';return true;"							OnMouseOut="window.status=\'\'"	target=Body title="Sol-Ro Tower: Xuzl"							>SolRo<br />Xuzl</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=PoP_Tier_3_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=SolRoTower_Arlyxir&SortDirection='					. GetSortDirection( $strSortOrder, "SolRoTower_Arlyxir",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Sol-Ro Tower: Arlyxir\';return true;"						OnMouseOut="window.status=\'\'"	target=Body title="Sol-Ro Tower: Arlyxir"						>SolRo<br />Arlyxir</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=PoP_Tier_3_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=SolRoTower_Rizlona&SortDirection='					. GetSortDirection( $strSortOrder, "SolRoTower_Rizlona",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Sol-Ro Tower: Rizlona\';return true;"						OnMouseOut="window.status=\'\'"	target=Body title="Sol-Ro Tower: Rizlona"						>SolRo<br />Rizlona</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=PoP_Tier_3_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=SolRoTower_Protector_of_Dresolik&SortDirection='	. GetSortDirection( $strSortOrder, "SolRoTower_Protector_of_Dresolik",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Sol-Ro Tower: Protector of Dresolik\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Sol-Ro Tower: Protector of Dresolik"			>SolRo<br />Dresolik</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=PoP_Tier_3_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=SolRoTower_Solusek_Ro&SortDirection='				. GetSortDirection( $strSortOrder, "SolRoTower_Solusek_Ro",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Sol-Ro Tower: Solusek Ro\';return true;"					OnMouseOut="window.status=\'\'"	target=Body title="Sol-Ro Tower: Solusek Ro"					>SolRo<br />Sol.Ro</a></b></td>
		  </tr>
		</table>
		</div>
		<!-- End of Header -->
		';
	}
	
	
	
	// ========================================================================
	// Show all the records on screen
	// ========================================================================
	// This function will loop through all the records in the database table,
	// and create a html table entry for each one of them.
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS		= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];
		$strClassFilter		= $_GET['ClassFilter'];

		// Declare variables
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT CharName, NameMain, HoH_Trial1_RyddaDar, HoH_Trial2_Ogre, HoH_Trial3_Madmen, HoHb_Mithanial_Marr, PoTactics_Tallon_Zek, PoTactics_Vallon_Zek, PoTactics_Rallos_Zek_Quest, BoT_Rescue_Karana_Quest, SolRoTower_Jiva, SolRoTower_Xuzl, SolRoTower_Arlyxir, SolRoTower_Rizlona, SolRoTower_Protector_of_Dresolik, SolRoTower_Solusek_Ro, OldMember \n" .
							  "FROM PoP_Tier_3_Flags \n" .
							  "LEFT JOIN Characters ON (PoP_Tier_3_Flags.CharID = Characters.CharID) \n" .
							  "WHERE ( HoH_Trial1_RyddaDar > 0				OR \n" .
							  "        HoH_Trial2_Ogre > 0					OR \n" .
							  "        HoH_Trial3_Madmen > 0				OR \n" .
							  "        HoHb_Mithanial_Marr > 0				OR \n" .
							  "        PoTactics_Tallon_Zek > 0				OR \n" .
							  "        PoTactics_Vallon_Zek > 0				OR \n" .
							  "        PoTactics_Rallos_Zek_Quest > 0		OR \n" .
							  "        BoT_Rescue_Karana_Quest > 0			OR \n" .
							  "        SolRoTower_Jiva > 0					OR \n" .
							  "        SolRoTower_Xuzl > 0					OR \n" .
							  "        SolRoTower_Arlyxir > 0				OR \n" .
							  "        SolRoTower_Rizlona > 0				OR \n" .
							  "        SolRoTower_Protector_of_Dresolik > 0	OR \n" .
							  "        SolRoTower_Solusek_Ro > 0 )			   \n";

		// Check if we should set a class filter
		if( ( isset( $strClassFilter ) ) &&
			( $strClassFilter != "" ) &&
			( $strClassFilter != "<<All>>" ) )
		{
			$strSelectQuery	.= "AND Class = '" . $strClassFilter . "'";
		} 

		// Check if we should use the default sort order
		if( ( !isset( $strSortOrder ) ) ||
			( $strSortOrder == "" ) )
		{
			// Default sort on Character name
			$strSortOrder	= "CharName"; 
		}

		// Sorting on all numbers should be reversed (Desc first, then Asc)
		$strModifiedSortDirection	= $strSortDirection;
		if( $strSortOrder != "CharName" )
		{
			// Switch the sort order around
			if( $strModifiedSortDirection == "DESC" )
			{
				$strModifiedSortDirection	= "";
			}
			else
			{
				$strModifiedSortDirection	= "DESC";
			}
		}
	
		// Add the sort order
		$strSelectQuery		.= "ORDER BY " . $strSortOrder . " " . $strModifiedSortDirection . ", CharName";
	
		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
		<div id="Body">
		<table id="RosterTable" width="100%" border="0" cellpadding="0" cellspacing="0">
		';
	
		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex								= 0;
			$strCharName						= $aResult[$nIndex++];
			$strNameMain						= $aResult[$nIndex++];
			$nHoH_Trial1_RyddaDar				= $aResult[$nIndex++];
			$nHoH_Trial2_Ogre					= $aResult[$nIndex++];
			$nHoH_Trial3_Madmen					= $aResult[$nIndex++];
			$nHoHb_Mithanial_Marr				= $aResult[$nIndex++];
			$nPoTactics_Tallon_Zek				= $aResult[$nIndex++];
			$nPoTactics_Vallon_Zek				= $aResult[$nIndex++];
			$nPoTactics_Rallos_Zek_Quest		= $aResult[$nIndex++];
			$nBoT_Rescue_Karana_Quest			= $aResult[$nIndex++];
			$nSolRoTower_Jiva					= $aResult[$nIndex++];
			$nSolRoTower_Xuzl					= $aResult[$nIndex++];
			$nSolRoTower_Arlyxir				= $aResult[$nIndex++];
			$nSolRoTower_Rizlona				= $aResult[$nIndex++];
			$nSolRoTower_Protector_of_Dresolik	= $aResult[$nIndex++];
			$nSolRoTower_Solusek_Ro				= $aResult[$nIndex++];
			$nOldMember							= $aResult[$nIndex++];
	
			// Only show old members for the administrator
			if( ( $strCharName != "" ) &&
				( ( $nOldMember == 0 ) ||
				  ( IsAdministrator( $strUserName ) ) ) )
			{
				// Show the BoT Flag parts
				$this->ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nHoH_Trial1_RyddaDar, $nHoH_Trial2_Ogre, $nHoH_Trial3_Madmen, $nHoHb_Mithanial_Marr, $nPoTactics_Tallon_Zek, $nPoTactics_Vallon_Zek, $nPoTactics_Rallos_Zek_Quest, $nBoT_Rescue_Karana_Quest, $nSolRoTower_Jiva, $nSolRoTower_Xuzl, $nSolRoTower_Arlyxir, $nSolRoTower_Rizlona, $nSolRoTower_Protector_of_Dresolik, $nSolRoTower_Solusek_Ro, $nOldMember, $strRowType );
		
				// Switch RowType, so the rows alternate	
				if( $strRowType == "OddRow" )
				{
					$strRowType	= "EvenRow";
				}
				else
				{
					$strRowType	= "OddRow";
				}
			}
		}
	
		// End the table
		echo '
		</table>
		</div>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );
	}
	
	
	
	// ========================================================================
	// Show a record
	// ========================================================================
	// This function will create a html table row for a record in the table
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// In:  Variables containing the data to show 
	// ========================================================================
	function ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nHoH_Trial1_RyddaDar, $nHoH_Trial2_Ogre, $nHoH_Trial3_Madmen, $nHoHb_Mithanial_Marr, $nPoTactics_Tallon_Zek, $nPoTactics_Vallon_Zek, $nPoTactics_Rallos_Zek_Quest, $nBoT_Rescue_Karana_Quest, $nSolRoTower_Jiva, $nSolRoTower_Xuzl, $nSolRoTower_Arlyxir, $nSolRoTower_Rizlona, $nSolRoTower_Protector_of_Dresolik, $nSolRoTower_Solusek_Ro, $nOldMember, $strRowType )
	{
		// Declare variables
		$strImageCheck							= '<img src="images/check.gif" border="0" />';
		$strDeleteChar							= "";
		$strHoH_Trial1_RyddaDar					= "";
		$strHoH_Trial2_Ogre						= "";
		$strHoH_Trial3_Madmen					= "";
		$strHoHb_Mithanial_Marr					= "";
		$strPoTactics_Tallon_Zek				= "";
		$strPoTactics_Vallon_Zek				= "";
		$strPoTactics_Rallos_Zek_Quest			= "";
		$strBoT_Rescue_Karana_Quest				= "";
		$strSolRoTower_Jiva						= "";
		$strSolRoTower_Xuzl						= "";
		$strSolRoTower_Arlyxir					= "";
		$strSolRoTower_Rizlona					= "";
		$strSolRoTower_Protector_of_Dresolik	= "";
		$strSolRoTower_Solusek_Ro				= "";

		// Set the check-image for all filled variables
		if( $nHoH_Trial1_RyddaDar > 0 )					{	$strHoH_Trial1_RyddaDar					= $strImageCheck;	}
		if( $nHoH_Trial2_Ogre > 0 )						{	$strHoH_Trial2_Ogre						= $strImageCheck;	}
		if( $nHoH_Trial3_Madmen > 0 )					{	$strHoH_Trial3_Madmen					= $strImageCheck;	}
		if( $nHoHb_Mithanial_Marr > 0 )					{	$strHoHb_Mithanial_Marr					= $strImageCheck;	}
		if( $nPoTactics_Tallon_Zek > 0 )				{	$strPoTactics_Tallon_Zek				= $strImageCheck;	}
		if( $nPoTactics_Vallon_Zek > 0 )				{	$strPoTactics_Vallon_Zek				= $strImageCheck;	}
		if( $nPoTactics_Rallos_Zek_Quest > 0 )			{	$strPoTactics_Rallos_Zek_Quest			= $strImageCheck;	}
		if( $nBoT_Rescue_Karana_Quest > 0 )				{	$strBoT_Rescue_Karana_Quest				= $strImageCheck;	}
		if( $nSolRoTower_Jiva > 0 )						{	$strSolRoTower_Jiva						= $strImageCheck;	}
		if( $nSolRoTower_Xuzl > 0 )						{	$strSolRoTower_Xuzl						= $strImageCheck;	}
		if( $nSolRoTower_Arlyxir > 0 )					{	$strSolRoTower_Arlyxir					= $strImageCheck;	}
		if( $nSolRoTower_Rizlona > 0 )					{	$strSolRoTower_Rizlona					= $strImageCheck;	}
		if( $nSolRoTower_Protector_of_Dresolik > 0 )	{	$strSolRoTower_Protector_of_Dresolik	= $strImageCheck;	}
		if( $nSolRoTower_Solusek_Ro > 0 )				{	$strSolRoTower_Solusek_Ro				= $strImageCheck;	}
	
		// Check if it's an old member
		if( $nOldMember == 1 )
		{
			$strRowType		= "DeletedRow";

			// Allow the deletion of old members
			$strDeleteChar	= ' <a href="form.php?FormName=Character_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=PoP_Tier_3_Flags&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Delete ' . $strCharName . '\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Delete ' . $strCharName . '"><img src="images/delete.gif" border="0" /></a>';
		}
	
		// Check if this character belongs to the logged in User
		$strModify	= "";
		if( ( isset( $strUserName ) ) &&
			( isset( $strNameMain ) ) &&
			( $strUserName == $strNameMain ) )
		{
			$strModify	= '<a href="character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=PoP_Tier_3_Flags&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="images/modify.gif" border="0" />';
		}
		else if( IsAdministrator( $strUserName ) )
		{
			$strModify	= '<a href="character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=PoP_Tier_3_Flags&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="images/modify_others.gif" border="0" />';
		}
	
		echo '
		  <tr	onMouseOver="this.bgColor=\'' . GetRowHighLightColor() . '\'" onMouseOut="this.bgColor=\'\'">
			<td width= "5%" align="center">'				. $strModify							. '</td>
			<td width="11%" class="' . $strRowType . '">'	. $strCharName							. $strDeleteChar . '</td>
			<td width= "6%" align="center">'				. $strHoH_Trial1_RyddaDar				. '</td>
			<td width= "6%" align="center">'				. $strHoH_Trial2_Ogre					. '</td>
			<td width= "6%" align="center">'				. $strHoH_Trial3_Madmen					. '</td>
			<td width= "6%" align="center">'				. $strHoHb_Mithanial_Marr				. '</td>
			<td width= "6%" align="center">'				. $strPoTactics_Tallon_Zek				. '</td>
			<td width= "6%" align="center">'				. $strPoTactics_Vallon_Zek				. '</td>
			<td width= "6%" align="center">'				. $strPoTactics_Rallos_Zek_Quest		. '</td>
			<td width= "6%" align="center">'				. $strBoT_Rescue_Karana_Quest			. '</td>
			<td width= "6%" align="center">'				. $strSolRoTower_Jiva					. '</td>
			<td width= "6%" align="center">'				. $strSolRoTower_Xuzl					. '</td>
			<td width= "6%" align="center">'				. $strSolRoTower_Arlyxir				. '</td>
			<td width= "6%" align="center">'				. $strSolRoTower_Rizlona				. '</td>
			<td width= "6%" align="center">'				. $strSolRoTower_Protector_of_Dresolik	. '</td>
			<td width= "6%" align="center">'				. $strSolRoTower_Solusek_Ro				. '</td>
		  </tr>
		';
	}

}

?>
