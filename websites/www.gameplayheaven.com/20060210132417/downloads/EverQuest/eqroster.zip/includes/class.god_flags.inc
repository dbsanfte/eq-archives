<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );


// ============================================================================
// The GoD Flags class
// ============================================================================
// This class provides an interface to the GoD_Flags table
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class GoD_Flags
{
	var $bShowVerticalScrollbars	= true;

	// ========================================================================
	// Constructor
	// ========================================================================
	function GoD_Flags()
	{
		// No code yet
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "GoD Flags";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<div id="Header">
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td width= "5%"></td>
			<td width= "7%">				<b><a href="form.php?FormName=GoD_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=CharName&SortDirection='					. GetSortDirection( $strSortOrder, "CharName",					$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Name\';return true;"						OnMouseOut="window.status=\'\'"	target=Body title="Name"						>Name</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=GoD_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Purifying_Plant&SortDirection='			. GetSortDirection( $strSortOrder, "Purifying_Plant",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Purifying Plant\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Purifying Plant"				>Purif.<br />Plant</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=GoD_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Emanating_Furnace&SortDirection='			. GetSortDirection( $strSortOrder, "Emanating_Furnace",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Emanating Furnace\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Emanating Furnace"			>Eman.<br />Furnace</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=GoD_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Lair_of_Trapped_Ones&SortDirection='		. GetSortDirection( $strSortOrder, "Lair_of_Trapped_Ones",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Lair of Trapped Ones\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Lair of Trapped Ones"		>Lair of<br />Tr.Ones</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=GoD_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Pool_of_Sludge&SortDirection='			. GetSortDirection( $strSortOrder, "Pool_of_Sludge",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Pool of Sludge\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Pool of Sludge"				>Pool of<br />Sludge</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=GoD_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Smith_Rondo&SortDirection='				. GetSortDirection( $strSortOrder, "Smith_Rondo",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Smith Rondo\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Smith Rondo"					>Smith<br />Rondo</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=GoD_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Vxed&SortDirection='						. GetSortDirection( $strSortOrder, "Vxed",						$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Vxed\';return true;"						OnMouseOut="window.status=\'\'"	target=Body title="Vxed"						>Vxed</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=GoD_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Tipt&SortDirection='						. GetSortDirection( $strSortOrder, "Tipt",						$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Tipt\';return true;"						OnMouseOut="window.status=\'\'"	target=Body title="Tipt"						>Tipt</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=GoD_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Vrex_Barxt_Qurat&SortDirection='			. GetSortDirection( $strSortOrder, "Vrex_Barxt_Qurat",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Vrex Barxt Qurat\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Vrex Barxt Qurat"			>V.Barxt<br />Qurat</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=GoD_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Keeper_of_the_Altar&SortDirection='		. GetSortDirection( $strSortOrder, "Keeper_of_the_Altar",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Keeper of the Altar\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Keeper of the Altar"			>Keeper<br />ot Altar</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=GoD_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Noqufiel_in_Inktuta&SortDirection='		. GetSortDirection( $strSortOrder, "Noqufiel_in_Inktuta",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Noqufiel in Inktuta\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Noqufiel in Inktuta"			>Noquf.<br />Inktuta</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=GoD_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Cynosure_Kvanjji&SortDirection='			. GetSortDirection( $strSortOrder, "Cynosure_Kvanjji",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Cynosure Kvanjji\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Cynosure Kvanjji"			>Cynos.<br />Kvanjji</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=GoD_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Ixt_Hsek_Syat&SortDirection='				. GetSortDirection( $strSortOrder, "Ixt_Hsek_Syat",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Ixt Hsek Syat\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Ixt Hsek Syat"				>Ixt H.<br />Syat</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=GoD_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=High_Priest_Nkosi_Bakari&SortDirection='	. GetSortDirection( $strSortOrder, "High_Priest_Nkosi_Bakari",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by High Priest Nkosi Bakari\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="High Priest Nkosi Bakari"	>Nkosi<br />Bakari</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=GoD_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=ZunMuram_Tkarish_Zyk&SortDirection='		. GetSortDirection( $strSortOrder, "ZunMuram_Tkarish_Zyk",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by ZunMuram Tkarish Zyk\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="ZunMuram Tkarish Zyk"		>Z.Muram<br />Tkar.Zyk</a></b></td>
		  </tr>
		</table>
		</div>
		<!-- End of Header -->
		';
	}
	
	
	
	// ========================================================================
	// Show all the records on screen
	// ========================================================================
	// This function will loop through all the records in the database table,
	// and create a html table entry for each one of them.
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS		= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];
		$strClassFilter		= $_GET['ClassFilter'];

		// Declare variables
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT CharName, NameMain, Purifying_Plant, Emanating_Furnace, Lair_of_Trapped_Ones, Pool_of_Sludge, Smith_Rondo, Vxed, Tipt, Vrex_Barxt_Qurat, Keeper_of_the_Altar, Noqufiel_in_Inktuta, Cynosure_Kvanjji, Ixt_Hsek_Syat, High_Priest_Nkosi_Bakari, ZunMuram_Tkarish_Zyk, OldMember \n" .
							  "FROM GoD_Flags \n" .
							  "LEFT JOIN Characters ON (GoD_Flags.CharID = Characters.CharID) \n" .
							  "WHERE ( Purifying_Plant > 0			OR \n" .
							  "        Emanating_Furnace > 0		OR \n" .
							  "        Lair_of_Trapped_Ones > 0		OR \n" .
							  "        Pool_of_Sludge > 0			OR \n" .
							  "        Smith_Rondo > 0				OR \n" .
							  "        Vxed > 0						OR \n" .
							  "        Tipt > 0						OR \n" .
							  "        Vrex_Barxt_Qurat > 0			OR \n" .
							  "        Keeper_of_the_Altar > 0		OR \n" .
							  "        Noqufiel_in_Inktuta > 0		OR \n" .
							  "        Cynosure_Kvanjji > 0			OR \n" .
							  "        Ixt_Hsek_Syat > 0			OR \n" .
							  "        High_Priest_Nkosi_Bakari > 0	OR \n" .
							  "        ZunMuram_Tkarish_Zyk > 0	)	   \n";
	
		// Check if we should set a class filter
		if( ( isset( $strClassFilter ) ) &&
			( $strClassFilter != "" ) &&
			( $strClassFilter != "<<All>>" ) )
		{
			$strSelectQuery	.= "AND Class = '" . $strClassFilter . "'";
		} 

		// Check if we should use the default sort order
		if( ( !isset( $strSortOrder ) ) ||
			( $strSortOrder == "" ) )
		{
			// Default sort on Character name
			$strSortOrder	= "CharName"; 
		}

		// Sorting on all numbers should be reversed (Desc first, then Asc)
		$strModifiedSortDirection	= $strSortDirection;
		if( $strSortOrder != "CharName" )
		{
			// Switch the sort order around
			if( $strModifiedSortDirection == "DESC" )
			{
				$strModifiedSortDirection	= "";
			}
			else
			{
				$strModifiedSortDirection	= "DESC";
			}
		}
	
		// Add the sort order
		$strSelectQuery		.= "ORDER BY " . $strSortOrder . " " . $strModifiedSortDirection . ", CharName";

		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
		<div id="Body">
		<table id="RosterTable" width="100%" border="0" cellpadding="0" cellspacing="0">
		';
	
		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex						= 0;
			$strCharName				= $aResult[$nIndex++];
			$strNameMain				= $aResult[$nIndex++];
			$nPurifying_Plant			= $aResult[$nIndex++];
			$nEmanating_Furnace			= $aResult[$nIndex++];
			$nLair_of_Trapped_Ones		= $aResult[$nIndex++];
			$nPool_of_Sludge			= $aResult[$nIndex++];
			$nSmith_Rondo				= $aResult[$nIndex++];
			$nVxed						= $aResult[$nIndex++];
			$nTipt						= $aResult[$nIndex++];
			$nVrex_Barxt_Qurat			= $aResult[$nIndex++];
			$nKeeper_of_the_Altar		= $aResult[$nIndex++];
			$nNoqufiel_in_Inktuta		= $aResult[$nIndex++];
			$nCynosure_Kvanjji			= $aResult[$nIndex++];
			$nZunMuram_Tkarish_Zyk		= $aResult[$nIndex++];
			$nIxt_Hsek_Syat				= $aResult[$nIndex++];
			$nHigh_Priest_Nkosi_Bakari	= $aResult[$nIndex++];
			$nOldMember					= $aResult[$nIndex++];
	
			// Only show old members for the administrator
			if( ( $strCharName != "" ) &&
				( ( $nOldMember == 0 ) ||
				  ( IsAdministrator( $strUserName ) ) ) )
			{
				// Show the BoT Flag parts
				$this->ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nPurifying_Plant, $nEmanating_Furnace, $nLair_of_Trapped_Ones, $nPool_of_Sludge, $nSmith_Rondo, $nVxed, $nTipt, $nVrex_Barxt_Qurat, $nKeeper_of_the_Altar, $nNoqufiel_in_Inktuta, $nCynosure_Kvanjji, $nIxt_Hsek_Syat, $nHigh_Priest_Nkosi_Bakari, $nZunMuram_Tkarish_Zyk, $nOldMember, $strRowType );
		
				// Switch RowType, so the rows alternate	
				if( $strRowType == "OddRow" )
				{
					$strRowType	= "EvenRow";
				}
				else
				{
					$strRowType	= "OddRow";
				}
			}
		}
	
		// End the table
		echo '
		</table>
		</div>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );
	}
	
	
	
	// ========================================================================
	// Show a record
	// ========================================================================
	// This function will create a html table row for a record in the table
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// In:  Variables containing the data to show 
	// ========================================================================
	function ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nPurifying_Plant, $nEmanating_Furnace, $nLair_of_Trapped_Ones, $nPool_of_Sludge, $nSmith_Rondo, $nVxed, $nTipt, $nVrex_Barxt_Qurat, $nKeeper_of_the_Altar, $nNoqufiel_in_Inktuta, $nCynosure_Kvanjji, $nIxt_Hsek_Syat, $nHigh_Priest_Nkosi_Bakari, $nZunMuram_Tkarish_Zyk, $nOldMember, $strRowType )
	{
		// Declare variables
		$strImageCheck					= '<img src="images/check.gif" border="0" />';
		$strDeleteChar					= '';
		$strPurifying_Plant				= '';
		$strEmanating_Furnace			= '';
		$strLair_of_Trapped_Ones		= '';
		$strPool_of_Sludge				= '';
		$strSmith_Rondo					= '';
		$strVxed						= '';
		$strTipt						= '';
		$strVrex_Barxt_Qurat			= '';
		$strKeeper_of_the_Altar			= '';
		$strNoqufiel_in_Inktuta			= '';
		$strCynosure_Kvanjji			= '';
		$strIxt_Hsek_Syat				= '';
		$strHigh_Priest_Nkosi_Bakari	= '';
		$strZunMuram_Tkarish_Zyk		= '';
	
		// Set the check-image for all filled variables
		if( $nPurifying_Plant > 0 )				{	$strPurifying_Plant				= $strImageCheck;	}
		if( $nEmanating_Furnace > 0 )			{	$strEmanating_Furnace			= $strImageCheck;	}
		if( $nLair_of_Trapped_Ones > 0 )		{	$strLair_of_Trapped_Ones		= $strImageCheck;	}
		if( $nPool_of_Sludge > 0 )				{	$strPool_of_Sludge				= $strImageCheck;	}
		if( $nSmith_Rondo > 0 )					{	$strSmith_Rondo					= $strImageCheck;	}
		if( $nVxed > 0 )						{	$strVxed						= $strImageCheck;	}
		if( $nTipt > 0 )						{	$strTipt						= $strImageCheck;	}
		if( $nVrex_Barxt_Qurat > 0 )			{	$strVrex_Barxt_Qurat			= $strImageCheck;	}
		if( $nKeeper_of_the_Altar > 0 )			{	$strKeeper_of_the_Altar			= $strImageCheck;	}
		if( $nNoqufiel_in_Inktuta > 0 )			{	$strNoqufiel_in_Inktuta			= $strImageCheck;	}
		if( $nCynosure_Kvanjji > 0 )			{	$strCynosure_Kvanjji			= $strImageCheck;	}
		if( $nIxt_Hsek_Syat > 0 )				{	$strIxt_Hsek_Syat				= $strImageCheck;	}
		if( $nHigh_Priest_Nkosi_Bakari > 0 )	{	$strHigh_Priest_Nkosi_Bakari	= $strImageCheck;	}
		if( $nZunMuram_Tkarish_Zyk > 0 )		{	$strZunMuram_Tkarish_Zyk		= $strImageCheck;	}

		// Check if it's an old member
		if( $nOldMember == 1 )
		{
			$strRowType		= "DeletedRow";

			// Allow the deletion of old members
			$strDeleteChar	= ' <a href="form.php?FormName=Character_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=GoD_Flags&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Delete ' . $strCharName . '\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Delete ' . $strCharName . '"><img src="images/delete.gif" border="0" /></a>';
		}
	
		// Check if this character belongs to the logged in User
		$strModify	= "";
		if( ( isset( $strUserName ) ) &&
			( isset( $strNameMain ) ) &&
			( $strUserName == $strNameMain ) )
		{
			$strModify	= '<a href="character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=GoD_Flags&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="images/modify.gif" border="0" />';
		}
		else if( IsAdministrator( $strUserName ) )
		{
			$strModify	= '<a href="character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=GoD_Flags&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="images/modify_others.gif" border="0" />';
		}
	
		echo '
		  <tr	onMouseOver="this.bgColor=\'' . GetRowHighLightColor() . '\'" onMouseOut="this.bgColor=\'\'">
			<td width= "5%" align="center">'				. $strModify					. '</td>
			<td width= "7%" class="' . $strRowType . '">'	. $strCharName					. $strDeleteChar . '</td>
			<td width= "6%" align="center">'				. $strPurifying_Plant			. '</td>
			<td width= "6%" align="center">'				. $strEmanating_Furnace			. '</td>
			<td width= "6%" align="center">'				. $strLair_of_Trapped_Ones		. '</td>
			<td width= "6%" align="center">'				. $strPool_of_Sludge			. '</td>
			<td width= "6%" align="center">'				. $strSmith_Rondo				. '</td>
			<td width= "6%" align="center">'				. $strVxed						. '</td>
			<td width= "6%" align="center">'				. $strTipt						. '</td>
			<td width= "6%" align="center">'				. $strVrex_Barxt_Qurat			. '</td>
			<td width= "6%" align="center">'				. $strKeeper_of_the_Altar		. '</td>
			<td width= "6%" align="center">'				. $strNoqufiel_in_Inktuta		. '</td>
			<td width= "6%" align="center">'				. $strCynosure_Kvanjji			. '</td>
			<td width= "6%" align="center">'				. $strIxt_Hsek_Syat				. '</td>
			<td width= "6%" align="center">'				. $strHigh_Priest_Nkosi_Bakari	. '</td>
			<td width= "6%" align="center">'				. $strZunMuram_Tkarish_Zyk		. '</td>
		  </tr>
		';
	}
}

?>
