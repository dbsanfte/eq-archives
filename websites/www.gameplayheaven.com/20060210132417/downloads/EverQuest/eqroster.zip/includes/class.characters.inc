<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );


// ============================================================================
// The Characters class
// ============================================================================
// This class provides an interface to the Character table
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class Characters
{
	// Member variables
	var $bShowVerticalScrollbars	= true;
	// Max values
	var $nMaxAA						= 99999;
	var $nMaxGLP					= 99999;


	// ========================================================================
	// Constructor
	// ========================================================================
	function Characters()
	{
		// No code yet
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "Characters";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		// Set the Show Alts variables
		if( $strShowAlts == "Yes" )
		{
			$strShowAltsToggled	= "No";
			$strShowAltsDesc	= "Hide Alts and Inactive characters";
			$strShowAltsImg		= '<img src="images/show_no_alts.gif" border="0" alt="' . $strShowAltsDesc . '" />';
		}
		else
		{
			$strShowAltsToggled	= "Yes";
			$strShowAltsDesc	= "Show Alts and Inactive characters";
			$strShowAltsImg		= '<img src="images/show_all.gif" border="0" alt="' . $strShowAltsDesc . '" />';
		}

		echo '
		<!-- Start of Header -->
		<div id="Header">
		<br />
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td width= "3%" align="center">	<b><a href="form.php?FormName=Characters&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAltsToggled .	'&SortOrder=' . $strSortOrder				. '&SortDirection=' . $strSortDirection									. '&ClassFilter=' . $strClassFilter . '&CookieAction=WRITE"	OnMouseOver="window.status=\'' . $strShowAltsDesc . '\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="' . $strShowAltsDesc . '"		>' . $strShowAltsImg . '</a></b></td>
			<td width="19%">				<b><a href="form.php?FormName=Characters&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 		'&SortOrder=CharName&SortDirection='		. GetSortDirection( $strSortOrder, "CharName",		$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '&CookieAction=WRITE"	OnMouseOver="window.status=\'Sort by Name\';return true;"							OnMouseOut="window.status=\'\'"	target=Body title="Name"							>Name</a></b></td>
			<td width="11%">				<b><a href="form.php?FormName=Characters&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 		'&SortOrder=NameMain&SortDirection='		. GetSortDirection( $strSortOrder, "NameMain",		$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '&CookieAction=WRITE"	OnMouseOver="window.status=\'Sort by Name Main\';return true;"						OnMouseOut="window.status=\'\'"	target=Body title="Name Main"						>Name Main</a></b></td>
			<td width= "8%">				<b><a href="form.php?FormName=Characters&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 		'&SortOrder=GuildStatus&SortDirection='		. GetSortDirection( $strSortOrder, "GuildStatus",	$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '&CookieAction=WRITE"	OnMouseOver="window.status=\'Sort by Title\';return true;"							OnMouseOut="window.status=\'\'"	target=Body title="Title"							>Title</a></b></td>
			<td width="11%">				<b><a href="form.php?FormName=Characters&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 		'&SortOrder=Class&SortDirection='			. GetSortDirection( $strSortOrder, "Class",			$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '&CookieAction=WRITE"	OnMouseOver="window.status=\'Sort by Class\';return true;"							OnMouseOut="window.status=\'\'"	target=Body title="Class"							>Class</a></b></td>
			<td width= "8%">				<b><a href="form.php?FormName=Characters&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 		'&SortOrder=Race&SortDirection='			. GetSortDirection( $strSortOrder, "Race",			$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '&CookieAction=WRITE"	OnMouseOver="window.status=\'Sort by Race\';return true;"							OnMouseOut="window.status=\'\'"	target=Body title="Race"							>Race</a></b></td>
			<td width= "4%" align="center">	<b><a href="form.php?FormName=Characters&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 		'&SortOrder=Level&SortDirection='			. GetSortDirection( $strSortOrder, "Level",			$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '&CookieAction=WRITE"	OnMouseOver="window.status=\'Sort by Level\';return true;"							OnMouseOut="window.status=\'\'"	target=Body title="Level"							>LVL</a></b></td>
			<td width= "4%" align="center">	<b><a href="form.php?FormName=Characters&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 		'&SortOrder=AA&SortDirection='				. GetSortDirection( $strSortOrder, "AA",			$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '&CookieAction=WRITE"	OnMouseOver="window.status=\'Sort by Nr. of AA\\\'s\';return true;"					OnMouseOut="window.status=\'\'"	target=Body title="Nr. of AAs"						>AA</a></b></td>
			<td width= "4%" align="center">	<b><a href="form.php?FormName=Characters&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 		'&SortOrder=GLP&SortDirection='				. GetSortDirection( $strSortOrder, "GLP",			$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '&CookieAction=WRITE"	OnMouseOver="window.status=\'Sort by Nr. of Group Leadership points\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Nr. of Group Leadership Points"	>GLP</a></b></td>
			<td width= "1%"></td>
			<td width= "3%" align="center">	<b><a href="form.php?FormName=Characters&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 		'&SortOrder=MageloNr&SortDirection='		. GetSortDirection( $strSortOrder, "MageloNr",		$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '&CookieAction=WRITE"	OnMouseOver="window.status=\'Sort by Magelo Nr.\';return true;"						OnMouseOut="window.status=\'\'"	target=Body title="Magelo Nr."						><img src="images/magelo.gif" border="0" alt="MageloNr"></a></b></td>
			<td width= "3%" align="center">	<b><a href="form.php?FormName=Characters&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 		'&SortOrder=Gender&SortDirection='			. GetSortDirection( $strSortOrder, "Gender",		$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '&CookieAction=WRITE"	OnMouseOver="window.status=\'Sort by Gender\';return true;"							OnMouseOut="window.status=\'\'"	target=Body title="Gender"							><img src="images/gender.gif" border="0" alt="Gender"></a></b></td>
			<td width= "3%" align="center">	<b><a href="form.php?FormName=Characters&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 		'&SortOrder=EMailAddress&SortDirection='	. GetSortDirection( $strSortOrder, "EMailAddress",	$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '&CookieAction=WRITE"	OnMouseOver="window.status=\'Sort by E-Mail Address\';return true;"					OnMouseOut="window.status=\'\'"	target=Body title="E-Mail"							><img src="images/email.gif" border="0" alt="EMail"></a></b></td>
			<td width= "1%"></td>
			<td width="10%">				<b><a href="form.php?FormName=Characters&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 		'&SortOrder=TimeZone&SortDirection='		. GetSortDirection( $strSortOrder, "TimeZone",		$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '&CookieAction=WRITE"	OnMouseOver="window.status=\'Sort by Time Zone\';return true;"						OnMouseOut="window.status=\'\'"	target=Body title="Time Zone"						>Time Zone</a></b></td>
			<td width= "7%">				<b><a href="form.php?FormName=Characters&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 		'&SortOrder=LastOn&SortDirection='			. GetSortDirection( $strSortOrder, "LastOn",		$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '&CookieAction=WRITE"	OnMouseOver="window.status=\'Sort by Last On Date\';return true;"					OnMouseOut="window.status=\'\'"	target=Body title="Last-On Date"					>Last On</a></b></td>
		  </tr>
		</table>
		</div>
		<!-- End of Header -->
		';
	}



	// ========================================================================
	// Show all the records on screen
	// ========================================================================
	// This function will loop through all the records in the database table,
	// and create a html table entry for each one of them.
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS		= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];
		$strClassFilter		= $_GET['ClassFilter'];

		// Declare variables
		$bAdministrator		= IsAdministrator( $strUserName );
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT UserName, CharName, LastName, NameMain, Class, Race, Gender, Religion, Level, AA, GLP, MageloNr, GuildStatus, LastOn, EMailAddress, ShowEMail, TimeZone, OldMember \n" .
							  "FROM Characters \n" .
							  "LEFT JOIN Users ON (Characters.UserID = Users.UserID) \n";
		$strSelectMaxQuery	= "SELECT MAX(AA), MAX(GLP) FROM Characters WHERE OldMember = 0 \n";
	
		// Check if we should show alts
		if( $strShowAlts != "Yes" )
		{
			$strSelectQuery	.= "WHERE ((GuildStatus != 'Alt' AND GuildStatus != 'Inactive') OR NameMain = '" . $strUserName . "') \n";
		}
	
		// Check if we should set a class filter
		if( ( isset( $strClassFilter ) ) &&
			( $strClassFilter != "" ) &&
			( $strClassFilter != "<<All>>" ) )
		{	
			if( $strShowAlts != "Yes" )
			{
				$strSelectQuery	.= "AND Class = '" . $strClassFilter . "'";
			}
			else
			{
				$strSelectQuery	.= "WHERE Class = '" . $strClassFilter . "'";
			}
		} 

		// Check if we should use the default sort order
		if( ( !isset( $strSortOrder ) ) ||
			( $strSortOrder == "" ) )
		{
			// Default sort on Character name
			$strSortOrder	= "CharName"; 
		}

		// Sorting on Level, AA, GLP, MageloNr, LastOn and E-Mail Address should be reversed (Desc first, then Asc)
		$strModifiedSortDirection	= $strSortDirection;
		if( ( $strSortOrder == "Level" ) ||
			( $strSortOrder == "AA" ) || 
			( $strSortOrder == "GLP" ) || 
			( $strSortOrder == "MageloNr" ) ||
			( $strSortOrder == "LastOn" ) ||
			( $strSortOrder == "EMailAddress" ) ) 
		{
			// Switch the sort order around
			if( $strModifiedSortDirection == "DESC" )
			{
				$strModifiedSortDirection	= "";
			}
			else
			{
				$strModifiedSortDirection	= "DESC";
			}
		}
	
		// Add the sort order
		$strSelectQuery		.= "ORDER BY " . $strSortOrder . " " . $strModifiedSortDirection . ", CharName \n";
	
		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
		<div id="Body">
		<table id="RosterTable" width="100%" border="0" cellpadding="0" cellspacing="0">
		';
	
		// Retrieve all the maximum values
		$nResult	= mysql_query( $strSelectMaxQuery, $nLinkID );
		// Store the values
	    if( $aResult = mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex				= 0;
			$this->nMaxAA		= $aResult[$nIndex++];
			$this->nMaxGLP		= $aResult[$nIndex++];
		}

		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex				= 0;
			$strOwnerName		= $aResult[$nIndex++];
			$strCharName		= $aResult[$nIndex++];
			$strLastName		= $aResult[$nIndex++];
			$strNameMain		= $aResult[$nIndex++];
			$strClass			= $aResult[$nIndex++];
			$strRace			= $aResult[$nIndex++];
			$strGender			= $aResult[$nIndex++];
			$strReligion		= $aResult[$nIndex++];
			$nLevel				= $aResult[$nIndex++];
			$nAA				= $aResult[$nIndex++];
			$nGLP				= $aResult[$nIndex++]; 
			$nMageloNr			= $aResult[$nIndex++];
			$strGuildStatus		= $aResult[$nIndex++];
			$strLastOn			= $aResult[$nIndex++];
			$strEMailAddress	= $aResult[$nIndex++];
			$strShowEMail		= $aResult[$nIndex++];
			$strTimeZone		= $aResult[$nIndex++];
			$nOldMember			= $aResult[$nIndex++];
	
			// Only show old members for the administrator
			if( ( $nOldMember == 0 ) ||
				( $bAdministrator == true ) ||
				( $strNameMain == $strUserName ) )
			{
				// Show the character
				$this->ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter, $strOwnerName, $strCharName, $strLastName, $strNameMain, $strClass, $strRace, $strGender, $strReligion, $nLevel, $nAA, $nGLP, $nMageloNr, $strGuildStatus, $strLastOn, $strEMailAddress, $strShowEMail, $strTimeZone, $nOldMember, $strRowType, $bAdministrator );
	
				// Switch RowType, so the rows alternate	
				if( $strRowType == "OddRow" )
				{
					$strRowType	= "EvenRow";
				}
				else
				{
					$strRowType	= "OddRow";
				}
			}
		}
	
		// End the character table
		echo '
		</table>
		</div>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );
	}
	
	
	
	// ========================================================================
	// Show a record
	// ========================================================================
	// This function will create a html table row for a record in the table
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// In:  Variables containing the data to show 
	// ========================================================================
	function ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter, $strOwnerName, $strCharName, $strLastName, $strNameMain, $strClass, $strRace, $strGender, $strReligion, $nLevel, $nAA, $nGLP, $nMageloNr, $strGuildStatus, $strLastOn, $strEMailAddress, $strShowEMail, $strTimeZone, $nOldMember, $strRowType, $bAdministrator )
	{
		// Declare variables
		$strDeleteChar		= "";

		// Check if it's an old member
		if( $nOldMember == 1 )
		{
			$strRowType			= "DeletedRow";

			// Allow the deletion of old members
			$strDeleteChar		= ' <a href="form.php?FormName=Character_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=Characters&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Delete ' . $strCharName . '\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Delete ' . $strCharName . '"><img src="images/delete.gif" border="0" /></a>';
		}
		
		// Check if the last name is filled
		$strFullName	= $strCharName;
		if( $strLastName != "" )
		{
			$strFullName	.=  " " . $strLastName;
		}

		// Mark admins
		if( ( IsAdministrator( $strNameMain ) ) &&
			( $strCharName == $strNameMain ) )
		{
			$strFullName	.= '<img src="images/admin.gif" border="0" align="top" 	OnMouseOver="window.status=\'Administrator\';return true;"	OnMouseOut="window.status=\'\'"	title="This user is a Roster Administrator"/>';
		}

		// Check if magelo nr is filled in
		if( ( isset( $nMageloNr ) ) &&
			( $nMageloNr > 0 ) )
		{
			$strFullMagelo	= '<a href="http://www.magelo.com/eq_view_profile.html?num=' . $nMageloNr . '"	OnMouseOver="window.status=\'Show ' . $strCharName . '\\\'s magelo\';return true;"	OnMouseOut="window.status=\'\'"	target="_blank" title="Show ' . $strCharName . '\'s magelo"><img src="images/magelo.gif" border="0" />';
		}
	
		// Check the gender
		$strFullGender		= '';
		if( ( isset( $strGender ) ) &&
			( $strGender == "Female" ) )
		{
			$strFullGender	= '<img src="images/female.gif" border="0" title="Female"/>';
		}
		else if( $strGender == "Male" )
		{
			$strFullGender	= '<img src="images/male.gif" border="0" title="Male"/>';
		}
		
		// Retrieve the formatted date
		$strLastOn	= FormatDate( $strLastOn );
	
		// Check the EMail
		$strFullEMail		= "";
		if( isset( $strEMailAddress ) )
		{
			// Check if the address should be viewable
			if( ( $strShowEMail == "Always" ) ||
				( $bAdministrator == true ) ||
				( ( $strShowEMail == "Members Only" ) &&
				  ( isset( $strUserName ) ) &&
				  ( $strUserName != "" ) ) )
			{
				$strFullEMail	= '<a href="mailto:' . $strEMailAddress . '"	OnMouseOver="window.status=\'Send E-Mail to ' . $strOwnerName . '\';return true;"	OnMouseOut="window.status=\'\'" title="Send E-Mail to ' . $strOwnerName . '"><img src="images/email.gif" border="0" /></a>';
			}
			// Check if the address is viewable by members only
			else if( ( $strShowEMail == "Members Only" ) &&
					 ( ( !isset( $strUserName ) ) ||
					   ( $strUserName == "" ) ) )
			{
				$strFullEMail	= '<img src="images/email_private.gif" border="0" OnMouseOver="window.status=\'' . $strOwnerName . '\\\'s E-Mail is viewable by members only\';return true;"	OnMouseOut="window.status=\'\'" title="' . $strOwnerName . '\'s E-Mail is viewable by members only" />';
			}
			// Private address
			else
			{
				$strFullEMail	= '<img src="images/email_private.gif" border="0" OnMouseOver="window.status=\'' . $strOwnerName . '\\\'s E-Mail is private\';return true;"	OnMouseOut="window.status=\'\'" title="' . $strOwnerName . '\'s E-Mail is private" />';
			}
		}
	
		// Check if this character belongs to the logged in User
		$strModify	= "";
		if( ( isset( $strUserName ) ) &&
			( isset( $strOwnerName ) ) &&
			( $strUserName == $strOwnerName ) )
		{
			$strModify	= '<a href="character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=Characters&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="images/modify.gif" border="0" /></a>';
		}
		else if( $bAdministrator == true )
		{
			$strModify	= '<a href="character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=Characters&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="images/modify_others.gif" border="0" /></a>';
		}
	
		echo '
		  <tr	onMouseOver="this.bgColor=\'' . GetRowHighLightColor() . '\'" onMouseOut="this.bgColor=\'\'">
			<td width= "3%" align="center">'																			. $strModify		. '</td>
			<td width="19%" class="' . $strRowType												. '">'					. $strFullName		. $strDeleteChar . '</td>
			<td width="11%" class="' . $strRowType												. '">'					. $strNameMain		. '</td>
			<td width= "8%" class="' . $strRowType												. '">'					. $strGuildStatus	. '</td>
			<td width="11%" class="' . $strRowType												. '">'					. $strClass			. '</td>
			<td width= "8%" class="' . $strRowType												. '">'					. $strRace			. '</td>
			<td width= "4%" class="' . $strRowType												. '" align="center">'	. $nLevel			. '</td> 
			<td width= "4%" class="' . $this->GetCellClass( $nAA, $this->nMaxAA, $strRowType )	. '" align="center">'	. $nAA				. '</td>
			<td width= "4%" class="' . $this->GetCellClass( $nGLP, $this->nMaxGLP, $strRowType ). '" align="center">'	. $nGLP				. '</td>
			<td width= "1%"></td>
			<td width= "3%" class="' . $strRowType												. '" align="center">'	. $strFullMagelo	. '</td>
			<td width= "3%" class="' . $strRowType												. '" align="center">'	. $strFullGender	. '</td>
			<td width= "3%" class="' . $strRowType												. '" align="center">'	. $strFullEMail		. '</td>
			<td width= "1%"></td>
			<td width="10%" class="' . $strRowType												. '">'					. $strTimeZone		. '</td>
			<td width= "7%" class="' . $strRowType												. '">'					. $strLastOn		. '</td>
		  </tr>
		';
	}



	// ========================================================================
	// Get the font color for the AA or GLP value
	// ========================================================================
	// This function will determine (and return) the font color for a skill
	// All highest skills will receive a different color.
	// ========================================================================
	// In:	$nValue			= Value
	// In:	$nMaxValue		= Max Value for the category
	// In:	$strRowType		= Default RowType
	// Out:	RowType to use
	// ========================================================================
	function GetCellClass( $nValue, $nMaxValue, $strRowType )
	{
		// If the tradeskill has a high value
		if( $nValue >= $nMaxValue )
		{
			// Check which RowType was in use
			if( $strRowType == "EvenRow" )
			{
				return "EvenRowHighSkill";
			}
			else if( $strRowType == "OddRow" )
			{
				return "OddRowHighSkill";
			}
		}
		// Otherwise return the defautl font color
		return $strRowType;
	}
}

?>
