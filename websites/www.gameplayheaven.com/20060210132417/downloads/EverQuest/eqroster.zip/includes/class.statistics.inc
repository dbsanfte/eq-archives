<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );


// ============================================================================
// The Statistics class
// ============================================================================
// This class provides an interface to the roster/guild statistics
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class Statistics
{
	var $bShowVerticalScrollbars	= true;

	// ========================================================================
	// Constructor
	// ========================================================================
	function Statistics()
	{
		// No code yet
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "Statistics";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		// Empty Header
		echo '
		<!-- Start of Header -->
		<!-- End of Header -->
		';
	}
	
	
	
	// ========================================================================
	// Show all the records on screen
	// ========================================================================
	// This function will loop through all the records in the database table,
	// and create a html table entry for each one of them.
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS		= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];

		// Declare variables
		$nNrOfCharacters	= 0;
		$nNrOfOldCharacters	= 0;
		$nNrOfMains			= 0;
		$nNrOfAlts			= 0;
		$nNrOfOfficers		= 0;
		$nNrOfProbations	= 0;
		$nNrOfInactives		= 0;
		$strSelectNrOfCharactersQuery	= "SELECT COUNT(*) FROM Characters";
		$strSelectNrOfMainsQuery		= "SELECT COUNT(*) FROM Characters WHERE OldMember = 0 AND GuildStatus = 'Member'";
		$strSelectNrOfAltsQuery			= "SELECT COUNT(*) FROM Characters WHERE OldMember = 0 AND (GuildStatus = 'Alt' OR (GuildStatus = 'Officer' AND CharName != NameMain))";
		$strSelectNrOfOfficersQuery		= "SELECT COUNT(*) FROM Characters WHERE OldMember = 0 AND GuildStatus = 'Officer' AND CharName = NameMain";
		$strSelectNrOfProbationsQuery	= "SELECT COUNT(*) FROM Characters WHERE OldMember = 0 AND GuildStatus = 'Probation'";
		$strSelectNrOfInactivesQuery	= "SELECT COUNT(*) FROM Characters WHERE OldMember = 0 AND GuildStatus = 'Inactive'";

		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Get the nr of characters
		$nResult	= mysql_query( $strSelectNrOfCharactersQuery . " WHERE OldMember = 0", $nLinkID );
		$aResult	= mysql_fetch_row( $nResult );
		if( isset( $aResult[0] ) )
		{
			$nNrOfCharacters	= $aResult[0];
		}

		// Get the nr of old characters
		$nResult	= mysql_query( $strSelectNrOfCharactersQuery . " WHERE OldMember = 1", $nLinkID );
		$aResult	= mysql_fetch_row( $nResult );
		if( isset( $aResult[0] ) )
		{
			$nNrOfOldCharacters	= $aResult[0];
		}

		// Get the nr of mains
		$nResult	= mysql_query( $strSelectNrOfMainsQuery, $nLinkID );
		$aResult	= mysql_fetch_row( $nResult );
		if( isset( $aResult[0] ) )
		{
			$nNrOfMains			= $aResult[0];
		}

		// Get the nr of alts
		$nResult	= mysql_query( $strSelectNrOfAltsQuery, $nLinkID );
		$aResult	= mysql_fetch_row( $nResult );
		if( isset( $aResult[0] ) )
		{
			$nNrOfAlts			= $aResult[0];
		}

		// Get the nr of officers
		$nResult	= mysql_query( $strSelectNrOfOfficersQuery, $nLinkID );
		$aResult	= mysql_fetch_row( $nResult );
		if( isset( $aResult[0] ) )
		{
			$nNrOfOfficers		= $aResult[0];
		}

		// Get the nr of probations
		$nResult	= mysql_query( $strSelectNrOfProbationsQuery, $nLinkID );
		$aResult	= mysql_fetch_row( $nResult );
		if( isset( $aResult[0] ) )
		{
			$nNrOfProbations	= $aResult[0];
		}

		// Get the nr of inactives
		$nResult	= mysql_query( $strSelectNrOfInactivesQuery, $nLinkID );
		$aResult	= mysql_fetch_row( $nResult );
		if( isset( $aResult[0] ) )
		{
			$nNrOfInactives		= $aResult[0];
		}

		// Close the connection
		DBDisconnect( $nLinkID );


		echo '
		<div id="Body" align="center">
		 <p><strong><font color="#CCCCCC" size="+3"><em>Roster Statistics</em></font></strong></p>
		 <p>&nbsp;</p>
		 <table id="RosterTable" width="30%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td width="20%" class="OddRow">Total Characters</td>
			<td width="10%" class="OddRow" align="center">'		. $nNrOfCharacters		. '</td>
		  </tr>
		  <tr>
			<td width="20%" class="EvenRow"> Mains</td>
			<td width="10%" class="EvenRow" align="center">'	. $nNrOfMains			. '</td>
		  </tr>
		  <tr>
			<td width="20%" class="OddRow"> Alts</td>
			<td width="10%" class="OddRow" align="center">'		. $nNrOfAlts			. '</td>
		  </tr>
		  <tr>
			<td width="20%" class="EvenRow"> Officers</td>
			<td width="10%" class="EvenRow" align="center">'	. $nNrOfOfficers		. '</td>
		  </tr>
		  <tr>
			<td width="20%" class="OddRow"> Probation</td>
			<td width="10%" class="OddRow" align="center">'		. $nNrOfProbations		. '</td>
		  </tr>
		  <tr>
			<td width="20%" class="EvenRow"> Inactive</td>
			<td width="10%" class="EvenRow" align="center">'	. $nNrOfInactives		. '</td>
		  </tr>
		  <tr>
			<td width="20%" class="DeletedRow"> Deguilded</td>
			<td width="10%" class="DeletedRow" align="center">'	. $nNrOfOldCharacters	. '</td>
		  </tr>
		 </table>
		</div>
		';
	}

}

?>
