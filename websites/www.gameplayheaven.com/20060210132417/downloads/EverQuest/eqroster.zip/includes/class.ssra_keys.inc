<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );


// ============================================================================
// The SSRA_Keys class
// ============================================================================
// This class provides an interface to the SSRA_Key table
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class SSRA_Keys
{
	var $bShowVerticalScrollbars	= true;

	// ========================================================================
	// Constructor
	// ========================================================================
	function SSRA_Keys()
	{
		// No code yet
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "SSRA Keys";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<div id="Header">
		<br />
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td width= "5%"></td>
			<td width="19%">				<b><a href="form.php?FormName=SSRA_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=CharName&SortDirection='			. GetSortDirection( $strSortOrder, "CharName",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Name\';return true;"					OnMouseOut="window.status=\'\'"	target=Body title="Name"				>Name</a></b></td>
			<td width="16%" align="center">	<b><a href="form.php?FormName=SSRA_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Taskmasters_Pouch&SortDirection='	. GetSortDirection( $strSortOrder, "Taskmasters_Pouch",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Taskmaster\\\'s Pouch\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Taskmaster\'s Pouch"	>Taskmaster\'s Pouch</a></b></td>
			<td width="16%" align="center">	<b><a href="form.php?FormName=SSRA_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Zazuzhs_Idol&SortDirection='		. GetSortDirection( $strSortOrder, "Zazuzhs_Idol",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Zazuzh\\\'s Idol\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Zazuzh\'s Idol"		>Zazuzh\'s Idol</a></b></td>
			<td width="16%" align="center">	<b><a href="form.php?FormName=SSRA_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Ring&SortDirection='				. GetSortDirection( $strSortOrder, "Ring",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Ring\';return true;"					OnMouseOut="window.status=\'\'"	target=Body title="Ring"				>Ring</a></b></td>
			<td width="16%" align="center">	<b><a href="form.php?FormName=SSRA_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Insignia&SortDirection='			. GetSortDirection( $strSortOrder, "Insignia",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Insignia\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Insignia"			>Insignia</a></b></td>
			<td width= "7%"></td>
			<td width= "5%" align="center">	<b><a href="form.php?FormName=SSRA_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=SSRA_Emperor_Key&SortDirection='	. GetSortDirection( $strSortOrder, "SSRA_Emperor_Key",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by key completed\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Key completed"		>Done</a></b></td>
		  </tr>
		</table>
		</div>
		<!-- End of Header -->
		';
	}
	
	
	
	// ========================================================================
	// Show all the records on screen
	// ========================================================================
	// This function will loop through all the records in the database table,
	// and create a html table entry for each one of them.
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS		= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];
		$strClassFilter		= $_GET['ClassFilter'];

		// Declare variables
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT CharName, NameMain, SSRA_Emperor_Key, Taskmasters_Pouch, Zazuzhs_Idol, Ring, Insignia, OldMember \n" .
							  "FROM SSRA_Emperor_Key \n" .
							  "LEFT JOIN Characters ON (SSRA_Emperor_Key.CharID = Characters.CharID) \n" .
							  "LEFT JOIN `Keys`     ON (SSRA_Emperor_Key.CharID = Keys.CharID) \n" . 
							  "WHERE (	SSRA_Emperor_Key > 0	OR \n" .
							  "			Taskmasters_Pouch > 0	OR \n" .
							  "			Zazuzhs_Idol > 0		OR \n" .
							  "			Ring > 0				OR \n" .
							  "			Insignia > 0 )			   \n";

		// Check if we should set a class filter
		if( ( isset( $strClassFilter ) ) &&
			( $strClassFilter != "" ) &&
			( $strClassFilter != "<<All>>" ) )
		{
			$strSelectQuery	.= "AND Class = '" . $strClassFilter . "'";
		} 

		// Check if we should use the default sort order
		if( ( !isset( $strSortOrder ) ) ||
			( $strSortOrder == "" ) )
		{
			// Default sort on Character name
			$strSortOrder	= "CharName"; 
		}

		// Sorting on all numbers should be reversed (Desc first, then Asc)
		$strModifiedSortDirection	= $strSortDirection;
		if( $strSortOrder != "CharName" )
		{
			// Switch the sort order around
			if( $strModifiedSortDirection == "DESC" )
			{
				$strModifiedSortDirection	= "";
			}
			else
			{
				$strModifiedSortDirection	= "DESC";
			}
		}
	
		// Add the sort order
		$strSelectQuery		.= "ORDER BY " . $strSortOrder . " " . $strModifiedSortDirection . ", CharName";
	
		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
		<div id="Body">
		<table id="RosterTable" width="100%" border="0" cellpadding="0" cellspacing="0">
		';
	
		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex				= 0;
			$strCharName		= $aResult[$nIndex++];
			$strNameMain		= $aResult[$nIndex++];
			$nCompleted			= $aResult[$nIndex++];
			$nTaskmasters_Pouch	= $aResult[$nIndex++];
			$nZazuzhs_Idol		= $aResult[$nIndex++];
			$nRing				= $aResult[$nIndex++];
			$nInsignia			= $aResult[$nIndex++];
			$nOldMember			= $aResult[$nIndex++];
	
			// Only show old members for the administrator
			if( ( $strCharName != "" ) &&
				( ( $nOldMember == 0 ) ||
				  ( IsAdministrator( $strUserName ) ) ) )
			{
				// Show the SSRA Emperor key parts
				$this->ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nCompleted, $nTaskmasters_Pouch, $nZazuzhs_Idol, $nRing, $nInsignia, $nOldMember, $strRowType );
		
				// Switch RowType, so the rows alternate	
				if( $strRowType == "OddRow" )
				{
					$strRowType	= "EvenRow";
				}
				else
				{
					$strRowType	= "OddRow";
				}
			}
		}
	
		// End the table
		echo '
		</table>
		</div>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );
	}
	
	
	
	// ========================================================================
	// Show a record
	// ========================================================================
	// This function will create a html table row for a record in the table
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// In:  Variables containing the data to show 
	// ========================================================================
	function ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nCompleted, $nTaskmasters_Pouch, $nZazuzhs_Idol, $nRing, $nInsignia, $nOldMember, $strRowType )
	{
		// Declare variables
		$strImageCheck			= '<img src="images/check.gif" border="0" />';
		$strDeleteChar			= "";
		$strCompleted			= "";
		$strTaskmasters_Pouch	= "";
		$strZazuzhs_Idol		= "";
		$strRing				= "";
		$strInsignia			= "";
	
		// Set the check-image for all filled variables
		if( $nCompleted > 0 )			{	$strCompleted			= $strImageCheck;	}
		if( $nTaskmasters_Pouch > 0 )	{	$strTaskmasters_Pouch	= $strImageCheck;	}
		if( $nZazuzhs_Idol > 0 )		{	$strZazuzhs_Idol		= $strImageCheck;	}
		if( $nRing > 0 )				{	$strRing				= $strImageCheck;	}
		if( $nInsignia > 0 )			{	$strInsignia			= $strImageCheck;	}
	
		// Check if it's an old member
		if( $nOldMember == 1 )
		{
			$strRowType		= "DeletedRow";

			// Allow the deletion of old members
			$strDeleteChar	= ' <a href="form.php?FormName=Character_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=SSRA_Keys&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Delete ' . $strCharName . '\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Delete ' . $strCharName . '"><img src="images/delete.gif" border="0" /></a>';
		}
	
		// Check if this character belongs to the logged in User
		$strModify	= "";
		if( ( isset( $strUserName ) ) &&
			( isset( $strNameMain ) ) &&
			( $strUserName == $strNameMain ) )
		{
			$strModify	= '<a href="character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=SSRA_Keys&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="images/modify.gif" border="0" />';
		}
		else if( IsAdministrator( $strUserName ) )
		{
			$strModify	= '<a href="character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=SSRA_Keys&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="images/modify_others.gif" border="0" />';
		}
	
		echo '
		  <tr	onMouseOver="this.bgColor=\'' . GetRowHighLightColor() . '\'" onMouseOut="this.bgColor=\'\'">
			<td width= "5%" align="center">'				. $strModify			. '</td>
			<td width="19%" class="' . $strRowType . '">'	. $strCharName			. $strDeleteChar . '</td>
			<td width="16%" align="center">'				. $strTaskmasters_Pouch	. '</td>
			<td width="16%" align="center">'				. $strZazuzhs_Idol		. '</td>
			<td width="16%" align="center">'				. $strRing				. '</td>
			<td width="16%" align="center">'				. $strInsignia			. '</td>
			<td width= "7%"></td>
			<td width= "5%" align="center">'				. $strCompleted			. '</td>
		  </tr>
		';
	}

}

?>
