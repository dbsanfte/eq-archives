<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );


// ============================================================================
// The Veeshans_Peak_Keys class
// ============================================================================
// This class provides an interface to the Veeshans_Peak_Key table
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class Veeshans_Peak_Keys
{
	var $bShowVerticalScrollbars	= true;

	// ========================================================================
	// Constructor
	// ========================================================================
	function Veeshans_Peak_Keys()
	{
		// No code yet
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "Veeshans Peak Keys";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<div id="Header">
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td width= "5%"></td>
			<td width="15%">				<b><a href="form.php?FormName=Veeshans_Peak_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=CharName&SortDirection='				. GetSortDirection( $strSortOrder, "CharName",				$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Name\';return true;"						OnMouseOut="window.status=\'\'"	target=Body title="Name"					>Name</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=Veeshans_Peak_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=KylongMedal_Top&SortDirection='		. GetSortDirection( $strSortOrder, "KylongMedal_Top",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Kylong Medalion Top\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Kylong Medalion Top"		><br />Top</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=Veeshans_Peak_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=KylongMedal_Middle&SortDirection='	. GetSortDirection( $strSortOrder, "KylongMedal_Middle",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Kylong Medalion Middel\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Kylong Medalion Middel"	>Kylong<br />Middel</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=Veeshans_Peak_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=KylongMedal_Bottom&SortDirection='	. GetSortDirection( $strSortOrder, "KylongMedal_Bottom",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Kylong Medalion Bottom\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Kylong Medalion Bottom"	><br />Bottom</a></b></td>
			<td width= "2%"></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=Veeshans_Peak_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=JarsathMedal_Top&SortDirection='		. GetSortDirection( $strSortOrder, "JarsathMedal_Top",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Jarsath Medalion Top\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Jarsath Medalion Top"	><br />Top</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=Veeshans_Peak_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=JarsathMedal_Middle&SortDirection='	. GetSortDirection( $strSortOrder, "JarsathMedal_Middle",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Jarsath Medalion Middel\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Jarsath Medalion Middel"	>Jarsath<br />Middel</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=Veeshans_Peak_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=JarsathMedal_Bottom&SortDirection='	. GetSortDirection( $strSortOrder, "JarsathMedal_Bottom",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Jarsath Medalion Bottom\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Jarsath Medalion Bottom"	><br />Bottom</a></b></td>
			<td width= "2%"></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=Veeshans_Peak_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=ObulusMedal_Top&SortDirection='		. GetSortDirection( $strSortOrder, "ObulusMedal_Top",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Obulus Medalion Top\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Obulus Medalion Top"		><br />Top</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=Veeshans_Peak_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=ObulusMedal_Middle&SortDirection='	. GetSortDirection( $strSortOrder, "ObulusMedal_Middle",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Obulus Medalion Middel\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Obulus Medalion Middel"	>Obulus<br />Middel</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=Veeshans_Peak_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=ObulusMedal_Bottom&SortDirection='	. GetSortDirection( $strSortOrder, "ObulusMedal_Bottom",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Obulus Medalion Bottom\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Obulus Medalion Bottom"	><br />Bottom</a></b></td>
			<td width= "2%"></td>
			<td width= "8%" align="center">	<b><a href="form.php?FormName=Veeshans_Peak_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Trak_Tooth&SortDirection='			. GetSortDirection( $strSortOrder, "Trak_Tooth",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Trakanon\\\'s Tooth\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Trakanon\'s Tooth"		>Trakanon\'s Tooth</a></b></td>
			<td width= "7%"></td>
			<td width= "5%" align="center">	<b><a href="form.php?FormName=Veeshans_Peak_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Veeshans_Peak_Key&SortDirection='	. GetSortDirection( $strSortOrder, "Veeshans_Peak_Key",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by key completed\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Key completed"			>Done</a></b></td>
		  </tr>
		</table>
		</div>
		<!-- End of Header -->
		';
	}
	
	
	
	// ========================================================================
	// Show all the records on screen
	// ========================================================================
	// This function will loop through all the records in the database table,
	// and create a html table entry for each one of them.
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS		= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];
		$strClassFilter		= $_GET['ClassFilter'];

		// Declare variables
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT CharName, NameMain, Veeshans_Peak_Key, KylongMedal_Top, KylongMedal_Middle, KylongMedal_Bottom, JarsathMedal_Top, JarsathMedal_Middle, JarsathMedal_Bottom, ObulusMedal_Top, ObulusMedal_Middle, ObulusMedal_Bottom, Trak_Tooth, OldMember \n" .
							  "FROM Veeshans_Peak_Key \n" .
							  "LEFT JOIN Characters ON (Veeshans_Peak_Key.CharID = Characters.CharID) \n" .
							  "LEFT JOIN `Keys`     ON (Veeshans_Peak_Key.CharID = Keys.CharID) \n" .
							  "WHERE (	Veeshans_Peak_Key > 0		OR \n" .
							  "			KylongMedal_Top > 0			OR \n" .
							  "			KylongMedal_Middle > 0		OR \n" .
							  "			KylongMedal_Bottom > 0		OR \n" .
							  "			JarsathMedal_Top > 0		OR \n" .
							  "			JarsathMedal_Middle > 0		OR \n" .
							  "			JarsathMedal_Bottom > 0		OR \n" .
							  "			ObulusMedal_Top > 0			OR \n" .
							  "			ObulusMedal_Middle > 0		OR \n" .
							  "			ObulusMedal_Bottom > 0		OR \n" .
							  "			Trak_Tooth > 0 )			   \n";

		// Check if we should set a class filter
		if( ( isset( $strClassFilter ) ) &&
			( $strClassFilter != "" ) &&
			( $strClassFilter != "<<All>>" ) )
		{
			$strSelectQuery	.= "AND Class = '" . $strClassFilter . "'";
		} 

		// Check if we should use the default sort order
		if( ( !isset( $strSortOrder ) ) ||
			( $strSortOrder == "" ) )
		{
			// Default sort on Character name
			$strSortOrder	= "CharName"; 
		}

		// Sorting on all numbers should be reversed (Desc first, then Asc)
		$strModifiedSortDirection	= $strSortDirection;
		if( $strSortOrder != "CharName" )
		{
			// Switch the sort order around
			if( $strModifiedSortDirection == "DESC" )
			{
				$strModifiedSortDirection	= "";
			}
			else
			{
				$strModifiedSortDirection	= "DESC";
			}
		}
	
		// Add the sort order
		$strSelectQuery		.= "ORDER BY " . $strSortOrder . " " . $strModifiedSortDirection . ", CharName";
	
		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
		<div id="Body">
		<table id="RosterTable" width="100%" border="0" cellpadding="0" cellspacing="0">
		';
	
		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex					= 0;
			$strCharName			= $aResult[$nIndex++];
			$strNameMain			= $aResult[$nIndex++];
			$nCompleted				= $aResult[$nIndex++];
			$nKylongMedal_Top		= $aResult[$nIndex++];
			$nKylongMedal_Middle	= $aResult[$nIndex++];
			$nKylongMedal_Bottom	= $aResult[$nIndex++];
			$nJarsathMedal_Top		= $aResult[$nIndex++];
			$nJarsathMedal_Middle	= $aResult[$nIndex++];
			$nJarsathMedal_Bottom	= $aResult[$nIndex++];
			$nObulusMedal_Top		= $aResult[$nIndex++];
			$nObulusMedal_Middle	= $aResult[$nIndex++];
			$nObulusMedal_Bottom	= $aResult[$nIndex++];
			$nTrak_Tooth			= $aResult[$nIndex++];
			$nOldMember				= $aResult[$nIndex++];
	
			// Only show old members for the administrator
			if( ( $strCharName != "" ) &&
				( ( $nOldMember == 0 ) ||
				  ( IsAdministrator( $strUserName ) ) ) )
			{
				// Show the Veeshans Peak key parts
				$this->ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nCompleted, $nKylongMedal_Top, $nKylongMedal_Middle, $nKylongMedal_Bottom, $nJarsathMedal_Top, $nJarsathMedal_Middle, $nJarsathMedal_Bottom, $nObulusMedal_Top, $nObulusMedal_Middle, $nObulusMedal_Bottom, $nTrak_Tooth, $nOldMember, $strRowType );
		
				// Switch RowType, so the rows alternate	
				if( $strRowType == "OddRow" )
				{
					$strRowType	= "EvenRow";
				}
				else
				{
					$strRowType	= "OddRow";
				}
			}
		}
	
		// End the table
		echo '
		</table>
		</div>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );
	}
	
	
	
	// ========================================================================
	// Show a record
	// ========================================================================
	// This function will create a html table row for a record in the table
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// In:  Variables containing the data to show 
	// ========================================================================
	function ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nCompleted, $nKylongMedal_Top, $nKylongMedal_Middle, $nKylongMedal_Bottom, $nJarsathMedal_Top, $nJarsathMedal_Middle, $nJarsathMedal_Bottom, $nObulusMedal_Top, $nObulusMedal_Middle, $nObulusMedal_Bottom, $nTrak_Tooth, $nOldMember, $strRowType )
	{
		// Declare variables
		$strImageCheck			= '<img src="images/check.gif" border="0" />';
		$strDeleteChar			= "";
		$strCompleted			= "";
		$strKylongMedal_Top		= "";
		$strKylongMedal_Middle	= "";
		$strKylongMedal_Bottom	= "";
		$strJarsathMedal_Top	= "";
		$strJarsathMedal_Middle	= "";
		$strJarsathMedal_Bottom	= "";
		$strObulusMedal_Top		= "";
		$strObulusMedal_Middle	= "";
		$strObulusMedal_Bottom	= "";
		$strTrak_Tooth			= "";
	
		// Set the check-image for all filled variables
		if( $nCompleted > 0 )			{	$strCompleted			= $strImageCheck;	}
		if( $nKylongMedal_Top > 0 )		{	$strKylongMedal_Top		= $strImageCheck;	}
		if( $nKylongMedal_Middle > 0 )	{	$strKylongMedal_Middle	= $strImageCheck;	}
		if( $nKylongMedal_Bottom > 0 )	{	$strKylongMedal_Bottom	= $strImageCheck;	}
		if( $nJarsathMedal_Top > 0 )	{	$strJarsathMedal_Top	= $strImageCheck;	}
		if( $nJarsathMedal_Middle > 0 )	{	$strJarsathMedal_Middle	= $strImageCheck;	}
		if( $nJarsathMedal_Bottom > 0 )	{	$strJarsathMedal_Bottom	= $strImageCheck;	}
		if( $nObulusMedal_Top > 0 )		{	$strObulusMedal_Top		= $strImageCheck;	}
		if( $nObulusMedal_Middle > 0 )	{	$strObulusMedal_Middle	= $strImageCheck;	}
		if( $nObulusMedal_Bottom > 0 )	{	$strObulusMedal_Bottom	= $strImageCheck;	}
		if( $nTrak_Tooth > 0 )			{	$strTrak_Tooth			= $strImageCheck;	}
	
		// Check if it's an old member
		if( $nOldMember == 1 )
		{
			$strRowType		= "DeletedRow";

			// Allow the deletion of old members
			$strDeleteChar	= ' <a href="form.php?FormName=Character_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=Veeshans_Peak_Keys&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Delete ' . $strCharName . '\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Delete ' . $strCharName . '"><img src="images/delete.gif" border="0" /></a>';
		}
	
		// Check if this character belongs to the logged in User
		$strModify	= "";
		if( ( isset( $strUserName ) ) &&
			( isset( $strNameMain ) ) &&
			( $strUserName == $strNameMain ) )
		{
			$strModify	= '<a href="character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=Veeshans_Peak_Keys"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="images/modify.gif" border="0" />';
		}
		else if( IsAdministrator( $strUserName ) )
		{
			$strModify	= '<a href="character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=Veeshans_Peak_Keys"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="images/modify_others.gif" border="0" />';
		}
	
		echo '
		  <tr	onMouseOver="this.bgColor=\'' . GetRowHighLightColor() . '\'" onMouseOut="this.bgColor=\'\'">
			<td width= "5%" align="center">'				. $strModify				. '</td>
			<td width="15%" class="' . $strRowType . '">'	. $strCharName				. $strDeleteChar . '</td>
			<td width= "6%" align="center">'				. $strKylongMedal_Top		. '</td>
			<td width= "6%" align="center">'				. $strKylongMedal_Middle	. '</td>
			<td width= "6%" align="center">'				. $strKylongMedal_Bottom	. '</td>
			<td width= "2%"></td>
			<td width= "6%" align="center">'				. $strJarsathMedal_Top		. '</td>
			<td width= "6%" align="center">'				. $strJarsathMedal_Middle	. '</td>
			<td width= "6%" align="center">'				. $strJarsathMedal_Bottom	. '</td>
			<td width= "2%"></td>
			<td width= "6%" align="center">'				. $strObulusMedal_Top		. '</td>
			<td width= "6%" align="center">'				. $strObulusMedal_Middle	. '</td>
			<td width= "6%" align="center">'				. $strObulusMedal_Bottom	. '</td>
			<td width= "2%"></td>
			<td width= "8%" align="center">'				. $strTrak_Tooth			. '</td>
			<td width= "7%"></td>
			<td width= "5%" align="center">'				. $strCompleted				. '</td>
		  </tr>
		';
	}

}

?>
