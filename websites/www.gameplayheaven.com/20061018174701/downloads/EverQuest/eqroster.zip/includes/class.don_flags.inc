<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );
require_once( GetSkinDir() . 'class.skin.inc' );


// ============================================================================
// The Dragons of Norath (DoN) Flags class
// ============================================================================
// This class provides an interface to the DoN_Flags table
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class DoN_Flags
{
	// Member variables
	var $theSkin;
	var $bShowVerticalScrollbars	= true;

	// ========================================================================
	// Constructor
	// ========================================================================
	function DoN_Flags()
	{
		// Create the skin
		$this->theSkin	= new Skin();
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "Dragons of Norath Flags";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<div id="Header">
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td width= "5%" align="center"><br />' . GetInfoLink( "DoN_Progression_Good", "Dragons of Norrath Progression information" ) . '</td>
			<td width="11%">					<b><a href="form.php?FormName=DoN_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=CharName&SortDirection='					. GetSortDirection( $strSortOrder, "CharName",					$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Name\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Name"	><br />Name</a></b>
			<td width="16%">
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="100%" align="center"><b>Tier 1</b></td>
			  </tr>
			  </table>
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="25%" align="center">	<b><a href="form.php?FormName=DoN_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=T1_Create_an_Antidote&SortDirection='		. GetSortDirection( $strSortOrder, "T1_Create_an_Antidote",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Create an Antidote (good) or Blood of the Basilisk (evil)\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Create an Antidote (good) or Blood of the Basilisk (evil)"	>CaA</a></b></td>
				<td width="25%" align="center">	<b><a href="form.php?FormName=DoN_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=T1_Greed_of_the_Goblins&SortDirection='	. GetSortDirection( $strSortOrder, "T1_Greed_of_the_Goblins",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Greed of the Goblins (good) or Clearing the Path (evil)\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Greed of the Goblins (good) or Clearing the Path (evil)"		>GotG</a></b></td>
				<td width="25%" align="center">	<b><a href="form.php?FormName=DoN_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=T1_Burning_Arrows&SortDirection='			. GetSortDirection( $strSortOrder, "T1_Burning_Arrows",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Burning Arrows (good) or The Burning Poison (evil)\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Burning Arrows (good) or The Burning Poison (evil)"			>BA</a></b></td>
				<td width="25%" align="center">	<b><a href="form.php?FormName=DoN_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=T1_Children_of_Gimblax&SortDirection='	. GetSortDirection( $strSortOrder, "T1_Children_of_Gimblax",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Children of Gimblax (good) or Have Note Will Travel (evil)\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Children of Gimblax (good) or Have Note Will Travel (evil)"	>CoG</a></b></td>
			  </tr>
			  </table>
			</td>
			<td align="center"><br>|</td>
			<td width="20%">
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="100%" align="center"><b>Tier 2</b></td>
			  </tr>
			  </table>
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="20%" align="center">	<b><a href="form.php?FormName=DoN_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=T2_Defend_the_Kirin_Contact&SortDirection='	. GetSortDirection( $strSortOrder, "T2_Defend_the_Kirin_Contact",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Defend the Kirin Contact (good) or Reap the Kirin Mind (evil)\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Defend the Kirin Contact (good) or Reap the Kirin Mind (evil)"	>DKC</a></b></td>
				<td width="20%" align="center">	<b><a href="form.php?FormName=DoN_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=T2_Recover_the_Lost_Map&SortDirection='		. GetSortDirection( $strSortOrder, "T2_Recover_the_Lost_Map",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Recover the Lost Map (good) or Army of Stone (evil)\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Recover the Lost Map (good) or Army of Stone (evil)"				>RLM</a></b></td>
				<td width="20%" align="center">	<b><a href="form.php?FormName=DoN_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=T2_Turn_the_Tides_of_the_Sand&SortDirection='	. GetSortDirection( $strSortOrder, "T2_Turn_the_Tides_of_the_Sand",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Turn the Tides of the Sand (good) or Blood from the Sand (evil)\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Turn the Tides of the Sand (good) or Blood from the Sand (evil)"	>TTS</a></b></td>
				<td width="20%" align="center">	<b><a href="form.php?FormName=DoN_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=T2_Sickness_of_the_Spirit&SortDirection='		. GetSortDirection( $strSortOrder, "T2_Sickness_of_the_Spirit",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Sickness of the Spirit (good) or Drake Egg (evil)\';return true;"					OnMouseOut="window.status=\'\'"	target=Body title="Sickness of the Spirit (good) or Drake Egg (evil)"				>SotS</a></b></td>
				<td width="20%" align="center">	<b><a href="form.php?FormName=DoN_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=T2_Calling_Emoush&SortDirection='				. GetSortDirection( $strSortOrder, "T2_Calling_Emoush",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Calling Emoush\';return true;"														OnMouseOut="window.status=\'\'"	target=Body title="Calling Emoush"													>CE</a></b></td>
			  </tr>
			  </table>
			</td>
			<td align="center"><br>|</td>
			<td width="24%">
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="100%" align="center"><b>Tier 3</b></td>
			  </tr>
			  </table>
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="16%" align="center">	<b><a href="form.php?FormName=DoN_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=T3_Protect_the_Waters&SortDirection='		. GetSortDirection( $strSortOrder, "T3_Protect_the_Waters",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Protect the Waters (good) or Muddy the Waters (evil)\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Protect the Waters (good) or Muddy the Waters (evil)"	>PtW</a></b></td>
				<td width="16%" align="center">	<b><a href="form.php?FormName=DoN_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=T3_Snowfoots_Revenge&SortDirection='		. GetSortDirection( $strSortOrder, "T3_Snowfoots_Revenge",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Snowfoots Revenge (good) or Snowfoot Attack (evil)\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Snowfoots Revenge (good) or Snowfoot Attack (evil)"		>SR</a></b></td>
				<td width="17%" align="center">	<b><a href="form.php?FormName=DoN_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=T3_The_Sacred_Scrolls&SortDirection='		. GetSortDirection( $strSortOrder, "T3_The_Sacred_Scrolls",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by The Sacred Scrolls (good) or The Gilded Scroll (evil)\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="The Sacred Scrolls (good) or The Gilded Scroll (evil)"	>TSS</a></b></td>
				<td width="17%" align="center">	<b><a href="form.php?FormName=DoN_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=T3_History_of_the_Isle&SortDirection='	. GetSortDirection( $strSortOrder, "T3_History_of_the_Isle",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by History of the Isle (good) or Knowledge is Power (evil)\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="History of the Isle (good) or Knowledge is Power (evil)"	>HotI</a></b></td>
				<td width="17%" align="center">	<b><a href="form.php?FormName=DoN_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=T3_Trial_of_Perserverance&SortDirection='	. GetSortDirection( $strSortOrder, "T3_Trial_of_Perserverance",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Trial of Perserverance\';return true;"										OnMouseOut="window.status=\'\'"	target=Body title="Trial of Perserverance"									>ToP</a></b></td>
				<td width="17%" align="center">	<b><a href="form.php?FormName=DoN_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=T3_Volkaras_Bite&SortDirection='			. GetSortDirection( $strSortOrder, "T3_Volkaras_Bite",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Volkara\\\'s Bite\';return true;"											OnMouseOut="window.status=\'\'"	target=Body title="Volkara\'s Bite"											>VB</a></b></td>
			  </tr>
			  </table>
			</td>
			<td align="center"><br>|</td>
			<td width="12%">
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="100%" align="center"><b>Tier 4</b></td>
			  </tr>
			  </table>
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="33%" align="center">	<b><a href="form.php?FormName=DoN_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=T4_Goblin_Dojo&SortDirection='			. GetSortDirection( $strSortOrder, "T4_Goblin_Dojo",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Goblin Dojo\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Goblin Dojo"				>GD</a></b></td>
				<td width="33%" align="center">	<b><a href="form.php?FormName=DoN_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=T4_Guardian_of_the_Sands&SortDirection='	. GetSortDirection( $strSortOrder, "T4_Guardian_of_the_Sands",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Guardian of the Sands\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Guardian of the Sands"	>GotS</a></b></td>
				<td width="34%" align="center">	<b><a href="form.php?FormName=DoN_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=T4_Volkaras_Bite&SortDirection='			. GetSortDirection( $strSortOrder, "T4_Volkaras_Bite",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by An End to the Storms\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="An End to the Storms"	>ES</a></b></td>
			  </tr>
			  </table>
			</td>
			<td align="center"><br>|</td>
			<td width="12%">
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="100%" align="center"><b>Tier 5</b></td>
			  </tr>
			  </table>
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="33%" align="center">	<b><a href="form.php?FormName=DoN_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=T5_Origins_of_the_Curse&SortDirection='	. GetSortDirection( $strSortOrder, "T5_Origins_of_the_Curse",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Origins of the Curse\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Origins of the Curse"	>OotC</a></b></td>
				<td width="33%" align="center">	<b><a href="form.php?FormName=DoN_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=T5_The_Curse_of_JuRek&SortDirection='		. GetSortDirection( $strSortOrder, "T5_The_Curse_of_JuRek",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by The Curse of Ju\\\'Rek\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="The Curse of Ju\'Rek"	>TCoJ</a></b></td>
				<td width="34%" align="center">	<b><a href="form.php?FormName=DoN_Flags&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=T5_In_the_Shadows&SortDirection='			. GetSortDirection( $strSortOrder, "T5_In_the_Shadows",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by In the Shadows\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="In the Shadows"			>ItS</a></b></td>
			  </tr>
			  </table>
			</td>
		  </tr>
		</table>
		</div>
		<!-- End of Header -->
		';
	}

	
	
	// ========================================================================
	// Show all the records on screen
	// ========================================================================
	// This function will loop through all the records in the database table,
	// and create a html table entry for each one of them.
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS		= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];
		$strClassFilter		= $_GET['ClassFilter'];

		// Declare variables
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT CharName, NameMain, T1_Create_an_Antidote, T1_Greed_of_the_Goblins, T1_Burning_Arrows, T1_Children_of_Gimblax, T2_Defend_the_Kirin_Contact, T2_Recover_the_Lost_Map, T2_Turn_the_Tides_of_the_Sand, T2_Sickness_of_the_Spirit, T2_Calling_Emoush, T3_Protect_the_Waters, T3_Snowfoots_Revenge, T3_The_Sacred_Scrolls, T3_History_of_the_Isle, T3_Trial_of_Perserverance, T3_Volkaras_Bite, T4_Goblin_Dojo, T4_Guardian_of_the_Sands, T4_An_End_to_the_Storms, T5_Origins_of_the_Curse, T5_The_Curse_of_JuRek, T5_In_the_Shadows, OldMember \n" .
							  "FROM DoN_Flags \n" .
							  "LEFT JOIN Characters ON (DoN_Flags.CharID = Characters.CharID) \n" .
							  "WHERE (	T1_Create_an_Antidote > 0			OR \n" .
							  "			T1_Greed_of_the_Goblins > 0			OR \n" .
							  "			T1_Burning_Arrows > 0				OR \n" .
							  "			T1_Children_of_Gimblax > 0			OR \n" .
							  "			T2_Defend_the_Kirin_Contact > 0		OR \n" .
							  "			T2_Recover_the_Lost_Map > 0			OR \n" .
							  "			T2_Turn_the_Tides_of_the_Sand > 0	OR \n" .
							  "			T2_Sickness_of_the_Spirit > 0		OR \n" .
							  "			T2_Calling_Emoush > 0				OR \n" .
							  "			T3_Protect_the_Waters > 0			OR \n" .
							  "			T3_Snowfoots_Revenge > 0			OR \n" .
							  "			T3_The_Sacred_Scrolls > 0			OR \n" .
							  "			T3_History_of_the_Isle > 0			OR \n" .
							  "			T3_Trial_of_Perserverance > 0		OR \n" .
							  "			T3_Volkaras_Bite > 0				OR \n" .
							  "			T4_Goblin_Dojo > 0					OR \n" .
							  "			T4_Guardian_of_the_Sands > 0		OR \n" .
							  "			T4_An_End_to_the_Storms > 0			OR \n" .
							  "			T5_Origins_of_the_Curse > 0			OR \n" .
							  "			T5_The_Curse_of_JuRek > 0			OR \n" .
							  "			T5_In_the_Shadows > 0 )				   \n";

		// Check if we should set a class filter
		if( ( isset( $strClassFilter ) ) &&
			( $strClassFilter != "" ) &&
			( $strClassFilter != "<<All>>" ) )
		{
			$strSelectQuery	.= "AND Class = '" . $strClassFilter . "'";
		} 

		// Check if we should use the default sort order
		if( ( !isset( $strSortOrder ) ) ||
			( $strSortOrder == "" ) )
		{
			// Default sort on Character name
			$strSortOrder	= "CharName"; 
		}

		// Sorting on all numbers should be reversed (Desc first, then Asc)
		$strModifiedSortDirection	= $strSortDirection;
		if( $strSortOrder != "CharName" )
		{
			// Switch the sort order around
			if( $strModifiedSortDirection == "DESC" )
			{
				$strModifiedSortDirection	= "";
			}
			else
			{
				$strModifiedSortDirection	= "DESC";
			}
		}
	
		// Add the sort order
		$strSelectQuery		.= "ORDER BY " . $strSortOrder . " " . $strModifiedSortDirection . ", CharName";
	
		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
		<div id="RosterMainBody">
		<table id="RosterTable" width="100%" border="0" cellpadding="0" cellspacing="0">
		';
	
		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex							= 0;
			$strCharName					= $aResult[$nIndex++];
			$strNameMain					= $aResult[$nIndex++];
			$nT1_Create_an_Antidote			= $aResult[$nIndex++];
			$nT1_Greed_of_the_Goblins		= $aResult[$nIndex++];
			$nT1_Burning_Arrows				= $aResult[$nIndex++];
			$nT1_Children_of_Gimblax		= $aResult[$nIndex++];
			$nT2_Defend_the_Kirin_Contact	= $aResult[$nIndex++];
			$nT2_Recover_the_Lost_Map		= $aResult[$nIndex++];
			$nT2_Turn_the_Tides_of_the_Sand	= $aResult[$nIndex++];
			$nT2_Sickness_of_the_Spirit		= $aResult[$nIndex++];
			$nT2_Calling_Emoush				= $aResult[$nIndex++];
			$nT3_Protect_the_Waters			= $aResult[$nIndex++];
			$nT3_Snowfoots_Revenge			= $aResult[$nIndex++];
			$nT3_The_Sacred_Scrolls			= $aResult[$nIndex++];
			$nT3_History_of_the_Isle		= $aResult[$nIndex++];
			$nT3_Trial_of_Perserverance		= $aResult[$nIndex++];
			$nT3_Volkaras_Bite				= $aResult[$nIndex++];
			$nT4_Goblin_Dojo				= $aResult[$nIndex++];
			$nT4_Guardian_of_the_Sands		= $aResult[$nIndex++];
			$nT4_An_End_to_the_Storms		= $aResult[$nIndex++];
			$nT5_Origins_of_the_Curse		= $aResult[$nIndex++];
			$nT5_The_Curse_of_JuRek			= $aResult[$nIndex++];
			$nT5_In_the_Shadows				= $aResult[$nIndex++];
			$nOldMember						= $aResult[$nIndex++];
	
			// Only show old members for the administrator
			if( ( $strCharName != "" ) &&
				( ( $nOldMember == 0 ) ||
				  ( IsAdministrator( $strUserName ) ) ) )
			{
				// Show the Veeshans Peak key parts
				$this->ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nT1_Create_an_Antidote, $nT1_Greed_of_the_Goblins, $nT1_Burning_Arrows, $nT1_Children_of_Gimblax, $nT2_Defend_the_Kirin_Contact, $nT2_Recover_the_Lost_Map, $nT2_Turn_the_Tides_of_the_Sand, $nT2_Sickness_of_the_Spirit, $nT2_Calling_Emoush, $nT3_Protect_the_Waters, $nT3_Snowfoots_Revenge, $nT3_The_Sacred_Scrolls, $nT3_History_of_the_Isle, $nT3_Trial_of_Perserverance, $nT3_Volkaras_Bite, $nT4_Goblin_Dojo, $nT4_Guardian_of_the_Sands, $nT4_An_End_to_the_Storms, $nT5_Origins_of_the_Curse, $nT5_The_Curse_of_JuRek, $nT5_In_the_Shadows, $nOldMember, $strRowType );
		
				// Switch RowType, so the rows alternate	
				if( $strRowType == "OddRow" )
				{
					$strRowType	= "EvenRow";
				}
				else
				{
					$strRowType	= "OddRow";
				}
			}
		}
	
		// End the table
		echo '
		</table>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );
	}
	
	
	
	// ========================================================================
	// Show a record
	// ========================================================================
	// This function will create a html table row for a record in the table
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// In:  Variables containing the data to show 
	// ========================================================================
	function ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nT1_Create_an_Antidote, $nT1_Greed_of_the_Goblins, $nT1_Burning_Arrows, $nT1_Children_of_Gimblax, $nT2_Defend_the_Kirin_Contact, $nT2_Recover_the_Lost_Map, $nT2_Turn_the_Tides_of_the_Sand, $nT2_Sickness_of_the_Spirit, $nT2_Calling_Emoush, $nT3_Protect_the_Waters, $nT3_Snowfoots_Revenge, $nT3_The_Sacred_Scrolls, $nT3_History_of_the_Isle, $nT3_Trial_of_Perserverance, $nT3_Volkaras_Bite, $nT4_Goblin_Dojo, $nT4_Guardian_of_the_Sands, $nT4_An_End_to_the_Storms, $nT5_Origins_of_the_Curse, $nT5_The_Curse_of_JuRek, $nT5_In_the_Shadows, $nOldMember, $strRowType )
	{
		// Declare variables
		$strImageCheck						= '<img src="' . GetSkinDir() . 'images/check.gif" border="0" />';
		$strDeleteChar						= '';
		$strT1_Create_an_Antidote			= "";
		$strT1_Greed_of_the_Goblins			= "";
		$strT1_Burning_Arrows				= "";
		$strT1_Children_of_Gimblax			= "";
		$strT2_Defend_the_Kirin_Contact		= "";
		$strT2_Recover_the_Lost_Map			= "";
		$strT2_Turn_the_Tides_of_the_Sand	= "";
		$strT2_Sickness_of_the_Spirit		= "";
		$strT2_Calling_Emoush				= "";
		$strT3_Protect_the_Waters			= "";
		$strT3_Snowfoots_Revenge			= "";
		$strT3_The_Sacred_Scrolls			= "";
		$strT3_History_of_the_Isle			= "";
		$strT3_Trial_of_Perserverance		= "";
		$strT3_Volkaras_Bite				= "";
		$strT4_Goblin_Dojo					= "";
		$strT4_Guardian_of_the_Sands		= "";
		$strT4_An_End_to_the_Storms			= "";
		$strT5_Origins_of_the_Curse			= "";
		$strT5_The_Curse_of_JuRek			= "";
		$strT5_In_the_Shadows				= "";
	
		// Set the check-image for all filled variables
		if( $nCompleted > 0 )						{	$strCompleted						= $strImageCheck;	}
		if( $nT1_Create_an_Antidote > 0 )			{	$strT1_Create_an_Antidote			= $strImageCheck;	}
		if( $nT1_Greed_of_the_Goblins > 0 )			{	$strT1_Greed_of_the_Goblins			= $strImageCheck;	}
		if( $nT1_Burning_Arrows > 0 )				{	$strT1_Burning_Arrows				= $strImageCheck;	}
		if( $nT1_Children_of_Gimblax > 0 )			{	$strT1_Children_of_Gimblax			= $strImageCheck;	}
		if( $nT2_Defend_the_Kirin_Contact > 0 )		{	$strT2_Defend_the_Kirin_Contact		= $strImageCheck;	}
		if( $nT2_Recover_the_Lost_Map > 0 )			{	$strT2_Recover_the_Lost_Map			= $strImageCheck;	}
		if( $nT2_Turn_the_Tides_of_the_Sand > 0 )	{	$strT2_Turn_the_Tides_of_the_Sand	= $strImageCheck;	}
		if( $nT2_Sickness_of_the_Spirit > 0 )		{	$strT2_Sickness_of_the_Spirit		= $strImageCheck;	}
		if( $nT2_Calling_Emoush > 0 )				{	$strT2_Calling_Emoush				= $strImageCheck;	}
		if( $nT3_Protect_the_Waters > 0 )			{	$strT3_Protect_the_Waters			= $strImageCheck;	}
		if( $nT3_Snowfoots_Revenge > 0 )			{	$strT3_Snowfoots_Revenge			= $strImageCheck;	}
		if( $nT3_The_Sacred_Scrolls > 0 )			{	$strT3_The_Sacred_Scrolls			= $strImageCheck;	}
		if( $nT3_History_of_the_Isle > 0 )			{	$strT3_History_of_the_Isle			= $strImageCheck;	}
		if( $nT3_Trial_of_Perserverance > 0 )		{	$strT3_Trial_of_Perserverance		= $strImageCheck;	}
		if( $nT3_Volkaras_Bite > 0 )				{	$strT3_Volkaras_Bite				= $strImageCheck;	}
		if( $nT4_Goblin_Dojo > 0 )					{	$strT4_Goblin_Dojo					= $strImageCheck;	}
		if( $nT4_Guardian_of_the_Sands > 0 )		{	$strT4_Guardian_of_the_Sands		= $strImageCheck;	}
		if( $nT4_An_End_to_the_Storms > 0 )			{	$strT4_An_End_to_the_Storms			= $strImageCheck;	}
		if( $nT5_Origins_of_the_Curse > 0 )			{	$strT5_Origins_of_the_Curse			= $strImageCheck;	}
		if( $nT5_The_Curse_of_JuRek > 0 )			{	$strT5_The_Curse_of_JuRek			= $strImageCheck;	}
		if( $nT5_In_the_Shadows > 0 )				{	$strT5_In_the_Shadows				= $strImageCheck;	}
	
		// Check if it's an old member
		if( $nOldMember == 1 )
		{
			$strRowType		= "DeletedRow";

			// Allow the deletion of old members
			$strDeleteChar	= ' <a href="form.php?FormName=Character_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=DoN_Flags&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Delete ' . $strCharName . '\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Delete ' . $strCharName . '"><img src="' . GetSkinDir() . 'images/delete.gif" border="0" /></a>';
		}
	
		// Check if this character belongs to the logged in User
		$strModify	= "";
		if( ( isset( $strUserName ) ) &&
			( isset( $strNameMain ) ) &&
			( $strUserName == $strNameMain ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=DoN_Flags&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify.gif" border="0" />';
		}
		else if( IsAdministrator( $strUserName ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=DoN_Flags&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify_others.gif" border="0" />';
		}
	
		echo '
		  <tr	onMouseOver="this.bgColor=\'' . $this->theSkin->strRowHighlightColor . '\'" onMouseOut="this.bgColor=\'\'">
			<td width= "5%" align="center">'				. $strModify						. '</td>
			<td width="11%" class="' . $strRowType . '">'	. $strCharName						. $strDeleteChar . '</td>
			<td width= "4%" align="center">'				. $strT1_Create_an_Antidote			. '</td>
			<td width= "4%" align="center">'				. $strT1_Greed_of_the_Goblins		. '</td>
			<td width= "4%" align="center">'				. $strT1_Burning_Arrows				. '</td>
			<td width= "4%" align="center">'				. $strT1_Children_of_Gimblax		. '</td>
			<td width= "4%" align="center">'				. $strT2_Defend_the_Kirin_Contact	. '</td>
			<td width= "4%" align="center">'				. $strT2_Recover_the_Lost_Map		. '</td>
			<td width= "4%" align="center">'				. $strT2_Turn_the_Tides_of_the_Sand	. '</td>
			<td width= "4%" align="center">'				. $strT2_Sickness_of_the_Spirit		. '</td>
			<td width= "4%" align="center">'				. $strT2_Calling_Emoush				. '</td>
			<td width= "4%" align="center">'				. $strT3_Protect_the_Waters			. '</td>
			<td width= "4%" align="center">'				. $strT3_Snowfoots_Revenge			. '</td>
			<td width= "4%" align="center">'				. $strT3_The_Sacred_Scrolls			. '</td>
			<td width= "4%" align="center">'				. $strT3_History_of_the_Isle		. '</td>
			<td width= "4%" align="center">'				. $strT3_Trial_of_Perserverance		. '</td>
			<td width= "4%" align="center">'				. $strT3_Volkaras_Bite				. '</td>
			<td width= "4%" align="center">'				. $strT4_Goblin_Dojo				. '</td>
			<td width= "4%" align="center">'				. $strT4_Guardian_of_the_Sands		. '</td>
			<td width= "4%" align="center">'				. $strT4_An_End_to_the_Storms		. '</td>
			<td width= "4%" align="center">'				. $strT5_Origins_of_the_Curse		. '</td>
			<td width= "4%" align="center">'				. $strT5_The_Curse_of_JuRek			. '</td>
			<td width= "4%" align="center">'				. $strT5_In_the_Shadows				. '</td>
		  </tr>
		';
	}

}

?>
