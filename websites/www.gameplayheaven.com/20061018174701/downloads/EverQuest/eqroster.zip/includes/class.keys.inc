<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );
require_once( GetSkinDir() . 'class.skin.inc' );


// ============================================================================
// The Keys class
// ============================================================================
// This class provides an interface to the Keys_Flags table
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class Keys
{
	// Member variables
	var $theSkin;
	var $bShowVerticalScrollbars	= true;

	// ========================================================================
	// Constructor
	// ========================================================================
	function Keys()
	{
		// Create the skin
		$this->theSkin	= new Skin();
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "Keys";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<div id="Header">
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td width= "5%"></td>
	  		<td width="18%">				<b><a href="form.php?FormName=Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=CharName&SortDirection='			. GetSortDirection( $strSortOrder, "CharName",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Name\';return true;"							OnMouseOut="window.status=\'\'"	target=Body title="Name"							>Name</a></b></td>
			<td width="11%" align="center">	<b><a href="form.php?FormName=Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=BoT_Tower_Key&SortDirection='		. GetSortDirection( $strSortOrder, "BoT_Tower_Key",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Bastion of Thunder: Tower key\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Bastion of Thunder: Tower key"	>BoT<br />Tower</a></b></td>
			<td width="11%" align="center">	<b><a href="form.php?FormName=Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Howling_Stones_Key&SortDirection='	. GetSortDirection( $strSortOrder, "Howling_Stones_Key",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Howling Stones key\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Howling Stones key"				>Howling<br />Stones</a></b></td>
			<td width="11%" align="center">	<b><a href="form.php?FormName=Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Sebilis_Key&SortDirection='		. GetSortDirection( $strSortOrder, "Sebilis_Key",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Sebilis key\';return true;"					OnMouseOut="window.status=\'\'"	target=Body title="Sebilis key"						>Sebilis</a></b></td>
			<td width="11%" align="center">	<b><a href="form.php?FormName=Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Sleepers_Tomb_Key&SortDirection='	. GetSortDirection( $strSortOrder, "Sleepers_Tomb_Key",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Sleepers Tomb key\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Sleepers Tomb key"				>Sleepers<br />Tomb</a></b></td>
			<td width="11%" align="center">	<b><a href="form.php?FormName=Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=SSRA_Emperor_Key&SortDirection='	. GetSortDirection( $strSortOrder, "SSRA_Emperor_Key",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by SSRA Emperor key\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="SSRA Emperor key"				>SSRA<br />Emperor</a></b></td>
			<td width="11%" align="center">	<b><a href="form.php?FormName=Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Veeshans_Peak_Key&SortDirection='	. GetSortDirection( $strSortOrder, "Veeshans_Peak_Key",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Veeshans Peak key\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Veeshans Peak key"				>Veeshans<br />Peak</a></b></td>
			<td width="11%" align="center">	<b><a href="form.php?FormName=Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Vex_Thal_Key&SortDirection='		. GetSortDirection( $strSortOrder, "Vex_Thal_Key",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Vex Thal key\';return true;"					OnMouseOut="window.status=\'\'"	target=Body title="Vex Thal key"					>Vex<br />Thal</a></b></td>
		  </tr>
		</table>
		</div>
		<!-- End of Header -->
		';
	}
	
	
	
	// ========================================================================
	// Show all the records on screen
	// ========================================================================
	// This function will loop through all the records in the database table,
	// and create a html table entry for each one of them.
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS		= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];
		$strClassFilter		= $_GET['ClassFilter'];

		// Declare variables
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT CharName, NameMain, BoT_Tower_Key, Howling_Stones_Key, Sebilis_Key, Sleepers_Tomb_Key, SSRA_Emperor_Key, Veeshans_Peak_Key, Vex_Thal_Key, OldMember \n" .
							  "FROM `Keys` \n" .
							  "LEFT JOIN Characters ON (Keys.CharID = Characters.CharID) \n" .
							  "WHERE (	BoT_Tower_Key > 0		OR \n" .
							  "			Howling_Stones_Key > 0	OR \n" .
							  "			Sebilis_Key > 0			OR \n" .
							  "			Sleepers_Tomb_Key > 0	OR \n" .
							  "			SSRA_Emperor_Key > 0	OR \n" .
							  "			Veeshans_Peak_Key > 0	OR \n" .
							  "			Vex_Thal_Key > 0 )		   \n";
	
		// Check if we should set a class filter
		if( ( isset( $strClassFilter ) ) &&
			( $strClassFilter != "" ) &&
			( $strClassFilter != "<<All>>" ) )
		{
			$strSelectQuery	.= "AND Class = '" . $strClassFilter . "'";
		} 

		// Check if we should use the default sort order
		if( ( !isset( $strSortOrder ) ) ||
			( $strSortOrder == "" ) )
		{
			// Default sort on Character name
			$strSortOrder	= "CharName"; 
		}

		// Sorting on all numbers should be reversed (Desc first, then Asc)
		$strModifiedSortDirection	= $strSortDirection;
		if( $strSortOrder != "CharName" )
		{
			// Switch the sort order around
			if( $strModifiedSortDirection == "DESC" )
			{
				$strModifiedSortDirection	= "";
			}
			else
			{
				$strModifiedSortDirection	= "DESC";
			}
		}
	
		// Add the sort order
		$strSelectQuery		.= "ORDER BY " . $strSortOrder . " " . $strModifiedSortDirection . ", CharName";
	
		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
		<div id="Body">
		<table id="RosterTable" width="100%" border="0" cellpadding="0" cellspacing="0">
		';
	
		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex					= 0;
			$strCharName			= $aResult[$nIndex++];
			$strNameMain			= $aResult[$nIndex++];
			$nBoT_Tower_Key			= $aResult[$nIndex++];
			$nHowling_Stones_Key	= $aResult[$nIndex++];
			$nSebilis_Key			= $aResult[$nIndex++];
			$nSleepers_Tomb_Key		= $aResult[$nIndex++];
			$nSSRA_Emperor_Key		= $aResult[$nIndex++];
			$nVeeshans_Peak_Key		= $aResult[$nIndex++];
			$nVex_Thal_Key			= $aResult[$nIndex++];
			$nOldMember				= $aResult[$nIndex++];
	
			// Only show old members for the administrator
			if( ( $strCharName != "" ) &&
				( ( $nOldMember == 0 ) ||
				  ( IsAdministrator( $strUserName ) ) ) )
			{
				// Show a Keys record
				$this->ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nBoT_Tower_Key, $nHowling_Stones_Key, $nSebilis_Key, $nSleepers_Tomb_Key, $nSSRA_Emperor_Key, $nVeeshans_Peak_Key, $nVex_Thal_Key, $nOldMember, $strRowType );
		
				// Switch RowType, so the rows alternate	
				if( $strRowType == "OddRow" )
				{
					$strRowType	= "EvenRow";
				}
				else
				{
					$strRowType	= "OddRow";
				}
			}
		}
	
		// End the table
		echo '
		</table>
		</div>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );
	}
	
	
	
	// ========================================================================
	// Show a record
	// ========================================================================
	// This function will create a html table row for a record in the table
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// In:  Variables containing the data to show 
	// ========================================================================
	function ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nBoT_Tower_Key, $nHowling_Stones_Key, $nSebilis_Key, $nSleepers_Tomb_Key, $nSSRA_Emperor_Key, $nVeeshans_Peak_Key, $nVex_Thal_Key, $nOldMember, $strRowType )
	{
		// Declare variables
		$strImageCheck			= '<img src="' . GetSkinDir() . 'images/check.gif" border="0" />';
		$strDeleteChar			= "";
		$strBoT_Tower_Key		= "";
		$strHowling_Stones_Key	= "";
		$strSebilis_Key			= "";
		$strSleepers_Tomb_Key	= "";
		$strSSRA_Emperor_Key	= "";
		$strVeeshans_Peak_Key	= "";
		$strVex_Thal_Key		= "";
	
		// Set the check-image for all filled variables
		if( $nBoT_Tower_Key > 0 )		{	$strBoT_Tower_Key		= $strImageCheck;	}
		if( $nHowling_Stones_Key > 0 )	{	$strHowling_Stones_Key	= $strImageCheck;	}
		if( $nSebilis_Key > 0 )			{	$strSebilis_Key			= $strImageCheck;	}
		if( $nSleepers_Tomb_Key > 0 )	{	$strSleepers_Tomb_Key	= $strImageCheck;	}
		if( $nSSRA_Emperor_Key > 0 )	{	$strSSRA_Emperor_Key	= $strImageCheck;	}
		if( $nVeeshans_Peak_Key > 0 )	{	$strVeeshans_Peak_Key	= $strImageCheck;	}
		if( $nVex_Thal_Key > 0 )		{	$strVex_Thal_Key		= $strImageCheck;	}
	
		// Check if it's an old member
		if( $nOldMember == 1 )
		{
			$strRowType		= "DeletedRow";

			// Allow the deletion of old members
			$strDeleteChar	= ' <a href="form.php?FormName=Character_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=Keys&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Delete ' . $strCharName . '\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Delete ' . $strCharName . '"><img src="' . GetSkinDir() . 'images/delete.gif" border="0" /></a>';
		}
	
		// Check if this character belongs to the logged in User
		$strModify	= "";
		if( ( isset( $strUserName ) ) &&
			( isset( $strNameMain ) ) &&
			( $strUserName == $strNameMain ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=Keys&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify.gif" border="0" />';
		}
		else if( IsAdministrator( $strUserName ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=Keys&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify_others.gif" border="0" />';
		}
	
		echo '
		  <tr	onMouseOver="this.bgColor=\'' . $this->theSkin->strRowHighlightColor . '\'" onMouseOut="this.bgColor=\'\'">
			<td width= "5%" align="center">'				. $strModify				. '</td>
			<td width="18%" class="' . $strRowType . '">'	. $strCharName				. $strDeleteChar . '</td>
			<td width="11%" align="center">'				. $strBoT_Tower_Key			. '</td>
			<td width="11%" align="center">'				. $strHowling_Stones_Key	. '</td>
			<td width="11%" align="center">'				. $strSebilis_Key			. '</td>
			<td width="11%" align="center">'				. $strSleepers_Tomb_Key		. '</td>
			<td width="11%" align="center">'				. $strSSRA_Emperor_Key		. '</td>
			<td width="11%" align="center">'				. $strVeeshans_Peak_Key		. '</td>
			<td width="11%" align="center">'				. $strVex_Thal_Key			. '</td>
		  </tr>
		';
	}

}

?>
