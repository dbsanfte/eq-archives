<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );
require_once( GetSkinDir() . 'class.skin.inc' );


// ============================================================================
// The Character_Delete class
// ============================================================================
// This class handles the Character_Delete procedure
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class Character_Delete
{
	// Member variables
	var $theSkin;

	// ========================================================================
	// Constructor
	// ========================================================================
	function Character_Delete()
	{
		// Create the skin
		$this->theSkin	= new Skin();
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "Character Delete";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<!-- End of Header -->
		';
	}
	
	
	
	// ========================================================================
	// Show the body
	// ========================================================================
	// This function will show the character delete page
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS	= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strCharName		= $_GET['CharName'];
		$strPreviousForm	= $_GET['PreviousForm'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];
		$strClassFilter		= $_GET['ClassFilter'];
		$bDeleteChar		= $_GET['cbDeleteChar'];
		$bCancelDelete		= $_GET['cbCancelDelete'];

		// Check if the user cancelled
		if( ( isset( $bCancelDelete ) ) &&
			( $bCancelDelete == "true" ) )
		{
			// Go back to the previous form
			LoadForm( $strPreviousForm, "&UserName=" . $strUserName . "&Password=" . $strPassword . "&SortOrder=" . $strSortOrder . "&SortDirection=" . $strSortDirection  . "&ShowAlts=" . $strShowAlts . "&ClassFilter=" . $strClassFilter );
		}

		// Check if the UserName is an admin
		if( ( isset( $strUserName ) ) &&
			( $strUserName != "" ) && 
			( IsAdministrator( $strUserName ) ) )
		{
			// Check if the user clicked delete
			if( ( isset( $bDeleteChar ) ) &&
				( $bDeleteChar == "true" ) )
			{
				// Delete the character
				$this->DeleteCharacter( $strUserName, $strPassword, $strCharName, $strPreviousForm, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter, $bDeleteChar );
			}
			else
			{
				// Show the delete character page
				$this->ShowCharacterDeletePage( $strUserName, $strPassword, $strCharName, $strPreviousForm, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter, $bDeleteChar );
			}
		}
		else
		{
			// Show error
			print( "Only administators can delete characters..." );
		}
	}
	
	
	
	// ========================================================================
	// Delete a character
	// ========================================================================
	function DeleteCharacter( $strUserName, $strPassword, $strCharName, $strPreviousForm, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter, $bDeleteChar )
	{
		// Start the form
		echo '
		<form name="formDeletingCharacter" method="post" action="form.php?FormName=' . $strPreviousForm . '&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&ClassFilter=' . $strClassFilter . '" target=Body>
		  <div id="Body" align="center"> 
		    <p><strong><font color="' . $this->theSkin->strBodyFontColor . '" size="+3"><em>
		      Deleting character "' . $strCharName . '"
		    </em></font></strong></p>
			<br />
		';		
		print( "\n" );

		// Get the CharID
		$nCharID	= $this->GetCharID( $strCharName );
		if( $nCharID > 0 )
		{
			// Delete the character
			$this->DeleteCharacterRecord( 'Characters', $nCharID );
			// Delete the Tradeskill record
			$this->DeleteCharacterRecord( 'TradeSkills', $nCharID );
			// Delete the Keys record
			$this->DeleteCharacterRecord( 'Keys', $nCharID );
			// Delete the PoS_Askr_Quest record
			$this->DeleteCharacterRecord( 'PoS_Askr_Quest', $nCharID );
			// Delete the SSRA_Emperor_Key record
			$this->DeleteCharacterRecord( 'SSRA_Emperor_Key', $nCharID );
			// Delete the Veeshans_Peak_Key record
			$this->DeleteCharacterRecord( 'Veeshans_Peak_Key', $nCharID );
			// Delete the Vex_Thal_Key record
			$this->DeleteCharacterRecord( 'Vex_Thal_Key', $nCharID );
			// Delete the Pop Tier 1 Flags record
			$this->DeleteCharacterRecord( 'PoP_Tier_1_Flags', $nCharID );
			// Delete the Pop Tier 2 Flags record
			$this->DeleteCharacterRecord( 'PoP_Tier_2_Flags', $nCharID );
			// Delete the Pop Tier 3 Flags record
			$this->DeleteCharacterRecord( 'PoP_Tier_3_Flags', $nCharID );
			// Delete the Pop Tier 4 Flags record
			$this->DeleteCharacterRecord( 'PoP_Tier_4_Flags', $nCharID );
			// Delete the GoD Flags record
			$this->DeleteCharacterRecord( 'GoD_Flags', $nCharID );
		}

		// Close the form
		echo '
			<br />
		    <input type="submit" name="pbDone" value="Done">
		  </div>
		</form>
		';
	}



	// ========================================================================
	// Get a character's CharID
	// ========================================================================
	function GetCharID( $strCharName )
	{
		// Declare variables
		$nCharID		= -1;
		$strSelectQuery	= "SELECT CharID FROM Characters WHERE CharName = '$strCharName'";

		// Connect to the database
		$nLinkID		= DBConnect();

		// Retrieve the CharID for this character
		$nResult		= mysql_query( $strSelectQuery, $nLinkID );
		$aResult		= mysql_fetch_row( $nResult );
		// Store the CharID
		if( isset( $aResult[0] ) )
		{
			$nCharID	= $aResult[0];
		}
		else
		{
			print( "			<font color=\"" . $this->theSkin->strErrorColor . "\"><a> Character \"$strCharName\" not found!<br /></a></font>\n" );
		}

		// Close the connection
		DBDisconnect( $nLinkID );

		return $nCharID;
	}



	// ========================================================================
	// Delete a character record from a table
	// ========================================================================
	function DeleteCharacterRecord( $strTableName, $nCharID )
	{
		// Connect to the database
		$nLinkID		= DBConnect();
		$nNrOfRecords	= 0;

		// Declare variables
		$strDeleteQuery	= "DELETE FROM `$strTableName` WHERE CharID = '$nCharID'";
		// Delete the record
		$nResult		= mysql_query( $strDeleteQuery, $nLinkID );

		// Check if the delete was succesfull
		if( $nResult == 1 )
		{
			// Check ho wmany rows where deleted
			if( mysql_affected_rows() == 1 )
			{
				print( "			<font color=\"" . $this->theSkin->strOKColor . "\">\"$strTableName\" record deleted.<br /></font>\n" );
			}
			else if( mysql_affected_rows() == 0 )
			{
				print( "			<font color=\"" . $this->theSkin->strWarningColor . "\">No \"$strTableName\" record found.<br /></font>\n" );
			}
			else
			{
				print( "			<font color=\"" . $this->theSkin->strErrorColor . "\">" . mysql_affected_rows() . " \"$strTableName\" records deleted!<br /></font>\n" );
			}
		}
		else
		{
			// Show error message
			print( "			<font color=\"" . $this->theSkin->strErrorColor . "\">\"$strTableName\" record delete FAILED!<br /></font>\n" );
			print( "			$strDeleteQuery<br />\n" );
			print( "			" . mysql_error() . "<br />\n" );
		}
	
		// Close the connection
		DBDisconnect( $nLinkID );
	
		return $nCharID;
	}



	// ========================================================================
	// Show the character delete page
	// ========================================================================
	function ShowCharacterDeletePage( $strUserName, $strPassword, $strCharName, $strPreviousForm, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter, $bDeleteChar )
	{
		echo '
		<!-- JavaScript block has been added here instead of in the header on purpose -->
		<script language="JavaScript">

		<!-- Delete the Char -->
		function DeleteCharacter()
		{
			// Validation complete, all fields are valid
			document.formDeleteCharacter.cbDeleteChar.value		= true;
			document.formDeleteCharacter.cbDeleteChar.checked	= true;

			// Submit the form
			document.formDeleteCharacter.submit();

			// Done
			return true;
		};

		<!-- Cancel the delete -->
		function CancelDelete()
		{
			// Cancel
			document.formDeleteCharacter.cbCancelDelete.value	= true;
			document.formDeleteCharacter.cbCancelDelete.checked	= true;

			// Submit the form
			document.formDeleteCharacter.submit();

			// Done
			return true;
		};
		</script>


		<form name="formDeleteCharacter" method="post" action="form.php?FormName=Character_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&PreviousForm=' . $strPreviousForm . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&ClassFilter=' . $strClassFilter . '" target=Body>
		  <div id="Body" align="center"> 
			<br />
			<br />
			<font size="+2" color="' . $this->theSkin->strErrorColor . '">
			  Are you sure you want to delete the character "' . $strCharName . '" and all his/her records?<br />
			</font>
			<br />
		    <input type="submit" name="pbCancel" value="Cancel" onclick="CancelDelete();">
		    <input type="submit" name="pbDelete" value="Delete" onclick="DeleteCharacter();">
		    <!-- Hidden field to store CancelModify status -->
	        <input name="cbCancelDelete" type="hidden" id="cbCancelDelete" value="false">
		    <!-- Hidden field to store Delete status -->
	        <input name="cbDeleteChar" type="hidden" id="cbDeleteChar" value="' . $bDeleteChar . '">
		  </div>
		</form>
		';
	}

}

?>
