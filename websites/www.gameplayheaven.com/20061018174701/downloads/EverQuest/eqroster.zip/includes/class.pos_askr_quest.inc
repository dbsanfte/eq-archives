<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );
require_once( GetSkinDir() . 'class.skin.inc' );


// ============================================================================
// The PoS_Askr_Quest class
// ============================================================================
// This class provides an interface to the PoS_Askr_Quest table
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class PoS_Askr_Quest
{
	// Member variables
	var $theSkin;
	var $bShowVerticalScrollbars	= true;

	// ========================================================================
	// Constructor
	// ========================================================================
	function PoS_Askr_Quest()
	{
		// Create the skin
		$this->theSkin	= new Skin();
	}

	// ========================================================================
	// Get the title of this list
	// ========================================================================
	// Out:	The title of this list
	// ========================================================================
	function GetTitle()
	{
		return "PoS Askr Quest";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<div id="Header">
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td width= "5%" align="center">' . GetInfoLink( "PoS_Askr_Quest", "Plane of Storms: Askr Quest information" ) . '</td>
			<td width="15%">				<b><a href="form.php?FormName=PoS_Askr_Quest&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=CharName&SortDirection='			. GetSortDirection( $strSortOrder, "CharName",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Name\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Name"			>Name</a></b></td>
			<td width="10%" align="center">	<b><a href="form.php?FormName=PoS_Askr_Quest&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Head&SortDirection='				. GetSortDirection( $strSortOrder, "Head",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Head\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Head"			>Head</a></b></td>
			<td width="10%" align="center">	<b><a href="form.php?FormName=PoS_Askr_Quest&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Beard&SortDirection='			. GetSortDirection( $strSortOrder, "Beard",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Beard\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Beard"			>Beard<br />(Ocean)</a></b></td>
			<td width="10%" align="center">	<b><a href="form.php?FormName=PoS_Askr_Quest&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Bone&SortDirection='				. GetSortDirection( $strSortOrder, "Bone",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Bone\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Bone"			>Bone<br />(Desert)</a></b></td>
			<td width="10%" align="center">	<b><a href="form.php?FormName=PoS_Askr_Quest&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Sash&SortDirection='				. GetSortDirection( $strSortOrder, "Sash",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Sash\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Sash"			>Sash<br />(Forest)</a></b></td>
			<td width="10%" align="center">	<b><a href="form.php?FormName=PoS_Askr_Quest&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=OceanMedal&SortDirection='		. GetSortDirection( $strSortOrder, "OceanMedal",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Ocean Medalion\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Ocean Medalion"	>Ocean<br />Medalion</a></b></td>
			<td width="10%" align="center">	<b><a href="form.php?FormName=PoS_Askr_Quest&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=DesertMedal&SortDirection='		. GetSortDirection( $strSortOrder, "DesertMedal",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Desert Medalion\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Desert Medalion"	>Desert<br />Medalion</a></b></td>
			<td width="10%" align="center">	<b><a href="form.php?FormName=PoS_Askr_Quest&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=ForestMedal&SortDirection='		. GetSortDirection( $strSortOrder, "ForestMedal",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Forest Medalion\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Forest Medalion"	>Forest<br />Medalion</a></b></td>
			<td width= "5%"></td>
			<td width= "5%" align="center">	<b><a href="form.php?FormName=PoS_Askr_Quest&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=PoS_Askr_Quest&SortDirection='	. GetSortDirection( $strSortOrder, "PoS_Askr_Quest",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Flag completed\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Flag completed"	>Done</a></b></td>
		  </tr>
		</table>
		</div>
		<!-- End of Header -->
		';
	}
	
	
	
	// ========================================================================
	// Show all the records on screen
	// ========================================================================
	// This function will loop through all the records in the database table,
	// and create a html table entry for each one of them.
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS		= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];
		$strClassFilter		= $_GET['ClassFilter'];

		// Declare variables
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT CharName, NameMain, PoS_Askr_Quest, Head, Beard, Bone, Sash, OceanMedal, DesertMedal, ForestMedal, OldMember \n" .
							  "FROM PoS_Askr_Quest \n" .
							  "LEFT JOIN Characters       ON (PoS_Askr_Quest.CharID = Characters.CharID) \n" .
							  "LEFT JOIN PoP_Tier_2_Flags ON (PoS_Askr_Quest.CharID = PoP_Tier_2_Flags.CharID) \n" .
							  "WHERE (	PoS_Askr_Quest > 0	OR \n" .
							  "			Head > 0			OR \n" .
							  "			Beard > 0			OR \n" .
							  "			Bone > 0			OR \n" .
							  "			Sash > 0			OR \n" .
							  "			OceanMedal > 0		OR \n" .
							  "			DesertMedal > 0		OR \n" .
							  "			ForestMedal > 0 )	   \n";	

		// Check if we should set a class filter
		if( ( isset( $strClassFilter ) ) &&
			( $strClassFilter != "" ) &&
			( $strClassFilter != "<<All>>" ) )
		{
			$strSelectQuery	.= "AND Class = '" . $strClassFilter . "'";
		} 

		// Check if we should use the default sort order
		if( ( !isset( $strSortOrder ) ) ||
			( $strSortOrder == "" ) )
		{
			// Default sort on Character name
			$strSortOrder	= "CharName"; 
		}

		// Sorting on all numbers should be reversed (Desc first, then Asc)
		$strModifiedSortDirection	= $strSortDirection;
		if( $strSortOrder != "CharName" )
		{
			// Switch the sort order around
			if( $strModifiedSortDirection == "DESC" )
			{
				$strModifiedSortDirection	= "";
			}
			else
			{
				$strModifiedSortDirection	= "DESC";
			}
		}
	
		// Add the sort order
		$strSelectQuery		.= "ORDER BY " . $strSortOrder . " " . $strModifiedSortDirection . ", CharName";
	
		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
		<div id="Body">
		<table id="RosterTable" width="100%" border="0" cellpadding="0" cellspacing="0">
		';
	
		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex				= 0;
			$strCharName		= $aResult[$nIndex++];
			$strNameMain		= $aResult[$nIndex++];
			$nCompleted			= $aResult[$nIndex++];
			$nHead				= $aResult[$nIndex++];
			$nBeard				= $aResult[$nIndex++];
			$nBone				= $aResult[$nIndex++];
			$nSash				= $aResult[$nIndex++];
			$nOceanMedal		= $aResult[$nIndex++];
			$nDesertMedal		= $aResult[$nIndex++];
			$nForestMedal		= $aResult[$nIndex++];
			$nOldMember			= $aResult[$nIndex++];
	
			// Only show old members for the administrator
			if( ( $strCharName != "" ) &&
				( ( $nOldMember == 0 ) ||
				  ( IsAdministrator( $strUserName ) ) ) )
			{
				// Show the BoT Flag parts
				$this->ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nCompleted, $nHead, $nBeard, $nBone, $nSash, $nOceanMedal, $nDesertMedal, $nForestMedal, $nOldMember, $strRowType );
		
				// Switch RowType, so the rows alternate	
				if( $strRowType == "OddRow" )
				{
					$strRowType	= "EvenRow";
				}
				else
				{
					$strRowType	= "OddRow";
				}
			}
		}
	
		// End the table
		echo '
		</table>
		</div>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );
	}
	
	
	
	// ========================================================================
	// Show a record
	// ========================================================================
	// This function will create a html table row for a record in the table
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// In:  Variables containing the data to show 
	// ========================================================================
	function ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nCompleted, $nHead, $nBeard, $nBone, $nSash, $nOceanMedal, $nDesertMedal, $nForestMedal, $nOldMember, $strRowType )
	{
		// Declare variables
		$strImageCheck			= '<img src="' . GetSkinDir() . 'images/check.gif" border="0" />';
		$strDeleteChar			= "";
		$strCompleted			= "";
		$strHead				= "";
		$strBeard				= "";
		$strBone				= "";
		$strSash				= "";
		$strOceanMedal			= "";
		$strDesertMedal			= "";
		$strForestMedal			= "";
	
		// Set the check-image for all filled variables
		if( $nCompleted > 0 )			{	$strCompleted			= $strImageCheck;	}
		if( $nHead > 0 )				{	$strHead				= $strImageCheck;	}
		if( $nBeard > 0 )				{	$strBeard				= $strImageCheck;	}
		if( $nBone > 0 )				{	$strBone				= $strImageCheck;	}
		if( $nSash > 0 )				{	$strSash				= $strImageCheck;	}
		if( $nOceanMedal > 0 )			{	$strOceanMedal			= $strImageCheck;	}
		if( $nDesertMedal > 0 )			{	$strDesertMedal			= $strImageCheck;	}
		if( $nForestMedal > 0 )			{	$strForestMedal			= $strImageCheck;	}
	
		// Check if it's an old member
		if( $nOldMember == 1 )
		{
			$strRowType		= "DeletedRow";

			// Allow the deletion of old members
			$strDeleteChar	= ' <a href="form.php?FormName=Character_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=PoS_Askr_Quest&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Delete ' . $strCharName . '\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Delete ' . $strCharName . '"><img src="' . GetSkinDir() . 'images/delete.gif" border="0" /></a>';
		}
	
		// Check if this character belongs to the logged in User
		$strModify	= "";
		if( ( isset( $strUserName ) ) &&
			( isset( $strNameMain ) ) &&
			( $strUserName == $strNameMain ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=PoS_Askr_Quest&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify.gif" border="0" />';
		}
		else if( IsAdministrator( $strUserName ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=PoS_Askr_Quest&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify_others.gif" border="0" />';
		}
	
		echo '
		  <tr	onMouseOver="this.bgColor=\'' . $this->theSkin->strRowHighlightColor . '\'" onMouseOut="this.bgColor=\'\'">
			<td width= "5%" align="center">'				. $strModify		. '</td>
			<td width="15%" class="' . $strRowType . '">'	. $strCharName		. $strDeleteChar . '</td>
			<td width="10%" align="center">'				. $strHead			. '</td>
			<td width="10%" align="center">'				. $strBeard			. '</td>
			<td width="10%" align="center">'				. $strBone			. '</td>
			<td width="10%" align="center">'				. $strSash			. '</td>
			<td width="10%" align="center">'				. $strOceanMedal	. '</td>
			<td width="10%" align="center">'				. $strDesertMedal	. '</td>
			<td width="10%" align="center">'				. $strForestMedal	. '</td>
			<td width= "5%"></td>
			<td width= "5%" align="center">'				. $strCompleted	. '</td>
		  </tr>
		';
	}

}

?>
