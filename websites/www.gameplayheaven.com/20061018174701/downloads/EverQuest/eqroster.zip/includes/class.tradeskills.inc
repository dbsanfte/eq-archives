<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );
require_once( GetSkinDir() . 'class.skin.inc' );


// ============================================================================
// The TradeSkills class
// ============================================================================
// This class provides an interface to the TradeSkill table
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class TradeSkills
{
	// Member variables
	var $theSkin;
	var $bShowVerticalScrollbars	= true;

	// ========================================================================
	// Constructor
	// ========================================================================
	function TradeSkills()
	{
		// Create the skin
		$this->theSkin	= new Skin();
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "TradeSkills";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<div id="Header">
		<br />
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td width= "2%" align="center">' . GetInfoLink( "TradeSkills", "Trade Skills information" ) . '</td>
			<td width= "7%">				<b><a href="form.php?FormName=TradeSkills&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=CharName&SortDirection='	. GetSortDirection( $strSortOrder, "CharName",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Name\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Name"		>Name</a></b></td>
			<td width= "7%" align="center">	<b><a href="form.php?FormName=TradeSkills&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Alchemy&SortDirection='		. GetSortDirection( $strSortOrder, "Alchemy",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Alchemy\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Alchemy"		>Alchemy</a></b></td>
			<td width= "7%" align="center">	<b><a href="form.php?FormName=TradeSkills&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Baking&SortDirection='		. GetSortDirection( $strSortOrder, "Baking",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Baking\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Baking"		>Baking</a></b></td>
			<td width= "7%" align="center">	<b><a href="form.php?FormName=TradeSkills&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Brewing&SortDirection='		. GetSortDirection( $strSortOrder, "Brewing",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Brewing\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Brewing"		>Brewing</a></b></td>
			<td width= "7%" align="center">	<b><a href="form.php?FormName=TradeSkills&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Fishing&SortDirection='		. GetSortDirection( $strSortOrder, "Fishing",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Fishing\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Fishing"		>Fishing</a></b></td>
			<td width= "7%" align="center">	<b><a href="form.php?FormName=TradeSkills&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Fletching&SortDirection='	. GetSortDirection( $strSortOrder, "Fletching",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Fletching\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Fletching"	>Fletch.</a></b></td>
			<td width= "7%" align="center">	<b><a href="form.php?FormName=TradeSkills&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Foraging&SortDirection='	. GetSortDirection( $strSortOrder, "Foraging",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Foraging\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Foraging"	>Forag.</a></b></td>
			<td width= "7%" align="center">	<b><a href="form.php?FormName=TradeSkills&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Jewelcraft&SortDirection='	. GetSortDirection( $strSortOrder, "Jewelcraft",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Jewelcraft\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Jewelcraft"	>Jewel.</a></b></td>
			<td width= "7%" align="center">	<b><a href="form.php?FormName=TradeSkills&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Poison&SortDirection='		. GetSortDirection( $strSortOrder, "Poison",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Poison\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Poison"		>Poison</a></b></td>
			<td width= "7%" align="center">	<b><a href="form.php?FormName=TradeSkills&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Pottery&SortDirection='		. GetSortDirection( $strSortOrder, "Pottery",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Pottery\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Pottery"		>Pottery</a></b></td>
			<td width= "7%" align="center">	<b><a href="form.php?FormName=TradeSkills&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Research&SortDirection='	. GetSortDirection( $strSortOrder, "Research",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Research\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Research"	>Research</a></b></td>
			<td width= "7%" align="center">	<b><a href="form.php?FormName=TradeSkills&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Smithing&SortDirection='	. GetSortDirection( $strSortOrder, "Smithing",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Smithing\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Smithing"	>Smithing</a></b></td>
			<td width= "7%" align="center">	<b><a href="form.php?FormName=TradeSkills&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Tailoring&SortDirection='	. GetSortDirection( $strSortOrder, "Tailoring",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Tailoring\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Tailoring"	>Tailor.</a></b></td>
			<td width= "7%" align="center">	<b><a href="form.php?FormName=TradeSkills&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Tinkering&SortDirection='	. GetSortDirection( $strSortOrder, "Tinkering",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Tinkering\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Tinkering"	>Tinker.</a></b></td>
		  </tr>
		</table>
		</div>
		<!-- End of Header -->
		';
	}
	
	
	
	// ========================================================================
	// Show all the records on screen
	// ========================================================================
	// This function will loop through all the records in the database table,
	// and create a html table entry for each one of them.
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS		= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];
		$strClassFilter		= $_GET['ClassFilter'];

		// Declare variables
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT CharName, NameMain, Alchemy, Baking, Brewing, Fishing, Fletching, Foraging, Jewelcraft, Poison, Pottery, Research, Smithing, Tailoring, Tinkering, OldMember \n" .
							  "FROM TradeSkills \n" .
							  "LEFT JOIN Characters ON (TradeSkills.CharID = Characters.CharID) \n" .
							  "WHERE (	Alchemy > 0		OR \n" .
							  "			Baking > 0		OR \n" .
							  "			Brewing > 0		OR \n" .
							  "			Fishing > 0		OR \n" .
							  "			Fletching > 0	OR \n" .
							  "			Foraging > 0	OR \n" .
							  "			Jewelcraft > 0	OR \n" .
							  "			Poison > 0		OR \n" .
							  "			Pottery > 0		OR \n" .
							  "			Research > 0	OR \n" .
							  "			Smithing > 0	OR \n" .
							  "			Tailoring > 0	OR \n" .
							  "			Tinkering > 0 )	   \n";

		// Check if we should set a class filter
		if( ( isset( $strClassFilter ) ) &&
			( $strClassFilter != "" ) &&
			( $strClassFilter != "<<All>>" ) )
		{
			$strSelectQuery	.= "AND Class = '" . $strClassFilter . "'";
		} 

		// Check if we should use the default sort order
		if( ( !isset( $strSortOrder ) ) ||
			( $strSortOrder == "" ) )
		{
			// Default sort on Character name
			$strSortOrder	= "CharName"; 
		}

		// Sorting on all numbers should be reversed (Desc first, then Asc)
		$strModifiedSortDirection	= $strSortDirection;
		if( $strSortOrder != "CharName" )
		{
			// Switch the sort order around
			if( $strModifiedSortDirection == "DESC" )
			{
				$strModifiedSortDirection	= "";
			}
			else
			{
				$strModifiedSortDirection	= "DESC";
			}
		}
	
		// Add the sort order
		$strSelectQuery		.= "ORDER BY " . $strSortOrder . " " . $strModifiedSortDirection . ", CharName";
	
		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
		<div id="Body">
		<table id="RosterTable" width="100%" border="0" cellpadding="0" cellspacing="0">
		';
	
		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex				= 0;
			$strCharName		= $aResult[$nIndex++];
			$strNameMain		= $aResult[$nIndex++];
			$nAlchemy			= $aResult[$nIndex++];
			$nBaking			= $aResult[$nIndex++];
			$nBrewing			= $aResult[$nIndex++];
			$nFishing			= $aResult[$nIndex++];
			$nFletching			= $aResult[$nIndex++];
			$nForaging			= $aResult[$nIndex++];
			$nJewelcraft		= $aResult[$nIndex++];
			$nPoison			= $aResult[$nIndex++];
			$nPottery			= $aResult[$nIndex++];
			$nResearch			= $aResult[$nIndex++];
			$nSmithing			= $aResult[$nIndex++];
			$nTailoring			= $aResult[$nIndex++];
			$nTinkering			= $aResult[$nIndex++];
			$nOldMember			= $aResult[$nIndex++];
	
			// Only show old members for the administrator
			if( ( $strCharName != "" ) &&
				( ( $nOldMember == 0 ) ||
				  ( IsAdministrator( $strUserName ) ) ) )
			{
				// Show the TradeSkills
				$this->ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nAlchemy, $nBaking, $nBrewing, $nFishing, $nFletching, $nForaging, $nJewelcraft, $nPoison, $nPottery, $nResearch, $nSmithing, $nTailoring, $nTinkering, $nOldMember, $strRowType );
		
				// Switch RowType, so the rows alternate	
				if( $strRowType == "OddRow" )
				{
					$strRowType	= "EvenRow";
				}
				else
				{
					$strRowType	= "OddRow";
				}
			}
		}
	
		// End the table
		echo '
		</table>
		</div>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );
	}
	
	
	
	// ========================================================================
	// Show a record
	// ========================================================================
	// This function will create a html table row for a record in the table
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// In:  Variables containing the data to show 
	// ========================================================================
	function ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nAlchemy, $nBaking, $nBrewing, $nFishing, $nFletching, $nForaging, $nJewelcraft, $nPoison, $nPottery, $nResearch, $nSmithing, $nTailoring, $nTinkering, $nOldMember, $strRowType )
	{
		// Declare variables
		$strDeleteChar		= "";

		// Check if it's an old member
		if( $nOldMember == 1 )
		{
			$strRowType		= "DeletedRow";

			// Allow the deletion of old members
			$strDeleteChar	= ' <a href="form.php?FormName=Character_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=TradeSkills&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Delete ' . $strCharName . '\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Delete ' . $strCharName . '"><img src="' . GetSkinDir() . 'images/delete.gif" border="0" /></a>';
		}
	
		// Check if this character belongs to the logged in User
		$strModify	= "";
		if( ( isset( $strUserName ) ) &&
			( isset( $strNameMain ) ) &&
			( $strUserName == $strNameMain ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=TradeSkills&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify.gif" border="0" />';
		}
		else if( IsAdministrator( $strUserName ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=TradeSkills&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify_others.gif" border="0" />';
		}
	
		echo '
		  <tr	onMouseOver="this.bgColor=\'' . $this->theSkin->strRowHighlightColor . '\'" onMouseOut="this.bgColor=\'\'">
			<td width= "2%" align="center">'																	. $strModify	. '</td>
			<td width= "7%" class="' . $strRowType . '">'														. $strCharName	. $strDeleteChar . '</td>
			<td width= "7%" class="' . $this->GetCellClass( $nAlchemy, $strRowType )	. '" align="center">'	. $nAlchemy		. '</td>
			<td width= "7%" class="' . $this->GetCellClass( $nBaking, $strRowType )		. '" align="center">'	. $nBaking		. '</td>
			<td width= "7%" class="' . $this->GetCellClass( $nBrewing, $strRowType )	. '" align="center">'	. $nBrewing		. '</td>
			<td width= "7%" class="' . $this->GetCellClass( $nFishing, $strRowType )	. '" align="center">'	. $nFishing		. '</td>
			<td width= "7%" class="' . $this->GetCellClass( $nFletching, $strRowType )	. '" align="center">'	. $nFletching	. '</td>
			<td width= "7%" class="' . $this->GetCellClass( $nForaging, $strRowType )	. '" align="center">'	. $nForaging	. '</td>
			<td width= "7%" class="' . $this->GetCellClass( $nJewelcraft, $strRowType )	. '" align="center">'	. $nJewelcraft	. '</td>
			<td width= "7%" class="' . $this->GetCellClass( $nPoison, $strRowType )		. '" align="center">'	. $nPoison		. '</td>
			<td width= "7%" class="' . $this->GetCellClass( $nPottery, $strRowType )	. '" align="center">'	. $nPottery		. '</td>
			<td width= "7%" class="' . $this->GetCellClass( $nResearch, $strRowType )	. '" align="center">'	. $nResearch	. '</td>
			<td width= "7%" class="' . $this->GetCellClass( $nSmithing, $strRowType )	. '" align="center">'	. $nSmithing	. '</td>
			<td width= "7%" class="' . $this->GetCellClass( $nTailoring, $strRowType )	. '" align="center">'	. $nTailoring	. '</td>
			<td width= "7%" class="' . $this->GetCellClass( $nTinkering, $strRowType )	. '" align="center">'	. $nTinkering	. '</td>
		  </tr>
		';
	}



	// ========================================================================
	// Get the font color for a tradeskill
	// ========================================================================
	// This function will determine (and return) the font color for a skill
	// All skills higher then 200 will receive a different color.
	// ========================================================================
	// In:	$nValue			= Value of skill
	// In:	$strRowType		= Default RowType
	// Out:	RowType to use
	// ========================================================================
	function GetCellClass( $nValue, $strRowType )
	{
		// If the tradeskill has a high value
		if( $nValue >= 200 )
		{
			// Check which RowType was in use
			if( $strRowType == "EvenRow" )
			{
				return "EvenRowHighSkill";
			}
			else if( $strRowType == "OddRow" )
			{
				return "OddRowHighSkill";
			}
		}
		// Otherwise return the defautl font color
		return $strRowType;
	}

}

?>
