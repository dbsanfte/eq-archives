<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );
require_once( GetSkinDir() . 'class.skin.inc' );


// ============================================================================
// The DoD_Mask class
// ============================================================================
// This class provides an interface to the Mask missions in the DoD_Flags table
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class DoD_Mask
{
	// Member variables
	var $theSkin;
	var $bShowVerticalScrollbars	= true;

	// ========================================================================
	// Constructor
	// ========================================================================
	function DoD_Mask()
	{
		// Create the skin
		$this->theSkin	= new Skin();
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "DoD Mask Missions";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<div id="Header">
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td width= "5%" align="center"><br />' . GetInfoLink( "DoD_MaskQuest", "Depths of Darkhollow quest information" ) . '</td>
			<td width="11%">					<b><a href="form.php?FormName=DoD_Mask&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=CharName&SortDirection='				. GetSortDirection( $strSortOrder, "CharName",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Name\';return true;"					OnMouseOut="window.status=\'\'"	target=Body title="Name"					><br />Name</a></b></td>
			<td width="30%">
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="100%" align="center"><b>Elder Longshadow</b>' . GetInfoLink( "DoD_ElderLongshadow", "Mission information" ) . '</td>
			  </tr>
			  </table>
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="20%" align="center">	<b><a href="form.php?FormName=DoD_Mask&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Freeing_an_Elder&SortDirection='		. GetSortDirection( $strSortOrder, "Freeing_an_Elder",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Freeing an Elder\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Freeing an Elder"		>FaE</a></b></td>
				<td width="20%" align="center">	<b><a href="form.php?FormName=DoD_Mask&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Orb_of_Subversion&SortDirection='		. GetSortDirection( $strSortOrder, "Orb_of_Subversion",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Orb of Subversion\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Orb of Subversion"		>OoS</a></b></td>
				<td width="20%" align="center">	<b><a href="form.php?FormName=DoD_Mask&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=A_Plea_for_Help&SortDirection='		. GetSortDirection( $strSortOrder, "A_Plea_for_Help",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by A Plea for Help\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="A Plea for Help"			>APfH</a></b></td>
				<td width="20%" align="center">	<b><a href="form.php?FormName=DoD_Mask&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Trailing_Longshadow&SortDirection='	. GetSortDirection( $strSortOrder, "Trailing_Longshadow",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Trailing Longshadow\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Trailing Longshadow"		>TL</a></b></td>
				<td width="20%" align="center">	<b><a href="form.php?FormName=DoD_Mask&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Confronting_a_Traitor&SortDirection='	. GetSortDirection( $strSortOrder, "Confronting_a_Traitor",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Confronting a Traitor\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Confronting a Traitor"	>CaT</a></b></td>
			  </tr>
			  </table>
			</td>
			<td align="center"><br />|</td>
			<td width="24%">
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="100%" align="center"><b>Korlach Leviathan</b>' . GetInfoLink( "DoD_KorlachLeviathan", "Mission information" ) . '</td>
			  </tr>
			  </table>
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="25%" align="center">	<b><a href="form.php?FormName=DoD_Mask&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=The_Search_for_Coral&SortDirection='	. GetSortDirection( $strSortOrder, "The_Search_for_Coral",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by The Search for Coral\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="The Search for Coral"	>TSfC</a></b></td>
				<td width="25%" align="center">	<b><a href="form.php?FormName=DoD_Mask&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Learning_the_Power&SortDirection='		. GetSortDirection( $strSortOrder, "Learning_the_Power",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Learning the Power\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Learning the Power"		>LtP</a></b></td>
				<td width="25%" align="center">	<b><a href="form.php?FormName=DoD_Mask&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Discover_the_Secret&SortDirection='	. GetSortDirection( $strSortOrder, "Discover_the_Secret",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Discover the Secret\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Discover the Secret"		>DtS</a></b></td>
				<td width="25%" align="center">	<b><a href="form.php?FormName=DoD_Mask&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Taking_Control&SortDirection='			. GetSortDirection( $strSortOrder, "Taking_Control",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Taking Control\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Taking Control"			>TC</a></b></td>
			  </tr>
			  </table>
			</td>
			<td align="center"><br />|</td>
			<td width="30%">
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="100%" align="center"><b>Find Fibblebrap</b>' . GetInfoLink( "DoD_FindFibblebrap", "Mission information" ) . '</td>
			  </tr>
			  </table>
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="20%" align="center">	<b><a href="form.php?FormName=DoD_Mask&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=The_Mines&SortDirection='				. GetSortDirection( $strSortOrder, "The_Mines",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by The Mines\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="The Mines"				>TM</a></b></td>
				<td width="20%" align="center">	<b><a href="form.php?FormName=DoD_Mask&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Lost_Caverns&SortDirection='			. GetSortDirection( $strSortOrder, "Lost_Caverns",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Lost Caverns\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Lost Caverns"			>LC</a></b></td>
				<td width="20%" align="center">	<b><a href="form.php?FormName=DoD_Mask&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=The_Hive&SortDirection='				. GetSortDirection( $strSortOrder, "The_Hive",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by The Hive\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="The Hive"				>TH</a></b></td>
				<td width="20%" align="center">	<b><a href="form.php?FormName=DoD_Mask&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=The_Korlach&SortDirection='			. GetSortDirection( $strSortOrder, "The_Korlach",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by The Korlach\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="The Korlach"				>TK</a></b></td>
				<td width="20%" align="center">	<b><a href="form.php?FormName=DoD_Mask&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=The_Rescue&SortDirection='				. GetSortDirection( $strSortOrder, "The_Rescue",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by The Rescue\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="The Rescue"				>TR</a></b></td>
			  </tr>
			  </table>
			</td>
		  </tr>
		</table>
		</div>
		<!-- End of Header -->
		';
	}

	// ========================================================================
	// Show all the records on screen
	// ========================================================================
	// This function will loop through all the records in the database table,
	// and create a html table entry for each one of them.
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS		= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];
		$strClassFilter		= $_GET['ClassFilter'];

		// Declare variables
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT CharName, NameMain, Freeing_an_Elder, Orb_of_Subversion, A_Plea_for_Help, Trailing_Longshadow, Confronting_a_Traitor, The_Search_for_Coral, Learning_the_Power, Discover_the_Secret, Taking_Control, The_Mines, Lost_Caverns, The_Hive, The_Korlach, The_Rescue, OldMember \n" .
							  "FROM DoD_Flags \n" .
							  "LEFT JOIN Characters ON (DoD_Flags.CharID = Characters.CharID) \n" .
							  "WHERE (	Freeing_an_Elder > 0		OR \n" .
							  "			Orb_of_Subversion > 0		OR \n" .
							  "			A_Plea_for_Help > 0			OR \n" .
							  "			Trailing_Longshadow > 0		OR \n" .
							  "			Confronting_a_Traitor > 0	OR \n" .
							  "			The_Search_for_Coral > 0	OR \n" .
							  "			Learning_the_Power > 0		OR \n" .
							  "			Discover_the_Secret > 0		OR \n" .
							  "			Taking_Control > 0			OR \n" .
							  "			The_Mines > 0				OR \n" .
							  "			Lost_Caverns > 0			OR \n" .
							  "			The_Hive > 0				OR \n" .
							  "			The_Korlach > 0				OR \n" .
							  "			The_Rescue > 0 )			   \n";

		// Check if we should set a class filter
		if( ( isset( $strClassFilter ) ) &&
			( $strClassFilter != "" ) &&
			( $strClassFilter != "<<All>>" ) )
		{
			$strSelectQuery	.= "AND Class = '" . $strClassFilter . "'";
		} 

		// Check if we should use the default sort order
		if( ( !isset( $strSortOrder ) ) ||
			( $strSortOrder == "" ) )
		{
			// Default sort on Character name
			$strSortOrder	= "CharName"; 
		}

		// Sorting on all numbers should be reversed (Desc first, then Asc)
		$strModifiedSortDirection	= $strSortDirection;
		if( $strSortOrder != "CharName" )
		{
			// Switch the sort order around
			if( $strModifiedSortDirection == "DESC" )
			{
				$strModifiedSortDirection	= "";
			}
			else
			{
				$strModifiedSortDirection	= "DESC";
			}
		}
	
		// Add the sort order
		$strSelectQuery		.= "ORDER BY " . $strSortOrder . " " . $strModifiedSortDirection . ", CharName";
	
		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
		<div id="Body">
		<table id="RosterTable" width="100%" border="0" cellpadding="0" cellspacing="0">
		';
	
		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex					= 0;
			$strCharName			= $aResult[$nIndex++];
			$strNameMain			= $aResult[$nIndex++];
			$nFreeing_an_Elder		= $aResult[$nIndex++];
			$nOrb_of_Subversion		= $aResult[$nIndex++];
			$nA_Plea_for_Help		= $aResult[$nIndex++];
			$nTrailing_Longshadow	= $aResult[$nIndex++];
			$nConfronting_a_Traitor	= $aResult[$nIndex++];
			$nThe_Search_for_Coral	= $aResult[$nIndex++];
			$nLearning_the_Power	= $aResult[$nIndex++];
			$nDiscover_the_Secret	= $aResult[$nIndex++];
			$nTaking_Control		= $aResult[$nIndex++];
			$nThe_Mines				= $aResult[$nIndex++];
			$nLost_Caverns			= $aResult[$nIndex++];
			$nThe_Hive				= $aResult[$nIndex++];
			$nThe_Korlach			= $aResult[$nIndex++];
			$nThe_Rescue			= $aResult[$nIndex++];
			$nOldMember				= $aResult[$nIndex++];

			// Only show old members for the administrator
			if( ( $strCharName != "" ) &&
				( ( $nOldMember == 0 ) ||
				  ( IsAdministrator( $strUserName ) ) ) )
			{
				// Show the record
				$this->ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nFreeing_an_Elder, $nOrb_of_Subversion, $nA_Plea_for_Help, $nTrailing_Longshadow, $nConfronting_a_Traitor, $nThe_Search_for_Coral, $nLearning_the_Power, $nDiscover_the_Secret, $nTaking_Control, $nThe_Mines, $nLost_Caverns, $nThe_Hive, $nThe_Korlach, $nThe_Rescue, $nOldMember, $strRowType );
		
				// Switch RowType, so the rows alternate	
				if( $strRowType == "OddRow" )
				{
					$strRowType	= "EvenRow";
				}
				else
				{
					$strRowType	= "OddRow";
				}
			}
		}
	
		// End the table
		echo '
		</table>
		</div>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );
	}
	
	
	
	// ========================================================================
	// Show a record
	// ========================================================================
	// This function will create a html table row for a record in the table
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// In:  Variables containing the data to show 
	// ========================================================================
	function ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nFreeing_an_Elder, $nOrb_of_Subversion, $nA_Plea_for_Help, $nTrailing_Longshadow, $nConfronting_a_Traitor, $nThe_Search_for_Coral, $nLearning_the_Power, $nDiscover_the_Secret, $nTaking_Control, $nThe_Mines, $nLost_Caverns, $nThe_Hive, $nThe_Korlach, $nThe_Rescue, $nOldMember, $strRowType )
	{
		// Declare variables
		$strImageCheck				= '<img src="' . GetSkinDir() . 'images/check.gif" border="0" />';
		$strDeleteChar				= "";
		$strFreeing_an_Elder		= "";
		$strOrb_of_Subversion		= "";
		$strA_Plea_for_Help			= "";
		$strTrailing_Longshadow		= "";
		$strConfronting_a_Traitor	= "";
		$strThe_Search_for_Coral	= "";
		$strLearning_the_Power		= "";
		$strDiscover_the_Secret		= "";
		$strTaking_Control			= "";
		$strThe_Mines				= "";
		$strLost_Caverns			= "";
		$strThe_Hive				= "";
		$strThe_Korlach				= "";
		$strThe_Rescue				= "";

		// Set the check-image for all filled variables
		if( $nFreeing_an_Elder > 0 )		{	$strFreeing_an_Elder		= $strImageCheck;	}
		if( $nOrb_of_Subversion > 0 )		{	$strOrb_of_Subversion		= $strImageCheck;	}
		if( $nA_Plea_for_Help > 0 )			{	$strA_Plea_for_Help			= $strImageCheck;	}
		if( $nTrailing_Longshadow > 0 )		{	$strTrailing_Longshadow		= $strImageCheck;	}
		if( $nConfronting_a_Traitor > 0 )	{	$strConfronting_a_Traitor	= $strImageCheck;	}
		if( $nThe_Search_for_Coral > 0 )	{	$strThe_Search_for_Coral	= $strImageCheck;	}
		if( $nLearning_the_Power > 0 )		{	$strLearning_the_Power		= $strImageCheck;	}
		if( $nDiscover_the_Secret > 0 )		{	$strDiscover_the_Secret		= $strImageCheck;	}
		if( $nTaking_Control > 0 )			{	$strTaking_Control			= $strImageCheck;	}
		if( $nThe_Mines > 0 )				{	$strThe_Mines				= $strImageCheck;	}
		if( $nLost_Caverns > 0 )			{	$strLost_Caverns			= $strImageCheck;	}
		if( $nThe_Hive > 0 )				{	$strThe_Hive				= $strImageCheck;	}
		if( $nThe_Korlach > 0 )				{	$strThe_Korlach				= $strImageCheck;	}
		if( $nThe_Rescue > 0 )				{	$strThe_Rescue				= $strImageCheck;	}

		// Check if it's an old member
		if( $nOldMember == 1 )
		{
			$strRowType		= "DeletedRow";

			// Allow the deletion of old members
			$strDeleteChar	= ' <a href="form.php?FormName=Character_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=DoD_Mask&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Delete ' . $strCharName . '\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Delete ' . $strCharName . '"><img src="' . GetSkinDir() . 'images/delete.gif" border="0" /></a>';
		}
	
		// Check if this character belongs to the logged in User
		$strModify	= "";
		if( ( isset( $strUserName ) ) &&
			( isset( $strNameMain ) ) &&
			( $strUserName == $strNameMain ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=DoD_Mask&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify.gif" border="0" />';
		}
		else if( IsAdministrator( $strUserName ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=DoD_Mask&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify_others.gif" border="0" />';
		}

		echo '
		  <tr	onMouseOver="this.bgColor=\'' . $this->theSkin->strRowHighlightColor . '\'" onMouseOut="this.bgColor=\'\'">
			<td width= "5%" align="center">'				. $strModify				. '</td>
			<td width="11%" class="' . $strRowType . '">'	. $strCharName				. $strDeleteChar . '</td>
			<td width= "6%" align="center">'				. $strFreeing_an_Elder		. '</td>
			<td width= "6%" align="center">'				. $strOrb_of_Subversion		. '</td>
			<td width= "6%" align="center">'				. $strA_Plea_for_Help		. '</td>
			<td width= "6%" align="center">'				. $strTrailing_Longshadow	. '</td>
			<td width= "6%" align="center">'				. $strConfronting_a_Traitor	. '</td>
			<td width= "6%" align="center">'				. $strThe_Search_for_Coral	. '</td>
			<td width= "6%" align="center">'				. $strLearning_the_Power	. '</td>
			<td width= "6%" align="center">'				. $strDiscover_the_Secret	. '</td>
			<td width= "6%" align="center">'				. $strTaking_Control		. '</td>
			<td width= "6%" align="center">'				. $strThe_Mines				. '</td>
			<td width= "6%" align="center">'				. $strLost_Caverns			. '</td>
			<td width= "6%" align="center">'				. $strThe_Hive				. '</td>
			<td width= "6%" align="center">'				. $strThe_Korlach			. '</td>
			<td width= "6%" align="center">'				. $strThe_Rescue			. '</td>
		  </tr>
		';
	}

}

?>
