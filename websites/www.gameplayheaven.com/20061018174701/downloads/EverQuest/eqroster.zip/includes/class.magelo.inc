<?php
// Includes
require_once( './includes/class.httpconnection.inc' );
require_once( GetSkinDir() . 'class.skin.inc' );

// ============================================================================
// The Magelo class
// ============================================================================
// This class will retrieve and store all the info from a characters magelo
//
// Usage:
// Create a Magelo object, passing the required 3 parameters:
//	$theMagelo	= new Magelo( $strMageloNr, $strCharacterName, $strCharacterClass );
// Call the import function:
//	$bMageloImported	= $theMagelo->Import();
// Check if the Import succeeded
//	if( $bMageloImported == true )
//	{
//		// Perform your actions with the magelo variables here
//	}
//
// ============================================================================
class Magelo
{
	// Member variables
	var $theSkin;
	var $strMageloNr						= "";
	var $strCharName						= "";
	var $strClass							= "";
	// Character info
	var $nLevel								= 0;
	var $strDeity							= "";
	var $nAA								= 0;
	var $strLastName						= "";
	var $strRace							= "";
	// Character Statistics
	var $nHP								= 0;
	var $nMana								= 0;
	var $nEndurance							= 0;
	var $nAC								= 0;
	var $nFT								= 0;
	var $nRegen								= 0;
	var $nAtk								= 0;
	var $nStr								= 0;
	var $nSta								= 0;
	var $nAgi								= 0;
	var $nDex								= 0;
	var $nWis								= 0;
	var $nInt								= 0;
	var $nCha								= 0;
	var $nPR								= 0;
	var $nMR								= 0;
	var $nDR								= 0;
	var $nFR								= 0;
	var $nCR								= 0;
	// Tradeskills
	var $nForaging							= 0;
	var $nFishing							= 0;
	var $nSmithing							= 0;
	var $nBaking							= 0;
	var $nTailoring							= 0;
	var $nFletching							= 0;
	var $nBrewing							= 0;
	var $nJewelry							= 0;
	var $nPottery							= 0;
	var $nAlcoholTolerance					= 0;
	var $nAlchemy							= 0;
	var $nTinkering							= 0;
	var $nResearch							= 0;
	var $nPosionMaking						= 0;
	// Keys
	var $nVexThalKey						= 0;
	var $nSebilisKey						= 0;
	var $nVeeshansPeakKey					= 0;
	var $nHowlingStonesKey					= 0;
	var $nSleepersTombKey					= 0;
	var $nSSRAEmperorKey					= 0;
	// Group Leadership Points
	var $nNrOfGLPs							= 0;
	var $nMarkNPC							= 0;
	var $nNPCHealth							= 0;
	var $nDelegateMA						= 0;
	var $nDelegateMarkNPC					= 0;
	var $nInspectBuffs						= 0;
	var $nSpellAwareness					= 0;
	var $nOffEnh							= 0;
	var $nManaEnh							= 0;
	var $nHealthEnh							= 0;
	var $nHealthRegen						= 0;
	var $nFindPathToPC						= 0;
	var $nHealthOfTT						= 0;
		// Pop Tier 1 Flags
	var $nAny_PoJ_Trial						= 0;
	var $nAll_PoJ_Trials					= 0;
	var $nPoI_Xanamech						= 0;
	var $nPoI_Behemoth						= 0;
	var $nPoD_Grimror_Quest					= 0;
	var $nPoD_Grummus						= 0;
	var $nPoN_Hedge_Quest					= 0;
	var $nPoNb_Terris_Thule					= 0;
		// Pop Tier 2 Flags
	var $nPoS_Askr_Quest					= 0;
	var $nPoV_Grenic_Quest					= 0;
	var $nPoV_AerinDar						= 0;
	var $nCoD_Bertoxxulous					= 0;
	var $nPoTorment_Saryrn					= 0;
	var $nPoS_Wembly_Quest					= 0;
		// Pop Tier 3 Flags
	var $nHoH_Trial1_RyddaDar				= 0;
	var $nHoH_Trial2_Ogre					= 0;
	var $nHoH_Trial3_Madmen					= 0;
	var $nHoHb_Mithanial_Marr				= 0;
	var $nPoTactics_Tallon_Zek				= 0;
	var $nPoTactics_Vallon_Zek				= 0;
	var $nPoTactics_Rallos_Zek_Quest		= 0;
	var $nBoT_Rescue_Karana_Quest			= 0;
	var $nSolRoTower_Jiva					= 0;
	var $nSolRoTower_Xuzl					= 0;
	var $nSolRoTower_Arlyxir				= 0;
	var $nSolRoTower_Rizlona				= 0;
	var $nSolRoTower_Protector_of_Dresolik	= 0;
	var $nSolRoTower_Solusek_Ro				= 0;
		// Pop Tier 4 Flags
	var $nPoAir_Xegony						= 0;
	var $nPoFire_Fennin_Ro					= 0;
	var $nPoWater_Coirnav					= 0;
	var $nPoEarthb_The_Rathe				= 0;
	var $nPoTime_Time_Phased_Quintessence	= 0;
		// GoD Flags
	var $nPurifying_Plant					= 0;
	var $nEmanating_Furnace					= 0;
	var $nLair_of_Trapped_Ones				= 0;
	var $nPool_of_Sludge					= 0;
	var $nSmith_Rondo						= 0;
	var $nVxed								= 0;
	var $nTipt								= 0;
	var $nVrex_Barxt_Qurat					= 0;
	var $nCynosure_Kvanjji					= 0;
	var $nNoqufiel_in_Inktuta				= 0;
	var $nZunMuram_Tkarish_Zyk				= 0;
		// OoW_CoA Flags/Signets
	var	$nSeal_Mastery_of_All				= 0;
	var $nCrystal_Gemmed_Signet				= 0;
	var $nDiscolored_Signet					= 0;
	var $nDust_Marred_Signet				= 0;
	var $nGlimmering_Signet					= 0;
	var $nTarnished_Signet					= 0;
	var $nTwo_Toned_Signet					= 0;
	var $nWeather_Worn_Signet				= 0;
		// DoN Flags
	var $nDoN_Tier1_Done					= 0;
	var $nDoN_Tier2_Done					= 0;
	var $nDoN_Tier3_Done					= 0;
	var $nDoN_Tier4_Done					= 0;
	var $nDoN_Tier5_Done					= 0;



	// ========================================================================
	// Constructor
	// ========================================================================
	// In:	$strMageloNr	= String containing the Magelo Nr
	// In:	$strCharName	= String containing the Character name
	// In:	$strClass		= String containing the Character class
	// ========================================================================
	function Magelo( $strMageloNr, $strCharName, $strClass )
	{
		// Create the skin
		$this->theSkin	= new Skin();

		// Store the character settings
		$this->strMageloNr							= $strMageloNr;
		$this->strCharName							= $strCharName;
		$this->strClass								= $strClass;
	}


	
	// ========================================================================
	// Retrieve Character info from the magelo profile
	// ========================================================================
	// This function will open the magelo page and store it in memory.
	// It will then perform string manupilations to retrieve the character
	// details out of the magelo, and store them in variables.
	//
	// !!!WARNING!!!
	// DO NOT call this function a lot of times in a row.
	// If you want to retrieve the magelo's for a lot of characters in a row,
	// then make sure you wait 5 to 10 minutes between each call to this
	// function, otherwise your IP will get banned on the magelo site.
	// ========================================================================
	// Out:	Boolean indicating wether the import succeeded or failed
	// ========================================================================
	function Import()
	{
		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve the magelo profile into memory
		///////////////////////////////////////////////////////////////////////////////////
		$strHost		= "www.magelo.com";
		$strProtocol	= "HTTP/1.0";
		$strURL			= "/eq_view_profile.html?num=" . $this->strMageloNr;

		$astrHeaders[]	= new HTTP_Header( "Accept", "text/html, */*" );
		$astrHeaders[]	= new HTTP_Header( "User-Agent", "Mozilla/4.0 (compatible; MSIE 5.01; Windows 98;)" );
		$astrHeaders[]	= new HTTP_Header( "Host", $strHost );
		$astrHeaders[]	= new HTTP_Header( "Referer", "" );

		$strHTTPRequest	= new HTTP_Request( "GET", $strURL, $strProtocol, $astrHeaders );
		$theConnection	= new HTTP_Connection( $strHost );

		$theConnection->Connect();
		$theConnection->Request( $strHTTPRequest );
		$theConnection->Response( $theResponse );
		$theConnection->Close();

		// Retrieve the content
		$strContent		= $theResponse->GetEntityBody();

		// ignore the first 10 characters in the content
		$strContent		= substr( $strContent, 10 );
		// Unpack the content	
		$strContent		= gzinflate( $strContent );

		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve Character Info
		///////////////////////////////////////////////////////////////////////////////////
		// Adjust the class tag for ShadowKnights (Magelo uses 1 word, instead of the 2 in the roster)
		$strMageloClass		= $this->strClass;
		if( $strMageloClass == "Shadow Knight" )
		{
			$strMageloClass	= "Shadowknight";
		}

		// Retrieve the Level and Deity	
		if( ereg( $this->strCharName . "<br>([0-9]{1,2})(&nbsp;){1,2}" . $strMageloClass . "<br>([a-zA-Z -]+)", $strContent, $aMatches ) )
		{
			$this->nLevel				= $aMatches[1];
			$this->strDeity				= $aMatches[3];
		}
		else
		{
			// If this info wasn't found, abort the import
			return false;
		}
	
		// Retrieve the nr of AA's
		if( ereg( '<tr><td>Total:</td><td[[:space:]]align=\"right\"[[:space:]]style=\"color:\#FFFF00;\">([0-9]{1,4})</td></tr>', $strContent, $aMatches ) )
		{
			$this->nAA					= $aMatches[1];
		}
	
		// Retrieve the LastName and Race
		if( ereg( "document\.title=\"" . $this->strCharName . " ([a-zA-Z `\\\'-]+){0,1} {0,1}- ([a-zA-Z -]+) " . $strMageloClass, $strContent, $aMatches ) )
		{
			$this->strLastName			= $aMatches[1];
			$this->strRace				= $aMatches[2];
		}
	
		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve Character Statistics
		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve the HP
		if( ereg( 'Total HP:([0-9]{1,5})', $strContent, $aMatches ) )
		{
			$this->nHP					= $aMatches[1];
		}

		// Retrieve the Mana
		if( ereg( 'MANA</td><td>([0-9]{1,5})</td><td>([0-9]{1,5})</td><td>([0-9]{1,5})</td><td>([0-9]{1,5})</td>', $strContent, $aMatches ) )
		{
			$this->nMana				= $aMatches[4];
		}

		// Retrieve the Endurance
/*		if( ereg( 'MANA</td><td>([0-9]{1,5})</td><td>([0-9]{1,5})</td><td>([0-9]{1,5})</td><td>([0-9]{1,5})</td>', $strContent, $aMatches ) )
		{
			$this->nEndurance			= $aMatches[4];
		}
*/
		// Retrieve the AC
		if( ereg( 'TOTAL AC</td><td>([0-9]{1,4})</td>', $strContent, $aMatches ) )
		{
			$this->nAC					= $aMatches[1];
		}

		// Retrieve the Flowing Thought
		if( ereg( 'Regen of ([0-9]{1,2}) mana per tick', $strContent, $aMatches ) )
		{
			$this->nFT					= $aMatches[1];
		}

		// Retrieve the Regen
		if( ereg( 'HP Regen</td><td align="center">([0-9]{1,2})/([0-9]{1,2})</td><td align="center">([0-9]{1,2})</td><td align="center">([0-9]{1,2})/([0-9]{1,2})', $strContent, $aMatches ) )
		{
			$this->nRegen				= $aMatches[4];
		}

		// Retrieve the Atk
		if( ereg( '\("atk"\).innerHTML=\("<span style=\'color:"\+getColor\(([0-9]{1,4})\)\+";\'>"\+([0-9]{1,4})', $strContent, $aMatches ) )
		{
			$this->nAtk					= $aMatches[2];
		}

		// Retrieve the Str
		if( ereg( '\("str-label"\).appendChild\(document.createTextNode\(([0-9]{1,3})\)', $strContent, $aMatches ) )
		{
			$this->nStr					= $aMatches[1];
		}

		// Retrieve the Sta
		if( ereg( '\("sta"\).appendChild\(document.createTextNode\(([0-9]{1,3})\)', $strContent, $aMatches ) )
		{
			$this->nSta					= $aMatches[1];
		}

		// Retrieve the Agi
		if( ereg( '\("agi"\).appendChild\(document.createTextNode\(([0-9]{1,3})\)', $strContent, $aMatches ) )
		{
			$this->nAgi					= $aMatches[1];
		}

		// Retrieve the Dex
		if( ereg( '\("dex"\).appendChild\(document.createTextNode\(([0-9]{1,3})\)', $strContent, $aMatches ) )
		{
			$this->nDex					= $aMatches[1];
		}

		// Retrieve the Wis
		if( ereg( '\("wis"\).appendChild\(document.createTextNode\(([0-9]{1,3})\)', $strContent, $aMatches ) )
		{
			$this->nWis					= $aMatches[1];
		}

		// Retrieve the Int
		if( ereg( '\("int"\).appendChild\(document.createTextNode\(([0-9]{1,3})\)', $strContent, $aMatches ) )
		{
			$this->nInt					= $aMatches[1];
		}

		// Retrieve the Cha
		if( ereg( '\("cha"\).appendChild\(document.createTextNode\(([0-9]{1,3})\)', $strContent, $aMatches ) )
		{
			$this->nCha					= $aMatches[1];
		}

		// Retrieve the PR
		if( ereg( '\("RP"\).appendChild\(document.createTextNode\(([0-9]{1,3})\)', $strContent, $aMatches ) )
		{
			$this->nPR					= $aMatches[1];
		}

		// Retrieve the MR
		if( ereg( '\("RM"\).appendChild\(document.createTextNode\(([0-9]{1,3})\)', $strContent, $aMatches ) )
		{
			$this->nMR					= $aMatches[1];
		}

		// Retrieve the DR
		if( ereg( '\("RD"\).appendChild\(document.createTextNode\(([0-9]{1,3})\)', $strContent, $aMatches ) )
		{
			$this->nDR					= $aMatches[1];
		}

		// Retrieve the FR
		if( ereg( '\("RF"\).appendChild\(document.createTextNode\(([0-9]{1,3})\)', $strContent, $aMatches ) )
		{
			$this->nFR					= $aMatches[1];
		}

		// Retrieve the CR
		if( ereg( '\("RC"\).appendChild\(document.createTextNode\(([0-9]{1,3})\)', $strContent, $aMatches ) )
		{
			$this->nCR					= $aMatches[1];
		}


		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve the Skills/Tradeskills
		///////////////////////////////////////////////////////////////////////////////////
		if( ereg( '<tr><td style=\'width: 200px\'>Forage</td><td align=\'center\'>([0-9]{1,3})</td></tr>', $strContent, $aMatches ) )
		{
			$this->nForaging			= $aMatches[1];
		}
	
		if( ereg( '<tr><td style=\'width: 200px\'>Fishing</td><td align=\'center\'>([0-9]{1,3})</td></tr>', $strContent, $aMatches ) )
		{
			$this->nFishing				= $aMatches[1];
		}
	
		if( ereg( '<tr><td style=\'width: 200px\'>Blacksmithing</td><td align=\'center\'>([0-9]{1,3})</td></tr>', $strContent, $aMatches ) )
		{
			$this->nSmithing			= $aMatches[1];
		}
	
		if( ereg( '<tr><td style=\'width: 200px\'>Baking</td><td align=\'center\'>([0-9]{1,3})</td></tr>', $strContent, $aMatches ) )
		{
			$this->nBaking				= $aMatches[1];
		}
	
		if( ereg( '<tr><td style=\'width: 200px\'>Tailoring</td><td align=\'center\'>([0-9]{1,3})</td></tr>', $strContent, $aMatches ) )
		{
			$this->nTailoring			= $aMatches[1];
		}
	
		if( ereg( '<tr><td style=\'width: 200px\'>Fletching</td><td align=\'center\'>([0-9]{1,3})</td></tr>', $strContent, $aMatches ) )
		{
			$this->nFletching			= $aMatches[1];
		}
	
		if( ereg( '<tr><td style=\'width: 200px\'>Brewing</td><td align=\'center\'>([0-9]{1,3})</td></tr>', $strContent, $aMatches ) )
		{
			$this->nBrewing				= $aMatches[1];
		}
	
		if( ereg( '<tr><td style=\'width: 200px\'>Jewellery</td><td align=\'center\'>([0-9]{1,3})</td></tr>', $strContent, $aMatches ) )
		{
			$this->nJewelry				= $aMatches[1];
		}
	
		if( ereg( '<tr><td style=\'width: 200px\'>Pottery</td><td align=\'center\'>([0-9]{1,3})</td></tr>', $strContent, $aMatches ) )
		{
			$this->nPottery				= $aMatches[1];
		}
	
		if( ereg( '<tr><td style=\'width: 200px\'>Alcohol Tolerance</td><td align=\'center\'>([0-9]{1,3})</td></tr>', $strContent, $aMatches ) )
		{
			$this->nAlcoholTolerance	= $aMatches[1];
		}
	
		if( ereg( '<tr><td style=\'width: 200px\'>Alchemy</td><td align=\'center\'>([0-9]{1,3})</td></tr>', $strContent, $aMatches ) )
		{
			$this->nAlchemy				= $aMatches[1];
		}
	
		if( ereg( '<tr><td style=\'width: 200px\'>Tinkering</td><td align=\'center\'>([0-9]{1,3})</td></tr>', $strContent, $aMatches ) )
		{
			$this->nTinkering			= $aMatches[1];
		}
	
		if( ereg( '<tr><td style=\'width: 200px\'>Research</td><td align=\'center\'>([0-9]{1,3})</td></tr>', $strContent, $aMatches ) )
		{
			$this->nResearch			= $aMatches[1];
		}
	
		if( ereg( '<tr><td style=\'width: 200px\'>Make Poison</td><td align=\'center\'>([0-9]{1,3})</td></tr>', $strContent, $aMatches ) )
		{
			$this->nPosionMaking		= $aMatches[1];
		}
	
		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve Keys
		///////////////////////////////////////////////////////////////////////////////////
		if( preg_match( "/<li>Vex Thal<br>/i", $strContent ) )
		{
			$this->nVexThalKey			= 1;
		}

		if( preg_match( "/<li>Sebilis<br>/i", $strContent ) )
		{
			$this->nSebilisKey			= 1;
		}
	
		if( preg_match( "/<li>Veeshan's Peak<br>/i", $strContent ) )
		{
			$this->nVeeshansPeakKey		= 1;
		}
	
		if( preg_match( "/<li>The Howling Stones<br>/i", $strContent ) )
		{
			$this->nHowlingStonesKey	= 1;
		}
	
		if( preg_match( "/<li>Sleeper's Tomb<br>/i", $strContent ) )
		{
			$this->nSleepersTombKey		= 1;
		}
	
		if( preg_match( "/<li>SSRA Emperor Area<br>/i", $strContent ) )
		{
			$this->nSSRAEmperorKey		= 1;
		}
	
		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve Group Leadership Points
		///////////////////////////////////////////////////////////////////////////////////

		// Initialize the number of Group Leadership Points
		$this->nNrOfGLPs	= 0;
	
		// Determine the correct GLP ID
		$strMageloGLPID		= "100";
		if( ereg( "'Inspect Buffs\',([0-9]{1,3}),", $strContent, $aMatches ) )
		{
			$strMageloGLPID	= $aMatches[1];
		}

		if( ereg( "Mark NPC\'," . $strMageloGLPID . ",([0-9]{1}),", $strContent, $aMatches ) )
		{
			$this->nMarkNPC				= $aMatches[1];

			// Adjust the total nr of GLP's
			if( $this->nMarkNPC >= 1 )
			{
				$this->nNrOfGLPs		+= 3;
			}
			if( $this->nMarkNPC >= 2 )
			{
				$this->nNrOfGLPs		+= 4;
			}
			if( $this->nMarkNPC >= 3 )
			{
				$this->nNrOfGLPs		+= 5;
			}
		}

		if( ereg( "NPC Health\'," . $strMageloGLPID . ",([0-9]{1}),", $strContent, $aMatches ) )
		{
			$this->nNPCHealth			= $aMatches[1];

			// Adjust the total nr of GLP's
			if( $this->nNPCHealth >= 1 )
			{
				$this->nNrOfGLPs		+= 2;
			}
		}
	
		if( ereg( "Delegate Main Assist\'," . $strMageloGLPID . ",([0-9]{1}),", $strContent, $aMatches ) )
		{
			$this->nDelegateMA			= $aMatches[1];

			// Adjust the total nr of GLP's
			if( $this->nDelegateMA >= 1 )
			{
				$this->nNrOfGLPs		+= 4;
			}
		}

		if( ereg( "Delegate Mark NPC\'," . $strMageloGLPID . ",([0-9]{1}),", $strContent, $aMatches ) )
		{
			$this->nDelegateMarkNPC		= $aMatches[1];

			// Adjust the total nr of GLP's
			if( $this->nDelegateMarkNPC >= 1 )
			{
				$this->nNrOfGLPs		+= 4;
			}
		}

		if( ereg( "Inspect Buffs\'," . $strMageloGLPID . ",([0-9]{1}),", $strContent, $aMatches ) )
		{
			$this->nInspectBuffs		= $aMatches[1];

			// Adjust the total nr of GLP's
			if( $this->nInspectBuffs >= 1 )
			{
				$this->nNrOfGLPs		+= 4;
			}
			if( $this->nInspectBuffs >= 2 )
			{
				$this->nNrOfGLPs		+= 6;
			}
		}

		if( ereg( "Spell Awareness\'," . $strMageloGLPID . ",([0-9]{1}),", $strContent, $aMatches ) )
		{
			$this->nSpellAwareness		= $aMatches[1];

			// Adjust the total nr of GLP's
			if( $this->nSpellAwareness >= 1 )
			{
				$this->nNrOfGLPs		+= 6;
			}
		}

		if( ereg( "Offense Enhancement\'," . $strMageloGLPID . ",([0-9]{1}),", $strContent, $aMatches ) )
		{
			$this->nOffEnh				= $aMatches[1];

			// Adjust the total nr of GLP's
			if( $this->nOffEnh >= 1 )
			{
				$this->nNrOfGLPs		+= 4;
			}
			if( $this->nOffEnh >= 2 )
			{
				$this->nNrOfGLPs		+= 5;
			}
			if( $this->nOffEnh >= 3 )
			{
				$this->nNrOfGLPs		+= 6;
			}
			if( $this->nOffEnh >= 4 )
			{
				$this->nNrOfGLPs		+= 7;
			}
			if( $this->nOffEnh >= 5 )
			{
				$this->nNrOfGLPs		+= 8;
			}
		}

		if( ereg( "Mana Enhancement\'," . $strMageloGLPID . ",([0-9]{1}),", $strContent, $aMatches ) )
		{
			$this->nManaEnh				= $aMatches[1];

			// Adjust the total nr of GLP's
			if( $this->nManaEnh >= 1 )
			{
				$this->nNrOfGLPs		+= 4;
			}
			if( $this->nManaEnh >= 2 )
			{
				$this->nNrOfGLPs		+= 6;
			}
			if( $this->nManaEnh >= 3 )
			{
				$this->nNrOfGLPs		+= 8;
			}
		}

		if( ereg( "Health Enhancement\'," . $strMageloGLPID . ",([0-9]{1}),", $strContent, $aMatches ) )
		{
			$this->nHealthEnh			= $aMatches[1];

			// Adjust the total nr of GLP's
			if( $this->nHealthEnh >= 1 )
			{
				$this->nNrOfGLPs		+= 4;
			}
			if( $this->nHealthEnh >= 2 )
			{
				$this->nNrOfGLPs		+= 6;
			}
			if( $this->nHealthEnh >= 3 )
			{
				$this->nNrOfGLPs		+= 8;
			}
		}

		if( ereg( "Health Regeneration\'," . $strMageloGLPID . ",([0-9]{1}),", $strContent, $aMatches ) )
		{
			$this->nHealthRegen			= $aMatches[1];

			// Adjust the total nr of GLP's
			if( $this->nHealthRegen >= 1 )
			{
				$this->nNrOfGLPs		+= 4;
			}
			if( $this->nHealthRegen >= 2 )
			{
				$this->nNrOfGLPs		+= 6;
			}
			if( $this->nHealthRegen >= 3 )
			{
				$this->nNrOfGLPs		+= 8;
			}
		}

		if( ereg( "Find Path to PC\'," . $strMageloGLPID . ",([0-9]{1}),", $strContent, $aMatches ) )
		{
			$this->nFindPathToPC		= $aMatches[1];

			// Adjust the total nr of GLP's
			if( $this->nFindPathToPC >= 1 )
			{
				$this->nNrOfGLPs		+= 4;
			}
		}

		if( ereg( "Health of Target\\\'s Target\'," . $strMageloGLPID . ",([0-9]{1}),", $strContent, $aMatches ) )
		{
			$this->nHealthOfTT			= $aMatches[1];

			// Adjust the total nr of GLP's
			if( $this->nHealthOfTT >= 1 )
			{
				$this->nNrOfGLPs		+= 7;
			}
		}

		// Add the unspend point
		if( ereg( "Group Points<br>([0-9]{1}),", $strContent, $aMatches ) )
		{
			$this->nNrOfGLPs			+= $aMatches[1];
		}

		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve PoP Tier 1 Flags
		///////////////////////////////////////////////////////////////////////////////////
		if( ereg( 'Full PoV/PoS access</td><td width=\'\*\' align=\'center\'><span style=\'color: #00FF00\'>Yes', $strContent, $aMatches ) )
		{
		   $this->nAny_PoJ_Trial						= 1;
		}
		
		if( ereg( 'PoJ Seventh Hammer</td><td width=\'\*\' align=\'center\'><span style=\'color: #00FF00\'>Yes', $strContent, $aMatches ) )
		{
		   $this->nAll_PoJ_Trials						= 1;
		}

		if( ereg( 'PoI Factory</td><td width=\'\*\' align=\'center\'><span style=\'color: #00FF00\'>Yes', $strContent, $aMatches ) )
		{
			$this->nPoI_Xanamech						= 1;
		}

		if( ereg( 'Plane of Tactics</td><td width=\'\*\' align=\'center\'><span style=\'color: #00FF00\'>Yes', $strContent, $aMatches ) )
		{
		   $this->nPoI_Behemoth							= 1;
		}

		if( ereg( 'Crypt of Decay for exp only</td><td width=\'*\' align=\'center\'><span style=\'color: #00FF00\'>Yes', $strContent, $aMatches ) )
		{
		    $this->nPoD_Grimror_Quest					= 1;
		}

		if( ereg( 'Crypt of Decay</td><td width=\'\*\' align=\'center\'><span style=\'color: #00FF00\'>Yes', $strContent, $aMatches ) )
		{
		    $this->nPoD_Grummus							= 1;
		}
		
		if( ereg( 'Crypt of Terris Thule</td><td width=\'\*\' align=\'center\'><span style=\'color: #00FF00\'>Yes', $strContent, $aMatches ) )
		{
		    $this->nPoN_Hedge_Quest						= 1;
		}
		
		if( ereg( 'Plane of Torment</td><td width=\'\*\' align=\'center\'><span style=\'color: #00FF00\'>Yes', $strContent, $aMatches ) )
		{
		    $this->nPoNb_Terris_Thule					= 1;
		}

		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve PoP Tier 2 Flags
		///////////////////////////////////////////////////////////////////////////////////
		if( ereg( 'Torden, Bastion of Thunder</td><td width=\'\*\' align=\'center\'><span style=\'color: #00FF00\'>Yes', $strContent, $aMatches ) )
		{
		    $this->nPoS_Askr_Quest						= 1;
		}

		if( ereg( 'Halls of Honor for exp only</td><td width=\'*\' align=\'center\'><span style=\'color: #00FF00\'>Yes', $strContent, $aMatches ) )
		{
		    $this->nPoV_Grenic_Quest					= 1;
		}

		if( ereg( 'Halls of Honor</td><td width=\'\*\' align=\'center\'><span style=\'color: #00FF00\'>Yes', $strContent, $aMatches ) )
		{
		    $this->nPoV_AerinDar						= 1;
		}

		if( ereg( 'Plane of Torment and Saryrn</td><td width=\'\*\' align=\'center\'><span style=\'color: #00FF00\'>Yes', $strContent, $aMatches ) )
		{
			$this->nCoD_Bertoxxulous					= 1;
		}

		if( ereg( '\[DONE\] Killed PoTorment Saryrn', $strContent, $aMatches ) )
		{
		    $this->nPoTorment_Saryrn					= 1;
		}

		if( ereg( 'Plane of Tactics for exp only</td><td width=\'*\' align=\'center\'><span style=\'color: #00FF00\'>Yes', $strContent, $aMatches ) )
		{
		    $this->nnPoS_Wembly_Quest					= 1;
		}
		
		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve PoP Tier 3 Flags
		///////////////////////////////////////////////////////////////////////////////////
		if( ereg( 'HoHb, Temple of Marr</td><td width=\'\*\' align=\'center\'><span style=\'color: #00FF00\'>Yes', $strContent, $aMatches ) )
		{
		    $this->nHoH_Trial1_RyddaDar					= 1;
		    $this->nHoH_Trial2_Ogre						= 1;
		    $this->nHoH_Trial3_Madmen					= 1;
		}

		if( ereg( '\[DONE\] Killed HoHb Mithanial Marr', $strContent, $aMatches ) )
		{
		    $this->nHoHb_Mithanial_Marr					= 1;
		}
		
		if( ereg( '\[DONE\] Killed PoTactics Tallon Zek', $strContent, $aMatches ) )
		{
		    $this->nPoTactics_Tallon_Zek				= 1;
		}
		
		if( ereg( '\[DONE\] Killed PoTactics Vallon Zek', $strContent, $aMatches ) )
		{
		    $this->nPoTactics_Vallon_Zek				= 1;
		} 
		
		if( ereg( '\[DONE\] PoTactics Rallos Zek Quest', $strContent, $aMatches ) )
		{
		    $this->nPoTactics_Rallos_Zek_Quest			= 1;
		}
		
		if( ereg( '\[DONE\] BoT Rescue Karana Quest', $strContent, $aMatches ) )
		{
		    $this->nBoT_Rescue_Karana_Quest				= 1;
		}
		
		if( ereg( 'To get past Rallos Zek</td><td width=\'\*\' align=\'center\'><span style=\'color: #00FF00\'>Yes', $strContent, $aMatches ) )
		{
		    $this->nPoTorment_Saryrn					= 1;
		    $this->nHoHb_Mithanial_Marr					= 1;
		    $this->nPoTactics_Tallon_Zek				= 1;
		    $this->nPoTactics_Vallon_Zek				= 1;
		}

		if( ereg( '\[DONE\] Killed SolRoTower Jiva', $strContent, $aMatches ) )
		{
		    $this->nSolRoTower_Jiva						= 1;
		}
		
		if( ereg( '\[DONE\] Killed SolRoTower Xuzl', $strContent, $aMatches ) )
		{
		    $this->nSolRoTower_Xuzl						= 1;
		}
		
		if( ereg( '\[DONE\] Killed SolRoTower Arlyxir', $strContent, $aMatches ) )
		{
		    $this->nSolRoTower_Arlyxir					= 1;
		}
		
		if( ereg( '\[DONE\] Killed SolRoTower Rizlona', $strContent, $aMatches ) )
		{
		    $this->nSolRoTower_Rizlona					= 1;
		}
		
		if( ereg( '\[DONE\] Killed SolRoTower Protector of Dresolik', $strContent, $aMatches ) )
		{
		    $this->nSolRoTower_Protector_of_Dresolik	= 1;
		}
		
		if( ereg( 'Solusek Ro</td><td width=\'\*\' align=\'center\'><span style=\'color: #00FF00\'>Yes', $strContent, $aMatches ) )
		{
		    $this->nPoTactics_Rallos_Zek_Quest			= 1;
		    $this->nBoT_Rescue_Karana_Quest				= 1;
		    $this->nSolRoTower_Jiva						= 1;
		    $this->nSolRoTower_Xuzl						= 1;
		    $this->nSolRoTower_Arlyxir					= 1;
		    $this->nSolRoTower_Rizlona					= 1;
		    $this->nSolRoTower_Protector_of_Dresolik	= 1;
		}

		if( ereg( 'Plane of Fire</td><td width=\'\*\' align=\'center\'><span style=\'color: #00FF00\'>Yes', $strContent, $aMatches ) )
		{
		    $this->nSolRoTower_Solusek_Ro				= 1;
		}

		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve PoP Tier 4 Flags
		///////////////////////////////////////////////////////////////////////////////////
		if( ereg( '\[DONE\] Killed PoAir Xegony', $strContent, $aMatches ) )
		{
		    $this->nPoAir_Xegony						= 1;
		}

		if( ereg( '\[DONE\] Killed PoFire Fennin Ro', $strContent, $aMatches ) )
		{
		    $this->nPoFire_Fennin_Ro					= 1;
		}

		if( ereg( '\[DONE\] Killed PoEarthb The Rathe', $strContent, $aMatches ) )
		{
		    $this->nPoEarthb_The_Rathe					= 1;
		}

		if( ereg( '\[DONE\] Killed PoWater Coirnav', $strContent, $aMatches ) )
		{
		    $this->nPoWater_Coirnav						= 1;
		}

		if( ereg( 'Plane of Time</td><td width=\'\*\' align=\'center\'><span style=\'color: #00FF00\'>Yes', $strContent, $aMatches ) )
		{
		    $this->nPoAir_Xegony						= 1;
		    $this->nPoEarthb_The_Rathe					= 1;
		    $this->nPoFire_Fennin_Ro					= 1;
		    $this->nPoWater_Coirnav						= 1;
		}

		if( ereg( 'Time Phased Quintessence', $strContent, $aMatches ) )
		{
		    $this->nPoTime_Time_Phased_Quintessence		= 1;
		}

		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve GoD Flags
		///////////////////////////////////////////////////////////////////////////////////
		if( ereg( '\[DONE\] Purifying Plant Trial', $strContent, $aMatches ) )
		{
		    $this->nPurifying_Plant						= 1;
		}

		if( ereg( '\[DONE\] Emanating Furnace Trial', $strContent, $aMatches ) )
		{
		    $this->nEmanating_Furnace					= 1;
		}

		if( ereg( '\[DONE\] Lair of Trapped Ones Trial', $strContent, $aMatches ) )
		{
		    $this->nLair_of_Trapped_Ones				= 1;
		}

		if( ereg( '\[DONE\] Pool of Sludge Trial', $strContent, $aMatches ) )
		{
		    $this->nPool_of_Sludge						= 1;
		}

		if( ereg( '\[DONE\] Killed Smith Rondo', $strContent, $aMatches ) )
		{
		    $this->nSmith_Rondo							= 1;
		}

		if( ereg( '\[DONE\] Vxed Trial', $strContent, $aMatches ) )
		{
		    $this->nVxed								= 1;
		}

		if( ereg( '\[DONE\] Tipt Trial', $strContent, $aMatches ) )
		{
		    $this->nTipt								= 1;
		}

		if( ereg( 'Kod`Taz,Ikkinz,Yxtta</td><td width=\'*\' align=\'center\'><span style=\'color: #00FF00\'>Yes', $strContent, $aMatches ) )
		{
			// We have no clue if the user did the 4 trials or the rondo, so we leave those flags alone
			// Vxed and Tipt we do know, so enable them
		    $this->nVxed								= 1;
		    $this->nTipt								= 1;
		}
		
		if( ereg( 'Qvic</td><td width=\'\*\' align=\'center\'><span style=\'color: #00FF00\'>Yes', $strContent, $aMatches ) )
		{
		    $this->nVrex_Barxt_Qurat					= 1;
		}

		if( ereg( 'Inktu\'ta</td><td width=\'\*\' align=\'center\'><span style=\'color: #00FF00\'>Yes', $strContent, $aMatches ) )
		{
		    $this->nCynosure_Kvanjji					= 1;
		}

		if( ereg( 'Txevu</td><td width=\'\*\' align=\'center\'><span style=\'color: #00FF00\'>Yes', $strContent, $aMatches ) )
		{
		    $this->nNoqufiel_in_Inktuta					= 1;
		}

		if( ereg( 'Tacvi</td><td width=\'\*\' align=\'center\'><span style=\'color: #00FF00\'>Yes', $strContent, $aMatches ) )
		{
		    $this->nZunMuram_Tkarish_Zyk				= 1;
		}

		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve OoW Flags/Signets
		///////////////////////////////////////////////////////////////////////////////////
		if( ereg( 'Seal: Mastery of All', $strContent, $aMatches ) )
		{
		    $this->nSeal_Mastery_of_All					= 1;
		}
		
		if( ereg( 'Crystal-Gemmed Signet', $strContent, $aMatches ) )
		{
			$this->nCrystal_Gemmed_Signet				= 1;
		}
		if( ereg( 'Discolored Signet', $strContent, $aMatches ) )
		{
			$this->nDiscolored_Signet					= 1;
		}
		if( ereg( 'Dust-Marred Signet', $strContent, $aMatches ) )
		{
			$this->nDust_Marred_Signet					= 1;
		}
		if( ereg( 'Glimmering Signet', $strContent, $aMatches ) )
		{
			$this->nGlimmering_Signet					= 1;
		}
		if( ereg( 'Tarnished Signet', $strContent, $aMatches ) )
		{
			$this->nTarnished_Signet					= 1;
		}
		if( ereg( 'Two-Toned Signet', $strContent, $aMatches ) )
		{
			$this->nTwo_Toned_Signet					= 1;
		}
		if( ereg( 'Weather-Worn Signet', $strContent, $aMatches ) )
		{
			$this->nWeather_Worn_Signet					= 1;
		}

		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve DoN Flags
		///////////////////////////////////////////////////////////////////////////////////
		if( ereg( 'Gift of the Keepers', $strContent, $aMatches ) ||
			ereg( 'Gift of the Dark Reign', $strContent, $aMatches ) )
		{
		    $this->nDoN_Tier1_Done						= 1;
		}
		if( ereg( 'Valor of the Keepers', $strContent, $aMatches ) ||
			ereg( 'Tenacity of the Dark Reign', $strContent, $aMatches ) )
		{
		    $this->nDoN_Tier2_Done						= 1;
		}

		if( ereg( 'Embrace of the Keepers', $strContent, $aMatches ) ||
			ereg( 'Embrace of the Dark Reign', $strContent, $aMatches ) )
		{
		    $this->nDoN_Tier3_Done						= 1;
		}

		if( ereg( 'Power of the Keepers', $strContent, $aMatches ) ||
			ereg( 'Power of the Dark Reign', $strContent, $aMatches ) )
		{
		    $this->nDoN_Tier4_Done						= 1;
		}

		if( ereg( 'Sanctity of the Keepers', $strContent, $aMatches ) ||
			ereg( 'Fervor of the Dark Reign', $strContent, $aMatches ) )
		{
		    $this->nDoN_Tier5_Done						= 1;
		}

		// Import completed succesfully
		return true;
	}



	// ========================================================================
	// Show the magelo info on screen (debug function)
	// ========================================================================
	// This function is only here for debug purposes.
	// If you really want to output the data to screen, 
	// you should create you're own layout and rewrite this function
	// ========================================================================
	function Show()
	{
		// Print the results
		print( "MageloNr			= [" . $this->strMageloNr . "]							<br \>\n" );
		print( "CharName			= [" . $this->strCharName . "]							<br \>\n" );
		print( "Class				= [" . $this->strClass . "]								<br \>\n" );
		print( "<hr \>\n" );
		print( "Level				= [" . $this->nLevel . "]								<br \>\n" );
		print( "Deity				= [" . $this->strDeity . "]								<br \>\n" );
		print( "AA					= [" . $this->nAA . "]									<br \>\n" );
		print( "LastName			= [" . $this->strLastName . "]							<br \>\n" );
		print( "Race				= [" . $this->strRace . "]								<br \>\n" );
		print( "<hr \>\n" );
		print( "HP					= [" . $this->nHP . "]									<br \>\n" );
		print( "Mana				= [" . $this->nMana . "]								<br \>\n" );
		print( "Endurance			= [" . $this->nEndurance . "]							<br \>\n" );
		print( "AC					= [" . $this->nAC . "]									<br \>\n" );
		print( "FT					= [" . $this->nFT . "]									<br \>\n" );
		print( "Regen				= [" . $this->nRegen . "]								<br \>\n" );
		print( "Atk					= [" . $this->nAtk . "]									<br \>\n" );
		print( "Str					= [" . $this->nStr . "]									<br \>\n" );
		print( "Sta					= [" . $this->nSta . "]									<br \>\n" );
		print( "Agi					= [" . $this->nAgi . "]									<br \>\n" );
		print( "Dex					= [" . $this->nDex . "]									<br \>\n" );
		print( "Wis					= [" . $this->nWis . "]									<br \>\n" );
		print( "Int					= [" . $this->nInt . "]									<br \>\n" );
		print( "Cha					= [" . $this->nCha . "]									<br \>\n" );
		print( "PR					= [" . $this->nPR . "]									<br \>\n" );
		print( "MR					= [" . $this->nMR . "]									<br \>\n" );
		print( "DR					= [" . $this->nDR . "]									<br \>\n" );
		print( "FR					= [" . $this->nFR . "]									<br \>\n" );
		print( "CR					= [" . $this->nCR . "]									<br \>\n" );
		print( "<hr \>\n" );
		print( "Foraging			= [" . $this->nForaging . "]							<br \>\n" );
		print( "Fishing				= [" . $this->nFishing . "]								<br \>\n" );
		print( "Smithing			= [" . $this->nSmithing . "]							<br \>\n" );
		print( "Baking				= [" . $this->nBaking . "]								<br \>\n" );
		print( "Tailoring			= [" . $this->nTailoring . "]							<br \>\n" );
		print( "Fletching			= [" . $this->nFletching . "]							<br \>\n" );
		print( "Brewing				= [" . $this->nBrewing . "]								<br \>\n" );
		print( "Jewelry				= [" . $this->nJewelry . "]								<br \>\n" );
		print( "Pottery				= [" . $this->nPottery . "]								<br \>\n" );
		print( "AlcoholToler.		= [" . $this->nAlcoholTolerance . "]					<br \>\n" );
		print( "Alchemy				= [" . $this->nAlchemy . "]								<br \>\n" );
		print( "Tinkering			= [" . $this->nTinkering . "]							<br \>\n" );
		print( "Research			= [" . $this->nResearch . "]							<br \>\n" );
		print( "PosionMaking		= [" . $this->nPosionMaking . "]						<br \>\n" );
		print( "<hr \>\n" );
		print( "VexThalKey			= [" . $this->nVexThalKey . "]							<br \>\n" );
		print( "SebilisKey			= [" . $this->nSebilisKey . "]							<br \>\n" );
		print( "VeeshansPeakKey		= [" . $this->nVeeshansPeakKey . "]						<br \>\n" );
		print( "HowlingStonesKey	= [" . $this->nHowlingStonesKey . "]					<br \>\n" );
		print( "SleepersTombKey		= [" . $this->nSleepersTombKey . "]						<br \>\n" );
		print( "SSRAEmperorKey		= [" . $this->nSSRAEmperorKey . "]						<br \>\n" );
		print( "<hr \>\n" );
		print( "NrOfGLPs			= [" . $this->nNrOfGLPs . "] (plus unspent)				<br \>\n" );
		print( "MarkNPC				= [" . $this->nMarkNPC . "]								<br \>\n" );
		print( "NPCHealth			= [" . $this->nNPCHealth . "]							<br \>\n" );
		print( "DelegateMA			= [" . $this->nDelegateMA . "]							<br \>\n" );
		print( "DelegateMarkNPC		= [" . $this->nDelegateMarkNPC . "]						<br \>\n" );
		print( "InspectBuffs		= [" . $this->nInspectBuffs . "]						<br \>\n" );
		print( "SpellAwareness		= [" . $this->nSpellAwareness . "]						<br \>\n" );
		print( "OffEnh				= [" . $this->nOffEnh . "]								<br \>\n" );
		print( "ManaEnh				= [" . $this->nManaEnh . "]								<br \>\n" );
		print( "HealthEnh			= [" . $this->nHealthEnh . "]							<br \>\n" );
		print( "HealthRegen			= [" . $this->nHealthRegen . "]							<br \>\n" );
		print( "FindPathToPC		= [" . $this->nFindPathToPC . "]						<br \>\n" );
		print( "HealthOfTT			= [" . $this->nHealthOfTT . "]							<br \>\n" );
		print( "<hr \>\n" );
		// Pop Tier 1 Flags
		print( "Any_PoJ_Trial		= [" . $this->nAny_PoJ_Trial . "]						<br \>\n" );
		print( "All_PoJ_Trials		= [" . $this->nAll_PoJ_Trials . "]						<br \>\n" );
		print( "PoI_Xanamech		= [" . $this->nPoI_Xanamech . "]						<br \>\n" );
		print( "PoI_Behemoth		= [" . $this->nPoI_Behemoth . "]						<br \>\n" );
		print( "PoD_Grimror_Quest	= [" . $this->nPoD_Grimror_Quest . "]					<br \>\n" );
		print( "PoD_Grummus			= [" . $this->nPoD_Grummus . "]							<br \>\n" );
		print( "PoN_Hedge_Quest		= [" . $this->nPoN_Hedge_Quest . "]						<br \>\n" );
		print( "PoNb_Terris_Thule	= [" . $this->nPoNb_Terris_Thule . "]					<br \>\n" );
		print( "<hr \>\n" );
		// Pop Tier 2 Flags
		print( "PoS_Askr_Quest		= [" . $this->nPoS_Askr_Quest . "]						<br \>\n" );
		print( "PoV_Grenic_Quest	= [" . $this->nPoV_Grenic_Quest . "]					<br \>\n" );
		print( "PoV_AerinDar		= [" . $this->nPoV_AerinDar . "]						<br \>\n" );
		print( "CoD_Bertoxxulous	= [" . $this->nCoD_Bertoxxulous . "]					<br \>\n" );
		print( "PoTorment_Saryrn	= [" . $this->nPoTorment_Saryrn . "]					<br \>\n" );
		print( "PoS_Wembly_Quest	= [" . $this->nPoS_Wembly_Quest . "]					<br \>\n" );
		print( "<hr \>\n" );
		// Pop Tier 3 Flags
		print( "HoH_Trial1_RyddaDar	= [" . $this->nHoH_Trial1_RyddaDar . "]					<br \>\n" );
		print( "HoH_Trial2_Ogre		= [" . $this->nHoH_Trial2_Ogre . "]						<br \>\n" );
		print( "HoH_Trial3_Madmen	= [" . $this->nHoH_Trial3_Madmen . "]					<br \>\n" );
		print( "HoHb_Mithanial_Marr	= [" . $this->nHoHb_Mithanial_Marr . "]					<br \>\n" );
		print( "PoTactics_Tallon_Z	= [" . $this->nPoTactics_Tallon_Zek . "]				<br \>\n" );
		print( "PoTactics_Vallon_Z	= [" . $this->nPoTactics_Vallon_Zek . "]				<br \>\n" );
		print( "PoTactics_Rallos_Z	= [" . $this->nPoTactics_Rallos_Zek_Quest . "]			<br \>\n" );
		print( "BoT_Rescue_Karana	= [" . $this->nBoT_Rescue_Karana_Quest . "]				<br \>\n" );
		print( "SolRoTower_Jiva		= [" . $this->nSolRoTower_Jiva . "]						<br \>\n" );
		print( "SolRoTower_Xuzl		= [" . $this->nSolRoTower_Xuzl . "]						<br \>\n" );
		print( "SolRoTower_Arlyxir	= [" . $this->nSolRoTower_Arlyxir . "]					<br \>\n" );
		print( "SolRoTower_Rizlona	= [" . $this->nSolRoTower_Rizlona . "]					<br \>\n" );
		print( "SolRoTower_Prot.D.	= [" . $this->nSolRoTower_Protector_of_Dresolik . "]	<br \>\n" );
		print( "SolRoTower_Solus.Ro	= [" . $this->nSolRoTower_Solusek_Ro . "]				<br \>\n" );
		print( "<hr \>\n" );
		// Pop Tier 4 Flags
		print( "PoAir_Xegony		= [" . $this->nPoAir_Xegony . "]						<br \>\n" );
		print( "PoFire_Fennin_Ro	= [" . $this->nPoFire_Fennin_Ro . "]					<br \>\n" );
		print( "PoWater_Coirnav		= [" . $this->nPoWater_Coirnav . "]						<br \>\n" );
		print( "PoEarthb_The_Rathe	= [" . $this->nPoEarthb_The_Rathe . "]					<br \>\n" );
		print( "Time_Time_Phased_Q.	= [" . $this->nPoTime_Time_Phased_Quintessence . "]		<br \>\n" );
		print( "<hr \>\n" );
		// GoD Flags
		print( "Purifying_Plant		= [" . $this->nPurifying_Plant . "]						<br \>\n" );
		print( "Emanating_Furnace	= [" . $this->nEmanating_Furnace . "]					<br \>\n" );
		print( "Lair_Trapped_Ones	= [" . $this->nLair_of_Trapped_Ones . "]				<br \>\n" );
		print( "Pool_of_Sludge		= [" . $this->nPool_of_Sludge . "]						<br \>\n" );
		print( "Smith_Rondo			= [" . $this->nSmith_Rondo . "]							<br \>\n" );
		print( "Vxed				= [" . $this->nVxed . "]								<br \>\n" );
		print( "Tipt				= [" . $this->nTipt . "]								<br \>\n" );
		print( "Vrex_Barxt_Qurat	= [" . $this->nVrex_Barxt_Qurat . "]					<br \>\n" );
		print( "Cynosure_Kvanjji	= [" . $this->nCynosure_Kvanjji . "]					<br \>\n" );
		print( "Noqufiel_in_Inktuta	= [" . $this->nNoqufiel_in_Inktuta . "]					<br \>\n" );
		print( "ZunMuram_Tkarish_Z.	= [" . $this->nZunMuram_Tkarish_Zyk . "]				<br \>\n" );
		print( "<hr \>\n" );
		// OoW Flags/Signets
		print( "Seal_Mastery_of_All	= [" . $this->nSeal_Mastery_of_All . "]					<br \>\n" );
		print( "Crystal_Gemmed_Sign = [" . $this->nCrystal_Gemmed_Signet . "]				<br \>\n" );
		print( "Discolored_Signet	= [" . $this->nDiscolored_Signet . "]					<br \>\n" );
		print( "Dust_Marred_Signet	= [" . $this->nDust_Marred_Signet . "]					<br \>\n" );
		print( "Glimmering_Signet	= [" . $this->nGlimmering_Signet . "]					<br \>\n" );
		print( "Tarnished_Signet	= [" . $this->nTarnished_Signet . "]					<br \>\n" );
		print( "Two_Toned_Signet	= [" . $this->nTwo_Toned_Signet . "]					<br \>\n" );
		print( "Weather_Worn_Signet	= [" . $this->nWeather_Worn_Signet . "]					<br \>\n" );
		print( "<hr \>\n" );
		// DoN Flags
		print( "DoN_Tier1_Done		= [" . $this->nDoN_Tier1_Done . "]						<br \>\n" );
		print( "DoN_Tier2_Done		= [" . $this->nDoN_Tier2_Done . "]						<br \>\n" );
		print( "DoN_Tier3_Done		= [" . $this->nDoN_Tier3_Done . "]						<br \>\n" );
		print( "DoN_Tier4_Done		= [" . $this->nDoN_Tier4_Done . "]						<br \>\n" );
		print( "DoN_Tier5_Done		= [" . $this->nDoN_Tier5_Done . "]						<br \>\n" );
		print( "<hr \>\n" );
	}
}

?>
