<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );
require_once( GetSkinDir() . 'class.skin.inc' );


// ============================================================================
// The Vex_Thal_Keys class
// ============================================================================
// This class provides an interface to the Vex_Thal_Key table
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class Vex_Thal_Keys
{
	// Member variables
	var $theSkin;
	var $bShowVerticalScrollbars	= true;

	// ========================================================================
	// Constructor
	// ========================================================================
	function Vex_Thal_Keys()
	{
		// Create the skin
		$this->theSkin	= new Skin();
	}

	// ========================================================================
	// Get the title of this list
	// ========================================================================
	// Out:	The title of this list
	// ========================================================================
	function GetTitle()
	{
		return "Vex-Thal Keys";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<div id="Header">
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td width= "5%" align="center">' . GetInfoLink( "Vex_Thal_Keys", "Vex Thal key information" ) . '</td>
			<td width="10%">				<b><a href="form.php?FormName=Vex_Thal_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=CharName&SortDirection='			. GetSortDirection( $strSortOrder, "CharName",			$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Name\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Name"			>Name</a></b></td>
			<td width= "8%" align="center">	<b><a href="form.php?FormName=Vex_Thal_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Glowing_Orb&SortDirection='		. GetSortDirection( $strSortOrder, "Glowing_Orb",		$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Glowing Orb\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Glowing Orb"		>Glowing Orb</a></b></td>
			<td width= "8%" align="center">	<b><a href="form.php?FormName=Vex_Thal_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Celestial_Rift&SortDirection='	. GetSortDirection( $strSortOrder, "Celestial_Rift",	$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Celestial Rift\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Celestial Rift"	>Celestial Rift</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=Vex_Thal_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Shard_Dat&SortDirection='			. GetSortDirection( $strSortOrder, "Shard_Dat",			$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Shard Dat\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Shard Dat"		>Dat<br />(FG)</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=Vex_Thal_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Shard_Dax&SortDirection='			. GetSortDirection( $strSortOrder, "Shard_Dax",			$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Shard Dax\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Shard Dax"		>Dax<br />(AR)</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=Vex_Thal_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Shard_Kel&SortDirection='			. GetSortDirection( $strSortOrder, "Shard_Kel",			$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Shard Kel\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Shard Kel"		>Kel<br />(TG)</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=Vex_Thal_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Shard_Kelara&SortDirection='		. GetSortDirection( $strSortOrder, "Shard_Kelara",		$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Shard Kelara\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Shard Kelara"	>Kelara<br />(SS)</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=Vex_Thal_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Shard_Lor&SortDirection='			. GetSortDirection( $strSortOrder, "Shard_Lor",			$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Shard Lor\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Shard Lor"		>Lor<br />(DP)</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=Vex_Thal_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Shard_Raf&SortDirection='			. GetSortDirection( $strSortOrder, "Shard_Raf",			$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Shard Raf\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Shard Raf"		>Raf<br />(TD)</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=Vex_Thal_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Shard_Set&SortDirection='			. GetSortDirection( $strSortOrder, "Shard_Set",			$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Shard Set\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Shard Set"		>Set<br />(SD)</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=Vex_Thal_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Shard_Tak&SortDirection='			. GetSortDirection( $strSortOrder, "Shard_Tak",			$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Shard Tak\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Shard Tak"		>Tak<br />(ME)</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=Vex_Thal_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Shard_Ved&SortDirection='			. GetSortDirection( $strSortOrder, "Shard_Ved",			$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Shard Ved\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Shard Ved"		>Ved<br />(AC)</a></b></td>
			<td width= "6%" align="center">	<b><a href="form.php?FormName=Vex_Thal_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Shard_Vin&SortDirection='			. GetSortDirection( $strSortOrder, "Shard_Vin",			$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Shard Vin\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Shard Vin"		>Vin<br />(SSRA)</a></b></td>
			<td width= "4%"></td>
			<td width= "5%" align="center">	<b><a href="form.php?FormName=Vex_Thal_Keys&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Vex_Thal_Key&SortDirection='		. GetSortDirection( $strSortOrder, "Vex_Thal_Key",		$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by key completed\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Key completed"	>Done</a></b></td>
		  </tr>
		</table>
		</div>
		<!-- End of Header -->
		';
	}
	
	
	
	// ========================================================================
	// Show all the records on screen
	// ========================================================================
	// This function will loop through all the records in the database table,
	// and create a html table entry for each one of them.
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS		= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];
		$strClassFilter		= $_GET['ClassFilter'];

		// Declare variables
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT CharName, NameMain, Vex_Thal_Key, Glowing_Orb, Celestial_Rift, Shard_Dat, Shard_Dax, Shard_Kel, Shard_Kelara, Shard_Lor, Shard_Set, Shard_Raf, Shard_Tak, Shard_Ved, Shard_Vin, OldMember \n" .
							  "FROM Vex_Thal_Key \n" .
							  "LEFT JOIN Characters ON (Vex_Thal_Key.CharID = Characters.CharID) \n" .
							  "LEFT JOIN `Keys`     ON (Vex_Thal_Key.CharID = Keys.CharID) \n" .
							  "WHERE (	Vex_Thal_Key > 0		OR \n" .
							  "			Glowing_Orb > 0			OR \n" .
							  "			Celestial_Rift > 0		OR \n" .
							  "			Shard_Dat > 0			OR \n" .
							  "			Shard_Dax > 0			OR \n" .
							  "			Shard_Kel > 0			OR \n" .
							  "			Shard_Kelara > 0		OR \n" .
							  "			Shard_Lor > 0			OR \n" .
							  "			Shard_Set > 0			OR \n" .
							  "			Shard_Raf > 0			OR \n" .
							  "			Shard_Tak > 0			OR \n" .
							  "			Shard_Ved > 0			OR \n" .
							  "			Shard_Vin > 0 )			   \n";
	
		// Check if we should set a class filter
		if( ( isset( $strClassFilter ) ) &&
			( $strClassFilter != "" ) &&
			( $strClassFilter != "<<All>>" ) )
		{
			$strSelectQuery	.= "AND Class = '" . $strClassFilter . "'";
		} 

		// Check if we should use the default sort order
		if( ( !isset( $strSortOrder ) ) ||
			( $strSortOrder == "" ) )
		{
			// Default sort on Character name
			$strSortOrder	= "CharName"; 
		}

		// Sorting on all numbers should be reversed (Desc first, then Asc)
		$strModifiedSortDirection	= $strSortDirection;
		if( $strSortOrder != "CharName" )
		{
			// Switch the sort order around
			if( $strModifiedSortDirection == "DESC" )
			{
				$strModifiedSortDirection	= "";
			}
			else
			{
				$strModifiedSortDirection	= "DESC";
			}
		}
	
		// Add the sort order
		$strSelectQuery		.= "ORDER BY " . $strSortOrder . " " . $strModifiedSortDirection . ", CharName";
	
		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
		<div id="Body">
		<table id="RosterTable" width="100%" border="0" cellpadding="0" cellspacing="0">
		';
	
		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex				= 0;
			$strCharName		= $aResult[$nIndex++];
			$strNameMain		= $aResult[$nIndex++];
			$nCompleted			= $aResult[$nIndex++];
			$nGlowing_Orb		= $aResult[$nIndex++];
			$nCelestial_Rift	= $aResult[$nIndex++];
			$nShard_Dat			= $aResult[$nIndex++];
			$nShard_Dax			= $aResult[$nIndex++];
			$nShard_Kel			= $aResult[$nIndex++];
			$nShard_Kelara		= $aResult[$nIndex++];
			$nShard_Lor			= $aResult[$nIndex++];
			$nShard_Set			= $aResult[$nIndex++];
			$nShard_Raf			= $aResult[$nIndex++];
			$nShard_Tak			= $aResult[$nIndex++];
			$nShard_Ved			= $aResult[$nIndex++];
			$nShard_Vin			= $aResult[$nIndex++];
			$nOldMember			= $aResult[$nIndex++];
	
			// Only show old members for the administrator
			if( ( $strCharName != "" ) &&
				( ( $nOldMember == 0 ) ||
				  ( IsAdministrator( $strUserName ) ) ) )
			{
				// Show the Vex Thal key parts record
				$this->ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nCompleted, $nGlowing_Orb, $nCelestial_Rift, $nShard_Dat, $nShard_Dax, $nShard_Kel, $nShard_Kelara, $nShard_Lor, $nShard_Set, $nShard_Raf, $nShard_Tak, $nShard_Ved, $nShard_Vin, $nOldMember, $strRowType );
		
				// Switch RowType, so the rows alternate	
				if( $strRowType == "OddRow" )
				{
					$strRowType	= "EvenRow";
				}
				else
				{
					$strRowType	= "OddRow";
				}
			}
		}
	
		// End the table
		echo '
		</table>
		</div>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );
	}
	
	
	
	// ========================================================================
	// Show a record
	// ========================================================================
	// This function will create a html table row for a record in the table
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// In:  Variables containing the data to show 
	// ========================================================================
	function ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nCompleted, $nGlowing_Orb, $nCelestial_Rift, $nShard_Dat, $nShard_Dax, $nShard_Kel, $nShard_Kelara, $nShard_Lor, $nShard_Set, $nShard_Raf, $nShard_Tak, $nShard_Ved, $nShard_Vin, $nOldMember, $strRowType )
	{
		// Declare variables
		$strImageCheck		= '<img src="' . GetSkinDir() . 'images/check.gif" border="0" />';
		$strDeleteChar		= "";
		$strCompleted		= "";
		$strGlowing_Orb		= "";
		$strCelestial_Rift	= "";
		$strShard_Dat		= "";
		$strShard_Dax		= "";
		$strShard_Kel		= "";
		$strShard_Kelara	= "";
		$strShard_Lor		= "";
		$strShard_Set		= "";
		$strShard_Raf		= "";
		$strShard_Tak		= "";
		$strShard_Ved		= "";
		$strShard_Vin		= "";
	
		// Set the check-image for all filled variables
		if( $nCompleted > 0 )			{	$strCompleted		= $strImageCheck;	}
		if( $nGlowing_Orb > 0 )			{	$strGlowing_Orb		= $strImageCheck;	}
		if( $nCelestial_Rift > 0 )		{	$strCelestial_Rift	= $strImageCheck;	}
		if( $nShard_Dat > 0 )			{	$strShard_Dat		= $strImageCheck;	}
		if( $nShard_Dax > 0 )			{	$strShard_Dax		= $strImageCheck;	}
		if( $nShard_Kel > 0 )			{	$strShard_Kel		= $strImageCheck;	}
		if( $nShard_Kelara > 0 )		{	$strShard_Kelara	= $strImageCheck;	}
		if( $nShard_Lor > 0 )			{	$strShard_Lor		= $strImageCheck;	}
		if( $nShard_Set > 0 )			{	$strShard_Set		= $strImageCheck;	}
		if( $nShard_Raf > 0 )			{	$strShard_Raf		= $strImageCheck;	}
		if( $nShard_Tak > 0 )			{	$strShard_Tak		= $strImageCheck;	}
		if( $nShard_Ved > 0 )			{	$strShard_Ved		= $strImageCheck;	}
		if( $nShard_Vin > 0 )			{	$strShard_Vin		= $strImageCheck;	}
	
		// Check if it's an old member
		if( $nOldMember == 1 )
		{
			$strRowType		= "DeletedRow";

			// Allow the deletion of old members
			$strDeleteChar	= ' <a href="form.php?FormName=Character_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=Vex_Thal_Keys&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Delete ' . $strCharName . '\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Delete ' . $strCharName . '"><img src="' . GetSkinDir() . 'images/delete.gif" border="0" /></a>';
		}
	
		// Check if this character belongs to the logged in User
		$strModify	= "";
		if( ( isset( $strUserName ) ) &&
			( isset( $strNameMain ) ) &&
			( $strUserName == $strNameMain ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=Vex_Thal_Keys"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify.gif" border="0" />';
		}
		else if( IsAdministrator( $strUserName ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=Vex_Thal_Keys"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify_others.gif" border="0" />';
		}
	
		echo '
		  <tr	onMouseOver="this.bgColor=\'' . $this->theSkin->strRowHighlightColor . '\'" onMouseOut="this.bgColor=\'\'">
			<td width= "5%" align="center">'					. $strModify			. '</td>
			<td width="10%" class="' . $strRowType . '">'		. $strCharName			. $strDeleteChar . '</td>
			<td width= "8%" align="center">'					. $strGlowing_Orb		. '</td>
			<td width= "8%" align="center">'					. $strCelestial_Rift	. '</td>
			<td width= "6%" align="center">'					. $strShard_Dat			. '</td>
			<td width= "6%" align="center">'					. $strShard_Dax			. '</td>
			<td width= "6%" align="center">'					. $strShard_Kel			. '</td>
			<td width= "6%" align="center">'					. $strShard_Kelara		. '</td>
			<td width= "6%" align="center">'					. $strShard_Lor			. '</td>
			<td width= "6%" align="center">'					. $strShard_Raf			. '</td>
			<td width= "6%" align="center">'					. $strShard_Set			. '</td>
			<td width= "6%" align="center">'					. $strShard_Tak			. '</td>
			<td width= "6%" align="center">'					. $strShard_Ved			. '</td>
			<td width= "6%" align="center">'					. $strShard_Vin			. '</td>
			<td width= "4%"></td>
			<td width= "5%" align="center">'					. $strCompleted			. '</td>
		  </tr>
		';
	}

}

?>
