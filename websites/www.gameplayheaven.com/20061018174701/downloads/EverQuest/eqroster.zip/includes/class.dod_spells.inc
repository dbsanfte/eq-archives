<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );
require_once( GetSkinDir() . 'class.skin.inc' );


// ============================================================================
// The DoD_Spells class
// ============================================================================
// This class provides an interface to the Spell missions in the DoD_Flags table
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class DoD_Spells
{
	// Member variables
	var $theSkin;
	var $bShowVerticalScrollbars	= true;

	// ========================================================================
	// Constructor
	// ========================================================================
	function DoD_Spells()
	{
		// Create the skin
		$this->theSkin	= new Skin();
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "DoD Spells";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<div id="Header">
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td width= "5%" align="center"><br />' . GetInfoLink( "DoD_Missions", "Depths of Darkhollow mission information" ) . '</td>
			<td width="11%">					<b><a href="form.php?FormName=DoD_Spells&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=CharName&SortDirection='					. GetSortDirection( $strSortOrder, "CharName",					$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Name\';return true;"							OnMouseOut="window.status=\'\'"	target=Body title="Name"							><br />Name</a></b></td>
			<td width="30%">
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="100%" align="center"><b>Spell Mission 68</b>' . GetInfoLink( "DoD_SpellMission68", "Mission information" ) . '</td>
			  </tr>
			  </table>
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="20%" align="center">	<b><a href="form.php?FormName=DoD_Spells&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=A_Rogues_Trust&SortDirection='			. GetSortDirection( $strSortOrder, "A_Rogues_Trust",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by A Rogue\\\'s Trust (68.1)\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="A Rogue\'s Trust (68.1)"			>ART</a></b></td>
				<td width="20%" align="center">	<b><a href="form.php?FormName=DoD_Spells&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Scouting_the_City&SortDirection='		. GetSortDirection( $strSortOrder, "Scouting_the_City",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Scouting the City (68.2)\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Scouting the City (68.2)"		>StC</a></b></td>
				<td width="20%" align="center">	<b><a href="form.php?FormName=DoD_Spells&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Building_the_Disguise&SortDirection='	. GetSortDirection( $strSortOrder, "Building_the_Disguise",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Building the Disguise (68.3)\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Building the Disguise (68.3)"	>BtD</a></b></td>
				<td width="20%" align="center">	<b><a href="form.php?FormName=DoD_Spells&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=The_Search_for_Illsuras&SortDirection='	. GetSortDirection( $strSortOrder, "The_Search_for_Illsuras",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by The Search for Illsuras (68.4)\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="The Search for Illsuras (68.4)"	>TSfI</a></b></td>
				<td width="20%" align="center">	<b><a href="form.php?FormName=DoD_Spells&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=The_Rage_of_Kelliad&SortDirection='		. GetSortDirection( $strSortOrder, "The_Rage_of_Kelliad",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by The Rage of Kelliad (68.5)\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="The Rage of Kelliad (68.5)"		>TRoK</a></b></td>
			  </tr>
			  </table>
			</td>
			<td align="center"><br />|</td>
			<td width="24%">
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="100%" align="center"><b>Spell Mission 69</b>' . GetInfoLink( "DoD_SpellMission69", "Mission information" ) . '</td>
			  </tr>
			  </table>
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="25%" align="center">	<b><a href="form.php?FormName=DoD_Spells&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=The_Lost_Notebook&SortDirection='		. GetSortDirection( $strSortOrder, "The_Lost_Notebook",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by The Lost Notebook (69.1)\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="The Lost Notebook (69.1)"		>TLN</a></b></td>
				<td width="25%" align="center">	<b><a href="form.php?FormName=DoD_Spells&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Cavern_Botany&SortDirection='			. GetSortDirection( $strSortOrder, "Cavern_Botany",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Cavern Botany (69.2)\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Cavern Botany (69.2)"			>CB</a></b></td>
				<td width="25%" align="center">	<b><a href="form.php?FormName=DoD_Spells&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=The_Search_for_Clues&SortDirection='		. GetSortDirection( $strSortOrder, "The_Search_for_Clues",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by The Search for Clues (69.3)\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="The Search for Clues (69.3)"		>TSfC</a></b></td>
				<td width="25%" align="center">	<b><a href="form.php?FormName=DoD_Spells&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Rescue_Cicero&SortDirection='			. GetSortDirection( $strSortOrder, "Rescue_Cicero",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Rescue Cicero (69.4)\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Rescue Cicero (69.4)"			>RC</a></b></td>
			  </tr>
			  </table>
			</td>
			<td align="center"><br />|</td>
			<td width="30%">
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="100%" align="center"><b>Spell Mission 70</b>' . GetInfoLink( "DoD_SpellMission70", "Mission information" ) . '</td>
			  </tr>
			  </table>
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="20%" align="center">	<b><a href="form.php?FormName=DoD_Spells&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Preemptive_Strike&SortDirection='		. GetSortDirection( $strSortOrder, "Preemptive_Strike",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Preemptive Strike (70.1)\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Preemptive Strike (70.1)"		>PS</a></b></td>
				<td width="20%" align="center">	<b><a href="form.php?FormName=DoD_Spells&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Praetorian_Guard&SortDirection='			. GetSortDirection( $strSortOrder, "Praetorian_Guard",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Praetorian Guard (70.2)\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Praetorian Guard (70.2)"			>PG</a></b></td>
				<td width="20%" align="center">	<b><a href="form.php?FormName=DoD_Spells&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=The_Fall_of_Illsalin&SortDirection='		. GetSortDirection( $strSortOrder, "The_Fall_of_Illsalin",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by The Fall of Illsalin (70.3)\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="The Fall of Illsalin (70.3)"		>TFoI</a></b></td>
				<td width="20%" align="center">	<b><a href="form.php?FormName=DoD_Spells&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Flights_of_the_Seeker&SortDirection='	. GetSortDirection( $strSortOrder, "Flights_of_the_Seeker",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Flights of the Seeker (70.4)\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Flights of the Seeker (70.4)"	>FotS</a></b></td>
				<td width="20%" align="center">	<b><a href="form.php?FormName=DoD_Spells&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Into_the_Shadows&SortDirection='			. GetSortDirection( $strSortOrder, "Into_the_Shadows",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Into the Shadows (70.5)\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Into the Shadows (70.5)"			>ItS</a></b></td>
			  </tr>
			  </table>
			</td>
		  </tr>
		</table>
		</div>
		<!-- End of Header -->
		';
	}

	// ========================================================================
	// Show all the records on screen
	// ========================================================================
	// This function will loop through all the records in the database table,
	// and create a html table entry for each one of them.
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS		= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];
		$strClassFilter		= $_GET['ClassFilter'];

		// Declare variables
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT CharName, NameMain, A_Rogues_Trust, Scouting_the_City, Building_the_Disguise, The_Search_for_Illsuras, The_Rage_of_Kelliad, The_Lost_Notebook, Cavern_Botany, The_Search_for_Clues, Rescue_Cicero, Preemptive_Strike, Praetorian_Guard, The_Fall_of_Illsalin, Flights_of_the_Seeker, Into_the_Shadows, OldMember \n" .
							  "FROM DoD_Flags \n" .
							  "LEFT JOIN Characters ON (DoD_Flags.CharID = Characters.CharID) \n" .
							  "WHERE (	A_Rogues_Trust > 0				OR \n" .
							  "			Scouting_the_City > 0			OR \n" .
							  "			Building_the_Disguise > 0		OR \n" .
							  "			The_Search_for_Illsuras > 0		OR \n" .
							  "			The_Rage_of_Kelliad > 0			OR \n" .
							  "			The_Lost_Notebook > 0			OR \n" .
							  "			Cavern_Botany > 0				OR \n" .
							  "			The_Search_for_Clues > 0		OR \n" .
							  "			Rescue_Cicero > 0				OR \n" .
							  "			Preemptive_Strike > 0			OR \n" .
							  "			Praetorian_Guard > 0			OR \n" .
							  "			The_Fall_of_Illsalin > 0		OR \n" .
							  "			Flights_of_the_Seeker > 0		OR \n" .
							  "			Into_the_Shadows > 0 )			   \n";

		// Check if we should set a class filter
		if( ( isset( $strClassFilter ) ) &&
			( $strClassFilter != "" ) &&
			( $strClassFilter != "<<All>>" ) )
		{
			$strSelectQuery	.= "AND Class = '" . $strClassFilter . "'";
		} 

		// Check if we should use the default sort order
		if( ( !isset( $strSortOrder ) ) ||
			( $strSortOrder == "" ) )
		{
			// Default sort on Character name
			$strSortOrder	= "CharName"; 
		}

		// Sorting on all numbers should be reversed (Desc first, then Asc)
		$strModifiedSortDirection	= $strSortDirection;
		if( $strSortOrder != "CharName" )
		{
			// Switch the sort order around
			if( $strModifiedSortDirection == "DESC" )
			{
				$strModifiedSortDirection	= "";
			}
			else
			{
				$strModifiedSortDirection	= "DESC";
			}
		}
	
		// Add the sort order
		$strSelectQuery		.= "ORDER BY " . $strSortOrder . " " . $strModifiedSortDirection . ", CharName";
	
		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
		<div id="Body">
		<table id="RosterTable" width="100%" border="0" cellpadding="0" cellspacing="0">
		';
	
		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex						= 0;
			$strCharName				= $aResult[$nIndex++];
			$strNameMain				= $aResult[$nIndex++];
			$nA_Rogues_Trust			= $aResult[$nIndex++];
			$nScouting_the_City			= $aResult[$nIndex++];
			$nBuilding_the_Disguise		= $aResult[$nIndex++];
			$nThe_Search_for_Illsuras	= $aResult[$nIndex++];
			$nThe_Rage_of_Kelliad		= $aResult[$nIndex++];
			$nThe_Lost_Notebook			= $aResult[$nIndex++];
			$nCavern_Botany				= $aResult[$nIndex++];
			$nThe_Search_for_Clues		= $aResult[$nIndex++];
			$nRescue_Cicero				= $aResult[$nIndex++];
			$nPreemptive_Strike			= $aResult[$nIndex++];
			$nPraetorian_Guard			= $aResult[$nIndex++];
			$nThe_Fall_of_Illsalin		= $aResult[$nIndex++];
			$nFlights_of_the_Seeker		= $aResult[$nIndex++];
			$nInto_the_Shadows			= $aResult[$nIndex++];
			$nOldMember					= $aResult[$nIndex++];

			// Only show old members for the administrator
			if( ( $strCharName != "" ) &&
				( ( $nOldMember == 0 ) ||
				  ( IsAdministrator( $strUserName ) ) ) )
			{
				// Show the record
				$this->ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nA_Rogues_Trust, $nScouting_the_City, $nBuilding_the_Disguise, $nThe_Search_for_Illsuras, $nThe_Rage_of_Kelliad, $nThe_Lost_Notebook, $nCavern_Botany, $nThe_Search_for_Clues, $nRescue_Cicero, $nPreemptive_Strike, $nPraetorian_Guard, $nThe_Fall_of_Illsalin, $nFlights_of_the_Seeker, $nInto_the_Shadows, $nOldMember, $strRowType );
		
				// Switch RowType, so the rows alternate	
				if( $strRowType == "OddRow" )
				{
					$strRowType	= "EvenRow";
				}
				else
				{
					$strRowType	= "OddRow";
				}
			}
		}
	
		// End the table
		echo '
		</table>
		</div>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );
	}
	
	
	
	// ========================================================================
	// Show a record
	// ========================================================================
	// This function will create a html table row for a record in the table
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// In:  Variables containing the data to show 
	// ========================================================================
	function ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nA_Rogues_Trust, $nScouting_the_City, $nBuilding_the_Disguise, $nThe_Search_for_Illsuras, $nThe_Rage_of_Kelliad, $nThe_Lost_Notebook, $nCavern_Botany, $nThe_Search_for_Clues, $nRescue_Cicero, $nPreemptive_Strike, $nPraetorian_Guard, $nThe_Fall_of_Illsalin, $nFlights_of_the_Seeker, $nInto_the_Shadows, $nOldMember, $strRowType )
	{
		// Declare variables
		$strImageCheck				= '<img src="' . GetSkinDir() . 'images/check.gif" border="0" />';
		$strDeleteChar				= "";
		$strA_Rogues_Trust			= "";
		$strScouting_the_City		= "";
		$strBuilding_the_Disguise	= "";
		$strThe_Search_for_Illsuras	= "";
		$strThe_Rage_of_Kelliad		= "";
		$strThe_Lost_Notebook		= "";
		$strCavern_Botany			= "";
		$strThe_Search_for_Clues	= "";
		$strRescue_Cicero			= "";
		$strPreemptive_Strike		= "";
		$strPraetorian_Guard		= "";
		$strThe_Fall_of_Illsalin	= "";
		$strFlights_of_the_Seeker	= "";
		$strInto_the_Shadows		= "";

		// Set the check-image for all filled variables
		if( $nA_Rogues_Trust > 0 )			{	$strA_Rogues_Trust			= $strImageCheck;	}
		if( $nScouting_the_City > 0 )		{	$strScouting_the_City		= $strImageCheck;	}
		if( $nBuilding_the_Disguise > 0 )	{	$strBuilding_the_Disguise	= $strImageCheck;	}
		if( $nThe_Search_for_Illsuras > 0 )	{	$strThe_Search_for_Illsuras	= $strImageCheck;	}
		if( $nThe_Rage_of_Kelliad > 0 )		{	$strThe_Rage_of_Kelliad		= $strImageCheck;	}
		if( $nThe_Lost_Notebook > 0 )		{	$strThe_Lost_Notebook		= $strImageCheck;	}
		if( $nCavern_Botany > 0 )			{	$strCavern_Botany			= $strImageCheck;	}
		if( $nThe_Search_for_Clues > 0 )	{	$strThe_Search_for_Clues	= $strImageCheck;	}
		if( $nRescue_Cicero > 0 )			{	$strRescue_Cicero			= $strImageCheck;	}
		if( $nPreemptive_Strike > 0 )		{	$strPreemptive_Strike		= $strImageCheck;	}
		if( $nPraetorian_Guard > 0 )		{	$strPraetorian_Guard		= $strImageCheck;	}
		if( $nThe_Fall_of_Illsalin > 0 )	{	$strThe_Fall_of_Illsalin	= $strImageCheck;	}
		if( $nFlights_of_the_Seeker > 0 )	{	$strFlights_of_the_Seeker	= $strImageCheck;	}
		if( $nInto_the_Shadows	 > 0 )		{	$strInto_the_Shadows		= $strImageCheck;	}

		// Check if it's an old member
		if( $nOldMember == 1 )
		{
			$strRowType		= "DeletedRow";

			// Allow the deletion of old members
			$strDeleteChar	= ' <a href="form.php?FormName=Character_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=DoD_Spells&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Delete ' . $strCharName . '\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Delete ' . $strCharName . '"><img src="' . GetSkinDir() . 'images/delete.gif" border="0" /></a>';
		}
	
		// Check if this character belongs to the logged in User
		$strModify	= "";
		if( ( isset( $strUserName ) ) &&
			( isset( $strNameMain ) ) &&
			( $strUserName == $strNameMain ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=DoD_Spells&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify.gif" border="0" />';
		}
		else if( IsAdministrator( $strUserName ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=DoD_Spells&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify_others.gif" border="0" />';
		}

		echo '
		  <tr	onMouseOver="this.bgColor=\'' . $this->theSkin->strRowHighlightColor . '\'" onMouseOut="this.bgColor=\'\'">
			<td width= "5%" align="center">'				. $strModify					. '</td>
			<td width="11%" class="' . $strRowType . '">'	. $strCharName					. $strDeleteChar . '</td>
			<td width= "6%" align="center">'				. $strA_Rogues_Trust			. '</td>
			<td width= "6%" align="center">'				. $strScouting_the_City			. '</td>
			<td width= "6%" align="center">'				. $strBuilding_the_Disguise		. '</td>
			<td width= "6%" align="center">'				. $strThe_Search_for_Illsuras	. '</td>
			<td width= "6%" align="center">'				. $strThe_Rage_of_Kelliad		. '</td>
			<td width= "6%" align="center">'				. $strThe_Lost_Notebook			. '</td>
			<td width= "6%" align="center">'				. $strCavern_Botany				. '</td>
			<td width= "6%" align="center">'				. $strThe_Search_for_Clues		. '</td>
			<td width= "6%" align="center">'				. $strRescue_Cicero				. '</td>
			<td width= "6%" align="center">'				. $strPreemptive_Strike			. '</td>
			<td width= "6%" align="center">'				. $strPraetorian_Guard			. '</td>
			<td width= "6%" align="center">'				. $strThe_Fall_of_Illsalin		. '</td>
			<td width= "6%" align="center">'				. $strFlights_of_the_Seeker		. '</td>
			<td width= "6%" align="center">'				. $strInto_the_Shadows			. '</td>
		  </tr>
		';
	}

}

?>
