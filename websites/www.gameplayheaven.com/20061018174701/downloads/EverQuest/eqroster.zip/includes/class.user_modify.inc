<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );
require_once( GetSkinDir() . 'class.skin.inc' );


// ============================================================================
// The Users class
// ============================================================================
// This class handles the User_Modify procedure
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class User_Modify
{
	// Member variables
	var $theSkin;

	// ========================================================================
	// Constructor
	// ========================================================================
	function User_Modify()
	{
		// No code yet
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "User Modify";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<!-- End of Header -->
		';
	}
	
	
	
	// ========================================================================
	// Show the body
	// ========================================================================
	// This function will show the user modify page
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS			= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName			= $_GET['UserName'];
		$strPassword			= $_GET['Password'];
		$strModifyUserName		= $_GET['ModifyUserName'];
		$strNewPassword			= $_GET['editNewPassword'];
		$strNewPasswordCheck	= $_GET['editNewPasswordCheck'];
		$strEMailAddress		= $_GET['editEMailAddress'];
		$strShowEMail			= $_GET['cmbShowEMail'];
		$strTimeZone			= $_GET['cmbTimeZone'];
		$bValidated				= $_GET['cbValidated'];
		// Declare variables
		$strResultCode			= "";
	
		// Check if the UserName or ModifyUserName is not set
		if( ( !isset( $strModifyUserName ) ) ||
			( !isset( $strUserName ) ) )
		{
			// Show error message
			echo '
			<form name="formModifyUser" method="post" action="form.php?FormName=Characters" target=Body>
			  <div id="Body" align="center">
			    <font size="+2" color="' . $this->theSkin->strErrorColor . '">
			      <br />
			      Illegal call to page...<br />
			      ERROR 01: Unkown user!
			    </font>
			  </div>
			</form>
			';

			// Abort page
			return;
		}

		// Check if we should update the User
		if( ( isset( $bValidated ) ) &&
			( $bValidated == true ) )
		{
			// Re-check the password, to prevent hacking
			if( CheckPassword( $strUserName, $strPassword ) == false )
			{
				// Wrong password, warn the user
				echo '
				<form name="formModifyUser" method="post" action="form.php?FormName=Characters" target=Body>
				  <div id="Body" align="center">
				    <font size="+2" color="' . $this->theSkin->strErrorColor . '">
				      <br />
				      Incorrect password detected...<br />
				      You will be logged out and returned to the main page!<br />
					  <br />
					  <input name="pbContinue" type="submit" id="pbContinue" value="Continue"> <br />
				    </font>
				  </div>
				</form>
				';

				// Abort page
				return;
			}
			
			// Update the user
			$strResultCode	= $this->UpdateUser( $strUserName, $strPassword, $strModifyUserName, $strNewPassword, $strEMailAddress, $strShowEMail, $strTimeZone );
	
			// Check if the password was changed
			if( ( ( $strResultCode == "EMAIL_UPDATED" ) ||
				  ( $strResultCode == "USER_UPDATED" ) ) &&
				( isset( $strNewPassword ) ) &&
				( $strNewPassword != "" ) &&
				( $strUserName == $strModifyUserName ) )	// Only write the cookie if the user is editing him/herself
			{
				// Store the new password
				$strPassword	= Encrypt( $strNewPassword );
	
				// Write the cookie (with the new password)
				WriteCookie( $strUserName, $strPassword, "", "", "No" );
			}
	
			// Check if the EMail has changed
			if( $strResultCode == "EMAIL_UPDATED" )
			{
				// Fill the E-mail fields
				$strAddresse	= $strEMailAddress;
				$strSubject		= GetRosterName() . " Verification";
				$strContents	= "Hello $strModifyUserName,\n" .
								  "\n" .
								  "Here is your verification code as requested: \"" . Encrypt( strtoupper($strUserName . $strEMailAddress) ) . "\" (without the quotes).\n" .
								  "You will be asked for this code if you try to login.\n" .
								  "\n" .
								  "The " . GetRosterName() . " crew.\n";
				$strFromSender	= "From: " . GetAdminEmail();
				// Send the verification E-mail
				mail( $strAddresse, $strSubject, $strContents, $strFromSender );

				// Check if the user or an admin edited the user
				if( $strUserName == $strModifyUserName )
				{	
					// Switch to verify_user
					LoadForm( "User_Verify", "&UserName=" . $strUserName . "&Password=" . $strPassword );
				}
				else
				{
					// Go back to the member list
					LoadForm( "Users", "&UserName=" . $strUserName . "&Password=" . $strPassword );
				}

				// Abort page
				return;
			}
		}
	
		// Check if the E-Mail address is empty
		if( ( !isset( $strEMailAddress ) ) ||
			( $strEMailAddress == "" ) )
		{
			// Show the modify user page from the table
			$this->ShowModifyUserPageFromTable( $strUserName, $strPassword, $strModifyUserName, $bValidated );
		}
		else
		{
			// Show the modify user page
			$this->ShowModifyUserPage( $strUserName, $strPassword, $strModifyUserName, $strNewPassword, $strNewPasswordCheck, $strEMailAddress, $strShowEMail, $strTimeZone, $bValidated );

			// Check if we already performed an update		
			if( $strResultCode != "" )
			{
				// Show user updated message
				echo '
				<center><font color="' . $this->theSkin->strWarningColor . '">
				  The changes have been saved.<br \>
				</font></center>
				';
			}
		}
	}
	
	
	
	// ========================================================================
	// Update the user
	// ========================================================================
	function UpdateUser( $strUserName, $strPassword, $strModifyUserName, $strNewPassword, $strEMailAddress, $strShowEMail, $strTimeZone )
	{
		// Declare variables
		$strResult				= "UPDATE_FAILED";
		$strEncryptedPassword	= Encrypt( $strNewPassword );		// Encrypt the password
		$strSelectEMailQuery	= "SELECT EMailAddress FROM Users WHERE UserName = '$strModifyUserName'";
	
		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Retrieve the E-Mail Address for this user
		$nResult	= mysql_query( $strSelectEMailQuery, $nLinkID );
		$aResult	= mysql_fetch_row( $nResult );
		// Store the E-Mail Address
		if( isset( $aResult[0] ) )
		{
			$strOldEMailAddress	= $aResult[0];
		}
	
		// Check the User exists
		if( isset( $strOldEMailAddress ) )
		{
			// Create update query
			$strUpdateQuery				= "UPDATE Users \n" .
										  "SET ShowEMail    = '$strShowEMail', \n";
	
			// Only update the password if it was entered
			if( ( isset( $strNewPassword ) ) &&
				( $strNewPassword != "" ) )
			{
				$strUpdateQuery			.= "    Password     = '$strEncryptedPassword', \n";
			}
	
			// Check if the E-Mail address was entered
			if( isset( $strEMailAddress ) )
			{
				// Only update the EMail Address if it was entered and has been changed
				if( $strEMailAddress != $strOldEMailAddress )
				{
					$strUpdateQuery		.= "    EMailAddress = '$strEMailAddress', \n";
					// Check if the E-Mail has actually been changed (not just different capitals)
					if( strtoupper( $strEMailAddress ) != strtoupper( $strOldEMailAddress ) )
					{
						$strUpdateQuery	.= "    Verified     = 'No', \n";
					}
				}
			}
	
			// CLose the query
			$strUpdateQuery				.= "    TimeZone     = '$strTimeZone' \n" .
										   "WHERE UserName = '$strModifyUserName'";
	
			// Update the user
			$nResult	= mysql_query( $strUpdateQuery, $nLinkID );
			// Check if the update was succesfull
			if( $nResult == 1 )
			{
				// Set the result
				$strResult	= "USER_UPDATED";
	
				// If the EMail Address has been updated, send the verification E-Mail
				if( ( isset( $strEMailAddress ) ) &&
					( strtoupper( $strEMailAddress ) != strtoupper( $strOldEMailAddress ) ) )
				{
					$strResult	= "EMAIL_UPDATED";
				}
			}
		}
		else
		{
			$strResult	= "UNKOWN_USER";
		}
	
		// Close the connection
		DBDisconnect( $nLinkID );
	
		return $strResult;
	}
	
	
	
	// ========================================================================
	// Retrieve all the user data from the tables and show the Modify user page
	// ========================================================================
	function ShowModifyUserPageFromTable( $strUserName, $strPassword, $strModifyUserName, $bValidated )
	{
		// Declare variables
		$strSelectQuery	= "SELECT EMailAddress, ShowEMail, TimeZone FROM Users WHERE UserName = '$strModifyUserName'";
	
		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Retrieve the record
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Fetch the record
		$aResult	= mysql_fetch_row( $nResult );
	
		// Close the connection
		DBDisconnect( $nLinkID );
	
	    if( $aResult ) 
		{
			// Retrieve the variables out of the array
			$nIndex				= 0;
			$strEMailAddress	= $aResult[$nIndex++];
			$strShowEMail		= $aResult[$nIndex++];
			$strTimeZone		= $aResult[$nIndex++];
	
			// Show the Modify Character page
			$this->ShowModifyUserPage( $strUserName, $strPassword, $strModifyUserName, "", "", $strEMailAddress, $strShowEMail, $strTimeZone, $bValidated );
		}
	}
	
	
	
	// ========================================================================
	// Show the Modify User page
	// ========================================================================
	function ShowModifyUserPage( $strUserName, $strPassword, $strModifyUserName, $strNewPassword, $strNewPasswordCheck, $strEMailAddress, $strShowEMail, $strTimeZone, $bValidated )
	{
		echo '
		<!-- JavaScript block has been added here instead of in the header on purpose -->
		<script language="JavaScript">
		<!-- Check if all the fields on the form are valid -->
		function ValidateFields()
		{
			// Check if the password is filled
			if( document.formModifyUser.editNewPassword.value != "" )
			{
				// Check if both passwords are the same
				if( document.formModifyUser.editNewPassword.value != document.formModifyUser.editNewPasswordCheck.value )
				{
					alert( "The passwords don\'t match, make sure they\'re both the same!" );
					document.formModifyUser.editNewPassword.focus();
					return false;
				}
			}
	
			// Check if the E-mail address is filled
			if( document.formModifyUser.editNewPassword.value != "" )
			{
				// Check if the E-mail address does not contain the @ and .
				var	strEMailFilter	= /^.+@.+\..{2,3}$/;
				if( !( strEMailFilter.test( document.formModifyUser.editEMailAddress.value ) ) )
				{ 
					alert( "Please enter a valid E-mail address." );
					document.formModifyUser.editEMailAddress.focus();
					return false;
				}
				// Check if the E-mail address contains any invalid characters
				var	strIllegalChars	= /[\(\)\<\>\,\;\:\\/\"\[\]]/;
				if( document.formModifyUser.editEMailAddress.value.match( strIllegalChars ) )
				{
					alert( "The E-mail address contains illegal characters." );
					document.formModifyUser.editEMailAddress.focus();
					return false;
				}
			}
	
			// Validation complete, all fields are valid
			document.formModifyUser.cbValidated.value	= true;
	
			// Submit the form
			document.formModifyUser.submit();
	
			// Done
			return true;
		};
		</script>
	
		<form name="formModifyUser" method="post" action="form.php?FormName=User_Modify&UserName=' . $strUserName . '&Password=' . $strPassword . '&ModifyUserName=' . $strModifyUserName . '" target=Body>
		  <div id="Body" align="center"> 
		  <p><strong><font color="' . $this->theSkin->strBodyFontColor . '" size="+3"><em>Modify User "' . $strModifyUserName . '"</em></font></strong></p>
			<p>&nbsp;</p>
			<table width="60%" border="0">
			  <tr> 
				<td width="20%"></td>
				<td width="30%">Password:</td>
				<td width="50%"><input name="editNewPassword" type="password" id="editNewPassword" value="' . $strNewPassword . '"></td>
			  </tr>
			  <tr> 
				<td width="20%"></td>
				<td width="30%">Verify Password:</td>
				<td width="50%"><input name="editNewPasswordCheck" type="password" id="editNewPasswordCheck" value="' . $strNewPasswordCheck . '"></td>
			  </tr>
			  <tr> 
				<td width="20%"></td>
				<td width="30%">E-mail address:</td>
				<td width="50%"><input name="editEMailAddress" type="text" id="editEMailAddress" value="' . $strEMailAddress . '"  size="40"></td>
			  </tr>
			  <tr> 
				<td width="20%"></td>
				<td width="30%">Show E-Mail address:</td>
				<td width="50%">' . CreateSelectFromEnum( "Users", "ShowEMail", $strShowEMail, "					" ) . '</td>
			  </tr>
			  <tr> 
				<td width="20%"></td>
				<td width="30%">Time zone:</td>
				<td width="50%">' . CreateSelectFromEnum( "Users", "TimeZone", $strTimeZone, "					" ) . '</td>
			  </tr>
			</table>
			<br />
			<p>
			  <input name="pbUpdate" type="button" id="pbUpdate" value="Update" onclick="ValidateFields()">
			</p>
	
		    <!-- Hidden field to store Validation status -->
		    <input name="cbValidated" type="hidden" id="cbValidated" value="' . $bValidated . '">
		  </div>
		</form>';
	}



	// ========================================================================
	// Show the footer
	// ========================================================================
	function ShowFooter( $strUserName, $strPassword )
	{
		// Show the verify footer
		echo '
		<!-- Start of Footer -->
		<br />
		<div id="Footer">
		<center>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td align="center">
			  <font face="verdana,arial" size="2" ><b>
				<a href="form.php?FormName=User_Verify&UserName=' . $strUserName . '&Password=' . $strPassword . '"	OnMouseOver="window.status=\'Verify ' . $strUserName . '\\\' E-Mail address\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Verify ' . $strUserName . '\' E-Mail address">Verify User</a> |
				<a href="form.php?FormName=Characters&UserName=&Password=&CookieAction=DELETE"						OnMouseOver="window.status=\'Log ' . $strUserName . ' out\';return true;"					OnMouseOut="window.status=\'\'"	target=Body title="Log ' . $strUserName . ' out">Log out</a>
			  </b></font>
			</td>
		  </tr>
		</table>
		</center>
		</div>
		<!-- End of Footer -->
		';
	}

}

?>
