<?php
// Includes
require_once( './includes/class.httpconnection.inc' );
require_once( GetSkinDir() . 'class.skin.inc' );


// ============================================================================
// The EQPlayers class
// ============================================================================
// This class will retrieve and store all the info from a characters EQ Players profile
//
// Usage:
// Create an EQPlayers object, passing the required 2 parameters:
//	$theEQPlayers	= new EQPlayers( $nGuildID );
// Call the import function:
//	$bEQPlayersImported	= $theEQPlayers->Import( $strCharacterName );
// Check if the Import succeeded
//	if( $bEQPlayersImported == true )
//	{
//		// Perform your actions with the EQPlayers variables here
//	}
//
// ============================================================================
class EQPlayers
{
	// Member variables
	var $theSkin;
	var $nGuildID		= -1;
	var $strGuildPage	= "";
	var $nCharacterID	= -1;
	var $bAnonymous		= false;
	// Character info
	var $strCharName	= "";
	var $strClass		= "";
	var $nLevel			= 0;
	var $strDeity		= "";
	var $strLastName	= "";
	var $strRace		= "";
	var $strLastOnDate	= "";
	// Character Statistics
	var $nHP			= 0;
	var $nMana			= 0;
	var $nAC			= 0;
	var $nEndurance		= 0;
	var $nAtk			= 0;
	var $nStr			= 0;
	var $nSta			= 0;
	var $nAgi			= 0;
	var $nDex			= 0;
	var $nWis			= 0;
	var $nInt			= 0;
	var $nCha			= 0;
	var $nPR			= 0;
	var $nMR			= 0;
	var $nDR			= 0;
	var $nFR			= 0;
	var $nCR			= 0;



	// ========================================================================
	// Constructor
	// ========================================================================
	// In:	$nGuildID	= ID of your guild on the EQ Players website
	// ========================================================================
	function EQPlayers( $nGuildID )
	{
		// Create the skin
		$this->theSkin	= new Skin();

		// Store the guild settings
		$this->nGuildID		= $nGuildID;

		// Initialize the variables
		$this->Reset();

		// Get the Guild page
		$this->ImportGuild();
	}



	// ========================================================================
	// Reset all variables
	// ========================================================================
	function Reset()
	{
		// Reset all variables
		$this->nCharacterID		= 0;
		$this->strCharName		= "";
		$this->bAnonymous		= false;
		// Character info
		$this->strClass			= "";
		$this->nLevel			= 0;
		$this->strDeity			= "";
		$this->strLastName		= "";
		$this->strRace			= "";
		$this->strLastOnDate	= "0000-00-00";
		// Character Statistics
		$this->nHP				= 0;
		$this->nMana			= 0;
		$this->nAC				= 0;
		$this->nEndurance		= 0;
		$this->nAtk				= 0;
		$this->nStr				= 0;
		$this->nSta				= 0;
		$this->nAgi				= 0;
		$this->nDex				= 0;
		$this->nWis				= 0;
		$this->nInt				= 0;
		$this->nCha				= 0;
		$this->nPR				= 0;
		$this->nMR				= 0;
		$this->nDR				= 0;
		$this->nFR				= 0;
		$this->nCR				= 0;
	}



	// ========================================================================
	// Retrieve Guild info from the EQPlayers site
	// ========================================================================
	// This function will open the EQPlayers Guild page and store it in memory.
	// It can then be used to look up a character's EQPlayers CharacterID.
	//
	// !!!WARNING!!!
	// DO NOT call this function a lot of times in a row.
	// If you want to retrieve the EQPlayers Guild pages for a lot of guilds
	// in a row, then make sure you wait 5 to 10 minutes between each call to
	// this function, otherwise your IP might get banned on the EQPlayers site.
	// ========================================================================
	// Out:	Boolean indicating wether the import succeeded or failed
	// ========================================================================
	function ImportGuild()
	{
		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve the EQPlayers profile into memory
		///////////////////////////////////////////////////////////////////////////////////
		$strHost		= "eqplayers.station.sony.com";
		$strProtocol	= "HTTP/1.0";
		$strURL			= "/guild_profile.vm?guildId=" . $this->nGuildID;

		$astrHeaders[]	= new HTTP_Header( "Accept", "text/html, */*" );
		$astrHeaders[]	= new HTTP_Header( "User-Agent", "Mozilla/4.0 (compatible; MSIE 5.01; Windows 98;)" );
		$astrHeaders[]	= new HTTP_Header( "Host", $strHost );
		$astrHeaders[]	= new HTTP_Header( "Referer", "" );

		$strHTTPRequest	= new HTTP_Request( "GET", $strURL, $strProtocol, $astrHeaders );
		$theConnection	= new HTTP_Connection( $strHost );

		$theConnection->Connect();
		$theConnection->Request( $strHTTPRequest );
		$theConnection->Response( $theResponse );
		$theConnection->Close();

		// Retrieve the content
		$this->strGuildPage	= $theResponse->GetEntityBody();

		// Check if page was succesfully loaded
//		print( "GuildPage: " . strlen( $this->strGuildPage ) . " bytes<br>\n" );

		// Guild Import completed succesfully
		return true;
	}



	// ========================================================================
	// Retrieve Character info from the EQPlayers profile
	// ========================================================================
	// This function will look the Characters ID up in the stored Guild page, 
	// and then retrieve all it's info by the found ID.
	// ========================================================================
	// Out:	Boolean indicating wether the import succeeded or failed
	// ========================================================================
	function ImportCharacterByName( $strCharacterName )
	{
		// Retrieve the CharacterID
		if( ereg( 'character_profile.vm\?characterId=([0-9]{1,20})" class="innerContentData">' . $strCharacterName . '</a>', $this->strGuildPage, $aMatches ) )
		{
			$this->nCharacterID	= $aMatches[1];
		}
		else
		{
			return false;
		}

		return $this->ImportCharacterByID( $this->nCharacterID, $strCharacterName );
	}



	// ========================================================================
	// Retrieve Character info from the EQPlayers profile
	// ========================================================================
	// This function will open the EQPlayers page and store it in memory.
	// It will then perform string manupilations to retrieve the character
	// details out of the EQPlayers profile, and store them in variables.
	//
	// !!!WARNING!!!
	// DO NOT call this function a lot of times in a row.
	// If you want to retrieve the EQPlayers profiles for a lot of characters,
	// in a row then make sure you wait 5 to 10 minutes between each call to
	// this function, otherwise your IP might get banned on the EQPlayers site.
	// ========================================================================
	// Out:	Boolean indicating wether the import succeeded or failed
	// ========================================================================
	function ImportCharacterByID( $nCharacterID, $strCharacterName )
	{
		// Clear all old values
		$this->Reset();

		// Store the CharacterID
		$this->nCharacterID		= $nCharacterID;
		$this->strCharName		= $strCharacterName;

		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve the EQPlayers profile into memory
		///////////////////////////////////////////////////////////////////////////////////
		$strHost		= "eqplayers.station.sony.com";
		$strProtocol	= "HTTP/1.0";
		$strURL			= "/character_profile.vm?characterId=" . $this->nCharacterID;

		$astrHeaders[]	= new HTTP_Header( "Accept", "text/html, */*" );
		$astrHeaders[]	= new HTTP_Header( "User-Agent", "Mozilla/4.0 (compatible; MSIE 5.01; Windows 98;)" );
		$astrHeaders[]	= new HTTP_Header( "Host", $strHost );
		$astrHeaders[]	= new HTTP_Header( "Referer", "" );

		$strHTTPRequest	= new HTTP_Request( "GET", $strURL, $strProtocol, $astrHeaders );
		$theConnection	= new HTTP_Connection( $strHost );

		$theConnection->Connect();
		$theConnection->Request( $strHTTPRequest );
		$theConnection->Response( $theResponse );
		$theConnection->Close();

		// Retrieve the content
		$strContent		= $theResponse->GetEntityBody();

		// Check if page was succesfully loaded
//		print( "CharPage: " . strlen( $strContent ) . " bytes<br>\n" );

		// Remove all tabs
		$strContent	= ereg_replace( "	", "", $strContent );
		// Remove all clusters of 4 spaces in a row
		$strContent	= ereg_replace( "    ", "", $strContent );
		// Remove extra space before < tag (Mana/Disease)
		$strContent	= ereg_replace( " <", "<", $strContent );
//print( "<hr>$strContent<hr>" );

		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve Character Info
		///////////////////////////////////////////////////////////////////////////////////

		// Check if the character is anonymous
		if( ereg( '>Level</td>.<td colspan="2">.<div align="right" class="innerContentData">/Anonymous</div>', $strContent, $aMatches ) )
		{
			$this->bAnonymous			= true;
		}

		// Retrieve the LastName
		if( ereg( "<nobr>" . $this->strCharName . " ([a-zA-Z`\\\'-]+){0,1}<", $strContent, $aMatches ) )
		{
			$this->strLastName			= $aMatches[1];
		}

		// Retrieve the Class
		if( ereg( '>Class</td>.<td colspan="2">.<div align="right" class="innerContentData">([a-zA-Z -]+)</div>', $strContent, $aMatches ) )
		{
			$this->strClass				= $aMatches[1];
		}

		// Retrieve the Level
		if( ereg( '>Level</td>.<td colspan="2">.<div align="right" class="innerContentData">([0-9]{1,3})</div>', $strContent, $aMatches ) )
		{
			$this->nLevel				= $aMatches[1];
		}
	
		// Retrieve the Deity
		if( ereg( '>Deity</td>.<td colspan="2">.<div align="right" class="innerContentData">([a-zA-Z -]+)</div>', $strContent, $aMatches ) )
		{
			$this->strDeity				= $aMatches[1];
		}

		// Retrieve the Race
		if( ereg( '>Race</td>.<td colspan="2">.<div align="right" class="innerContentData">([a-zA-Z -]+)</div>', $strContent, $aMatches ) )
		{
			$this->strRace				= $aMatches[1];
		}

		// Retrieve the Race
		if( ereg( '>Last Online</td>.<td colspan="3" class="innerContentDataNoPad">.<div class="innerContentData">([a-zA-Z]{3}) ([0-9]{1,2}) ([0-9]{1,4})<', $strContent, $aMatches ) )
		{
			$strMonth	= $aMatches[1];
			$nDay		= $aMatches[2];
			$nYear		= $aMatches[3];
			// Skip Nov 16 2005, as this is they day EQPlayers went live.
			if( $strMonth == "Nov" && $nDay == 16 && $nYear == 2005 )
			{
				$this->strLastOnDate	= "0000-00-00";
			}
			else
			{
				// Convert the date to the MySQL database format, which uses the "YYYY-MM-DD" format
				if( $strMonth == "Jan" )	{	$nMonth	= 01;	}
				if( $strMonth == "Feb" )	{	$nMonth	= 02;	}
				if( $strMonth == "Mar" )	{	$nMonth	= 03;	}
				if( $strMonth == "Apr" )	{	$nMonth	= 04;	}
				if( $strMonth == "May" )	{	$nMonth	= 05;	}
				if( $strMonth == "Jun" )	{	$nMonth	= 06;	}
				if( $strMonth == "Jul" )	{	$nMonth	= 07;	}
				if( $strMonth == "Aug" )	{	$nMonth	= 08;	}
				if( $strMonth == "Sep" )	{	$nMonth	= 09;	}
				if( $strMonth == "Oct" )	{	$nMonth	= 10;	}
				if( $strMonth == "Nov" )	{	$nMonth	= 11;	}
				if( $strMonth == "Dec" )	{	$nMonth	= 12;	}
				// Create the date
				$this->strLastOnDate	= $nYear . "-" . $nMonth . "-" . $nDay;
			}
		}

		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve Character Statistics
		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve the HP
		if( ereg( '>Hit Points</td>.<td colspan="2">.<div align="right"><strong>([0-9,]{1,6})</strong>', $strContent, $aMatches ) )
		{
			$this->nHP					= ereg_replace( ",", "", $aMatches[1] );
		}

		// Retrieve the Mana
		if( ereg( '>Mana</td>.<td colspan="2">.<div align="right"><strong>([0-9,]{1,6})</strong>', $strContent, $aMatches ) )
		{
			$this->nMana				= ereg_replace( ",", "", $aMatches[1] );
		}

		// Retrieve the Endurance
		if( ereg( '>Endurance</td>.<td colspan="2">.<div align="right"><strong>([0-9,]{1,6})*</strong>', $strContent, $aMatches ) )
		{
			$this->nEndurance			= ereg_replace( ",", "", $aMatches[1] );
		}

		// Retrieve the AC
		if( ereg( '>Armor Class</td>.<td colspan="2">.<div align="right"><strong>([0-9,]{1,5})</strong>', $strContent, $aMatches ) )
		{
			$this->nAC					= ereg_replace( ",", "", $aMatches[1] );
		}

		// Retrieve the Atk
		if( ereg( '>Attack</td>.<td colspan="2">.<div align="right"><strong>([0-9,]{1,5})</strong>', $strContent, $aMatches ) )
		{
			$this->nAtk					= ereg_replace( ",", "", $aMatches[1] );
		}

		// Retrieve the Str
		if( ereg( '>STR</td>.<td width="25%" class="innerContentField">.<div align="right" class="innerContentData"><font color="#000000">([0-9]{1,3})</font>', $strContent, $aMatches ) )
		{
			$this->nStr					= $aMatches[1];
		}

		// Retrieve the Sta
		if( ereg( '>STA</td>.<td width="25%" class="innerContentField">.<div align="right" class="innerContentData"><font color="#000000">([0-9]{1,3})</font>', $strContent, $aMatches ) )
		{
			$this->nSta					= $aMatches[1];
		}

		// Retrieve the Agi
		if( ereg( '>AGI</td>.<td width="25%" class="innerContentField">.<div align="right" class="innerContentData"><font color="#000000">([0-9]{1,3})</font>', $strContent, $aMatches ) )
		{
			$this->nAgi					= $aMatches[1];
		}

		// Retrieve the Dex
		if( ereg( '>DEX</td>.<td width="25%" class="innerContentField">.<div align="right" class="innerContentData"><font color="#000000">([0-9]{1,3})</font>', $strContent, $aMatches ) )
		{
			$this->nDex					= $aMatches[1];
		}

		// Retrieve the Wis
		if( ereg( '>WIS</td>.<td width="25%" class="innerContentField">.<div align="right" class="innerContentData"><font color="#000000">([0-9]{1,3})</font>', $strContent, $aMatches ) )
		{
			$this->nWis					= $aMatches[1];
		}

		// Retrieve the Int
		if( ereg( '>INT</td>.<td width="25%" class="innerContentField">.<div align="right" class="innerContentData"><font color="#000000">([0-9]{1,3})</font>', $strContent, $aMatches ) )
		{
			$this->nInt					= $aMatches[1];
		}

		// Retrieve the Cha
		if( ereg( '>CHA</td>.<td width="25%" class="innerContentField">.<div align="right"><font color="#000000">([0-9]{1,3})</font>', $strContent, $aMatches ) )
		{
			$this->nCha					= $aMatches[1];
		}

		// Retrieve the PR
		if( ereg( 'Poison</td>.<td width="25%">.<div align="right"><strong>([0-9]{1,3})*</strong>', $strContent, $aMatches ) )
		{
			$this->nPR					= $aMatches[1];
		}

		// Retrieve the MR
		if( ereg( 'Magic</td>.<td width="25%">.<div align="right"><strong>([0-9]{1,3})*</strong>', $strContent, $aMatches ) )
		{
			$this->nMR					= $aMatches[1];
		}

		// Retrieve the DR
		if( ereg( 'Disease</td>.<td width="25%">.<div align="right"><strong>([0-9]{1,3})*</strong>', $strContent, $aMatches ) )
		{
			$this->nDR					= $aMatches[1];
		}

		// Retrieve the FR
		if( ereg( 'Fire</td>.<td width="25%">.<div align="right"><strong>([0-9]{1,3})*</strong>', $strContent, $aMatches ) )
		{
			$this->nFR					= $aMatches[1];
		}

		// Retrieve the CR
		if( ereg( 'Cold</td>.<td width="25%">.<div align="right"><strong>([0-9]{1,3})*</strong>', $strContent, $aMatches ) )
		{
			$this->nCR					= $aMatches[1];
		}

		// Character Import completed succesfully
		return true;
	}



	// ========================================================================
	// Show the magelo info on screen (debug function)
	// ========================================================================
	// This function is only here for debug purposes.
	// If you really want to output the data to screen, 
	// you should create you're own layout and rewrite this function
	// ========================================================================
	function Show()
	{
		// Print the results
		print( "GuildID				= [" . $this->nGuildID . "]								<br \>\n" );
		print( "CharacterID			= [" . $this->nCharacterID . "]							<br \>\n" );
		print( "Anonymous			= [" . $this->bAnonymous . "]							<br \>\n" );
		print( "<hr \>\n" );
		// Character info
		print( "CharName			= [" . $this->strCharName . "]							<br \>\n" );
		print( "LastName			= [" . $this->strLastName . "]							<br \>\n" );
		print( "Class				= [" . $this->strClass . "]								<br \>\n" );
		print( "Level				= [" . $this->nLevel . "]								<br \>\n" );
		print( "Deity				= [" . $this->strDeity . "]								<br \>\n" );
		print( "Race				= [" . $this->strRace . "]								<br \>\n" );
		print( "LastOn date			= [" . $this->strLastOnDate . "]						<br \>\n" );
		print( "<hr \>\n" );
		// Character Statistics
		print( "HP					= [" . $this->nHP . "]									<br \>\n" );
		print( "Mana				= [" . $this->nMana . "]								<br \>\n" );
		print( "AC					= [" . $this->nAC . "]									<br \>\n" );
		print( "Endurance			= [" . $this->nEndurance . "]							<br \>\n" );
		print( "Atk					= [" . $this->nAtk . "]									<br \>\n" );
		print( "<hr \>\n" );
		print( "Str					= [" . $this->nStr . "]									<br \>\n" );
		print( "Sta					= [" . $this->nSta . "]									<br \>\n" );
		print( "Agi					= [" . $this->nAgi . "]									<br \>\n" );
		print( "Dex					= [" . $this->nDex . "]									<br \>\n" );
		print( "Wis					= [" . $this->nWis . "]									<br \>\n" );
		print( "Int					= [" . $this->nInt . "]									<br \>\n" );
		print( "Cha					= [" . $this->nCha . "]									<br \>\n" );
		print( "PR					= [" . $this->nPR . "]									<br \>\n" );
		print( "MR					= [" . $this->nMR . "]									<br \>\n" );
		print( "DR					= [" . $this->nDR . "]									<br \>\n" );
		print( "FR					= [" . $this->nFR . "]									<br \>\n" );
		print( "CR					= [" . $this->nCR . "]									<br \>\n" );
		print( "<hr \>\n" );
	}
}

?>
