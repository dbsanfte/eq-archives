<?php

// ============================================================================
// The Skin class
// ============================================================================
// This class contains all the skin attributes that are not stored in the css files.
// ============================================================================
class Skin
{
	// Generic Colors
	var $strRowHighlightColor		= "#EEEEEE";		// The row highlight color

	// Result Colors
	var $strErrorColor				= "#FF3300";		// Error color
	var $strWarningColor			= "#9999FF";		// Warning color
	var $strOKColor					= "#00CC00";		// OK or Success color
	var $strStatusColor				= "#9999FF";		// Status color (used in batch import & guild tool update status messages)

	// Font colors
	var $strHeaderFontColor			= "#09A0FF";		// Font color used in the Header (frame)
	var $strBodyFontColor			= "#09A0FF";		// Font color used in the Body (frame)
	var $strFooterFontColor			= "#09A0FF";		// Font color used in the Footer (frame)
	var $strSpecialFooterFontColor	= "#000000";		// Special font color used for GamePlayHeaven footer texts

	// Alternating colors
	var $strFontColorLight			= "#09A0FF";		// Keep these 2 colors close together, 
	var $strFontColorDark			= "#0066BB";		// with just a little difference in tint

	// Character Modify colors
	var $strCharModifyFontColor		= "#EEEEEE";		// Font used on the Character Modify page
	var $strCharModifyHeaderBGColor	= "#80AFCC";		// Background color on the Character Modify page

	// Batch Import colors
	var $strBatchImportFontColor	= "#00CC00";		// Font used on the Batch Import pages
	

	// ========================================================================
	// Constructor
	// ========================================================================
	function Skin()
	{
	}
}

?>