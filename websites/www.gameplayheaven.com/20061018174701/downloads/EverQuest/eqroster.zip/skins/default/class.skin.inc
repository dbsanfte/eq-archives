<?php

// ============================================================================
// The Skin class
// ============================================================================
// This class contains all the skin attributes that are not stored in the css files.
// ============================================================================
class Skin
{
	// Generic Colors
	var $strRowHighlightColor		= "#444444";		// The row highlight color

	// Result Colors
	var $strErrorColor				= "#FF3300";		// Error color
	var $strWarningColor			= "#C0C0FF";		// Warning color
	var $strOKColor					= "#33FF00";		// OK or Success color
	var $strStatusColor				= "#CCCCFF";		// Status color (used in batch import & guild tool update status messages)

	// Font colors
	var $strHeaderFontColor			= "#CCCCCC";		// Font color used in the Header (frame)
	var $strBodyFontColor			= "#CCCCCC";		// Font color used in the Body (frame)
	var $strFooterFontColor			= "#CCCCCC";		// Font color used in the Footer (frame)
	var $strSpecialFooterFontColor	= "#8CC8F6";		// Special font color used for GamePlayHeaven footer texts

	// Alternating colors
	var $strFontColorLight			= "#CCCCCC";		// Keep these 2 colors close together, 
	var $strFontColorDark			= "#999999";		// with just a little difference in tint

	// Character Modify colors
	var $strCharModifyFontColor		= "#FFFFFF";		// Font used on the Character Modify page
	var $strCharModifyHeaderBGColor	= "#777777";		// Background color on the Character Modify page

	// Batch Import colors
	var $strBatchImportFontColor	= "#00FF33";		// Font used on the Batch Import pages
	

	// ========================================================================
	// Constructor
	// ========================================================================
	function Skin()
	{
	}
}

?>