<?php
////////////////////////////////////////////////////////////////////////////////
//
//	Author:	Micha�l Schoonbrood
//	Date:	May 12, 2004
//
//	Description:
//	This script provides functions for some/most of the configurable data
//
//	Usage:
//	Add the following line under the "<?php" tag:
//	require ('./config.php');
//
////////////////////////////////////////////////////////////////////////////////



// =============================================================================
// Connect to a database
// =============================================================================
// Out:	$nLinkID	= The ID of the database connection
function DBConnect()
{
	// Declare variables
	$nLinkID		= -1;
	// Database configuration
	$strDatabase	= "EQRoster";	// Replace this with the name of your database (for example "GuildName_EQRoster")
	$strHost		= "localhost";
	$strDBUserName	= "eqroster";	// Replace this with the name of the user you created (with SELECT,INSERT,UPDATE rights on the database)
	$strDBPassword	= "everquest_rocks";

	// Connect to the database
	$nLinkID	= mysql_connect( $strHost, $strDBUserName, $strDBPassword )	or die( "<br /><center><b><font color=\"#FF3300\">User '$strDBUserName' could not connect to the host '$strHost'.<br />\n ("		 . mysql_errno() . ") "  . mysql_error() . "</font></b><center>" );
	mysql_select_db( "$strDatabase", $nLinkID )								or die( "<br /><center><b><font color=\"#FF3300\">User '$strDBUserName' could not connect to the database '$strDatabase'.<br />\n (" . mysql_errno() . ") "  . mysql_error() . "</font></b><center>" );

	// Return the name
	return $nLinkID;
}



// =============================================================================
// Disconnect a database connection
// =============================================================================
// In:	$nLinkID	= The ID of the database connection to disconnect
function DBDisconnect( $nLinkID )
{
	// Close the connection
	mysql_close( $nLinkID );
}



// =============================================================================
// Check if a user has administrator rights
// =============================================================================
// Administrators can:
// - edit all characters
// - edit a character's GuildStatus
// - see all members, including deleted ones (aka marked as OldMembers)
// =============================================================================
// In:	$strUsername	= The name of the logged-in user
// Out:	$bAdministrator	= Boolean indicating wether the user has admin rights or not
function IsAdministrator( $strUserName )
{
	// Declare variables
	$bAdministrator	= false;

	// Check if the UserName is one of the Admin names
	if( $strUserName == "<<InsertYourAdminUsernameHere>>" )
	{
		$bAdministrator	= true;
	}

	// Done
	return $bAdministrator;
}



// =============================================================================
// Check if the CharName is valid
// =============================================================================
// In:	$strCharname	= A name of a character
// Out:	$bValidCharName	= Boolean indicating wether the character name is valid
function IsCharNameValid( $strCharName )
{
	// Declare variables
	$bValidCharName	= true;

	// Check if the name is valid
	if( ( $strCharName == "" ) ||					// Skip empty character names
		( $strCharName == "<<BuggedCharName>>" ) ) 	// Skip <<BuggedCharName>> because he is bugged in the guild tool
	{
		$bValidCharName	= false;
	}

	// Done
	return $bValidCharName;
}



// =============================================================================
// Get the name of the roster
// =============================================================================
// Out:	$strRosterName	= Name of the roster
function GetRosterName()
{
	return "EverQuest Roster";
}



// =============================================================================
// Get the E-Mail Address of the roster admin
// =============================================================================
// Out:	$strAdminEmail	= E-Mail address of the roster admin
function GetAdminEmail()
{
	return "Admin@EverQuestRoster.com";
}



// =============================================================================
// Check if the user's password is valid
// =============================================================================
// In:	$strUsername	= The name of the user
// In:	$strPassword	= The password of the user (encrypted)
// Out:	$bValidPassword	= True if the password is valid, False otherwise
function CheckPassword( $strUserName, $strPassword )
{
	// Declare variables
	$bValidPassword	= false;

	// Connect to the database
	$nLinkID	= DBConnect();

	// Retrieve the users password and verification status
 	$nResult	= mysql_query( "select Password from Users where UserName = '$strUserName'", $nLinkID );//	or die( "Query failed (" . mysql_error() . ")" );
	$aResult	= mysql_fetch_row( $nResult );

	// Close the database connection
	DBDisconnect( $nLinkID );

	// Check if the password is correct
	if( ( isset( $strPassword ) ) &&
		( $aResult[0] == $strPassword ) )
	{
		$bValidPassword	= true;
	}

	return $bValidPassword;
}



// ========================================================================
// Check if the user is verified
// ========================================================================
// In:	$strUsername	= The name of the user
// Out:	$bVerified		= True if the user is verified, False otherwise
function IsUserVerified( $strUserName )
{
	// Declare variables
	$bVerified	= false;

	// Connect to the database
	$nLinkID	= DBConnect();

	// Retrieve the users password and verification status
 	$nResult	= mysql_query( "select Verified from Users where UserName = '$strUserName'", $nLinkID );
	$aResult	= mysql_fetch_row( $nResult );

	// Close the database connection
	DBDisconnect( $nLinkID );

	// Check if the password is correct
	if( $aResult[0] == "Yes" )
	{
		$bVerified	= true;
	}

	return $bVerified;
}



// =============================================================================
// Format a date
// =============================================================================
// Keep in mind that sorting the "LastOn" column, sorts on the database.
// So when you change the date display here (for example to: "DD-MM-YY"),
// then the column will still be sorted chronically, and not on your specified format here.
// That means July 10th 2004 (10-07-04) comes before August 8th 2004 (08-08-04).
//
// The column is also sized on 8 characters, so adding the milenia will probably overflow the column.
// You can fix this by resizing the "LastOn" column to display the dates correctly.
// =============================================================================
// In:	$strMySQLDate		= Date from the MySQL database, using the "YYYY-MM-DD" format
// Out:	$strFormattedDate	= Formatted date
function FormatDate( $strMySQLDate )
{
	// Declare variables
	$strSeperator	= "-";
	$strMilenia		= substr( $strMySQLDate, 0, 2 );
	$strYear		= substr( $strMySQLDate, 2, 2 );
	$strMonth		= substr( $strMySQLDate, 5, 2 );
	$strDay			= substr( $strMySQLDate, 8, 2 );

	// Return your date
	return ( $strYear . $strSeperator . $strMonth . $strSeperator . $strDay );	// "YY-MM-DD"
}



// =============================================================================
// Get the nr of days a user is allowed to not have logged on,
// before marking him/her as inactive on the roster
// =============================================================================
// Out:	$nNrOfDays	= The nr of allowed days
function GetNrOfAllowedInactiveDays()
{
	return 60;	// Default: 60 days allowed (approx. 2 months).
}



// =============================================================================
// Extract the name of a Main from a string
// =============================================================================
// In:	$strSource		= String possibly containing the name of a Main
// Out:	$strNameMain	= The name of the Main, or an empty string if no name Main found.
function ExtractNameMainFromString( $strSource )
{
	// Declare variables
	$strNameMain		= "";
	$nStartPos			= 0;
	$nEndPos			= 0;
	$bFound				= true;
	$nMainPrefixPos		= -1;
	$nAltPrefixPos		= -1;

	// Settings
	$bMainsHaveMains	= true;			// false: Mains don't have a name in the string, true: Mains will be in the string right after the MainPrefix
	$strMainPrefix		= "MAIN:";		// Prefix used before the name of the Main, if empty: the first word is used
	$bAltsHaveMains		= true;			// false: Alts don't have a name in the string, true: The Main of the Alt will be in the string right after the AltPrefix
	$strAltPrefix		= "MAIN:";		// Prefix used before the name of the Main belonging to this Alt
	// Examples
	// Mains and Alts have the name of the main as the first word in the string
//	$bMainsHaveMains	= true;
//	$strMainPrefix		= "";
//	$bAltsHaveMains		= true;
//	$strAltPrefix		= "";
	// Mains are not in the string, but Alts are marked as "Main: namemain" in the string
//	$bMainsHaveMains	= false;
//	$strMainPrefix		= "";
//	$bAltsHaveMains		= true;
//	$strAltPrefix		= "Main:";

	// Check for impossible combination first
	if( ( ( !$bMainsHaveMains ) && ( !$bAltsHaveMains ) ) ||
		( strlen( $strSource ) == 0 ) )
	{
		return "";
	}

	// Scan for the Main prefix
	if( ( $bMainsHaveMains ) && 
		( $strMainPrefix != "" ) )
	{
		// Convert tags to upper, to prevent case mismatching
		$strUpperSource		= strtoupper( $strSource );
		$strUpperPrefix		= strtoupper( $strMainPrefix );

		$nMainPrefixPos	= strpos( $strUpperSource, $strUpperPrefix, 0 );
		if( $nMainPrefixPos !== false )
		{
			$nStartPos	= $nMainPrefixPos + strlen( $strMainPrefix );
		}
		else
		{
			// Nothing found, abort
			return "";
		}
	}
	// Scan for the Alt prefix
	else if( ( $bAltsHaveMains ) && 
			 ( $strAltPrefix != "" ) )
	{
		// Convert tags to upper, to prevent case mismatching
		$strUpperSource		= strtoupper( $strSource );
		$strUpperPrefix		= strtoupper( $strAltPrefix );

		$nAltPrefixPos	= strpos( $strUpperSource, $strUpperPrefix, 0 );
		if( $nAltPrefixPos !== false )
		{
			$nStartPos	= $nAltPrefixPos + strlen( $strAltPrefix );
		}
		else
		{
			// Nothing found, abort
			return "";
		}
	}

	// Trim leading spaces by moving the startpositing backwards if it's a space
	while( $strSource[$nStartPos] === " " )
	{
		$nStartPos++;
	}

	// Scan for a space in the string, after our start position+1 (in case there's a space between the prefix and the name)
	$nEndPos	= strpos( $strSource, " ", $nStartPos );
	// If no space found, then use the full string
	if( $nEndPos == false )
	{
		$nEndPos		= strlen( $strSource );
	}
	// Subtract the name
	$strNameMain	= substr( $strSource, $nStartPos, $nEndPos - $nStartPos );

	// Make sure the name does not contain a '
	$nEndPos	= strpos( $strNameMain, "'", 0 );
	// Check if a ' was found
	if( $nEndPos > 0 )
	{
		// Cut everything from the ' of the name
		$strNameMain	= substr( $strSource, 0, $nEndPos );
	}

	// Make sure no weird trailing chars exist
	$strNameMain	= rtrim( $strNameMain, " ,.;:~'`" );

	// Make sure the name of the main is not the main prefix
	if( ( $strMainPrefix != "" ) &&
		( $strMainPrefix == $strNameMain ) )
	{
		// It's a main after all, Abort
		return "";
	}

	// Return the name
	return $strNameMain;
}



// =============================================================================
// Get your guild's EQPlayers GuildID
//
// To find out what your guild's EQPlayers GuildID is, go to:
// http://eqplayers.station.sony.com/guilds_index.vm
// Enter your guild's name and click search.
// On the next page, click the link for your guild (on the correct server).
// The GuildID will now be in your URL bar, for example:
// http://eqplayers.station.sony.com/guild_profile.vm?guildId=123123123123
// You can see that your GuildID is 123123123123.
// =============================================================================
// Out:	$nGuildID	= The EQPlayers GuildID for your guild.
function GetEQPlayersGuildID()
{
	return -1;	// Replace the -1 with your GuildID here, in our example: return 123123123123;
}



// =============================================================================
// Get name of the Skin to use
//
// There are 2 skins provided with the roster, "default" and "default_light".
//
// You can add your own skin by going to the skins subdir, and copying the
// default dir and renaming it (to your guild name for example).
// I recommend not using spaces in the name, use underscores instead
// (for example: epic_heroes)
//
// In this function you return the name of this subdir, as it will be used
// to determine the path to your skin.
// =============================================================================
// Out:	$strSkinName	= The name of the skin you want to use
function GetSkinName()
{
	// Make sure this dir exists in the skins subdir, and contains all the required files!
//	return "default_light";
	return "default";
}



// =============================================================================
// Get the full path of the skin dir to use
//
// This function will use the SkinName supplied above to determine the full
// path the the skins dir in use.
// =============================================================================
// Out:	$strSkinDir		= The full path to the skin you want to use
function GetSkinDir()
{
	return "skins/" . GetSkinName() . "/";
}

?>