<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );
require_once( GetSkinDir() . 'class.skin.inc' );


// Main PHP code
{
	// PHP5 with register_long_arrays off?
	if (!isset($HTTP_POST_VARS) && isset($_POST))
	{
		$HTTP_POST_VARS		= $_POST;
		$HTTP_GET_VARS		= $_GET;
		$HTTP_POST_FILES	= $_FILES;
	}

	// Create the CharacterModify form
	$theGuildToolUpdateForm	= new GuildToolUpdateForm();
	// Show the form
	$theGuildToolUpdateForm->Show( $HTTP_POST_VARS, $HTTP_GET_VARS, $HTTP_POST_FILES );
}



// ============================================================================
// The GuildToolUpdateForm class
// ============================================================================
// This class handles the Guild Tool Update
//
// Usage:
// Just call this page.
// ============================================================================
class GuildToolUpdateForm
{
	// Declare variables
	var $theSkin;
	// Commandline parameters
	var $strUserName				= "";
	var $strPassword				= "";
	var $strClassFilter				= "";


	// ========================================================================
	// Constructor
	// ========================================================================
	function GuildToolUpdateForm()
	{
		// Create the Skin object
		$this->theSkin	= new Skin();
	}



	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "GuildTool Update Form";
	}



	// Main PHP code
	function Show( &$aHTTP_POST_VARS, &$aHTTP_GET_VARS, &$aHTTP_POST_FILES )
	{
		// Start the page
		$this->CreatePageStart();

		// Declare variables
		$this->strUserName		= $aHTTP_GET_VARS['UserName'];
		$this->strPassword		= $aHTTP_GET_VARS['Password'];
		$this->strClassFilter	= $aHTTP_GET_VARS['ClassFilter'];
		$strFileName			= $aHTTP_POST_VARS['editFileName'];
		$strImportFilename		= "./uploads/" . $aHTTP_POST_FILES['editFileName']['name'];
			// Check boxes
		$bImport				= $aHTTP_POST_VARS['cbImport'];
		$bCancel				= $aHTTP_POST_VARS['cbCancel'];

		// Check if the user cancelled the import
		if( ( isset( $bCancel ) ) &&
			( $bCancel == "true" ) )
		{
			// redirect the user back to page he clicked modify on
			echo '<meta http-equiv="Refresh" content="0; url=form.php?FormName=Characters&UserName=' . $this->strUserName . '&Password=' . $this->strPassword . '&ClassFilter=' . $this->strClassFilter . '">';
		}
		// Only Administrators can do a guild update
		else if( !IsAdministrator( $this->strUserName ) )
		{
			// Show Error
			print( "	<center><font size=+2 color=\"" . $this->theSkin->strErrorColor . "\">\n" );
			print( "	  You don't the necesary permissions to access the guildtool update page... <br />\n" );
			print( "	  You will be logged out and returned to the main page!\n" );
			print( "	</font></center>\n\n" );
	
			// Show main page
			echo '<meta http-equiv="Refresh" content="5; url=form.php?FormName=Characters&UserName=&Password="; target=Body>';    
			// Abort page
			exit;
		}
		// If no (correct) file was selected, show the file selection form
		else if( $aHTTP_POST_FILES['editFileName']['error'] != 0 )
		{
			// Determin the error info
			if( $aHTTP_POST_FILES['editFileName']['error'] == 1 )
			{
				$strErrorInfo	= "The uploaded file exceeds the upload_max_filesize directive in php.ini.";
			}
			else if( $aHTTP_POST_FILES['editFileName']['error'] == 2 )
			{
				$strErrorInfo	= "The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form.";
			}
			else if( $aHTTP_POST_FILES['editFileName']['error'] == 3 )
			{
				$strErrorInfo	= "The uploaded file was only partially uploaded.";
			}
			else if( $aHTTP_POST_FILES['editFileName']['error'] == 4 )
			{
				$strErrorInfo	= "No file was uploaded.";
			}
			else
			{
				$strErrorInfo	= "Unkown error, check <a href=\"http://www.php.net/manual/en/features.file-upload.errors.php\" target=_blank>here</a> for more info";
			}
		
			// Print Error
			print( "	<strong><center>\n" );
			print( "	  <font size=\"+2\" color=\"" . $this->theSkin->strErrorColor . "\"><a>\n" );
			print( "        Error Code " . $aHTTP_POST_FILES['editFileName']['error'] . " occured while importing the file:<br />" );
			print( "	    (\"" . $aHTTP_POST_FILES['editFileName']['name'] . "\")<br />\n" );
			print( "	  </a></font><br />\n" );
			print( "	  <font size=\"+1\" color=\"" . $this->theSkin->strErrorColor . "\"><a>\n" );
			print( "	    Error info:<br />\n" );
			print( "	    " . $strErrorInfo . "<br />\n" );
			print( "	  </a></font>\n" );
			print( "	</center></strong>\n" );
	
			// Abort
			exit;
		}
		else if( ( $aHTTP_POST_FILES['editFileName']['name'] == "" ) ||
				 ( ( $aHTTP_POST_FILES['editFileName']['type'] != "text/plain" ) &&
				   ( $aHTTP_POST_FILES['editFileName']['type'] != "text/misc" ) ) )
		{
			// Show the select guilddump form
			$this->ShowSelectFileNameForm();

			// Show error message if a file was selected, but the type is not of "text/plain" or "text/misc"
			if( ( $aHTTP_POST_FILES['editFileName']['name'] != "" ) &&
				( $aHTTP_POST_FILES['editFileName']['type'] != "text/plain" ) && 
				( $aHTTP_POST_FILES['editFileName']['type'] != "text/misc" ) )
			{
				// Print Error
				print( "	<strong><center>\n" );
				print( "	  <font size=\"+2\" color=\"" . $this->theSkin->strErrorColor . "\"><a>\n" );
				print( "        ERROR: Not a valid text file selected.<br />" );
				print( "	    (\"" . $aHTTP_POST_FILES['editFileName']['name'] . "\", \"" . $aHTTP_POST_FILES['editFileName']['type'] . "\" )<br />\n" );
				print( "	  </a></font>\n" );
				print( "	</center></strong>\n" );
	
				// Abort
				exit;
			}
		}
		else
		{
			// Move the uploaded file to the EQRoster Upload dir
			if( !move_uploaded_file( $aHTTP_POST_FILES['editFileName']['tmp_name'], $strImportFilename ) )
			{
				// Use the unmoved file instead
				$strImportFilename	= $aHTTP_POST_FILES['editFileName']['tmp_name'];

				// Print Error
				print( "	<strong><center>\n" );
				print( "	  <font size=\"+1\" color=\"" . $this->theSkin->strErrorColor . "\"><a>\n" );
				print( "        WARNING: Coulnd't move uploaded file!\n" );
				print( "	    Attempting to import from default location...<br />\n" );
				print( "	  </a></font>\n" );
				print( "	</center></strong>\n" );
			}

			// Open the guild dump
			$fileGuildDump	= fopen( $strImportFilename, "r" );
			// Check if the File was opened succesfully
			if( $fileGuildDump == FALSE )
			{
				// Print Error
				print( "	<strong><center>\n" );
				print( "	  <font size=\"+2\" color=\"" . $this->theSkin->strErrorColor . "\"><a>\n" );
				print( "        ERROR: Could not open Guild Dump file! Import aborted...\n" );
				print( "	    (\"" . $strImportFilename . "\")<br />\n" );
				print( "	  </a></font>\n" );
				print( "	</center></strong>" );
				print( "	<hr />\n" );

				// Abort
				exit;
			}

			// Re-check the password, to prevent hacking
			if( CheckPassword( $this->strUserName, $this->strPassword ) == false )
			{
				// Wrong password, warn the user
				print( "	<center><font size=+2 color=\"" . $this->theSkin->strErrorColor . "\">\n" );
				print( "	  Incorrect password detected... <br />\n" );
				print( "	  You will be logged out and returned to the main page!\n" );
				print( "	</font></center>\n\n" );

				// Show main page
				echo '<meta http-equiv="Refresh" content="5; url=form.php?FormName=Characters&UserName=&Password="; target=Body>';    
				// Abort page
				exit;
			}

			// Print header
			print( "	<strong><center>\n" );
			print( "	  <font size=\"+2\" color=\"" . $this->theSkin->strOKColor . "\"><a>\n" );
			print( "	    Importing Guild Tool dump into database<br />\n" );
			print( "	    (\"" . $strImportFilename . "\")<br />\n" );
			print( "	  </a></font>\n" );
			print( "	</center></strong>" );
			print( "	<hr />\n" );

			// Start of Update table
			echo '
			<!-- Start of Update table -->
			<div id="Header">
			<center>
			<table width="60%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="10%"></td>
				<td width= "8%"><font color=WHITE><b>UserID</b></font></td>
				<td width= "8%"><font color=WHITE><b>CharID</b></font></td>
				<td width="14%"><font color=WHITE><b>Name</b></font></td>
				<td width="20%"><font color=WHITE><b>Status</b></font></td>
			  </tr>
			</table>
			</center>
			</div>
			<hr />
			<div id="Body">
			<center>
			<table width="60%" border="0" cellpadding="0" cellspacing="0">
			';

	
			// Declare variables 
			$strResultCode			= "";
			$nNrOfOldActiveMembers	= 0;
			$nNrCreated				= 0;
			$nNrCreateFailed		= 0;
			$nNrUpdated				= 0;
			$nNrUpdateFailed		= 0;
			$bInitialUpdate			= false;

			// Open the log file
			$strLogFilename	= $strImportFilename . ".log";
			$fileImportLog	= fopen( $strLogFilename, "w" );

			// Get the nr of active members
			$nNrOfOldActiveMembers	= $this->GetNrOfActiveMembers();
			// Check if this is the initial update
			if( $nNrOfOldActiveMembers == 0 )
			{
				$bInitialUpdate		= true;
			}


			// Mark all members as OldMember (the char update will remove this check)
			if( $aHTTP_POST_FILES['editFileName']['size'] > 0 )
			{
				$this->SetAllMembersToOld();
			}

			// Read each line in the guild dump file
			while( !feof( $fileGuildDump ) )
			{
				// Store the line
				$strLine		= fgets( $fileGuildDump, 4096 );

				// Store all the fields in an array
				$aFields		= explode( "	", $strLine );
	
				// Copy the fields we use into seperate variables	// Guild tool format:
				$strCharName			= $aFields[0];				// 0: Name
				$nLevel					= $aFields[1];				// 1: Level
				$strClass				= $aFields[2];				// 2: Class
				$strRank				= $aFields[3];				// 3: Rank
				$strBanker				= $aFields[4];				// 3: Banker (B)
				$strAlt					= $aFields[5];				// 3: Alt (Alt)
				$strLastOn				= $aFields[6];				// 4: Last on (MM-DD-YY)
//				$strZone				= $aFields[7];				// 5: Zone
//				$strGuildTributeStatus	= $aFields[8];				// 6: Guildtribute Status
//				$strGuildTributeAmount	= $aFields[9];				// 7: Guildtribute Amount
//				$strGuildTributeDate	= $aFields[10];				// 8: Guildtribute Date
				$strPublicNote			= $aFields[11];				// 9: Public note (contains Name main and invite date)
//				$strPrivateNote			= $aFields[12];				// 10: Personal note

				// Check if the CharName is valid
				if( IsCharNameValid( $strCharName ) )
				{
					// Extract the Main name out of the Public note
					$strNameMain		= ExtractNameMainFromString( $strPublicNote );

					// Make sure the name is properly formatted
					$strNameMain		= FormatName( $strNameMain );

					// If the main name is not filled in, we asume that this user is a main
					if( ( !isset( $strNameMain ) ) ||
						( $strNameMain == "" ) )
					{
						$strNameMain	= $strCharName;
					}
					// If the main name doesn't match the char name, then we assume this is an alt
					else if( $strNameMain != $strCharName )
					{
						$strRank		= "A";
					}

					// Convert the LastOn date (MM-DD-YY) to the MySQL Date format (YYYY-MM-DD)
					if( substr( $strLastOn, 6, 2 ) < 70 )
					{
						$strLastOnDate	= "20" . substr( $strLastOn, 6, 2 ) . "-" . substr( $strLastOn, 0, 2 ) . "-" . substr( $strLastOn, 3, 2 );
					}
					else
					{
						$strLastOnDate	= "19" . substr( $strLastOn, 6, 2 ) . "-" . substr( $strLastOn, 0, 2 ) . "-" . substr( $strLastOn, 3, 2 );
					}

					// Update the character
					$strResultCode		= $this->UpdateChar( $strCharName, $nLevel, $strClass, $strRank, $strNameMain, $strLastOnDate, $bInitialUpdate, $fileImportLog );

					// Update the counters
					if( $strResultCode == "Created" )
					{
						$nNrCreated++;
					}
					else if( $strResultCode == "Create failed" )
					{
						$nNrCreateFailed++;
					}
					else if( $strResultCode == "Updated" )
					{
						$nNrUpdated++;
					}
					else if( $strResultCode == "Update failed" )
					{
						$nNrUpdateFailed++;
					}
				}
				// Check if the charname was filled in, but invalid
				else if( $strCharName != "" )
				{
					// Write the update table row
					echo '
					  <tr>
						<td width="10%"></td>
						<td width= "2%"></td>
						<td width= "6%"><font color="' . $this->theSkin->strErrorColor . '">0</font></td>
						<td width= "2%"></td>
						<td width= "6%"><font color="' . $this->theSkin->strErrorColor . '">0</font></td>
						<td width="14%"><font color="' . $this->theSkin->strErrorColor . '">' . $strCharName	. '</font></td>
						<td width="20%"><font color="' . $this->theSkin->strErrorColor . '">Skipped (Invalid CharName)</font></td>
					  </tr>
					';
	
					// Log the update
					fwrite( $fileImportLog, "0;0;" . $strCharName . ";Skipped (Invalid CharName);\n" );
				}
			}

			// Close the log file
			fclose( $fileImportLog );

			// Close the guild dump
			fclose( $fileGuildDump );

			// Check for inactive members, and mark them as Inactive
			$this->UpdateMemberStatuses();

			// Get the new nr of active members
			$nNrOfNewActiveMembers	= $this->GetNrOfActiveMembers();

			// End of Update table
			echo '
			</table>
			</center>
			</div>
			<hr />
			<!-- End of Update table -->
			';

			// Print the summary
			print( "	<div id=\"Footer\">\n" );
			print( "	<strong><center>\n" );
			print( "	  <font size=\"+2\" color=\"" . $this->theSkin->strOKColor . "\"><a>\n" );
			print( "	    Import succeeded<br /><br />\n" );
			print( "	  </a></font>\n" );
			print( "\n" );
			print( "      <table width=\"30%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\"> \n" );
			print( "        <tr> \n" );
			print( "          <td width=\"20%\">Nr of new members: </td> \n" );
			print( "          <td width=\"10%\"><font color=\"" . $this->theSkin->strOKColor . "\">" . $nNrCreated . "</font></td> \n" );
			print( "        </tr> \n" );
			print( "        <tr> \n" );
			print( "          <td width=\"20%\">Nr of updated members: </td> \n" );
			print( "          <td width=\"10%\"><font color=\"" . $this->theSkin->strStatusColor . "\">" . $nNrUpdated . "</font></td> \n" );
			print( "        </tr> \n" );
			print( "        <tr> \n" );
			print( "          <td width=\"20%\">Nr of deleted members: </td> \n" );
			print( "          <td width=\"10%\"><font color=\"" . $this->theSkin->strErrorColor . "\">" . ($nNrOfOldActiveMembers - ($nNrOfNewActiveMembers - $nNrCreated)) . "</font></td> \n" );
			print( "        </tr> \n" );
			print( "      </table> \n" );

			// Print the errors (if any)
			if( ( $nNrCreateFailed > 0 ) ||
				( $nNrUpdateFailed > 0 ) )
			{
				print( "      <table width=\"30%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\"> \n" );
				print( "        <tr> \n" );
				print( "          <td width=\"20%\"><font color=\"" . $this->theSkin->strErrorColor . "\">Failed to create: </font></td> \n" );
				print( "          <td width=\"10%\"><font color=\"" . $this->theSkin->strErrorColor . "\">" . $nNrCreateFailed . "</font></td> \n" );
				print( "        </tr> \n" );
				print( "        <tr> \n" );
				print( "          <td width=\"20%\"><font color=\"" . $this->theSkin->strErrorColor . "\">Failed to update: </font></td> \n" );
				print( "          <td width=\"10%\"><font color=\"" . $this->theSkin->strErrorColor . "\">" . $nNrUpdateFailed . "</font></td> \n" );
				print( "        </tr> \n" );
				print( "      </table> \n" );
			}

			// Print the link back to the character overview
			print( "      <br />\n\n" );
			print( "	  Click <a href=\"form.php?FormName=Characters&UserName=" . $this->strUserName . "&Password=" . $this->strPassword . "&ClassFilter=" . $this->strClassFilter . "\"	OnMouseOver=\"window.status='Return to Characters overview';return true\"	OnMouseOut=\"window.status=''\"	target=Body>here</a> to return to the roster<br />\n" );
			print( "	</center></strong>" );
			print( "	</div>\n" );
			print( "    <br /><br />\n\n" );
		}

		// End the page
		$this->CreatePageEnd();
	}





	// Start the HTML page
	function CreatePageStart()
	{
		echo'<html>
<head>
	<title>EverQuest Roster: Guild Tool Update</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<link rel="stylesheet" href="' . GetSkinDir() . 'roster.css" type="text/css">
</head>

<body>


';
	}



	// End the HTML page
	function CreatePageEnd()
	{
		echo '</body>
</html>
';
	}



	// Retrieve the number of active members
	function GetNrOfActiveMembers()
	{
		// Declare variables
		$nNrOfActiveMembers	= 0;
		$strSelectQuery		= "SELECT Count(*) FROM Characters WHERE OldMember = 0";

		// Connect to the database
		$nLinkID	= DBConnect();

		// Retrieve the nr of active members
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		$aResult	= mysql_fetch_row( $nResult );
		// Store the nr of active members
		if( isset( $aResult[0] ) )
		{
			$nNrOfActiveMembers	= $aResult[0];
		}

		// Close the connection
		DBDisconnect( $nLinkID );

		return $nNrOfActiveMembers;
	}



	// Mark all characters as "OldMember"
	// All still existing members will have this mark removed after the update
	function SetAllMembersToOld()
	{
		// Declare variables
		$strResult		= "UPDATE_FAILED";
		$strUpdateQuery	= "UPDATE Characters SET OldMember = 1";

		// Connect to the database
		$nLinkID	= DBConnect();

		// Update the characters
		$nResult	= mysql_query( $strUpdateQuery, $nLinkID );
		// Check if the update was succesfull
		if( $nResult == 1 )
		{
			$strResult	= "RECORDS_UPDATED";
		}

		// Close the connection
		DBDisconnect( $nLinkID );

		return $strResult;
	}



	// Check for inactive members, and mark them as Inactive
	function UpdateMemberStatuses()
	{
		// Declare variables
		$strInactivateQuery			= "UPDATE Characters SET GuildStatus='Inactive' WHERE TO_DAYS( NOW() ) - TO_DAYS( LastOn  ) >  " . GetNrOfAllowedInactiveDays() . " AND (GuildStatus='Member' OR GuildStatus='Alt')";
		$strActivateMembersQuery	= "UPDATE Characters SET GuildStatus='Member'   WHERE TO_DAYS( NOW() ) - TO_DAYS( LastOn  ) <= " . GetNrOfAllowedInactiveDays() . " AND GuildStatus='Inactive' AND CharName = NameMain";
		$strActivateAltsQuery		= "UPDATE Characters SET GuildStatus='Alt'      WHERE TO_DAYS( NOW() ) - TO_DAYS( LastOn  ) <= " . GetNrOfAllowedInactiveDays() . " AND GuildStatus='Inactive' AND CharName != NameMain";

		// Connect to the database
		$nLinkID	= DBConnect();

		// Perform the update
		$nResult	= mysql_query( $strInactivateQuery, $nLinkID );
		$nResult	= mysql_query( $strActivateMembersQuery, $nLinkID );
		$nResult	= mysql_query( $strActivateAltsQuery, $nLinkID );

		// Close the connection
		DBDisconnect( $nLinkID );
	}



	// Update a character (and if the character doesn't exist, insert him/her)
	function UpdateChar( $strCharName, $nLevel, $strClass, $strRank, $strNameMain, $strLastOnDate, $bInitialUpdate, $fileImportLog )
	{
		// Declare variables
		$nUserID				= 0;
		$nCharID				= -1;
		$strGuildStatus			= "Probation";
		$strSelectUserIDQuery	= "SELECT UserID FROM Users WHERE UserName = '$strNameMain'";
		$strSelectCharIDQuery	= "SELECT CharID FROM Characters WHERE CharName = '$strCharName'";
		$strStatus				= "";
		$strStatusColor			= "";

		// Connect to the database
		$nLinkID	= DBConnect();

		// Retrieve the UserID for this user
		$nResult	= mysql_query( $strSelectUserIDQuery, $nLinkID );
		$aResult	= mysql_fetch_row( $nResult );
		// Store the UserID
		if( isset( $aResult[0] ) )
		{
			$nUserID	= $aResult[0];
		}

		// Retrieve the CharID for this user
		$nResult	= mysql_query( $strSelectCharIDQuery, $nLinkID );
		$aResult	= mysql_fetch_row( $nResult );
		// Store the CharID
		if( isset( $aResult[0] ) )
		{
			$nCharID	= $aResult[0];
		}

		// Check if the char already exists
		if( $nCharID >= 0 )
		{
			// Define the query
			$strUpdateQuery		=	"UPDATE Characters \n" .
							 		"SET    Level     = $nLevel, \n" .
							 		"       LastOn    = '$strLastOnDate', \n";

			// Check if a UserID was found
			if( $nUserID > 0 )
			{
				$strUpdateQuery	.=	"       UserID    = $nUserID, \n";
			}

			// Check if the NameMain is set
			if( $strNameMain != "" )
			{
				$strUpdateQuery	.=	"       NameMain  = '$strNameMain', \n";
			}

			// Check if it's the GuildLeader
			if( $strRank == "L" )
			{
				$strUpdateQuery	.=	"       GuildStatus = 'Leader',";
			}
			// Check if it's an Officer
			else if( $strRank == "O" )
			{
				$strUpdateQuery	.=	"       GuildStatus = 'Officer',";
			}

			// Finish the query
			$strUpdateQuery		.=	"       OldMember = 0 \n" .
									"WHERE  CharID = $nCharID";

			// Update this char
			$nResult		= mysql_query( $strUpdateQuery, $nLinkID );
			// Check if the update was succesfull
			if( $nResult == 1 )
			{
				// Set Status
				$strStatus				= "Updated";
				$strStatusColor			= $this->theSkin->strStatusColor;
			}
			else
			{
				// Set Status
				$strStatus				= "Update failed (" . mysql_error() . ")";
				$strStatusColor			= $this->theSkin->strErrorColor;
			}
		}
		else
		{
			// Determine the GuildStatus
			// Check if the CharName and NameMain are the same
			if( $strCharName == $strNameMain )
			{
				// Check if this is the initial update
				if( $bInitialUpdate == true )
				{
					// If so, it's a normal member
					$strGuildStatus	= "Member";
				}
				else
				{
					// If not, it's a probationary member
					$strGuildStatus	= "Probation";
				}
			}
			// Check if it's the GuildLeader
			else if( $strRank == "L" )
			{
				$strGuildStatus	= "Leader";
			}
			// Check if it's an Officer
			else if( $strRank == "O" )
			{
				$strGuildStatus	= "Officer";
			}
			// otherwise this is an Alt
			else
			{
				$strGuildStatus	= "Alt";
			}

			// Define the query
			$strInsertQuery		= "INSERT INTO Characters \n" .
								  "(UserID, CharName, NameMain, Level, Class, GuildStatus, Race, Gender, Religion, LastOn ) \n" .
								  "VALUES ($nUserID, '$strCharName', '$strNameMain', '$nLevel', '$strClass', '$strGuildStatus', '', '', '', '$strLastOnDate' )";
			// Insert the character
			$nResult			= mysql_query( $strInsertQuery, $nLinkID );
			// Check if the insert was succesfull
			if( $nResult == 1 )
			{
				// Set Status
				$strStatus		= "Created";
				$strStatusColor	= $this->theSkin->strOKColor;

				// Retrieve the CharID for this user
				$nResult		= mysql_query( $strSelectCharIDQuery, $nLinkID );
				$aResult		= mysql_fetch_row( $nResult );
				// Store the CharID
				if( isset( $aResult[0] ) )
				{
					$nCharID	= $aResult[0];
				}
			}
			else
			{
				// Set Status
				$strStatus		= "Create failed (" . mysql_error() . ")";
				$strStatusColor	= $this->theSkin->strErrorColor;
			}
		}

		// Close the connection
		DBDisconnect( $nLinkID );

		// Write the update table row
		echo '
		  <tr>
			<td width="10%"></td>
			<td width= "2%"></td>
			<td width= "6%"><font color="' . $strStatusColor . '">' . $nUserID		. '</font></td>
			<td width= "2%"></td>
			<td width= "6%"><font color="' . $strStatusColor . '">' . $nCharID		. '</font></td>
			<td width="14%"><font color="' . $strStatusColor . '">' . $strCharName	. '</font></td>
			<td width="20%"><font color="' . $strStatusColor . '">' . $strStatus	. '</font></td>
		  </tr>
		';

		// Log the update
		fwrite( $fileImportLog, $nUserID . ";" . $nCharID .  ";" . $strCharName .  ";" . $strStatus . ";\n" );

		// Return the status result
		return $strStatus;
	}



	// Show the Form to select the guilddump filename
	function ShowSelectFileNameForm()
	{
		// Create the page
		echo '
	<!-- JavaScript block has been added here instead of in the header on purpose -->
	<script language="JavaScript">

	<!-- Perform the Import -->
	function PerformImport()
	{
		// Set the Import checkbox on
		document.formGuildToolUpdate.cbImport.value		= true;
		document.formGuildToolUpdate.cbImport.checked	= true;

		// Submit the form
		document.formGuildToolUpdate.submit();

		// Done
		return true;
	};

	<!-- Cancel -->
	function CancelImport()
	{
		// Set the Cancel checkbox on
		document.formGuildToolUpdate.cbCancel.value		= true;
		document.formGuildToolUpdate.cbCancel.checked	= true;

		// Submit the form
		document.formGuildToolUpdate.submit();

		// Done
		return true;
	};
	</script>


	<!-- Start of GuildTool Update -->
	<form name="formGuildToolUpdate" enctype="multipart/form-data" method="post" action="form_guildtool_update.php?UserName=' . $this->strUserName . '&Password=' . $this->strPassword . '&ClassFilter=' . $this->strClassFilter . '&' . $strAction . '">
	  <div id="Body" align="center"> 
	  <p><strong><font color="' . $this->theSkin->strBodyFontColor . '" size="+3"><em>GuildTool Update</em></font></strong></p>
		<p>&nbsp;</p>
		<table width="50%" border="0">
		  <tr> 
			<td width="50%" align="center">Filename of latest GuildDump:</td>
		  </tr>
		  <tr> 
			<td width="50%" align="center">
				<input type="hidden" name="MAX_FILE_SIZE" value="100000" />
				<input name="editFileName" type="file" accept="text/plain" />
			</td>
		  </tr>
		</table>
		<br />
		<p>
		  <input name="pbCancel" type="submit" id="pbCancel" value="Cancel" onclick="CancelImport();" />
		  <input name="pbImport" type="submit" id="pbImport" value="Import" onclick="PerformImport();" />
		</p>
		<!-- Hidden field to store CancelUpdate status -->
	    <input name="cbCancel" type="hidden" id="cbCancel" value="false" />
		<!-- Hidden field to store PerformUpdate status -->
	    <input name="cbImport" type="hidden" id="cbImport" value="false" />
	  </div>
	</form>';
		print( "\n\n\n" );
	}
}

?>
