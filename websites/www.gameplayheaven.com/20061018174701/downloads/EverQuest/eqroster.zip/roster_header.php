<?php
// Includes
require_once( './config.php' );


// Main PHP code
{
	// Show the page
	echo'<html>
<head>
	<meta http-equiv="Refresh" content="0; url=\'' . GetSkinDir() . 'roster_header.html\'">
</head>

<body>
</body>
</html>';
}

?>
