<?php
// Includes
require_once( './includes/form.inc' );

// Main PHP code
{
	// Declare variables
	$strFormName		= $_GET['FormName'];
	$strUserName		= $_GET['UserName'];
	$strPassword		= $_GET['Password'];
	$strSortOrder		= $_GET['SortOrder'];
	$strSortDirection	= $_GET['SortDirection'];
	$strShowAlts		= $_GET['ShowAlts'];
	$strClassFilter		= $_GET['ClassFilter'];

	// Create the List object
	$theForm			= new $strFormName;

	// Start the HTML page
	CreateHTMLStart( ($theForm->GetTitle() . " Title"), $theForm->bShowVerticalScrollbars );

	// Show the header
	$theForm->ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter );

	// End the HTML page
	CreateHTMLEnd();
}

?>
