<?php
// Includes
require_once( './includes/form.inc' );
require_once( './includes/functions.inc' );


// Main PHP code
{
	// PHP5 with register_long_arrays off?
	if (!isset($HTTP_POST_VARS) && isset($_POST))
	{
		$HTTP_POST_VARS		= $_POST;
		$HTTP_GET_VARS		= $_GET;
	}

	// Declare variables
	$strCookieAction	= $_GET['CookieAction'];
	$strFormName		= $_GET['FormName'];

	// Create the Form object
	$theForm			= new $strFormName;

	// Start the HTML page
	CreateHTMLStart( ($theForm->GetTitle() . " Body"), $theForm->bShowVerticalScrollbars );

	// Show the Form body
	$theForm->ShowBody( $HTTP_GET_VARS );

	// End the HTML page
	CreateHTMLEnd();
}

?>
