<?php
// Includes
require_once( './config.php' );
require_once( './includes/class.character.inc' );
require_once( './includes/class.eqplayers.inc' );
require_once( './includes/class.magelo.inc' );
require_once( './includes/functions.inc' );
require_once( GetSkinDir() . 'class.skin.inc' );


// Defines
// Import modes
define( "IMPORTMODE_NONE",		0 );
define( "IMPORTMODE_MAGELO",	1 );
define( "IMPORTMODE_EQPLAYERS",	2 );


// Main PHP code
{
	// PHP5 with register_long_arrays off?
	if (!isset($HTTP_POST_VARS) && isset($_POST))
	{
		$HTTP_POST_VARS		= $_POST;
		$HTTP_GET_VARS		= $_GET;
	}

	// Create the CharacterModify form
	$theCharacterModifyForm	= new CharacterModifyForm();
	// Show the form
	$theCharacterModifyForm->Show( $HTTP_POST_VARS, $HTTP_GET_VARS );
}



// ============================================================================
// The CharacterModifyForm class
// ============================================================================
// This class handles the CharacterModifyForm
//
// Usage:
// Just call this page.
// ============================================================================
class CharacterModifyForm
{
	// Declare variables
	var $theSkin;
	var $theCharacter;
	// Commandline parameters
	var $strUserName				= "";
	var $strPassword				= "";
	var $strPreviousForm			= "";
	var $strSortOrder				= "";
	var $strSortDirection			= "";
	var $strShowAlts				= "";
	var $strClassFilter				= "";
	// Settings
	var $bValidated					= false;
	var $nImportMode				= IMPORTMODE_NONE;
	var $bShowStatistics			= false;
	var $bShowTradeskills			= false;
	var $bShowKeysProgression		= false;
	var $bShowPoPProgression		= false;
	var $bShowGoDProgression		= false;
	var $bShowOoW_CoAProgression	= false;
	var $bShowDoNProgression		= false;
	var $bDoNProgressionGood		= false;
	var $bShowDoDProgression		= false;

	
	// ========================================================================
	// Constructor
	// ========================================================================
	function CharacterModifyForm()
	{
		// Create the Character storage container
		$this->theCharacter	= new Character();
		// Create the Skin object
		$this->theSkin		= new Skin();
	}



	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "Character Modify";
	}



	// Main PHP code
	function Show( &$aHTTP_POST_VARS, &$aHTTP_GET_VARS )
	{
		// Start the page
		$this->CreatePageStart();

		// Store all character info in the character container
		$this->StoreCharacterData( $aHTTP_POST_VARS );

		// Retrieve parameters
		$this->strUserName				= $aHTTP_GET_VARS['UserName'];
		$this->strPassword				= $aHTTP_GET_VARS['Password'];
		$this->theCharacter->strCharName= $aHTTP_GET_VARS['CharName'];
		$this->strPreviousForm			= $aHTTP_GET_VARS['PreviousForm'];
		$this->strSortOrder				= $aHTTP_GET_VARS['SortOrder'];
		$this->strSortDirection			= $aHTTP_GET_VARS['SortDirection'];
		$this->strShowAlts				= $aHTTP_GET_VARS['ShowAlts'];
		$this->strClassFilter			= $aHTTP_GET_VARS['ClassFilter'];
			// Validation tag
		$this->bValidated				= $aHTTP_POST_VARS['cbValidated'];
			// CancelModify tag
		$this->bCancelModify			= $aHTTP_POST_VARS['cbCancelModify'];
			// Import mode
		$this->nImportMode				= $aHTTP_POST_VARS['editImportMode'];
			// Show Progression tags
		$this->bShowStatistics			= $aHTTP_POST_VARS['cbDisplayStatistics'];
		$this->bShowTradeskills			= $aHTTP_POST_VARS['cbDisplayTradeskills'];
		$this->bShowKeysProgression		= $aHTTP_POST_VARS['cbDisplayKeysProgression'];
		$this->bShowPoPProgression		= $aHTTP_POST_VARS['cbDisplayPoPProgression'];
		$this->bShowGoDProgression		= $aHTTP_POST_VARS['cbDisplayGoDProgression'];
		$this->bShowOoW_CoAProgression	= $aHTTP_POST_VARS['cbDisplayOoW_CoAProgression'];
		$this->bShowDoNProgression		= $aHTTP_POST_VARS['cbDisplayDoNProgression'];
		$this->bShowDoDProgression		= $aHTTP_POST_VARS['cbDisplayDoDProgression'];
			// DoN Progression Good/Evil tag
		$strDoNProgression				= $aHTTP_POST_VARS['DoN_Progression'];
		if( $strDoNProgression == "Good" )
		{
			$this->bDoNProgressionGood	= true;
		}
		else
		{
			$this->bDoNProgressionGood	= false;
		}
	
		// Default Progression tags
		if( !isset( $this->theCharacter->nLevel ) )
		{
			$this->bShowStatistics			= false;
			$this->bShowTradeskills			= false;
			$this->bShowKeysProgression		= false;
			$this->bShowPoPProgression		= false;
			$this->bShowGoDProgression		= false;
			$this->bShowOoW_CoAProgression	= false;
			$this->bShowDoNProgression		= false;
			$this->bDoNProgressionGood		= true;
			$this->bShowDoDProgression		= false;
			
			// Show the progression of the page the user clicked edit on
			if( ( $this->strPreviousForm == "Characters" ) ||
				( $this->strPreviousForm == "Character_Statistics" ) )	{	$this->bShowStatistics			= true;	}
			if( $this->strPreviousForm == "TradeSkills" )				{	$this->bShowTradeskills			= true;	}
			if( ( $this->strPreviousForm == "Keys" ) ||
				( $this->strPreviousForm == "SSRA_Keys" ) ||
				( $this->strPreviousForm == "Veeshans_Peak_Keys" ) ||
				( $this->strPreviousForm == "Vex_Thal_Keys" )	)		{	$this->bShowKeysProgression		= true;	}
			if( ( $this->strPreviousForm == "PoP_Tier_1_Flags" ) ||
				( $this->strPreviousForm == "PoP_Tier_2_Flags" ) ||
				( $this->strPreviousForm == "PoP_Tier_3_Flags" ) ||
				( $this->strPreviousForm == "PoP_Tier_4_Flags" ) || 
				( $this->strPreviousForm == "PoS_Askr_Quest" ) )		{	$this->bShowPoPProgression		= true;	}
			if( $this->strPreviousForm == "GoD_Flags" )					{	$this->bShowGoDProgression		= true;	}
			if( $this->strPreviousForm == "OoW_CoA" )					{	$this->bShowOoW_CoAProgression	= true;	}
			if( $this->strPreviousForm == "DoN_Flags" )					{	$this->bShowDoNProgression		= true;	}
			if( ( $this->strPreviousForm == "DoD_Mask" ) || 
				( $this->strPreviousForm == "DoD_Spells" ) )			{	$this->bShowDoDProgression		= true;	}
		}
	
		// We can't do anything if the CharName is unkown
		if( !isset( $this->theCharacter->strCharName ) )
		{
			// Show error message
			print( "	<center><font size=+2 color=\"" . $this->theSkin->strErrorColor . "\">\n" );
			print( "	  Illegal call to Modify Character page... <br />\n" );
			print( "	  Contact the board admin!\n" );
			print( "	</font></center>\n\n" );
		}
		// Check if the user cancelled the modify
		else if( ( isset( $this->bCancelModify ) ) &&
				 ( $this->bCancelModify == "true" ) )
		{
			// redirect the user back to page he clicked modify on
			echo '<meta http-equiv="Refresh" content="0; url=form.php?FormName=' . $this->strPreviousForm . '&UserName=' . $this->strUserName . '&Password=' . $this->strPassword . '&SortOrder=' . $this->strSortOrder . '&SortDirection=' . $this->strSortDirection  . '&ShowAlts=' . $this->strShowAlts . '&ClassFilter=' . $this->strClassFilter . '">';
		}
		// Check if the page has been validated
		else if( ( isset( $this->bValidated ) ) &&
				 ( $this->bValidated == true ) )
		{
			// Re-check the password, to prevent hacking
			if( CheckPassword( $this->strUserName, $this->strPassword ) == false )
			{
				// Wrong password, warn the user
				print( "	<center><font size=+2 color=\"" . $this->theSkin->strErrorColor . "\">\n" );
				print( "	  Incorrect password detected... <br />\n" );
				print( "	  You will be logged out and returned to the main page!\n" );
				print( "	</font></center>\n\n" );
	
				// Show main page
				echo '<meta http-equiv="Refresh" content="5; url=form.php?FormName=Characters&UserName=&Password="; target=Body>';    
				// Abort page
				exit;
			}
			
			// Update the Character
			$bUpdated	= $this->theCharacter->StoreAllData();
			if( $bUpdated )
			{
				// redirect the user back to page he clicked modify on
				echo '<meta http-equiv="Refresh" content="0; url=form.php?FormName=' . $this->strPreviousForm . '&UserName=' . $this->strUserName . '&Password=' . $this->strPassword . '&SortOrder=' . $this->strSortOrder . '&SortDirection=' . $this->strSortDirection  . '&ShowAlts=' . $this->strShowAlts . '&ClassFilter=' . $this->strClassFilter . '">';
			}
		}
		// If we're not importing, retrieve all the Character data from the tables
		else
		{
			if( $this->nImportMode == IMPORTMODE_NONE )
			{
				// Retrieve all Character data from the tables
				$this->theCharacter->GetAllDataFromDatabase();
			}
			// Show the Modify Character page
			$this->ShowModifyCharacterPage();
		}

		// End the page
		$this->CreatePageEnd();
	}



	// Show the header
	function CreatePageStart()
	{
		echo'<html>
<head>
	<title>EverQuest Roster: Modify Character</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<link rel="stylesheet" type="text/css" href="' . GetSkinDir() . 'roster.css">
	<style>
		body
		{
			height:							101%;
		}

		div #Statistics
		{
			margin:		0px 0px 0px 0px;
			display:	none;
		}

		div #Tradeskills
		{
			margin:		0px 0px 0px 0px;
			display:	none;
		}

		div #Keys_Progression
		{
			margin:		0px 0px 0px 0px;
			display:	none;
		}

		div #PoP_Progression
		{
			margin:		0px 0px 0px 0px;
			display:	none;
		}

		div #GoD_Progression
		{
			margin:		0px 0px 0px 0px;
			display:	none;
		}

		div #OoW_CoA_Progression
		{
			margin:		0px 0px 0px 0px;
			display:	none;
		}

		div #DoN_Progression
		{
			margin:		0px 0px 0px 0px;
			display:	none;
		}

		div #DoN_Progression_Good
		{
			margin:		0px 0px 0px 0px;
			display:	none;
		}

		div #DoN_Progression_Evil
		{
			margin:		0px 0px 0px 0px;
			display:	none;
		}

		div #DoD_Progression
		{
			margin:		0px 0px 0px 0px;
			display:	none;
		}
	</style>
</head>

<body>
	<p>&nbsp;</p>


';
	}



	// End the HTML page
	function CreatePageEnd()
	{
		echo '</body>
</html>
';
	}



	// Store all character data in the character container
	function StoreCharacterData( &$aHTTP_POST_VARS )
	{
		// Character info
		$this->theCharacter->strLastName						= $aHTTP_POST_VARS['editLastName'];
		$this->theCharacter->strNameMain						= $aHTTP_POST_VARS['cmbNameMain'];
		$this->theCharacter->strGuildStatus						= $aHTTP_POST_VARS['cmbGuildStatus'];
		$this->theCharacter->strClass							= $aHTTP_POST_VARS['editClass'];
		$this->theCharacter->nLevel								= $aHTTP_POST_VARS['editLevel'];
		$this->theCharacter->nAA								= $aHTTP_POST_VARS['editAA'];
		$this->theCharacter->nGLP								= $aHTTP_POST_VARS['editGLP'];
		$this->theCharacter->strRace							= $aHTTP_POST_VARS['cmbRace'];
		$this->theCharacter->strGender							= $aHTTP_POST_VARS['cmbGender'];
		$this->theCharacter->nEQPlayersCharID					= $aHTTP_POST_VARS['editEQPlayersCharID'];
		$this->theCharacter->nMageloNr							= $aHTTP_POST_VARS['editMageloNr'];
		$this->theCharacter->strLastOnDate						= $aHTTP_POST_VARS['editLastOnDate'];
		// Character Statistics
		$this->theCharacter->nHP								= $aHTTP_POST_VARS['editHP'];
		$this->theCharacter->nMana								= $aHTTP_POST_VARS['editMana'];
		$this->theCharacter->nEndurance							= $aHTTP_POST_VARS['editEndurance'];
		$this->theCharacter->nAC								= $aHTTP_POST_VARS['editAC'];
		$this->theCharacter->nFT								= $aHTTP_POST_VARS['editFT'];
		$this->theCharacter->nRegen								= $aHTTP_POST_VARS['editRegen'];
		$this->theCharacter->nAtk								= $aHTTP_POST_VARS['editAtk'];
		$this->theCharacter->nStr								= $aHTTP_POST_VARS['editStr'];
		$this->theCharacter->nSta								= $aHTTP_POST_VARS['editSta'];
		$this->theCharacter->nAgi								= $aHTTP_POST_VARS['editAgi'];
		$this->theCharacter->nDex								= $aHTTP_POST_VARS['editDex'];
		$this->theCharacter->nWis								= $aHTTP_POST_VARS['editWis'];
		$this->theCharacter->nInt								= $aHTTP_POST_VARS['editInt'];
		$this->theCharacter->nCha								= $aHTTP_POST_VARS['editCha'];
		$this->theCharacter->nPR								= $aHTTP_POST_VARS['editPR'];
		$this->theCharacter->nMR								= $aHTTP_POST_VARS['editMR'];
		$this->theCharacter->nDR								= $aHTTP_POST_VARS['editDR'];
		$this->theCharacter->nFR								= $aHTTP_POST_VARS['editFR'];
		$this->theCharacter->nCR								= $aHTTP_POST_VARS['editCR'];
		// DoD Spells
		$this->theCharacter->nA_Rogues_Trust					= $aHTTP_POST_VARS['cbA_Rogues_Trust'];
		$this->theCharacter->nScouting_the_City					= $aHTTP_POST_VARS['cbScouting_the_City'];
		$this->theCharacter->nBuilding_the_Disguise				= $aHTTP_POST_VARS['cbBuilding_the_Disguise'];
		$this->theCharacter->nThe_Search_for_Illsuras			= $aHTTP_POST_VARS['cbThe_Search_for_Illsuras'];
		$this->theCharacter->nThe_Rage_of_Kelliad				= $aHTTP_POST_VARS['cbThe_Rage_of_Kelliad'];
		$this->theCharacter->nThe_Lost_Notebook					= $aHTTP_POST_VARS['cbThe_Lost_Notebook'];
		$this->theCharacter->nCavern_Botany						= $aHTTP_POST_VARS['cbCavern_Botany'];
		$this->theCharacter->nThe_Search_for_Clues				= $aHTTP_POST_VARS['cbThe_Search_for_Clues'];
		$this->theCharacter->nRescue_Cicero						= $aHTTP_POST_VARS['cbRescue_Cicero'];
		$this->theCharacter->nPreemptive_Strike					= $aHTTP_POST_VARS['cbPreemptive_Strike'];
		$this->theCharacter->nPraetorian_Guard					= $aHTTP_POST_VARS['cbPraetorian_Guard'];
		$this->theCharacter->nThe_Fall_of_Illsalin				= $aHTTP_POST_VARS['cbThe_Fall_of_Illsalin'];
		$this->theCharacter->nFlights_of_the_Seeker				= $aHTTP_POST_VARS['cbFlights_of_the_Seeker'];
		$this->theCharacter->nInto_the_Shadows					= $aHTTP_POST_VARS['cbInto_the_Shadows'];
		$this->theCharacter->nFreeing_an_Elder					= $aHTTP_POST_VARS['cbFreeing_an_Elder'];
		$this->theCharacter->nOrb_of_Subversion					= $aHTTP_POST_VARS['cbOrb_of_Subversion'];
		$this->theCharacter->nA_Plea_for_Help					= $aHTTP_POST_VARS['cbA_Plea_for_Help'];
		$this->theCharacter->nTrailing_Longshadow				= $aHTTP_POST_VARS['cbTrailing_Longshadow'];
		$this->theCharacter->nConfronting_a_Traitor				= $aHTTP_POST_VARS['cbConfronting_a_Traitor'];
		$this->theCharacter->nThe_Search_for_Coral				= $aHTTP_POST_VARS['cbThe_Search_for_Coral'];
		$this->theCharacter->nLearning_the_Power				= $aHTTP_POST_VARS['cbLearning_the_Power'];
		$this->theCharacter->nDiscover_the_Secret				= $aHTTP_POST_VARS['cbDiscover_the_Secret'];
		$this->theCharacter->nTaking_Control					= $aHTTP_POST_VARS['cbTaking_Control'];
		$this->theCharacter->nThe_Mines							= $aHTTP_POST_VARS['cbThe_Mines'];
		$this->theCharacter->nLost_Caverns						= $aHTTP_POST_VARS['cbLost_Caverns'];
		$this->theCharacter->nThe_Hive							= $aHTTP_POST_VARS['cbThe_Hive'];
		$this->theCharacter->nThe_Korlach						= $aHTTP_POST_VARS['cbThe_Korlach'];
		$this->theCharacter->nThe_Rescue						= $aHTTP_POST_VARS['cbThe_Rescue'];
		// DoN Flags
		$this->theCharacter->nT1_Create_an_Antidote				= $aHTTP_POST_VARS['cbT1_Create_an_Antidote'];
		$this->theCharacter->nT1_Greed_of_the_Goblins			= $aHTTP_POST_VARS['cbT1_Greed_of_the_Goblins'];
		$this->theCharacter->nT1_Burning_Arrows					= $aHTTP_POST_VARS['cbT1_Burning_Arrows'];
		$this->theCharacter->nT1_Children_of_Gimblax			= $aHTTP_POST_VARS['cbT1_Children_of_Gimblax'];
		$this->theCharacter->nT2_Defend_the_Kirin_Contact		= $aHTTP_POST_VARS['cbT2_Defend_the_Kirin_Contact'];
		$this->theCharacter->nT2_Recover_the_Lost_Map			= $aHTTP_POST_VARS['cbT2_Recover_the_Lost_Map'];
		$this->theCharacter->nT2_Turn_the_Tides_of_the_Sand		= $aHTTP_POST_VARS['cbT2_Turn_the_Tides_of_the_Sand'];
		$this->theCharacter->nT2_Sickness_of_the_Spirit			= $aHTTP_POST_VARS['cbT2_Sickness_of_the_Spirit'];
		$this->theCharacter->nT2_Calling_Emoush					= $aHTTP_POST_VARS['cbT2_Calling_Emoush'];
		$this->theCharacter->nT3_Protect_the_Waters				= $aHTTP_POST_VARS['cbT3_Protect_the_Waters'];
		$this->theCharacter->nT3_Snowfoots_Revenge				= $aHTTP_POST_VARS['cbT3_Snowfoots_Revenge'];
		$this->theCharacter->nT3_The_Sacred_Scrolls				= $aHTTP_POST_VARS['cbT3_The_Sacred_Scrolls'];
		$this->theCharacter->nT3_History_of_the_Isle			= $aHTTP_POST_VARS['cbT3_History_of_the_Isle'];
		$this->theCharacter->nT3_Trial_of_Perserverance			= $aHTTP_POST_VARS['cbT3_Trial_of_Perserverance'];
		$this->theCharacter->nT3_Volkaras_Bite					= $aHTTP_POST_VARS['cbT3_Volkaras_Bite'];
		$this->theCharacter->nT4_Goblin_Dojo					= $aHTTP_POST_VARS['cbT4_Goblin_Dojo'];
		$this->theCharacter->nT4_Guardian_of_the_Sands			= $aHTTP_POST_VARS['cbT4_Guardian_of_the_Sands'];
		$this->theCharacter->nT4_An_End_to_the_Storms			= $aHTTP_POST_VARS['cbT4_An_End_to_the_Storms'];
		$this->theCharacter->nT5_Origins_of_the_Curse			= $aHTTP_POST_VARS['cbT5_Origins_of_the_Curse'];
		$this->theCharacter->nT5_The_Curse_of_JuRek				= $aHTTP_POST_VARS['cbT5_The_Curse_of_JuRek'];
		$this->theCharacter->nT5_In_the_Shadows					= $aHTTP_POST_VARS['cbT5_In_the_Shadows'];
		// GoD Flags
		$this->theCharacter->nPurifying_Plant					= $aHTTP_POST_VARS['cbPurifying_Plant'];
		$this->theCharacter->nEmanating_Furnace					= $aHTTP_POST_VARS['cbEmanating_Furnace'];
		$this->theCharacter->nLair_of_Trapped_Ones				= $aHTTP_POST_VARS['cbLair_of_Trapped_Ones'];
		$this->theCharacter->nPool_of_Sludge					= $aHTTP_POST_VARS['cbPool_of_Sludge'];
		$this->theCharacter->nSmith_Rondo						= $aHTTP_POST_VARS['cbSmith_Rondo'];
		$this->theCharacter->nVxed								= $aHTTP_POST_VARS['cbVxed'];
		$this->theCharacter->nTipt								= $aHTTP_POST_VARS['cbTipt'];
		$this->theCharacter->nVrex_Barxt_Qurat					= $aHTTP_POST_VARS['cbVrex_Barxt_Qurat'];
		$this->theCharacter->nKeeper_of_the_Altar				= $aHTTP_POST_VARS['cbKeeper_of_the_Altar'];
		$this->theCharacter->nNoqufiel_in_Inktuta				= $aHTTP_POST_VARS['cbNoqufiel_in_Inktuta'];
		$this->theCharacter->nCynosure_Kvanjji					= $aHTTP_POST_VARS['cbCynosure_Kvanjji'];
		$this->theCharacter->nIxt_Hsek_Syat						= $aHTTP_POST_VARS['cbIxt_Hsek_Syat'];
		$this->theCharacter->nHigh_Priest_Nkosi_Bakari			= $aHTTP_POST_VARS['cbHigh_Priest_Nkosi_Bakari'];
		$this->theCharacter->nZunMuram_Tkarish_Zyk				= $aHTTP_POST_VARS['cbZunMuram_Tkarish_Zyk'];
		// Keys
		$this->theCharacter->nBoT_Tower_Key						= $aHTTP_POST_VARS['cbBoT_Tower_Key'];
		$this->theCharacter->nHowling_Stones_Key				= $aHTTP_POST_VARS['cbHowling_Stones_Key'];
		$this->theCharacter->nSebilis_Key						= $aHTTP_POST_VARS['cbSebilis_Key'];
		$this->theCharacter->nSleepers_Tomb_Key					= $aHTTP_POST_VARS['cbSleepers_Tomb_Key'];
		$this->theCharacter->nSSRA_Emperor_Key					= $aHTTP_POST_VARS['cbSSRA_Emperor_Key'];
		$this->theCharacter->nVeeshans_Peak_Key					= $aHTTP_POST_VARS['cbVeeshans_Peak_Key'];
		$this->theCharacter->nVex_Thal_Key						= $aHTTP_POST_VARS['cbVex_Thal_Key'];
		// OoW CoA
		$this->theCharacter->nMastery_of_Adaptation				= $aHTTP_POST_VARS['cbMastery_of_Adaptation'];
		$this->theCharacter->nMastery_of_Corruption				= $aHTTP_POST_VARS['cbMastery_of_Corruption'];
		$this->theCharacter->nMastery_of_Endurance				= $aHTTP_POST_VARS['cbMastery_of_Endurance'];
		$this->theCharacter->nMastery_of_Foresight				= $aHTTP_POST_VARS['cbMastery_of_Foresight'];
		$this->theCharacter->nMastery_of_Hate					= $aHTTP_POST_VARS['cbMastery_of_Hate'];
		$this->theCharacter->nMastery_of_Specialization			= $aHTTP_POST_VARS['cbMastery_of_Specialization'];
		$this->theCharacter->nSeal_Mastery_of_All				= $aHTTP_POST_VARS['cbSeal_Mastery_of_All'];
		$this->theCharacter->nSignet_Crystal_Gemmed				= $aHTTP_POST_VARS['cbSignet_Crystal_Gemmed'];
		$this->theCharacter->nSignet_Discolored					= $aHTTP_POST_VARS['cbSignet_Discolored'];
		$this->theCharacter->nSignet_Dust_Marred				= $aHTTP_POST_VARS['cbSignet_Dust_Marred'];
		$this->theCharacter->nSignet_Glimmering					= $aHTTP_POST_VARS['cbSignet_Glimmering'];
		$this->theCharacter->nSignet_Tarnished					= $aHTTP_POST_VARS['cbSignet_Tarnished'];
		$this->theCharacter->nSignet_Two_Toned					= $aHTTP_POST_VARS['cbSignet_Two_Toned'];
		$this->theCharacter->nSignet_Weather_Worn				= $aHTTP_POST_VARS['cbSignet_Weather_Worn'];
		// Pop Tier 1 Flags
		$this->theCharacter->nAny_PoJ_Trial						= $aHTTP_POST_VARS['cbAny_PoJ_Trial'];
		$this->theCharacter->nAll_PoJ_Trials					= $aHTTP_POST_VARS['cbAll_PoJ_Trials'];
		$this->theCharacter->nPoI_Xanamech						= $aHTTP_POST_VARS['cbPoI_Xanamech'];
		$this->theCharacter->nPoI_Behemoth						= $aHTTP_POST_VARS['cbPoI_Behemoth'];
		$this->theCharacter->nPoD_Grimror_Quest					= $aHTTP_POST_VARS['cbPoD_Grimror_Quest'];
		$this->theCharacter->nPoD_Grummus						= $aHTTP_POST_VARS['cbPoD_Grummus'];
		$this->theCharacter->nPoN_Hedge_Quest					= $aHTTP_POST_VARS['cbPoN_Hedge_Quest'];
		$this->theCharacter->nPoNb_Terris_Thule					= $aHTTP_POST_VARS['cbPoNb_Terris_Thule'];
		// Pop Tier 2 Flags
		$this->theCharacter->nPoS_Askr_Quest					= $aHTTP_POST_VARS['cbPoS_Askr_Quest'];
		$this->theCharacter->nPoV_Grenic_Quest					= $aHTTP_POST_VARS['cbPoV_Grenic_Quest'];
		$this->theCharacter->nPoV_AerinDar						= $aHTTP_POST_VARS['cbPoV_AerinDar'];
		$this->theCharacter->nCoD_Carprin_Event					= $aHTTP_POST_VARS['cbCoD_Carprin_Event'];
		$this->theCharacter->nCoD_Bertoxxulous					= $aHTTP_POST_VARS['cbCoD_Bertoxxulous'];
		$this->theCharacter->nPoTorment_Saryrn					= $aHTTP_POST_VARS['cbPoTorment_Saryrn'];
		$this->theCharacter->nPoS_Wembly_Quest					= $aHTTP_POST_VARS['cbPoS_Wembly_Quest'];
		// Pop Tier 3 Flags
		$this->theCharacter->nHoH_Trial1_RyddaDar				= $aHTTP_POST_VARS['cbHoH_Trial1_RyddaDar'];
		$this->theCharacter->nHoH_Trial2_Ogre					= $aHTTP_POST_VARS['cbHoH_Trial2_Ogre'];
		$this->theCharacter->nHoH_Trial3_Madmen					= $aHTTP_POST_VARS['cbHoH_Trial3_Madmen'];
		$this->theCharacter->nHoHb_Mithanial_Marr				= $aHTTP_POST_VARS['cbHoHb_Mithanial_Marr'];
		$this->theCharacter->nPoTactics_Tallon_Zek				= $aHTTP_POST_VARS['cbPoTactics_Tallon_Zek'];
		$this->theCharacter->nPoTactics_Vallon_Zek				= $aHTTP_POST_VARS['cbPoTactics_Vallon_Zek'];
		$this->theCharacter->nPoTactics_Rallos_Zek_Quest		= $aHTTP_POST_VARS['cbPoTactics_Rallos_Zek_Quest'];
		$this->theCharacter->nBoT_Rescue_Karana_Quest			= $aHTTP_POST_VARS['cbBoT_Rescue_Karana_Quest'];
		$this->theCharacter->nSolRoTower_Jiva					= $aHTTP_POST_VARS['cbSolRoTower_Jiva'];
		$this->theCharacter->nSolRoTower_Xuzl					= $aHTTP_POST_VARS['cbSolRoTower_Xuzl'];
		$this->theCharacter->nSolRoTower_Arlyxir				= $aHTTP_POST_VARS['cbSolRoTower_Arlyxir'];
		$this->theCharacter->nSolRoTower_Rizlona				= $aHTTP_POST_VARS['cbSolRoTower_Rizlona'];
		$this->theCharacter->nSolRoTower_Protector_of_Dresolik	= $aHTTP_POST_VARS['cbSolRoTower_Protector_of_Dresolik'];
		$this->theCharacter->nSolRoTower_Solusek_Ro				= $aHTTP_POST_VARS['cbSolRoTower_Solusek_Ro'];
		// Pop Tier 4 Flags
		$this->theCharacter->nPoAir_Xegony						= $aHTTP_POST_VARS['cbPoAir_Xegony'];
		$this->theCharacter->nPoFire_Fennin_Ro					= $aHTTP_POST_VARS['cbPoFire_Fennin_Ro'];
		$this->theCharacter->nPoWater_Coirnav					= $aHTTP_POST_VARS['cbPoWater_Coirnav'];
		$this->theCharacter->nPoEarthb_The_Rathe				= $aHTTP_POST_VARS['cbPoEarthb_The_Rathe'];
		$this->theCharacter->nPoTime_Time_Phased_Quintessence	= $aHTTP_POST_VARS['cbPoTime_Time_Phased_Quintessence'];
		// PoS_Askr Quest (BoT flag)
		$this->theCharacter->nHead								= $aHTTP_POST_VARS['cbHead'];
		$this->theCharacter->nBeard								= $aHTTP_POST_VARS['cbBeard'];
		$this->theCharacter->nBone								= $aHTTP_POST_VARS['cbBone'];
		$this->theCharacter->nSash								= $aHTTP_POST_VARS['cbSash'];
		$this->theCharacter->nOceanMedal						= $aHTTP_POST_VARS['cbOceanMedal'];
		$this->theCharacter->nDesertMedal						= $aHTTP_POST_VARS['cbDesertMedal'];
		$this->theCharacter->nForestMedal						= $aHTTP_POST_VARS['cbForestMedal'];
		// SSRA Emperor key
		$this->theCharacter->nTaskmasters_Pouch					= $aHTTP_POST_VARS['cbTaskmasters_Pouch'];
		$this->theCharacter->nZazuzhs_Idol						= $aHTTP_POST_VARS['cbZazuzhs_Idol'];
		$this->theCharacter->nRing								= $aHTTP_POST_VARS['cbRing'];
		$this->theCharacter->nInsignia							= $aHTTP_POST_VARS['cbInsignia'];
		// Trade Skills
		$this->theCharacter->nAlchemy							= $aHTTP_POST_VARS['editAlchemy'];
		$this->theCharacter->nBaking							= $aHTTP_POST_VARS['editBaking'];
		$this->theCharacter->nBrewing							= $aHTTP_POST_VARS['editBrewing'];
		$this->theCharacter->nFishing							= $aHTTP_POST_VARS['editFishing'];
		$this->theCharacter->nFletching							= $aHTTP_POST_VARS['editFletching'];
		$this->theCharacter->nForaging							= $aHTTP_POST_VARS['editForaging'];
		$this->theCharacter->nJewelcraft						= $aHTTP_POST_VARS['editJewelcraft'];
		$this->theCharacter->nPoison							= $aHTTP_POST_VARS['editPoison'];
		$this->theCharacter->nPottery							= $aHTTP_POST_VARS['editPottery'];
		$this->theCharacter->nResearch							= $aHTTP_POST_VARS['editResearch'];
		$this->theCharacter->nSmithing							= $aHTTP_POST_VARS['editSmithing'];
		$this->theCharacter->nTailoring							= $aHTTP_POST_VARS['editTailoring'];
		$this->theCharacter->nTinkering							= $aHTTP_POST_VARS['editTinkering'];
		// Veeshan's Peek key
		$this->theCharacter->nKylongMedal_Top					= $aHTTP_POST_VARS['cbKylongMedal_Top'];
		$this->theCharacter->nKylongMedal_Middle				= $aHTTP_POST_VARS['cbKylongMedal_Middle'];
		$this->theCharacter->nKylongMedal_Bottom				= $aHTTP_POST_VARS['cbKylongMedal_Bottom'];
		$this->theCharacter->nJarsathMedal_Top					= $aHTTP_POST_VARS['cbJarsathMedal_Top'];
		$this->theCharacter->nJarsathMedal_Middle				= $aHTTP_POST_VARS['cbJarsathMedal_Middle'];
		$this->theCharacter->nJarsathMedal_Bottom				= $aHTTP_POST_VARS['cbJarsathMedal_Bottom'];
		$this->theCharacter->nObulusMedal_Top					= $aHTTP_POST_VARS['cbObulusMedal_Top'];
		$this->theCharacter->nObulusMedal_Middle				= $aHTTP_POST_VARS['cbObulusMedal_Middle'];
		$this->theCharacter->nObulusMedal_Bottom				= $aHTTP_POST_VARS['cbObulusMedal_Bottom'];
		$this->theCharacter->nTrak_Tooth						= $aHTTP_POST_VARS['cbTrak_Tooth'];
		// Vex Thal key
		$this->theCharacter->nGlowing_Orb						= $aHTTP_POST_VARS['cbGlowing_Orb'];
		$this->theCharacter->nCelestial_Rift					= $aHTTP_POST_VARS['cbCelestial_Rift'];
		$this->theCharacter->nShard_Dat							= $aHTTP_POST_VARS['cbShard_Dat'];
		$this->theCharacter->nShard_Dax							= $aHTTP_POST_VARS['cbShard_Dax'];
		$this->theCharacter->nShard_Kel							= $aHTTP_POST_VARS['cbShard_Kel'];
		$this->theCharacter->nShard_Kelara						= $aHTTP_POST_VARS['cbShard_Kelara'];
		$this->theCharacter->nShard_Lor							= $aHTTP_POST_VARS['cbShard_Lor'];
		$this->theCharacter->nShard_Raf							= $aHTTP_POST_VARS['cbShard_Raf'];
		$this->theCharacter->nShard_Set							= $aHTTP_POST_VARS['cbShard_Set'];
		$this->theCharacter->nShard_Tak							= $aHTTP_POST_VARS['cbShard_Tak'];
		$this->theCharacter->nShard_Ved							= $aHTTP_POST_VARS['cbShard_Ved'];
		$this->theCharacter->nShard_Vin							= $aHTTP_POST_VARS['cbShard_Vin'];
	}



	// Show the Modify Character page
	function ShowModifyCharacterPage()
	{
		// Declare variables
		$strImportMagelo	= "";
		$strFooterMessage	= "";
		$bImportOK			= false;
	
		// Check if we should import the data from EQPlayers
		if( $this->nImportMode == IMPORTMODE_EQPLAYERS )
		{
			// Import the EQPlayers profile
			$bImportOK	= $this->theCharacter->ImportEQPlayersProfileExt();
			if( $bImportOK )
			{
				// Set the footer message
				$strFooterMessage	= "<br />EQPlayers profile imported...";
			}
			else
			{
				echo '<br /><br /><center><font size="+1" color="' . $this->theSkin->strErrorColor . '">' . $this->theCharacter->strClass . ' ' . $this->theCharacter->strCharName . '`s EQPlayers profile (' . $this->theCharacter->nEQPlayersCharID . ') could not be imported!</font><br /><br /><br />Click back in your browser to return to the Character Modify page.</center>';
				return;
			}
		}
		// Check if we should import the data from magelo
		if( $this->nImportMode == IMPORTMODE_MAGELO )
		{
			// Import the magelo
			$bImportOK	= $this->theCharacter->ImportMageloProfile();
			if( $bImportOK )
			{
				// Set the footer message
				$strFooterMessage	= "<br />Magelo imported...";
			}
			else
			{
				echo '<br /><br /><center><font size="+1" color="' . $this->theSkin->strErrorColor . '">' . $this->theCharacter->strClass . ' ' . $this->theCharacter->strCharName . '`s Magelo profile (' . $this->theCharacter->nMageloNr . ') could not be imported!</font><br /><br /><br />Click back in your browser to return to the Character Modify page.</center>';
				return;
			}
		}
		else
		{
			// Check if magelo nr is filled in
			if( ( isset( $this->theCharacter->nMageloNr ) ) &&
				( $this->theCharacter->nMageloNr > 0 ) )
			{
				$strImportMagelo	= '<a href="form_character_modify.php?UserName=' . $this->strUserName . '&Password=' . $this->strPassword . '&CharName=' . $this->theCharacter->strCharName . '&PreviousForm=' . $this->strPreviousForm . '&SortOrder=' . $this->strSortOrder . '&SortDirection=' . $this->strSortDirection  . '&ShowAlts=' . $this->strShowAlts . '&ClassFilter=' . $this->strClassFilter . '&Action=ImportMagelo" OnMouseOver="window.status=\'Import data from ' . $this->theCharacter->strCharName . '\\\'s magelo\';return true;"	OnMouseOut="window.status=\'\'"	target="Body" title="Import data from ' . $this->theCharacter->strCharName . '\'s magelo">' .
									  '					<img src="' . GetSkinDir() . 'images/magelo.gif" border="0" />' .
									  '					<!-- Show/Hide the image on page load -->' .
									  '					<script language="JavaScript">' .
									  '						CheckMageloNr();' .
									  '					</script>' .
									  '</a>';
			}
		}

		// Admin can edit NameMain and GuildStatus
		if( IsAdministrator( $this->strUserName ) )
		{
			$strFieldNameMain		= 	'  <tr>
				<td width="10%"><b>Name Main:</b></td>
				<td width="20%">' . $this->CreateNameMainSelect( $this->theCharacter->strNameMain, "							" ) . '</td>
				<td width="10%"></td>
				<td width= "8%"></td>
				<td width= "4%"></td>
				<td width= "4%"></td>
				<td width= "4%"></td>
				<td width="10%"></td>
				<td width= "8%"></td>
				<td width="12%"></td>
			  </tr>';
			$strFieldGuildStatus	= CreateSelectFromEnum( "Characters", "GuildStatus", $this->theCharacter->strGuildStatus, "							" );
		}
		else
		{
			$strFieldNameMain		= '<input type="hidden"	name="cmbNameMain"	value="' . $this->theCharacter->strNameMain . '">';
			$strFieldGuildStatus	= $this->theCharacter->strGuildStatus . '<input type="hidden"	name="cmbGuildStatus"	value="' . $this->theCharacter->strGuildStatus . '">';
		}

		echo '
	<!-- JavaScript block has been added here instead of in the header on purpose -->
	<script language="JavaScript">
	<!-- Show/Hide an element on the Form -->
	function ShowElement( strElement, bShow )
	{
		// Try the standard method
		if( document.getElementById )
		{
			document.poppedLayer	= eval("document.getElementById(\'" + strElement + "\')");
		}
		// Try the old MSIE method
		else if( document.all )
		{
			document.poppedLayer	= eval("document.all[\'" + strElement + "\']");
		}
		// Try the Netscape method
		else if( document.layers )
		{
			document.poppedLayer	= eval("document.layers[\'`" + strElement + "\']");
		}
		
		if( bShow == true )
		{
			document.poppedLayer.style.visibility	= "visible";
		}
		else
		{
			document.poppedLayer.style.visibility	= "hidden";
		}
	}
	
	<!-- Show/Hide a layer on the form -->
	function ShowLayer( theLayer, bShow )
	{
		// Try the standard method
		if( document.getElementById )
		{
			var style2		= document.getElementById(theLayer).style;
		}
		// Try the old MSIE method
		else if( document.all )
		{
			var style2		= document.all[theLayer].style;
		}
		// Try the Netscape method
		else if( document.layers )
		{
			var style2		= document.layers[theLayer].style;
		}

		if( bShow == true )
		{
			style2.display	= "block";
		}
		else
		{
			style2.display	= "";
		}
	}

	<!-- Check if Statistics should be shown -->
	function DisplayStatistics()
	{
		if( document.formModifyCharacter.cbDisplayStatistics.checked == true )
		{
			document.formModifyCharacter.cbDisplayStatistics.value	= true;
			ShowLayer( "Statistics", true );
		}
		else
		{
			document.formModifyCharacter.cbDisplayStatistics.value	= false;
			ShowLayer( "Statistics", false );
		}
	};

	<!-- Check if Tradeskills should be shown -->
	function DisplayTradeskills()
	{
		if( document.formModifyCharacter.cbDisplayTradeskills.checked == true )
		{
			document.formModifyCharacter.cbDisplayTradeskills.value	= true;
			ShowLayer( "Tradeskills", true );
		}
		else
		{
			document.formModifyCharacter.cbDisplayTradeskills.value	= false;
			ShowLayer( "Tradeskills", false );
		}
	};

	<!-- Check if Keys progression should be shown -->
	function DisplayKeysProgression()
	{
		if( document.formModifyCharacter.cbDisplayKeysProgression.checked == true )
		{
			document.formModifyCharacter.cbDisplayKeysProgression.value	= true;
			ShowLayer( "Keys_Progression", true );
		}
		else
		{
			document.formModifyCharacter.cbDisplayKeysProgression.value	= false;
			ShowLayer( "Keys_Progression", false );
		}
	};

	<!-- Check if PoP progression should be shown -->
	function DisplayPoPProgression()
	{
		if( document.formModifyCharacter.cbDisplayPoPProgression.checked == true )
		{
			document.formModifyCharacter.cbDisplayPoPProgression.value	= true;
			ShowLayer( "PoP_Progression", true );
		}
		else
		{
			document.formModifyCharacter.cbDisplayPoPProgression.value	= false;
			ShowLayer( "PoP_Progression", false );
		}
	};

	<!-- Check if GoD progression should be shown -->
	function DisplayGoDProgression()
	{
		if( document.formModifyCharacter.cbDisplayGoDProgression.checked == true )
		{
			document.formModifyCharacter.cbDisplayGoDProgression.value	= true;
			ShowLayer( "GoD_Progression", true );
		}
		else
		{
			document.formModifyCharacter.cbDisplayGoDProgression.value	= false;
			ShowLayer( "GoD_Progression", false );
		}
	};

	<!-- Check if OoW CoA progression should be shown -->
	function DisplayOoW_CoAProgression()
	{
		if( document.formModifyCharacter.cbDisplayOoW_CoAProgression.checked == true )
		{
			document.formModifyCharacter.cbDisplayOoW_CoAProgression.value	= true;
			ShowLayer( "OoW_CoA_Progression", true );
		}
		else
		{
			document.formModifyCharacter.cbDisplayOoW_CoAProgression.value	= false;
			ShowLayer( "OoW_CoA_Progression", false );
		}
	};

	<!-- Check if DoN progression should be shown -->
	function DisplayDoNProgression()
	{
		if( document.formModifyCharacter.cbDisplayDoNProgression.checked == true )
		{
			document.formModifyCharacter.cbDisplayDoNProgression.value	= true;
			ShowLayer( "DoN_Progression", true );
			DisplayDoNProgressionType();
		}
		else
		{
			document.formModifyCharacter.cbDisplayDoNProgression.value	= false;
			ShowLayer( "DoN_Progression", false );
		}
	};

	<!-- Check which DoN Progression should be shown -->
	function DisplayDoNProgressionType()
	{
		if( document.formModifyCharacter.rbDoN_Progression_Good.checked == true )
		{
			ShowLayer( "DoN_Progression_Evil", false );
			ShowLayer( "DoN_Progression_Good", true );
		}
		else
		{
			ShowLayer( "DoN_Progression_Good", false );
			ShowLayer( "DoN_Progression_Evil", true );
			// If I don`t hide/show the whole layer, I get a space where the good table was... weird bug!
			ShowLayer( "DoN_Progression", false );
			ShowLayer( "DoN_Progression", true );
		}
	};

	<!-- Check if DoD progression should be shown -->
	function DisplayDoDProgression()
	{
		if( document.formModifyCharacter.cbDisplayDoDProgression.checked == true )
		{
			document.formModifyCharacter.cbDisplayDoDProgression.value	= true;
			ShowLayer( "DoD_Progression", true );
		}
		else
		{
			document.formModifyCharacter.cbDisplayDoDProgression.value	= false;
			ShowLayer( "DoD_Progression", false );
		}
	};

	<!-- Check the MageloNr to see if we should hide/show the image -->
	function CheckMageloNr()
	{
		if( (document.formModifyCharacter.editMageloNr.value * 1) > 0 )
		{
			ShowElement( "MageloLink", true );
		}
		else
		{
			ShowElement( "MageloLink", false );
		}
	};

	<!-- Check if all the fields on the form are valid -->
	function ValidateFields()
	{
		// We do not really do any validation, because there are no invalid fields possible
		// But we do set the Validation flag of the form, so that the PHP knows that it should
		// update all the records (instead of show this form)

		// Validation complete, all fields are valid
		document.formModifyCharacter.cbValidated.value		= true;
		document.formModifyCharacter.cbValidated.checked	= true;

		// Submit the form
		document.formModifyCharacter.submit();

		// Done
		return true;
	};

	<!-- Cancel the modify -->
	function CancelModify()
	{
		// Validation complete, all fields are valid
		document.formModifyCharacter.cbCancelModify.value	= true;
		document.formModifyCharacter.cbCancelModify.checked	= true;

		// Submit the form
		document.formModifyCharacter.submit();

		// Done
		return true;
	};

	<!-- Perform the Magelo Import -->
	function PerformMageloImport()
	{
		// Set the import mode
		document.formModifyCharacter.editImportMode.value		= ' . IMPORTMODE_MAGELO . ';

		// Submit the form
		document.formModifyCharacter.submit();

		// Done
		return true;
	};

	<!-- Perform the EQPlayers Import -->
	function PerformEQPlayersImport()
	{
		// Set the import mode
		document.formModifyCharacter.editImportMode.value		= ' . IMPORTMODE_EQPLAYERS . ';

		// Submit the form
		document.formModifyCharacter.submit();

		// Done
		return true;
	};
	</script>


	<!-- Start of Modify CHaracter -->
	<form name="formModifyCharacter" method="post" action="form_character_modify.php?UserName=' . $this->strUserName . '&Password=' . $this->strPassword . '&CharName=' . $this->theCharacter->strCharName . '&PreviousForm=' . $this->strPreviousForm . '&SortOrder=' . $this->strSortOrder . '&SortDirection=' . $this->strSortDirection . '&ShowAlts=' . $this->strShowAlts . '&ClassFilter=' . $this->strClassFilter . '">
		<div id="Body">
		<center>
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="' . $this->theSkin->strCharModifyHeaderBGColor . '">
		  <tr>
			<td width="10%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Name</i></font></td>
			<td width="20%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Last Name</i></font></td>
			<td width="10%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Title</i></font></td>
			<td width= "8%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Class</i></font></td>
			<td width= "4%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Level</i></font></td>
			<td width= "4%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>AA</i></font></td>
			<td width= "4%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>GLP</i></font></td>
			<td width="10%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Race</i></font></td>
			<td width= "8%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Gender</i></font></td>
			<td width="12%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>MageloNr</i></font></td>
		  </tr>
		</table>
		<table width="98%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td width="10%">' . $this->theCharacter->strCharName . ' <img src="' . GetSkinDir() . 'images/eqplayers.gif" border="0" OnMouseOver="window.status=\'Import data from ' . $this->theCharacter->strCharName . '\\\'s EQPlayers profile\';return true;"	OnMouseOut="window.status=\'\'" onClick="PerformEQPlayersImport();" title="Import data from ' . $this->theCharacter->strCharName . '\'s EQPlayers profile"/></td>
			<td width="20%"><input type="text"		name="editLastName"	size="20"	value="' . $this->theCharacter->strLastName . '"	maxlength="30"></td>
			<td width="10%">' . $strFieldGuildStatus . '</td>
			<td width= "8%"><input type="hidden"	name="editClass"				value="' . $this->theCharacter->strClass . '">'	. $this->theCharacter->strClass . '</td>
			<td width= "4%"><input type="hidden"	name="editLevel"				value="' . $this->theCharacter->nLevel . '">'	. $this->theCharacter->nLevel . '</td>
			<td width= "4%"><input type="number"	name="editAA"		size="2"	value="' . $this->theCharacter->nAA . '"			maxlength="4"></td>
			<td width= "4%"><input type="number"	name="editGLP"		size="2"	value="' . $this->theCharacter->nGLP . '"			maxlength="3"></td>
			<td width="10%">' . CreateSelectFromEnum( "Characters", "Race",   $this->theCharacter->strRace,   "							" ) . '</td>
			<td width= "8%">' . CreateSelectFromEnum( "Characters", "Gender", $this->theCharacter->strGender, "							" ) . '</td>
			<td width="12%"><input type="text"		name="editMageloNr"	size="10"	value="' . $this->theCharacter->nMageloNr . '"		maxlength="10"	onKeyUp="CheckMageloNr();"><img src="' . GetSkinDir() . 'images/magelo.gif" border="0" id="MageloLink" OnMouseOver="window.status=\'Import data from ' . $this->theCharacter->strCharName . '\\\'s magelo\';return true;"	OnMouseOut="window.status=\'\'" onClick="PerformMageloImport();" title="Import data from ' . $this->theCharacter->strCharName . '\'s magelo"/></a>
				<!-- Show/Hide the image on page load -->
				<script language="JavaScript">
					CheckMageloNr();
				</script>
			</td>
		  </tr>
		' . $strFieldNameMain . '
		</table>
			
		<!-- Character Statistics -->
		<br />
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="' . $this->theSkin->strCharModifyHeaderBGColor . '">
		  <tr>
			<td width= "8%"></td>
			<td width="84%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Statistics</i></font></td>
			<td width= "8%" align="right"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Show</i></font><input type="checkbox" name="cbDisplayStatistics" id="cbDisplayStatistics" onClick="DisplayStatistics();" value="' . $this->bShowStatistics . '" ' . GetCheckboxValue( $this->bShowStatistics ) . ' title="Show/hide the Statistics"></td>
		  </tr>
		</table>

		<div id="Statistics">
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="' . $this->theSkin->strCharModifyHeaderBGColor . '">
		  <tr>
			<td width= "2%"></td>
			<td width= "5%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>HP</i></font></td>
			<td width= "5%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Mana</i></font></td>
			<td width= "5%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>End</i></font></td>
			<td width= "5%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>AC</i></font></td>
			<td width= "5%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>FT</i></font></td>
			<td width= "5%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Regen</i></font></td>
			<td width= "5%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Atk</i></font></td>
			<td width= "5%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Str</i></font></td>
			<td width= "5%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Sta</i></font></td>
			<td width= "5%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Agi</i></font></td>
			<td width= "5%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Dex</i></font></td>
			<td width= "5%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Wis</i></font></td>
			<td width= "5%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Int</i></font></td>
			<td width= "5%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Cha</i></font></td>
			<td width= "5%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>PR</i></font></td>
			<td width= "5%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>MR</i></font></td>
			<td width= "5%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>DR</i></font></td>
			<td width= "5%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>FR</i></font></td>
			<td width= "5%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>CR</i></font></td>
			<td width= "1%"></td>
		  </tr>
		</table>
		<table width="98%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td width= "2%"></td>
			<td width= "5%" align="center"><input type="number" name="editHP"			size="2" value="' . $this->theCharacter->nHP . '"			maxlength="5"></td>
			<td width= "5%" align="center"><input type="number" name="editMana"			size="2" value="' . $this->theCharacter->nMana . '"			maxlength="5"></td>
			<td width= "5%" align="center"><input type="number" name="editEndurance"	size="2" value="' . $this->theCharacter->nEndurance . '"	maxlength="5"></td>
			<td width= "5%" align="center"><input type="number" name="editAC"			size="2" value="' . $this->theCharacter->nAC . '"			maxlength="4"></td>
			<td width= "5%" align="center"><input type="number" name="editFT"			size="2" value="' . $this->theCharacter->nFT . '"			maxlength="2"></td>
			<td width= "5%" align="center"><input type="number" name="editRegen"		size="2" value="' . $this->theCharacter->nRegen . '"		maxlength="2"></td>
			<td width= "5%" align="center"><input type="number" name="editAtk"			size="2" value="' . $this->theCharacter->nAtk . '"			maxlength="4"></td>
			<td width= "5%" align="center"><input type="number" name="editStr"			size="2" value="' . $this->theCharacter->nStr . '"			maxlength="3"></td>
			<td width= "5%" align="center"><input type="number" name="editSta"			size="2" value="' . $this->theCharacter->nSta . '"			maxlength="3"></td>
			<td width= "5%" align="center"><input type="number" name="editAgi"			size="2" value="' . $this->theCharacter->nAgi . '"			maxlength="3"></td>
			<td width= "5%" align="center"><input type="number" name="editDex"			size="2" value="' . $this->theCharacter->nDex . '"			maxlength="3"></td>
			<td width= "5%" align="center"><input type="number" name="editWis"			size="2" value="' . $this->theCharacter->nWis . '"			maxlength="3"></td>
			<td width= "5%" align="center"><input type="number" name="editInt"			size="2" value="' . $this->theCharacter->nInt . '"			maxlength="3"></td>
			<td width= "5%" align="center"><input type="number" name="editCha"			size="2" value="' . $this->theCharacter->nCha . '"			maxlength="3"></td>
			<td width= "5%" align="center"><input type="number" name="editPR"			size="2" value="' . $this->theCharacter->nPR . '"			maxlength="3"></td>
			<td width= "5%" align="center"><input type="number" name="editMR"			size="2" value="' . $this->theCharacter->nMR . '"			maxlength="3"></td>
			<td width= "5%" align="center"><input type="number" name="editDR"			size="2" value="' . $this->theCharacter->nDR . '"			maxlength="3"></td>
			<td width= "5%" align="center"><input type="number" name="editFR"			size="2" value="' . $this->theCharacter->nFR . '"			maxlength="3"></td>
			<td width= "5%" align="center"><input type="number" name="editCR"			size="2" value="' . $this->theCharacter->nCR . '"			maxlength="3"></td>
			<td width= "1%"></td>
		  </tr>
		</table>
		</div>


		<!-- Tradeskills -->
		<br />
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="' . $this->theSkin->strCharModifyHeaderBGColor . '">
		  <tr>
			<td width= "8%"></td>
			<td width="84%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Tradeskills</i></font></td>
			<td width= "8%" align="right"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Show</i></font><input type="checkbox" name="cbDisplayTradeskills" id="cbDisplayTradeskills" onClick="DisplayTradeskills();" value="' . $this->bShowTradeskills . '" ' . GetCheckboxValue( $this->bShowTradeskills ) . ' title="Show/hide the Tradeskills"></td>
		  </tr>
		</table>

		<div id="Tradeskills">
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="' . $this->theSkin->strCharModifyHeaderBGColor . '">
		  <tr>
			<td width= "1%"></td>
			<td width= "7%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Alchemy</i></font></td>
			<td width= "7%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Baking</i></font></td>
			<td width= "7%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Brewing</i></font></td>
			<td width= "7%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Fishing</i></font></td>
			<td width= "7%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Fletching</i></font></td>
			<td width= "7%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Foraging</i></font></td>
			<td width= "7%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Jewelcraft</i></font></td>
			<td width= "7%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Poison</i></font></td>
			<td width= "7%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Pottery</i></font></td>
			<td width= "7%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Research</i></font></td>
			<td width= "7%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Smithing</i></font></td>
			<td width= "7%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Tailoring</i></font></td>
			<td width= "7%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Tinkering</i></font></td>
			<td width= "1%"></td>
		  </tr>
		</table>
		<table width="98%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td width= "1%"></td>
			<td width= "7%" align="center"><input type="number" name="editAlchemy"		size="2" value="' . $this->theCharacter->nAlchemy . '"		maxlength="3"></td>
			<td width= "7%" align="center"><input type="number" name="editBaking"		size="2" value="' . $this->theCharacter->nBaking . '"		maxlength="3"></td>
			<td width= "7%" align="center"><input type="number" name="editBrewing"		size="2" value="' . $this->theCharacter->nBrewing . '"		maxlength="3"></td>
			<td width= "7%" align="center"><input type="number" name="editFishing"		size="2" value="' . $this->theCharacter->nFishing . '"		maxlength="3"></td>
			<td width= "7%" align="center"><input type="number" name="editFletching"	size="2" value="' . $this->theCharacter->nFletching . '"	maxlength="3"></td>
			<td width= "7%" align="center"><input type="number" name="editForaging"		size="2" value="' . $this->theCharacter->nForaging . '"		maxlength="3"></td>
			<td width= "7%" align="center"><input type="number" name="editJewelcraft"	size="2" value="' . $this->theCharacter->nJewelcraft . '"	maxlength="3"></td>
			<td width= "7%" align="center"><input type="number" name="editPoison"		size="2" value="' . $this->theCharacter->nPoison . '"		maxlength="3"></td>
			<td width= "7%" align="center"><input type="number" name="editPottery"		size="2" value="' . $this->theCharacter->nPottery . '"		maxlength="3"></td>
			<td width= "7%" align="center"><input type="number" name="editResearch"		size="2" value="' . $this->theCharacter->nResearch . '"		maxlength="3"></td>
			<td width= "7%" align="center"><input type="number" name="editSmithing"		size="2" value="' . $this->theCharacter->nSmithing . '"		maxlength="3"></td>
			<td width= "7%" align="center"><input type="number" name="editTailoring"	size="2" value="' . $this->theCharacter->nTailoring . '"	maxlength="3"></td>
			<td width= "7%" align="center"><input type="number" name="editTinkering"	size="2" value="' . $this->theCharacter->nTinkering . '"	maxlength="3"></td>
			<td width= "1%"></td>
		  </tr>
		</table>
		</div>


		<!-- Keys -->
		<br />
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="' . $this->theSkin->strCharModifyHeaderBGColor . '">
		  <tr>
			<td width= "8%"></td>
			<td width="84%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Keys</i></font></td>
			<td width= "8%" align="right"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Show</i></font><input type="checkbox" name="cbDisplayKeysProgression" id="cbDisplayKeysProgression" onClick="DisplayKeysProgression();" value="' . $this->bShowKeysProgression . '" ' . GetCheckboxValue( $this->bShowKeysProgression ) . ' title="Show/hide the Keys"></td>
		  </tr>
		</table>

		<div id="Keys_Progression">
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="' . $this->theSkin->strCharModifyHeaderBGColor . '">
		  <tr>
			<td width="10%"></td>
			<td width="20%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp Keys</i></font></td>
			<td width="20%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp SSRA Emperor key</i></font></td>
			<td width="20%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp Veeshan\'s Peak key</i></font></td>
			<td width="20%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp Vex Thal key</i></font></td>
			<td width="10%"></td>
		  </tr>
		</table>

		<table width="98%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td width="10%"></td>
			<td width="20%"><input type="checkbox" name="cbBoT_Tower_Key"		value="1" ' . GetCheckboxValue( $this->theCharacter->nBoT_Tower_Key ) . '>BoT Tower Key</td>
			<td width="20%"><input type="checkbox" name="cbTaskmasters_Pouch"	value="1" ' . GetCheckboxValue( $this->theCharacter->nTaskmasters_Pouch ) . '>Taskm.\'s Pouch</td>
			<td width="20%"><input type="checkbox" name="cbKylongMedal_Top"		value="1" ' . GetCheckboxValue( $this->theCharacter->nKylongMedal_Top ) . '>Kylong Medal. Top</td>
			<td width="20%"><input type="checkbox" name="cbGlowing_Orb"			value="1" ' . GetCheckboxValue( $this->theCharacter->nGlowing_Orb ) . '>Glowing Orb</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"><input type="checkbox" name="cbHowling_Stones_Key"	value="1" ' . GetCheckboxValue( $this->theCharacter->nHowling_Stones_Key ) . '>Howling Stones Key</td>
			<td width="20%"><input type="checkbox" name="cbZazuzhs_Idol"		value="1" ' . GetCheckboxValue( $this->theCharacter->nZazuzhs_Idol ) . '>Zazuzh\'s Idol</td>
			<td width="20%"><input type="checkbox" name="cbKylongMedal_Middle"	value="1" ' . GetCheckboxValue( $this->theCharacter->nKylongMedal_Middle ) . '>Kylong Medal. Mid.</td>
			<td width="20%"><input type="checkbox" name="cbCelestial_Rift"		value="1" ' . GetCheckboxValue( $this->theCharacter->nCelestial_Rift ) . '>Celestial Rift</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"><input type="checkbox" name="cbSebilis_Key"			value="1" ' . GetCheckboxValue( $this->theCharacter->nSebilis_Key ) . '>Sebilis Key</td>
			<td width="20%"><input type="checkbox" name="cbRing"				value="1" ' . GetCheckboxValue( $this->theCharacter->nRing ) . '>Ring</td>
			<td width="20%"><input type="checkbox" name="cbKylongMedal_Bottom"	value="1" ' . GetCheckboxValue( $this->theCharacter->nKylongMedal_Bottom ) . '>Kylong Medal. Bot.</td>
			<td width="20%"><input type="checkbox" name="cbShard_Dat"			value="1" ' . GetCheckboxValue( $this->theCharacter->nShard_Dat ) . '>Shard: Dat (FG)</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"><input type="checkbox" name="cbSleepers_Tomb_Key"	value="1" ' . GetCheckboxValue( $this->theCharacter->nSleepers_Tomb_Key ) . '>Sleepers Tomb Key</td>
			<td width="20%"><input type="checkbox" name="cbInsignia"			value="1" ' . GetCheckboxValue( $this->theCharacter->nInsignia ) . '>Insignia</td>
			<td width="20%"><input type="checkbox" name="cbJarsathMedal_Top"	value="1" ' . GetCheckboxValue( $this->theCharacter->nJarsathMedal_Top ) . '>Jarsath Medal. Top</td>
			<td width="20%"><input type="checkbox" name="cbShard_Dax"			value="1" ' . GetCheckboxValue( $this->theCharacter->nShard_Dax ) . '>Shard: Dax (AR)</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"><input type="checkbox" name="cbSSRA_Emperor_Key"	value="1" ' . GetCheckboxValue( $this->theCharacter->nSSRA_Emperor_Key ) . '>SSRA Emperor Key</td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbJarsathMedal_Middle"	value="1" ' . GetCheckboxValue( $this->theCharacter->nJarsathMedal_Middle ) . '>Jarsath Medal. Mid.</td>
			<td width="20%"><input type="checkbox" name="cbShard_Kel"			value="1" ' . GetCheckboxValue( $this->theCharacter->nShard_Kel ) . '>Shard: Kel (TG)</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"><input type="checkbox" name="cbVeeshans_Peak_Key"	value="1" ' . GetCheckboxValue( $this->theCharacter->nVeeshans_Peak_Key ) . '>Veeshan\'s Peak Key</td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbJarsathMedal_Bottom"	value="1" ' . GetCheckboxValue( $this->theCharacter->nJarsathMedal_Bottom ) . '>Jarsath Medal. Bot.</td>
			<td width="20%"><input type="checkbox" name="cbShard_Kelara"		value="1" ' . GetCheckboxValue( $this->theCharacter->nShard_Kelara ) . '>Shard: Kelara (SS)</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"><input type="checkbox" name="cbVex_Thal_Key"		value="1" ' . GetCheckboxValue( $this->theCharacter->nVex_Thal_Key ) . '>Vex Thal Key</td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbObulusMedal_Top"		value="1" ' . GetCheckboxValue( $this->theCharacter->nObulusMedal_Top ) . '>Obulus Medal. Top</td>
			<td width="20%"><input type="checkbox" name="cbShard_Lor"			value="1" ' . GetCheckboxValue( $this->theCharacter->nShard_Lor ) . '>Shard: Lor (DP)</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbObulusMedal_Middle"	value="1" ' . GetCheckboxValue( $this->theCharacter->nObulusMedal_Middle ) . '>Obulus Medal. Mid.</td>
			<td width="20%"><input type="checkbox" name="cbShard_Raf"			value="1" ' . GetCheckboxValue( $this->theCharacter->nShard_Raf ) . '>Shard: Raf (TD)</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbObulusMedal_Bottom"	value="1" ' . GetCheckboxValue( $this->theCharacter->nObulusMedal_Bottom ) . '>Obulus Medal. Bot.</td>
			<td width="20%"><input type="checkbox" name="cbShard_Set"			value="1" ' . GetCheckboxValue( $this->theCharacter->nShard_Set ) . '>Shard: Set (SD)</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbTrak_Tooth"			value="1" ' . GetCheckboxValue( $this->theCharacter->nTrak_Tooth ) . '>Trakanon\'s Tooth</td>
			<td width="20%"><input type="checkbox" name="cbShard_Tak"			value="1" ' . GetCheckboxValue( $this->theCharacter->nShard_Tak ) . '>Shard: Tak (ME)</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbShard_Ved"			value="1" ' . GetCheckboxValue( $this->theCharacter->nShard_Ved ) . '>Shard: Ved (AC)</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbShard_Vin"			value="1" ' . GetCheckboxValue( $this->theCharacter->nShard_Vin ) . '>Shard: Vin (SSRA)</td>
			<td width="10%"></td>
		  </tr>
		</table>
		</div>


		<!-- PoP -->
		<br />
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="' . $this->theSkin->strCharModifyHeaderBGColor . '">
		  <tr>
			<td width= "8%"></td>
			<td width="84%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Planes of Power</i></font></td>
			<td width= "8%" align="right"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Show</i></font><input type="checkbox" name="cbDisplayPoPProgression" id="cbDisplayPoPProgression" onClick="DisplayPoPProgression();" value="' . $this->bShowPoPProgression . '" ' . GetCheckboxValue( $this->bShowPoPProgression ) . ' title="Show/hide the Planes of Power progress"></td>
		  </tr>
		</table>

		<div id="PoP_Progression">
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="' . $this->theSkin->strCharModifyHeaderBGColor . '">
		  <tr>
			<td width="20%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp PoP Tier 1 Flags</i></font></td>
			<td width="20%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp PoP Tier 2 Flags</i></font></td>
			<td width="20%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp PoP Tier 3 Flags</i></font></td>
			<td width="20%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp PoP Tier 4 Flags</i></font></td>
			<td width="20%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp BoT (PoS Quest)</i></font></td>
		  </tr>
		</table>

		<table width="98%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td width="20%"><input type="checkbox" name="cbAny_PoJ_Trial"						value="1" ' . GetCheckboxValue( $this->theCharacter->nAny_PoJ_Trial )						. '>Any PoJ Trial</td>
			<td width="20%"><input type="checkbox" name="cbPoS_Askr_Quest"						value="1" ' . GetCheckboxValue( $this->theCharacter->nPoS_Askr_Quest )						. '>PoS Askr Quest</td>
			<td width="20%"><input type="checkbox" name="cbHoH_Trial1_RyddaDar"					value="1" ' . GetCheckboxValue( $this->theCharacter->nHoH_Trial1_RyddaDar )					. '>HoH Trial1 RyddaDar</td>
			<td width="20%"><input type="checkbox" name="cbPoAir_Xegony"						value="1" ' . GetCheckboxValue( $this->theCharacter->nPoAir_Xegony )						. '>PoAir Xegony</td>
			<td width="20%"><input type="checkbox" name="cbHead"								value="1" ' . GetCheckboxValue( $this->theCharacter->nHead )								. '>Giant head</td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbAll_PoJ_Trials"						value="1" ' . GetCheckboxValue( $this->theCharacter->nAll_PoJ_Trials )						. '>All PoJ Trials</td>
			<td width="20%"><input type="checkbox" name="cbPoV_Grenic_Quest"					value="1" ' . GetCheckboxValue( $this->theCharacter->nPoV_Grenic_Quest )					. '>PoV Grenic Quest</td>
			<td width="20%"><input type="checkbox" name="cbHoH_Trial2_Ogre"						value="1" ' . GetCheckboxValue( $this->theCharacter->nHoH_Trial2_Ogre )						. '>HoH Trial2 Ogre</td>
			<td width="20%"><input type="checkbox" name="cbPoFire_Fennin_Ro"					value="1" ' . GetCheckboxValue( $this->theCharacter->nPoFire_Fennin_Ro )					. '>PoFire Fennin Ro</td>
			<td width="20%"><input type="checkbox" name="cbBeard"								value="1" ' . GetCheckboxValue( $this->theCharacter->nBeard )								. '>Beard (Ocean)</td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbPoI_Xanamech"						value="1" ' . GetCheckboxValue( $this->theCharacter->nPoI_Xanamech )						. '>PoI Xanamech</td>
			<td width="20%"><input type="checkbox" name="cbPoV_AerinDar"						value="1" ' . GetCheckboxValue( $this->theCharacter->nPoV_AerinDar )						. '>PoV AerinDar</td>
			<td width="20%"><input type="checkbox" name="cbHoH_Trial3_Madmen"					value="1" ' . GetCheckboxValue( $this->theCharacter->nHoH_Trial3_Madmen )					. '>HoH Trial3 Madmen</td>
			<td width="20%"><input type="checkbox" name="cbPoWater_Coirnav"						value="1" ' . GetCheckboxValue( $this->theCharacter->nPoWater_Coirnav )						. '>PoWater Coirnav</td>
			<td width="20%"><input type="checkbox" name="cbBone"								value="1" ' . GetCheckboxValue( $this->theCharacter->nBone )								. '>Bone (Desert)</td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbPoI_Behemoth"						value="1" ' . GetCheckboxValue( $this->theCharacter->nPoI_Behemoth )						. '>PoI Behemoth</td>
			<td width="20%"><input type="checkbox" name="cbCoD_Carprin_Event"					value="1" ' . GetCheckboxValue( $this->theCharacter->nCoD_Carprin_Event )					. '>CoD Carprin Event</td>
			<td width="20%"><input type="checkbox" name="cbHoHb_Mithanial_Marr"					value="1" ' . GetCheckboxValue( $this->theCharacter->nHoHb_Mithanial_Marr )					. '>HoHb Mithanial Marr</td>
			<td width="20%"><input type="checkbox" name="cbPoEarthb_The_Rathe"					value="1" ' . GetCheckboxValue( $this->theCharacter->nPoEarthb_The_Rathe )					. '>PoEarthb The Rathe</td>
			<td width="20%"><input type="checkbox" name="cbSash"								value="1" ' . GetCheckboxValue( $this->theCharacter->nSash )								. '>Sash (Forest)</td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbPoD_Grimror_Quest"					value="1" ' . GetCheckboxValue( $this->theCharacter->nPoD_Grimror_Quest )					. '>PoD Grimror Quest</td>
			<td width="20%"><input type="checkbox" name="cbCoD_Bertoxxulous"					value="1" ' . GetCheckboxValue( $this->theCharacter->nCoD_Bertoxxulous )					. '>CoD Bertoxxulous</td>
			<td width="20%"><input type="checkbox" name="cbPoTactics_Tallon_Zek"				value="1" ' . GetCheckboxValue( $this->theCharacter->nPoTactics_Tallon_Zek )				. '>PoTactics Tallon Zek</td>
			<td width="20%"><input type="checkbox" name="cbPoTime_Time_Phased_Quintessence"		value="1" ' . GetCheckboxValue( $this->theCharacter->nPoTime_Time_Phased_Quintessence )		. '>Time Phased Quintessence</td>
			<td width="20%"><input type="checkbox" name="cbOceanMedal"							value="1" ' . GetCheckboxValue( $this->theCharacter->nOceanMedal )							. '>Ocean Medalion </td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbPoD_Grummus"							value="1" ' . GetCheckboxValue( $this->theCharacter->nPoD_Grummus )							. '>PoD Grummus</td>
			<td width="20%"><input type="checkbox" name="cbPoTorment_Saryrn"					value="1" ' . GetCheckboxValue( $this->theCharacter->nPoTorment_Saryrn )					. '>PoTorment Saryrn</td>
			<td width="20%"><input type="checkbox" name="cbPoTactics_Vallon_Zek"				value="1" ' . GetCheckboxValue( $this->theCharacter->nPoTactics_Vallon_Zek )				. '>PoTactics Vallon Zek</td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbDesertMedal"							value="1" ' . GetCheckboxValue( $this->theCharacter->nDesertMedal )							. '>Desert Medalion </td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbPoN_Hedge_Quest"						value="1" ' . GetCheckboxValue( $this->theCharacter->nPoN_Hedge_Quest )						. '>PoN Hedge Quest</td>
			<td width="20%"><input type="checkbox" name="cbPoS_Wembly_Quest"					value="1" ' . GetCheckboxValue( $this->theCharacter->nPoS_Wembly_Quest )					. '>PoS Wembly Quest</td>
			<td width="20%"><input type="checkbox" name="cbPoTactics_Rallos_Zek_Quest"			value="1" ' . GetCheckboxValue( $this->theCharacter->nPoTactics_Rallos_Zek_Quest )			. '>PoTactics Rallos Zek Quest</td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbForestMedal"							value="1" ' . GetCheckboxValue( $this->theCharacter->nForestMedal )							. '>Forest Medalion</td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbPoNb_Terris_Thule"					value="1" ' . GetCheckboxValue( $this->theCharacter->nPoNb_Terris_Thule )					. '>PoNb Terris Thule</td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbBoT_Rescue_Karana_Quest"				value="1" ' . GetCheckboxValue( $this->theCharacter->nBoT_Rescue_Karana_Quest )				. '>BoT Rescue Karana Quest</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		  <tr>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbSolRoTower_Jiva"						value="1" ' . GetCheckboxValue( $this->theCharacter->nSolRoTower_Jiva )						. '>SolRoTower Jiva</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		  <tr>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbSolRoTower_Xuzl"						value="1" ' . GetCheckboxValue( $this->theCharacter->nSolRoTower_Xuzl )						. '>SolRoTower Xuzl</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		  <tr>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbSolRoTower_Arlyxir"					value="1" ' . GetCheckboxValue( $this->theCharacter->nSolRoTower_Arlyxir )					. '>SolRoTower Arlyxir</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		  <tr>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbSolRoTower_Rizlona"					value="1" ' . GetCheckboxValue( $this->theCharacter->nSolRoTower_Rizlona )					. '>SolRoTower Rizlona</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		  <tr>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbSolRoTower_Protector_of_Dresolik"	value="1" ' . GetCheckboxValue( $this->theCharacter->nSolRoTower_Protector_of_Dresolik )	. '>SolRoTower Dresolik</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		  <tr>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbSolRoTower_Solusek_Ro"				value="1" ' . GetCheckboxValue( $this->theCharacter->nSolRoTower_Solusek_Ro )				. '>SolRoTower Solusek Ro</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		</table>
		</div>


		<!-- GoD progress -->
		<br />
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="' . $this->theSkin->strCharModifyHeaderBGColor . '">
		  <tr>
			<td width= "8%"></td>
			<td width="84%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Gates of Discord</i></font></td>
			<td width= "8%" align="right"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Show</i></font><input type="checkbox" name="cbDisplayGoDProgression" id="cbDisplayGoDProgression" onClick="DisplayGoDProgression();" value="' . $this->bShowGoDProgression . '" ' . GetCheckboxValue( $this->bShowGoDProgression ) . ' title="Show/hide the Gates of Discord progress"></td>
		  </tr>
		</table>

		<div id="GoD_Progression">
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="' . $this->theSkin->strCharModifyHeaderBGColor . '">
		  <tr>
			<td width="10%"></td>
			<td width="20%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp Tier 1</i></font></td>
			<td width="20%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp Tier 2</i></font></td>
			<td width="20%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp Tier 3</i></font></td>
			<td width="20%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp Tacvi</i></font></td>
			<td width="10%"></td>
		  </tr>
		</table>

		<table width="98%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td width="10%"></td>
			<td width="20%"><input type="checkbox" name="cbPurifying_Plant"						value="1" ' . GetCheckboxValue( $this->theCharacter->nPurifying_Plant )						. '>Purifying Plant</td>
			<td width="20%"><input type="checkbox" name="cbVxed"								value="1" ' . GetCheckboxValue( $this->theCharacter->nVxed )								. '>Vxed</td>
			<td width="20%"><input type="checkbox" name="cbVrex_Barxt_Qurat"					value="1" ' . GetCheckboxValue( $this->theCharacter->nVrex_Barxt_Qurat )					. '>Vrex Barxt Qurat</td>
			<td width="20%"><input type="checkbox" name="cbIxt_Hsek_Syat"						value="1" ' . GetCheckboxValue( $this->theCharacter->nIxt_Hsek_Syat )						. '>Ixt Hsek Syat</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"><input type="checkbox" name="cbEmanating_Furnace"					value="1" ' . GetCheckboxValue( $this->theCharacter->nEmanating_Furnace )					. '>Emanating Furnace</td>
			<td width="20%"><input type="checkbox" name="cbTipt"								value="1" ' . GetCheckboxValue( $this->theCharacter->nTipt )								. '>Tipt</td>
			<td width="20%"><input type="checkbox" name="cbKeeper_of_the_Altar"					value="1" ' . GetCheckboxValue( $this->theCharacter->nKeeper_of_the_Altar )					. '>Keeper of the Altar</td>
			<td width="20%"><input type="checkbox" name="cbHigh_Priest_Nkosi_Bakari"			value="1" ' . GetCheckboxValue( $this->theCharacter->nHigh_Priest_Nkosi_Bakari )			. '>High Priest Nkosi Bakari</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"><input type="checkbox" name="cbLair_of_Trapped_Ones"				value="1" ' . GetCheckboxValue( $this->theCharacter->nLair_of_Trapped_Ones )				. '>Lair of Trapped Ones</td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbNoqufiel_in_Inktuta"					value="1" ' . GetCheckboxValue( $this->theCharacter->nNoqufiel_in_Inktuta )					. '>Noqufiel in Inktuta</td>
			<td width="20%"><input type="checkbox" name="cbZunMuram_Tkarish_Zyk"				value="1" ' . GetCheckboxValue( $this->theCharacter->nZunMuram_Tkarish_Zyk )				. '>Zun\'Muram Tkarish Zyk</td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"><input type="checkbox" name="cbPool_of_Sludge"						value="1" ' . GetCheckboxValue( $this->theCharacter->nPool_of_Sludge )						. '>Pool of Sludge</td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbCynosure_Kvanjji"					value="1" ' . GetCheckboxValue( $this->theCharacter->nCynosure_Kvanjji )					. '>Cynosure Kvanjji</td>
			<td width="20%"></td>
			<td width="10%"></td>
		  </tr>
		  <tr>
			<td width="10%"></td>
			<td width="20%"><input type="checkbox" name="cbSmith_Rondo"							value="1" ' . GetCheckboxValue( $this->theCharacter->nSmith_Rondo )							. '>Smith Rondo</td>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="10%"></td>
		  </tr>
		</table>
		</div>


		<!-- OoW CoA progress -->
		<br />
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="' . $this->theSkin->strCharModifyHeaderBGColor . '">
		  <tr>
			<td width= "8%"></td>
			<td width="84%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Omens of War - Citadel of Anguish</i></font></td>
			<td width= "8%" align="right"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Show</i></font><input type="checkbox" name="cbDisplayOoW_CoAProgression" id="cbDisplayOoW_CoAProgression" onClick="DisplayOoW_CoAProgression();" value="' . $this->bShowOoW_CoAProgression . '" ' . GetCheckboxValue( $this->bShowOoW_CoAProgression ) . ' title="Show/hide the Omens of War: Citadel of Anguish progress"></td>
		  </tr>
		</table>

		<div id="OoW_CoA_Progression">
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="' . $this->theSkin->strCharModifyHeaderBGColor . '">
		  <tr>
			<td width="30%"></td>
			<td width="20%" align="left"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp Access</i></font></td>
			<td width="20%" align="left"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp Immunisation</i></font></td>
			<td width="30%"></td>
		  </tr>
		</table>

		<table width="98%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td width="30%"></td>
			<td width="20%"><input type="checkbox" name="cbMastery_of_Adaptation"		value="1" ' . GetCheckboxValue( $this->theCharacter->nMastery_of_Adaptation )		. '>Mastery of Adaptation</td>
			<td width="20%"><input type="checkbox" name="cbSignet_Crystal_Gemmed"		value="1" ' . GetCheckboxValue( $this->theCharacter->nSignet_Crystal_Gemmed )		. '>Crystal Gemmed Signet</td>
			<td width="30%"></td>
		  </tr>
		  <tr>
			<td width="30%"></td>
			<td width="20%"><input type="checkbox" name="cbMastery_of_Corruption"		value="1" ' . GetCheckboxValue( $this->theCharacter->nMastery_of_Corruption )		. '>Mastery of Corruption</td>
			<td width="20%"><input type="checkbox" name="cbSignet_Discolored"			value="1" ' . GetCheckboxValue( $this->theCharacter->nSignet_Discolored )			. '>Discolored Signet</td>
			<td width="30%"></td>
		  </tr>
		  <tr>
			<td width="30%"></td>
			<td width="20%"><input type="checkbox" name="cbMastery_of_Endurance"		value="1" ' . GetCheckboxValue( $this->theCharacter->nMastery_of_Endurance )		. '>Mastery of Endurance</td>
			<td width="20%"><input type="checkbox" name="cbSignet_Dust_Marred"			value="1" ' . GetCheckboxValue( $this->theCharacter->nSignet_Dust_Marred )			. '>Dust Marred Signet</td>
			<td width="30%"></td>
		  </tr>
		  <tr>
			<td width="30%"></td>
			<td width="20%"><input type="checkbox" name="cbMastery_of_Foresight"		value="1" ' . GetCheckboxValue( $this->theCharacter->nMastery_of_Foresight )		. '>Mastery of Foresight</td>
			<td width="20%"><input type="checkbox" name="cbSignet_Glimmering"			value="1" ' . GetCheckboxValue( $this->theCharacter->nSignet_Glimmering )			. '>Glimmering Signet</td>
			<td width="30%"></td>
		  </tr>
		  <tr>
			<td width="30%"></td>
			<td width="20%"><input type="checkbox" name="cbMastery_of_Hate"				value="1" ' . GetCheckboxValue( $this->theCharacter->nMastery_of_Hate )				. '>Mastery of Hate</td>
			<td width="20%"><input type="checkbox" name="cbSignet_Tarnished"			value="1" ' . GetCheckboxValue( $this->theCharacter->nSignet_Tarnished )			. '>Tarnished Signet</td>
			<td width="30%"></td>
		  </tr>
		  <tr>
			<td width="30%"></td>
			<td width="20%"><input type="checkbox" name="cbMastery_of_Specialization"	value="1" ' . GetCheckboxValue( $this->theCharacter->nMastery_of_Specialization )	. '>Mastery of Specialization</td>
			<td width="20%"><input type="checkbox" name="cbSignet_Two_Toned"			value="1" ' . GetCheckboxValue( $this->theCharacter->nSignet_Two_Toned )			. '>Two Toned Signet</td>
			<td width="30%"></td>
		  </tr>
		  <tr>
			<td width="30%"></td>
			<td width="20%"><input type="checkbox" name="cbSeal_Mastery_of_All"			value="1" ' . GetCheckboxValue( $this->theCharacter->nSeal_Mastery_of_All )			. '>Seal: Mastery of All</td>
			<td width="20%"><input type="checkbox" name="cbSignet_Weather_Worn"			value="1" ' . GetCheckboxValue( $this->theCharacter->nSignet_Weather_Worn )			. '>Weather Worn Signet</td>
			<td width="30%"></td>
		  </tr>
		</table>
		</div>


		<!-- DoN progress -->
		<br />
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="' . $this->theSkin->strCharModifyHeaderBGColor . '">
		  <tr>
			<td width= "8%"></td>
			<td width="84%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Dragons of Norrath</i></font></td>
			<td width= "8%" align="right"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Show</i></font><input type="checkbox" name="cbDisplayDoNProgression" id="cbDisplayDoNProgression" onClick="DisplayDoNProgression();" value="' . $this->bShowDoNProgression . '" ' . GetCheckboxValue( $this->bShowDoNProgression ) . ' title="Show/hide the Dragons of Norrath progress"></td>
		  </tr>
		</table>

		<div id="DoN_Progression">
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="' . $this->theSkin->strCharModifyHeaderBGColor . '">
		  <tr>
			<td width="20%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp Tier 1</i></font></td>
			<td width="20%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp Tier 2</i></font></td>
			<td width="20%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp Tier 3</i></font></td>
			<td width="20%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp Tier 4</i></font></td>
			<td width="20%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp Tier 5</i></font></td>
		  </tr>
		</table>

		<div id="DoN_Progression_Good">
		<table width="98%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td width="20%"><input type="checkbox" name="cbT1_Create_an_Antidote"			value="1" ' . GetCheckboxValue( $this->theCharacter->nT1_Create_an_Antidote )			. '>Create an Antidote</td>
			<td width="20%"><input type="checkbox" name="cbT2_Defend_the_Kirin_Contact"		value="1" ' . GetCheckboxValue( $this->theCharacter->nT2_Defend_the_Kirin_Contact )		. '>Defend the Kirin Contact</td>
			<td width="20%"><input type="checkbox" name="cbT3_Protect_the_Waters"			value="1" ' . GetCheckboxValue( $this->theCharacter->nT3_Protect_the_Waters )			. '>Protect the Waters</td>
			<td width="20%"><input type="checkbox" name="cbT4_Goblin_Dojo"					value="1" ' . GetCheckboxValue( $this->theCharacter->nT4_Goblin_Dojo )					. '>Goblin Dojo</td>
			<td width="20%"><input type="checkbox" name="cbT5_Origins_of_the_Curse"			value="1" ' . GetCheckboxValue( $this->theCharacter->nT5_Origins_of_the_Curse )			. '>Origins of the Curse</td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbT1_Greed_of_the_Goblins"			value="1" ' . GetCheckboxValue( $this->theCharacter->nT1_Greed_of_the_Goblins )			. '>Greed of the Goblins</td>
			<td width="20%"><input type="checkbox" name="cbT2_Recover_the_Lost_Map"			value="1" ' . GetCheckboxValue( $this->theCharacter->nT2_Recover_the_Lost_Map )			. '>Recover the Lost Map</td>
			<td width="20%"><input type="checkbox" name="cbT3_Snowfoots_Revenge"			value="1" ' . GetCheckboxValue( $this->theCharacter->nT3_Snowfoots_Revenge )			. '>Snowfoots Revenge</td>
			<td width="20%"><input type="checkbox" name="cbT4_Guardian_of_the_Sands"		value="1" ' . GetCheckboxValue( $this->theCharacter->nT4_Guardian_of_the_Sands )		. '>Guardian of the Sands</td>
			<td width="20%"><input type="checkbox" name="cbT5_The_Curse_of_JuRek"			value="1" ' . GetCheckboxValue( $this->theCharacter->nT5_The_Curse_of_JuRek )			. '>The Curse of Ju\'Rek</td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbT1_Burning_Arrows"				value="1" ' . GetCheckboxValue( $this->theCharacter->nT1_Burning_Arrows )				. '>Burning Arrows</td>
			<td width="20%"><input type="checkbox" name="cbT2_Turn_the_Tides_of_the_Sand"	value="1" ' . GetCheckboxValue( $this->theCharacter->nT2_Turn_the_Tides_of_the_Sand )	. '>Turn the Tides of the Sand</td>
			<td width="20%"><input type="checkbox" name="cbT3_The_Sacred_Scrolls"			value="1" ' . GetCheckboxValue( $this->theCharacter->nT3_The_Sacred_Scrolls )			. '>The Sacred Scrolls</td>
			<td width="20%"><input type="checkbox" name="cbT4_An_End_to_the_Storms"			value="1" ' . GetCheckboxValue( $this->theCharacter->nT4_An_End_to_the_Storms )			. '>An End to the Storms</td>
			<td width="20%"><input type="checkbox" name="cbT5_In_the_Shadows"				value="1" ' . GetCheckboxValue( $this->theCharacter->nT5_In_the_Shadows )				. '>In the Shadows</td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbT1_Children_of_Gimblax"			value="1" ' . GetCheckboxValue( $this->theCharacter->nT1_Children_of_Gimblax )			. '>Children of Gimblax</td>
			<td width="20%"><input type="checkbox" name="cbT2_Sickness_of_the_Spirit"		value="1" ' . GetCheckboxValue( $this->theCharacter->nT2_Sickness_of_the_Spirit )		. '>Sickness of the Spirit</td>
			<td width="20%"><input type="checkbox" name="cbT3_History_of_the_Isle"			value="1" ' . GetCheckboxValue( $this->theCharacter->nT3_History_of_the_Isle )			. '>History of the Isle</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		  <tr>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbT2_Calling_Emoush"				value="1" ' . GetCheckboxValue( $this->theCharacter->nT2_Calling_Emoush )				. '>Calling Emoush</td>
			<td width="20%"><input type="checkbox" name="cbT3_Trial_of_Perserverance"		value="1" ' . GetCheckboxValue( $this->theCharacter->nT3_Trial_of_Perserverance )		. '>Trial of Perserverance</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		  <tr>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbT3_Volkaras_Bite"				value="1" ' . GetCheckboxValue( $this->theCharacter->nT3_Volkaras_Bite )				. '>Volkara\'s Bite</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		</table>
		</div>

		<div id="DoN_Progression_Evil">
		<table width="98%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td width="20%"><input type="checkbox" name="cbT1_Create_an_Antidote"			value="1" ' . GetCheckboxValue( $this->theCharacter->nT1_Create_an_Antidote )			. '>Blood of the Basilisk</td>
			<td width="20%"><input type="checkbox" name="cbT2_Defend_the_Kirin_Contact"		value="1" ' . GetCheckboxValue( $this->theCharacter->nT2_Defend_the_Kirin_Contact )		. '>Reap the Kirin Mind</td>
			<td width="20%"><input type="checkbox" name="cbT3_Protect_the_Waters"			value="1" ' . GetCheckboxValue( $this->theCharacter->nT3_Protect_the_Waters )			. '>Muddy the Waters</td>
			<td width="20%"><input type="checkbox" name="cbT4_Goblin_Dojo"					value="1" ' . GetCheckboxValue( $this->theCharacter->nT4_Goblin_Dojo )					. '>Goblin Dojo</td>
			<td width="20%"><input type="checkbox" name="cbT5_Origins_of_the_Curse"			value="1" ' . GetCheckboxValue( $this->theCharacter->nT5_Origins_of_the_Curse )			. '>Origins of the Curse</td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbT1_Greed_of_the_Goblins"			value="1" ' . GetCheckboxValue( $this->theCharacter->nT1_Greed_of_the_Goblins )			. '>Clearing the Path</td>
			<td width="20%"><input type="checkbox" name="cbT2_Recover_the_Lost_Map"			value="1" ' . GetCheckboxValue( $this->theCharacter->nT2_Recover_the_Lost_Map )			. '>Army of Stone</td>
			<td width="20%"><input type="checkbox" name="cbT3_Snowfoots_Revenge"			value="1" ' . GetCheckboxValue( $this->theCharacter->nT3_Snowfoots_Revenge )			. '>Snowfoot Attack</td>
			<td width="20%"><input type="checkbox" name="cbT4_Guardian_of_the_Sands"		value="1" ' . GetCheckboxValue( $this->theCharacter->nT4_Guardian_of_the_Sands )		. '>Guardian of the Sands</td>
			<td width="20%"><input type="checkbox" name="cbT5_The_Curse_of_JuRek"			value="1" ' . GetCheckboxValue( $this->theCharacter->nT5_The_Curse_of_JuRek )			. '>The Curse of Ju\'Rek</td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbT1_Burning_Arrows"				value="1" ' . GetCheckboxValue( $this->theCharacter->nT1_Burning_Arrows )				. '>The Burning Poison</td>
			<td width="20%"><input type="checkbox" name="cbT2_Turn_the_Tides_of_the_Sand"	value="1" ' . GetCheckboxValue( $this->theCharacter->nT2_Turn_the_Tides_of_the_Sand )	. '>Blood from the Sand</td>
			<td width="20%"><input type="checkbox" name="cbT3_The_Sacred_Scrolls"			value="1" ' . GetCheckboxValue( $this->theCharacter->nT3_The_Sacred_Scrolls )			. '>The Gilded Scroll</td>
			<td width="20%"><input type="checkbox" name="cbT4_An_End_to_the_Storms"			value="1" ' . GetCheckboxValue( $this->theCharacter->nT4_An_End_to_the_Storms )			. '>An End to the Storms</td>
			<td width="20%"><input type="checkbox" name="cbT5_In_the_Shadows"				value="1" ' . GetCheckboxValue( $this->theCharacter->nT5_In_the_Shadows )				. '>In the Shadows</td>
		  </tr>
		  <tr>
			<td width="20%"><input type="checkbox" name="cbT1_Children_of_Gimblax"			value="1" ' . GetCheckboxValue( $this->theCharacter->nT1_Children_of_Gimblax )			. '>Have Note Will Travel</td>
			<td width="20%"><input type="checkbox" name="cbT2_Sickness_of_the_Spirit"		value="1" ' . GetCheckboxValue( $this->theCharacter->nT2_Sickness_of_the_Spirit )		. '>Drake Egg</td>
			<td width="20%"><input type="checkbox" name="cbT3_History_of_the_Isle"			value="1" ' . GetCheckboxValue( $this->theCharacter->nT3_History_of_the_Isle )			. '>Knowledge is Power</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		  <tr>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbT2_Calling_Emoush"				value="1" ' . GetCheckboxValue( $this->theCharacter->nT2_Calling_Emoush )				. '>Calling Emoush</td>
			<td width="20%"><input type="checkbox" name="cbT3_Trial_of_Perserverance"		value="1" ' . GetCheckboxValue( $this->theCharacter->nT3_Trial_of_Perserverance )		. '>Trial of Perserverance</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		  <tr>
			<td width="20%"></td>
			<td width="20%"></td>
			<td width="20%"><input type="checkbox" name="cbT3_Volkaras_Bite"				value="1" ' . GetCheckboxValue( $this->theCharacter->nT3_Volkaras_Bite )				. '>Volkara\'s Bite</td>
			<td width="20%"></td>
			<td width="20%"></td>
		  </tr>
		</table>
		</div>

		<table width="60%" border="0" cellspacing="0" cellpadding="0" bgcolor="' . $this->theSkin->strCharModifyHeaderBGColor . '">
		  <tr>
			<td width="30%" align="right"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Show DoN progression:</i></font></td>
			<td width="30%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>
				<input type="radio" id="rbDoN_Progression_Good" name="DoN_Progression" onClick="DisplayDoNProgressionType();" value="Good" ' . GetCheckboxValue( $this->bDoNProgressionGood )  . '>Good
				<input type="radio" id="rbDoN_Progression_Evil" name="DoN_Progression" onClick="DisplayDoNProgressionType();" value="Evil" ' . GetCheckboxValue( !$this->bDoNProgressionGood ) . '>Evil
				</i></font>
			</td>
		  </tr>
		</table>
		</div>

		<!-- DoD Spell Missions -->
		<br />
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="' . $this->theSkin->strCharModifyHeaderBGColor . '">
		  <tr>
			<td width= "8%"></td>
			<td width="84%" align="center"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Depths of Darkhollow</i></font></td>
			<td width= "8%" align="right"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>Show</i></font><input type="checkbox" name="cbDisplayDoDProgression" id="cbDisplayDoDProgression" onClick="DisplayDoDProgression();" value="' . $this->bShowDoDProgression . '" ' . GetCheckboxValue( $this->bShowDoDProgression ) . ' title="Show/hide the Depths of Darkhollow progress"></td>
		  </tr>
		</table>

		<div id="DoD_Progression">
		<table width="98%" border="0" cellspacing="0" cellpadding="0" bgcolor="' . $this->theSkin->strCharModifyHeaderBGColor . '">
		  <tr>
			<td width="1%"></td>
			<td width="16%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp Level 68 Spell</i></font></td>
			<td width="16%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp Level 69 Spell</i></font></td>
			<td width="16%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp Level 70 Spell</i></font></td>
			<td width="16%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp Elder Longshadow</i></font></td>
			<td width="16%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp Korlach Leviathan</i></font></td>
			<td width="16%"><font color="' . $this->theSkin->strCharModifyFontColor . '"><i>&nbsp Find Fibblebrap</i></font></td>
			<td width="1%"></td>
		  </tr>
		</table>

		<table width="98%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td width="1%"></td>
			<td width="16%"><input type="checkbox" name="cbA_Rogues_Trust"			value="1" ' . GetCheckboxValue( $this->theCharacter->nA_Rogues_Trust ) . '>A Rogue`s Trust</td>
			<td width="16%"><input type="checkbox" name="cbThe_Lost_Notebook"		value="1" ' . GetCheckboxValue( $this->theCharacter->nThe_Lost_Notebook ) . '>The Lost Notebook</td>
			<td width="16%"><input type="checkbox" name="cbPreemptive_Strike"		value="1" ' . GetCheckboxValue( $this->theCharacter->nPreemptive_Strike ) . '>Preemptive Strike</td>
			<td width="16%"><input type="checkbox" name="cbFreeing_an_Elder"		value="1" ' . GetCheckboxValue( $this->theCharacter->nFreeing_an_Elder ) . '>Freeing an Elder</td>
			<td width="16%"><input type="checkbox" name="cbThe_Search_for_Coral"	value="1" ' . GetCheckboxValue( $this->theCharacter->nThe_Search_for_Coral ) . '>The Search for Coral</td>
			<td width="16%"><input type="checkbox" name="cbThe_Mines"				value="1" ' . GetCheckboxValue( $this->theCharacter->nThe_Mines ) . '>The Mines</td>
			<td width="1%"></td>
		  </tr>
		  <tr>
			<td width="1%"></td>
			<td width="16%"><input type="checkbox" name="cbScouting_the_City"		value="1" ' . GetCheckboxValue( $this->theCharacter->nScouting_the_City ) . '>Scouting the City</td>
			<td width="16%"><input type="checkbox" name="cbCavern_Botany"			value="1" ' . GetCheckboxValue( $this->theCharacter->nCavern_Botany ) . '>Cavern Botany</td>
			<td width="16%"><input type="checkbox" name="cbPraetorian_Guard"		value="1" ' . GetCheckboxValue( $this->theCharacter->nPraetorian_Guard ) . '>Praetorian Guard</td>
			<td width="16%"><input type="checkbox" name="cbOrb_of_Subversion"		value="1" ' . GetCheckboxValue( $this->theCharacter->nOrb_of_Subversion ) . '>Orb of Subversion</td>
			<td width="16%"><input type="checkbox" name="cbLearning_the_Power"		value="1" ' . GetCheckboxValue( $this->theCharacter->nLearning_the_Power ) . '>Learning the Power</td>
			<td width="16%"><input type="checkbox" name="cbLost_Caverns"			value="1" ' . GetCheckboxValue( $this->theCharacter->nLost_Caverns ) . '>Lost Caverns</td>
			<td width="1%"></td>
		  </tr>
		  <tr>
			<td width="1%"></td>
			<td width="16%"><input type="checkbox" name="cbBuilding_the_Disguise"	value="1" ' . GetCheckboxValue( $this->theCharacter->nBuilding_the_Disguise ) . '>Building the Disguise</td>
			<td width="16%"><input type="checkbox" name="cbThe_Search_for_Clues"	value="1" ' . GetCheckboxValue( $this->theCharacter->nThe_Search_for_Clues ) . '>The Search for Clues</td>
			<td width="16%"><input type="checkbox" name="cbThe_Fall_of_Illsalin"	value="1" ' . GetCheckboxValue( $this->theCharacter->nThe_Fall_of_Illsalin ) . '>The Fall of Illsalin</td>
			<td width="16%"><input type="checkbox" name="cbA_Plea_for_Help"			value="1" ' . GetCheckboxValue( $this->theCharacter->nA_Plea_for_Help ) . '>A Plea for Help</td>
			<td width="16%"><input type="checkbox" name="cbDiscover_the_Secret"		value="1" ' . GetCheckboxValue( $this->theCharacter->nDiscover_the_Secret ) . '>Discover the Secret</td>
			<td width="16%"><input type="checkbox" name="cbThe_Hive"				value="1" ' . GetCheckboxValue( $this->theCharacter->nThe_Hive ) . '>The Hive</td>
			<td width="1%"></td>
		  </tr>
		  <tr>
			<td width="1%"></td>
			<td width="16%"><input type="checkbox" name="cbThe_Search_for_Illsuras"	value="1" ' . GetCheckboxValue( $this->theCharacter->nThe_Search_for_Illsuras ) . '>The Search for Illsuras</td>
			<td width="16%"><input type="checkbox" name="cbRescue_Cicero"			value="1" ' . GetCheckboxValue( $this->theCharacter->nRescue_Cicero ) . '>Rescue Cicero</td>
			<td width="16%"><input type="checkbox" name="cbFlights_of_the_Seeker"	value="1" ' . GetCheckboxValue( $this->theCharacter->nFlights_of_the_Seeker ) . '>Flights of the Seeker</td>
			<td width="16%"><input type="checkbox" name="cbTrailing_Longshadow"		value="1" ' . GetCheckboxValue( $this->theCharacter->nTrailing_Longshadow ) . '>Trailing Longshadow</td>
			<td width="16%"><input type="checkbox" name="cbTaking_Control"			value="1" ' . GetCheckboxValue( $this->theCharacter->nTaking_Control ) . '>Taking Control</td>
			<td width="16%"><input type="checkbox" name="cbThe_Korlach"				value="1" ' . GetCheckboxValue( $this->theCharacter->nThe_Korlach ) . '>The Korlach</td>
			<td width="1%"></td>
		  </tr>
		  <tr>
			<td width="1%"></td>
			<td width="16%"><input type="checkbox" name="cbThe_Rage_of_Kelliad"		value="1" ' . GetCheckboxValue( $this->theCharacter->nThe_Rage_of_Kelliad ) . '>The Rage of Kelliad</td>
			<td width="16%"></td>
			<td width="16%"><input type="checkbox" name="cbInto_the_Shadows"		value="1" ' . GetCheckboxValue( $this->theCharacter->nInto_the_Shadows ) . '>Into the Shadows</td>
			<td width="16%"><input type="checkbox" name="cbConfronting_a_Traitor"	value="1" ' . GetCheckboxValue( $this->theCharacter->nConfronting_a_Traitor ) . '>Confronting a Traitor<font color="' . $this->theSkin->strWarningColor . '">*</font></td>
			<td width="16%"></td>
			<td width="16%"><input type="checkbox" name="cbThe_Rescue"				value="1" ' . GetCheckboxValue( $this->theCharacter->nThe_Rescue ) . '>The Rescue<font color="' . $this->theSkin->strWarningColor . '">*</font></td>
			<td width="1%"></td>
		  </tr>
		</table>
		<font color="' . $this->theSkin->strWarningColor . '">Missions marked with a * are optional.</font>
		</div>


		<!-- Show/Hide the correct progressions -->
		<script language="JavaScript">
		  DisplayStatistics();
		  DisplayTradeskills();
		  DisplayKeysProgression();
		  DisplayPoPProgression();
		  DisplayGoDProgression();
		  DisplayOoW_CoAProgression();
		  DisplayDoNProgressionType();
		  DisplayDoNProgression();
		  DisplayDoDProgression();
		</script>

		<font color="' . $this->theSkin->strWarningColor . '">
			' . $strFooterMessage . '
		</font>
		<br />

		<br />
		<input type="submit" name="pbCancel" value="Cancel" onclick="CancelModify();">
		<input type="submit" name="pbModifyRecord" value="Modify Record" onclick="ValidateFields();">

		<!-- Hidden field to store CancelModify status -->
	    <input name="cbCancelModify" type="hidden" id="cbCancelModify" value="false">
		<!-- Hidden field to store Validation status -->
	    <input name="cbValidated" type="hidden" id="cbValidated" value="' . $this->bValidated . '">
		<!-- Hidden field to store Import mode -->
	    <input name="editImportMode" type="hidden" id="cbImportMode" value="' . IMPORTMODE_NONE . '" />
		<!-- Hidden field to store the CharID -->
		<input name="editCharID" type="hidden" value="' . $this->theCharacter->nCharID . '" />
		<!-- Hidden field to store EQPlayers Character ID -->
		<input name="editEQPlayersCharID" type="hidden" size="10" value="' . $this->theCharacter->nEQPlayersCharID . '" maxlength="20" />
		<!-- Hidden field to store LastOn date -->
		<input name="editLastOnDate" type="hidden" size="10" value="' . $this->theCharacter->strLastOnDate . '" maxlength="10" />

		</center>
		</div>
		<br />
	</form>
	<!-- End of Modify Character -->

';
	}



	// =============================================================================
	// Create a select box on a the Name Main field for all Mains
	// =============================================================================
	// Out:	$strResult	= The html code to create the select box
	function CreateNameMainSelect( $strSelectedNameMain, $strOffSet )
	{
		// Declare variables
		$strResult			= "";
		$strSelectQuery		= "SELECT DISTINCT NameMain \n" .
							  "FROM Characters \n" .
							  "WHERE NameMain = CharName \n" .
							  "   OR GuildStatus != 'Alt' \n" .
							  "ORDER BY NameMain \n";

		// Check if no default value was passed
		if( !isset( $strSelectedNameMain ) )
		{
			// Empty the field
			$strSelectedNameMain	= "";
		}
	
		// Connect to the database
		$nLinkID			= DBConnect();
	
		// Get the database fields
		$nResult			= mysql_query( $strSelectQuery, $nLinkID );
	
		// Create the combobox
		$strResult			= "<select name=\"cmbNameMain\" id=\"cmbNameMain\"><br />\n";	// $strOffSet is not used here, because we expect this function to be called at that offset.
	
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$strNameMain	= $aResult[0];
	
			// Create the option
			$strResult		.= "$strOffSet	<option value=\"" . $strNameMain . "\"";
			// Check if this is the default option
			if( $strNameMain == $strSelectedNameMain )
			{
				$strResult	.= " selected=\"selected\"";
			}
			// Finish the option
			$strResult		.= ">" . $strNameMain . "</option>\n";
		}

		// Finish the combobox
		$strResult			.= "$strOffSet</select>";
	
		// Close the connection
		DBDisconnect( $nLinkID );
	
		// Done, return the result
		return $strResult;
	}
}

?>
