<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );


// Main PHP code
{
	// Declare variables
	$strExtraArguments	= "";
	// Retrieve the cookie variables now
	$strCookieAction	= $_GET['CookieAction'];
	$strFormName		= $_GET['FormName'];
	$strUserName		= $_GET['UserName'];
	$strPassword		= $_GET['Password'];
	$strSortOrder		= $_GET['SortOrder'];
	$strSortDirection	= $_GET['SortDirection'];
	$strShowAlts		= $_GET['ShowAlts'];
	$strClassFilter		= $_GET['ClassFilter'];

	// Check if a cookie action was passed
	if( ( isset( $strCookieAction ) ) && 
		( $strCookieAction != "" ) )
	{
		// Perform the cookie action
		$strExtraArguments	= HandleCookieAction( strtoupper( $strCookieAction ), $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts );
	}

	// PHP5 with register_long_arrays off?
	if (!isset($HTTP_POST_VARS) && isset($_POST))
	{
		$HTTP_POST_VARS		= $_POST;
		$HTTP_GET_VARS		= $_GET;
	}

	// Get the arguments string
	$strArguments			= GetArgumentsString( $HTTP_GET_VARS, $HTTP_POST_VARS );

	// Add the extra arguments
	if( $strArguments != "" )
	{
		// Append the extra arguments
		$strArguments		.= $strExtraArguments;
	}
	else if( $strExtraArguments != "" )
	{
		// Store the extra arguments in the arguments string
		$strArguments		= $strExtraArguments;
		// Start with the ? mark (not the & sign)
		$strArguments[0]	= "?";
	}

	// Show the Frames
	echo '
<html>
<head>
	<title>EverQuest Roster</title>
	<link rel="stylesheet" href="' . GetSkinDir() . 'roster.css" type="text/css">

	<!-- Start of Create frames -->
	<frameset rows="42,*,45">
		<frame name="FormHeader" src="form_header.php?FormName=' . $strFormName . '&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection . '&ShowAlts=' . $strShowAlts . '&ClassFilter=' . $strClassFilter . '"	scrolling="auto" frameborder="0" noresize="noresize" marginheight="1" marginwidth="0" />
		<frame name="FormBody"   src="form_body.php' . $strArguments . '"																																																					scrolling="auto" frameborder="1" noresize="noresize" marginheight="1" marginwidth="0" />
		<frame name="FormFooter" src="form_footer.php?FormName=' . $strFormName . '&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection . '&ShowAlts=' . $strShowAlts . '&ClassFilter=' . $strClassFilter . '"	scrolling="auto" frameborder="1" noresize="noresize" marginheight="3" marginwidth="0" />
	</frameset>
	<!-- End of Create frames -->
</head>


<body>
</body>
</html>';
}



// =============================================================================
// Handle a cookie action
// =============================================================================
// In:	$strCookieAction	= String containing the cookie action to perform
// In:	&$strUserName		= Username												(passed by reference)
// In:	&$strPassword		= Password												(passed by reference)
// In:	&$strSortOrder		= Sort Order											(passed by reference)
// In:	&$strSortDirection	= Sort Direction										(passed by reference)
// In:	&$strShowAlts		= Show Alts setting										(passed by reference)
// Out:	$strExtraArguments	= String containing extra arguments for the next form
function HandleCookieAction( $strCookieAction, &$strUserName, &$strPassword, &$strSortOrder, &$strSortDirection, &$strShowAlts )
{
	// Declare variables
	$strExtraArguments	= "";

	// Check if we should read the cookie
	if( $strCookieAction == "READ" )
	{
		$strCookieValues	= ReadCookie();

		// Verify the UserName&Password
		if( ( $strCookieValues[0] != "" ) ||
			( CheckPassword( $strCookieValues[0], $strCookieValues[1] ) ) )
		{
			$strUserName		= $strCookieValues[0];
			$strPassword		= $strCookieValues[1];
			$strSortOrder		= $strCookieValues[2];
			$strSortDirection	= $strCookieValues[3];
			$strShowAlts		= $strCookieValues[4];

			// Store the variables, either in the $_GET or in a Extra Arguments string
			if( isset( $_GET['UserName'] ) )
			{
				$_GET['UserName']		= $strUserName;
			}
			else
			{
				$strExtraArguments		.= "&UserName=" . $strUserName;
			}

			if( isset( $_GET['Password'] ) )
			{
				$_GET['Password']		= $strPassword;
			}
			else
			{
				$strExtraArguments		.= "&Password=" . $strPassword;
			}

			if( isset( $_GET['SortOrder'] ) )
			{
				$_GET['SortOrder']		= $strSortOrder;
			}
			else
			{
				$strExtraArguments		.= "&SortOrder=" . $strSortOrder;
			}

			// Store the variables
			if( isset( $_GET['SortDirection'] ) )
			{
				$_GET['SortDirection']	= $strSortDirection;
			}
			else
			{
				$strExtraArguments		.= "&SortDirection=" . $strSortDirection;
			}

			// Store the variables
			if( isset( $_GET['ShowAlts'] ) )
			{
				$_GET['ShowAlts']		= $strShowAlts;
			}
			else
			{
				$strExtraArguments		.= "&ShowAlts=" . $strShowAlts;
			}

			// Write the cookie, so the cookie is valid for another 30 days
			$strCookieAction	= "WRITE";
		}
		else
		{
			// Delete the bad cookie
			$strCookieAction	= "DELETE";
		}
	}
	// Check if we should write the cookie
	if( $strCookieAction == "WRITE" )
	{
		// Convert empty SortDirection into "ASC", otherwise it won't save
		if( $strSortDirection == "" )
		{
			$strSortDirection	= "ASC";
		}
		
		// Write the cookie
		WriteCookie( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts );
	}
	// Check if we should delete the cookie
	else if( $strCookieAction == "DELETE" )
	{
		// Delete the cookie
		DeleteCookie();
	}

	// Return the extra arguments
	return $strExtraArguments;
}



// =============================================================================
// Create a string containing the argument string that was passed into a php file
// =============================================================================
// This function will create a long string that can be attached to a
// .php file to pass on all GET and POST arguments.
//
// Usage:
//	// Get the arguments string
//	$strArguments	= GetArgumentsString( $HTTP_GET_VARS, $HTTP_POST_VARS );
//	// Create the URL
//	$strURL			= "form_body.php" . $strArguments;
//
// Notice: All POST variables will be extracted from the submitted form, and
//         passed on as GET variables.
// =============================================================================
// In:	$aGetVars		= Array containing all the gets ($HTTP_GET_VARS)
// In:	$aPostVars		= Array containing all the posts ($HTTP_POST_VARS)
// Out:	$strArguments	= String containing all the arguments and their values
function GetArgumentsString( &$aGetVars, &$aPostVars )
{
	// Declare variables
	$strArguments	= "";
	$strSeperator	= "?";

	// For each GET argument...
	if( !empty($aGetVars) )
	{
		foreach ( $aGetVars as $strGetVar => $strValue )
		{
			// Add the argument to the argument list
			$strArguments		.= "$strSeperator$strGetVar=$strValue";
	
			// Check if this was the first argument
			if( $strSeperator == "?" )
			{
				$strSeperator	= "&";
			}
		}
	}

	// For each POST argument...
	if( !empty($aPostVars) )
	{
		foreach( $aPostVars as $strPostVar => $strValue )
		{
			// Add the argument to the argument list
			$strArguments		.= "$strSeperator$strPostVar=$strValue";
	
			// Check if this was the first argument
			if( $strSeperator == "?" )
			{
				$strSeperator	= "&";
			}
		}
	}

	// Return the Arguments string
	return $strArguments;
}

?>
