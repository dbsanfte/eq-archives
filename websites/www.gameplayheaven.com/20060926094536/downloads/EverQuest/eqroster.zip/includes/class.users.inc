<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );
require_once( GetSkinDir() . 'class.skin.inc' );


// ============================================================================
// The Users class
// ============================================================================
// This class provides an interface to the User table
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class Users
{
	// Member variables
	var $theSkin;

	// ========================================================================
	// Constructor
	// ========================================================================
	function Users()
	{
		// Create the skin
		$this->theSkin	= new Skin();
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "Users";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<div id="Header">
		<br />
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td width= "5%"></td>
			<td width="10%">				<b><a href="form.php?FormName=Characters&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 		'&SortOrder=UserName&SortDirection='		. GetSortDirection( $strSortOrder, "CharName",		$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '&CookieAction=WRITE"	OnMouseOver="window.status=\'Sort by Name\';return true;"					OnMouseOut="window.status=\'\'"	target=Body title="Name"							>Name</a></b></td>
			<td width="30%">				<b><a href="form.php?FormName=Characters&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 		'&SortOrder=EMailAddress&SortDirection='	. GetSortDirection( $strSortOrder, "EMailAddress",	$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '&CookieAction=WRITE"	OnMouseOver="window.status=\'Sort by E-Mail Address\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="E-Mail Address"					><img src="' . GetSkinDir() . 'images/email.gif" border="0" alt="EMail"> E-Mail address</a></b></td>
			<td width="15%">				<b><a href="form.php?FormName=Characters&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 		'&SortOrder=ShowEMail&SortDirection='		. GetSortDirection( $strSortOrder, "ShowEMail",		$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '&CookieAction=WRITE"	OnMouseOver="window.status=\'Sort by Show E-Mail\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Show E-Mail"						>Show E-Mail</a></b></td>
			<td width="10%">				<b><a href="form.php?FormName=Characters&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 		'&SortOrder=TimeZone&SortDirection='		. GetSortDirection( $strSortOrder, "TimeZone",		$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '&CookieAction=WRITE"	OnMouseOver="window.status=\'Sort by Time Zone\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Time Zone"						>Time Zone</a></b></td>
			<td width="10%" align="center">	<b><a href="form.php?FormName=Characters&UserName=' . $strUserName . '&Password=' . $strPassword . '&ShowAlts=' . $strShowAlts . 		'&SortOrder=Verified&SortDirection='		. GetSortDirection( $strSortOrder, "Verified",		$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '&CookieAction=WRITE"	OnMouseOver="window.status=\'Sort by Verified\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Verified"						>Verified</a></b></td>
			<td width= "5%" align="center">	<img src="' . GetSkinDir() . 'images/show_all.gif" border="0" alt="Chars"																																																																	OnMouseOver="window.status=\'Nr of Characters in the guild\';return true;"	OnMouseOut="window.status=\'\'"             title="Nr of Characters in the guild"	/></td>
			<td width="15%"></td>
		  </tr>
		</table>
		</div>
		<!-- End of Header -->
		';
	}
	
	
	
	// ========================================================================
	// Show all the records on screen
	// ========================================================================
	// This function will loop through all the records in the database table,
	// and create a html table entry for each one of them.
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS		= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];
		$strClassFilter		= $_GET['ClassFilter'];

		// Declare variables
		$bAdministrator		= IsAdministrator( $strUserName );
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT UserID, UserName, EMailAddress, ShowEMail, TimeZone, Verified FROM Users ";

		// Check if we should use the default sort order
		if( ( !isset( $strSortOrder ) ) ||
			( $strSortOrder == "" ) )
		{
			// Default sort on Character name
			$strSortOrder	= "UserName"; 
		}

		// Sorting on E-Mail Address should be reversed (Desc first, then Asc)
		$strModifiedSortDirection	= $strSortDirection;
		if( $strSortOrder == "EMailAddress" )
		{
			// Switch the sort order around
			if( $strModifiedSortDirection == "DESC" )
			{
				$strModifiedSortDirection	= "";
			}
			else
			{
				$strModifiedSortDirection	= "DESC";
			}
		}
	
		// Add the sort order
		$strSelectQuery		.= "ORDER BY " . $strSortOrder . " " . $strModifiedSortDirection . ", UserName \n";
	
		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
		<div id="Body">
		<table id="RosterTable" width="100%" border="0" cellpadding="0" cellspacing="0">
		';
	
		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex				= 0;
			$nUserID			= $aResult[$nIndex++];
			$strDBUserName		= $aResult[$nIndex++];
			$strEMailAddress	= $aResult[$nIndex++];
			$strShowEMail		= $aResult[$nIndex++];
			$strTimeZone		= $aResult[$nIndex++];
			$strVerified		= $aResult[$nIndex++];
	
			// Only show old members for the administrator
			if( ( $nOldMember == 0 ) ||
				( $bAdministrator == true ) )
			{
				// Declare the count statement
				$strCountQuery	= "SELECT Count(*) FROM Characters WHERE UserID = '$nUserID'";

				// Retrieve the nr of active members
				$nCountResult	= mysql_query( $strCountQuery, $nLinkID );
				$aCountResult	= mysql_fetch_row( $nCountResult );
				// Store the nr of active members
				if( isset( $aCountResult[0] ) )
				{
					$nNrOfCharacters	= $aCountResult[0];
				}

				// Show the user
				$this->ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter, $strDBUserName, $strEMailAddress, $strShowEMail, $strTimeZone, $strVerified, $nNrOfCharacters, $strRowType, $bAdministrator );
	
				// Switch RowType, so the rows alternate	
				if( $strRowType == "OddRow" )
				{
					$strRowType	= "EvenRow";
				}
				else
				{
					$strRowType	= "OddRow";
				}
			}
		}
	
		// End the character table
		echo '
		</table>
		</div>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );
	}
	
	
	
	// ========================================================================
	// Show a record
	// ========================================================================
	// This function will create a html table row for a record in the table
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// In:  Variables containing the data to show 
	// ========================================================================
	function ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter, $strDBUserName, $strEMailAddress, $strShowEMail, $strTimeZone, $strVerified, $nNrOfCharacters, $strRowType, $bAdministrator )
	{
		// Check the EMail
		$strFullEMail		= "";
		if( isset( $strEMailAddress ) )
		{
			// Check if the address should be viewable
			if( ( $strShowEMail == "Always" ) ||
				( $bAdministrator == true ) ||
				( ( $strShowEMail == "Members Only" ) &&
				  ( isset( $strUserName ) ) &&
				  ( $strUserName != "" ) ) )
			{
				$strFullEMail	= '<a href="mailto:' . $strEMailAddress . '"	OnMouseOver="window.status=\'Send E-Mail to ' . $strDBUserName . '\';return true;"	OnMouseOut="window.status=\'\'" title="Send E-Mail to ' . $strDBUserName . '"><img src="' . GetSkinDir() . 'images/email.gif" border="0" /></a>';
			}
			// Check if the address is viewable by members only
			else if( ( $strShowEMail == "Members Only" ) &&
					 ( ( !isset( $strUserName ) ) ||
					   ( $strUserName == "" ) ) )
			{
				$strFullEMail	= '<img src="' . GetSkinDir() . 'images/email_private.gif" border="0" OnMouseOver="window.status=\'' . $strDBUserName . '\\\'s E-Mail is viewable by members only\';return true;"	OnMouseOut="window.status=\'\'" title="' . $strDBUserName . '\'s E-Mail is viewable by members only"/>';
			}
			// Private address
			else
			{
				$strFullEMail	= '<img src="' . GetSkinDir() . 'images/email_private.gif" border="0" OnMouseOver="window.status=\'' . $strDBUserName . '\\\'s E-Mail is private\';return true;"	OnMouseOut="window.status=\'\'" title="' . $strDBUserName . '\'s E-Mail is private"/>';
			}
			
			// Add the actual E-Mail address
			$strFullEMail		.= " " . $strEMailAddress;
		}
	
		// Check if this character belongs to the logged in User
		$strModify	= "";
		if( ( isset( $strUserName ) ) &&
			( isset( $strDBUserName ) ) &&
			( $strUserName == $strDBUserName ) )
		{
			$strModify	= '<a href="form.php?FormName=User_Modify&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&ModifyUserName='	. $strUserName		. '&PreviousForm=Users&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strUserName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strUserName . '\'s information"><img src="' . GetSkinDir() . 'images/modify.gif" border="0" /></a>';
		}
		else if( $bAdministrator == true )
		{
			$strModify	= '<a href="form.php?FormName=User_Modify&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&ModifyUserName='	. $strDBUserName	. '&PreviousForm=Users&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strDBUserName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strDBUserName . '\'s information"><img src="' . GetSkinDir() . 'images/modify_others.gif" border="0" /></a>';
		}

		// Allow deletion of users
		$strDelete		= ' <a href="form.php?FormName=User_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&DeleteUserName='	. $strDBUserName	. '&PreviousForm=Users&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Delete ' . $strDBUserName . '\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Delete ' . $strDBUserName . '"><img src="' . GetSkinDir() . 'images/delete.gif" border="0" /></a>';

		// Allow user verify
		$strVerify	= "";
		if( $strVerified == "No" )
		{
			$strVerificationCode	= Encrypt( strtoupper( $strDBUserName . $strEMailAddress ) );
			$strVerify				= ' <a href="form.php?FormName=User_Verify&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strDBUserName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&VerifyUserName=' . $strDBUserName . '&editVerificationCode=' . $strVerificationCode . '&PreviousForm=Users&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Verify ' . $strDBUserName . '\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Verify ' . $strDBUserName . '"><img src="' . GetSkinDir() . 'images/check.gif" border="0" /></a>';
		}
		else
		{
			$strVerified .= "  ";
		}
	
		echo '
		  <tr	onMouseOver="this.bgColor=\'' . $this->theSkin->strRowHighlightColor . '\'" onMouseOut="this.bgColor=\'\'">
			<td width= "5%" align="center">'								. $strModify . $strDelete	. '</td>
			<td width="10%" class="' . $strRowType . '">'					. $strDBUserName			. '</td>
			<td width="30%" class="' . $strRowType . '">'					. $strFullEMail				. '</td>
			<td width="15%" class="' . $strRowType . '">'					. $strShowEMail				. '</td>
			<td width="10%" class="' . $strRowType . '">'					. $strTimeZone				. '</td>
			<td width="10%" class="' . $strRowType . '" align="center">'	. $strVerified . $strVerify	. '</td>
			<td width= "5%" class="' . $strRowType . '" align="center">'	. $nNrOfCharacters			. '</td>
			<td width="15%"></td>
		  </tr>
		';
	}

}

?>
