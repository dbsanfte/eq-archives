<?php
// Includes
require_once( './config.php' );
require_once( './includes/class.eqplayers.inc' );
require_once( './includes/class.magelo.inc' );
require_once( './includes/functions.inc' );
require_once( GetSkinDir() . 'class.skin.inc' );


// ============================================================================
// The Character class
// ============================================================================
// This is a container class for all Character data
//
// Usage:
// Create an object of this class, and use it's member variables
// ============================================================================
class Character
{
	// Member variables
	var $theSkin;
		// Character info
	var $nCharID							= -1;
	var $strCharName						= "";
	var $strLastName						= "";
	var $strNameMain						= "";
	var $strGuildStatus						= "";
	var $strClass							= "";
	var $nLevel								= 0;
	var $nAA								= 0;
	var $nGLP								= 0;
	var $strRace							= "";
	var $strGender							= "";
	var $nEQPlayersCharID					= 0;
	var $nMageloNr							= 0;
	var $strLastOnDate						= "";
		// Character Statistics
	var $nHP								= 0;
	var $nMana								= 0;
	var $nEndurance							= 0;
	var $nAC								= 0;
	var $nFT								= 0;
	var $nRegen								= 0;
	var $nAtk								= 0;
	var $nStr								= 0;
	var $nSta								= 0;
	var $nAgi								= 0;
	var $nDex								= 0;
	var $nWis								= 0;
	var $nInt								= 0;
	var $nCha								= 0;
	var $nPR								= 0;
	var $nMR								= 0;
	var $nDR								= 0;
	var $nFR								= 0;
	var $nCR								= 0;
		// DoD_Flags
	var $nA_Rogues_Trust					= 0;
	var $nScouting_the_City					= 0;
	var $nBuilding_the_Disguise				= 0;
	var $nThe_Search_for_Illsuras			= 0;
	var $nThe_Rage_of_Kelliad				= 0;
	var $nThe_Lost_Notebook					= 0;
	var $nCavern_Botany						= 0;
	var $nThe_Search_for_Clues				= 0;
	var $nRescue_Cicero						= 0;
	var $nPreemptive_Strike					= 0;
	var $nPraetorian_Guard					= 0;
	var $nThe_Fall_of_Illsalin				= 0;
	var $nFlights_of_the_Seeker				= 0;
	var $nInto_the_Shadows					= 0;
	var $nFreeing_an_Elder					= 0;
	var $nOrb_of_Subversion					= 0;
	var $nA_Plea_for_Help					= 0;
	var $nTrailing_Longshadow				= 0;
	var $nConfronting_a_Traitor				= 0;
	var $nThe_Search_for_Coral				= 0;
	var $nLearning_the_Power				= 0;
	var $nDiscover_the_Secret				= 0;
	var $nTaking_Control					= 0;
	var $nThe_Mines							= 0;
	var $nLost_Caverns						= 0;
	var $nThe_Hive							= 0;
	var $nThe_Korlach						= 0;
	var $nThe_Rescue						= 0;
		// DoN_Flags
	var $nT1_Create_an_Antidote				= 0;
	var $nT1_Greed_of_the_Goblins			= 0;
	var $nT1_Burning_Arrows					= 0;
	var $nT1_Children_of_Gimblax			= 0;
	var $nT2_Defend_the_Kirin_Contact		= 0;
	var $nT2_Recover_the_Lost_Map			= 0;
	var $nT2_Turn_the_Tides_of_the_Sand		= 0;
	var $nT2_Sickness_of_the_Spirit			= 0;
	var $nT2_Calling_Emoush					= 0;
	var $nT3_Protect_the_Waters				= 0;
	var $nT3_Snowfoots_Revenge				= 0;
	var $nT3_The_Sacred_Scrolls				= 0;
	var $nT3_History_of_the_Isle			= 0;
	var $nT3_Trial_of_Perserverance			= 0;
	var $nT3_Volkaras_Bite					= 0;
	var $nT4_Goblin_Dojo					= 0;
	var $nT4_Guardian_of_the_Sands			= 0;
	var $nT4_An_End_to_the_Storms			= 0;
	var $nT5_Origins_of_the_Curse			= 0;
	var $nT5_The_Curse_of_JuRek				= 0;
	var $nT5_In_the_Shadows					= 0;
		// GoD_Flags
	var $nPurifying_Plant					= 0;
	var $nEmanating_Furnace					= 0;
	var $nLair_of_Trapped_Ones				= 0;
	var $nPool_of_Sludge					= 0;
	var $nSmith_Rondo						= 0;
	var $nVxed								= 0;
	var $nTipt								= 0;
	var $nVrex_Barxt_Qurat					= 0;
	var $nKeeper_of_the_Altar				= 0;
	var $nNoqufiel_in_Inktuta				= 0;
	var $nCynosure_Kvanjji					= 0;
	var $nIxt_Hsek_Syat						= 0;
	var $nHigh_Priest_Nkosi_Bakari			= 0;
	var $nZunMuram_Tkarish_Zyk				= 0;
		// Keys
	var $nBoT_Tower_Key						= 0;
	var $nHowling_Stones_Key				= 0;
	var $nSebilis_Key						= 0;
	var $nSleepers_Tomb_Key					= 0;
	var $nSSRA_Emperor_Key					= 0;
	var $nVeeshans_Peak_Key					= 0;
	var $nVex_Thal_Key						= 0;
		// OoW_CoA
	var $nMastery_of_Adaptation				= 0;
	var $nMastery_of_Corruption				= 0;
	var $nMastery_of_Endurance				= 0;
	var $nMastery_of_Foresight				= 0;
	var $nMastery_of_Hate					= 0;
	var $nMastery_of_Specialization			= 0;
	var $nSeal_Mastery_of_All				= 0;
	var $nSignet_Crystal_Gemmed				= 0;
	var $nSignet_Discolored					= 0;
	var $nSignet_Dust_Marred				= 0;
	var $nSignet_Glimmering					= 0;
	var $nSignet_Tarnished					= 0;
	var $nSignet_Two_Toned					= 0;
	var $nSignet_Weather_Worn				= 0;
		// Pop_Tier_1_Flags
	var $nAny_PoJ_Trial						= 0;
	var $nAll_PoJ_Trials					= 0;
	var $nPoI_Xanamech						= 0;
	var $nPoI_Behemoth						= 0;
	var $nPoD_Grimror_Quest					= 0;
	var $nPoD_Grummus						= 0;
	var $nPoN_Hedge_Quest					= 0;
	var $nPoNb_Terris_Thule					= 0;
		// Pop_Tier_2_Flags
	var $nPoS_Askr_Quest					= 0;
	var $nPoV_Grenic_Quest					= 0;
	var $nPoV_AerinDar						= 0;
	var $nCoD_Carprin_Event					= 0;
	var $nCoD_Bertoxxulous					= 0;
	var $nPoTorment_Saryrn					= 0;
	var $nPoS_Wembly_Quest					= 0;
		// Pop_Tier_3_Flags
	var $nHoH_Trial1_RyddaDar				= 0;
	var $nHoH_Trial2_Ogre					= 0;
	var $nHoH_Trial3_Madmen					= 0;
	var $nHoHb_Mithanial_Marr				= 0;
	var $nPoTactics_Tallon_Zek				= 0;
	var $nPoTactics_Vallon_Zek				= 0;
	var $nPoTactics_Rallos_Zek_Quest		= 0;
	var $nBoT_Rescue_Karana_Quest			= 0;
	var $nSolRoTower_Jiva					= 0;
	var $nSolRoTower_Xuzl					= 0;
	var $nSolRoTower_Arlyxir				= 0;
	var $nSolRoTower_Rizlona				= 0;
	var $nSolRoTower_Protector_of_Dresolik	= 0;
	var $nSolRoTower_Solusek_Ro				= 0;
		// Pop_Tier_4_Flags
	var $nPoAir_Xegony						= 0;
	var $nPoFire_Fennin_Ro					= 0;
	var $nPoWater_Coirnav					= 0;
	var $nPoEarthb_The_Rathe				= 0;
	var $nPoTime_Time_Phased_Quintessence	= 0;
		// PoS_Askr_Quest (BoT flag)
	var $nHead								= 0;
	var $nBeard								= 0;
	var $nBone								= 0;
	var $nSash								= 0;
	var $nOceanMedal						= 0;
	var $nDesertMedal						= 0;
	var $nForestMedal						= 0;
		// SSRA_Emperor_key
	var $nTaskmasters_Pouch					= 0;
	var $nZazuzhs_Idol						= 0;
	var $nRing								= 0;
	var $nInsignia							= 0;
		// TradeSkills
	var $nAlchemy							= 0;
	var $nBaking							= 0;
	var $nBrewing							= 0;
	var $nFishing							= 0;
	var $nFletching							= 0;
	var $nForaging							= 0;
	var $nJewelcraft						= 0;
	var $nPoison							= 0;
	var $nPottery							= 0;
	var $nResearch							= 0;
	var $nSmithing							= 0;
	var $nTailoring							= 0;
	var $nTinkering							= 0;
		// Veeshans_Peek_key
	var $nKylongMedal_Top					= 0;
	var $nKylongMedal_Middle				= 0;
	var $nKylongMedal_Bottom				= 0;
	var $nJarsathMedal_Top					= 0;
	var $nJarsathMedal_Middle				= 0;
	var $nJarsathMedal_Bottom				= 0;
	var $nObulusMedal_Top					= 0;
	var $nObulusMedal_Middle				= 0;
	var $nObulusMedal_Bottom				= 0;
	var $nTrak_Tooth						= 0;
		// Vex_Thal_key
	var $nGlowing_Orb						= 0;
	var $nCelestial_Rift					= 0;
	var $nShard_Dat							= 0;
	var $nShard_Dax							= 0;
	var $nShard_Kel							= 0;
	var $nShard_Kelara						= 0;
	var $nShard_Lor							= 0;
	var $nShard_Raf							= 0;
	var $nShard_Set							= 0;
	var $nShard_Tak							= 0;
	var $nShard_Ved							= 0;
	var $nShard_Vin							= 0;



	// ========================================================================
	// Constructor
	// ========================================================================
	function Character()
	{
		// Create the skin
		$this->theSkin	= new Skin();
	}



	// ========================================================================
	// Retrieve a Character's CharID
	// ========================================================================
	// In:  strCharName	= Name of character whomes CharID we need to find
	// Out: nCharID		= CharID of character
	function GetCharID( $strCharName )
	{
		// Declare variables
		$strSelectQuery		= "SELECT CharID FROM Characters WHERE CharName = '$strCharName'";
		$nCharID			= -1;

		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Retrieve the record
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		if( $nResult == FALSE )
		{
			print( "	<font color=\"" . $this->theSkin->strErrorColor . "\"><a>Couldn't find the CharID for char '$strCharName'! (" . mysql_error() . ")</a></font><br />\n" );
		}
		else
		{
			// Fetch the record
			$aResult	= mysql_fetch_row( $nResult );
		}
	
		// Close the connection
		DBDisconnect( $nLinkID );
	
	    if( $aResult ) 
		{
			// Retrieve the CharID out of the array
			$nCharID	= $aResult[0];
		}

		// Done
		return $nCharID;
	}



	// ========================================================================
	// Retrieve all Character data from the Database tables
	// ========================================================================
	function GetAllDataFromDatabase()
	{
		// Make sure the CharID is known
		if( $this->nCharID < 0 )
		{
			$this->nCharID	= $this->GetCharID( $this->strCharName );
		}

		// Declare variables
		$bSucces			= false;
		$strSelectQuery		= "SELECT	CharName, LastName, NameMain, Class, Race, Gender, Level, AA, GLP, EQPlayersCharID, MageloNr, GuildStatus, LastOn, \n" .
							  "         HP, Mana, Endurance, AC, FlowingThought, Regen, Atk, Str, Sta, Agi, Dex, Wis, `Int`, Cha, PR, MR, DR, FR, CR, \n" .
							  "			A_Rogues_Trust, Scouting_the_City, Building_the_Disguise, The_Search_for_Illsuras, The_Rage_of_Kelliad, The_Lost_Notebook, Cavern_Botany, The_Search_for_Clues, Rescue_Cicero, Preemptive_Strike, Praetorian_Guard, The_Fall_of_Illsalin, Flights_of_the_Seeker, Into_the_Shadows, Freeing_an_Elder, Orb_of_Subversion, A_Plea_for_Help, Trailing_Longshadow, Confronting_a_Traitor, The_Search_for_Coral, Learning_the_Power, Discover_the_Secret, Taking_Control, The_Mines, Lost_Caverns, The_Hive, The_Korlach, The_Rescue,  \n" .
							  "         T1_Create_an_Antidote, T1_Greed_of_the_Goblins, T1_Burning_Arrows, T1_Children_of_Gimblax, T2_Defend_the_Kirin_Contact, T2_Recover_the_Lost_Map, T2_Turn_the_Tides_of_the_Sand, T2_Sickness_of_the_Spirit, T2_Calling_Emoush, T3_Protect_the_Waters, T3_Snowfoots_Revenge, T3_The_Sacred_Scrolls, T3_History_of_the_Isle, T3_Trial_of_Perserverance, T3_Volkaras_Bite, T4_Goblin_Dojo, T4_Guardian_of_the_Sands, T4_An_End_to_the_Storms, T5_Origins_of_the_Curse, T5_The_Curse_of_JuRek, T5_In_the_Shadows, \n" .
							  "         Purifying_Plant, Emanating_Furnace, Lair_of_Trapped_Ones, Pool_of_Sludge, Smith_Rondo, Vxed, Tipt, Vrex_Barxt_Qurat, Keeper_of_the_Altar, Noqufiel_in_Inktuta, Cynosure_Kvanjji, Ixt_Hsek_Syat, High_Priest_Nkosi_Bakari, ZunMuram_Tkarish_Zyk, \n" .
							  "         BoT_Tower_Key, Howling_Stones_Key, Sebilis_Key, Sleepers_Tomb_Key, SSRA_Emperor_Key, Veeshans_Peak_Key, Vex_Thal_Key, \n" .
							  "         Mastery_of_Adaptation, Mastery_of_Corruption, Mastery_of_Endurance, Mastery_of_Foresight, Mastery_of_Hate, Mastery_of_Specialization, Seal_Mastery_of_All, Signet_Crystal_Gemmed, Signet_Discolored, Signet_Dust_Marred, Signet_Glimmering, Signet_Tarnished, Signet_Two_Toned, Signet_Weather_Worn, \n" .
							  "         Any_PoJ_Trial, All_PoJ_Trials, PoI_Xanamech, PoI_Behemoth, PoD_Grimror_Quest, PoD_Grummus, PoN_Hedge_Quest, PoNb_Terris_Thule, \n" .
							  "         PoS_Askr_Quest, PoV_Grenic_Quest, PoV_AerinDar, CoD_Carprin_Event, CoD_Bertoxxulous, PoTorment_Saryrn, PoS_Wembly_Quest, \n" .
							  "         HoH_Trial1_RyddaDar, HoH_Trial2_Ogre, HoH_Trial3_Madmen, HoHb_Mithanial_Marr, PoTactics_Tallon_Zek, PoTactics_Vallon_Zek, PoTactics_Rallos_Zek_Quest, BoT_Rescue_Karana_Quest, SolRoTower_Jiva, SolRoTower_Xuzl, SolRoTower_Arlyxir, SolRoTower_Rizlona, SolRoTower_Protector_of_Dresolik, SolRoTower_Solusek_Ro, \n" .
							  "         PoAir_Xegony, PoFire_Fennin_Ro, PoWater_Coirnav, PoEarthb_The_Rathe, PoTime_Time_Phased_Quintessence, \n" .
							  "         Head, Beard, Bone, Sash, OceanMedal, DesertMedal, ForestMedal, \n" .
							  "         Taskmasters_Pouch, Zazuzhs_Idol, Ring, Insignia, \n" .
							  "         Alchemy, Baking, Brewing, Fishing, Fletching, Foraging, Jewelcraft, Poison, Pottery, Research, Smithing, Tailoring, Tinkering, \n" .
							  "         KylongMedal_Top, KylongMedal_Middle, KylongMedal_Bottom, JarsathMedal_Top, JarsathMedal_Middle, JarsathMedal_Bottom, ObulusMedal_Top, ObulusMedal_Middle, ObulusMedal_Bottom, Trak_Tooth, \n" .
							  "         Glowing_Orb, Celestial_Rift, Shard_Dat, Shard_Dax, Shard_Kel, Shard_Kelara, Shard_Lor, Shard_Raf, Shard_Set, Shard_Tak, Shard_Ved, Shard_Vin \n" .
							  "FROM Characters \n" .
							  "LEFT JOIN DoD_Flags			ON (Characters.CharID = DoD_Flags.CharID) \n" .
							  "LEFT JOIN DoN_Flags			ON (Characters.CharID = DoN_Flags.CharID) \n" .
							  "LEFT JOIN GoD_Flags			ON (Characters.CharID = GoD_Flags.CharID) \n" .
							  "LEFT JOIN `Keys`				ON (Characters.CharID = `Keys`.CharID) \n" .
							  "LEFT JOIN OoW_CoA			ON (Characters.CharID = OoW_CoA.CharID) \n" .
							  "LEFT JOIN PoP_Tier_1_Flags	ON (Characters.CharID = PoP_Tier_1_Flags.CharID) \n" .
							  "LEFT JOIN PoP_Tier_2_Flags	ON (Characters.CharID = PoP_Tier_2_Flags.CharID) \n" .
							  "LEFT JOIN PoP_Tier_3_Flags	ON (Characters.CharID = PoP_Tier_3_Flags.CharID) \n" .
							  "LEFT JOIN PoP_Tier_4_Flags	ON (Characters.CharID = PoP_Tier_4_Flags.CharID) \n" .
							  "LEFT JOIN PoS_Askr_Quest		ON (Characters.CharID = PoS_Askr_Quest.CharID) \n" .
							  "LEFT JOIN SSRA_Emperor_Key	ON (Characters.CharID = SSRA_Emperor_Key.CharID) \n" .
							  "LEFT JOIN TradeSkills		ON (Characters.CharID = TradeSkills.CharID) \n" .
							  "LEFT JOIN Veeshans_Peak_Key	ON (Characters.CharID = Veeshans_Peak_Key.CharID) \n" .
							  "LEFT JOIN Vex_Thal_Key		ON (Characters.CharID = Vex_Thal_Key.CharID) \n" .
							  "WHERE Characters.CharID = '$this->nCharID' \n";

		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Retrieve the record
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		if( $nResult == FALSE )
		{
			print( "	<font color=\"" . $this->theSkin->strErrorColor . "\"><a>Couldn't select data for char '$this->nCharID:$this->strCharName'! (" . mysql_error() . ")</a></font><br />\n" );
		}
		else
		{
			// Fetch the record
			$aResult	= mysql_fetch_row( $nResult );
		}
	
		// Close the connection
		DBDisconnect( $nLinkID );
	
	    if( $aResult ) 
		{
			// Retrieve the variables out of the array
			$nIndex										= 0;
				// Characters
			$this->strCharName							= $aResult[$nIndex++];
			$this->strLastName							= $aResult[$nIndex++];
			$this->strNameMain							= $aResult[$nIndex++];
			$this->strClass								= $aResult[$nIndex++];
			$this->strRace								= $aResult[$nIndex++];
			$this->strGender							= $aResult[$nIndex++];
			$this->nLevel								= $aResult[$nIndex++];
			$this->nAA									= $aResult[$nIndex++];
			$this->nGLP									= $aResult[$nIndex++];
			$this->nEQPlayersCharID						= $aResult[$nIndex++];
			$this->nMageloNr							= $aResult[$nIndex++];
			$this->strGuildStatus						= $aResult[$nIndex++];
			$this->strLastOnDate						= $aResult[$nIndex++];
				// Character Statistics
			$this->nHP									= $aResult[$nIndex++];
			$this->nMana								= $aResult[$nIndex++];
			$this->nEndurance							= $aResult[$nIndex++];
			$this->nAC									= $aResult[$nIndex++];
			$this->nFT									= $aResult[$nIndex++];
			$this->nRegen								= $aResult[$nIndex++];
			$this->nAtk									= $aResult[$nIndex++];
			$this->nStr									= $aResult[$nIndex++];
			$this->nSta									= $aResult[$nIndex++];
			$this->nAgi									= $aResult[$nIndex++];
			$this->nDex									= $aResult[$nIndex++];
			$this->nWis									= $aResult[$nIndex++];
			$this->nInt									= $aResult[$nIndex++];
			$this->nCha									= $aResult[$nIndex++];
			$this->nPR									= $aResult[$nIndex++];
			$this->nMR									= $aResult[$nIndex++];
			$this->nDR									= $aResult[$nIndex++];
			$this->nFR									= $aResult[$nIndex++];
			$this->nCR 									= $aResult[$nIndex++];
				// DoD Spells
			$this->nA_Rogues_Trust						= $aResult[$nIndex++];
			$this->nScouting_the_City					= $aResult[$nIndex++];
			$this->nBuilding_the_Disguise				= $aResult[$nIndex++];
			$this->nThe_Search_for_Illsuras				= $aResult[$nIndex++];
			$this->nThe_Rage_of_Kelliad					= $aResult[$nIndex++];
			$this->nThe_Lost_Notebook					= $aResult[$nIndex++];
			$this->nCavern_Botany						= $aResult[$nIndex++];
			$this->nThe_Search_for_Clues				= $aResult[$nIndex++];
			$this->nRescue_Cicero						= $aResult[$nIndex++];
			$this->nPreemptive_Strike					= $aResult[$nIndex++];
			$this->nPraetorian_Guard					= $aResult[$nIndex++];
			$this->nThe_Fall_of_Illsalin				= $aResult[$nIndex++];
			$this->nFlights_of_the_Seeker				= $aResult[$nIndex++];
			$this->nInto_the_Shadows					= $aResult[$nIndex++];
			$this->nFreeing_an_Elder					= $aResult[$nIndex++];
			$this->nOrb_of_Subversion					= $aResult[$nIndex++];
			$this->nA_Plea_for_Help						= $aResult[$nIndex++];
			$this->nTrailing_Longshadow					= $aResult[$nIndex++];
			$this->nConfronting_a_Traitor				= $aResult[$nIndex++];
			$this->nThe_Search_for_Coral				= $aResult[$nIndex++];
			$this->nLearning_the_Power					= $aResult[$nIndex++];
			$this->nDiscover_the_Secret					= $aResult[$nIndex++];
			$this->nTaking_Control						= $aResult[$nIndex++];
			$this->nThe_Mines							= $aResult[$nIndex++];
			$this->nLost_Caverns						= $aResult[$nIndex++];
			$this->nThe_Hive							= $aResult[$nIndex++];
			$this->nThe_Korlach							= $aResult[$nIndex++];
			$this->nThe_Rescue							= $aResult[$nIndex++];
				// DoN Flags
			$this->nT1_Create_an_Antidote				= $aResult[$nIndex++];
			$this->nT1_Greed_of_the_Goblins				= $aResult[$nIndex++];
			$this->nT1_Burning_Arrows					= $aResult[$nIndex++];
			$this->nT1_Children_of_Gimblax				= $aResult[$nIndex++];
			$this->nT2_Defend_the_Kirin_Contact			= $aResult[$nIndex++];
			$this->nT2_Recover_the_Lost_Map				= $aResult[$nIndex++];
			$this->nT2_Turn_the_Tides_of_the_Sand		= $aResult[$nIndex++];
			$this->nT2_Sickness_of_the_Spirit			= $aResult[$nIndex++];
			$this->nT2_Calling_Emoush					= $aResult[$nIndex++];
			$this->nT3_Protect_the_Waters				= $aResult[$nIndex++];
			$this->nT3_Snowfoots_Revenge				= $aResult[$nIndex++];
			$this->nT3_The_Sacred_Scrolls				= $aResult[$nIndex++];
			$this->nT3_History_of_the_Isle				= $aResult[$nIndex++];
			$this->nT3_Trial_of_Perserverance			= $aResult[$nIndex++];
			$this->nT3_Volkaras_Bite					= $aResult[$nIndex++];
			$this->nT4_Goblin_Dojo						= $aResult[$nIndex++];
			$this->nT4_Guardian_of_the_Sands			= $aResult[$nIndex++];
			$this->nT4_An_End_to_the_Storms				= $aResult[$nIndex++];
			$this->nT5_Origins_of_the_Curse				= $aResult[$nIndex++];
			$this->nT5_The_Curse_of_JuRek				= $aResult[$nIndex++];
			$this->nT5_In_the_Shadows					= $aResult[$nIndex++];
				// GoD Flags
			$this->nPurifying_Plant						= $aResult[$nIndex++];
			$this->nEmanating_Furnace					= $aResult[$nIndex++];
			$this->nLair_of_Trapped_Ones				= $aResult[$nIndex++];
			$this->nPool_of_Sludge						= $aResult[$nIndex++];
			$this->nSmith_Rondo							= $aResult[$nIndex++];
			$this->nVxed								= $aResult[$nIndex++];
			$this->nTipt								= $aResult[$nIndex++];
			$this->nVrex_Barxt_Qurat					= $aResult[$nIndex++];
			$this->nKeeper_of_the_Altar					= $aResult[$nIndex++];
			$this->nNoqufiel_in_Inktuta					= $aResult[$nIndex++];
			$this->nCynosure_Kvanjji					= $aResult[$nIndex++];
			$this->nIxt_Hsek_Syat						= $aResult[$nIndex++];
			$this->nHigh_Priest_Nkosi_Bakari			= $aResult[$nIndex++];
			$this->nZunMuram_Tkarish_Zyk				= $aResult[$nIndex++];
				// Keys
			$this->nBoT_Tower_Key						= $aResult[$nIndex++]; 
			$this->nHowling_Stones_Key					= $aResult[$nIndex++]; 
			$this->nSebilis_Key							= $aResult[$nIndex++]; 
			$this->nSleepers_Tomb_Key					= $aResult[$nIndex++]; 
			$this->nSSRA_Emperor_Key					= $aResult[$nIndex++]; 
			$this->nVeeshans_Peak_Key					= $aResult[$nIndex++]; 
			$this->nVex_Thal_Key						= $aResult[$nIndex++]; 
				// OoW CoA
			$this->nMastery_of_Adaptation				= $aResult[$nIndex++];
			$this->nMastery_of_Corruption				= $aResult[$nIndex++];
			$this->nMastery_of_Endurance				= $aResult[$nIndex++];
			$this->nMastery_of_Foresight				= $aResult[$nIndex++];
			$this->nMastery_of_Hate						= $aResult[$nIndex++];
			$this->nMastery_of_Specialization			= $aResult[$nIndex++];
			$this->nSeal_Mastery_of_All					= $aResult[$nIndex++];
			$this->nSignet_Crystal_Gemmed				= $aResult[$nIndex++];
			$this->nSignet_Discolored					= $aResult[$nIndex++];
			$this->nSignet_Dust_Marred					= $aResult[$nIndex++];
			$this->nSignet_Glimmering					= $aResult[$nIndex++];
			$this->nSignet_Tarnished					= $aResult[$nIndex++];
			$this->nSignet_Two_Toned					= $aResult[$nIndex++];
			$this->nSignet_Weather_Worn					= $aResult[$nIndex++];
				// Pop Tier 1 Flags
			$this->nAny_PoJ_Trial						= $aResult[$nIndex++];
			$this->nAll_PoJ_Trials						= $aResult[$nIndex++];
			$this->nPoI_Xanamech						= $aResult[$nIndex++];
			$this->nPoI_Behemoth						= $aResult[$nIndex++];
			$this->nPoD_Grimror_Quest					= $aResult[$nIndex++];
			$this->nPoD_Grummus							= $aResult[$nIndex++];
			$this->nPoN_Hedge_Quest						= $aResult[$nIndex++];
			$this->nPoNb_Terris_Thule					= $aResult[$nIndex++];
				// Pop Tier 2 Flags
			$this->nPoS_Askr_Quest						= $aResult[$nIndex++];
			$this->nPoV_Grenic_Quest					= $aResult[$nIndex++];
			$this->nPoV_AerinDar						= $aResult[$nIndex++];
			$this->nCoD_Carprin_Event					= $aResult[$nIndex++];
			$this->nCoD_Bertoxxulous					= $aResult[$nIndex++];
			$this->nPoTorment_Saryrn					= $aResult[$nIndex++];
			$this->nPoS_Wembly_Quest					= $aResult[$nIndex++];
				// Pop Tier 3 Flags
			$this->nHoH_Trial1_RyddaDar					= $aResult[$nIndex++];
			$this->nHoH_Trial2_Ogre						= $aResult[$nIndex++];
			$this->nHoH_Trial3_Madmen					= $aResult[$nIndex++];
			$this->nHoHb_Mithanial_Marr					= $aResult[$nIndex++];
			$this->nPoTactics_Tallon_Zek				= $aResult[$nIndex++];
			$this->nPoTactics_Vallon_Zek				= $aResult[$nIndex++];
			$this->nPoTactics_Rallos_Zek_Quest			= $aResult[$nIndex++];
			$this->nBoT_Rescue_Karana_Quest				= $aResult[$nIndex++];
			$this->nSolRoTower_Jiva						= $aResult[$nIndex++];
			$this->nSolRoTower_Xuzl						= $aResult[$nIndex++];
			$this->nSolRoTower_Arlyxir					= $aResult[$nIndex++];
			$this->nSolRoTower_Rizlona					= $aResult[$nIndex++];
			$this->nSolRoTower_Protector_of_Dresolik	= $aResult[$nIndex++];
			$this->nSolRoTower_Solusek_Ro				= $aResult[$nIndex++];
				// Pop Tier 4 Flags
			$this->nPoAir_Xegony						= $aResult[$nIndex++];
			$this->nPoFire_Fennin_Ro					= $aResult[$nIndex++];
			$this->nPoWater_Coirnav						= $aResult[$nIndex++];
			$this->nPoEarthb_The_Rathe					= $aResult[$nIndex++];
			$this->nPoTime_Time_Phased_Quintessence		= $aResult[$nIndex++];
				// PoS Askr quest (BoT flag)
			$this->nHead								= $aResult[$nIndex++]; 
			$this->nBeard								= $aResult[$nIndex++]; 
			$this->nBone								= $aResult[$nIndex++]; 
			$this->nSash								= $aResult[$nIndex++]; 
			$this->nOceanMedal							= $aResult[$nIndex++]; 
			$this->nDesertMedal							= $aResult[$nIndex++]; 
			$this->nForestMedal							= $aResult[$nIndex++]; 
				// SSRA Emperor key
			$this->nTaskmasters_Pouch					= $aResult[$nIndex++]; 
			$this->nZazuzhs_Idol						= $aResult[$nIndex++]; 
			$this->nRing								= $aResult[$nIndex++]; 
			$this->nInsignia							= $aResult[$nIndex++]; 
				// Trade Skills
			$this->nAlchemy								= $aResult[$nIndex++]; 
			$this->nBaking								= $aResult[$nIndex++]; 
			$this->nBrewing								= $aResult[$nIndex++]; 
			$this->nFishing								= $aResult[$nIndex++]; 
			$this->nFletching							= $aResult[$nIndex++]; 
			$this->nForaging							= $aResult[$nIndex++]; 
			$this->nJewelcraft							= $aResult[$nIndex++]; 
			$this->nPoison								= $aResult[$nIndex++]; 
			$this->nPottery								= $aResult[$nIndex++]; 
			$this->nResearch							= $aResult[$nIndex++]; 
			$this->nSmithing							= $aResult[$nIndex++]; 
			$this->nTailoring							= $aResult[$nIndex++]; 
			$this->nTinkering							= $aResult[$nIndex++]; 
				// Veeshan's Peek key
			$this->nKylongMedal_Top						= $aResult[$nIndex++]; 
			$this->nKylongMedal_Middle					= $aResult[$nIndex++]; 
			$this->nKylongMedal_Bottom					= $aResult[$nIndex++]; 
			$this->nJarsathMedal_Top					= $aResult[$nIndex++]; 
			$this->nJarsathMedal_Middle					= $aResult[$nIndex++]; 
			$this->nJarsathMedal_Bottom					= $aResult[$nIndex++]; 
			$this->nObulusMedal_Top						= $aResult[$nIndex++]; 
			$this->nObulusMedal_Middle					= $aResult[$nIndex++]; 
			$this->nObulusMedal_Bottom					= $aResult[$nIndex++]; 
			$this->nTrak_Tooth							= $aResult[$nIndex++]; 
				// Vex Thal key
			$this->nGlowing_Orb							= $aResult[$nIndex++]; 
			$this->nCelestial_Rift						= $aResult[$nIndex++]; 
			$this->nShard_Dat							= $aResult[$nIndex++]; 
			$this->nShard_Dax							= $aResult[$nIndex++]; 
			$this->nShard_Kel							= $aResult[$nIndex++]; 
			$this->nShard_Kelara						= $aResult[$nIndex++]; 
			$this->nShard_Lor							= $aResult[$nIndex++]; 
			$this->nShard_Raf							= $aResult[$nIndex++]; 
			$this->nShard_Set							= $aResult[$nIndex++]; 
			$this->nShard_Tak							= $aResult[$nIndex++]; 
			$this->nShard_Ved							= $aResult[$nIndex++]; 
			$this->nShard_Vin							= $aResult[$nIndex++]; 
			
			$bSucces	= true;
		}
		else if( IsAdministrator( $strUserName ) )
		{
			// Show error message
			print( "    <hr />$strSelectQuery\n" );
		}
		
		// Done
		return $bSucces;
	}



	// ========================================================================
	// Retrieve all Character data from a speciefied Database table
	// ========================================================================
	function GetDataFromTable( $strTableName )
	{
		// Make sure the CharID is known
		if( $this->nCharID < 0 )
		{
			$this->nCharID	= $this->GetCharID( $this->strCharName );
		}

		// Declare variables
		$bSucces			= false;

		// Determine the select statement
		if( $strTableName == "Characters" )				{	$strSelectQuery		= "SELECT	CharName, LastName, NameMain, Class, Race, Gender, Level, AA, GLP, EQPlayersCharID, MageloNr, GuildStatus, LastOn, HP, Mana, Endurance, AC, FlowingThought, Regen, Atk, Str, Sta, Agi, Dex, Wis, `Int`, Cha, PR, MR, DR, FR, CR \n";	}
		else if( $strTableName == "DoD_Flags" )			{	$strSelectQuery		= "SELECT	A_Rogues_Trust, Scouting_the_City, Building_the_Disguise, The_Search_for_Illsuras, The_Rage_of_Kelliad, The_Lost_Notebook, Cavern_Botany, The_Search_for_Clues, Rescue_Cicero, Preemptive_Strike, Praetorian_Guard, The_Fall_of_Illsalin, Flights_of_the_Seeker, Into_the_Shadows, Freeing_an_Elder, Orb_of_Subversion, A_Plea_for_Help, Trailing_Longshadow, Confronting_a_Traitor, The_Search_for_Coral, Learning_the_Power, Discover_the_Secret, Taking_Control, The_Mines, Lost_Caverns, The_Hive, The_Korlach, The_Rescue \n";	}
		else if( $strTableName == "DoN_Flags" )			{	$strSelectQuery		= "SELECT	T1_Create_an_Antidote, T1_Greed_of_the_Goblins, T1_Burning_Arrows, T1_Children_of_Gimblax, T2_Defend_the_Kirin_Contact, T2_Recover_the_Lost_Map, T2_Turn_the_Tides_of_the_Sand, T2_Sickness_of_the_Spirit, T2_Calling_Emoush, T3_Protect_the_Waters, T3_Snowfoots_Revenge, T3_The_Sacred_Scrolls, T3_History_of_the_Isle, T3_Trial_of_Perserverance, T3_Volkaras_Bite, T4_Goblin_Dojo, T4_Guardian_of_the_Sands, T4_An_End_to_the_Storms, T5_Origins_of_the_Curse, T5_The_Curse_of_JuRek, T5_In_the_Shadows \n";	}
		else if( $strTableName == "GoD_Flags" )			{	$strSelectQuery		= "SELECT	Purifying_Plant, Emanating_Furnace, Lair_of_Trapped_Ones, Pool_of_Sludge, Smith_Rondo, Vxed, Tipt, Vrex_Barxt_Qurat, Keeper_of_the_Altar, Noqufiel_in_Inktuta, Cynosure_Kvanjji, Ixt_Hsek_Syat, High_Priest_Nkosi_Bakari, ZunMuram_Tkarish_Zyk \n";	}
		else if( $strTableName == "`Keys`" )			{	$strSelectQuery		= "SELECT	BoT_Tower_Key, Howling_Stones_Key, Sebilis_Key, Sleepers_Tomb_Key, SSRA_Emperor_Key, Veeshans_Peak_Key, Vex_Thal_Key \n";	}
		else if( $strTableName == "OoW_CoA" )			{	$strSelectQuery		= "SELECT	Mastery_of_Adaptation, Mastery_of_Corruption, Mastery_of_Endurance, Mastery_of_Foresight, Mastery_of_Hate, Mastery_of_Specialization, Seal_Mastery_of_All, Signet_Crystal_Gemmed, Signet_Discolored, Signet_Dust_Marred, Signet_Glimmering, Signet_Tarnished, Signet_Two_Toned, Signet_Weather_Worn \n";	}
		else if( $strTableName == "PoP_Tier_1_Flags" )	{	$strSelectQuery		= "SELECT	Any_PoJ_Trial, All_PoJ_Trials, PoI_Xanamech, PoI_Behemoth, PoD_Grimror_Quest, PoD_Grummus, PoN_Hedge_Quest, PoNb_Terris_Thule \n";	}
		else if( $strTableName == "PoP_Tier_2_Flags" )	{	$strSelectQuery		= "SELECT	PoS_Askr_Quest, PoV_Grenic_Quest, PoV_AerinDar, CoD_Carprin_Event, CoD_Bertoxxulous, PoTorment_Saryrn, PoS_Wembly_Quest \n";	}
		else if( $strTableName == "PoP_Tier_3_Flags" )	{	$strSelectQuery		= "SELECT	HoH_Trial1_RyddaDar, HoH_Trial2_Ogre, HoH_Trial3_Madmen, HoHb_Mithanial_Marr, PoTactics_Tallon_Zek, PoTactics_Vallon_Zek, PoTactics_Rallos_Zek_Quest, BoT_Rescue_Karana_Quest, SolRoTower_Jiva, SolRoTower_Xuzl, SolRoTower_Arlyxir, SolRoTower_Rizlona, SolRoTower_Protector_of_Dresolik, SolRoTower_Solusek_Ro \n";	}
		else if( $strTableName == "PoP_Tier_4_Flags" )	{	$strSelectQuery		= "SELECT	PoAir_Xegony, PoFire_Fennin_Ro, PoWater_Coirnav, PoEarthb_The_Rathe, PoTime_Time_Phased_Quintessence \n";	}
		else if( $strTableName == "PoS_Askr_Quest" )	{	$strSelectQuery		= "SELECT	Head, Beard, Bone, Sash, OceanMedal, DesertMedal, ForestMedal \n";	}
		else if( $strTableName == "SSRA_Emperor_Key" )	{	$strSelectQuery		= "SELECT	Taskmasters_Pouch, Zazuzhs_Idol, Ring, Insignia \n";	}
		else if( $strTableName == "TradeSkills" )		{	$strSelectQuery		= "SELECT	Alchemy, Baking, Brewing, Fishing, Fletching, Foraging, Jewelcraft, Poison, Pottery, Research, Smithing, Tailoring, Tinkering \n";	}
		else if( $strTableName == "Veeshans_Peak_Key" )	{	$strSelectQuery		= "SELECT	KylongMedal_Top, KylongMedal_Middle, KylongMedal_Bottom, JarsathMedal_Top, JarsathMedal_Middle, JarsathMedal_Bottom, ObulusMedal_Top, ObulusMedal_Middle, ObulusMedal_Bottom, Trak_Tooth \n";	}
		else if( $strTableName == "Vex_Thal_Key" )		{	$strSelectQuery		= "SELECT	Glowing_Orb, Celestial_Rift, Shard_Dat, Shard_Dax, Shard_Kel, Shard_Kelara, Shard_Lor, Shard_Raf, Shard_Set, Shard_Tak, Shard_Ved, Shard_Vin \n";	}
		else
		{
			// Error
			print( "	<font color=\"" . $this->theSkin->strErrorColor . "\"><a>Can't select data for char '$this->nCharID:$this->strCharName' from table '$strTableName'! (Table is not known to script)</a></font><br />\n" );
		}
		// Finish select statement
		$strSelectQuery		.= "FROM $strTableName \n" .
							   "WHERE CharID = '$this->nCharID' \n";

		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Retrieve the record
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		if( $nResult == FALSE )
		{
			print( "	<font color=\"" . $this->theSkin->strErrorColor . "\"><a>Couldn't select data for char '$this->nCharID:$this->strCharName' from table '$strTableName'! (" . mysql_error() . ")</a></font><br />\n" );
		}
		else
		{
			// Fetch the record
			$aResult	= mysql_fetch_row( $nResult );
		}
	
		// Close the connection
		DBDisconnect( $nLinkID );
	
	    if( $aResult ) 
		{
			// Retrieve the variables out of the array
			$nIndex										= 0;
			// Characters
			if( $strTableName == "Characters" )
			{
				$this->strCharName							= $aResult[$nIndex++];
				$this->strLastName							= $aResult[$nIndex++];
				$this->strNameMain							= $aResult[$nIndex++];
				$this->strClass								= $aResult[$nIndex++];
				$this->strRace								= $aResult[$nIndex++];
				$this->strGender							= $aResult[$nIndex++];
				$this->nLevel								= $aResult[$nIndex++];
				$this->nAA									= $aResult[$nIndex++];
				$this->nGLP									= $aResult[$nIndex++];
				$this->nEQPlayersCharID						= $aResult[$nIndex++];
				$this->nMageloNr							= $aResult[$nIndex++];
				$this->strGuildStatus						= $aResult[$nIndex++];
				$this->strLastOnDate						= $aResult[$nIndex++];
				// Character Statistics
				$this->nHP									= $aResult[$nIndex++];
				$this->nMana								= $aResult[$nIndex++];
				$this->nEndurance							= $aResult[$nIndex++];
				$this->nAC									= $aResult[$nIndex++];
				$this->nFT									= $aResult[$nIndex++];
				$this->nRegen								= $aResult[$nIndex++];
				$this->nAtk									= $aResult[$nIndex++];
				$this->nStr									= $aResult[$nIndex++];
				$this->nSta									= $aResult[$nIndex++];
				$this->nAgi									= $aResult[$nIndex++];
				$this->nDex									= $aResult[$nIndex++];
				$this->nWis									= $aResult[$nIndex++];
				$this->nInt									= $aResult[$nIndex++];
				$this->nCha									= $aResult[$nIndex++];
				$this->nPR									= $aResult[$nIndex++];
				$this->nMR									= $aResult[$nIndex++];
				$this->nDR									= $aResult[$nIndex++];
				$this->nFR									= $aResult[$nIndex++];
				$this->nCR 									= $aResult[$nIndex++];
			}
			// DoD Spells
			else if( $strTableName == "DoD_Flags" )
			{
				$this->nA_Rogues_Trust						= $aResult[$nIndex++];
				$this->nScouting_the_City					= $aResult[$nIndex++];
				$this->nBuilding_the_Disguise				= $aResult[$nIndex++];
				$this->nThe_Search_for_Illsuras				= $aResult[$nIndex++];
				$this->nThe_Rage_of_Kelliad					= $aResult[$nIndex++];
				$this->nThe_Lost_Notebook					= $aResult[$nIndex++];
				$this->nCavern_Botany						= $aResult[$nIndex++];
				$this->nThe_Search_for_Clues				= $aResult[$nIndex++];
				$this->nRescue_Cicero						= $aResult[$nIndex++];
				$this->nPreemptive_Strike					= $aResult[$nIndex++];
				$this->nPraetorian_Guard					= $aResult[$nIndex++];
				$this->nThe_Fall_of_Illsalin				= $aResult[$nIndex++];
				$this->nFlights_of_the_Seeker				= $aResult[$nIndex++];
				$this->nInto_the_Shadows					= $aResult[$nIndex++];
				$this->nFreeing_an_Elder					= $aResult[$nIndex++];
				$this->nOrb_of_Subversion					= $aResult[$nIndex++];
				$this->nA_Plea_for_Help						= $aResult[$nIndex++];
				$this->nTrailing_Longshadow					= $aResult[$nIndex++];
				$this->nConfronting_a_Traitor				= $aResult[$nIndex++];
				$this->nThe_Search_for_Coral				= $aResult[$nIndex++];
				$this->nLearning_the_Power					= $aResult[$nIndex++];
				$this->nDiscover_the_Secret					= $aResult[$nIndex++];
				$this->nTaking_Control						= $aResult[$nIndex++];
				$this->nThe_Mines							= $aResult[$nIndex++];
				$this->nLost_Caverns						= $aResult[$nIndex++];
				$this->nThe_Hive							= $aResult[$nIndex++];
				$this->nThe_Korlach							= $aResult[$nIndex++];
				$this->nThe_Rescue							= $aResult[$nIndex++];
			}
			// DoN Flags
			else if( $strTableName == "DoN_Flags" )
			{
				$this->nT1_Create_an_Antidote				= $aResult[$nIndex++];
				$this->nT1_Greed_of_the_Goblins				= $aResult[$nIndex++];
				$this->nT1_Burning_Arrows					= $aResult[$nIndex++];
				$this->nT1_Children_of_Gimblax				= $aResult[$nIndex++];
				$this->nT2_Defend_the_Kirin_Contact			= $aResult[$nIndex++];
				$this->nT2_Recover_the_Lost_Map				= $aResult[$nIndex++];
				$this->nT2_Turn_the_Tides_of_the_Sand		= $aResult[$nIndex++];
				$this->nT2_Sickness_of_the_Spirit			= $aResult[$nIndex++];
				$this->nT2_Calling_Emoush					= $aResult[$nIndex++];
				$this->nT3_Protect_the_Waters				= $aResult[$nIndex++];
				$this->nT3_Snowfoots_Revenge				= $aResult[$nIndex++];
				$this->nT3_The_Sacred_Scrolls				= $aResult[$nIndex++];
				$this->nT3_History_of_the_Isle				= $aResult[$nIndex++];
				$this->nT3_Trial_of_Perserverance			= $aResult[$nIndex++];
				$this->nT3_Volkaras_Bite					= $aResult[$nIndex++];
				$this->nT4_Goblin_Dojo						= $aResult[$nIndex++];
				$this->nT4_Guardian_of_the_Sands			= $aResult[$nIndex++];
				$this->nT4_An_End_to_the_Storms				= $aResult[$nIndex++];
				$this->nT5_Origins_of_the_Curse				= $aResult[$nIndex++];
				$this->nT5_The_Curse_of_JuRek				= $aResult[$nIndex++];
				$this->nT5_In_the_Shadows					= $aResult[$nIndex++];
			}
			// GoD Flags
			else if( $strTableName == "GoD_Flags" )
			{
				$this->nPurifying_Plant						= $aResult[$nIndex++];
				$this->nEmanating_Furnace					= $aResult[$nIndex++];
				$this->nLair_of_Trapped_Ones				= $aResult[$nIndex++];
				$this->nPool_of_Sludge						= $aResult[$nIndex++];
				$this->nSmith_Rondo							= $aResult[$nIndex++];
				$this->nVxed								= $aResult[$nIndex++];
				$this->nTipt								= $aResult[$nIndex++];
				$this->nVrex_Barxt_Qurat					= $aResult[$nIndex++];
				$this->nKeeper_of_the_Altar					= $aResult[$nIndex++];
				$this->nNoqufiel_in_Inktuta					= $aResult[$nIndex++];
				$this->nCynosure_Kvanjji					= $aResult[$nIndex++];
				$this->nIxt_Hsek_Syat						= $aResult[$nIndex++];
				$this->nHigh_Priest_Nkosi_Bakari			= $aResult[$nIndex++];
				$this->nZunMuram_Tkarish_Zyk				= $aResult[$nIndex++];
			}
			// Keys
			else if( $strTableName == "`Keys`" )
			{
				$this->nBoT_Tower_Key						= $aResult[$nIndex++]; 
				$this->nHowling_Stones_Key					= $aResult[$nIndex++]; 
				$this->nSebilis_Key							= $aResult[$nIndex++]; 
				$this->nSleepers_Tomb_Key					= $aResult[$nIndex++]; 
				$this->nSSRA_Emperor_Key					= $aResult[$nIndex++]; 
				$this->nVeeshans_Peak_Key					= $aResult[$nIndex++]; 
				$this->nVex_Thal_Key						= $aResult[$nIndex++]; 
			}
			// OoW CoA
			else if( $strTableName == "OoW_CoA" )
			{
				$this->nMastery_of_Adaptation				= $aResult[$nIndex++];
				$this->nMastery_of_Corruption				= $aResult[$nIndex++];
				$this->nMastery_of_Endurance				= $aResult[$nIndex++];
				$this->nMastery_of_Foresight				= $aResult[$nIndex++];
				$this->nMastery_of_Hate						= $aResult[$nIndex++];
				$this->nMastery_of_Specialization			= $aResult[$nIndex++];
				$this->nSeal_Mastery_of_All					= $aResult[$nIndex++];
				$this->nSignet_Crystal_Gemmed				= $aResult[$nIndex++];
				$this->nSignet_Discolored					= $aResult[$nIndex++];
				$this->nSignet_Dust_Marred					= $aResult[$nIndex++];
				$this->nSignet_Glimmering					= $aResult[$nIndex++];
				$this->nSignet_Tarnished					= $aResult[$nIndex++];
				$this->nSignet_Two_Toned					= $aResult[$nIndex++];
				$this->nSignet_Weather_Worn					= $aResult[$nIndex++];
			}
			// Pop Tier 1 Flags
			else if( $strTableName == "PoP_Tier_1_Flags" )
			{
				$this->nAny_PoJ_Trial						= $aResult[$nIndex++];
				$this->nAll_PoJ_Trials						= $aResult[$nIndex++];
				$this->nPoI_Xanamech						= $aResult[$nIndex++];
				$this->nPoI_Behemoth						= $aResult[$nIndex++];
				$this->nPoD_Grimror_Quest					= $aResult[$nIndex++];
				$this->nPoD_Grummus							= $aResult[$nIndex++];
				$this->nPoN_Hedge_Quest						= $aResult[$nIndex++];
				$this->nPoNb_Terris_Thule					= $aResult[$nIndex++];
			}
			// Pop Tier 2 Flags
			else if( $strTableName == "PoP_Tier_2_Flags" )
			{
				$this->nPoS_Askr_Quest						= $aResult[$nIndex++];
				$this->nPoV_Grenic_Quest					= $aResult[$nIndex++];
				$this->nPoV_AerinDar						= $aResult[$nIndex++];
				$this->nCoD_Carprin_Event					= $aResult[$nIndex++];
				$this->nCoD_Bertoxxulous					= $aResult[$nIndex++];
				$this->nPoTorment_Saryrn					= $aResult[$nIndex++];
				$this->nPoS_Wembly_Quest					= $aResult[$nIndex++];
			}
			// Pop Tier 3 Flags
			else if( $strTableName == "PoP_Tier_3_Flags" )
			{
				$this->nHoH_Trial1_RyddaDar					= $aResult[$nIndex++];
				$this->nHoH_Trial2_Ogre						= $aResult[$nIndex++];
				$this->nHoH_Trial3_Madmen					= $aResult[$nIndex++];
				$this->nHoHb_Mithanial_Marr					= $aResult[$nIndex++];
				$this->nPoTactics_Tallon_Zek				= $aResult[$nIndex++];
				$this->nPoTactics_Vallon_Zek				= $aResult[$nIndex++];
				$this->nPoTactics_Rallos_Zek_Quest			= $aResult[$nIndex++];
				$this->nBoT_Rescue_Karana_Quest				= $aResult[$nIndex++];
				$this->nSolRoTower_Jiva						= $aResult[$nIndex++];
				$this->nSolRoTower_Xuzl						= $aResult[$nIndex++];
				$this->nSolRoTower_Arlyxir					= $aResult[$nIndex++];
				$this->nSolRoTower_Rizlona					= $aResult[$nIndex++];
				$this->nSolRoTower_Protector_of_Dresolik	= $aResult[$nIndex++];
				$this->nSolRoTower_Solusek_Ro				= $aResult[$nIndex++];
			}
			// Pop Tier 4 Flags
			else if( $strTableName == "PoP_Tier_4_Flags" )
			{
				$this->nPoAir_Xegony						= $aResult[$nIndex++];
				$this->nPoFire_Fennin_Ro					= $aResult[$nIndex++];
				$this->nPoWater_Coirnav						= $aResult[$nIndex++];
				$this->nPoEarthb_The_Rathe					= $aResult[$nIndex++];
				$this->nPoTime_Time_Phased_Quintessence		= $aResult[$nIndex++];
			}
			// PoS Askr quest (BoT flag)
			else if( $strTableName == "PoS_Askr_Quest" )
			{
				$this->nHead								= $aResult[$nIndex++]; 
				$this->nBeard								= $aResult[$nIndex++]; 
				$this->nBone								= $aResult[$nIndex++]; 
				$this->nSash								= $aResult[$nIndex++]; 
				$this->nOceanMedal							= $aResult[$nIndex++]; 
				$this->nDesertMedal							= $aResult[$nIndex++]; 
				$this->nForestMedal							= $aResult[$nIndex++]; 
			}
			// SSRA Emperor key
			else if( $strTableName == "SSRA_Emperor_Key" )
			{
				$this->nTaskmasters_Pouch					= $aResult[$nIndex++]; 
				$this->nZazuzhs_Idol						= $aResult[$nIndex++]; 
				$this->nRing								= $aResult[$nIndex++]; 
				$this->nInsignia							= $aResult[$nIndex++]; 
			}
			// Trade Skills
			else if( $strTableName == "TradeSkills" )
			{
				$this->nAlchemy								= $aResult[$nIndex++]; 
				$this->nBaking								= $aResult[$nIndex++]; 
				$this->nBrewing								= $aResult[$nIndex++]; 
				$this->nFishing								= $aResult[$nIndex++]; 
				$this->nFletching							= $aResult[$nIndex++]; 
				$this->nForaging							= $aResult[$nIndex++]; 
				$this->nJewelcraft							= $aResult[$nIndex++]; 
				$this->nPoison								= $aResult[$nIndex++]; 
				$this->nPottery								= $aResult[$nIndex++]; 
				$this->nResearch							= $aResult[$nIndex++]; 
				$this->nSmithing							= $aResult[$nIndex++]; 
				$this->nTailoring							= $aResult[$nIndex++]; 
				$this->nTinkering							= $aResult[$nIndex++]; 
			}
			// Veeshan's Peek key
			else if( $strTableName == "Veeshans_Peak_Key" )
			{
				$this->nKylongMedal_Top						= $aResult[$nIndex++]; 
				$this->nKylongMedal_Middle					= $aResult[$nIndex++]; 
				$this->nKylongMedal_Bottom					= $aResult[$nIndex++]; 
				$this->nJarsathMedal_Top					= $aResult[$nIndex++]; 
				$this->nJarsathMedal_Middle					= $aResult[$nIndex++]; 
				$this->nJarsathMedal_Bottom					= $aResult[$nIndex++]; 
				$this->nObulusMedal_Top						= $aResult[$nIndex++]; 
				$this->nObulusMedal_Middle					= $aResult[$nIndex++]; 
				$this->nObulusMedal_Bottom					= $aResult[$nIndex++]; 
				$this->nTrak_Tooth							= $aResult[$nIndex++]; 
			}
			// Vex Thal key
			else if( $strTableName == "Vex_Thal_Key" )
			{
				$this->nGlowing_Orb							= $aResult[$nIndex++]; 
				$this->nCelestial_Rift						= $aResult[$nIndex++]; 
				$this->nShard_Dat							= $aResult[$nIndex++]; 
				$this->nShard_Dax							= $aResult[$nIndex++]; 
				$this->nShard_Kel							= $aResult[$nIndex++]; 
				$this->nShard_Kelara						= $aResult[$nIndex++]; 
				$this->nShard_Lor							= $aResult[$nIndex++]; 
				$this->nShard_Raf							= $aResult[$nIndex++]; 
				$this->nShard_Set							= $aResult[$nIndex++]; 
				$this->nShard_Tak							= $aResult[$nIndex++]; 
				$this->nShard_Ved							= $aResult[$nIndex++]; 
				$this->nShard_Vin							= $aResult[$nIndex++]; 
			}
			
			$bSucces	= true;
		}
		else if( IsAdministrator( $strUserName ) )
		{
			// Show error message
			print( "    <hr />$strSelectQuery\n" );
		}
		
		// Done
		return $bSucces;
	}



	// ========================================================================
	// Store all Character data in the Database tables
	// ========================================================================
	function StoreAllData()
	{
		// Declare variables
		$bSucces	= false;
		$strResult	= "";

		// Make sure the Last Name is properly formatted (Names start with capital etc.)
		$this->strLastName	= FormatName( $this->strLastName );

		// Make sure the CharID is known
		if( $this->nCharID < 0 )
		{
			$this->nCharID	= $this->GetCharID( $this->strCharName );
		}
		if( $this->nCharID >= 0 )
		{
			// Update the Character
			$this->UpdateCharacterData();
			// Update the DoD_Flags record
			$this->UpdateDoD_FlagsData();
			// Update the DoN_Flags record
			$this->UpdateDoN_FlagsData();
			// Update the GoD_Flags record
			$this->UpdateGoD_FlagsData();
			// Update the Keys record
			$this->UpdateKeysData();
			// Update the OoW_CoA record
			$this->UpdateOoW_CoAData();
			// Update the Pop_Tier_1_Flags record
			$this->UpdatePoP_Tier_1_FlagsData();
			// Update the Pop_Tier_2_Flags record
			$this->UpdatePoP_Tier_2_FlagsData();
			// Update the Pop_Tier_3_Flags record
			$this->UpdatePoP_Tier_3_FlagsData();
			// Update the Pop_Tier_4_Flags record
			$this->UpdatePoP_Tier_4_FlagsData();
			// Update the PoS_Askr_Quest record
			$this->UpdatePoS_Askr_QuestData();
			// Update the SSRA_Emperor_Key record
			$this->UpdateSSRA_Emperor_KeyData();
			// Update the TradeSkills record
			$this->UpdateTradeSkillsData();
			// Update the Veeshans_Peak_Key record
			$this->UpdateVeeshans_Peak_KeyData();
			// Update the Vex_Thal_Key record
			$this->UpdateVex_Thal_KeyData();

			$bSucces	= true;
		}

		// Done
		return $bSucces;
	}



	// ========================================================================
	// Retrieve all Character data from the Character table
	// ========================================================================
	function GetCharacterData()
	{
		return $this->GetDataFromTable( "Characters" );
	}



	// =============================================================================
	// Update the Character record
	// =============================================================================
	function UpdateCharacterData()
	{
		// Declare variables
		$nUserID				= -1;
		$strSelectUserIDQuery	= "SELECT UserID FROM Users WHERE UserName = '$this->strNameMain'";
		$strResult				= "UPDATE_FAILED";

		// Connect to the database
		$nLinkID	= DBConnect();

		// Retrieve the UserID for this user
		$nResult	= mysql_query( $strSelectUserIDQuery, $nLinkID );
		$aResult	= mysql_fetch_row( $nResult );
		// Store the UserID
		if( isset( $aResult[0] ) )
		{
			$nUserID	= $aResult[0];
		}

		// Make sure all parameters have a value
		if( !isset( $this->nAA ) )	{ $this->nAA	= 0; }
		if( !isset( $this->nGLP ) )	{ $this->nGLP	= 0; }
		
		if( !isset( $this->nEQPlayersCharID ) || $this->nEQPlayersCharID == "" )
		{
			$strEQPlayersCharID	= "NULL";
		}
		else
		{
			$strEQPlayersCharID	= "'" . $this->nEQPlayersCharID . "'";
		}

		if( !isset( $this->nMageloNr ) || $this->nMageloNr == "" )
		{
			$strMageloNr		= "NULL";
		}
		else
		{
			$strMageloNr		= "'" . $this->nMageloNr . "'";
		}

		// Define the Update statement
		$strUpdateQuery			= "UPDATE Characters \n" .
		                          "SET LastName        = '$this->strLastName', \n" .
		                          "    NameMain        = '$this->strNameMain', \n" .
		                          "    GuildStatus     = '$this->strGuildStatus', \n" .
								  "    AA              = '$this->nAA', \n" .
								  "    GLP             = '$this->nGLP', \n" .
								  "    Race            = '$this->strRace', \n" .
								  "    Gender          = '$this->strGender', \n" .
								  "    EQPlayersCharID = $strEQPlayersCharID, \n" .
								  "    MageloNr        = $strMageloNr, \n" .
								  "    UserID          = '$nUserID', \n" .
								  "    LastOn          = '$this->strLastOnDate', \n" .
								  "    HP              = '$this->nHP', \n" .
								  "    Mana            = '$this->nMana', \n" .
								  "    Endurance       = '$this->nEndurance', \n" .
								  "    AC              = '$this->nAC', \n" .
								  "    FlowingThought  = '$this->nFT', \n" .
								  "    Regen           = '$this->nRegen', \n" .
								  "    Atk             = '$this->nAtk', \n" .
								  "    Str             = '$this->nStr', \n" .
								  "    Sta             = '$this->nSta', \n" .
								  "    Agi             = '$this->nAgi', \n" .
								  "    Dex             = '$this->nDex', \n" .
								  "    Wis             = '$this->nWis', \n" .
								  "    `Int`           = '$this->nInt', \n" .
								  "    Cha             = '$this->nCha', \n" .
								  "    PR              = '$this->nPR', \n" .
								  "    MR              = '$this->nMR', \n" .
								  "    DR              = '$this->nDR', \n" .
								  "    FR              = '$this->nFR', \n" .
								  "    CR              = '$this->nCR' \n" .
								  "WHERE CharID = '$this->nCharID'";
		// Update the character
		$nResult	= mysql_query( $strUpdateQuery, $nLinkID );
		// Check if the update was succesfull
		if( $nResult == 1 )
		{
			$strResult	= "RECORD_UPDATED";
		}
		else
		{
			// Show error message
			print( "	<font color=\"" . $this->theSkin->strErrorColor . "\"><a>Update Char " . $this->strCharName . " FAILED!<br /></a></font>\n" );
			print( "    $strUpdateQuery<br />\n" );
			print( "    " . mysql_error() . "<br />\n" );
			exit( "<hr>" );
		}
	
		// Close the connection
		DBDisconnect( $nLinkID );

		return $strResult;
	}
	
	
	
	// ========================================================================
	// Retrieve all Character data from the DoD_Flags table
	// ========================================================================
	function GetDoD_FlagsData()
	{
		return $this->GetDataFromTable( "DoD_Flags" );
	}



	// =============================================================================
	// Update the DoD_Flags record
	// =============================================================================
	function UpdateDoD_FlagsData()
	{
		// Make sure all parameters have a value
		if( !isset( $this->nA_Rogues_Trust ) )			{ $this->nA_Rogues_Trust			= 0; }
		if( !isset( $this->nScouting_the_City ) )		{ $this->nScouting_the_City			= 0; }
		if( !isset( $this->nBuilding_the_Disguise ) )	{ $this->nBuilding_the_Disguise		= 0; }
		if( !isset( $this->nThe_Search_for_Illsuras ) )	{ $this->nThe_Search_for_Illsuras	= 0; }
		if( !isset( $this->nThe_Rage_of_Kelliad ) )		{ $this->nThe_Rage_of_Kelliad		= 0; }
		if( !isset( $this->nThe_Lost_Notebook ) )		{ $this->nThe_Lost_Notebook			= 0; }
		if( !isset( $this->nCavern_Botany ) )			{ $this->nCavern_Botany				= 0; }
		if( !isset( $this->nThe_Search_for_Clues ) )	{ $this->nThe_Search_for_Clues		= 0; }
		if( !isset( $this->nRescue_Cicero ) )			{ $this->nRescue_Cicero				= 0; }
		if( !isset( $this->nPreemptive_Strike ) )		{ $this->nPreemptive_Strike			= 0; }
		if( !isset( $this->nPraetorian_Guard ) )		{ $this->nPraetorian_Guard			= 0; }
		if( !isset( $this->nThe_Fall_of_Illsalin ) )	{ $this->nThe_Fall_of_Illsalin		= 0; }
		if( !isset( $this->nFlights_of_the_Seeker ) )	{ $this->nFlights_of_the_Seeker		= 0; }
		if( !isset( $this->nInto_the_Shadows ) )		{ $this->nInto_the_Shadows			= 0; }
		if( !isset( $this->nFreeing_an_Elder ) )		{ $this->nFreeing_an_Elder			= 0; }
		if( !isset( $this->nOrb_of_Subversion ) )		{ $this->nOrb_of_Subversion			= 0; }
		if( !isset( $this->nA_Plea_for_Help ) )			{ $this->nA_Plea_for_Help			= 0; }
		if( !isset( $this->nTrailing_Longshadow ) )		{ $this->nTrailing_Longshadow		= 0; }
		if( !isset( $this->nConfronting_a_Traitor ) )	{ $this->nConfronting_a_Traitor		= 0; }
		if( !isset( $this->nThe_Search_for_Coral ) )	{ $this->nThe_Search_for_Coral		= 0; }
		if( !isset( $this->nLearning_the_Power ) )		{ $this->nLearning_the_Power		= 0; }
		if( !isset( $this->nDiscover_the_Secret ) )		{ $this->nDiscover_the_Secret		= 0; }
		if( !isset( $this->nTaking_Control ) )			{ $this->nTaking_Control			= 0; }
		if( !isset( $this->nThe_Mines ) )				{ $this->nThe_Mines					= 0; }
		if( !isset( $this->nLost_Caverns ) )			{ $this->nLost_Caverns				= 0; }
		if( !isset( $this->nThe_Hive ) )				{ $this->nThe_Hive					= 0; }
		if( !isset( $this->nThe_Korlach ) )				{ $this->nThe_Korlach				= 0; }
		if( !isset( $this->nThe_Rescue ) )				{ $this->nThe_Rescue				= 0; }
	
		// Declare variables
		$strResult		= "UPDATE_FAILED";
		$strTableName	= "DoD_Flags";
		$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
						  "(CharID, A_Rogues_Trust, Scouting_the_City, Building_the_Disguise, The_Search_for_Illsuras, The_Rage_of_Kelliad, The_Lost_Notebook, Cavern_Botany, The_Search_for_Clues, Rescue_Cicero, Preemptive_Strike, Praetorian_Guard, The_Fall_of_Illsalin, Flights_of_the_Seeker, Into_the_Shadows, Freeing_an_Elder, Orb_of_Subversion, A_Plea_for_Help, Trailing_Longshadow, Confronting_a_Traitor, The_Search_for_Coral, Learning_the_Power, Discover_the_Secret, Taking_Control, The_Mines, Lost_Caverns, The_Hive, The_Korlach, The_Rescue) \n" .
						  "VALUES ($this->nCharID, '$this->nA_Rogues_Trust', '$this->nScouting_the_City', '$this->nBuilding_the_Disguise', '$this->nThe_Search_for_Illsuras', '$this->nThe_Rage_of_Kelliad', '$this->nThe_Lost_Notebook', '$this->nCavern_Botany', '$this->nThe_Search_for_Clues', '$this->nRescue_Cicero', '$this->nPreemptive_Strike', '$this->nPraetorian_Guard', '$this->nThe_Fall_of_Illsalin', '$this->nFlights_of_the_Seeker', '$this->nInto_the_Shadows', '$this->nFreeing_an_Elder', '$this->nOrb_of_Subversion', '$this->nA_Plea_for_Help', '$this->nTrailing_Longshadow', '$this->nConfronting_a_Traitor', '$this->nThe_Search_for_Coral', '$this->nLearning_the_Power', '$this->nDiscover_the_Secret', '$this->nTaking_Control', '$this->nThe_Mines', '$this->nLost_Caverns', '$this->nThe_Hive', '$this->nThe_Korlach', '$this->nThe_Rescue')";
		$strUpdateQuery	= "UPDATE `$strTableName` \n" .
						  "SET A_Rogues_Trust			= '$this->nA_Rogues_Trust', \n" .
						  "    Scouting_the_City		= '$this->nScouting_the_City', \n" .
						  "    Building_the_Disguise	= '$this->nBuilding_the_Disguise', \n" .
						  "    The_Search_for_Illsuras	= '$this->nThe_Search_for_Illsuras', \n" .
						  "    The_Rage_of_Kelliad		= '$this->nThe_Rage_of_Kelliad', \n" .
						  "    The_Lost_Notebook		= '$this->nThe_Lost_Notebook', \n" .
						  "    Cavern_Botany			= '$this->nCavern_Botany', \n" .
						  "    The_Search_for_Clues		= '$this->nThe_Search_for_Clues', \n" .
						  "    Rescue_Cicero			= '$this->nRescue_Cicero', \n" .
						  "    Preemptive_Strike		= '$this->nPreemptive_Strike', \n" .
						  "    Praetorian_Guard			= '$this->nPraetorian_Guard', \n" .
						  "    The_Fall_of_Illsalin		= '$this->nThe_Fall_of_Illsalin', \n" .
						  "    Flights_of_the_Seeker	= '$this->nFlights_of_the_Seeker', \n" .
						  "    Into_the_Shadows			= '$this->nInto_the_Shadows', \n" .
						  "    Freeing_an_Elder			= '$this->nFreeing_an_Elder', \n" .
						  "    Orb_of_Subversion		= '$this->nOrb_of_Subversion', \n" .
						  "    A_Plea_for_Help			= '$this->nA_Plea_for_Help', \n" .
						  "    Trailing_Longshadow		= '$this->nTrailing_Longshadow', \n" .
						  "    Confronting_a_Traitor	= '$this->nConfronting_a_Traitor', \n" .
						  "    The_Search_for_Coral		= '$this->nThe_Search_for_Coral', \n" .
						  "    Learning_the_Power		= '$this->nLearning_the_Power', \n" .
						  "    Discover_the_Secret		= '$this->nDiscover_the_Secret', \n" .
						  "    Taking_Control			= '$this->nTaking_Control', \n" .
						  "    The_Mines				= '$this->nThe_Mines', \n" .
						  "    Lost_Caverns				= '$this->nLost_Caverns', \n" .
						  "    The_Hive					= '$this->nThe_Hive', \n" .
						  "    The_Korlach				= '$this->nThe_Korlach', \n" .
						  "    The_Rescue				= '$this->nThe_Rescue' \n" .
						  "WHERE CharID = $this->nCharID ";
	
		// Check if all the values are empty (delete record)
		if( ( $this->nA_Rogues_Trust == 0 ) &&
			( $this->nScouting_the_City == 0 ) &&
			( $this->nBuilding_the_Disguise == 0 ) &&
			( $this->nThe_Search_for_Illsuras == 0 ) &&
			( $this->nThe_Rage_of_Kelliad == 0 ) &&
			( $this->nThe_Lost_Notebook == 0 ) &&
			( $this->nCavern_Botany == 0 ) &&
			( $this->nThe_Search_for_Clues == 0 ) &&
			( $this->nRescue_Cicero == 0 ) &&
			( $this->nPreemptive_Strike == 0 ) &&
			( $this->nPraetorian_Guard == 0 ) &&
			( $this->nThe_Fall_of_Illsalin == 0 ) &&
			( $this->nFlights_of_the_Seeker == 0 ) &&
			( $this->nInto_the_Shadows == 0 ) &&
			( $this->nFreeing_an_Elder == 0 ) &&
			( $this->nOrb_of_Subversion == 0 ) &&
			( $this->nA_Plea_for_Help == 0 ) &&
			( $this->nTrailing_Longshadow == 0 ) &&
			( $this->nConfronting_a_Traitor == 0 ) &&
			( $this->nThe_Search_for_Coral == 0 ) &&
			( $this->nLearning_the_Power == 0 ) &&
			( $this->nDiscover_the_Secret == 0 ) &&
			( $this->nTaking_Control == 0 ) &&
			( $this->nThe_Mines == 0 ) &&
			( $this->nLost_Caverns == 0 ) &&
			( $this->nThe_Hive == 0 ) &&
			( $this->nThe_Korlach == 0 ) &&
			( $this->nThe_Rescue == 0 ) )
		{
			// Delete the record
			$strResult	= $this->DeleteRecord( $strTableName );
		}
		else
		{
			// Save the record
			$strResult	= $this->SaveRecord( $strTableName, $strInsertQuery, $strUpdateQuery );
		}
	
		// Done
		return $strResult;
	}
	
	
	
	// ========================================================================
	// Retrieve all Character data from the DoN_Flags table
	// ========================================================================
	function GetDoN_FlagsData()
	{
		return $this->GetDataFromTable( "DoN_Flags" );
	}



	// =============================================================================
	// Update the DoN Flags record
	// =============================================================================
	function UpdateDoN_FlagsData()
	{
		// Make sure all parameters have a value
		if( !isset( $this->nT1_Create_an_Antidote ) )			{ $this->nT1_Create_an_Antidote			= 0; }
		if( !isset( $this->nT1_Greed_of_the_Goblins ) )			{ $this->nT1_Greed_of_the_Goblins		= 0; }
		if( !isset( $this->nT1_Burning_Arrows ) )				{ $this->nT1_Burning_Arrows				= 0; }
		if( !isset( $this->nT1_Children_of_Gimblax ) )			{ $this->nT1_Children_of_Gimblax		= 0; }
		if( !isset( $this->nT2_Defend_the_Kirin_Contact ) )		{ $this->nT2_Defend_the_Kirin_Contact	= 0; }
		if( !isset( $this->nT2_Recover_the_Lost_Map ) )			{ $this->nT2_Recover_the_Lost_Map		= 0; }
		if( !isset( $this->nT2_Turn_the_Tides_of_the_Sand ) )	{ $this->nT2_Turn_the_Tides_of_the_Sand	= 0; }
		if( !isset( $this->nT2_Sickness_of_the_Spirit ) )		{ $this->nT2_Sickness_of_the_Spirit		= 0; }
		if( !isset( $this->nT2_Calling_Emoush ) )				{ $this->nT2_Calling_Emoush				= 0; }
		if( !isset( $this->nT3_Protect_the_Waters ) )			{ $this->nT3_Protect_the_Waters			= 0; }
		if( !isset( $this->nT3_Snowfoots_Revenge ) )			{ $this->nT3_Snowfoots_Revenge			= 0; }
		if( !isset( $this->nT3_The_Sacred_Scrolls ) )			{ $this->nT3_The_Sacred_Scrolls			= 0; }
		if( !isset( $this->nT3_History_of_the_Isle ) )			{ $this->nT3_History_of_the_Isle		= 0; }
		if( !isset( $this->nT3_Trial_of_Perserverance ) )		{ $this->nT3_Trial_of_Perserverance		= 0; }
		if( !isset( $this->nT3_Volkaras_Bite ) )				{ $this->nT3_Volkaras_Bite				= 0; }
		if( !isset( $this->nT4_Goblin_Dojo ) )					{ $this->nT4_Goblin_Dojo				= 0; }
		if( !isset( $this->nT4_Guardian_of_the_Sands ) )		{ $this->nT4_Guardian_of_the_Sands		= 0; }
		if( !isset( $this->nT4_An_End_to_the_Storms ) )			{ $this->nT4_An_End_to_the_Storms		= 0; }
		if( !isset( $this->nT5_Origins_of_the_Curse ) )			{ $this->nT5_Origins_of_the_Curse		= 0; }
		if( !isset( $this->nT5_The_Curse_of_JuRek ) )			{ $this->nT5_The_Curse_of_JuRek			= 0; }
		if( !isset( $this->nT5_In_the_Shadows ) )				{ $this->nT5_In_the_Shadows				= 0; }
	
		// Declare variables
		$strResult		= "UPDATE_FAILED";
		$strTableName	= "DoN_Flags";
		$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
						  "(CharID, T1_Create_an_Antidote, T1_Greed_of_the_Goblins, T1_Burning_Arrows, T1_Children_of_Gimblax, T2_Defend_the_Kirin_Contact, T2_Recover_the_Lost_Map, T2_Turn_the_Tides_of_the_Sand, T2_Sickness_of_the_Spirit, T2_Calling_Emoush, T3_Protect_the_Waters, T3_Snowfoots_Revenge, T3_The_Sacred_Scrolls, T3_History_of_the_Isle, T3_Trial_of_Perserverance, T3_Volkaras_Bite, T4_Goblin_Dojo, T4_Guardian_of_the_Sands, T4_An_End_to_the_Storms, T5_Origins_of_the_Curse, T5_The_Curse_of_JuRek, T5_In_the_Shadows) \n" .
						  "VALUES ($this->nCharID, '$this->nT1_Create_an_Antidote', '$this->nT1_Greed_of_the_Goblins', '$this->nT1_Burning_Arrows', '$this->nT1_Children_of_Gimblax', '$this->nT2_Defend_the_Kirin_Contact', '$this->nT2_Recover_the_Lost_Map', '$this->nT2_Turn_the_Tides_of_the_Sand', '$this->nT2_Sickness_of_the_Spirit', '$this->nT2_Calling_Emoush', '$this->nT3_Protect_the_Waters', '$this->nT3_Snowfoots_Revenge', '$this->nT3_The_Sacred_Scrolls', '$this->nT3_History_of_the_Isle', '$this->nT3_Trial_of_Perserverance', '$this->nT3_Volkaras_Bite', '$this->nT4_Goblin_Dojo', '$this->nT4_Guardian_of_the_Sands', '$this->nT4_An_End_to_the_Storms', '$this->nT5_Origins_of_the_Curse', '$this->nT5_The_Curse_of_JuRek', '$this->nT5_In_the_Shadows')";
		$strUpdateQuery	= "UPDATE `$strTableName` \n" .
						  "SET T1_Create_an_Antidote         = '$this->nT1_Create_an_Antidote', \n" .
						  "    T1_Greed_of_the_Goblins       = '$this->nT1_Greed_of_the_Goblins', \n" .
						  "    T1_Burning_Arrows             = '$this->nT1_Burning_Arrows', \n" .
						  "    T1_Children_of_Gimblax        = '$this->nT1_Children_of_Gimblax', \n" .
						  "    T2_Defend_the_Kirin_Contact   = '$this->nT2_Defend_the_Kirin_Contact', \n" .
						  "    T2_Recover_the_Lost_Map       = '$this->nT2_Recover_the_Lost_Map', \n" .
						  "    T2_Turn_the_Tides_of_the_Sand = '$this->nT2_Turn_the_Tides_of_the_Sand', \n" .
						  "    T2_Sickness_of_the_Spirit     = '$this->nT2_Sickness_of_the_Spirit', \n" .
						  "    T2_Calling_Emoush             = '$this->nT2_Calling_Emoush', \n" .
						  "    T3_Protect_the_Waters         = '$this->nT3_Protect_the_Waters', \n" .
						  "    T3_Snowfoots_Revenge          = '$this->nT3_Snowfoots_Revenge', \n" .
						  "    T3_The_Sacred_Scrolls         = '$this->nT3_The_Sacred_Scrolls', \n" .
						  "    T3_History_of_the_Isle        = '$this->nT3_History_of_the_Isle', \n" .
						  "    T3_Trial_of_Perserverance     = '$this->nT3_Trial_of_Perserverance', \n" .
						  "    T3_Volkaras_Bite              = '$this->nT3_Volkaras_Bite', \n" .
						  "    T4_Goblin_Dojo                = '$this->nT4_Goblin_Dojo', \n" .
						  "    T4_Guardian_of_the_Sands      = '$this->nT4_Guardian_of_the_Sands', \n" .
						  "    T4_An_End_to_the_Storms       = '$this->nT4_An_End_to_the_Storms', \n" .
						  "    T5_Origins_of_the_Curse       = '$this->nT5_Origins_of_the_Curse', \n" .
						  "    T5_The_Curse_of_JuRek         = '$this->nT5_The_Curse_of_JuRek', \n" .
						  "    T5_In_the_Shadows             = '$this->nT5_In_the_Shadows' \n" .
						  "WHERE CharID = $this->nCharID ";
	
	
		// Check if all the values are empty (delete record)
		if( ( $this->nT1_Create_an_Antidote == 0 ) &&
			( $this->nT1_Greed_of_the_Goblins == 0 ) &&
			( $this->nT1_Burning_Arrows == 0 ) &&
			( $this->nT1_Children_of_Gimblax == 0 ) &&
			( $this->nT2_Defend_the_Kirin_Contact == 0 ) &&
			( $this->nT2_Recover_the_Lost_Map == 0 ) &&
			( $this->nT2_Turn_the_Tides_of_the_Sand == 0 ) &&
			( $this->nT2_Sickness_of_the_Spirit == 0 ) &&
			( $this->nT2_Calling_Emoush == 0 ) &&
			( $this->nT3_Protect_the_Waters == 0 ) &&
			( $this->nT3_Snowfoots_Revenge == 0 ) &&
			( $this->nT3_The_Sacred_Scrolls == 0 ) &&
			( $this->nT3_History_of_the_Isle == 0 ) &&
			( $this->nT3_Trial_of_Perserverance == 0 ) &&
			( $this->nT3_Volkaras_Bite == 0 ) &&
			( $this->nT4_Goblin_Dojo == 0 ) &&
			( $this->nT4_Guardian_of_the_Sands == 0 ) &&
			( $this->nT4_An_End_to_the_Storms == 0 ) &&
			( $this->nT5_Origins_of_the_Curse == 0 ) &&
			( $this->nT5_The_Curse_of_JuRek == 0 ) &&
			( $this->nT5_In_the_Shadows == 0 ) )
		{
			// Delete the record
			$strResult	= $this->DeleteRecord( $strTableName );
		}
		else
		{
			// Save the record
			$strResult	= $this->SaveRecord( $strTableName, $strInsertQuery, $strUpdateQuery );
		}
	
		// Done
		return $strResult;
	}
	
	
	
	// ========================================================================
	// Retrieve all Character data from the GoD_Flags table
	// ========================================================================
	function GetGoD_FlagsData()
	{
		return $this->GetDataFromTable( "GoD_Flags" );
	}



	// =============================================================================
	// Update the GoD Flags record
	// =============================================================================
	function UpdateGoD_FlagsData()
	{
		// Make sure all parameters have a value
		if( !isset( $this->nPurifying_Plant ) )				{ $this->nPurifying_Plant			= 0; }
		if( !isset( $this->nEmanating_Furnace ) )			{ $this->nEmanating_Furnace			= 0; }
		if( !isset( $this->nLair_of_Trapped_Ones ) )		{ $this->nLair_of_Trapped_Ones		= 0; }
		if( !isset( $this->nPool_of_Sludge ) )				{ $this->nPool_of_Sludge			= 0; }
		if( !isset( $this->nSmith_Rondo ) )					{ $this->nSmith_Rondo				= 0; }
		if( !isset( $this->nVxed ) )						{ $this->nVxed						= 0; }
		if( !isset( $this->nTipt ) )						{ $this->nTipt						= 0; }
		if( !isset( $this->nVrex_Barxt_Qurat ) )			{ $this->nVrex_Barxt_Qurat			= 0; }
		if( !isset( $this->nKeeper_of_the_Altar ) )			{ $this->nKeeper_of_the_Altar		= 0; }
		if( !isset( $this->nNoqufiel_in_Inktuta ) )			{ $this->nNoqufiel_in_Inktuta		= 0; }
		if( !isset( $this->nCynosure_Kvanjji ) )			{ $this->nCynosure_Kvanjji			= 0; }
		if( !isset( $this->nIxt_Hsek_Syat ) )				{ $this->nIxt_Hsek_Syat				= 0; }
		if( !isset( $this->nHigh_Priest_Nkosi_Bakari ) )	{ $this->nHigh_Priest_Nkosi_Bakari	= 0; }
		if( !isset( $this->nZunMuram_Tkarish_Zyk ) )		{ $this->nZunMuram_Tkarish_Zyk		= 0; }
	
		// Declare variables
		$strResult		= "UPDATE_FAILED";
		$strTableName	= "GoD_Flags";
		$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
						  "(CharID, Purifying_Plant, Emanating_Furnace, Lair_of_Trapped_Ones, Pool_of_Sludge, Smith_Rondo, Vxed, Tipt, Vrex_Barxt_Qurat, Keeper_of_the_Altar, Noqufiel_in_Inktuta, Cynosure_Kvanjji, Ixt_Hsek_Syat, High_Priest_Nkosi_Bakari, ZunMuram_Tkarish_Zyk) \n" .
						  "VALUES ($this->nCharID, '$this->nPurifying_Plant', '$this->nEmanating_Furnace', '$this->nLair_of_Trapped_Ones', '$this->nPool_of_Sludge', '$this->nSmith_Rondo', '$this->nVxed', '$this->nTipt', '$this->nVrex_Barxt_Qurat', '$this->nKeeper_of_the_Altar', '$this->nNoqufiel_in_Inktuta', '$this->nCynosure_Kvanjji', '$this->nIxt_Hsek_Syat', '$this->nHigh_Priest_Nkosi_Bakari', '$this->nZunMuram_Tkarish_Zyk')";
		$strUpdateQuery	= "UPDATE `$strTableName` \n" .
						  "SET Purifying_Plant           = '$this->nPurifying_Plant', \n" .
						  "    Emanating_Furnace         = '$this->nEmanating_Furnace', \n" .
						  "    Lair_of_Trapped_Ones      = '$this->nLair_of_Trapped_Ones', \n" .
						  "    Pool_of_Sludge            = '$this->nPool_of_Sludge', \n" .
						  "    Smith_Rondo               = '$this->nSmith_Rondo', \n" .
						  "    Vxed                      = '$this->nVxed', \n" .
						  "    Tipt                      = '$this->nTipt', \n" .
						  "    Vrex_Barxt_Qurat          = '$this->nVrex_Barxt_Qurat', \n" .
						  "    Keeper_of_the_Altar       = '$this->nKeeper_of_the_Altar', \n" .
						  "    Noqufiel_in_Inktuta       = '$this->nNoqufiel_in_Inktuta', \n" .
						  "    Cynosure_Kvanjji          = '$this->nCynosure_Kvanjji', \n" .
						  "    Ixt_Hsek_Syat             = '$this->nIxt_Hsek_Syat', \n" .
						  "    High_Priest_Nkosi_Bakari  = '$this->nHigh_Priest_Nkosi_Bakari', \n" .
						  "    ZunMuram_Tkarish_Zyk      = '$this->nZunMuram_Tkarish_Zyk' \n" .
						  "WHERE CharID = $this->nCharID ";
	
		// Check if all the values are empty (delete record)
		if( ( $this->nPurifying_Plant == 0 ) &&
			( $this->nEmanating_Furnace == 0 ) &&
			( $this->nLair_of_Trapped_Ones == 0 ) &&
			( $this->nPool_of_Sludge == 0 ) &&
			( $this->nSmith_Rondo == 0 ) &&
			( $this->nVxed == 0 ) &&
			( $this->nTipt == 0 ) &&
			( $this->nVrex_Barxt_Qurat == 0 ) &&
			( $this->nKeeper_of_the_Altar == 0 ) &&
			( $this->nNoqufiel_in_Inktuta == 0 ) &&
			( $this->nCynosure_Kvanjji == 0 ) &&
			( $this->nIxt_Hsek_Syat == 0 ) &&
			( $this->nHigh_Priest_Nkosi_Bakari == 0 ) &&
			( $this->nZunMuram_Tkarish_Zyk == 0 ) )
		{
			// Delete the record
			$strResult	= $this->DeleteRecord( $strTableName );
		}
		else
		{
			// Save the record
			$strResult	= $this->SaveRecord( $strTableName, $strInsertQuery, $strUpdateQuery );
		}
	
		// Done
		return $strResult;
	}
	
	
	
	// ========================================================================
	// Retrieve all Character data from the Keys table
	// ========================================================================
	function GetKeysData()
	{
		return $this->GetDataFromTable( "`Keys`" );
	}



	// =============================================================================
	// Update the Keys
	// =============================================================================
	function UpdateKeysData()
	{
		// Make sure all parameters have a value
		if( !isset( $this->nBoT_Tower_Key ) )		{ $this->nBoT_Tower_Key			= 0; }
		if( !isset( $this->nHowling_Stones_Key ) )	{ $this->nHowling_Stones_Key	= 0; }
		if( !isset( $this->nSebilis_Key ) )			{ $this->nSebilis_Key			= 0; }
		if( !isset( $this->nSleepers_Tomb_Key ) )	{ $this->nSleepers_Tomb_Key		= 0; }
		if( !isset( $this->nSSRA_Emperor_Key ) )	{ $this->nSSRA_Emperor_Key		= 0; }
		if( !isset( $this->nVeeshans_Peak_Key ) )	{ $this->nVeeshans_Peak_Key		= 0; }
		if( !isset( $this->nVex_Thal_Key ) )		{ $this->nVex_Thal_Key			= 0; }
	
		// Declare variables
		$strResult		= "UPDATE_FAILED";
		$strTableName	= "Keys";
		$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
						  "(CharID, BoT_Tower_Key, Howling_Stones_Key, Sebilis_Key, Sleepers_Tomb_Key, SSRA_Emperor_Key, Veeshans_Peak_Key, Vex_Thal_Key) \n" .
						  "VALUES ($this->nCharID, '$this->nBoT_Tower_Key', '$this->nHowling_Stones_Key', '$this->nSebilis_Key', '$this->nSleepers_Tomb_Key', '$this->nSSRA_Emperor_Key', '$this->nVeeshans_Peak_Key', '$this->nVex_Thal_Key')";
		$strUpdateQuery	= "UPDATE `$strTableName` \n" .
						  "SET BoT_Tower_Key       = '$this->nBoT_Tower_Key', \n" .
						  "    Howling_Stones_Key  = '$this->nHowling_Stones_Key', \n" .
						  "    Sebilis_Key         = '$this->nSebilis_Key', \n" .
						  "    Sleepers_Tomb_Key   = '$this->nSleepers_Tomb_Key', \n" .
						  "    SSRA_Emperor_Key    = '$this->nSSRA_Emperor_Key', \n" .
						  "    Veeshans_Peak_Key   = '$this->nVeeshans_Peak_Key', \n" .
						  "    Vex_Thal_Key        = '$this->nVex_Thal_Key'\n" .
						  "WHERE CharID = $this->nCharID ";
	
		// Check if all the values are empty (delete record)
		if( ( $this->nBoT_Tower_Key == 0 ) &&
			( $this->nHowling_Stones_Key == 0 ) &&
			( $this->nSebilis_Key == 0 ) &&
			( $this->nSleepers_Tomb_Key == 0 ) &&
			( $this->nSSRA_Emperor_Key == 0 ) &&
			( $this->nVeeshans_Peak_Key == 0 ) &&
			( $this->nVex_Thal_Key == 0 ) )
		{
			// Delete the record
			$strResult	= $this->DeleteRecord( $strTableName );
		}
		else
		{
			// Save the record
			$strResult	= $this->SaveRecord( $strTableName, $strInsertQuery, $strUpdateQuery );
		}
	
		// Done
		return $strResult;
	}
	
	
	
	// ========================================================================
	// Retrieve all Character data from the OoW_CoA table
	// ========================================================================
	function GetOoW_CoAData()
	{
		return $this->GetDataFromTable( "OoW_CoA" );
	}



	// =============================================================================
	// Update the OoW CoA record
	// =============================================================================
	function UpdateOoW_CoAData()
	{
		// Make sure all parameters have a value
		if( !isset( $this->nMastery_of_Adaptation ) )		{ $this->nMastery_of_Adaptation		= 0; }
		if( !isset( $this->nMastery_of_Corruption ) )		{ $this->nMastery_of_Corruption		= 0; }
		if( !isset( $this->nMastery_of_Endurance ) )		{ $this->nMastery_of_Endurance		= 0; }
		if( !isset( $this->nMastery_of_Foresight ) )		{ $this->nMastery_of_Foresight		= 0; }
		if( !isset( $this->nMastery_of_Hate ) )				{ $this->nMastery_of_Hate			= 0; }
		if( !isset( $this->nMastery_of_Specialization ) )	{ $this->nMastery_of_Specialization	= 0; }
		if( !isset( $this->nSeal_Mastery_of_All ) )			{ $this->nSeal_Mastery_of_All		= 0; }
		if( !isset( $this->nSignet_Crystal_Gemmed ) )		{ $this->nSignet_Crystal_Gemmed		= 0; }
		if( !isset( $this->nSignet_Discolored ) )			{ $this->nSignet_Discolored			= 0; }
		if( !isset( $this->nSignet_Dust_Marred ) )			{ $this->nSignet_Dust_Marred		= 0; }
		if( !isset( $this->nSignet_Glimmering ) )			{ $this->nSignet_Glimmering			= 0; }
		if( !isset( $this->nSignet_Tarnished ) )			{ $this->nSignet_Tarnished			= 0; }
		if( !isset( $this->nSignet_Two_Toned ) )			{ $this->nSignet_Two_Toned			= 0; }
		if( !isset( $this->nSignet_Weather_Worn ) )			{ $this->nSignet_Weather_Worn		= 0; }

		// Declare variables
		$strResult		= "UPDATE_FAILED";
		$strTableName	= "OoW_CoA";
		$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
						  "(CharID, Mastery_of_Adaptation, Mastery_of_Corruption, Mastery_of_Endurance, Mastery_of_Foresight, Mastery_of_Hate, Mastery_of_Specialization, Seal_Mastery_of_All, Signet_Crystal_Gemmed, Signet_Discolored, Signet_Dust_Marred, Signet_Glimmering, Signet_Tarnished, Signet_Two_Toned, Signet_Weather_Worn) \n" .
						  "VALUES ($this->nCharID, '$this->nMastery_of_Adaptation', '$this->nMastery_of_Corruption', '$this->nMastery_of_Endurance', '$this->nMastery_of_Foresight', '$this->nMastery_of_Hate', '$this->nMastery_of_Specialization', '$this->nSeal_Mastery_of_All', '$this->nSignet_Crystal_Gemmed', '$this->nSignet_Discolored', '$this->nSignet_Dust_Marred', '$this->nSignet_Glimmering', '$this->nSignet_Tarnished', '$this->nSignet_Two_Toned', '$this->nSignet_Weather_Worn')";
		$strUpdateQuery	= "UPDATE `$strTableName` \n" .
						  "SET Mastery_of_Adaptation		= '$this->nMastery_of_Adaptation', \n" .
						  "    Mastery_of_Corruption		= '$this->nMastery_of_Corruption', \n" .
						  "    Mastery_of_Endurance			= '$this->nMastery_of_Endurance', \n" .
						  "    Mastery_of_Foresight			= '$this->nMastery_of_Foresight', \n" .
						  "    Mastery_of_Hate				= '$this->nMastery_of_Hate', \n" .
						  "    Mastery_of_Specialization	= '$this->nMastery_of_Specialization', \n" .
						  "    Seal_Mastery_of_All			= '$this->nSeal_Mastery_of_All', \n" .
						  "    Signet_Crystal_Gemmed		= '$this->nSignet_Crystal_Gemmed', \n" .
						  "    Signet_Discolored			= '$this->nSignet_Discolored', \n" .
						  "    Signet_Dust_Marred			= '$this->nSignet_Dust_Marred', \n" .
						  "    Signet_Glimmering			= '$this->nSignet_Glimmering', \n" .
						  "    Signet_Tarnished				= '$this->nSignet_Tarnished', \n" .
						  "    Signet_Two_Toned				= '$this->nSignet_Two_Toned', \n" .
						  "    Signet_Weather_Worn			= '$this->nSignet_Weather_Worn' \n" .
						  "WHERE CharID = $this->nCharID ";
	
		// Check if all the values are empty (delete record)
		if( ( $this->nMastery_of_Adaptation == 0 ) &&
			( $this->nMastery_of_Corruption == 0 ) &&
			( $this->nMastery_of_Endurance == 0 ) &&
			( $this->nMastery_of_Foresight == 0 ) &&
			( $this->nMastery_of_Hate == 0 ) &&
			( $this->nMastery_of_Specialization == 0 ) &&
			( $this->nSeal_Mastery_of_All == 0 ) &&
			( $this->nSignet_Crystal_Gemmed == 0 ) &&
			( $this->nSignet_Discolored == 0 ) &&
			( $this->nSignet_Dust_Marred == 0 ) &&
			( $this->nSignet_Glimmering == 0 ) &&
			( $this->nSignet_Tarnished == 0 ) &&
			( $this->nSignet_Two_Toned == 0 ) &&
			( $this->nSignet_Weather_Worn == 0 ) )
		{
			// Delete the record
			$strResult	= $this->DeleteRecord( $strTableName );
		}
		else
		{
			// Save the record
			$strResult	= $this->SaveRecord( $strTableName, $strInsertQuery, $strUpdateQuery );
		}
	
		// Done
		return $strResult;
	}
	
	
	
	// ========================================================================
	// Retrieve all Character data from the PoP_Tier_1_Flags table
	// ========================================================================
	function GetPoP_Tier_1_FlagsData()
	{
		return $this->GetDataFromTable( "PoP_Tier_1_Flags" );
	}



	// =============================================================================
	// Update the Pop Tier 1 Flags record
	// =============================================================================
	function UpdatePoP_Tier_1_FlagsData()
	{
		// Make sure all parameters have a value
		if( !isset( $this->nAny_PoJ_Trial ) )		{ $this->nAny_PoJ_Trial		= 0; }
		if( !isset( $this->nAll_PoJ_Trials ) )		{ $this->nAll_PoJ_Trials	= 0; }
		if( !isset( $this->nPoI_Xanamech ) )		{ $this->nPoI_Xanamech		= 0; }
		if( !isset( $this->nPoI_Behemoth ) )		{ $this->nPoI_Behemoth		= 0; }
		if( !isset( $this->nPoD_Grimror_Quest ) )	{ $this->nPoD_Grimror_Quest	= 0; }
		if( !isset( $this->nPoD_Grummus ) )			{ $this->nPoD_Grummus		= 0; }
		if( !isset( $this->nPoN_Hedge_Quest ) )		{ $this->nPoN_Hedge_Quest	= 0; }
		if( !isset( $this->nPoNb_Terris_Thule ) )	{ $this->nPoNb_Terris_Thule	= 0; }
	
		// Declare variables
		$strResult		= "UPDATE_FAILED";
		$strTableName	= "PoP_Tier_1_Flags";
		$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
						  "(CharID, Any_PoJ_Trial, All_PoJ_Trials, PoI_Xanamech, PoI_Behemoth, PoD_Grimror_Quest, PoD_Grummus, PoN_Hedge_Quest, PoNb_Terris_Thule) \n" .
						  "VALUES ($this->nCharID, '$this->nAny_PoJ_Trial', '$this->nAll_PoJ_Trials', '$this->nPoI_Xanamech', '$this->nPoI_Behemoth', '$this->nPoD_Grimror_Quest', '$this->nPoD_Grummus', '$this->nPoN_Hedge_Quest', '$this->nPoNb_Terris_Thule')";
		$strUpdateQuery	= "UPDATE `$strTableName` \n" .
						  "SET Any_PoJ_Trial     = '$this->nAny_PoJ_Trial', \n" .
						  "    All_PoJ_Trials    = '$this->nAll_PoJ_Trials', \n" .
						  "    PoI_Xanamech      = '$this->nPoI_Xanamech', \n" .
						  "    PoI_Behemoth      = '$this->nPoI_Behemoth', \n" .
						  "    PoD_Grimror_Quest = '$this->nPoD_Grimror_Quest', \n" .
						  "    PoD_Grummus       = '$this->nPoD_Grummus', \n" .
						  "    PoN_Hedge_Quest   = '$this->nPoN_Hedge_Quest', \n" .
						  "    PoNb_Terris_Thule = '$this->nPoNb_Terris_Thule' \n" .
						  "WHERE CharID = $this->nCharID ";
	
		// Check if all the values are empty (delete record)
		if( ( $this->nAny_PoJ_Trial == 0 ) &&
			( $this->nAll_PoJ_Trials == 0 ) &&
			( $this->nPoI_Xanamech == 0 ) &&
			( $this->nPoI_Behemoth == 0 ) &&
			( $this->nPoD_Grimror_Quest == 0 ) &&
			( $this->nPoD_Grummus == 0 ) &&
			( $this->nPoN_Hedge_Quest == 0 ) &&
			( $this->nPoNb_Terris_Thule == 0 ) )
		{
			// Delete the record
			$strResult	= $this->DeleteRecord( $strTableName );
		}
		else
		{
			// Save the record
			$strResult	= $this->SaveRecord( $strTableName, $strInsertQuery, $strUpdateQuery );
		}
	
		// Done
		return $strResult;
	}
	
	
	
	// ========================================================================
	// Retrieve all Character data from the PoP_Tier_2_Flags table
	// ========================================================================
	function GetPoP_Tier_2_FlagsData()
	{
		return $this->GetDataFromTable( "PoP_Tier_2_Flags" );
	}



	// =============================================================================
	// Update the Pop Tier 2 Flags record
	// =============================================================================
	function UpdatePoP_Tier_2_FlagsData()
	{
		// Make sure all parameters have a value
		if( !isset( $this->nPoS_Askr_Quest ) )		{ $this->nPoS_Askr_Quest	= 0; }
		if( !isset( $this->nPoV_Grenic_Quest ) )	{ $this->nPoV_Grenic_Quest	= 0; }
		if( !isset( $this->nPoV_AerinDar ) )		{ $this->nPoV_AerinDar		= 0; }
		if( !isset( $this->nCoD_Carprin_Event ) )	{ $this->nCoD_Carprin_Event	= 0; }
		if( !isset( $this->nCoD_Bertoxxulous ) )	{ $this->nCoD_Bertoxxulous	= 0; }
		if( !isset( $this->nPoTorment_Saryrn ) )	{ $this->nPoTorment_Saryrn	= 0; }
		if( !isset( $this->nPoS_Wembly_Quest ) )	{ $this->nPoS_Wembly_Quest	= 0; }
	
		// Declare variables
		$strResult		= "UPDATE_FAILED";
		$strTableName	= "PoP_Tier_2_Flags";
		$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
						  "(CharID, PoS_Askr_Quest, PoV_Grenic_Quest, PoV_AerinDar, CoD_Carprin_Event, CoD_Bertoxxulous, PoTorment_Saryrn, PoS_Wembly_Quest) \n" .
						  "VALUES ($this->nCharID, '$this->nPoS_Askr_Quest', '$this->nPoV_Grenic_Quest', '$this->nPoV_AerinDar', '$this->nCoD_Carprin_Event', '$this->nCoD_Bertoxxulous', '$this->nPoTorment_Saryrn', '$this->nPoS_Wembly_Quest')";
		$strUpdateQuery	= "UPDATE `$strTableName` \n" .
						  "SET PoS_Askr_Quest    = '$this->nPoS_Askr_Quest', \n" .
						  "    PoV_Grenic_Quest  = '$this->nPoV_Grenic_Quest', \n" .
						  "    PoV_AerinDar      = '$this->nPoV_AerinDar', \n" .
						  "    CoD_Carprin_Event = '$this->nCoD_Carprin_Event', \n" .
						  "    CoD_Bertoxxulous  = '$this->nCoD_Bertoxxulous', \n" .
						  "    PoTorment_Saryrn  = '$this->nPoTorment_Saryrn', \n" .
						  "    PoS_Wembly_Quest  = '$this->nPoS_Wembly_Quest' \n" .
						  "WHERE CharID = $this->nCharID ";
	
		// Check if all the values are empty (delete record)
		if( ( $this->nPoS_Askr_Quest == 0 ) &&
			( $this->nPoV_Grenic_Quest == 0 ) &&
			( $this->nPoV_AerinDar == 0 ) &&
			( $this->nCoD_Carprin_Event == 0 ) &&
			( $this->nCoD_Bertoxxulous == 0 ) &&
			( $this->nPoTorment_Saryrn == 0 ) &&
			( $this->nPoS_Wembly_Quest == 0 ) )
		{
			// Delete the record
			$strResult	= $this->DeleteRecord( $strTableName );
		}
		else
		{
			// Save the record
			$strResult	= $this->SaveRecord( $strTableName, $strInsertQuery, $strUpdateQuery );
		}
	
		// Done
		return $strResult;
	}
	
	
	
	// ========================================================================
	// Retrieve all Character data from the PoP_Tier_3_Flags table
	// ========================================================================
	function GetPoP_Tier_3_FlagsData()
	{
		return $this->GetDataFromTable( "PoP_Tier_3_Flags" );
	}



	// =============================================================================
	// Update the Pop Tier 3 Flags record
	// =============================================================================
	function UpdatePoP_Tier_3_FlagsData()
	{
		// Make sure all parameters have a value
		if( !isset( $this->nHoH_Trial1_RyddaDar ) )					{ $this->nHoH_Trial1_RyddaDar				= 0; }
		if( !isset( $this->nHoH_Trial2_Ogre ) )						{ $this->nHoH_Trial2_Ogre					= 0; }
		if( !isset( $this->nHoH_Trial3_Madmen ) )					{ $this->nHoH_Trial3_Madmen					= 0; }
		if( !isset( $this->nHoHb_Mithanial_Marr ) )					{ $this->nHoHb_Mithanial_Marr				= 0; }
		if( !isset( $this->nPoTactics_Tallon_Zek ) )				{ $this->nPoTactics_Tallon_Zek				= 0; }
		if( !isset( $this->nPoTactics_Vallon_Zek ) )				{ $this->nPoTactics_Vallon_Zek				= 0; }
		if( !isset( $this->nPoTactics_Rallos_Zek_Quest ) )			{ $this->nPoTactics_Rallos_Zek_Quest		= 0; }
		if( !isset( $this->nBoT_Rescue_Karana_Quest ) )				{ $this->nBoT_Rescue_Karana_Quest			= 0; }
		if( !isset( $this->nSolRoTower_Jiva ) )						{ $this->nSolRoTower_Jiva					= 0; }
		if( !isset( $this->nSolRoTower_Xuzl ) )						{ $this->nSolRoTower_Xuzl					= 0; }
		if( !isset( $this->nSolRoTower_Arlyxir ) )					{ $this->nSolRoTower_Arlyxir				= 0; }
		if( !isset( $this->nSolRoTower_Rizlona ) )					{ $this->nSolRoTower_Rizlona				= 0; }
		if( !isset( $this->nSolRoTower_Protector_of_Dresolik ) )	{ $this->nSolRoTower_Protector_of_Dresolik	= 0; }
		if( !isset( $this->nSolRoTower_Solusek_Ro ) )				{ $this->nSolRoTower_Solusek_Ro				= 0; }
	
		// Declare variables
		$strResult		= "UPDATE_FAILED";
		$strTableName	= "PoP_Tier_3_Flags";
		$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
						  "(CharID, HoH_Trial1_RyddaDar, HoH_Trial2_Ogre, HoH_Trial3_Madmen, HoHb_Mithanial_Marr, PoTactics_Tallon_Zek, PoTactics_Vallon_Zek, PoTactics_Rallos_Zek_Quest, BoT_Rescue_Karana_Quest, SolRoTower_Jiva, SolRoTower_Xuzl, SolRoTower_Arlyxir, SolRoTower_Rizlona, SolRoTower_Protector_of_Dresolik, SolRoTower_Solusek_Ro) \n" .
						  "VALUES ($this->nCharID, '$this->nHoH_Trial1_RyddaDar', '$this->nHoH_Trial2_Ogre', '$this->nHoH_Trial3_Madmen', '$this->nHoHb_Mithanial_Marr', '$this->nPoTactics_Tallon_Zek', '$this->nPoTactics_Vallon_Zek', '$this->nPoTactics_Rallos_Zek_Quest', '$this->nBoT_Rescue_Karana_Quest', '$this->nSolRoTower_Jiva', '$this->nSolRoTower_Xuzl', '$this->nSolRoTower_Arlyxir', '$this->nSolRoTower_Rizlona', '$this->nSolRoTower_Protector_of_Dresolik', '$this->nSolRoTower_Solusek_Ro')";
		$strUpdateQuery	= "UPDATE `$strTableName` \n" .
						  "SET HoH_Trial1_RyddaDar              = '$this->nHoH_Trial1_RyddaDar', \n" .
						  "    HoH_Trial2_Ogre                  = '$this->nHoH_Trial2_Ogre', \n" .
						  "    HoH_Trial3_Madmen                = '$this->nHoH_Trial3_Madmen', \n" .
						  "    HoHb_Mithanial_Marr              = '$this->nHoHb_Mithanial_Marr', \n" .
						  "    PoTactics_Tallon_Zek             = '$this->nPoTactics_Tallon_Zek', \n" .
						  "    PoTactics_Vallon_Zek             = '$this->nPoTactics_Vallon_Zek', \n" .
						  "    PoTactics_Rallos_Zek_Quest       = '$this->nPoTactics_Rallos_Zek_Quest', \n" .
						  "    BoT_Rescue_Karana_Quest          = '$this->nBoT_Rescue_Karana_Quest', \n" .
						  "    SolRoTower_Jiva                  = '$this->nSolRoTower_Jiva', \n" .
						  "    SolRoTower_Xuzl                  = '$this->nSolRoTower_Xuzl', \n" .
						  "    SolRoTower_Arlyxir               = '$this->nSolRoTower_Arlyxir', \n" .
						  "    SolRoTower_Rizlona               = '$this->nSolRoTower_Rizlona', \n" .
						  "    SolRoTower_Protector_of_Dresolik = '$this->nSolRoTower_Protector_of_Dresolik', \n" .
						  "    SolRoTower_Solusek_Ro            = '$this->nSolRoTower_Solusek_Ro' \n" .
						  "WHERE CharID = $this->nCharID ";
	
		// Check if all the values are empty (delete record)
		if( ( $this->nHoH_Trial1_RyddaDar == 0 ) &&
			( $this->nHoH_Trial2_Ogre == 0 ) &&
			( $this->nHoH_Trial3_Madmen == 0 ) &&
			( $this->nHoHb_Mithanial_Marr == 0 ) &&
			( $this->nPoTactics_Tallon_Zek == 0 ) &&
			( $this->nPoTactics_Vallon_Zek == 0 ) &&
			( $this->nPoTactics_Rallos_Zek_Quest == 0 ) &&
			( $this->nBoT_Rescue_Karana_Quest == 0 ) &&
			( $this->nSolRoTower_Jiva == 0 ) &&
			( $this->nSolRoTower_Xuzl == 0 ) &&
			( $this->nSolRoTower_Arlyxir == 0 ) &&
			( $this->nSolRoTower_Rizlona == 0 ) &&
			( $this->nSolRoTower_Protector_of_Dresolik == 0 ) &&
			( $this->nSolRoTower_Solusek_Ro == 0 ) )
		{
			// Delete the record
			$strResult	= $this->DeleteRecord( $strTableName );
		}
		else
		{
			// Save the record
			$strResult	= $this->SaveRecord( $strTableName, $strInsertQuery, $strUpdateQuery );
		}
	
		// Done
		return $strResult;
	}
	
	
	
	// ========================================================================
	// Retrieve all Character data from the PoP_Tier_4_Flags table
	// ========================================================================
	function GetPoP_Tier_4_FlagsData()
	{
		return $this->GetDataFromTable( "PoP_Tier_4_Flags" );
	}



	// =============================================================================
	// Update the Pop Tier 4 Flags record
	// =============================================================================
	function UpdatePoP_Tier_4_FlagsData()
	{
		// Make sure all parameters have a value
		if( !isset( $this->nPoAir_Xegony ) )					{ $this->nPoAir_Xegony						= 0; }
		if( !isset( $this->nPoFire_Fennin_Ro ) )				{ $this->nPoFire_Fennin_Ro					= 0; }
		if( !isset( $this->nPoWater_Coirnav ) )					{ $this->nPoWater_Coirnav					= 0; }
		if( !isset( $this->nPoEarthb_The_Rathe ) )				{ $this->nPoEarthb_The_Rathe				= 0; }
		if( !isset( $this->nPoTime_Time_Phased_Quintessence ) )	{ $this->nPoTime_Time_Phased_Quintessence	= 0; }
	
		// Declare variables
		$strResult		= "UPDATE_FAILED";
		$strTableName	= "PoP_Tier_4_Flags";
		$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
						  "(CharID, PoAir_Xegony, PoFire_Fennin_Ro, PoWater_Coirnav, PoEarthb_The_Rathe, PoTime_Time_Phased_Quintessence) \n" .
						  "VALUES ($this->nCharID, '$this->nPoAir_Xegony', '$this->nPoFire_Fennin_Ro', '$this->nPoWater_Coirnav', '$this->nPoEarthb_The_Rathe', '$this->nPoTime_Time_Phased_Quintessence')";
		$strUpdateQuery	= "UPDATE `$strTableName` \n" .
						  "SET PoAir_Xegony                    = '$this->nPoAir_Xegony', \n" .
						  "    PoFire_Fennin_Ro                = '$this->nPoFire_Fennin_Ro', \n" .
						  "    PoWater_Coirnav                 = '$this->nPoWater_Coirnav', \n" .
						  "    PoEarthb_The_Rathe              = '$this->nPoEarthb_The_Rathe', \n" .
						  "    PoTime_Time_Phased_Quintessence = '$this->nPoTime_Time_Phased_Quintessence' \n" .
						  "WHERE CharID = $this->nCharID ";
	
		// Check if all the values are empty (delete record)
		if( ( $this->nPoAir_Xegony == 0 ) &&
			( $this->nPoFire_Fennin_Ro == 0 ) &&
			( $this->nPoWater_Coirnav == 0 ) &&
			( $this->nPoEarthb_The_Rathe == 0 ) &&
			( $this->nPoTime_Time_Phased_Quintessence == 0 ) )
		{
			// Delete the record
			$strResult	= $this->DeleteRecord( $strTableName );
		}
		else
		{
			// Save the record
			$strResult	= $this->SaveRecord( $strTableName, $strInsertQuery, $strUpdateQuery );
		}
	
		// Done
		return $strResult;
	}
	
	
	
	// ========================================================================
	// Retrieve all Character data from the PoS_Askr_Quest table
	// ========================================================================
	function GetPoS_Askr_QuestData()
	{
		return $this->GetDataFromTable( "PoS_Askr_Quest" );
	}



	// =============================================================================
	// Update the PoS_Askr_Quest record
	// =============================================================================
	function UpdatePoS_Askr_QuestData()
	{
		// Make sure all parameters have a value
		if( !isset( $this->nHead ) )		{ $this->nHead			= 0; }
		if( !isset( $this->nBeard ) )		{ $this->nBeard			= 0; }
		if( !isset( $this->nBone ) )		{ $this->nBone			= 0; }
		if( !isset( $this->nSash ) )		{ $this->nSash			= 0; }
		if( !isset( $this->nOceanMedal ) )	{ $this->nOceanMedal	= 0; }
		if( !isset( $this->nDesertMedal ) )	{ $this->nDesertMedal	= 0; }
		if( !isset( $this->nForestMedal ) )	{ $this->nForestMedal	= 0; }
	
		// Declare variables
		$strResult		= "UPDATE_FAILED";
		$strTableName	= "PoS_Askr_Quest";
		$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
						  "(CharID, Head, Beard, Bone, Sash, OceanMedal, DesertMedal, ForestMedal) \n" .
						  "VALUES ($this->nCharID, '$this->nHead', '$this->nBeard', '$this->nBone', '$this->nSash', '$this->nOceanMedal', '$this->nDesertMedal', '$this->nForestMedal')";
		$strUpdateQuery	= "UPDATE `$strTableName` \n" .
						  "SET Head         = '$this->nHead', \n" .
						  "    Beard        = '$this->nBeard', \n" .
						  "    Bone         = '$this->nBone', \n" .
						  "    Sash         = '$this->nSash', \n" .
						  "    OceanMedal   = '$this->nOceanMedal', \n" .
						  "    DesertMedal  = '$this->nDesertMedal', \n" .
						  "    ForestMedal  = '$this->nForestMedal' \n" .
						  "WHERE CharID = $this->nCharID ";
	
		// Check if all the values are empty (delete record)
		if( ( $this->nHead == 0 ) &&
			( $this->nBeard == 0 ) &&
			( $this->nBone == 0 ) &&
			( $this->nSash == 0 ) &&
			( $this->nOceanMedal == 0 ) &&
			( $this->nDesertMedal == 0 ) &&
			( $this->nForestMedal == 0 ) )
		{
			// Delete the record
			$strResult	= $this->DeleteRecord( $strTableName );
		}
		else
		{
			// Save the record
			$strResult	= $this->SaveRecord( $strTableName, $strInsertQuery, $strUpdateQuery );
		}
	
		// Done
		return $strResult;
	}
	
	
	
	// ========================================================================
	// Retrieve all Character data from the SSRA_Emperor_Key table
	// ========================================================================
	function GetSSRA_Emperor_KeyData()
	{
		return $this->GetDataFromTable( "SSRA_Emperor_Key" );
	}



	// =============================================================================
	// Update the SSRA_Emperor_Key record
	// =============================================================================
	function UpdateSSRA_Emperor_KeyData()
	{
		// Make sure all parameters have a value
		if( !isset( $this->nTaskmasters_Pouch ) )	{ $this->nTaskmasters_Pouch	= 0; }
		if( !isset( $this->nZazuzhs_Idol ) )		{ $this->nZazuzhs_Idol		= 0; }
		if( !isset( $this->nRing ) )				{ $this->nRing				= 0; }
		if( !isset( $this->nInsignia ) )			{ $this->nInsignia			= 0; }
	
		// Declare variables
		$strResult		= "UPDATE_FAILED";
		$strTableName	= "SSRA_Emperor_Key";
		$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
						  "(CharID, Taskmasters_Pouch, Zazuzhs_Idol, Ring, Insignia) \n" .
						  "VALUES ($this->nCharID, '$this->nTaskmasters_Pouch', '$this->nZazuzhs_Idol', '$this->nRing', '$this->nInsignia')";
		$strUpdateQuery	= "UPDATE `$strTableName` \n" .
						  "SET Taskmasters_Pouch  = '$this->nTaskmasters_Pouch', \n" .
						  "    Zazuzhs_Idol       = '$this->nZazuzhs_Idol', \n" .
						  "    Ring               = '$this->nRing', \n" .
						  "    Insignia           = '$this->nInsignia' \n" .
						  "WHERE CharID = $this->nCharID ";
	
		// Check if all the values are empty (delete record)
		if( ( $this->nTaskmasters_Pouch == 0 ) &&
			( $this->nZazuzhs_Idol == 0 ) &&
			( $this->nRing == 0 ) &&
			( $this->nInsignia == 0 ) )
		{
			// Delete the record
			$strResult	= $this->DeleteRecord( $strTableName );
		}
		else
		{
			// Save the record
			$strResult	= $this->SaveRecord( $strTableName, $strInsertQuery, $strUpdateQuery );
		}
	
		// Done
		return $strResult;
	}
	
	
	
	// ========================================================================
	// Retrieve all Character data from the TradeSkills table
	// ========================================================================
	function GetTradeSkillsData()
	{
		return $this->GetDataFromTable( "TradeSkills" );
	}



	// =============================================================================
	// Update the Tradeskills record
	// =============================================================================
	function UpdateTradeSkillsData()
	{
		// Make sure all parameters have a value
		if( !isset( $this->nAlchemy ) )		{ $this->nAlchemy		= 0; }
		if( !isset( $this->nBaking ) )		{ $this->nBaking		= 0; }
		if( !isset( $this->nBrewing ) )		{ $this->nBrewing		= 0; }
		if( !isset( $this->nFishing ) )		{ $this->nFishing		= 0; }
		if( !isset( $this->nFletching ) )	{ $this->nFletching		= 0; }
		if( !isset( $this->nForaging ) )	{ $this->nForaging		= 0; }
		if( !isset( $this->nJewelcraft ) )	{ $this->nJewelcraft	= 0; }
		if( !isset( $this->nPoison ) )		{ $this->nPoison		= 0; }
		if( !isset( $this->nPottery ) )		{ $this->nPottery		= 0; }
		if( !isset( $this->nResearch ) )	{ $this->nResearch		= 0; }
		if( !isset( $this->nSmithing ) )	{ $this->nSmithing		= 0; }
		if( !isset( $this->nTailoring ) )	{ $this->nTailoring		= 0; }
		if( !isset( $this->nTinkering ) )	{ $this->nTinkering		= 0; }
	
		// Declare variables
		$strResult		= "UPDATE_FAILED";
		$strTableName	= "TradeSkills";
		$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
						  "(CharID, Alchemy, Baking, Brewing, Fishing, Fletching, Foraging, Jewelcraft, Poison, Pottery, Research, Smithing, Tailoring, Tinkering) \n" .
						  "VALUES ($this->nCharID, '$this->nAlchemy', '$this->nBaking', '$this->nBrewing', '$this->nFishing', '$this->nFletching', '$this->nForaging', '$this->nJewelcraft', '$this->nPoison', '$this->nPottery', '$this->nResearch', '$this->nSmithing', '$this->nTailoring', '$this->nTinkering')";
		$strUpdateQuery	= "UPDATE `$strTableName` \n" .
						  "SET Alchemy    = '$this->nAlchemy', \n" .
						  "    Baking     = '$this->nBaking', \n" .
						  "    Brewing    = '$this->nBrewing', \n" .
						  "    Fishing    = '$this->nFishing', \n" .
						  "    Fletching  = '$this->nFletching', \n" .
						  "    Foraging   = '$this->nForaging', \n" .
						  "    Jewelcraft = '$this->nJewelcraft', \n" .
						  "    Poison     = '$this->nPoison', \n" .
						  "    Pottery    = '$this->nPottery', \n" .
						  "    Research   = '$this->nResearch', \n" .
						  "    Smithing   = '$this->nSmithing', \n" .
						  "    Tailoring  = '$this->nTailoring', \n" .
						  "    Tinkering  = '$this->nTinkering' \n" .
						  "WHERE CharID = $this->nCharID ";
	
		// Check if all the values are empty (delete record)
		if( ( $this->nAlchemy == 0 ) &&
			( $this->nBaking == 0 ) &&
			( $this->nBrewing == 0 ) &&
			( $this->nFishing == 0 ) &&
			( $this->nFletching == 0 ) &&
			( $this->nForaging == 0 ) &&
			( $this->nJewelcraft == 0 ) &&
			( $this->nPoison == 0 ) &&
			( $this->nPottery == 0 ) &&
			( $this->nResearch == 0 ) &&
			( $this->nSmithing == 0 ) &&
			( $this->nTailoring == 0 ) &&
			( $this->nTinkering == 0 ) )
		{
			// Delete the record
			$strResult	= $this->DeleteRecord( $strTableName );
		}
		else
		{
			// Save the record
			$strResult	= $this->SaveRecord( $strTableName, $strInsertQuery, $strUpdateQuery );
		}
	
		// Done
		return $strResult;
	}
	
	
	
	// ========================================================================
	// Retrieve all Character data from the Veeshans_Peak_Key table
	// ========================================================================
	function GetVeeshans_Peak_KeyData()
	{
		return $this->GetDataFromTable( "Veeshans_Peak_Key" );
	}



	// =============================================================================
	// Update the Veeshans_Peak_Key record
	// =============================================================================
	function UpdateVeeshans_Peak_KeyData()
	{
		// Make sure all parameters have a value
		if( !isset( $this->nKylongMedal_Top ) )		{ $this->nKylongMedal_Top		= 0; }
		if( !isset( $this->nKylongMedal_Middle ) )	{ $this->nKylongMedal_Middle	= 0; }
		if( !isset( $this->nKylongMedal_Bottom ) )	{ $this->nKylongMedal_Bottom	= 0; }
		if( !isset( $this->nJarsathMedal_Top ) )	{ $this->nJarsathMedal_Top		= 0; }
		if( !isset( $this->nJarsathMedal_Middle ) )	{ $this->nJarsathMedal_Middle	= 0; }
		if( !isset( $this->nJarsathMedal_Bottom ) )	{ $this->nJarsathMedal_Bottom	= 0; }
		if( !isset( $this->nObulusMedal_Top ) )		{ $this->nObulusMedal_Top		= 0; }
		if( !isset( $this->nObulusMedal_Middle ) )	{ $this->nObulusMedal_Middle	= 0; }
		if( !isset( $this->nObulusMedal_Bottom ) )	{ $this->nObulusMedal_Bottom	= 0; }
		if( !isset( $this->nTrak_Tooth ) )			{ $this->nTrak_Tooth			= 0; }
	
		// Declare variables
		$strResult		= "UPDATE_FAILED";
		$strTableName	= "Veeshans_Peak_Key";
		$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
						  "(CharID, KylongMedal_Top, KylongMedal_Middle, KylongMedal_Bottom, JarsathMedal_Top, JarsathMedal_Middle, JarsathMedal_Bottom, ObulusMedal_Top, ObulusMedal_Middle, ObulusMedal_Bottom, Trak_Tooth) \n" .
						  "VALUES ($this->nCharID, '$this->nKylongMedal_Top', '$this->nKylongMedal_Middle', '$this->nKylongMedal_Bottom', '$this->nJarsathMedal_Top', '$this->nJarsathMedal_Middle', '$this->nJarsathMedal_Bottom', '$this->nObulusMedal_Top', '$this->nObulusMedal_Middle', '$this->nObulusMedal_Bottom', '$this->nTrak_Tooth')";
		$strUpdateQuery	= "UPDATE `$strTableName` \n" .
						  "SET KylongMedal_Top      = '$this->nKylongMedal_Top', \n" .
						  "    KylongMedal_Middle   = '$this->nKylongMedal_Middle', \n" .
						  "    KylongMedal_Bottom   = '$this->nKylongMedal_Bottom', \n" .
						  "    JarsathMedal_Top     = '$this->nJarsathMedal_Top', \n" .
						  "    JarsathMedal_Middle  = '$this->nJarsathMedal_Middle', \n" .
						  "    JarsathMedal_Bottom  = '$this->nJarsathMedal_Bottom', \n" .
						  "    ObulusMedal_Top      = '$this->nObulusMedal_Top', \n" .
						  "    ObulusMedal_Middle   = '$this->nObulusMedal_Middle', \n" .
						  "    ObulusMedal_Bottom   = '$this->nObulusMedal_Bottom', \n" .
						  "    Trak_Tooth           = '$this->nTrak_Tooth' \n" .
						  "WHERE CharID = $this->nCharID ";
	
		// Check if all the values are empty (delete record)
		if( ( $this->nKylongMedal_Top == 0 ) &&
			( $this->nKylongMedal_Middle == 0 ) &&
			( $this->nKylongMedal_Bottom == 0 ) &&
			( $this->nJarsathMedal_Top == 0 ) &&
			( $this->nJarsathMedal_Middle == 0 ) &&
			( $this->nJarsathMedal_Bottom == 0 ) &&
			( $this->nObulusMedal_Top == 0 ) &&
			( $this->nObulusMedal_Middle == 0 ) &&
			( $this->nObulusMedal_Bottom == 0 ) &&
			( $this->nTrak_Tooth == 0 ) )
		{
			// Delete the record
			$strResult	= $this->DeleteRecord( $strTableName );
		}
		else
		{
			// Save the record
			$strResult	= $this->SaveRecord( $strTableName, $strInsertQuery, $strUpdateQuery );
		}
	
		// Done
		return $strResult;
	}
	
	
	
	// ========================================================================
	// Retrieve all Character data from the Vex_Thal_Key table
	// ========================================================================
	function GetVex_Thal_KeyData()
	{
		return $this->GetDataFromTable( "Vex_Thal_Key" );
	}



	// =============================================================================
	// Update the Vex_Thal_Key record
	// =============================================================================
	function UpdateVex_Thal_KeyData()
	{
		// Make sure all parameters have a value
		if( !isset( $this->nGlowing_Orb ) )		{ $this->nGlowing_Orb		= 0; }
		if( !isset( $this->nCelestial_Rift ) )	{ $this->nCelestial_Rift	= 0; }
		if( !isset( $this->nShard_Dat ) )		{ $this->nShard_Dat			= 0; }
		if( !isset( $this->nShard_Dax ) )		{ $this->nShard_Dax			= 0; }
		if( !isset( $this->nShard_Kel ) )		{ $this->nShard_Kel			= 0; }
		if( !isset( $this->nShard_Kelara ) )	{ $this->nShard_Kelara		= 0; }
		if( !isset( $this->nShard_Lor ) )		{ $this->nShard_Lor			= 0; }
		if( !isset( $this->nShard_Raf ) )		{ $this->nShard_Raf			= 0; }
		if( !isset( $this->nShard_Set ) )		{ $this->nShard_Set			= 0; }
		if( !isset( $this->nShard_Tak ) )		{ $this->nShard_Tak			= 0; }
		if( !isset( $this->nShard_Ved ) )		{ $this->nShard_Ved			= 0; }
		if( !isset( $this->nShard_Vin ) )		{ $this->nShard_Vin			= 0; }
	
		// Declare variables
		$strResult		= "UPDATE_FAILED";
		$strTableName	= "Vex_Thal_Key";
		$strInsertQuery	= "INSERT INTO `$strTableName` \n" .
						  "(CharID, Glowing_Orb, Celestial_Rift, Shard_Dat, Shard_Dax, Shard_Kel, Shard_Kelara, Shard_Lor, Shard_Raf, Shard_Set, Shard_Tak, Shard_Ved, Shard_Vin) \n" .
						  "VALUES ($this->nCharID, '$this->nGlowing_Orb', '$this->nCelestial_Rift', '$this->nShard_Dat', '$this->nShard_Dax', '$this->nShard_Kel', '$this->nShard_Kelara', '$this->nShard_Lor', '$this->nShard_Raf', '$this->nShard_Set', '$this->nShard_Tak', '$this->nShard_Ved', '$this->nShard_Vin')";
		$strUpdateQuery	= "UPDATE `$strTableName` \n" .
						  "SET Glowing_Orb     = '$this->nGlowing_Orb', \n" .
						  "    Celestial_Rift  = '$this->nCelestial_Rift', \n" .
						  "    Shard_Dat       = '$this->nShard_Dat', \n" .
						  "    Shard_Dax       = '$this->nShard_Dax', \n" .
						  "    Shard_Kel       = '$this->nShard_Kel', \n" .
						  "    Shard_Kelara    = '$this->nShard_Kelara', \n" .
						  "    Shard_Lor       = '$this->nShard_Lor', \n" .
						  "    Shard_Raf       = '$this->nShard_Raf', \n" .
						  "    Shard_Set       = '$this->nShard_Set', \n" .
						  "    Shard_Tak       = '$this->nShard_Tak', \n" .
						  "    Shard_Ved       = '$this->nShard_Ved', \n" .
						  "    Shard_Vin       = '$this->nShard_Vin' \n" .
						  "WHERE CharID = $this->nCharID ";
	
		// Check if all the values are empty (delete record)
		if( ( $this->nGlowing_Orb == 0 ) &&
			( $this->nCelestial_Rift == 0 ) &&
			( $this->nShard_Dat == 0 ) &&
			( $this->nShard_Dax == 0 ) &&
			( $this->nShard_Kel == 0 ) &&
			( $this->nShard_Kelara == 0 ) &&
			( $this->nShard_Lor == 0 ) &&
			( $this->nShard_Raf == 0 ) &&
			( $this->nShard_Set == 0 ) &&
			( $this->nShard_Tak == 0 ) &&
			( $this->nShard_Ved == 0 ) &&
			( $this->nShard_Vin == 0 ) )
		{
			// Delete the record
			$strResult	= $this->DeleteRecord( $strTableName );
		}
		else
		{
			// Save the record
			$strResult	= $this->SaveRecord( $strTableName, $strInsertQuery, $strUpdateQuery );
		}
	
		// Done
		return $strResult;
	}
	
	
	
	// =============================================================================
	// Delete a record
	// =============================================================================
	function DeleteRecord( $strTableName )
	{
		// Declare variables
		$strResult		= "DELETE_FAILED";
		$strDeleteQuery	= "DELETE FROM `$strTableName` WHERE CharID = $this->nCharID";

		// Connect to the database
		$nLinkID	= DBConnect();

		// Delete the record
		$nResult	= mysql_query( $strDeleteQuery, $nLinkID );

		// Set the status
		$strResult	= "RECORD_DELETED";

		// Close the connection
		DBDisconnect( $nLinkID );

		// Done
		return $strResult;
	}



	// =============================================================================
	// Save a record to a table, either by Inserting or Updating it.
	// =============================================================================
	function SaveRecord( $strTableName, $strInsertQuery, $strUpdateQuery )
	{
		// Declare variables
		$strResult		= "UPDATE_FAILED";
		$strCountQuery	= "SELECT COUNT(*) FROM `$strTableName` WHERE CharID = $this->nCharID";

		// Connect to the database
		$nLinkID	= DBConnect();

		// Check if the Char already exists
		$nResult	= mysql_query( $strCountQuery, $nLinkID );
		$aResult	= mysql_fetch_row( $nResult );
		if( ( isset( $aResult[0] ) ) &&
			( $aResult[0] >= 1 ) )
		{
			// Update the record
			$nResult	= mysql_query( $strUpdateQuery, $nLinkID );
			// Check if the update was succesfull
			if( $nResult == 1 )
			{
				$strResult	= "RECORD_UPDATED";
			}
			else
			{
				// Show error message
				print( "	<font color=\"" . $this->theSkin->strErrorColor . "\"><a> - Update `$strTableName` record FAILED (Char=" . $this->strCharName . ")!<br /></a></font>\n" );
				print( "    $strUpdateQuery<br />\n" );
				print( "    " . mysql_error() . "<br />\n" );
				exit( "<hr>" );
			}
		}
		else
		{
			// Insert the record
			$nResult	= mysql_query( $strInsertQuery, $nLinkID );
			// Check if the update was succesfull
			if( $nResult == 1 )
			{
				$strResult	= "RECORD_INSERTED";
			}
			else
			{
				// Show error message
				print( "	<font color=\"" . $this->theSkin->strErrorColor . "\"><a> - Insert of `$strTableName` record FAILED (Char=" . $this->strCharName . ")!<br /></a></font>\n" );
				print( "    $strUpdateQuery<br />\n" );
				print( "    " . mysql_error() . "<br />\n" );
				exit( "<hr>" );
			}
		}

		// Close the connection
		DBDisconnect( $nLinkID );

		// Done
		return $strResult;
	}



	// ========================================================================
	// Import a Character's EQPlayers profile
	//
	// This function creates the EQPlayers object first, and then calls the 
	// import. If you already have an EQPlayers object (for batch import for
	// example) then call ImportEQPlayersProfile() instead.
	// ========================================================================
	function ImportEQPlayersProfileExt()
	{
		// Create the EQPlayers object
		$theEQPlayers	= new EQPlayers( GetEQPlayersGuildID() );

		// Import the character
		return $this->ImportEQPlayersProfile( $theEQPlayers );
	}



	// ========================================================================
	// Import a Character's EQPlayers profile
	// ========================================================================
	// In: $theEQPlayers	= EQPlayers object
	// ========================================================================
	function ImportEQPlayersProfile( &$theEQPlayers )
	{
		// Declare variables
		$bImportOK		= false;

		// Check if we already know the EQPlayers CharacterID
		if( $this->nEQPlayersCharID > 0 )
		{
			// Import by CharacterID
			$bImportOK	= $theEQPlayers->ImportCharacterByID( $this->nEQPlayersCharID, $this->strCharName );
		}
		else
		{
			// Import by Character Name
			$bImportOK	= $theEQPlayers->ImportCharacterByName( $this->strCharName );
		}

		// Import the EQPlayers profile
		if( $bImportOK )
		{
			// Retrieve Character info
			$this->nEQPlayersCharID	= $theEQPlayers->nCharacterID;
			if( $theEQPlayers->strLastName != "" )	{ $this->strLastName	= $theEQPlayers->strLastName;	}
			if( $theEQPlayers->nLevel > 0 )			{ $this->nLevel			= $theEQPlayers->nLevel;		}
			if( $theEQPlayers->strRace != "" )		{ $this->strRace		= $theEQPlayers->strRace;		}
			if( $theEQPlayers->strDeity != "" )		{ $this->strDeity		= $theEQPlayers->strDeity;		}
			// Retrieve the statistics
			if( $theEQPlayers->nHP > 0 )			{ $this->nHP			= $theEQPlayers->nHP;			}
			if( $theEQPlayers->nMana > 0 )			{ $this->nMana			= $theEQPlayers->nMana;			}
			if( $theEQPlayers->nEndurance > 0 )		{ $this->nEndurance		= $theEQPlayers->nEndurance;	}
			if( $theEQPlayers->nAC > 0 )			{ $this->nAC			= $theEQPlayers->nAC;			}
			if( $theEQPlayers->nAtk > 0 )			{ $this->nAtk			= $theEQPlayers->nAtk;			}
			if( $theEQPlayers->nStr > 0 )			{ $this->nStr			= $theEQPlayers->nStr;			}
			if( $theEQPlayers->nSta > 0 )			{ $this->nSta			= $theEQPlayers->nSta;			}
			if( $theEQPlayers->nAgi > 0 )			{ $this->nAgi			= $theEQPlayers->nAgi;			}
			if( $theEQPlayers->nDex > 0 )			{ $this->nDex			= $theEQPlayers->nDex;			}
			if( $theEQPlayers->nWis > 0 )			{ $this->nWis			= $theEQPlayers->nWis;			}
			if( $theEQPlayers->nInt > 0 )			{ $this->nInt			= $theEQPlayers->nInt;			}
			if( $theEQPlayers->nCha > 0 )			{ $this->nCha			= $theEQPlayers->nCha;			}
			if( $theEQPlayers->nPR > 0 )			{ $this->nPR			= $theEQPlayers->nPR;			}
			if( $theEQPlayers->nMR > 0 )			{ $this->nMR			= $theEQPlayers->nMR;			}
			if( $theEQPlayers->nDR > 0 )			{ $this->nDR			= $theEQPlayers->nDR;			}
			if( $theEQPlayers->nFR > 0 )			{ $this->nFR			= $theEQPlayers->nFR;			}
			if( $theEQPlayers->nCR > 0 )			{ $this->nCR			= $theEQPlayers->nCR;			}

			// Retrieve the LastOnDate
			if( $theEQPlayers->strLastOnDate != "0000-00-00" )
			{
				$this->strLastOnDate	= $theEQPlayers->strLastOnDate;
			}
		}

		// Done
		return $bImportOK;
	}




	// ========================================================================
	// Import a Character's Magelo profile
	// ========================================================================
	function ImportMageloProfile()
	{
		// Create the magelo object
		$theMagelo	= new Magelo( $this->nMageloNr, $this->strCharName, $this->strClass );
		// Import the magelo
		$bImportOK	= $theMagelo->Import();
		if( $bImportOK )
		{
			// Character info
			$this->strLastName		= $theMagelo->strLastName;
			$this->nLevel			= $theMagelo->nLevel;
			if( $theMagelo->nAA > $this->nAA )			{	$this->nAA					= $theMagelo->nAA;			}
			if( $theMagelo->nNrOfGLPs > $this->nGLP )	{	$this->nGLP					= $theMagelo->nNrOfGLPs;	}
			if( $this->strRace != "" )					{	$this->strRace				= $theMagelo->strRace;		}
			// Magelo returns "Half Elf" as "Half-Elf", so we convert it back.
			if( $this->strRace == "Half-Elf" )			{	$this->strRace				= "Half Elf";				}

			// Character Statistics
			$this->nHP			= $theMagelo->nHP;
			$this->nMana		= $theMagelo->nMana;
//			$this->nEndurance	= $theMagelo->nEndurance;
			$this->nAC			= $theMagelo->nAC;
			$this->nFT			= $theMagelo->nFT;
			$this->nRegen		= $theMagelo->nRegen;
			$this->nAtk			= $theMagelo->nAtk;
			$this->nStr			= $theMagelo->nStr;
			$this->nSta			= $theMagelo->nSta;
			$this->nAgi			= $theMagelo->nAgi;
			$this->nDex			= $theMagelo->nDex;
			$this->nWis			= $theMagelo->nWis;
			$this->nInt			= $theMagelo->nInt;
			$this->nCha			= $theMagelo->nCha;
			$this->nPR			= $theMagelo->nPR;
			$this->nMR			= $theMagelo->nMR;
			$this->nDR			= $theMagelo->nDR;
			$this->nFR			= $theMagelo->nFR;
			$this->nCR			= $theMagelo->nCR;

			// DoN Flags
			if( $theMagelo->nDoN_Tier1_Done == 1 )		{	$this->nT1_Create_an_Antidote			= 1;
															$this->nT1_Greed_of_the_Goblins			= 1;
															$this->nT1_Burning_Arrows				= 1;
															$this->nT1_Children_of_Gimblax			= 1;	}
			if( $theMagelo->nDoN_Tier2_Done == 1 )		{	$this->nT2_Defend_the_Kirin_Contact		= 1;
															$this->nT2_Recover_the_Lost_Map			= 1;
															$this->nT2_Turn_the_Tides_of_the_Sand	= 1;
															$this->nT2_Sickness_of_the_Spirit		= 1;
															$this->nT2_Calling_Emoush				= 1;	}
			if( $theMagelo->nDoN_Tier3_Done == 1 )		{	$this->nT3_Protect_the_Waters			= 1;
															$this->nT3_Snowfoots_Revenge			= 1;
															$this->nT3_The_Sacred_Scrolls			= 1;
															$this->nT3_History_of_the_Isle			= 1;
															$this->nT3_Trial_of_Perserverance		= 1;
															$this->nT3_Volkaras_Bite				= 1;	}
			if( $theMagelo->nDoN_Tier4_Done == 1 )		{	$this->nT4_Goblin_Dojo					= 1;
															$this->nT4_Guardian_of_the_Sands		= 1;
															$this->nT4_An_End_to_the_Storms			= 1;	}
			if( $theMagelo->nDoN_Tier5_Done == 1 )		{	$this->nT5_Origins_of_the_Curse			= 1;
															$this->nT5_The_Curse_of_JuRek			= 1;
															$this->nT5_In_the_Shadows				= 1;	}

			// GoD Flags
			if( $theMagelo->nPurifying_Plant == 1 )		{	$this->nPurifying_Plant			= $theMagelo->nPurifying_Plant;		}
			if( $theMagelo->nEmanating_Furnace == 1 )	{	$this->nEmanating_Furnace		= $theMagelo->nEmanating_Furnace;	}
			if( $theMagelo->nLair_of_Trapped_Ones == 1 ){	$this->nLair_of_Trapped_Ones	= $theMagelo->nLair_of_Trapped_Ones;}
			if( $theMagelo->nPool_of_Sludge == 1 )		{	$this->nPool_of_Sludge			= $theMagelo->nPool_of_Sludge;		}
			if( $theMagelo->nSmith_Rondo == 1 )			{	$this->nSmith_Rondo				= $theMagelo->nSmith_Rondo;			}
			if( $theMagelo->nVxed == 1 )				{	$this->nVxed					= $theMagelo->nVxed;				}
			if( $theMagelo->nTipt == 1 )				{	$this->nTipt					= $theMagelo->nTipt;				}
			if( $theMagelo->nVrex_Barxt_Qurat == 1 )	{	$this->nVrex_Barxt_Qurat		= $theMagelo->nVrex_Barxt_Qurat;	}
			if( $theMagelo->nCynosure_Kvanjji == 1 )	{	$this->nCynosure_Kvanjji		= $theMagelo->nCynosure_Kvanjji;	}
			if( $theMagelo->nNoqufiel_in_Inktuta == 1 )	{	$this->nNoqufiel_in_Inktuta		= $theMagelo->nNoqufiel_in_Inktuta;	}
			if( $theMagelo->nZunMuram_Tkarish_Zyk == 1 ){	$this->nZunMuram_Tkarish_Zyk	= $theMagelo->nZunMuram_Tkarish_Zyk;}

			// Keys
			if( $theMagelo->nVexThalKey == 1 )			{	$this->nVex_Thal_Key		= $theMagelo->nVexThalKey;
															// Set all key flags to true as well
															$this->nGlowing_Orb			= 1;
															$this->nCelestial_Rift		= 1;
															$this->nShard_Dat			= 1;
															$this->nShard_Dax			= 1;
															$this->nShard_Kel			= 1;
															$this->nShard_Kelara		= 1;
															$this->nShard_Lor			= 1;
															$this->nShard_Raf			= 1;
															$this->nShard_Set			= 1;
															$this->nShard_Tak			= 1;
															$this->nShard_Ved			= 1;
															$this->nShard_Vin			= 1;						}
			if( $theMagelo->nSebilisKey == 1 )			{	$this->nSebilis_Key			= $theMagelo->nSebilisKey;	}
			if( $theMagelo->nVeeshansPeakKey == 1 )		{	$this->nVeeshans_Peak_Key	= $theMagelo->nVeeshansPeakKey;
															// Set all key flags to true as well
															$this->nKylongMedal_Top		= 1;
															$this->nKylongMedal_Middle	= 1;
															$this->nKylongMedal_Bottom	= 1;
															$this->nJarsathMedal_Top	= 1;
															$this->nJarsathMedal_Middle	= 1;
															$this->nJarsathMedal_Bottom	= 1;
															$this->nObulusMedal_Top		= 1;
															$this->nObulusMedal_Middle	= 1;
															$this->nObulusMedal_Bottom	= 1;
															$this->nTrak_Tooth			= 1;						}
			if( $theMagelo->nHowlingStonesKey == 1 )	{	$this->nHowling_Stones_Key	= $theMagelo->nHowlingStonesKey;	}
			if( $theMagelo->nSleepersTombKey == 1 )		{	$this->nSleepers_Tomb_Key	= $theMagelo->nSleepersTombKey;		}
			if( $theMagelo->nSSRAEmperorKey == 1 )		{	$this->nSSRA_Emperor_Key	= $theMagelo->nSSRAEmperorKey;
															// Set all key flags to true as well
															$this->nTaskmasters_Pouch	= 1;
															$this->nZazuzhs_Idol		= 1;
															$this->nRing				= 1;
															$this->nInsignia			= 1;						}
			if( $theMagelo->nPoS_Askr_Quest == 1 )		{	$this->nHead				= 1;
															$this->nBeard				= 1;
															$this->nBone				= 1;
															$this->nSash				= 1;						}

			// OoW_CoA Flags/Signets
			if( $theMagelo->nSeal_Mastery_of_All == 1 )	{	$this->nSeal_Mastery_of_All		= $theMagelo->nSeal_Mastery_of_All;	}
			if( $theMagelo->nCrystal_Gemmed_Signet == 1 ){	$this->nSignet_Crystal_Gemmed	= $theMagelo->nCrystal_Gemmed_Signet;}
			if( $theMagelo->nDiscolored_Signet == 1 )	{	$this->nSignet_Discolored		= $theMagelo->nDiscolored_Signet;	}
			if( $theMagelo->nDust_Marred_Signet == 1 )	{	$this->nSignet_Dust_Marred		= $theMagelo->nDust_Marred_Signet;	}
			if( $theMagelo->nGlimmering_Signet == 1 )	{	$this->nSignet_Glimmering		= $theMagelo->nGlimmering_Signet;	}
			if( $theMagelo->nTarnished_Signet == 1 )	{	$this->nSignet_Tarnished		= $theMagelo->nTarnished_Signet;	}
			if( $theMagelo->nTwo_Toned_Signet == 1 )	{	$this->nSignet_Two_Toned		= $theMagelo->nTwo_Toned_Signet;	}
			if( $theMagelo->nWeather_Worn_Signet == 1 )	{	$this->nSignet_Weather_Worn		= $theMagelo->nWeather_Worn_Signet;	}

			// Pop Tier 1 Flags
			if( $theMagelo->nAny_PoJ_Trial == 1 )		{	$this->nAny_PoJ_Trial			= $theMagelo->nAny_PoJ_Trial;		}
			if( $theMagelo->nAll_PoJ_Trials == 1 )		{	$this->nAll_PoJ_Trials			= $theMagelo->nAll_PoJ_Trials;		}
			if( $theMagelo->nPoI_Xanamech == 1 )		{	$this->nPoI_Xanamech			= $theMagelo->nPoI_Xanamech;		}
			if( $theMagelo->nPoI_Behemoth == 1 )		{	$this->nPoI_Behemoth			= $theMagelo->nPoI_Behemoth;		}
			if( $theMagelo->nPoD_Grimror_Quest == 1 )	{	$this->nPoD_Grimror_Quest		= $theMagelo->nPoD_Grimror_Quest;	}
			if( $theMagelo->nPoD_Grummus == 1 )			{	$this->nPoD_Grummus				= $theMagelo->nPoD_Grummus;			}
			if( $theMagelo->nPoN_Hedge_Quest == 1 )		{	$this->nPoN_Hedge_Quest			= $theMagelo->nPoN_Hedge_Quest;		}
			if( $theMagelo->nPoNb_Terris_Thule == 1 )	{	$this->nPoNb_Terris_Thule		= $theMagelo->nPoNb_Terris_Thule;	}

			// Pop Tier 2 Flags
			if( $theMagelo->nPoS_Askr_Quest == 1 )		{	$this->nPoS_Askr_Quest			= $theMagelo->nPoS_Askr_Quest;		}
			if( $theMagelo->nPoV_Grenic_Quest == 1 )	{	$this->nPoV_Grenic_Quest		= $theMagelo->nPoV_Grenic_Quest;	}
			if( $theMagelo->nPoV_AerinDar == 1 )		{	$this->nPoV_AerinDar			= $theMagelo->nPoV_AerinDar;		}
			if( $theMagelo->nCoD_Bertoxxulous == 1 )	{	$this->nCoD_Bertoxxulous		= $theMagelo->nCoD_Bertoxxulous;	}
			if( $theMagelo->nPoTorment_Saryrn == 1 )	{	$this->nPoTorment_Saryrn		= $theMagelo->nPoTorment_Saryrn;	}
			if( $theMagelo->nPoS_Wembly_Quest == 1 )	{	$this->nPoS_Wembly_Quest		= $theMagelo->nPoS_Wembly_Quest;	}

			// Pop Tier 3 Flags
			if( $theMagelo->nHoH_Trial1_RyddaDar == 1 )	{	$this->nHoH_Trial1_RyddaDar		= $theMagelo->nHoH_Trial1_RyddaDar;					}
			if( $theMagelo->nHoH_Trial2_Ogre == 1 )		{	$this->nHoH_Trial2_Ogre			= $theMagelo->nHoH_Trial2_Ogre;						}
			if( $theMagelo->nHoH_Trial3_Madmen == 1 )	{	$this->nHoH_Trial3_Madmen		= $theMagelo->nHoH_Trial3_Madmen;					}
			if( $theMagelo->nHoHb_Mithanial_Marr == 1 )	{	$this->nHoHb_Mithanial_Marr		= $theMagelo->nHoHb_Mithanial_Marr;					}
			if( $theMagelo->nPoTactics_Tallon_Zek == 1 ){	$this->nPoTactics_Tallon_Zek	= $theMagelo->nPoTactics_Tallon_Zek;				}
			if( $theMagelo->nPoTactics_Vallon_Zek == 1 ){	$this->nPoTactics_Vallon_Zek	= $theMagelo->nPoTactics_Vallon_Zek;				}
			if( $theMagelo->nPoTactics_Rallos_Zek_Quest == 1 ){	$this->nPoTactics_Rallos_Zek_Quest	= $theMagelo->nPoTactics_Rallos_Zek_Quest;	}
			if( $theMagelo->nBoT_Rescue_Karana_Quest == 1 ){	$this->nBoT_Rescue_Karana_Quest		= $theMagelo->nBoT_Rescue_Karana_Quest;		}
			if( $theMagelo->nSolRoTower_Jiva == 1 )		{	$this->nSolRoTower_Jiva			= $theMagelo->nSolRoTower_Jiva;						}
			if( $theMagelo->nSolRoTower_Xuzl == 1 )		{	$this->nSolRoTower_Xuzl			= $theMagelo->nSolRoTower_Xuzl;						}
			if( $theMagelo->nSolRoTower_Arlyxir == 1 )	{	$this->nSolRoTower_Arlyxir		= $theMagelo->nSolRoTower_Arlyxir;					}
			if( $theMagelo->nSolRoTower_Rizlona == 1 )	{	$this->nSolRoTower_Rizlona		= $theMagelo->nSolRoTower_Rizlona;					}
			if( $theMagelo->nSolRoTower_Protector_of_Dresolik == 1 ){	$this->nSolRoTower_Protector_of_Dresolik	= $theMagelo->nSolRoTower_Protector_of_Dresolik;}
			if( $theMagelo->nSolRoTower_Solusek_Ro == 1 ){	$this->nSolRoTower_Solusek_Ro	= $theMagelo->nSolRoTower_Solusek_Ro;				}

			// Pop Tier 4 Flags
			if( $theMagelo->nPoAir_Xegony == 1 )		{	$this->nPoAir_Xegony			= $theMagelo->nPoAir_Xegony;		}
			if( $theMagelo->nPoFire_Fennin_Ro == 1 )	{	$this->nPoFire_Fennin_Ro		= $theMagelo->nPoFire_Fennin_Ro;	}
			if( $theMagelo->nPoWater_Coirnav == 1 )		{	$this->nPoWater_Coirnav			= $theMagelo->nPoWater_Coirnav;		}
			if( $theMagelo->nPoEarthb_The_Rathe == 1 )	{	$this->nPoEarthb_The_Rathe		= $theMagelo->nPoEarthb_The_Rathe;	}
			if( $theMagelo->nPoTime_Time_Phased_Quintessence == 1 )	{	$this->nPoTime_Time_Phased_Quintessence	= 1;		}

			// Tradeskills
			if( $theMagelo->nAlchemy > $this->nAlchemy )		{	$this->nAlchemy			= $theMagelo->nAlchemy;		}
			if( $theMagelo->nBaking > $this->nBaking )			{	$this->nBaking			= $theMagelo->nBaking;		}
			if( $theMagelo->nBrewing > $this->nBrewing )		{	$this->nBrewing			= $theMagelo->nBrewing;		}
			if( $theMagelo->nFishing > $this->nFishing )		{	$this->nFishing			= $theMagelo->nFishing;		}
			if( $theMagelo->nFletching > $this->nFletching )	{	$this->nFletching		= $theMagelo->nFletching;	}
			if( $theMagelo->nForaging > $this->nForaging )		{	$this->nForaging		= $theMagelo->nForaging;	}
			if( $theMagelo->nJewelry > $this->nJewelry )		{	$this->nJewelcraft		= $theMagelo->nJewelry;		}
			if( $theMagelo->nPosionMaking > $this->nPosionMaking ){	$this->nPoison			= $theMagelo->nPosionMaking;}
			if( $theMagelo->nPottery > $this->nPottery )		{	$this->nPottery			= $theMagelo->nPottery;		}
			if( $theMagelo->nResearch > $this->nResearch )		{	$this->nResearch		= $theMagelo->nResearch;	}
			if( $theMagelo->nSmithing > $this->nSmithing )		{	$this->nSmithing		= $theMagelo->nSmithing;	}
			if( $theMagelo->nTailoring > $this->nTailoring )	{	$this->nTailoring		= $theMagelo->nTailoring;	}
			if( $theMagelo->nTinkering > $this->nTinkering )	{	$this->nTinkering		= $theMagelo->nTinkering;	}
		}

		// Done
		return $bImportOK;
	}
}

?>
