<?php
// Includes
require_once( './config.php' );
require_once( './includes/form.inc' );
require_once( './includes/functions.inc' );


// Main PHP code
{
	// Declare variables
	$strFormName		= $_GET['FormName'];
	$strUserName		= $_GET['UserName'];
	$strPassword		= $_GET['Password'];
	$strSortOrder		= $_GET['SortOrder'];
	$strSortDirection	= $_GET['SortDirection'];
	$strShowAlts		= $_GET['ShowAlts'];
	$strClassFilter		= $_GET['ClassFilter'];

	// Create the Form object
	$theForm		= new $strFormName;

	// Check if we're on the User_Create
	if( ( $strFormName == "User_Modify" ) &&
		( !IsUserVerified( $strUserName ) ) )
	{
		// Show the Form Footer
		$theForm->ShowFooter( $strUserName, $strPassword );
	}
	else
	{
		// NEVER pass the UserName and Password to ...
		if( $strFormName == "User_Verify" )		// The User_Verify page
		{
			$strUserName	= "";
			$strPassword	= "";
		}

		// Show the footer
		ShowFooter( $strUserName, $strPassword, $strFormName, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter );
	}
}



// Show the footer
function ShowFooter( $strUserName, $strPassword, $strFormName, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
{
	// Declare variables
	$theSkin	= new Skin();
	
	// Check if we should show the User link
	$strUserLink	= "";
	if( ( isset( $strUserName ) ) &&
		( $strUserName != "Guest" ) &&
		( $strUserName != "" ) )
	{
		$strUserLink		= '<a href="form.php?FormName=User_Modify&UserName='			. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '&ModifyUserName=' . $strUserName . '"	OnMouseOver="window.status=\'Modify ' . $strUserName . '\\\'s settings\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Modify ' . $strUserName . '\'s settings"><img src="' . GetSkinDir() . 'images/modify.gif" border="0" /></a> ';
		
		// Check if the user has Administrator rights
		if( IsAdministrator( $strUserName ) )
		{
			$strUserLink	= '<a href="form.php?FormName=Characters_Delete&UserName='		. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Delete characters\';return true;"							OnMouseOut="window.status=\'\'"	target=Body title="Delete characters"><img src="' . GetSkinDir() . 'images/trashcan.gif" border="0" /></a> ' .
							  '<a href="form_guildtool_update.php?UserName='				. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Update the roster from a guild dump\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Update the roster from a guild dump"><img src="' . GetSkinDir() . 'images/import.gif" border="0" /></a> ' .
							  $strUserLink .
							  '<a href="form.php?FormName=Users&UserName='					. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Show all Roster Users\';return true;"						OnMouseOut="window.status=\'\'"	target=Body title="Show all Roster Users"><img src="' . GetSkinDir() . 'images/users.gif" border="0" /></a> ';
		}

		// Only show the EQPlayers icon if the GuildID is set in the config.php
		if( GetEQPlayersGuildID() > 0 )
		{
			$strUserLink	.= '<a href="form.php?FormName=EQPlayers_Batch_Import&UserName='. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Batch Import EQPlayers character profiles\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Batch Import EQPlayers character profiles"><img src="' . GetSkinDir() . 'images/eqplayers.gif" border="0" /></a> ';
		}

		$strUserLink		.= '<a href="form.php?FormName=Magelo_Batch_Import&UserName='	. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Batch Import Magelo character profiles\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Batch Import Magelo character profiles"><img src="' . GetSkinDir() . 'images/magelo.gif" border="0" /></a> ';
	}

	// Check if we should show the Login or Logoff
	$strLastLink	= "";
	if( ( !isset( $strUserName ) ) ||
		( $strUserName == "" ) )
	{
		$strLogInOutLink	= '<a href="form.php?FormName=User_Login&UserName='	. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Log in\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Log in">Log in</a>';
	}
	else
	{
		$strLogInOutLink	= '<a href="form.php?FormName=Characters&UserName=&Password=&CookieAction=DELETE&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Log ' . $strUserName . ' out\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Log ' . $strUserName . ' out">Log out</a>';
	}

	// Create the overview select
	$strSelectOverview	= '<select name="cmbOverview" id="cmbOverview" onChange="ShowOverview();" class="SelectBox" title="Select the overview you want to display">
		      <option class="OptionOdd"		value="<<Choose>>"				title="Choose one of the overviews in the list..."								><< Make a selection >></option>
		      <option class="OptionEven"	value="GoD_BiC"					title="Show the Gates of Discord: Breakdown in Communication Quest overview"	>Breakdown in Communication Quest</option>
		      <option class="OptionOdd"		value="Characters"				title="Show the Characters overview"											>Characters</option>
		      <option class="OptionEven"	value="Character_Statistics"	title="Show the Character Statistics overview"									>Character Statistics</option>
		      <option class="OptionOdd"		value="DemiPlane_of_Blood"		title="Show the Demi-Plane of Blood Access overview"							>Demi-Plane of Blood Access</option>
		      <option class="OptionEven"	value="DoD_Mask"				title="Show the Depths of Darkhollow: Mask Missions overview"					>Depths of Darkhollow: Mask Missions</option>
		      <option class="OptionOdd"		value="DoD_Spells"				title="Show the Depths of Darkhollow: Spell Missions overview"					>Depths of Darkhollow: Spell Missions</option>
		      <option class="OptionEven"	value="GoD_DSS"					title="Show the Gates of Discord: Discord Skin Samples (Tongue) Quest overview"	>Discord Skin Samples (Tongue) Quest</option>
		      <option class="OptionOdd"		value="DoN_Flags"				title="Show the Dragons of Norrath Flags overview"								>Dragons of Norrath Flags</option>
		      <option class="OptionEven"	value="Dreadspire_Keep"			title="Show the Dreadspire Keep Access overview"								>Dreadspire Keep Access</option>
		      <option class="OptionOdd"		value="GoD_Flags"				title="Show the Gates of Discord Flags overview"								>Gates of Discord Flags</option>
		      <option class="OptionEven"	value="Keys"					title="Show the Keys overview"													>Keys</option>
		      <option class="OptionOdd"		value="OoW_CoA"					title="Show the Omens of War: Citadel of Anguish overview"						>Omens of War: Citadel of Anguish</option>
		      <option class="OptionEven"	value="PoP_Tier_1_Flags"		title="Show the Planes of Power: Tier 1 Flags overview"							>Planes of Power: Tier 1 Flags</option>
		      <option class="OptionOdd"		value="PoP_Tier_2_Flags"		title="Show the Planes of Power: Tier 2 Flags overview"							>Planes of Power: Tier 2 Flags</option>
		      <option class="OptionEven"	value="PoP_Tier_3_Flags"		title="Show the Planes of Power: Tier 3 Flags overview"							>Planes of Power: Tier 3 Flags</option>
		      <option class="OptionOdd"		value="PoP_Tier_4_Flags"		title="Show the Planes of Power: Tier 4 Flags overview"							>Planes of Power: Tier 4 Flags</option>
		      <option class="OptionEven"	value="PoS_Askr_Quest"			title="Show the Plane of Storms: Askr Quest overview"							>Plane of Storms: Askr Quest</option>
		      <option class="OptionOdd"		value="SSRA_Keys"				title="Show the SSRA Emperor keys overview"										>Ssraeshza Temple Emperor keys</option>
		      <option class="OptionEven"	value="Theatre_of_Blood"		title="Show the Theatre of Blood Access overview"								>Theatre of Blood Access</option>
		      <option class="OptionOdd"		value="TradeSkills"				title="Show the Trade Skills overview"											>Trade Skills</option>
		      <option class="OptionEven"	value="Veeshans_Peak_keys"		title="Show the Veeshans Peak keys overview"									>Veeshans Peak keys</option>
		      <option class="OptionOdd"		value="Vex_Thal_keys"			title="Show the Vex Thal keys overview"											>Vex Thal keys</option>
		  </select>';
	// Select the current value
	$strSelectOverview	= str_replace( '"' . $strFormName . '"', '"' . $strFormName . '" selected="selected"', $strSelectOverview );

	// Create the class filter select
	$strSelectClassFilter	= '<select name="cmbClassFilter" id="cmbClassFilter" onChange="SetClassFilter();" class="SelectBox" title="Select a class filter">
		      <option class="OptionOdd"  value="<<All>>"		title="Show all classes"			><< All >></option>
		      <option class="OptionEven" value="Bard"			title="Only show Bards"				>Bard</option>
		      <option class="OptionOdd"  value="Beastlord"		title="Only show Beastlords"		>Beastlord</option>
		      <option class="OptionEven" value="Berserker"		title="Only show Berserkers"		>Berserker</option>
		      <option class="OptionOdd"  value="Cleric"			title="Only show Clerics"			>Cleric</option>
		      <option class="OptionEven" value="Druid"			title="Only show Druids"			>Druid</option>
		      <option class="OptionOdd"  value="Enchanter"		title="Only show Enchanters"		>Enchanter</option>
		      <option class="OptionEven" value="Magician"		title="Only show Magicians"			>Magician</option>
		      <option class="OptionOdd"  value="Monk"			title="Only show Monks"				>Monk</option>
		      <option class="OptionEven" value="Necromancer"	title="Only show Necromancers"		>Necromancer</option>
		      <option class="OptionOdd"  value="Paladin"		title="Only show Paladins"			>Paladin</option>
		      <option class="OptionEven" value="Ranger"			title="Only show Rangers"			>Ranger</option>
		      <option class="OptionOdd"  value="Rogue"			title="Only show Rogues"			>Rogue</option>
		      <option class="OptionEven" value="Shadow Knight"	title="Only show Shadow Knights"	>Shadow Knight</option>
		      <option class="OptionOdd"  value="Shaman"			title="Only show Shamans"			>Shaman</option>
		      <option class="OptionEven" value="Warrior"		title="Only show Warriors"			>Warrior</option>
		      <option class="OptionOdd"  value="Wizard"			title="Only show Wizards"			>Wizard</option>
		  </select>';
	// Select the current value
	$strSelectClassFilter	= str_replace( '"' . $strClassFilter . '"', '"' . $strClassFilter . '" selected="selected"', $strSelectClassFilter );


	// Show the page
	echo '<html>
<head>
	<title>EverQuest Roster: Roster Footer</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<link rel="stylesheet" href="' . GetSkinDir() . 'roster.css" type="text/css">
</head>

<body>
	<script language="JavaScript">
	<!-- Show the selected overview -->
	function ShowOverview()
	{
		// Check if an overview was chosen
		if( document.all.cmbOverview.value != "<<Choose>>" )
		{
			// Submit the form
			parent.location = "form.php?FormName=" + document.all.cmbOverview.value + "&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&ShowAlts=' . $strShowAlts . '&ClassFilter=' . $strClassFilter . '";
		}

		// Done
		return true;
	};

	<!-- Filter on the selected class -->
	function SetClassFilter()
	{
		// Submit the form
		parent.location = "form.php?FormName=' . $strFormName . '&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection . '&ShowAlts=' . $strShowAlts . '&ClassFilter=" + document.all.cmbClassFilter.value;

		// Done
		return true;
	};
	</script>

	<!-- Start of Footer -->
	<div id="Footer" align="center">
	<table width="98%" border="0" cellspacing="0" cellpadding="0">
	  <tr>
		<td align="center">
		  ' . $strUserLink . '
		  <a href="form.php?FormName=Statistics'			. '&UserName='	. $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '"					OnMouseOver="window.status=\'Show Roster/Guild Statistics\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Show Roster/Guild Statistics"><img src="' . GetSkinDir() . 'images/statistics.gif" border="0" /></a> | 
		  <font color="' . $theSkin->strFooterFontColor . '">Overview: </font>
		  ' . $strSelectOverview . ' | 
		  <font color="' . $theSkin->strFooterFontColor . '">Class: </font>
		  ' . $strSelectClassFilter . ' | 
		  ' . $strLogInOutLink . '
		</td>
	  </tr>
	  <tr>
		<td align="center">
		  <font size="-1" color="' . $theSkin->strSpecialFooterFontColor . '">
		    EverQuest Roster 4.2.1 &#160&#160&#160 
		  </font>
		  <font size="-1">
		    ( <a href="http://eqroster.gameplayheaven.com/history.html"	OnMouseOver="window.status=\'Show the history of the EverQuest Roster\';return true;"	OnMouseOut="window.status=\'\'"	target=_blank title="Show the history of the EverQuest Roster">History</a>
		    / <a href="http://forums.gameplayheaven.com"				OnMouseOver="window.status=\'Go to the official EverQuest Roster forums\';return true;"	OnMouseOut="window.status=\'\'"	target=_blank title="Go to the official EverQuest Roster forums">Forums</a> )
		  </font>
		  <font size="-1" color="' . $theSkin->strSpecialFooterFontColor . '">
		     &#160&#160&#160 &#169 GamePlayHeaven
		  </font>
		</td>
	  </tr>
	</table>
	</div>
	<!-- End of Footer -->

</body>
</html>
	';
}

?>
