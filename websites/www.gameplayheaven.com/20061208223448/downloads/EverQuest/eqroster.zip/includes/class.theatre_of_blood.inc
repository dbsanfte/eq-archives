<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );
require_once( GetSkinDir() . 'class.skin.inc' );


// ============================================================================
// The Theatre_of_Blood class
// ============================================================================
// This class provides an interface to the Theatre_of_Blood table
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class Theatre_of_Blood
{
	// Member variables
	var $theSkin;
	var $bShowVerticalScrollbars	= true;

	// ========================================================================
	// Constructor
	// ========================================================================
	function Theatre_of_Blood()
	{
		// Create the skin
		$this->theSkin	= new Skin();
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "Theatre of Blood";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<div id="Header">
		<br />
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td width= "5%" align="center">' . GetInfoLink( "Theatre_of_Blood", "Theatre of Blood information" ) . '</td>
			<td width="13%">				<b><a href="form.php?FormName=Theatre_of_Blood&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=CharName&SortDirection='				. GetSortDirection( $strSortOrder, "CharName",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Name\';return true;"					OnMouseOut="window.status=\'\'"	target=Body title="Name"																		>Name</a></b></td>
			<td width="11%" align="center">	<b><a href="form.php?FormName=Theatre_of_Blood&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=The_Library&SortDirection='			. GetSortDirection( $strSortOrder, "The_Library",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by The Library\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Skylance: The Library (from Spirit of Ao the Fourth Born in Arcstone)"		>Library</a></b></td>
			<td width="11%" align="center">	<b><a href="form.php?FormName=Theatre_of_Blood&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=The_Oubliette&SortDirection='			. GetSortDirection( $strSortOrder, "The_Oubliette",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by The Oubliette\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Skylance: The Oubliette (from Spirit of Ao the Fourth Born in Arcstone)"		>Oubliette</a></b></td>
			<td width="11%" align="center">	<b><a href="form.php?FormName=Theatre_of_Blood&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=The_Laboratory&SortDirection='			. GetSortDirection( $strSortOrder, "The_Laboratory",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by The Laboratory\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Skylance: The Laboratory (from Spirit of Ao the Fourth Born in Arcstone)"	>Laboratory</a></b></td>
			<td width="11%" align="center">	<b><a href="form.php?FormName=Theatre_of_Blood&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=The_Key_to_the_Past&SortDirection='	. GetSortDirection( $strSortOrder, "The_Key_to_the_Past",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by The Key to the Past\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="The Key to the Past (from Tak\'Valnakor in North Ro)"						>TKttP</a></b></td>
			<td width="11%" align="center">	<b><a href="form.php?FormName=Theatre_of_Blood&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=The_Burning_Prince&SortDirection='		. GetSortDirection( $strSortOrder, "The_Burning_Prince",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by The Burning Prince\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="The Burning Prince (from Tak\'Valnakor in North Ro)"							>TBP</a></b></td>
			<td width="11%" align="center">	<b><a href="form.php?FormName=Theatre_of_Blood&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Message_to_the_Past&SortDirection='	. GetSortDirection( $strSortOrder, "Message_to_the_Past",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Message to the Past\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Message to the Past (from Tak\'Valnakor in North Ro)"						>MttP</a></b></td>
			<td width="11%" align="center">	<b><a href="form.php?FormName=Theatre_of_Blood&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Samples_of_Corruption&SortDirection='	. GetSortDirection( $strSortOrder, "Samples_of_Corruption",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Samples of Corruption\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Samples of Corruption (from Oathmir the Outcast in Devastation)"				>SoC</a></b></td>
			<td width= "5%" align="center">	<b><a href="form.php?FormName=Theatre_of_Blood&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Access&SortDirection='					. GetSortDirection( $strSortOrder, "Access",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by access\';return true;"					OnMouseOut="window.status=\'\'"	target=Body title="Theatre of Blood Access"															>Done</a></b></td>
		  </tr>
		</table>
		</div>
		<!-- End of Header -->
		';
	}

	
	
	// ========================================================================
	// Show all the records on screen
	// ========================================================================
	// This function will loop through all the records in the database table,
	// and create a html table entry for each one of them.
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS		= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];
		$strClassFilter		= $_GET['ClassFilter'];

		// Declare variables
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT CharName, NameMain, The_Library, The_Oubliette, The_Laboratory, The_Key_to_the_Past, The_Burning_Prince, Message_to_the_Past, Samples_of_Corruption, OldMember \n" .
							  "FROM PoR_Flags \n" .
							  "LEFT JOIN Characters ON (PoR_Flags.CharID = Characters.CharID) \n" .
							  "WHERE (	The_Library > 0				OR \n" .
							  "			The_Oubliette > 0			OR \n" .
							  "			The_Laboratory > 0			OR \n" .
							  "			The_Key_to_the_Past > 0		OR \n" .
							  "			The_Burning_Prince > 0		OR \n" .
							  "			Message_to_the_Past > 0		OR \n" .
							  "			Samples_of_Corruption > 0 )	   \n";

		// Check if we should set a class filter
		if( ( isset( $strClassFilter ) ) &&
			( $strClassFilter != "" ) &&
			( $strClassFilter != "<<All>>" ) )
		{
			$strSelectQuery	.= "AND Class = '" . $strClassFilter . "'";
		} 

		// Check if we should use the default sort order
		if( ( !isset( $strSortOrder ) ) ||
			( $strSortOrder == "" ) )
		{
			// Default sort on Character name
			$strSortOrder	= "CharName"; 
		}

		// Check if we're sorting on Access
		if( $strSortOrder == "Access" )
		{
			// Default sort on Character name
			$strSortOrder	= "(The_Library + The_Oubliette + The_Laboratory + The_Key_to_the_Past + The_Burning_Prince + Message_to_the_Past + Samples_of_Corruption)"; 
		}

		// Sorting on all numbers should be reversed (Desc first, then Asc)
		$strModifiedSortDirection	= $strSortDirection;
		if( $strSortOrder != "CharName" )
		{
			// Switch the sort order around
			if( $strModifiedSortDirection == "DESC" )
			{
				$strModifiedSortDirection	= "";
			}
			else
			{
				$strModifiedSortDirection	= "DESC";
			}
		}
	
		// Add the sort order
		$strSelectQuery		.= "ORDER BY " . $strSortOrder . " " . $strModifiedSortDirection . ", CharName";
	
		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
		<div id="Body">
		<table id="RosterTable" width="100%" border="0" cellpadding="0" cellspacing="0">
		';
	
		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex					= 0;
			$strCharName			= $aResult[$nIndex++];
			$strNameMain			= $aResult[$nIndex++];
			$nThe_Library			= $aResult[$nIndex++];
			$nThe_Oubliette			= $aResult[$nIndex++];
			$nThe_Laboratory		= $aResult[$nIndex++];
			$nThe_Key_to_the_Past	= $aResult[$nIndex++];
			$nThe_Burning_Prince	= $aResult[$nIndex++];
			$nMessage_to_the_Past	= $aResult[$nIndex++];
			$nSamples_of_Corruption	= $aResult[$nIndex++];
			$nOldMember				= $aResult[$nIndex++];
	
			// Only show old members for the administrator
			if( ( $strCharName != "" ) &&
				( ( $nOldMember == 0 ) ||
				  ( IsAdministrator( $strUserName ) ) ) )
			{
				// Show the SSRA Emperor key parts
				$this->ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nThe_Library, $nThe_Oubliette, $nThe_Laboratory, $nThe_Key_to_the_Past, $nThe_Burning_Prince, $nMessage_to_the_Past, $nSamples_of_Corruption, $nOldMember, $strRowType );
		
				// Switch RowType, so the rows alternate	
				if( $strRowType == "OddRow" )
				{
					$strRowType	= "EvenRow";
				}
				else
				{
					$strRowType	= "OddRow";
				}
			}
		}
	
		// End the table
		echo '
		</table>
		</div>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );
	}
	
	
	
	// ========================================================================
	// Show a record
	// ========================================================================
	// This function will create a html table row for a record in the table
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// In:  Variables containing the data to show 
	// ========================================================================
	function ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nThe_Library, $nThe_Oubliette, $nThe_Laboratory, $nThe_Key_to_the_Past, $nThe_Burning_Prince, $nMessage_to_the_Past, $nSamples_of_Corruption, $nOldMember, $strRowType )
	{
		// Declare variables
		$strImageCheck				= '<img src="' . GetSkinDir() . 'images/check.gif" border="0" />';
		$strDeleteChar				= "";
		$strCompleted				= "";
		$strThe_Library				= "";
		$strThe_Oubliette			= "";
		$strThe_Laboratory			= "";
		$strThe_Key_to_the_Past		= "";
		$strThe_Burning_Prince		= "";
		$strMessage_to_the_Past		= "";
		$strSamples_of_Corruption	= "";
	
		// Set the check-image for all filled variables
		if( $nThe_Library > 0 )					{	$strThe_Library				= $strImageCheck;	}
		if( $nThe_Oubliette > 0 )				{	$strThe_Oubliette			= $strImageCheck;	}
		if( $nThe_Laboratory > 0 )				{	$strThe_Laboratory			= $strImageCheck;	}
		if( $nThe_Key_to_the_Past > 0 )			{	$strThe_Key_to_the_Past		= $strImageCheck;	}
		if( $nThe_Burning_Prince > 0 )			{	$strThe_Burning_Prince		= $strImageCheck;	}
		if( $nMessage_to_the_Past > 0 )			{	$strMessage_to_the_Past		= $strImageCheck;	}
		if( $nSamples_of_Corruption > 0 )		{	$strSamples_of_Corruption	= $strImageCheck;	}
		if( ( $nThe_Library > 0 ) &&
			( $nThe_Oubliette > 0 ) &&
			( $nThe_Laboratory > 0 ) &&
			( $nThe_Key_to_the_Past > 0 ) &&
			( $nThe_Burning_Prince > 0 ) &&
			( $nMessage_to_the_Past > 0 ) &&
			( $nSamples_of_Corruption > 0 ) )	{	$strCompleted				= $strImageCheck;	}

		// Check if it's an old member
		if( $nOldMember == 1 )
		{
			$strRowType		= "DeletedRow";

			// Allow the deletion of old members
			$strDeleteChar	= ' <a href="form.php?FormName=Character_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=Theatre_of_Blood&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Delete ' . $strCharName . '\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Delete ' . $strCharName . '"><img src="' . GetSkinDir() . 'images/delete.gif" border="0" /></a>';
		}
	
		// Check if this character belongs to the logged in User
		$strModify	= "";
		if( ( isset( $strUserName ) ) &&
			( isset( $strNameMain ) ) &&
			( $strUserName == $strNameMain ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=Theatre_of_Blood&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify.gif" border="0" />';
		}
		else if( IsAdministrator( $strUserName ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=Theatre_of_Blood&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify_others.gif" border="0" />';
		}
	
		echo '
		  <tr	onMouseOver="this.bgColor=\'' . $this->theSkin->strRowHighlightColor	. '\'" onMouseOut="this.bgColor=\'\'">
			<td width= "5%" align="center">'				. $strModify				. '</td>
			<td width="13%" class="' . $strRowType . '">'	. $strCharName				. $strDeleteChar . '</td>
			<td width="11%" align="center">'				. $strThe_Library			. '</td>
			<td width="11%" align="center">'				. $strThe_Oubliette			. '</td>
			<td width="11%" align="center">'				. $strThe_Laboratory		. '</td>
			<td width="11%" align="center">'				. $strThe_Key_to_the_Past	. '</td>
			<td width="11%" align="center">'				. $strThe_Burning_Prince	. '</td>
			<td width="11%" align="center">'				. $strMessage_to_the_Past	. '</td>
			<td width="11%" align="center">'				. $strSamples_of_Corruption	. '</td>
			<td width= "5%" align="center">'				. $strCompleted				. '</td>
		  </tr>
		';
	}

}

?>
