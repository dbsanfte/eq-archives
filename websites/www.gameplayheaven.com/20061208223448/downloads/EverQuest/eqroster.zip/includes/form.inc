<?php

// This include file exists to make it easier to include all the form classes
// (used in form_body.php and form_header.php)

// Includes
require_once( './includes/class.character_delete.inc' );
require_once( './includes/class.character_statistics.inc' );
require_once( './includes/class.characters.inc' );
require_once( './includes/class.characters_delete.inc' );
require_once( './includes/class.dod_mask.inc' );
require_once( './includes/class.dod_spells.inc' );
require_once( './includes/class.don_flags.inc' );
require_once( './includes/class.dreadspire_keep.inc' );
require_once( './includes/class.demiplane_of_blood.inc' );
require_once( './includes/class.eqplayers_batch_import.inc' );
require_once( './includes/class.god_bic.inc' );
require_once( './includes/class.god_dss.inc' );
require_once( './includes/class.god_flags.inc' );
require_once( './includes/class.keys.inc' );
require_once( './includes/class.magelo_batch_import.inc' );
require_once( './includes/class.oow_coa.inc' );
require_once( './includes/class.pop_tier_1_flags.inc' );
require_once( './includes/class.pop_tier_2_flags.inc' );
require_once( './includes/class.pop_tier_3_flags.inc' );
require_once( './includes/class.pop_tier_4_flags.inc' );
require_once( './includes/class.pos_askr_quest.inc' );
require_once( './includes/class.ssra_keys.inc' );
require_once( './includes/class.statistics.inc' );
require_once( './includes/class.theatre_of_blood.inc' );
require_once( './includes/class.tradeskills.inc' );
require_once( './includes/class.user_create.inc' );
require_once( './includes/class.user_delete.inc' );
require_once( './includes/class.user_login.inc' );
require_once( './includes/class.user_modify.inc' );
require_once( './includes/class.user_verify.inc' );
require_once( './includes/class.users.inc' );
require_once( './includes/class.veeshans_peak_keys.inc' );
require_once( './includes/class.vex_thal_keys.inc' );

?>
