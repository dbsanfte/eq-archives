<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );
require_once( GetSkinDir() . 'class.skin.inc' );


// ============================================================================
// The GoD_BiC class
// ============================================================================
// This class provides an interface to the GoD_BiC table that keeps track of
// the Breakdown in Communication quest progress.
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class GoD_BiC
{
	// Member variables
	var $theSkin;
	var $bShowVerticalScrollbars	= true;

	// ========================================================================
	// Constructor
	// ========================================================================
	function GoD_BiC()
	{
		// Create the skin
		$this->theSkin	= new Skin();
	}

	// ========================================================================
	// Get the title of this list
	// ========================================================================
	// Out:	The title of this list
	// ========================================================================
	function GetTitle()
	{
		return "Breakdown in Communication Quest";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<div id="Header">
		<br />
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td width= "5%" align="center">' . GetInfoLink( "BiC_Start", "Gates of Discord: Breakdown in Communication Quest information" ) . '</td>
			<td width="15%"><b><a href="form.php?FormName=GoD_BiC&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=CharName&SortDirection='	. GetSortDirection( $strSortOrder, "CharName",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Name\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Name"					>Name</a></b></td>
			<td width= "5%"><b><a href="form.php?FormName=GoD_BiC&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=BiC_Part1&SortDirection='	. GetSortDirection( $strSortOrder, "BiC_Part1",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by BiC Part1\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="BiC Part1: Qinimi"		>1 '		. GetInfoLink( "BiC_Part1", "Gates of Discord: Breakdown in Communication (1: Qinimi) Quest information" ) . '</a></b></td>
			<td width= "5%"><b><a href="form.php?FormName=GoD_BiC&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=BiC_Part2&SortDirection='	. GetSortDirection( $strSortOrder, "BiC_Part2",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by BiC Part2\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="BiC Part2: Barindu"		>2 '		. GetInfoLink( "BiC_Part2", "Gates of Discord: Breakdown in Communication (2: Barindu) Quest information" ) . '</a></b></td>
			<td width= "5%"><b><a href="form.php?FormName=GoD_BiC&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=BiC_Part3&SortDirection='	. GetSortDirection( $strSortOrder, "BiC_Part3",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by BiC Part3\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="BiC Part3: Riwwi"		>3 '		. GetInfoLink( "BiC_Part3", "Gates of Discord: Breakdown in Communication (3: Riwwi) Quest information" ) . '</a></b></td>
			<td width= "5%"><b><a href="form.php?FormName=GoD_BiC&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=BiC_Part4&SortDirection='	. GetSortDirection( $strSortOrder, "BiC_Part4",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by BiC Part4\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="BiC Part4: Ferubi"		>4 '		. GetInfoLink( "BiC_Part4", "Gates of Discord: Breakdown in Communication (4: Ferubi) Quest information" ) . '</a></b></td>
			<td width= "5%"><b><a href="form.php?FormName=GoD_BiC&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=BiC_Part5&SortDirection='	. GetSortDirection( $strSortOrder, "BiC_Part5",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by BiC Part5\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="BiC Part5: Sewers"		>5 '		. GetInfoLink( "BiC_Part5", "Gates of Discord: Breakdown in Communication (5: Sewers) Quest information" ) . '</a></b></td>
			<td width= "5%"><b><a href="form.php?FormName=GoD_BiC&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=BiC_Part6&SortDirection='	. GetSortDirection( $strSortOrder, "BiC_Part6",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by BiC Part6\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="BiC Part6: Vxed"			>6 '		. GetInfoLink( "BiC_Part6", "Gates of Discord: Breakdown in Communication (6: Vxed) Quest information" ) . '</a></b></td>
			<td width= "5%"><b><a href="form.php?FormName=GoD_BiC&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=BiC_Part7&SortDirection='	. GetSortDirection( $strSortOrder, "BiC_Part7",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by BiC Part7\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="BiC Part7: Tipt"			>7 '		. GetInfoLink( "BiC_Part7", "Gates of Discord: Breakdown in Communication (7: Tipt) Quest information" ) . '</a></b></td>
			<td width= "5%"><b><a href="form.php?FormName=GoD_BiC&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=BiC_Part8&SortDirection='	. GetSortDirection( $strSortOrder, "BiC_Part8",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by BiC Part8\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="BiC Part8: Yxtta"		>8 '		. GetInfoLink( "BiC_Part8", "Gates of Discord: Breakdown in Communication (8: Yxtta) Quest information" ) . '</a></b></td>
			<td width= "5%"><b><a href="form.php?FormName=GoD_BiC&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=BiC_Part9&SortDirection='	. GetSortDirection( $strSortOrder, "BiC_Part9",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by BiC Part9\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="BiC Part9: Kod\'Taz"		>9 '		. GetInfoLink( "BiC_Part9", "Gates of Discord: Breakdown in Communication (9: Kod\'Taz) Quest information" ) . '</a></b></td>
			<td width= "5%"><b><a href="form.php?FormName=GoD_BiC&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=BiC_Part10&SortDirection='	. GetSortDirection( $strSortOrder, "BiC_Part10",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by BiC Part10\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="BiC Part10: Free Stuff"	>10 '		. GetInfoLink( "BiC_Part10", "Gates of Discord: Breakdown in Communication (10: Free Stuff) Quest information" ) . '</a></b></td>
			<td width= "5%"><b><a href="form.php?FormName=GoD_BiC&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=BiC_Part11&SortDirection='	. GetSortDirection( $strSortOrder, "BiC_Part11",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by BiC Part11\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="BiC Part11: Qvic"		>11 '		. GetInfoLink( "BiC_Part11", "Gates of Discord: Breakdown in Communication (11: Qvic) Quest information" ) . '</a></b></td>
			<td width= "5%"><b><a href="form.php?FormName=GoD_BiC&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=BiC_Part12&SortDirection='	. GetSortDirection( $strSortOrder, "BiC_Part12",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by BiC Part12\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="BiC Part12: Inktu\'ta"	>12 '		. GetInfoLink( "BiC_Part12", "Gates of Discord: Breakdown in Communication (12: Inktu\'ta) Quest information" ) . '</a></b></td>
			<td width= "5%"><b><a href="form.php?FormName=GoD_BiC&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=BiC_Part13&SortDirection='	. GetSortDirection( $strSortOrder, "BiC_Part13",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by BiC Part13\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="BiC Part13: Txevu"		>13 '		. GetInfoLink( "BiC_Part13", "Gates of Discord: Breakdown in Communication (13: Txevu) Quest information" ) . '</a></b></td>
			<td width= "5%"><b><a href="form.php?FormName=GoD_BiC&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=BiC_Part14&SortDirection='	. GetSortDirection( $strSortOrder, "BiC_Part14",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by BiC Part14\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="BiC Part14: Tacvi"		>14 '		. GetInfoLink( "BiC_Part14", "Gates of Discord: Breakdown in Communication (14: Tacvi) Quest information" ) . '</a></b></td>
			<td width= "5%"></td>
			<td width= "5%" align="center"><b><a href="form.php?FormName=GoD_BiC&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Done&SortDirection=' . GetSortDirection( $strSortOrder, "Done",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by completed\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Quest Completed"			>Done</a></b></td>
		  </tr>
		</table>
		</div>
		<!-- End of Header -->
		';
	}
	
	
	
	// ========================================================================
	// Show all the records on screen
	// ========================================================================
	// This function will loop through all the records in the database table,
	// and create a html table entry for each one of them.
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS		= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];
		$strClassFilter		= $_GET['ClassFilter'];

		// Declare variables
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT CharName, NameMain, Part1, Part2, Part3, Part4, Part5, Part6, Part7, Part8, Part9, Part10, Part11, Part12, Part13, Part14, OldMember \n" .
							  "FROM GoD_BiC_Quest \n" .
							  "LEFT JOIN Characters ON (GoD_BiC_Quest.CharID = Characters.CharID) \n" .
							  "WHERE (	Part1 > 0	OR \n" .
							  "			Part2 > 0	OR \n" .
							  "			Part3 > 0	OR \n" .
							  "			Part4 > 0	OR \n" .
							  "			Part5 > 0	OR \n" .
							  "			Part6 > 0	OR \n" .
							  "			Part7 > 0	OR \n" .
							  "			Part8 > 0	OR \n" .
							  "			Part9 > 0	OR \n" .
							  "			Part10 > 0	OR \n" .
							  "			Part11 > 0	OR \n" .
							  "			Part12 > 0	OR \n" .
							  "			Part13 > 0	OR \n" .
							  "			Part14 > 0 )   \n";	

		// Check if we should set a class filter
		if( ( isset( $strClassFilter ) ) &&
			( $strClassFilter != "" ) &&
			( $strClassFilter != "<<All>>" ) )
		{
			$strSelectQuery	.= "AND Class = '" . $strClassFilter . "'";
		} 

		// Check if we should use the default sort order
		if( ( !isset( $strSortOrder ) ) ||
			( $strSortOrder == "" ) )
		{
			// Default sort on Character name
			$strSortOrder	= "CharName"; 
		}

		// Check if we're sorting on Access
		if( $strSortOrder == "Done" )
		{
			// Default sort on Character name
			$strSortOrder	= "(Part1 + Part2 + Part3 + Part4 + Part5 + Part6 + Part7 + Part8 + Part9 + Part10 + Part11 + Part12 + Part13 + (20*Part14))"; 
		}

		// Sorting on all numbers should be reversed (Desc first, then Asc)
		$strModifiedSortDirection	= $strSortDirection;
		if( $strSortOrder != "CharName" )
		{
			// Switch the sort order around
			if( $strModifiedSortDirection == "DESC" )
			{
				$strModifiedSortDirection	= "";
			}
			else
			{
				$strModifiedSortDirection	= "DESC";
			}
		}

		// Add the sort order
		$strSelectQuery		.= "ORDER BY " . $strSortOrder . " " . $strModifiedSortDirection . ", CharName";

		// Connect to the database
		$nLinkID	= DBConnect();

		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
		<div id="Body">
		<table id="RosterTable" width="100%" border="0" cellpadding="0" cellspacing="0">
		';

		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex				= 0;
			$strCharName		= $aResult[$nIndex++];
			$strNameMain		= $aResult[$nIndex++];
			$nPart1				= $aResult[$nIndex++];
			$nPart2				= $aResult[$nIndex++];
			$nPart3				= $aResult[$nIndex++];
			$nPart4				= $aResult[$nIndex++];
			$nPart5				= $aResult[$nIndex++];
			$nPart6				= $aResult[$nIndex++];
			$nPart7				= $aResult[$nIndex++];
			$nPart8				= $aResult[$nIndex++];
			$nPart9				= $aResult[$nIndex++];
			$nPart10			= $aResult[$nIndex++];
			$nPart11			= $aResult[$nIndex++];
			$nPart12			= $aResult[$nIndex++];
			$nPart13			= $aResult[$nIndex++];
			$nPart14			= $aResult[$nIndex++];
			$nOldMember			= $aResult[$nIndex++];

			// Only show old members for the administrator
			if( ( $strCharName != "" ) &&
				( ( $nOldMember == 0 ) ||
				  ( IsAdministrator( $strUserName ) ) ) )
			{
				// Show the BoT Flag parts
				$this->ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nPart1, $nPart2, $nPart3, $nPart4, $nPart5, $nPart6, $nPart7, $nPart8, $nPart9, $nPart10, $nPart11, $nPart12, $nPart13, $nPart14, $nOldMember, $strRowType );

				// Switch RowType, so the rows alternate	
				if( $strRowType == "OddRow" )
				{
					$strRowType	= "EvenRow";
				}
				else
				{
					$strRowType	= "OddRow";
				}
			}
		}

		// End the table
		echo '
		</table>
		</div>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );
	}
	
	
	
	// ========================================================================
	// Show a record
	// ========================================================================
	// This function will create a html table row for a record in the table
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// In:  Variables containing the data to show 
	// ========================================================================
	function ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nPart1, $nPart2, $nPart3, $nPart4, $nPart5, $nPart6, $nPart7, $nPart8, $nPart9, $nPart10, $nPart11, $nPart12, $nPart13, $nPart14, $nOldMember, $strRowType )
	{
		// Declare variables
		$strImageCheck	= '<img src="' . GetSkinDir() . 'images/check.gif" border="0" />';
		$strDeleteChar	= "";
		$strPart1		= "";
		$strPart2		= "";
		$strPart3		= "";
		$strPart4		= "";
		$strPart5		= "";
		$strPart6		= "";
		$strPart7		= "";
		$strPart8		= "";
		$strPart9		= "";
		$strPart10		= "";
		$strPart11		= "";
		$strPart12		= "";
		$strPart13		= "";
		$strPart14		= "";
		$strCompleted	= "";
	
		// Set the check-image for all filled variables
		if( $nPart1 > 0 )	{	$strPart1	= $strImageCheck;	}
		if( $nPart2 > 0 )	{	$strPart2	= $strImageCheck;	}
		if( $nPart3 > 0 )	{	$strPart3	= $strImageCheck;	}
		if( $nPart4 > 0 )	{	$strPart4	= $strImageCheck;	}
		if( $nPart5 > 0 )	{	$strPart5	= $strImageCheck;	}
		if( $nPart6 > 0 )	{	$strPart6	= $strImageCheck;	}
		if( $nPart7 > 0 )	{	$strPart7	= $strImageCheck;	}
		if( $nPart8 > 0 )	{	$strPart8	= $strImageCheck;	}
		if( $nPart9 > 0 )	{	$strPart9	= $strImageCheck;	}
		if( $nPart10 > 0 )	{	$strPart10	= $strImageCheck;	}
		if( $nPart11 > 0 )	{	$strPart11	= $strImageCheck;	}
		if( $nPart12 > 0 )	{	$strPart12	= $strImageCheck;	}
		if( $nPart13 > 0 )	{	$strPart13	= $strImageCheck;	}
		if( $nPart14 > 0 )
		{
			$strPart14		= $strImageCheck;
			$strCompleted	= $strImageCheck;
		}
	
		// Check if it's an old member
		if( $nOldMember == 1 )
		{
			$strRowType		= "DeletedRow";

			// Allow the deletion of old members
			$strDeleteChar	= ' <a href="form.php?FormName=Character_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=GoD_BiC&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Delete ' . $strCharName . '\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Delete ' . $strCharName . '"><img src="' . GetSkinDir() . 'images/delete.gif" border="0" /></a>';
		}
	
		// Check if this character belongs to the logged in User
		$strModify	= "";
		if( ( isset( $strUserName ) ) &&
			( isset( $strNameMain ) ) &&
			( $strUserName == $strNameMain ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=GoD_BiC&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify.gif" border="0" />';
		}
		else if( IsAdministrator( $strUserName ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=GoD_BiC&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify_others.gif" border="0" />';
		}
	
		echo '
		  <tr	onMouseOver="this.bgColor=\'' . $this->theSkin->strRowHighlightColor . '\'" onMouseOut="this.bgColor=\'\'">
			<td width= "5%" align="center">'	. $strModify	. '</td>
			<td width="15%" class="' . $strRowType . '">'	. $strCharName	. $strDeleteChar . '</td>
			<td width= "5%">&nbsp'				. $strPart1		. '</td>
			<td width= "5%">&nbsp'				. $strPart2		. '</td>
			<td width= "5%">&nbsp'				. $strPart3		. '</td>
			<td width= "5%">&nbsp'				. $strPart4		. '</td>
			<td width= "5%">&nbsp'				. $strPart5		. '</td>
			<td width= "5%">&nbsp'				. $strPart6		. '</td>
			<td width= "5%">&nbsp'				. $strPart7		. '</td>
			<td width= "5%">&nbsp'				. $strPart8		. '</td>
			<td width= "5%">&nbsp'				. $strPart9		. '</td>
			<td width= "5%">&nbsp'				. $strPart10	. '</td>
			<td width= "5%">&nbsp'				. $strPart11	. '</td>
			<td width= "5%">&nbsp'				. $strPart12	. '</td>
			<td width= "5%">&nbsp'				. $strPart13	. '</td>
			<td width= "5%">&nbsp'				. $strPart14	. '</td>
			<td width= "5%"></td>
			<td width= "5%" align="center">'	. $strCompleted	. '</td>
		  </tr>
		';
	}

}

?>
