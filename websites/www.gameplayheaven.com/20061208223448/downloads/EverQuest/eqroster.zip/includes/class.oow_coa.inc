<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );
require_once( GetSkinDir() . 'class.skin.inc' );


// ============================================================================
// The Omens of War (OoW) Citadel of Anguish (CoA) access quest
// ============================================================================
// This class provides an interface to the OoW_CoA table
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class OoW_CoA
{
	// Member variables
	var $theSkin;
	var $bShowVerticalScrollbars	= true;

	// ========================================================================
	// Constructor
	// ========================================================================
	function OoW_CoA()
	{
		// Create the skin
		$this->theSkin	= new Skin();
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "Omens of War: Citadel of Anguish access quest";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<div id="Header">
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td width= "5%" align="center"><br />' . GetInfoLink( "OoW_CoA", "Omens of War: Citadel of Anguish information" ) . '</td>
			<td width="10%">					<b><a href="form.php?FormName=OoW_CoA&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=CharName&SortDirection='					. GetSortDirection( $strSortOrder, "CharName",					$strSortDirection )	. '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Name\';return true;"													OnMouseOut="window.status=\'\'"	target=Body title="Name"													><br />Name</a></b></td>
			<td width="35%">
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="100%" align="center"><b>MPG Trials</b></td>
			  </tr>
			  </table>
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="14%" align="center">	<b><a href="form.php?FormName=OoW_CoA&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Mastery_of_Adaptation&SortDirection='		. GetSortDirection( $strSortOrder, "Mastery_of_Adaptation",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by The Mastery of Adaptation (Projection of Realms)\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="The Mastery of Adaptation (Projection of Realms)"		>MoA</a></b></td>
				<td width="14%" align="center">	<b><a href="form.php?FormName=OoW_CoA&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Mastery_of_Corruption&SortDirection='		. GetSortDirection( $strSortOrder, "Mastery_of_Corruption",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by The Mastery of Corruption (Projection of Power)\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="The Mastery of Corruption (Projection of Power) "		>MoC</a></b></td>
				<td width="14%" align="center">	<b><a href="form.php?FormName=OoW_CoA&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Mastery_of_Endurance&SortDirection='		. GetSortDirection( $strSortOrder, "Mastery_of_Endurance",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by The Mastery of Endurance (Projection of Body)\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="The Mastery of Endurance (Projection of Body)"			>MoE</a></b></td>
				<td width="14%" align="center">	<b><a href="form.php?FormName=OoW_CoA&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Mastery_of_Foresight&SortDirection='		. GetSortDirection( $strSortOrder, "Mastery_of_Foresight",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by The Mastery of Foresight (Projection of Tactics)\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="The Mastery of Foresight (Projection of Tactics)"		>MoF</a></b></td>
				<td width="14%" align="center">	<b><a href="form.php?FormName=OoW_CoA&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Mastery_of_Hate&SortDirection='				. GetSortDirection( $strSortOrder, "Mastery_of_Hate",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by The Mastery of Hate (Projection of Mind)\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="The Mastery of Hate (Projection of Mind) "				>MoH</a></b></td>
				<td width="14%" align="center">	<b><a href="form.php?FormName=OoW_CoA&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Mastery_of_Specialization&SortDirection='	. GetSortDirection( $strSortOrder, "Mastery_of_Specialization",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by The Mastery of Specialization (Projection of Arcana)\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="The Mastery of Specialization (Projection of Arcana)"	>MoS</a></b></td>
				<td width="16%" align="center">	<b><a href="form.php?FormName=OoW_CoA&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Access&SortDirection='						. GetSortDirection( $strSortOrder, "Access",					$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Access to Citadel of Anguish\';return true;"							OnMouseOut="window.status=\'\'"	target=Body title="Access to Citadel of Anguish"							>Access</a></b></td>
			  </tr>
			  </table>
			</td>
			<td align="center"><br>|</td>
			<td width="50%">
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="100%" align="center"><b>Immunization</b></td>
			  </tr>
			  </table>
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="12%" align="center">	<b><a href="form.php?FormName=OoW_CoA&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Signet_Crystal_Gemmed&SortDirection='	. GetSortDirection( $strSortOrder, "Signet_Crystal_Gemmed",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Crystal-Gemmed Signet (From a Dragorn Battlemaster in RSS)\';return true;"								OnMouseOut="window.status=\'\'"	target=Body title="Crystal-Gemmed Signet (From a Dragorn Battlemaster in RSS)"								>CGS</a></b></td>
				<td width="12%" align="center">	<b><a href="form.php?FormName=OoW_CoA&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Signet_Discolored&SortDirection='		. GetSortDirection( $strSortOrder, "Signet_Discolored",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Discolored Signet (From a Cunning Dragorn in Sewers of Dranik)\';return true;"							OnMouseOut="window.status=\'\'"	target=Body title="Discolored Signet (From a Cunning Dragorn in Sewers of Dranik)"							>DS</a></b></td>
				<td width="12%" align="center">	<b><a href="form.php?FormName=OoW_CoA&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Signet_Dust_Marred&SortDirection='		. GetSortDirection( $strSortOrder, "Signet_Dust_Marred",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Dust-Marred Signet (From Insidious Dragorn in Catacombs of Dranik)\';return true;"						OnMouseOut="window.status=\'\'"	target=Body title="Dust-Marred Signet (From Insidious Dragorn in Catacombs of Dranik)"						>DMS</a></b></td>
				<td width="12%" align="center">	<b><a href="form.php?FormName=OoW_CoA&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Signet_Glimmering&SortDirection='		. GetSortDirection( $strSortOrder, "Signet_Glimmering",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Glimmering Signet (From Dragorn Tactician in MPG)\';return true;"										OnMouseOut="window.status=\'\'"	target=Body title="Glimmering Signet (From Dragorn Tactician in MPG)"										>GS</a></b></td>
				<td width="12%" align="center">	<b><a href="form.php?FormName=OoW_CoA&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Signet_Tarnished&SortDirection='		. GetSortDirection( $strSortOrder, "Signet_Tarnished",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Tarnished Signet (From a Dragorn Mastermind or Dragorn Tactician in Wall of Slaughter)\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Tarnished Signet (From a Dragorn Mastermind or Dragorn Tactician in Wall of Slaughter)"	>TS</a></b></td>
				<td width="12%" align="center">	<b><a href="form.php?FormName=OoW_CoA&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Signet_Two_Toned&SortDirection='		. GetSortDirection( $strSortOrder, "Signet_Two_Toned",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Two-Toned Signet (From a Shrewd Dragorn in Dranik\'s Hollows)\';return true;"							OnMouseOut="window.status=\'\'"	target=Body title="Two-Toned Signet (From a Shrewd Dragorn in Dranik\'s Hollows)"							>TTS</a></b></td>
				<td width="12%" align="center">	<b><a href="form.php?FormName=OoW_CoA&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Signet_Weather_Worn&SortDirection='		. GetSortDirection( $strSortOrder, "Signet_Weather_Worn",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Weather-Worn Signet (From a dragorn prodigy in Ruined City of Dranik)\';return true;"					OnMouseOut="window.status=\'\'"	target=Body title="Weather-Worn Signet (From a dragorn prodigy in Ruined City of Dranik)"					>WWS</a></b></td>
				<td width="16%" align="center">	<b><a href="form.php?FormName=OoW_CoA&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Immune&SortDirection='					. GetSortDirection( $strSortOrder, "Immune",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Immune to AE in Citadel of Anguish\';return true;"														OnMouseOut="window.status=\'\'"	target=Body title="Immune to AE in Citadel of Anguish"														>Immune</a></b></td>
			  </tr>
			  </table>
			</td>
		  </tr>
		</table>
		</div>
		<!-- End of Header -->
		';
	}

	
	
	// ========================================================================
	// Show all the records on screen
	// ========================================================================
	// This function will loop through all the records in the database table,
	// and create a html table entry for each one of them.
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS		= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];
		$strClassFilter		= $_GET['ClassFilter'];

		// Declare variables
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT CharName, NameMain, Mastery_of_Adaptation, Mastery_of_Corruption, Mastery_of_Endurance, Mastery_of_Foresight, Mastery_of_Hate, Mastery_of_Specialization, Seal_Mastery_of_All, Signet_Crystal_Gemmed, Signet_Discolored, Signet_Dust_Marred, Signet_Glimmering, Signet_Tarnished, Signet_Two_Toned, Signet_Weather_Worn, OldMember \n" .
							  "FROM OoW_CoA \n" .
							  "LEFT JOIN Characters ON (OoW_CoA.CharID = Characters.CharID) \n" .
							  "WHERE (	Mastery_of_Adaptation > 0		OR \n" .
							  "			Mastery_of_Corruption > 0		OR \n" .
							  "			Mastery_of_Endurance > 0		OR \n" .
							  "			Mastery_of_Foresight > 0		OR \n" .
							  "			Mastery_of_Hate > 0				OR \n" .
							  "			Mastery_of_Specialization > 0	OR \n" .
							  "         Seal_Mastery_of_All > 0         OR \n" .
							  "			Signet_Crystal_Gemmed > 0		OR \n" .
							  "			Signet_Discolored > 0			OR \n" .
							  "			Signet_Dust_Marred > 0			OR \n" .
							  "			Signet_Glimmering > 0			OR \n" .
							  "			Signet_Tarnished > 0			OR \n" .
							  "			Signet_Two_Toned > 0			OR \n" .
							  "			Signet_Weather_Worn > 0 )		   \n";

		// Check if we should set a class filter
		if( ( isset( $strClassFilter ) ) &&
			( $strClassFilter != "" ) &&
			( $strClassFilter != "<<All>>" ) )
		{
			$strSelectQuery	.= "AND Class = '" . $strClassFilter . "'";
		} 

		// Check if we should use the default sort order
		if( ( !isset( $strSortOrder ) ) ||
			( $strSortOrder == "" ) )
		{
			// Default sort on Character name
			$strSortOrder	= "CharName"; 
		}

		// Sorting on all numbers should be reversed (Desc first, then Asc)
		$strModifiedSortDirection	= $strSortDirection;
		if( $strSortOrder != "CharName" )
		{
			// Switch the sort order around
			if( $strModifiedSortDirection == "DESC" )
			{
				$strModifiedSortDirection	= "";
			}
			else
			{
				$strModifiedSortDirection	= "DESC";
			}
		}

		if( $strSortOrder == "Access" )
		{
			$strSortOrder	= "(Mastery_of_Adaptation + Mastery_of_Corruption + Mastery_of_Endurance + Mastery_of_Foresight + Mastery_of_Hate + Mastery_of_Specialization + 7*Seal_Mastery_of_All)";
		}
		else if( $strSortOrder == "Immune" )
		{
			$strSortOrder	= "(Signet_Crystal_Gemmed + Signet_Discolored + Signet_Dust_Marred + Signet_Glimmering + Signet_Tarnished + Signet_Two_Toned + Signet_Weather_Worn)";
		}

		// Add the sort order
		$strSelectQuery		.= "ORDER BY " . $strSortOrder . " " . $strModifiedSortDirection . ", CharName";
	
		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
		<div id="RosterMainBody">
		<table id="RosterTable" width="100%" border="0" cellpadding="0" cellspacing="0">
		';
	
		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			$nIndex						= 0;
			$strCharName				= $aResult[$nIndex++];
			$strNameMain				= $aResult[$nIndex++];
			$nMastery_of_Adaptation		= $aResult[$nIndex++];
			$nMastery_of_Corruption		= $aResult[$nIndex++];
			$nMastery_of_Endurance		= $aResult[$nIndex++];
			$nMastery_of_Foresight		= $aResult[$nIndex++];
			$nMastery_of_Hate			= $aResult[$nIndex++];
			$nMastery_of_Specialization	= $aResult[$nIndex++];
			$nSeal_Mastery_of_All		= $aResult[$nIndex++];
			$nSignet_Crystal_Gemmed		= $aResult[$nIndex++];
			$nSignet_Discolored			= $aResult[$nIndex++];
			$nSignet_Dust_Marred		= $aResult[$nIndex++];
			$nSignet_Glimmering			= $aResult[$nIndex++];
			$nSignet_Tarnished			= $aResult[$nIndex++];
			$nSignet_Two_Toned			= $aResult[$nIndex++];
			$nSignet_Weather_Worn		= $aResult[$nIndex++];
			$nOldMember					= $aResult[$nIndex++];

			// Only show old members for the administrator
			if( ( $strCharName != "" ) &&
				( ( $nOldMember == 0 ) ||
				  ( IsAdministrator( $strUserName ) ) ) )
			{
				// Show the Veeshans Peak key parts
				$this->ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nMastery_of_Adaptation, $nMastery_of_Corruption, $nMastery_of_Endurance, $nMastery_of_Foresight, $nMastery_of_Hate, $nMastery_of_Specialization, $nSeal_Mastery_of_All, $nSignet_Crystal_Gemmed, $nSignet_Discolored, $nSignet_Dust_Marred, $nSignet_Glimmering, $nSignet_Tarnished, $nSignet_Two_Toned, $nSignet_Weather_Worn, $nOldMember, $strRowType );
		
				// Switch RowType, so the rows alternate	
				if( $strRowType == "OddRow" )
				{
					$strRowType	= "EvenRow";
				}
				else
				{
					$strRowType	= "OddRow";
				}
			}
		}
	
		// End the table
		echo '
		</table>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );
	}
	
	
	
	// ========================================================================
	// Show a record
	// ========================================================================
	// This function will create a html table row for a record in the table
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// In:  Variables containing the data to show 
	// ========================================================================
	function ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nMastery_of_Adaptation, $nMastery_of_Corruption, $nMastery_of_Endurance, $nMastery_of_Foresight, $nMastery_of_Hate, $nMastery_of_Specialization, $nSeal_Mastery_of_All, $nSignet_Crystal_Gemmed, $nSignet_Discolored, $nSignet_Dust_Marred, $nSignet_Glimmering, $nSignet_Tarnished, $nSignet_Two_Toned, $nSignet_Weather_Worn, $nOldMember, $strRowType )
	{
		// Declare variables
		$strImageCheck						= '<img src="' . GetSkinDir() . 'images/check.gif" border="0" />';
		$strDeleteChar						= '';
		$strMastery_of_Adaptation			= "";
		$strMastery_of_Corruption			= "";
		$strMastery_of_Endurance			= "";
		$strMastery_of_Foresight			= "";
		$strMastery_of_Hate					= "";
		$strMastery_of_Specialization		= "";
		$strSeal_Mastery_of_All				= "";
		$strAccess							= "";
		$strSignet_Crystal_Gemmed			= "";
		$strSignet_Discolored				= "";
		$strSignet_Dust_Marred				= "";
		$strSignet_Glimmering				= "";
		$strSignet_Tarnished				= "";
		$strSignet_Two_Toned				= "";
		$strSignet_Weather_Worn				= "";
		$strImmune							= "";
	
		// Set the check-image for all filled variables
		if( $nCompleted > 0 )					{	$strCompleted						= $strImageCheck;	}
		if( $nMastery_of_Adaptation > 0 )		{	$strMastery_of_Adaptation			= $strImageCheck;	}
		if( $nMastery_of_Corruption > 0 )		{	$strMastery_of_Corruption			= $strImageCheck;	}
		if( $nMastery_of_Endurance > 0 )		{	$strMastery_of_Endurance			= $strImageCheck;	}
		if( $nMastery_of_Foresight > 0 )		{	$strMastery_of_Foresight			= $strImageCheck;	}
		if( $nMastery_of_Hate > 0 )				{	$strMastery_of_Hate					= $strImageCheck;	}
		if( $nMastery_of_Specialization > 0 )	{	$strMastery_of_Specialization		= $strImageCheck;	}
		if( $nSeal_Mastery_of_All > 0 )			{	$strAccess							= $strImageCheck;	}
		if( $nSignet_Crystal_Gemmed > 0 )		{	$strSignet_Crystal_Gemmed			= $strImageCheck;	}
		if( $nSignet_Discolored > 0 )			{	$strSignet_Discolored				= $strImageCheck;	}
		if( $nSignet_Dust_Marred > 0 )			{	$strSignet_Dust_Marred				= $strImageCheck;	}
		if( $nSignet_Glimmering > 0 )			{	$strSignet_Glimmering				= $strImageCheck;	}
		if( $nSignet_Tarnished > 0 )			{	$strSignet_Tarnished				= $strImageCheck;	}
		if( $nSignet_Two_Toned > 0 )			{	$strSignet_Two_Toned				= $strImageCheck;	}
		if( $nSignet_Weather_Worn > 0 )			{	$strSignet_Weather_Worn				= $strImageCheck;	}
		if( ( $nSignet_Crystal_Gemmed > 0 ) &&
			( $nSignet_Discolored > 0 ) &&
			( $nSignet_Dust_Marred > 0 ) &&
			( $nSignet_Glimmering > 0 ) &&
			( $nSignet_Tarnished > 0 ) &&
			( $nSignet_Two_Toned > 0 ) &&
			( $nSignet_Weather_Worn > 0 ) )		{	$strImmune							= $strImageCheck;	}
	
		// Check if it's an old member
		if( $nOldMember == 1 )
		{
			$strRowType		= "DeletedRow";

			// Allow the deletion of old members
			$strDeleteChar	= ' <a href="form.php?FormName=Character_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=OoW_CoA&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Delete ' . $strCharName . '\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Delete ' . $strCharName . '"><img src="' . GetSkinDir() . 'images/delete.gif" border="0" /></a>';
		}
	
		// Check if this character belongs to the logged in User
		$strModify	= "";
		if( ( isset( $strUserName ) ) &&
			( isset( $strNameMain ) ) &&
			( $strUserName == $strNameMain ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=OoW_CoA&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify.gif" border="0" />';
		}
		else if( IsAdministrator( $strUserName ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=OoW_CoA&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify_others.gif" border="0" />';
		}
	
		echo '
		  <tr	onMouseOver="this.bgColor=\'' . $this->theSkin->strRowHighlightColor . '\'" onMouseOut="this.bgColor=\'\'">
			<td width= "5%" align="center">'				. $strModify						. '</td>
			<td width="10%" class="' . $strRowType . '">'	. $strCharName						. $strDeleteChar . '</td>
			<td width="35%">
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="14%" align="center">'				. $strMastery_of_Adaptation		. '</td>
				<td width="14%" align="center">'				. $strMastery_of_Corruption		. '</td>
				<td width="14%" align="center">'				. $strMastery_of_Endurance		. '</td>
				<td width="14%" align="center">'				. $strMastery_of_Foresight		. '</td>
				<td width="14%" align="center">'				. $strMastery_of_Hate			. '</td>
				<td width="14%" align="center">'				. $strMastery_of_Specialization	. '</td>
				<td width="16%" align="center">'				. $strAccess					. '</td>
			  <tr>
			  </table>
			</td>
			<td width="50%">
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="12%" align="center">'				. $strSignet_Crystal_Gemmed		. '</td>
				<td width="12%" align="center">'				. $strSignet_Discolored			. '</td>
				<td width="12%" align="center">'				. $strSignet_Dust_Marred		. '</td>
				<td width="12%" align="center">'				. $strSignet_Glimmering			. '</td>
				<td width="12%" align="center">'				. $strSignet_Tarnished			. '</td>
				<td width="12%" align="center">'				. $strSignet_Two_Toned			. '</td>
				<td width="12%" align="center">'				. $strSignet_Weather_Worn		. '</td>
				<td width="16%" align="center">'				. $strImmune					. '</td>
			  <tr>
			  </table>
			</td>
		  </tr>
		';
	}
}

?>
