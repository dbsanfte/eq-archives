<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );
require_once( GetSkinDir() . 'class.skin.inc' );


// ============================================================================
// The GoD_DSS class
// ============================================================================
// This class provides an interface to the GoD_DSS table that keeps track of
// the Discord Skin Samples Quest progress.
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class GoD_DSS
{
	// Member variables
	var $theSkin;
	var $bShowVerticalScrollbars	= true;

	// ========================================================================
	// Constructor
	// ========================================================================
	function GoD_DSS()
	{
		// Create the skin
		$this->theSkin	= new Skin();
	}

	// ========================================================================
	// Get the title of this list
	// ========================================================================
	// Out:	The title of this list
	// ========================================================================
	function GetTitle()
	{
		return "Discord Skin Samples Quest";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<div id="Header">
		<br />
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td width= "5%" align="center">' . GetInfoLink( "Discord_Skin_Samples", "Gates of Discord: Discord Skin Samples Quest information" ) . '</td>
			<td width="15%">				<b><a href="form.php?FormName=GoD_DSS&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=CharName&SortDirection='			. GetSortDirection( $strSortOrder, "CharName",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Name\';return true;"					OnMouseOut="window.status=\'\'"	target=Body title="Name"				>Name</a></b></td>
			<td width= "7%" align="center">	<b><a href="form.php?FormName=GoD_DSS&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=A_Kyv_Sample&SortDirection='		. GetSortDirection( $strSortOrder, "A_Kyv_Sample",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by A Kyv Sample\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="A Kyv Sample"		>Kyv</a></b></td>
			<td width= "7%" align="center">	<b><a href="form.php?FormName=GoD_DSS&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=A_Mastruq_Sample&SortDirection='	. GetSortDirection( $strSortOrder, "A_Mastruq_Sample",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by A Mastruq Sample\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="A Mastruq Sample"	>Mastruq</a></b></td>
			<td width= "7%" align="center">	<b><a href="form.php?FormName=GoD_DSS&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=A_Noc_Sample&SortDirection='		. GetSortDirection( $strSortOrder, "A_Noc_Sample",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by A Noc Sample\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="A Noc Sample"		>Noc</a></b></td>
			<td width= "7%" align="center">	<b><a href="form.php?FormName=GoD_DSS&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=A_Ratuk_Sample&SortDirection='		. GetSortDirection( $strSortOrder, "A_Ratuk_Sample",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by A Ratuk Sample\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="A Ratuk Sample"		>Ratuk</a></b></td>
			<td width= "7%" align="center">	<b><a href="form.php?FormName=GoD_DSS&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=An_Aneuk_Sample&SortDirection='		. GetSortDirection( $strSortOrder, "An_Aneuk_Sample",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by An Aneuk Sample\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="An Aneuk Sample"		>Aneuk</a></b></td>
			<td width= "7%" align="center">	<b><a href="form.php?FormName=GoD_DSS&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=An_Ikaav_Sample&SortDirection='		. GetSortDirection( $strSortOrder, "An_Ikaav_Sample",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by An Ikaav Sample\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="An Ikaav Sample"		>Ikaav</a></b></td>
			<td width= "7%" align="center">	<b><a href="form.php?FormName=GoD_DSS&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=An_Ixt_Sample&SortDirection='		. GetSortDirection( $strSortOrder, "An_Ixt_Sample",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by An Ixt Sample\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="An Ixt Sample"		>Ixt</a></b></td>
			<td width= "7%" align="center">	<b><a href="form.php?FormName=GoD_DSS&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=An_Ukun_Sample&SortDirection='		. GetSortDirection( $strSortOrder, "An_Ukun_Sample",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by An Ukun Sample\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="An Ukun Sample"		>Ukun</a></b></td>
			<td width= "7%" align="center">	<b><a href="form.php?FormName=GoD_DSS&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=ZunMuram_Sample&SortDirection='		. GetSortDirection( $strSortOrder, "ZunMuram_Sample",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Zun\\\'Muram Sample\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Zun\'Muram Sample"	>Zun\'M.</a></b></td>
			<td width= "7%" align="center">	<b><a href="form.php?FormName=GoD_DSS&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=TunatMuram_Sample&SortDirection='	. GetSortDirection( $strSortOrder, "TunatMuram_Sample",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Tunat\\\'Muram Sample\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Tunat\'Muram Sample"	>Tunat\'M.</a></b></td>
			<td width= "5%"></td>
			<td width= "5%" align="center">	<b><a href="form.php?FormName=GoD_DSS&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Done&SortDirection='				. GetSortDirection( $strSortOrder, "Done",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Quest completed\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Quest completed"		>Done</a></b></td>
		  </tr>
		</table>
		</div>
		<!-- End of Header -->
		';
	}
	
	
	
	// ========================================================================
	// Show all the records on screen
	// ========================================================================
	// This function will loop through all the records in the database table,
	// and create a html table entry for each one of them.
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS		= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];
		$strClassFilter		= $_GET['ClassFilter'];

		// Declare variables
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT CharName, NameMain, A_Kyv_Sample, A_Mastruq_Sample, A_Noc_Sample, A_Ratuk_Sample, An_Aneuk_Sample, An_Ikaav_Sample, An_Ixt_Sample, An_Ukun_Sample, ZunMuram_Sample, TunatMuram_Sample, OldMember \n" .
							  "FROM GoD_DSS_Quest \n" .
							  "LEFT JOIN Characters ON (GoD_DSS_Quest.CharID = Characters.CharID) \n" .
							  "WHERE (	A_Kyv_Sample > 0		OR \n" .
							  "			A_Mastruq_Sample > 0	OR \n" .
							  "			A_Noc_Sample > 0		OR \n" .
							  "			A_Ratuk_Sample > 0		OR \n" .
							  "			An_Aneuk_Sample > 0		OR \n" .
							  "			An_Ikaav_Sample > 0		OR \n" .
							  "			An_Ixt_Sample > 0		OR \n" .
							  "			An_Ukun_Sample > 0		OR \n" .
							  "			ZunMuram_Sample > 0		OR \n" .
							  "			TunatMuram_Sample > 0 )	   \n";	

		// Check if we should set a class filter
		if( ( isset( $strClassFilter ) ) &&
			( $strClassFilter != "" ) &&
			( $strClassFilter != "<<All>>" ) )
		{
			$strSelectQuery	.= "AND Class = '" . $strClassFilter . "'";
		} 

		// Check if we should use the default sort order
		if( ( !isset( $strSortOrder ) ) ||
			( $strSortOrder == "" ) )
		{
			// Default sort on Character name
			$strSortOrder	= "CharName"; 
		}

		// Check if we're sorting on Access
		if( $strSortOrder == "Done" )
		{
			// Default sort on Character name
			$strSortOrder	= "(A_Kyv_Sample + A_Mastruq_Sample + A_Noc_Sample + A_Ratuk_Sample + An_Aneuk_Sample + An_Ikaav_Sample + An_Ixt_Sample + An_Ukun_Sample + ZunMuram_Sample + TunatMuram_Sample)"; 
		}

		// Sorting on all numbers should be reversed (Desc first, then Asc)
		$strModifiedSortDirection	= $strSortDirection;
		if( $strSortOrder != "CharName" )
		{
			// Switch the sort order around
			if( $strModifiedSortDirection == "DESC" )
			{
				$strModifiedSortDirection	= "";
			}
			else
			{
				$strModifiedSortDirection	= "DESC";
			}
		}
	
		// Add the sort order
		$strSelectQuery		.= "ORDER BY " . $strSortOrder . " " . $strModifiedSortDirection . ", CharName";
	
		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
		<div id="Body">
		<table id="RosterTable" width="100%" border="0" cellpadding="0" cellspacing="0">
		';

		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex				= 0;
			$strCharName		= $aResult[$nIndex++];
			$strNameMain		= $aResult[$nIndex++];
			$nA_Kyv_Sample		= $aResult[$nIndex++];
			$nA_Mastruq_Sample	= $aResult[$nIndex++];
			$nA_Noc_Sample		= $aResult[$nIndex++];
			$nA_Ratuk_Sample	= $aResult[$nIndex++];
			$nAn_Aneuk_Sample	= $aResult[$nIndex++];
			$nAn_Ikaav_Sample	= $aResult[$nIndex++];
			$nAn_Ixt_Sample		= $aResult[$nIndex++];
			$nAn_Ukun_Sample	= $aResult[$nIndex++];
			$nZunMuram_Sample	= $aResult[$nIndex++];
			$nTunatMuram_Sample	= $aResult[$nIndex++];
			$nOldMember			= $aResult[$nIndex++];
	
			// Only show old members for the administrator
			if( ( $strCharName != "" ) &&
				( ( $nOldMember == 0 ) ||
				  ( IsAdministrator( $strUserName ) ) ) )
			{
				// Show the BoT Flag parts
				$this->ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nA_Kyv_Sample, $nA_Mastruq_Sample, $nA_Noc_Sample, $nA_Ratuk_Sample, $nAn_Aneuk_Sample, $nAn_Ikaav_Sample, $nAn_Ixt_Sample, $nAn_Ukun_Sample, $nZunMuram_Sample, $nTunatMuram_Sample, $nOldMember, $strRowType );
		
				// Switch RowType, so the rows alternate	
				if( $strRowType == "OddRow" )
				{
					$strRowType	= "EvenRow";
				}
				else
				{
					$strRowType	= "OddRow";
				}
			}
		}
	
		// End the table
		echo '
		</table>
		</div>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );
	}
	
	
	
	// ========================================================================
	// Show a record
	// ========================================================================
	// This function will create a html table row for a record in the table
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// In:  Variables containing the data to show 
	// ========================================================================
	function ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nA_Kyv_Sample, $nA_Mastruq_Sample, $nA_Noc_Sample, $nA_Ratuk_Sample, $nAn_Aneuk_Sample, $nAn_Ikaav_Sample, $nAn_Ixt_Sample, $nAn_Ukun_Sample, $nZunMuram_Sample, $nTunatMuram_Sample, $nOldMember, $strRowType )
	{
		// Declare variables
		$strImageCheck			= '<img src="' . GetSkinDir() . 'images/check.gif" border="0" />';
		$strDeleteChar			= "";
		$strA_Kyv_Sample		= "";
		$strA_Mastruq_Sample	= "";
		$strA_Noc_Sample		= "";
		$strA_Ratuk_Sample		= "";
		$strAn_Aneuk_Sample		= "";
		$strAn_Ikaav_Sample		= "";
		$strAn_Ixt_Sample		= "";
		$strAn_Ukun_Sample		= "";
		$strZunMuram_Sample		= "";
		$strTunatMuram_Sample	= "";
		$strCompleted			= "";

		// Set the check-image for all filled variables
		if( $nA_Kyv_Sample > 0 )		{	$strA_Kyv_Sample		= $strImageCheck;	}
		if( $nA_Mastruq_Sample > 0 )	{	$strA_Mastruq_Sample	= $strImageCheck;	}
		if( $nA_Noc_Sample > 0 )		{	$strA_Noc_Sample		= $strImageCheck;	}
		if( $nA_Ratuk_Sample > 0 )		{	$strA_Ratuk_Sample		= $strImageCheck;	}
		if( $nAn_Aneuk_Sample > 0 )		{	$strAn_Aneuk_Sample		= $strImageCheck;	}
		if( $nAn_Ikaav_Sample > 0 )		{	$strAn_Ikaav_Sample		= $strImageCheck;	}
		if( $nAn_Ixt_Sample > 0 )		{	$strAn_Ixt_Sample		= $strImageCheck;	}
		if( $nAn_Ukun_Sample > 0 )		{	$strAn_Ukun_Sample		= $strImageCheck;	}
		if( $nZunMuram_Sample > 0 )		{	$strZunMuram_Sample		= $strImageCheck;	}
		if( $nTunatMuram_Sample	 > 0 )	{	$strTunatMuram_Sample	= $strImageCheck;	}
		if( ( $nA_Kyv_Sample > 0 ) &&
			( $nA_Mastruq_Sample > 0 ) &&
			( $nA_Noc_Sample > 0 ) &&
			( $nA_Ratuk_Sample > 0 ) &&
			( $nAn_Aneuk_Sample > 0 ) &&
			( $nAn_Ikaav_Sample > 0 ) &&
			( $nAn_Ixt_Sample > 0 ) &&
			( $nAn_Ukun_Sample > 0 ) &&
			( $nZunMuram_Sample > 0 ) &&
			( $nTunatMuram_Sample > 0 ) )
		{
			$strCompleted	= $strImageCheck;
		}
	        
		// Check if it's an old member
		if( $nOldMember == 1 )
		{   
			$strRowType		= "DeletedRow";
            
			// Allow the deletion of old members
			$strDeleteChar	= ' <a href="form.php?FormName=Character_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=GoD_DSS&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Delete ' . $strCharName . '\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Delete ' . $strCharName . '"><img src="' . GetSkinDir() . 'images/delete.gif" border="0" /></a>';
		}   
	
		// Check if this character belongs to the logged in User
		$strModify	= "";
		if( ( isset( $strUserName ) ) &&
			( isset( $strNameMain ) ) &&
			( $strUserName == $strNameMain ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=GoD_DSS&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify.gif" border="0" />';
		}
		else if( IsAdministrator( $strUserName ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=GoD_DSS&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify_others.gif" border="0" />';
		}
	
		echo '
		  <tr	onMouseOver="this.bgColor=\'' . $this->theSkin->strRowHighlightColor . '\'" onMouseOut="this.bgColor=\'\'">
			<td width= "5%" align="center">'				. $strModify			. '</td>
			<td width="15%" class="' . $strRowType . '">'	. $strCharName			. $strDeleteChar . '</td>
			<td width= "7%" align="center">'				. $strA_Kyv_Sample		. '</td>
			<td width= "7%" align="center">'				. $strA_Mastruq_Sample	. '</td>
			<td width= "7%" align="center">'				. $strA_Noc_Sample		. '</td>
			<td width= "7%" align="center">'				. $strA_Ratuk_Sample	. '</td>
			<td width= "7%" align="center">'				. $strAn_Aneuk_Sample	. '</td>
			<td width= "7%" align="center">'				. $strAn_Ikaav_Sample	. '</td>
			<td width= "7%" align="center">'				. $strAn_Ixt_Sample		. '</td>
			<td width= "7%" align="center">'				. $strAn_Ukun_Sample	. '</td>
			<td width= "7%" align="center">'				. $strZunMuram_Sample	. '</td>
			<td width= "7%" align="center">'				. $strTunatMuram_Sample	. '</td>
			<td width= "5%"></td>
			<td width= "5%" align="center">'				. $strCompleted			. '</td>
		  </tr>
		';
	}

}

?>
