<?php
////////////////////////////////////////////////////////////////////////////////
//
//	Author:	Micha�l Schoonbrood
//	Date:	March 18, 2004
//
//	Description:
//	This script provides some default functions that are used in the EQRoster
//
//	Usage:
//	Add the following line under the "<?php" tag:
//	require_once( './includes/functions.inc' );
//
////////////////////////////////////////////////////////////////////////////////



/// =============================================================================
// Convert a string to a name
// First and Last-name need to start with capitals, all the other letters should be lowercase
// =============================================================================
// In:	$strUnformattedName	= String containing the unformatted name
// Out:	$strFormattedName	= The formatted name
function FormatName( $strUnformattedName )
{
	// Declare variables
	$strFormattedName	= strtolower( $strUnformattedName );
	$nStartPos			= -1;

	while( $nStartPos != false )
	{
		// Convert the first char after the space to uppercase
		// The first time we enter this loop, this will be the first character in the string
		if( ($nStartPos+1) < strlen( $strFormattedName ) )
		{
			// Convert the char on the next pos to uppercase
			$strUpperChar		= strtoupper( substr( $strFormattedName, $nStartPos+1, 1 ) );
			// Replace the char in the name with the upperstring char
			$strFormattedName	= substr_replace( $strFormattedName, $strUpperChar, $nStartPos+1, 1 );
		}

		// Scan if there is a space in the string
		$nStartPos	= strpos( $strFormattedName, " ", $nStartPos+1 );
	}

	// Scan if there is a ' in the name
	$nStartPos	= strpos( $strFormattedName, "'", 0 );
	if( $nStartPos != false )
	{
		// Check if the position before the quote ain't a slash already
		if( ( $nStartPos > 0 ) &&
			( $strFormattedName[$nStartPos-1] != "\\" ) )
		{
			// Replace the quote in the name with a slash quote
			$strFormattedName	= substr_replace( $strFormattedName, "\\'", $nStartPos, 1 );
		}
	}

	// Return the name
	return $strFormattedName;
}



// =============================================================================
// Encrypt a string
// =============================================================================
// In:	$strSource		= The string to encrypt
// Out:	$strEncrypted	= The encrypted string
function Encrypt( $strSource )
{
	$strEncrypted	= crypt( md5( $strSource ), md5( $strSource ) );
	return $strEncrypted;
}



// =============================================================================
// Create a select box on a enum field
// =============================================================================
// In:	$strTableName			= Name of table that contains the enum field
//		$strRequestedFieldName	= Name of enum field to create the select box on
//		$strDefaultValue		= Value of the enum field the should be selected by default
//		$strOffSet				= String containing spaces to align the select box with the rest of the html code
// Out:	$strResult				= The html code to create the select box
function CreateSelectFromEnum( $strTableName, $strRequestedFieldName, $strDefaultValue, $strOffSet )
{
	// Declare variables
	$strResult		= "";

	// Connect to the database
	$nLinkID	= DBConnect();

	// Get the database fields
	$nResult	= mysql_query( "DESCRIBE $strTableName $strRequestedFieldName", $nLinkID );
	$aFields	= mysql_fetch_array( $nResult );

	// Close the connection
	DBDisconnect( $nLinkID );

	// Check if we found the fieldname
	if( sizeof( $aFields ) > 0 )
	{
		// Store the fieldname and fieldtype
		extract( $aFields );
		$strFieldName			= $aFields[0];
		$strFieldType			= $aFields[1];
		$strFieldDefaultValue	= $aFields[4];

		// Check if no default value was passed
		if( !isset( $strDefaultValue ) )
		{
			// Use the default value from the table
			$strDefaultValue	= $strFieldDefaultValue;
		}

		// Make sure it is an enum field
		if( ( substr( $strFieldType, 0, 4 ) == 'enum' ) )
		{
			// Subtract the items from the fieldtype 
			$strItems	= substr( $strFieldType, 5, (strlen( $strFieldType ) - 6) );
			// Store them in an array
			$aItems		= explode( ',', $strItems );
			// make sure we found any items
			if( sizeof( $aItems ) > 0 )
			{
				// Create the combobox
				$strResult			= "<select name=\"cmb" . $strFieldName . "\" id=\"cmb" . $strFieldName . "\"><br />\n";	// $strOffSet is not used here, because we expect this function to be called at that offset.
				for( $idx=0; $idx < sizeof( $aItems ); $idx++ )
				{
					// Extract the item (without the quotes)
					$strItem		= substr( $aItems[$idx], 1, (strlen( $aItems[$idx] ) - 2) );
					// Create the option
					$strResult		.= "$strOffSet    <option value=\"" . $strItem . "\"";
					// Check if this is the default option
					if( $strItem == $strDefaultValue )
					{
						$strResult	.= " selected=\"selected\"";
					}
					// Finish the option
					$strResult		.= ">" . $strItem . "</option>\n";
				}
				// Finish the combobox
				$strResult			.= "$strOffSet</select>";
			}
		}
	}

	// Done, return the result
	return $strResult;
}



// =============================================================================
// Show a "LOADING" image in the center of the screen (or active frame)
// This function must be called in the body of a page
// =============================================================================
function ShowLoadingImage()
{
	echo '
	<script language="JavaScript">
		// Show the loading text on the status bar
		window.status	= \'Loading, please wait...\';
	</script>

	<!-- Show the loading image -->
	<image id="imgLoading" src="' . GetSkinDir() . 'images/loading.gif"	style="position:absolute; top:50%; left:50%; margin-top:-23px; margin-left:-131px;" width="262" height="45" />

	'; 
} 



// =============================================================================
// Hide the "LOADING" image you created with ShowLoadingImage()
// =============================================================================
function HideLoadingImage()
{
	// Hide the loading image and text
	echo '
	<script language="JavaScript">
		// Get the loading image element
		elementImgLoading	= document.getElementById( \'imgLoading\' );
		if( elementImgLoading != null )
		{
			// Hide the loading image
			elementImgLoading.style.display	= \'none\';
		}
		// Hide the loading text on the status bar
		window.status	= \'\';
	</script>';
}



// =============================================================================
// Read the cookie
// =============================================================================
// Out:	$strCookieValues		= Array containing all the cookie values
//		[0] $strUserName		= Name of the user
// 		[1] $strPassword		= Password for the user
//		[2] $strSortOrder		= Sort order to sort on
//		[3] $strSortDirection	= Direction to sort in
// 		[4] $strShowAlts		= Show Alts ('Yes') or not ('No')
function ReadCookie()
{
	// Initialize variables
	$strCookieValues[0]	= "";
	$strCookieValues[1]	= "";
	$strCookieValues[2]	= "";
	$strCookieValues[3]	= "";
	$strCookieValues[4]	= "";

	// Read the cookie
	if( isset( $_COOKIE['EQRoster'] ) )
	{
		// Read the variables from the cookie
		foreach( $_COOKIE['EQRoster'] as $strCookieName => $strCookieValue )
		{
			// Check for UserName
			if( $strCookieName == "UserName" )
			{
				$strCookieValues[0]	= $strCookieValue;
			}
			// Check for Password
			else if( $strCookieName == "Password" )
			{
				$strCookieValues[1]	= $strCookieValue;
			}
			// Check for SortOrder
			else if( $strCookieName == "SortOrder" )
			{
				$strCookieValues[2]	= $strCookieValue;
			}
			// Check for SortDirection
			else if( $strCookieName == "SortDirection" )
			{
				$strCookieValues[3]	= $strCookieValue;
			}
			// Check for ShowAlts
			else if( $strCookieName == "ShowAlts" )
			{
				$strCookieValues[4]	= $strCookieValue;
			}
		}
	}
	
	// Return the cookie values
	return $strCookieValues;
}



// =============================================================================
// Write the cookie
// =============================================================================
// In:	$strUserName			= Name of the user
// 		$strPassword			= Password for the user
//		$strSortOrder			= Last used sort order
//		$strSortDirection		= Last used sort direction
// 		$strShowAlts			= 'Yes' or 'No' depending on wether the user wants to see alts or not
function WriteCookie( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts )
{
	// Cookie expires in 30 days
	$nTime	= time() + 60 * 60 * 24 * 30;	// CurrentTime + Sec * Min * Hours * Days

	// Write the cookie
	if( $strUserName != "" )
	{
		setcookie( "EQRoster[UserName]",		$strUserName,		$nTime );
	}
	if( $strPassword != "" )
	{
		setcookie( "EQRoster[Password]",		$strPassword,		$nTime );
	}
	if( $strSortOrder != "" )
	{
		setcookie( "EQRoster[SortOrder]",		$strSortOrder,		$nTime );
	}
	if( $strSortDirection != "" )
	{
		setcookie( "EQRoster[SortDirection]",	$strSortDirection,	$nTime );
	}
	if( $strShowAlts != "" )
	{
		setcookie( "EQRoster[ShowAlts]",		$strShowAlts,		$nTime );
	}
}



// =============================================================================
// Delete the cookie
// =============================================================================
function DeleteCookie()
{
	// Cookie has expired
	$nTime	= time() - 3600;

	setcookie( "EQRoster[UserName]",		"",	$nTime );
	setcookie( "EQRoster[Password]",		"",	$nTime );
	setcookie( "EQRoster[SortOrder]",		"",	$nTime );
	setcookie( "EQRoster[SortDirection]",	"",	$nTime );
	setcookie( "EQRoster[ShowAlts]",		"",	$nTime );
}



// =============================================================================
// Get the sort direction
// =============================================================================
// In:	$strOldSortOrder	= String containing the old sort order
// In:	$strNewSortOrder	= String containing the new sort order
// In:	$strSortDirection	= String containing the old sort direction
// Out:	$strSortDirection	= String containing the new sort direction
function GetSortDirection( $strOldSortOrder, $strNewSortOrder, $strSortDirection )
{
	// Check if the Sort Order is the same
	if( $strOldSortOrder == $strNewSortOrder )
	{
		// Toggle the sort direction
		if( $strSortDirection == "DESC" )
		{
			$strSortDirection	= "";
		}
		else
		{
			$strSortDirection	= "DESC";
		}
	}
	else
	{
		// Clear the sort direction (ASC)
		$strSortDirection	= "";
	}

	// Return the sort direction
	return $strSortDirection;
}



// =============================================================================
// Create the start of the HTML page (doctype, head, etc)
// =============================================================================
// In:	$strTitle	= Title of the page
function CreateHTMLStart( $strTitle, $bShowVerticalScrollbars )
{
	echo'
<html>
<head>
	<title>EverQuest Roster: ' . $strTitle . ' </title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<link rel="stylesheet" href="' . GetSkinDir() . 'roster.css" type="text/css">';

	if( $bShowVerticalScrollbars == true )
	{
		echo'
	<link rel="stylesheet" href="' . GetSkinDir() . 'roster_body_inc_vert_scrollbar.css" type="text/css">';
	}

	echo'
</head>


<body>
	';
}



// =============================================================================
// Create the end of the HTML page (closing body and html tags)
// =============================================================================
function CreateHTMLEnd()
{
	echo '

</body>
</html>
	';
}



// ========================================================================
// Load a form (using the form.php)
// ========================================================================
// This function submits the page, and makes the form.php load a different form.
// We can't use a meta refresh for this, because it doesn't accept a target,
// and always loads in the active frame
// ========================================================================
// In:	$strFormName	= Name of form to load
// In:	$strParameters	= Optional parameters to pass to the form.php (like username, pw, etc)
function LoadForm( $strFormName, $strParameters )
{
	echo '
	<form name="formLoadForm" method="post" action="form.php?FormName=' . $strFormName . $strParameters . '" target=Body>
		<script language=javascript>
			// Submit the form
			document.formLoadForm.submit();
		</script>
	</form>';
	print( "\n\n\n" );
}



// ========================================================================
// Return a string containing wether a checkbox or radio button is checked or not
// ========================================================================
// This function takes a numeric value (0/1) that indicates wether a checkbox
// or radio button is checked or not, and returns a usable HTML Input tag
// 
// Usage: 
// <input type="checkbox" name="cbTest" value="1" ' . GetCheckboxValue( $nTestValue ) . '>
// <input type="radio" name="rbTest" ' . GetRadioButtonValue( $nTestValue ) . '>
// ========================================================================
// In:	$nValue		= The value of the checkbox
// Out:	$strResult	= string containing usable HTML input tag
function GetCheckboxValue( $nValue )
{
	// Declare variables
	$strResult	= "";

	// Check if the checkbox is checked
	if( ( $nValue == 1 ) ||
		( $nValue == true ) )
	{
		$strResult	= "checked";
	}

	return $strResult;
}



// =============================================================================
// Get an Information Link for a roster topic/flag/key/mission
// =============================================================================
function GetInfoLink( $strTopic, $strToolTip )
{
	// Declare variables
	$strLink	= "";
	$strURL		= "";

	// General
	if( $strTopic == "TradeSkills" )
	{
		$strURL	= "http://www.eqtraders.com/articles/news_page.php";
	}
	// Kunark
	else if( $strTopic == "Veeshans_Peak_Keys" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=87";
	}
	// Luclin
	else if( $strTopic == "SSRA_Keys" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=1999";
	}
	else if( $strTopic == "Vex_Thal_Keys" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=2000";
	}
	// PoP
	else if( $strTopic == "PoP_Progression" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=2638";
	}
	else if( $strTopic == "PoS_Askr_Quest" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=2269";
	}
	else if( $strTopic == "BiC_Start" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=2781";
	}
	else if( $strTopic == "BiC_Part1" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=2868";
	}
	else if( $strTopic == "BiC_Part1" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=2868";
	}
	else if( $strTopic == "BiC_Part1" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=2868";
	}
	else if( $strTopic == "BiC_Part2" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=2869";
	}
	else if( $strTopic == "BiC_Part3" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=2870";
	}
	else if( $strTopic == "BiC_Part4" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=2871";
	}
	else if( $strTopic == "BiC_Part5" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=2872";
	}
	else if( $strTopic == "BiC_Part6" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=2873";
	}
	else if( $strTopic == "BiC_Part7" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=2874";
	}
	else if( $strTopic == "BiC_Part8" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=2875";
	}
	else if( $strTopic == "BiC_Part9" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=2876";
	}
	else if( $strTopic == "BiC_Part10" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=2880";
	}
	else if( $strTopic == "BiC_Part11" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=2881";
	}
	else if( $strTopic == "BiC_Part12" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=2882";
	}
	else if( $strTopic == "BiC_Part13" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=2891";
	}
	else if( $strTopic == "BiC_Part14" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=2909";
	}
	// Gates of Discord
	else if( $strTopic == "GoD_Progression" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/zone.html?zcont=Gates";
	}
	else if( $strTopic == "Discord_Skin_Samples" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=2839";
	}
	// Omens of War
	else if( $strTopic == "OoW_CoA" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=2978";
	}
	// DoN Missions
	else if( $strTopic == "DoN_Progression_Good" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=3061";
	}
	// DoD
	else if( $strTopic == "DoD_Missions" )
	{
		$strURL	= "http://samanna.net/gen.info/prog.dod.shtml";
	}
	else if( $strTopic == "DoD_MaskQuest" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=3264";
	}
	else if( $strTopic == "DoD_SpellMission68" )
	{
		$strURL	= "http://eqbeastiary.allakhazam.com/search.shtml?id=19190";
	}
	else if( $strTopic == "DoD_SpellMission69" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=3204";
	}
	else if( $strTopic == "DoD_SpellMission70" )
	{
		$strURL	= "http://eqbeastiary.allakhazam.com/search.shtml?id=19151";
	}
	else if( $strTopic == "DoD_ElderLongshadow" )
	{
		$strURL	= "http://eqbeastiary.allakhazam.com/search.shtml?id=19271";
	}
	else if( $strTopic == "DoD_KorlachLeviathan" )
	{
		$strURL	= "http://eqbeastiary.allakhazam.com/search.shtml?id=19270";
	}
	else if( $strTopic == "DoD_FindFibblebrap" )
	{
		$strURL	= "http://eqbeastiary.allakhazam.com/search.shtml?id=18946";
	}
	else if( $strTopic == "Dreadspire_Keep" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=3203";
	}
	else if( $strTopic == "DemiPlane_of_Blood" )
	{
//		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=3582";
		$strURL	= "http://samanna.net/gen.info/prog.bloodkey.shtml";
	}
	// PoR
	else if( $strTopic == "Theatre_of_Blood" )
	{
		$strURL	= "http://everquest.allakhazam.com/db/quest.html?quest=3444";
	}

	// Create the Link
	if( $strURL != "" )
	{
		$strLink	= ' <a href="' . $strURL . '" OnMouseOver="window.status=\'' . $strToolTip . '\';return true;" OnMouseOut="window.status=\'\'" target="_Blank" title="' . $strToolTip . '"><img src="' . GetSkinDir() . 'images/information.gif" border="0" /></a>';
	}

	return $strLink;
}

?>