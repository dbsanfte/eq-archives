<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );
require_once( GetSkinDir() . 'class.skin.inc' );


// ============================================================================
// The DemiPlane_of_Blood class
// ============================================================================
// This class provides an interface to the DemiPlane_of_Blood table
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class DemiPlane_of_Blood
{
	// Member variables
	var $theSkin;
	var $bShowVerticalScrollbars	= true;

	// ========================================================================
	// Constructor
	// ========================================================================
	function DemiPlane_of_Blood()
	{
		// Create the skin
		$this->theSkin	= new Skin();
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "Demi-Plane of Blood";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<div id="Header">
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td width= "5%" align="center">' . GetInfoLink( "DemiPlane_of_Blood", "Demi-Plane of Blood information" ) . '</td>
			<td width="12%">				<b><a href="form.php?FormName=DemiPlane_of_Blood&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=CharName&SortDirection='						. GetSortDirection( $strSortOrder, "CharName",					$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Name\';return true;"						OnMouseOut="window.status=\'\'"	target=Body title="Name"																												>Name</a></b></td>
			<td width="13%" align="center">	<b><a href="form.php?FormName=DemiPlane_of_Blood&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Frustrated_Functionary&SortDirection='		. GetSortDirection( $strSortOrder, "Frustrated_Functionary",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Frustrated Functionary\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Frustrated Functionary (from Melion Pell, Minor Functionary in Dreadspire Keep)"										>Frustrated<br />Functionary</a></b></td>
			<td width="13%" align="center">	<b><a href="form.php?FormName=DemiPlane_of_Blood&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Check_out_a_library_book&SortDirection='		. GetSortDirection( $strSortOrder, "Check_out_a_library_book",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Check Out a Library Book\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Check Out a Library Book (from Treddlehoop in Corathus Creep, reward: Polished Mystical Glass Shard)"				>Check Out a<br />Library Book</a></b></td>
			<td width="13%" align="center">	<b><a href="form.php?FormName=DemiPlane_of_Blood&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Eyes_Wide_Open&SortDirection='				. GetSortDirection( $strSortOrder, "Eyes_Wide_Open",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Eyes Wide Open\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Eyes Wide Open (from Treddlehoop in Corathus Creep, reward: Blurry Lens)"											>Eyes Wide<br />Open</a></b></td>
			<td width="13%" align="center">	<b><a href="form.php?FormName=DemiPlane_of_Blood&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Memories_Lost&SortDirection='				. GetSortDirection( $strSortOrder, "Memories_Lost",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Memories Lost\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Memories Lost (from Doorman in Dreadspire Keep, reward: Access to Vule)"												>Memories<br />Lost</a></b></td>
			<td width="13%" align="center">	<b><a href="form.php?FormName=DemiPlane_of_Blood&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Misty_for_You&SortDirection='				. GetSortDirection( $strSortOrder, "Misty_for_You",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Misty for You\';return true;"				OnMouseOut="window.status=\'\'"	target=Body title="Misty for You (from Coldwind Blackfoot in Nektulos Forest, reward: Lens of Bound Eyes)"								>Misty<br />for You</a></b></td>
			<td width="13%" align="center">	<b><a href="form.php?FormName=DemiPlane_of_Blood&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Eye_Bound&SortDirection='					. GetSortDirection( $strSortOrder, "Eye_Bound",					$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Eye Bound\';return true;"					OnMouseOut="window.status=\'\'"	target=Body title="Eye Bound (from Coldwind Blackfoot in Nektulos Forest, reward: Lens of Eye-Glass)"									>Eye<br />Bound</a></b></td>
			<td width= "5%" align="center">	<b><a href="form.php?FormName=DemiPlane_of_Blood&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Access&SortDirection='						. GetSortDirection( $strSortOrder, "Access",					$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by access\';return true;"						OnMouseOut="window.status=\'\'"	target=Body title="Demi-Plane of Blood Access (Completed final turn in at Treddlehoop in Corathus Creep, reward: Monocle of Blood)"		>Done</a></b></td>
		  </tr>
		</table>
		</div>
		<!-- End of Header -->
		';
	}



	// ========================================================================
	// Show all the records on screen
	// ========================================================================
	// This function will loop through all the records in the database table,
	// and create a html table entry for each one of them.
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS		= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];
		$strClassFilter		= $_GET['ClassFilter'];

		// Declare variables
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT CharName, NameMain, Frustrated_Functionary, Check_Out_a_Library_Book, Eyes_Wide_Open, Memories_Lost, Misty_for_You, Eye_Bound, DemiPlane_of_Blood_Access, OldMember \n" .
							  "FROM DoD_Flags \n" .
							  "LEFT JOIN Characters ON (DoD_Flags.CharID = Characters.CharID) \n" .
							  "WHERE (	Frustrated_Functionary > 0		OR \n" .
							  "			Check_Out_a_Library_Book > 0	OR \n" .
							  "			Eyes_Wide_Open > 0				OR \n" .
							  "			Memories_Lost > 0				OR \n" .
							  "			Misty_for_You > 0				OR \n" .
							  "			Eye_Bound > 0					OR \n" .
							  "			DemiPlane_of_Blood_Access > 0 )	   \n";

		// Check if we should set a class filter
		if( ( isset( $strClassFilter ) ) &&
			( $strClassFilter != "" ) &&
			( $strClassFilter != "<<All>>" ) )
		{
			$strSelectQuery	.= "AND Class = '" . $strClassFilter . "'";
		} 

		// Check if we should use the default sort order
		if( ( !isset( $strSortOrder ) ) ||
			( $strSortOrder == "" ) )
		{
			// Default sort on Character name
			$strSortOrder	= "CharName"; 
		}

		// Check if we're sorting on Access
		if( $strSortOrder == "Access" )
		{
			// Default sort on Character name
			$strSortOrder	= "(Frustrated_Functionary + Check_Out_a_Library_Book + Eyes_Wide_Open + Memories_Lost + Misty_for_You + Eye_Bound + (10*DemiPlane_of_Blood_Access))";
		}

		// Sorting on all numbers should be reversed (Desc first, then Asc)
		$strModifiedSortDirection	= $strSortDirection;
		if( $strSortOrder != "CharName" )
		{
			// Switch the sort order around
			if( $strModifiedSortDirection == "DESC" )
			{
				$strModifiedSortDirection	= "";
			}
			else
			{
				$strModifiedSortDirection	= "DESC";
			}
		}
	
		// Add the sort order
		$strSelectQuery		.= "ORDER BY " . $strSortOrder . " " . $strModifiedSortDirection . ", CharName";
	
		// Connect to the database
		$nLinkID	= DBConnect();

		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
		<div id="Body">
		<table id="RosterTable" width="100%" border="0" cellpadding="0" cellspacing="0">
		';

		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex						= 0;
			$strCharName				= $aResult[$nIndex++];
			$strNameMain				= $aResult[$nIndex++];
			$nFrustrated_Functionary	= $aResult[$nIndex++];
			$nCheck_Out_a_Library_Book	= $aResult[$nIndex++];
			$nEyes_Wide_Open			= $aResult[$nIndex++];
			$nMemories_Lost				= $aResult[$nIndex++];
			$nMisty_for_You				= $aResult[$nIndex++];
			$nEye_Bound					= $aResult[$nIndex++];
			$nDemiPlane_of_Blood_Access	= $aResult[$nIndex++];
			$nOldMember					= $aResult[$nIndex++];

			// Only show old members for the administrator
			if( ( $strCharName != "" ) &&
				( ( $nOldMember == 0 ) ||
				  ( IsAdministrator( $strUserName ) ) ) )
			{
				// Show the SSRA Emperor key parts
				$this->ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nFrustrated_Functionary, $nCheck_Out_a_Library_Book, $nEyes_Wide_Open, $nMemories_Lost, $nMisty_for_You, $nEye_Bound, $nDemiPlane_of_Blood_Access, $nOldMember, $strRowType );
		
				// Switch RowType, so the rows alternate	
				if( $strRowType == "OddRow" )
				{
					$strRowType	= "EvenRow";
				}
				else
				{
					$strRowType	= "OddRow";
				}
			}
		}
	
		// End the table
		echo '
		</table>
		</div>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );
	}
	
	
	
	// ========================================================================
	// Show a record
	// ========================================================================
	// This function will create a html table row for a record in the table
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// In:  Variables containing the data to show 
	// ========================================================================
	function ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nFrustrated_Functionary, $nCheck_Out_a_Library_Book, $nEyes_Wide_Open, $nMemories_Lost, $nMisty_for_You, $nEye_Bound, $nDemiPlane_of_Blood_Access, $nOldMember, $strRowType )
	{
		// Declare variables
		$strImageCheck					= '<img src="' . GetSkinDir() . 'images/check.gif" border="0" />';
		$strDeleteChar					= "";
		$strCompleted					= "";
		$strFrustrated_Functionary		= "";
		$strCheck_Out_a_Library_Book	= "";
		$strEyes_Wide_Open				= "";
		$strMemories_Lost				= "";
		$strMisty_for_You				= "";
		$strEye_Bound					= "";
		$strAccess						= "";


		// Set the check-image for all filled variables
		if( $nFrustrated_Functionary > 0 )		{	$strFrustrated_Functionary		= $strImageCheck;	}
		if( $nCheck_Out_a_Library_Book > 0 )	{	$strCheck_Out_a_Library_Book	= $strImageCheck;	}
		if( $nEyes_Wide_Open > 0 )				{	$strEyes_Wide_Open				= $strImageCheck;	}
		if( $nMemories_Lost > 0 )				{	$strMemories_Lost				= $strImageCheck;	}
		if( $nMisty_for_You > 0 )				{	$strMisty_for_You				= $strImageCheck;	}
		if( $nEye_Bound > 0 )					{	$strEye_Bound					= $strImageCheck;	}
		if( $nDemiPlane_of_Blood_Access > 0 )	{	$strAccess						= $strImageCheck;	}
	
		// Check if it's an old member
		if( $nOldMember == 1 )
		{
			$strRowType		= "DeletedRow";

			// Allow the deletion of old members
			$strDeleteChar	= ' <a href="form.php?FormName=Character_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=DemiPlane_of_Blood&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Delete ' . $strCharName . '\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Delete ' . $strCharName . '"><img src="' . GetSkinDir() . 'images/delete.gif" border="0" /></a>';
		}
	
		// Check if this character belongs to the logged in User
		$strModify	= "";
		if( ( isset( $strUserName ) ) &&
			( isset( $strNameMain ) ) &&
			( $strUserName == $strNameMain ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=DemiPlane_of_Blood&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify.gif" border="0" />';
		}
		else if( IsAdministrator( $strUserName ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=DemiPlane_of_Blood&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify_others.gif" border="0" />';
		}
	
		echo '
		  <tr	onMouseOver="this.bgColor=\'' . $this->theSkin->strRowHighlightColor		. '\'" onMouseOut="this.bgColor=\'\'">
			<td width= "5%" align="center">'				. $strModify					. '</td>
			<td width="12%" class="' . $strRowType . '">'	. $strCharName					. $strDeleteChar . '</td>
			<td width="13%" align="center">'				. $strFrustrated_Functionary	. '</td>
			<td width="13%" align="center">'				. $strCheck_Out_a_Library_Book	. '</td>
			<td width="13%" align="center">'				. $strEyes_Wide_Open			. '</td>
			<td width="13%" align="center">'				. $strMemories_Lost				. '</td>
			<td width="13%" align="center">'				. $strMisty_for_You				. '</td>
			<td width="13%" align="center">'				. $strEye_Bound					. '</td>
			<td width= "5%" align="center">'				. $strAccess					. '</td>
		  </tr>
		';
	}

}

?>
