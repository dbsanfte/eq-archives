<?php
// Includes
require_once( './includes/class.httpconnection.inc' );
require_once( GetSkinDir() . 'class.skin.inc' );

// ============================================================================
// The Magelo class
// ============================================================================
// This class will retrieve and store all the info from a characters magelo
//
// Usage:
// Create a Magelo object, passing the required 3 parameters:
//	$theMagelo	= new Magelo( $strMageloNr, $strCharacterName, $strCharacterClass );
// Call the import function:
//	$bMageloImported	= $theMagelo->Import();
// Check if the Import succeeded
//	if( $bMageloImported == true )
//	{
//		// Perform your actions with the magelo variables here
//	}
//
// ============================================================================
class Magelo
{
	// Member variables
	var $theSkin;
	var $strMageloNr						= "";
	var $strCharName						= "";
	var $strLastName						= "";
	// Character info
	var $strClass							= "";
	var $strRace							= "";
	var $strDeity							= "";
	var $nLevel								= 0;
	var $nAA								= 0;
	var $nNrOfGLPs							= 0;
	// Character Statistics
	var $nHP								= 0;
	var $nMana								= 0;
	var $nEndurance							= 0;
	var $nAC								= 0;
	var $nFT								= 0;
	var $nRegen								= 0;
	var $nAtk								= 0;
	var $nStr								= 0;
	var $nSta								= 0;
	var $nAgi								= 0;
	var $nDex								= 0;
	var $nWis								= 0;
	var $nInt								= 0;
	var $nCha								= 0;
	var $nPR								= 0;
	var $nMR								= 0;
	var $nDR								= 0;
	var $nFR								= 0;
	var $nCR								= 0;
	var $nCorruptionResist					= 0;
	// Tradeskills
	var $nForaging							= 0;
	var $nFishing							= 0;
	var $nSmithing							= 0;
	var $nBaking							= 0;
	var $nTailoring							= 0;
	var $nFletching							= 0;
	var $nBrewing							= 0;
	var $nJewelry							= 0;
	var $nPottery							= 0;
	var $nAlcoholTolerance					= 0;
	var $nAlchemy							= 0;
	var $nTinkering							= 0;
	var $nResearch							= 0;
	var $nPoisonMaking						= 0;
	// Keys
	var $nVexThalKey						= 0;
	var $nSebilisKey						= 0;
	var $nVeeshansPeakKey					= 0;
	var $nHowlingStonesKey					= 0;
	var $nSleepersTombKey					= 0;
	var $nSSRAEmperorKey					= 0;
		// Pop Tier 1 Flags
	var $nAny_PoJ_Trial						= 0;
	var $nAll_PoJ_Trials					= 0;
	var $nPoI_Xanamech						= 0;
	var $nPoI_Behemoth						= 0;
	var $nPoD_Grimror_Quest					= 0;
	var $nPoD_Grummus						= 0;
	var $nPoN_Hedge_Quest					= 0;
	var $nPoNb_Terris_Thule					= 0;
		// Pop Tier 2 Flags
	var $nPoS_Askr_Quest					= 0;
	var $nPoV_Grenic_Quest					= 0;
	var $nPoV_AerinDar						= 0;
	var $nCoD_Bertoxxulous					= 0;
	var $nPoTorment_Saryrn					= 0;
	var $nPoS_Wembly_Quest					= 0;
		// Pop Tier 3 Flags
	var $nHoH_Trial1_RyddaDar				= 0;
	var $nHoH_Trial2_Ogre					= 0;
	var $nHoH_Trial3_Madmen					= 0;
	var $nHoHb_Mithanial_Marr				= 0;
	var $nPoTactics_Tallon_Zek				= 0;
	var $nPoTactics_Vallon_Zek				= 0;
	var $nPoTactics_Rallos_Zek_Quest		= 0;
	var $nBoT_Rescue_Karana_Quest			= 0;
	var $nSolRoTower_Jiva					= 0;
	var $nSolRoTower_Xuzl					= 0;
	var $nSolRoTower_Arlyxir				= 0;
	var $nSolRoTower_Rizlona				= 0;
	var $nSolRoTower_Protector_of_Dresolik	= 0;
	var $nSolRoTower_Solusek_Ro				= 0;
		// Pop Tier 4 Flags
	var $nPoAir_Xegony						= 0;
	var $nPoFire_Fennin_Ro					= 0;
	var $nPoWater_Coirnav					= 0;
	var $nPoEarthb_The_Rathe				= 0;
	var $nPoTime_Time_Phased_Quintessence	= 0;
		// GoD Flags
	var $nPurifying_Plant					= 0;
	var $nEmanating_Furnace					= 0;
	var $nLair_of_Trapped_Ones				= 0;
	var $nPool_of_Sludge					= 0;
	var $nSmith_Rondo						= 0;
	var $nVxed								= 0;
	var $nTipt								= 0;
	var $nVrex_Barxt_Qurat					= 0;
	var $nCynosure_Kvanjji					= 0;
	var $nNoqufiel_in_Inktuta				= 0;
	var $nZunMuram_Tkarish_Zyk				= 0;
		// OoW_CoA Flags/Signets
	var	$nSeal_Mastery_of_All				= 0;
	var $nCrystal_Gemmed_Signet				= 0;
	var $nDiscolored_Signet					= 0;
	var $nDust_Marred_Signet				= 0;
	var $nGlimmering_Signet					= 0;
	var $nTarnished_Signet					= 0;
	var $nTwo_Toned_Signet					= 0;
	var $nWeather_Worn_Signet				= 0;
		// DoN Flags
	var $nDoN_Tier1_Done					= 0;
	var $nDoN_Tier2_Done					= 0;
	var $nDoN_Tier3_Done					= 0;
	var $nDoN_Tier4_Done					= 0;
	var $nDoN_Tier5_Done					= 0;



	// ========================================================================
	// Constructor
	// ========================================================================
	// In:	$strMageloNr	= String containing the Magelo Nr
	// In:	$strCharName	= String containing the Character name
	// In:	$strClass		= String containing the Character class
	// ========================================================================
	function Magelo( $strMageloNr, $strCharName, $strClass )
	{
		// Create the skin
		$this->theSkin	= new Skin();

		// Store the character settings
		$this->strMageloNr							= $strMageloNr;
		$this->strCharName							= $strCharName;
		$this->strClass								= $strClass;
	}


	
	// ========================================================================
	// Retrieve Character info from the magelo profile
	// ========================================================================
	// This function will open the magelo page and store it in memory.
	// It will then perform string manupilations to retrieve the character
	// details out of the magelo, and store them in variables.
	//
	// !!!WARNING!!!
	// DO NOT call this function a lot of times in a row.
	// If you want to retrieve the magelo's for a lot of characters in a row,
	// then make sure you wait 5 to 10 minutes between each call to this
	// function, otherwise your IP will get banned on the magelo site.
	// ========================================================================
	// Out:	Boolean indicating wether the import succeeded or failed
	// ========================================================================
	function Import()
	{
		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve the magelo profile into memory
		///////////////////////////////////////////////////////////////////////////////////
//		$strHost		= "www.magelo.com";
		$strHost		= "eq.magelo.com";
		$strProtocol	= "HTTP/1.0";
//		$strURL			= "/eq_view_profile.html?num=" . $this->strMageloNr;
		$strURL			= "/profile/" . $this->strMageloNr;

		$astrHeaders[]	= new HTTP_Header( "Accept", "text/html, */*" );
		$astrHeaders[]	= new HTTP_Header( "User-Agent", "Mozilla/4.0 (compatible; MSIE 5.01; Windows 98;)" );
		$astrHeaders[]	= new HTTP_Header( "Host", $strHost );
		$astrHeaders[]	= new HTTP_Header( "Referer", "" );

		$strHTTPRequest	= new HTTP_Request( "GET", $strURL, $strProtocol, $astrHeaders );
		$theConnection	= new HTTP_Connection( $strHost );

		$theConnection->Connect();
		$theConnection->Request( $strHTTPRequest );
		$theConnection->Response( $theResponse );
		$theConnection->Close();

		// Retrieve the content
		$strContent		= $theResponse->GetEntityBody();

		// ignore the first 10 characters in the content
		$strContent		= substr( $strContent, 10 );
		// Unpack the content	
		$strContent		= gzinflate( $strContent );

		// Remove all tabs and clusters of 4 spaces in a row
		$strContent	= ereg_replace( "	|    ", "", $strContent );
		// Remove extra space before < tag (Mana/Disease)
		$strContent	= ereg_replace( " <|  <|   <", "<", $strContent );
		$strContent	= ereg_replace( " >|  >|   >", ">", $strContent );
		// Remove all empty lines
		$strContent	= ereg_replace( "\r\n\r\n|\r\n\r\n\r\n|\n\r\n\r|\n\r\n\r\n\r)", "\r\n", $strContent );

		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve Character Info
		///////////////////////////////////////////////////////////////////////////////////
		// Adjust the class tag for ShadowKnights (Magelo uses 1 word, instead of the 2 in the roster)
		$strMageloClass		= $this->strClass;
		if( $strMageloClass == "Shadow Knight" )
		{
			$strMageloClass	= "Shadowknight";
		}

		// Retrieve FirstName, LastName, Level, Race, Class, Server
		if( ereg( '<span id="name">([a-zA-Z]+){0,1}  ([a-zA-Z`\\\'-]+){0,1}</span><br>..<span style="line-height: 12px;">..([0-9]{1,3}) ([a-zA-Z ]+) ([a-zA-Z]+) - ([a-zA-Z ]+)<br>', $strContent, $aMatches ) )
		{
			$this->strFirstName			= $aMatches[1];
			$this->strLastName			= $aMatches[2];
			$this->nLevel				= $aMatches[3];
			$this->strRace				= $aMatches[4];
			$this->strClass				= $aMatches[5];
			$this->strServer			= $aMatches[6];
		}
		// Retrieve FirstName, Level, Race, Class, Server
		else if( ereg( '<span id="name">([a-zA-Z]+){0,1}</span><br>..<span style="line-height: 12px;">..([0-9]{1,3}) ([a-zA-Z ]+) ([a-zA-Z]+) - ([a-zA-Z ]+)<br>', $strContent, $aMatches ) )
		{
			$this->strFirstName			= $aMatches[1];
			$this->nLevel				= $aMatches[2];
			$this->strRace				= $aMatches[3];
			$this->strClass				= $aMatches[4];
			$this->strServer			= $aMatches[5];
		}
		else
		{
			// If this info wasn't found, abort the import
			return false;
		}

		// Retrieve the nr of AA's
		if( ereg( '>AA</td>..<td class="tabCel" style="padding-bottom: 4px;">([0-9]{1,4})</td>', $strContent, $aMatches ) )
		{
			$this->nAA					= $aMatches[1];
		}

		// Retrieve Group Leadership Points
		if( ereg( 'new AbilityGrp\(2,([0-9]{1,4}),([0-9]{1,4}),([0-9]{1,2})\);', $strContent, $aMatches ) )
		{
			$this->nNrOfGLPs			= $aMatches[2] + $aMatches[3];
		}

		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve Character Statistics
		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve the HP
		if( ereg( '>HP</td>..<td class="tabCel">([0-9]{1,5})</td>', $strContent, $aMatches ) )
		{
			$this->nHP					= $aMatches[1];
		}

		// Retrieve the Mana
		if( ereg( '>MANA</td>..<td class="tabCel">([0-9]{1,5})</td>', $strContent, $aMatches ) )
		{
			$this->nMana				= $aMatches[1];
		}

		// Retrieve the Endurance
		if( ereg( '>ENDR</td>..<td class="tabCel">([0-9]{1,5})</td>', $strContent, $aMatches ) )
		{
			$this->nEndurance			= $aMatches[1];
		}

		// Retrieve the AC
		if( ereg( '>AC</td>..<td class="tabCel">([0-9]{1,4})</td>', $strContent, $aMatches ) )
		{
			$this->nAC					= $aMatches[1];
		}

		// Retrieve the Flowing Thought
		if( ereg( '>MANA\+</td>..<td class="tabCel">([0-9]{1,3})</td>', $strContent, $aMatches ) )
		{
			$this->nFT					= $aMatches[1];
		}

		// Retrieve the Regen
		if( ereg( '>HP\+</td>..<td class="tabCel">([0-9]{1,3})</td>', $strContent, $aMatches ) )
		{
			$this->nRegen				= $aMatches[1];
		}

		// Retrieve the Atk
		if( ereg( '>ATK</td>..<td class="tabCel" style="padding-bottom: 4px;">([0-9]{1,4})</td>', $strContent, $aMatches ) )
		{
			$this->nAtk					= $aMatches[1];
		}

		// Retrieve the Str
		if( ereg( '>STR</td>..<td class="tabCel">([0-9]{1,3})</td>', $strContent, $aMatches ) )
		{
			$this->nStr					= $aMatches[1];
		}

		// Retrieve the Sta
		if( ereg( '>STA</td>..<td class="tabCel">([0-9]{1,3})</td>', $strContent, $aMatches ) )
		{
			$this->nSta					= $aMatches[1];
		}

		// Retrieve the Agi
		if( ereg( '>AGI</td>..<td class="tabCel">([0-9]{1,3})</td>', $strContent, $aMatches ) )
		{
			$this->nAgi					= $aMatches[1];
		}

		// Retrieve the Dex
		if( ereg( '>DEX</td>..<td class="tabCel">([0-9]{1,3})</td>', $strContent, $aMatches ) )
		{
			$this->nDex					= $aMatches[1];
		}

		// Retrieve the Wis
		if( ereg( '>WIS</td>..<td class="tabCel">([0-9]{1,3})</td>', $strContent, $aMatches ) )
		{
			$this->nWis					= $aMatches[1];
		}

		// Retrieve the Int
		if( ereg( '>INT</td>..<td class="tabCel">([0-9]{1,3})</td>', $strContent, $aMatches ) )
		{
			$this->nInt					= $aMatches[1];
		}

		// Retrieve the Cha
		if( ereg( '>CHA</td>..<td class="tabCel" style="padding-bottom: 4px;">([0-9]{1,3})</td>', $strContent, $aMatches ) )
		{
			$this->nCha					= $aMatches[1];
		}

		// Retrieve the Poison Resist
		if( ereg( '>Poison</td>..<td class="tabCel">([0-9]{1,3})</td>', $strContent, $aMatches ) )
		{
			$this->nPR					= $aMatches[1];
		}

		// Retrieve the Magic Resist
		if( ereg( '>Magic</td>..<td class="tabCel">([0-9]{1,3})</td>', $strContent, $aMatches ) )
		{
			$this->nMR					= $aMatches[1];
		}

		// Retrieve the Disease Resist
		if( ereg( '>Disease</td>..<td class="tabCel">([0-9]{1,3})</td>', $strContent, $aMatches ) )
		{
			$this->nDR					= $aMatches[1];
		}

		// Retrieve the Fire Resist
		if( ereg( '>Fire</td>..<td class="tabCel">([0-9]{1,3})</td>', $strContent, $aMatches ) )
		{
			$this->nFR					= $aMatches[1];
		}

		// Retrieve the Cold Resist
		if( ereg( '>Cold</td>..<td class="tabCel">([0-9]{1,3})</td>', $strContent, $aMatches ) )
		{
			$this->nCR					= $aMatches[1];
		}

		// Retrieve the Corruption Resist
		if( ereg( '>Corrupt</td>..<td class="tabCel" style="padding-bottom: 4px;">([0-9]{1,3})</td>', $strContent, $aMatches ) )
		{
			$this->nCorruptionResist	= $aMatches[1];
		}


		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve the Skills/Tradeskills
		///////////////////////////////////////////////////////////////////////////////////
		if( ereg( "new Skill\('Alchemy',([0-9]{1,3})\);", $strContent, $aMatches ) )
		{
			$this->nAlchemy				= $aMatches[1];
		}

		if( ereg( "new Skill\('Alcohol Tolerance',([0-9]{1,3})\);", $strContent, $aMatches ) )
		{
			$this->nAlcoholTolerance	= $aMatches[1];
		}

		if( ereg( "new Skill\('Baking',([0-9]{1,3})\);", $strContent, $aMatches ) )
		{
			$this->nBaking				= $aMatches[1];
		}

		if( ereg( "new Skill\('Brewing',([0-9]{1,3})\);", $strContent, $aMatches ) )
		{
			$this->nBrewing				= $aMatches[1];
		}

		if( ereg( "new Skill\('Fishing',([0-9]{1,3})\);", $strContent, $aMatches ) )
		{
			$this->nFishing				= $aMatches[1];
		}

		if( ereg( "new Skill\('Fletching',([0-9]{1,3})\);", $strContent, $aMatches ) )
		{
			$this->nFletching			= $aMatches[1];
		}

		if( ereg( "new Skill\('Forage',([0-9]{1,3})\);", $strContent, $aMatches ) )
		{
			$this->nForaging			= $aMatches[1];
		}

		if( ereg( "new Skill\('Jewellery',([0-9]{1,3})\);", $strContent, $aMatches ) )
		{
			$this->nJewelry				= $aMatches[1];
		}

		if( ereg( "new Skill\('Make Poison',([0-9]{1,3})\);", $strContent, $aMatches ) )
		{
			$this->nPoisonMaking		= $aMatches[1];
		}

		if( ereg( "new Skill\('Pottery',([0-9]{1,3})\);", $strContent, $aMatches ) )
		{
			$this->nPottery				= $aMatches[1];
		}

		if( ereg( "new Skill\('Research',([0-9]{1,3})\);", $strContent, $aMatches ) )
		{
			$this->nResearch			= $aMatches[1];
		}

		if( ereg( "new Skill\('Blacksmithing',([0-9]{1,3})\);", $strContent, $aMatches ) )
		{
			$this->nSmithing			= $aMatches[1];
		}

		if( ereg( "new Skill\('Tailoring',([0-9]{1,3})\);", $strContent, $aMatches ) )
		{
			$this->nTailoring			= $aMatches[1];
		}

		if( ereg( "new Skill\('Tinkering',([0-9]{1,3})\);", $strContent, $aMatches ) )
		{
			$this->nTinkering			= $aMatches[1];
		}

		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve Keys
		///////////////////////////////////////////////////////////////////////////////////
		if( ereg( "new Key\('The Howling Stones'\);", $strContent ) )
		{
			$this->nHowlingStonesKey	= 1;
		}

		if( ereg( "new Key\('Sebilis'\);", $strContent ) )
		{
			$this->nSebilisKey			= 1;
		}

		if( ereg( "new Key\('Sleeper\\\'s Tomb'\);", $strContent ) )
		{
			$this->nSleepersTombKey		= 1;
		}

		if( ereg( "new Key\('SSRA Emperor Area'\);", $strContent ) )
		{
			$this->nSSRAEmperorKey		= 1;
		}

		if( ereg( "new Key\('Veeshan\\\'s Peak'\);", $strContent ) )
		{
			$this->nVeeshansPeakKey		= 1;
		}

		if( ereg( "new Key\('Vex Thal'\);", $strContent ) )
		{
			$this->nVexThalKey			= 1;
		}

		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve PoP Tier 1 Flags
		///////////////////////////////////////////////////////////////////////////////////
		if( ereg( "new Flag\('Full PoV/PoS access'\);", $strContent, $aMatches ) )
		{
		   $this->nAny_PoJ_Trial						= 1;
		}
		
		if( ereg( "new Flag\('PoJ Seventh Hammer'\);", $strContent, $aMatches ) )
		{
		   $this->nAll_PoJ_Trials						= 1;
		}

		if( ereg( "new Flag\('PoI Factory'\);", $strContent, $aMatches ) )
		{
			$this->nPoI_Xanamech						= 1;
		}

		if( ereg( "new Flag\('Plane of Tactics'\);", $strContent, $aMatches ) )
		{
		   $this->nPoI_Behemoth							= 1;
		}

		if( ereg( "new Flag\('Crypt of Decay for exp only'\);", $strContent, $aMatches ) )
		{
		    $this->nPoD_Grimror_Quest					= 1;
		}

		if( ereg( "new Flag\('Crypt of Decay'\);", $strContent, $aMatches ) )
		{
		    $this->nPoD_Grummus							= 1;
		}
		
		if( ereg( "new Flag\('Crypt of Terris Thule'\);", $strContent, $aMatches ) )
		{
		    $this->nPoN_Hedge_Quest						= 1;
		}
		
		if( ereg( "new Flag\('Plane of Torment'\);", $strContent, $aMatches ) )
		{
		    $this->nPoNb_Terris_Thule					= 1;
		}

		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve PoP Tier 2 Flags
		///////////////////////////////////////////////////////////////////////////////////
		if( ereg( "new Flag\('Torden, Bastion of Thunder'\);", $strContent, $aMatches ) )
		{
		    $this->nPoS_Askr_Quest						= 1;
		}

		if( ereg( "new Flag\('Halls of Honor for exp only'\);", $strContent, $aMatches ) )
		{
		    $this->nPoV_Grenic_Quest					= 1;
		}

		if( ereg( "new Flag\('Halls of Honor'\);", $strContent, $aMatches ) )
		{
		    $this->nPoV_AerinDar						= 1;
		}

		if( ereg( "new Flag\('Plane of Torment and Saryrn'\);", $strContent, $aMatches ) )
		{
			$this->nCoD_Bertoxxulous					= 1;
		}

// TODO: Remove this check?
		if( ereg( '\[DONE\] Killed PoTorment Saryrn', $strContent, $aMatches ) )
		{
		    $this->nPoTorment_Saryrn					= 1;
		}

		if( ereg( "new Flag\('Plane of Tactics for exp only'\);", $strContent, $aMatches ) )
		{
		    $this->nnPoS_Wembly_Quest					= 1;
		}
		
		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve PoP Tier 3 Flags
		///////////////////////////////////////////////////////////////////////////////////
		if( ereg( "new Flag\('HoHb, Temple of Marr'\);", $strContent, $aMatches ) )
		{
		    $this->nHoH_Trial1_RyddaDar					= 1;
		    $this->nHoH_Trial2_Ogre						= 1;
		    $this->nHoH_Trial3_Madmen					= 1;
		}

		if( ereg( "new Flag\('To get past Rallos Zek'\);", $strContent, $aMatches ) )
		{
		    $this->nPoTorment_Saryrn					= 1;
		    $this->nHoHb_Mithanial_Marr					= 1;
		    $this->nPoTactics_Tallon_Zek				= 1;
		    $this->nPoTactics_Vallon_Zek				= 1;
		}

		if( ereg( "new Flag\('PoEarth/PoAir/PoWater'\);", $strContent, $aMatches ) )
		{
			// Rallos Zek and Agnarr completed
		    $this->nBoT_Rescue_Karana_Quest				= 1;
		    // TODO: Not sure if this one is correct
//		    $this->nPoTactics_Rallos_Zek_Quest			= 1;
		}

		if( ereg( "new Flag\('Solusek Ro'\);", $strContent, $aMatches ) )
		{
		    $this->nPoTactics_Rallos_Zek_Quest			= 1;
		    $this->nBoT_Rescue_Karana_Quest				= 1;
		    $this->nSolRoTower_Jiva						= 1;
		    $this->nSolRoTower_Xuzl						= 1;
		    $this->nSolRoTower_Arlyxir					= 1;
		    $this->nSolRoTower_Rizlona					= 1;
		    $this->nSolRoTower_Protector_of_Dresolik	= 1;
		}

		if( ereg( "new Flag\('Plane of Fire'\);", $strContent, $aMatches ) )
		{
		    $this->nSolRoTower_Solusek_Ro				= 1;
		}

		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve PoP Tier 4 Flags
		///////////////////////////////////////////////////////////////////////////////////
		if( ereg( 'Time Phased Quintessence', $strContent, $aMatches ) )
		{
		    $this->nPoTime_Time_Phased_Quintessence		= 1;
		}
		else if( ereg( "new Flag\('Plane of Time'\);", $strContent, $aMatches ) )
		{
		    $this->nPoAir_Xegony						= 1;
		    $this->nPoEarthb_The_Rathe					= 1;
		    $this->nPoFire_Fennin_Ro					= 1;
		    $this->nPoWater_Coirnav						= 1;
		}

		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve GoD Flags
		///////////////////////////////////////////////////////////////////////////////////
		if( ereg( "new Flag\('Kod`Taz,Ikkinz,Yxtta'\);", $strContent, $aMatches ) )
		{
			// Vxed and Tipt must have been done, so enable them
		    $this->nVxed								= 1;
		    $this->nTipt								= 1;
		}

		if( ereg( "new Flag\('Qvic'\);", $strContent, $aMatches ) )
		{
		    $this->nVrex_Barxt_Qurat					= 1;
		}

		if( ereg( "new Flag\('Inktu\\\'ta'\);", $strContent, $aMatches ) )
		{
		    $this->nCynosure_Kvanjji					= 1;
		}

		if( ereg( "new Flag\('Txevu'\);", $strContent, $aMatches ) )
		{
		    $this->nNoqufiel_in_Inktuta					= 1;
		}

		if( ereg( "new Flag\('Tacvi'\);", $strContent, $aMatches ) )
		{
		    $this->nZunMuram_Tkarish_Zyk				= 1;
		}

		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve OoW Flags/Signets
		///////////////////////////////////////////////////////////////////////////////////
		if( ( ereg( 'Seal: Mastery of All', $strContent, $aMatches ) ) ||
			( ereg( "new Key\('Anguish, the Fallen Palace'\);", $strContent, $aMatches ) ) )
		{
		    $this->nSeal_Mastery_of_All					= 1;
		}
		
		if( ereg( 'Crystal-Gemmed Signet', $strContent, $aMatches ) )
		{
			$this->nCrystal_Gemmed_Signet				= 1;
		}
		if( ereg( 'Discolored Signet', $strContent, $aMatches ) )
		{
			$this->nDiscolored_Signet					= 1;
		}
		if( ereg( 'Dust-Marred Signet', $strContent, $aMatches ) )
		{
			$this->nDust_Marred_Signet					= 1;
		}
		if( ereg( 'Glimmering Signet', $strContent, $aMatches ) )
		{
			$this->nGlimmering_Signet					= 1;
		}
		if( ereg( 'Tarnished Signet', $strContent, $aMatches ) )
		{
			$this->nTarnished_Signet					= 1;
		}
		if( ereg( 'Two-Toned Signet', $strContent, $aMatches ) )
		{
			$this->nTwo_Toned_Signet					= 1;
		}
		if( ereg( 'Weather-Worn Signet', $strContent, $aMatches ) )
		{
			$this->nWeather_Worn_Signet					= 1;
		}

		///////////////////////////////////////////////////////////////////////////////////
		// Retrieve DoN Flags
		///////////////////////////////////////////////////////////////////////////////////
		if( ereg( 'Gift of the Keepers', $strContent, $aMatches ) ||
			ereg( 'Gift of the Dark Reign', $strContent, $aMatches ) )
		{
		    $this->nDoN_Tier1_Done						= 1;
		}
		if( ereg( 'Valor of the Keepers', $strContent, $aMatches ) ||
			ereg( 'Tenacity of the Dark Reign', $strContent, $aMatches ) )
		{
		    $this->nDoN_Tier2_Done						= 1;
		}

		if( ereg( 'Embrace of the Keepers', $strContent, $aMatches ) ||
			ereg( 'Embrace of the Dark Reign', $strContent, $aMatches ) )
		{
		    $this->nDoN_Tier3_Done						= 1;
		}

		if( ereg( 'Power of the Keepers', $strContent, $aMatches ) ||
			ereg( 'Power of the Dark Reign', $strContent, $aMatches ) )
		{
		    $this->nDoN_Tier4_Done						= 1;
		}

		if( ereg( 'Sanctity of the Keepers', $strContent, $aMatches ) ||
			ereg( 'Fervor of the Dark Reign', $strContent, $aMatches ) )
		{
		    $this->nDoN_Tier5_Done						= 1;
		}

		// Import completed succesfully
		return true;
	}



	// ========================================================================
	// Show the magelo info on screen (debug function)
	// ========================================================================
	// This function is only here for debug purposes.
	// If you really want to output the data to screen, 
	// you should create you're own layout and rewrite this function
	// ========================================================================
	function Show()
	{
		// Print the results
		print( "MageloNr			= [" . $this->strMageloNr . "]							<br \>\n" );
		print( "CharName			= [" . $this->strCharName . "]							<br \>\n" );
		print( "LastName			= [" . $this->strLastName . "]							<br \>\n" );
		print( "<hr \>\n" );
		print( "Class				= [" . $this->strClass . "]								<br \>\n" );
		print( "Deity				= [" . $this->strDeity . "]								<br \>\n" );
		print( "Race				= [" . $this->strRace . "]								<br \>\n" );
		print( "Level				= [" . $this->nLevel . "]								<br \>\n" );
		print( "AA					= [" . $this->nAA . "]									<br \>\n" );
		print( "NrOfGLPs			= [" . $this->nNrOfGLPs . "]							<br \>\n" );
		print( "<hr \>\n" );
		print( "HP					= [" . $this->nHP . "]									<br \>\n" );
		print( "Mana				= [" . $this->nMana . "]								<br \>\n" );
		print( "Endurance			= [" . $this->nEndurance . "]							<br \>\n" );
		print( "AC					= [" . $this->nAC . "]									<br \>\n" );
		print( "FT					= [" . $this->nFT . "]									<br \>\n" );
		print( "Regen				= [" . $this->nRegen . "]								<br \>\n" );
		print( "Atk					= [" . $this->nAtk . "]									<br \>\n" );
		print( "Str					= [" . $this->nStr . "]									<br \>\n" );
		print( "Sta					= [" . $this->nSta . "]									<br \>\n" );
		print( "Agi					= [" . $this->nAgi . "]									<br \>\n" );
		print( "Dex					= [" . $this->nDex . "]									<br \>\n" );
		print( "Wis					= [" . $this->nWis . "]									<br \>\n" );
		print( "Int					= [" . $this->nInt . "]									<br \>\n" );
		print( "Cha					= [" . $this->nCha . "]									<br \>\n" );
		print( "Poison Resist		= [" . $this->nPR . "]									<br \>\n" );
		print( "Magic Resist		= [" . $this->nMR . "]									<br \>\n" );
		print( "Disease Resist		= [" . $this->nDR . "]									<br \>\n" );
		print( "Fire Resist			= [" . $this->nFR . "]									<br \>\n" );
		print( "Cold Resist			= [" . $this->nCR . "]									<br \>\n" );
		print( "Corruption Resist	= [" . $this->nCorruptionResist . "]					<br \>\n" );
		print( "<hr \>\n" );
		print( "Alchemy				= [" . $this->nAlchemy . "]								<br \>\n" );
		print( "AlcoholToler.		= [" . $this->nAlcoholTolerance . "]					<br \>\n" );
		print( "Baking				= [" . $this->nBaking . "]								<br \>\n" );
		print( "Brewing				= [" . $this->nBrewing . "]								<br \>\n" );
		print( "Fishing				= [" . $this->nFishing . "]								<br \>\n" );
		print( "Fletching			= [" . $this->nFletching . "]							<br \>\n" );
		print( "Foraging			= [" . $this->nForaging . "]							<br \>\n" );
		print( "Jewelry				= [" . $this->nJewelry . "]								<br \>\n" );
		print( "PoisonMaking		= [" . $this->nPoisonMaking . "]						<br \>\n" );
		print( "Pottery				= [" . $this->nPottery . "]								<br \>\n" );
		print( "Smithing			= [" . $this->nSmithing . "]							<br \>\n" );
		print( "Tailoring			= [" . $this->nTailoring . "]							<br \>\n" );
		print( "Tinkering			= [" . $this->nTinkering . "]							<br \>\n" );
		print( "Research			= [" . $this->nResearch . "]							<br \>\n" );
		print( "<hr \>\n" );
		print( "HowlingStonesKey	= [" . $this->nHowlingStonesKey . "]					<br \>\n" );
		print( "SebilisKey			= [" . $this->nSebilisKey . "]							<br \>\n" );
		print( "SleepersTombKey		= [" . $this->nSleepersTombKey . "]						<br \>\n" );
		print( "SSRAEmperorKey		= [" . $this->nSSRAEmperorKey . "]						<br \>\n" );
		print( "VeeshansPeakKey		= [" . $this->nVeeshansPeakKey . "]						<br \>\n" );
		print( "VexThalKey			= [" . $this->nVexThalKey . "]							<br \>\n" );
		print( "<hr \>\n" );
		// Pop Tier 1 Flags
		print( "Any_PoJ_Trial		= [" . $this->nAny_PoJ_Trial . "]						<br \>\n" );
		print( "All_PoJ_Trials		= [" . $this->nAll_PoJ_Trials . "]						<br \>\n" );
		print( "PoI_Xanamech		= [" . $this->nPoI_Xanamech . "]						<br \>\n" );
		print( "PoI_Behemoth		= [" . $this->nPoI_Behemoth . "]						<br \>\n" );
		print( "PoD_Grimror_Quest	= [" . $this->nPoD_Grimror_Quest . "]					<br \>\n" );
		print( "PoD_Grummus			= [" . $this->nPoD_Grummus . "]							<br \>\n" );
		print( "PoN_Hedge_Quest		= [" . $this->nPoN_Hedge_Quest . "]						<br \>\n" );
		print( "PoNb_Terris_Thule	= [" . $this->nPoNb_Terris_Thule . "]					<br \>\n" );
		print( "<hr \>\n" );
		// Pop Tier 2 Flags
		print( "PoS_Askr_Quest		= [" . $this->nPoS_Askr_Quest . "]						<br \>\n" );
		print( "PoV_Grenic_Quest	= [" . $this->nPoV_Grenic_Quest . "]					<br \>\n" );
		print( "PoV_AerinDar		= [" . $this->nPoV_AerinDar . "]						<br \>\n" );
		print( "CoD_Bertoxxulous	= [" . $this->nCoD_Bertoxxulous . "]					<br \>\n" );
		print( "PoTorment_Saryrn	= [" . $this->nPoTorment_Saryrn . "]					<br \>\n" );
		print( "PoS_Wembly_Quest	= [" . $this->nPoS_Wembly_Quest . "]					<br \>\n" );
		print( "<hr \>\n" );
		// Pop Tier 3 Flags
		print( "HoH_Trial1_RyddaDar	= [" . $this->nHoH_Trial1_RyddaDar . "]					<br \>\n" );
		print( "HoH_Trial2_Ogre		= [" . $this->nHoH_Trial2_Ogre . "]						<br \>\n" );
		print( "HoH_Trial3_Madmen	= [" . $this->nHoH_Trial3_Madmen . "]					<br \>\n" );
		print( "HoHb_Mithanial_Marr	= [" . $this->nHoHb_Mithanial_Marr . "]					<br \>\n" );
		print( "PoTactics_Tallon_Z	= [" . $this->nPoTactics_Tallon_Zek . "]				<br \>\n" );
		print( "PoTactics_Vallon_Z	= [" . $this->nPoTactics_Vallon_Zek . "]				<br \>\n" );
		print( "PoTactics_Rallos_Z	= [" . $this->nPoTactics_Rallos_Zek_Quest . "]			<br \>\n" );
		print( "BoT_Rescue_Karana	= [" . $this->nBoT_Rescue_Karana_Quest . "]				<br \>\n" );
		print( "SolRoTower_Jiva		= [" . $this->nSolRoTower_Jiva . "]						<br \>\n" );
		print( "SolRoTower_Xuzl		= [" . $this->nSolRoTower_Xuzl . "]						<br \>\n" );
		print( "SolRoTower_Arlyxir	= [" . $this->nSolRoTower_Arlyxir . "]					<br \>\n" );
		print( "SolRoTower_Rizlona	= [" . $this->nSolRoTower_Rizlona . "]					<br \>\n" );
		print( "SolRoTower_Prot.D.	= [" . $this->nSolRoTower_Protector_of_Dresolik . "]	<br \>\n" );
		print( "SolRoTower_Solus.Ro	= [" . $this->nSolRoTower_Solusek_Ro . "]				<br \>\n" );
		print( "<hr \>\n" );
		// Pop Tier 4 Flags
		print( "PoAir_Xegony		= [" . $this->nPoAir_Xegony . "]						<br \>\n" );
		print( "PoFire_Fennin_Ro	= [" . $this->nPoFire_Fennin_Ro . "]					<br \>\n" );
		print( "PoWater_Coirnav		= [" . $this->nPoWater_Coirnav . "]						<br \>\n" );
		print( "PoEarthb_The_Rathe	= [" . $this->nPoEarthb_The_Rathe . "]					<br \>\n" );
		print( "Time_Time_Phased_Q.	= [" . $this->nPoTime_Time_Phased_Quintessence . "]		<br \>\n" );
		print( "<hr \>\n" );
		// GoD Flags
		print( "Purifying_Plant		= [" . $this->nPurifying_Plant . "]						<br \>\n" );
		print( "Emanating_Furnace	= [" . $this->nEmanating_Furnace . "]					<br \>\n" );
		print( "Lair_Trapped_Ones	= [" . $this->nLair_of_Trapped_Ones . "]				<br \>\n" );
		print( "Pool_of_Sludge		= [" . $this->nPool_of_Sludge . "]						<br \>\n" );
		print( "Smith_Rondo			= [" . $this->nSmith_Rondo . "]							<br \>\n" );
		print( "Vxed				= [" . $this->nVxed . "]								<br \>\n" );
		print( "Tipt				= [" . $this->nTipt . "]								<br \>\n" );
		print( "Vrex_Barxt_Qurat	= [" . $this->nVrex_Barxt_Qurat . "]					<br \>\n" );
		print( "Cynosure_Kvanjji	= [" . $this->nCynosure_Kvanjji . "]					<br \>\n" );
		print( "Noqufiel_in_Inktuta	= [" . $this->nNoqufiel_in_Inktuta . "]					<br \>\n" );
		print( "ZunMuram_Tkarish_Z.	= [" . $this->nZunMuram_Tkarish_Zyk . "]				<br \>\n" );
		print( "<hr \>\n" );
		// OoW Flags/Signets
		print( "Seal_Mastery_of_All	= [" . $this->nSeal_Mastery_of_All . "]					<br \>\n" );
		print( "Crystal_Gemmed_Sign = [" . $this->nCrystal_Gemmed_Signet . "]				<br \>\n" );
		print( "Discolored_Signet	= [" . $this->nDiscolored_Signet . "]					<br \>\n" );
		print( "Dust_Marred_Signet	= [" . $this->nDust_Marred_Signet . "]					<br \>\n" );
		print( "Glimmering_Signet	= [" . $this->nGlimmering_Signet . "]					<br \>\n" );
		print( "Tarnished_Signet	= [" . $this->nTarnished_Signet . "]					<br \>\n" );
		print( "Two_Toned_Signet	= [" . $this->nTwo_Toned_Signet . "]					<br \>\n" );
		print( "Weather_Worn_Signet	= [" . $this->nWeather_Worn_Signet . "]					<br \>\n" );
		print( "<hr \>\n" );
		// DoN Flags
		print( "DoN_Tier1_Done		= [" . $this->nDoN_Tier1_Done . "]						<br \>\n" );
		print( "DoN_Tier2_Done		= [" . $this->nDoN_Tier2_Done . "]						<br \>\n" );
		print( "DoN_Tier3_Done		= [" . $this->nDoN_Tier3_Done . "]						<br \>\n" );
		print( "DoN_Tier4_Done		= [" . $this->nDoN_Tier4_Done . "]						<br \>\n" );
		print( "DoN_Tier5_Done		= [" . $this->nDoN_Tier5_Done . "]						<br \>\n" );
		print( "<hr \>\n" );
	}
}

?>
