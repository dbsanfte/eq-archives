<?php
// Includes
require_once( './config.php' );
require_once( './includes/class.character.inc' );
require_once( './includes/class.eqplayers.inc' );
require_once( './includes/functions.inc' );
require_once( GetSkinDir() . 'class.skin.inc' );


// ============================================================================
// The Users class
// ============================================================================
// This class handles the EQPlayers_Batch_Import procedure
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class EQPlayers_Batch_Import
{
	// Member variables
	var $theSkin;
	var	$nNrOfImportChars			= 0;		// Nr of characters to import
	var $bDoNotLowerStats			= false;	// bool indicating that stats should only be raised (in case of bad profiles)
	var	$nNrOfImportedProfiles		= 0;		// Nr of succesfully imported characters
	var	$nNrOfAnonymousProfiles		= 0;		// Nr of characters that are anonymous on EQPlayers
	var	$nNrOfNeverUpdatedProfiles	= 0;		// Nr of characters that have never been updated on EQPlayers
	// String used to flush the page to the client
	var $strFlusher					= '                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ';
	// EQPlayers object
	var $theEQPlayers				= NULL;

	// ========================================================================
	// Constructor
	// ========================================================================
	function EQPlayers_Batch_Import()
	{
		// Create the skin
		$this->theSkin	= new Skin();
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "EQPlayers Batch Import";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<font size="-3"><br /></font>
		<center><b><font size="+2" color="' . $this->theSkin->strBatchImportFontColor . '">
		  Import multiple EQPlayers character profiles...
		</font></b></center>
		<!-- End of Header -->
		';
	}
	
	
	
	// ========================================================================
	// Show the body
	// ========================================================================
	// This function will show the EQPlayers Batch Import page
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS	= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName	= $_GET['UserName'];
		$strPassword	= $_GET['Password'];
		$strClassFilter	= $_GET['ClassFilter'];
		$bPerformImport	= $_GET['cbPerformImport'];
		$aCharacters[0]	= "";

		// Check if the UserName is an admin
		if( ( isset( $strUserName ) ) &&
			( $strUserName != "" ) )
		{
			// Check if the user clicked Import
			if( ( isset( $bPerformImport ) ) &&
				( $bPerformImport == "true" ) )
			{
				// Loop through the array with VARS to find the check boxes
				if( !empty($aHTTP_GET_VARS) )
				{
					foreach( $aHTTP_GET_VARS as $strVarName => $strValue )
					{
						// Check if it's an import checkbox
						if( substr( $strVarName, 0, 3 ) == "cb_" )
						{
							// Check if the checkbox was clicked
							if( $strValue == true )
							{
								// Import this char
								$aCharacters[$this->nNrOfImportChars]	= substr( $strVarName, 3 );
	
								// Raise the nr of imported chars
								$this->nNrOfImportChars++;
							}
						}
					}
	
					// Check if any chars where imported
					if( $this->nNrOfImportChars > 0 )
					{
						// Import the character
						$this->ImportEQPlayersProfiles( $strUserName, $strPassword, $strClassFilter, $aCharacters );
					}
					else
					{
						// Show a message telling the user to select some chars first
						echo'
						<center>Select some characters before pressing Import.</center><br />
						';
	
						// Show the import EQPlayers Profiles page
						$this->ShowImportEQPlayersProfilesPage( $strUserName, $strPassword, $strClassFilter, $bPerformImport );
					}
				}
				else
				{
					print( "<font color='" . $this->theSkin->strErrorColor . "'>Error: Empty HTTP_GET_VARS array!</font>" );
				}
			}
			else
			{
				// Show the import EQPlayers profiles page
				$this->ShowImportEQPlayersProfilesPage( $strUserName, $strPassword, $strClassFilter, $bPerformImport );
			}
		}
		else
		{
			// Show error
			print( "<font color='" . $this->theSkin->strErrorColor . "'>Unkown user...</font>" );
		}
	}
	
	
	
	// ========================================================================
	// Import EQPlayers character profiles
	// ========================================================================
	function ImportEQPlayersProfiles( $strUserName, $strPassword, $strClassFilter, $aCharacters )
	{
		// Declare variables
		$strRowType					= "EvenRow";

		// Set the execution time limit off
		@set_time_limit( 0 );

		// Start the form
		echo '
		<form name="formImportEQPlayersProfiles" method="post" action="form.php?FormName=Characters&UserName=' . $strUserName . '&Password=' . $strPassword . '&ClassFilter=' . $strClassFilter . '&CookieAction=READ" target=Body>
		  <div id="Body" align="center">
		    <br />
		';

		// Show the loading image
		ShowLoadingImage();

		// Create the header table
		echo '
			<table id="RosterTable" width="60%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="25%" class="HeaderRow">Name<br /><hr /></td>
				<td width="25%" class="HeaderRow" align="center">CharID<br /><hr /></td>
				<td width="50%" class="HeaderRow">Status<br /><hr /></td>
			  </tr>
			</table>
		';		

		// Flush the PHP page
		print( $this->strFlusher );
		print( $this->strFlusher );
		print( $this->strFlusher );
		print( $this->strFlusher );
		print( $this->strFlusher );
		flush();
		sleep(1);

		// Create the EQPlayers object
		$this->theEQPlayers	= new EQPlayers( GetEQPlayersGuildID() );

		// Loop through the array with VARS to find the check boxes
		foreach( $aCharacters as $nCharID )
		{
			// Import this character's EQPlayers profile
			$this->ImportEQPlayersProfile( $nCharID, $strRowType );

			// Switch RowType, so the rows alternate	
			if( $strRowType == "OddRow" )
			{
				$strRowType	= "EvenRow";
			}
			else
			{
				$strRowType	= "OddRow";
			}
		}

		// Close the form
		echo '
			<table id="RosterTable" width="60%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="25%"><hr /></td>
				<td width="25%"><hr /></td>
				<td width="50%"><hr /></td>
			  </tr>
			</table>

			<br />
			<font color="' . $this->theSkin->strBatchImportFontColor . '">' . $this->nNrOfImportedProfiles . ' profile(s) imported.</font><br />
			<font color="' . $this->theSkin->strWarningColor . '">' . $this->nNrOfAnonymousProfiles . ' anonymous profile(s).</font><br />
			<font color="' . $this->theSkin->strWarningColor . '">' . $this->nNrOfNeverUpdatedProfiles . ' never updated profile(s).</font><br />
			<font color="' . $this->theSkin->strErrorColor . '">' . (count( $aCharacters ) - $this->nNrOfImportedProfiles - $this->nNrOfAnonymousProfiles - $this->nNrOfNeverUpdatedProfiles) . ' Error(s) encountered.</font><br />
			<br />
		    <input type="submit" name="pbDone" value="Done">
		  </div>
		';

		// Hide the loading image
		HideLoadingImage();

		// Close the form
		echo '
		</form>
		';
	}



	// ========================================================================
	// Import a characters EQPlayers profile
	// ========================================================================
	function ImportEQPlayersProfile( $nCharID, $strRowType )
	{
		// Declare variables
		$theCharacter		= new Character();
		$nDelay				= 1;
		$bSucces			= false;
		$nNrOfRecords		= 0;

		// Start a new table
		echo'
			<table id="RosterTable" width="60%" border="0" cellpadding="0" cellspacing="0">
			  <tr	onMouseOver="this.bgColor=\'' . $this->theSkin->strRowHighlightColor . '\'" onMouseOut="this.bgColor=\'\'">
				';

		// Set the character's CharID
		$theCharacter->nCharID	= $nCharID;
		// Retrieve the character's data
		$bSucces	= $theCharacter->GetCharacterData();
	    if( $bSucces )
		{
			// Import the EQPlayers profile
			$bImportOK	= $theCharacter->ImportEQPlayersProfile( $this->theEQPlayers );

			// Store the EQPlayersCharID in the table cell
			echo '<td width="25%" class="' . $strRowType . '">' . $theCharacter->strCharName . '</td>
				<td width="25%" class="' . $strRowType . '" align="center">' . $theCharacter->nEQPlayersCharID . '</td>
				';

			// Did the Import succeed?
			if( $bImportOK )
			{
				// Update the Character
				$theCharacter->UpdateCharacterData();

				// Import/Update succesfull
				$bSucces	= true;

				// Check if the EQPlayers profile is anonymous
				if( $this->theEQPlayers->bAnonymous )
				{
					// Raise the Nr of anonymous profiles
					$this->nNrOfAnonymousProfiles++;
					// Fill the status cell in the table
					echo '<td width="50%"><font color="' . $this->theSkin->strWarningColor . '">Anonymous profile...</font></td>';
				}
				else if( $this->theEQPlayers->HasCharacterBeenUpdated() == false )
				{
					// Raise the Nr of profiles that have never been updated
					$this->nNrOfNeverUpdatedProfiles++;
					// Fill the status cell in the table
					echo '<td width="50%"><font color="' . $this->theSkin->strWarningColor . '">Never updated profile...</font></td>';
				}
				else
				{
					// Raise the Nr of successfully imported profiles
					$this->nNrOfImportedProfiles++;
					// Fill the status cell in the table
					echo '<td width="50%"><font color="' . $this->theSkin->strBatchImportFontColor . '">Profile imported...</font></td>';
				}
			}
			else
			{
				// Import failed
				$bSucces	= false;

				// Couldn't import profile
				echo '<td width="50%"><font color="' . $this->theSkin->strErrorColor . '">Failed to import profile!</font></td>';
			}
			
			// Set the Sleep delay to 2 minutes (120 seconds)
			$nDelay	= 0;	// DO NOT REMOVE THIS LINE OR LOWER THE NR, OR SONY MIGHT BAN YOUR IP!!!!!
		}
		else
		{
			// Couldn't find the character record
			echo '<td width="25%" class="' . $strRowType . '">' . $nCharID . '</td>
					<td width="25%" align="center"><font color="' . $this->theSkin->strErrorColor . '">Unkown</font></td>
					<td width="50%"><font color="' . $this->theSkin->strErrorColor . '">Database query failed!</font></td>';
		}

		// End the table
		echo '
			  </tr>
			</table>
			';

	
		// Flush the PHP page
		print( $this->strFlusher );
		print( $this->strFlusher );
		print( $this->strFlusher );
		print( $this->strFlusher );
		print( $this->strFlusher );
		flush();
		// Only sleep if more then 3 profiles are being imported
		if( $this->nNrOfImportChars > 3 )
		{
			sleep( $nDelay );
		}

		return $bSucces;
	}



	// ========================================================================
	// Show the EQPlayers profiles Import page
	// ========================================================================
	function ShowImportEQPlayersProfilesPage( $strUserName, $strPassword, $strClassFilter, $bPerformImport )
	{
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT CharID, CharName, LastName, EQPlayersCharID \n" .
							  " FROM Characters \n" .
							  " WHERE OldMember = 0 \n";
		$nNrOfCharacters	= 0;

		// Users can only edit their own characters
		if( !IsAdministrator( $strUserName ) )
		{
			$strSelectQuery	.= "   AND NameMain = '" . $strUserName . "' \n";
		}
		else
		{
			// Check if we should set a class filter (only for Admins)
			if( ( isset( $strClassFilter ) ) &&
				( $strClassFilter != "" ) &&
				( $strClassFilter != "<<All>>" ) )
			{
				$strSelectQuery	.= "   AND Class = '" . $strClassFilter . "' \n";
			}
		}
		
		// Add sort order
		$strSelectQuery		.= " ORDER BY CharName ";

		echo '
		<!-- JavaScript block has been added here instead of in the header on purpose -->
		<script language="JavaScript">

		<!-- Perform the Import -->
		function PerformImport()
		{
			// Declare variables
			var aControls		= document.getElementsByTagName( "input" )
			var nNrOfCharacters	= 0;

			// Loop through each checkbox in the array
			for( var nControl = 0; nControl < aControls.length; nControl++ )
			{
				// Check if it is a checkbox
				if( ( aControls[nControl].type == "checkbox" ) &&
					( aControls[nControl].checked == true ) )
				{
					nNrOfCharacters++;
				}
			}

			// Check if any characters are marked for import
			if( nNrOfCharacters > 0 )
			{
				// Validation complete, all fields are valid
				document.formImportEQPlayersProfiles.cbPerformImport.value		= true;
				document.formImportEQPlayersProfiles.cbPerformImport.checked	= true;

				// submit the form				
				document.formImportEQPlayersProfiles.submit();
			}
			else
			{
				// Show warning
				alert( "You must select some characters first..." );
			}
		};


		// Toggle the value of a checkbox when it is clicked
		function ClickCheckBox( cbClicked )
		{
			// Validation complete, all fields are valid
			cbClicked.value	= cbClicked.checked;
		};


		// Set all checkboxes ON (bChecked = true) or OFF (bChecked = false)
		function SetAllCheckBoxes( bChecked )
		{
			// Declare variables
			var aControls		= document.getElementsByTagName( "input" )
			var objControl		= null;
			var strControlName	= "";

			// Loop through each checkbox in the array
			for( var nControl = 0; nControl < aControls.length; nControl++ )
			{
				// Check if it is a checkbox
				if( ( aControls[nControl].type == "checkbox" ) &&
					( ((aControls[nControl].name).match( "cb_" )).length > 0 ) )
				{
					// turn the checkbox on
					aControls[nControl].value	= bChecked;
					aControls[nControl].checked	= bChecked;
				}
			}
		};
		
		</script>


		<form name="formImportEQPlayersProfiles" method="post" action="form.php?FormName=EQPlayers_Batch_Import&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&PreviousForm=' . $strPreviousForm . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&ClassFilter=' . $strClassFilter . '" target=Body>
		  <br />
		  <div id="Body" align="center"> 
		';

		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
			<table id="RosterTable" width="38%" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width= "5%"></td>
				<td width="25%">Name</td>
				<td width= "8%" align="center">CharID</td>
			  </tr>
			  <tr>
				<td width= "5%"><hr /></td>
				<td width="25%"><hr /></td>
				<td width= "8%"><hr /></td>
			  </tr>
		';

		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex				= 0;
			$nCharID			= $aResult[$nIndex++];
			$strCharName		= $aResult[$nIndex++];
			$strLastName		= $aResult[$nIndex++];
			$nEQPlayersCharID	= $aResult[$nIndex++];
			$strCheckBoxValue	= '"false"';

			// Check if the last name is filled
			$strFullName	= $strCharName;
			if( isset( $strLastName ) )
			{
				$strFullName	.=  " " . $strLastName;
			}

			echo'
			  <tr	onMouseOver="this.bgColor=\'' . $this->theSkin->strRowHighlightColor . '\'" onMouseOut="this.bgColor=\'\'">
				<td width= "5%" class="' . $strRowType . '" align="center"><input name="cb_' . $nCharID . '" type="checkbox" id="cb_' . $nCharID . '" value=' . $strCheckBoxValue . '" onClick="ClickCheckBox(this);">
				<td width="25%" class="' . $strRowType . '">'					. $strFullName		. '</td>
				<td width= "8%" class="' . $strRowType . '" align="center">'	. $nEQPlayersCharID	. '</td>
			  </tr>
			';

			// Switch RowType, so the rows alternate	
			if( $strRowType == "OddRow" )
			{
				$strRowType	= "EvenRow";
			}
			else
			{
				$strRowType	= "OddRow";
			}
			
			// Raise the OldMember counter
			$nNrOfCharacters++;
		}
	
		// End the character table
		echo '
			</table>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );

		// Print the end of the page
		if( $nNrOfCharacters > 0 )
		{
			echo '
			<br />
			<input type="button" name="pbDeselectAllCharacters" value="Select None" onclick="SetAllCheckBoxes( false );">
			<input type="button" name="pbSelectAllCharacters"   value="Select All"  onclick="SetAllCheckBoxes( true );">
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		    <input type="button" name="pbImport"                value="Import"      onclick="PerformImport();">
		    <!-- Hidden field to store Import status -->
	        <input name="cbPerformImport" type="hidden" id="cbPerformImport" value="' . $bPerformImport . '">
	        ';
	    }
	    else
	    {
			echo '
			<br />
			<br />
			<center><font size=+2 color="' . $this->theSkin->strErrorColor . '">
			No characters present on the roster.
			</font></center>
			';
	    }
	    
	    echo '
		  </div>
		</form>
		';
	}

}

?>
