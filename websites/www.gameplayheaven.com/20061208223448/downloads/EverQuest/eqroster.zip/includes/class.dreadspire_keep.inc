<?php
// Includes
require_once( './config.php' );
require_once( './includes/functions.inc' );
require_once( GetSkinDir() . 'class.skin.inc' );


// ============================================================================
// The Dreadspire_Keep class
// ============================================================================
// This class provides an interface to the Dreadspire_Keep table
//
// Usage:
// Create an object of this class, and call one of it's functions
// ============================================================================
class Dreadspire_Keep
{
	// Member variables
	var $theSkin;
	var $bShowVerticalScrollbars	= true;

	// ========================================================================
	// Constructor
	// ========================================================================
	function Dreadspire_Keep()
	{
		// Create the skin
		$this->theSkin	= new Skin();
	}

	// ========================================================================
	// Get the title of this overview
	// ========================================================================
	// Out:	The title of this overview
	// ========================================================================
	function GetTitle()
	{
		return "Dreadspire Keep";
	}



	// ========================================================================
	// Show the header
	// ========================================================================
	// This function will show the header of the list
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// ========================================================================
	function ShowHeader( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strShowAlts, $strClassFilter )
	{
		echo '
		<!-- Start of Header -->
		<div id="Header">
		<br />
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td width= "5%" align="center">' . GetInfoLink( "Dreadspire_Keep", "Dreadspire Keep information" ) . '</td>
			<td width="19%">				<b><a href="form.php?FormName=Dreadspire_Keep&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=CharName&SortDirection='			. GetSortDirection( $strSortOrder, "CharName",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Name\';return true;"					OnMouseOut="window.status=\'\'"	target=Body title="Name"																									>Name</a></b></td>
			<td width="16%" align="center">	<b><a href="form.php?FormName=Dreadspire_Keep&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Scavenger_Hunting&SortDirection='	. GetSortDirection( $strSortOrder, "Scavenger_Hunting",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Scavenger Hunting\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Scavenger Hunting (from Treddlehoop in Corathus Creep, reward: Treddlehoop\'s Signature Monocle)"		>Scavenger Hunting</a></b></td>
			<td width="16%" align="center">	<b><a href="form.php?FormName=Dreadspire_Keep&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=The_Lost_Notebook&SortDirection='	. GetSortDirection( $strSortOrder, "The_Lost_Notebook",		$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by The Lost Notebook\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="The Lost Notebook (from Brovil Palivineg in Corathus Creep, reward: Spectacular Image Enhancing Prism)"	>The Lost Notebook</a></b></td>
			<td width="16%" align="center">	<b><a href="form.php?FormName=Dreadspire_Keep&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Lost_Gnomes&SortDirection='			. GetSortDirection( $strSortOrder, "Lost_Gnomes",			$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Lost Gnomes\';return true;"			OnMouseOut="window.status=\'\'"	target=Body title="Lost Gnomes (from Mazil in Corathus Creep, reward: Gold and Platinum Twined Necklace)"					>Lost Gnomes</a></b></td>
			<td width="16%" align="center">	<b><a href="form.php?FormName=Dreadspire_Keep&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Deserting_the_Ranks&SortDirection='	. GetSortDirection( $strSortOrder, "Deserting_the_Ranks",	$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by Deserting the Ranks\';return true;"	OnMouseOut="window.status=\'\'"	target=Body title="Deserting the Ranks (from Zahn in Undershore, reward: Golden Shiliskin Tentacle Ring)"					>Deserting the Ranks</a></b></td>
			<td width= "7%"></td>
			<td width= "5%" align="center">	<b><a href="form.php?FormName=Dreadspire_Keep&UserName=' . $strUserName . '&Password=' . $strPassword . '&SortOrder=Access&SortDirection='				. GetSortDirection( $strSortOrder, "Access",				$strSortDirection ) . '&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Sort by access completed\';return true;"		OnMouseOut="window.status=\'\'"	target=Body title="Dreadspire Keep Access"																					>Done</a></b></td>
		  </tr>
		</table>
		</div>
		<!-- End of Header -->
		';
	}


	// ========================================================================
	// Show all the records on screen
	// ========================================================================
	// This function will loop through all the records in the database table,
	// and create a html table entry for each one of them.
	// ========================================================================
	// In:	$aHTTP_GET_VARS		= HTTP_GET_VARS that was passed into the form
	// ========================================================================
	function ShowBody( &$aHTTP_GET_VARS )
	{
		// Copy the $HTTP_GET_VARS of the calling page (always form_body), so that we can $_GET the arguments
		$HTTP_GET_VARS		= $aHTTP_GET_VARS;
		// Retrieve variables
		$strUserName		= $_GET['UserName'];
		$strPassword		= $_GET['Password'];
		$strSortOrder		= $_GET['SortOrder'];
		$strSortDirection	= $_GET['SortDirection'];
		$strShowAlts		= $_GET['ShowAlts'];
		$strClassFilter		= $_GET['ClassFilter'];

		// Declare variables
		$strRowType			= "OddRow";
		$strSelectQuery		= "SELECT CharName, NameMain, Scavenger_Hunting, The_Lost_Notebook, Lost_Gnomes, Deserting_the_Ranks, OldMember \n" .
							  "FROM DoD_Flags \n" .
							  "LEFT JOIN Characters ON (DoD_Flags.CharID = Characters.CharID) \n" .
							  "WHERE (	Scavenger_Hunting > 0		OR \n" .
							  "			The_Lost_Notebook > 0		OR \n" .
							  "			Lost_Gnomes > 0				OR \n" .
							  "			Deserting_the_Ranks > 0 )	   \n";

		// Check if we should set a class filter
		if( ( isset( $strClassFilter ) ) &&
			( $strClassFilter != "" ) &&
			( $strClassFilter != "<<All>>" ) )
		{
			$strSelectQuery	.= "AND Class = '" . $strClassFilter . "'";
		} 

		// Check if we should use the default sort order
		if( ( !isset( $strSortOrder ) ) ||
			( $strSortOrder == "" ) )
		{
			// Default sort on Character name
			$strSortOrder	= "CharName"; 
		}

		// Check if we're sorting on Access
		if( $strSortOrder == "Access" )
		{
			// Default sort on Character name
			$strSortOrder	= "(Scavenger_Hunting + The_Lost_Notebook + Lost_Gnomes + Deserting_the_Ranks)"; 
		}

		// Sorting on all numbers should be reversed (Desc first, then Asc)
		$strModifiedSortDirection	= $strSortDirection;
		if( $strSortOrder != "CharName" )
		{
			// Switch the sort order around
			if( $strModifiedSortDirection == "DESC" )
			{
				$strModifiedSortDirection	= "";
			}
			else
			{
				$strModifiedSortDirection	= "DESC";
			}
		}
	
		// Add the sort order
		$strSelectQuery		.= "ORDER BY " . $strSortOrder . " " . $strModifiedSortDirection . ", CharName";
	
		// Connect to the database
		$nLinkID	= DBConnect();
	
		// Show the loading image
		ShowLoadingImage();

		// Start the table
		echo '
		<div id="Body">
		<table id="RosterTable" width="100%" border="0" cellpadding="0" cellspacing="0">
		';
	
		// Retrieve all the records
		$nResult	= mysql_query( $strSelectQuery, $nLinkID );
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nIndex					= 0;
			$strCharName			= $aResult[$nIndex++];
			$strNameMain			= $aResult[$nIndex++];
			$nScavenger_Hunting		= $aResult[$nIndex++];
			$nThe_Lost_Notebook		= $aResult[$nIndex++];
			$nLost_Gnomes			= $aResult[$nIndex++];
			$nDeserting_the_Ranks	= $aResult[$nIndex++];
			$nOldMember				= $aResult[$nIndex++];
	
			// Only show old members for the administrator
			if( ( $strCharName != "" ) &&
				( ( $nOldMember == 0 ) ||
				  ( IsAdministrator( $strUserName ) ) ) )
			{
				// Show the SSRA Emperor key parts
				$this->ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nScavenger_Hunting, $nThe_Lost_Notebook, $nLost_Gnomes, $nDeserting_the_Ranks, $nOldMember, $strRowType );
		
				// Switch RowType, so the rows alternate	
				if( $strRowType == "OddRow" )
				{
					$strRowType	= "EvenRow";
				}
				else
				{
					$strRowType	= "OddRow";
				}
			}
		}
	
		// End the table
		echo '
		</table>
		</div>
		';
	
		// Hide the loading image
		HideLoadingImage();

		// Close the connection
		DBDisconnect( $nLinkID );
	}
	
	
	
	// ========================================================================
	// Show a record
	// ========================================================================
	// This function will create a html table row for a record in the table
	// ========================================================================
	// In:	$strUserName		= Name of logged in user
	// In:	$strPassword		= Encrypted password of logged in user
	// In:	$strSortOrder		= Column to sort on
	// In:	$strSortDirection	= Direction to sort in
	// In:	$strShowAlts		= Show Alts ('Yes') or not ('No')
	// In:  Variables containing the data to show 
	// ========================================================================
	function ShowRecord( $strUserName, $strPassword, $strSortOrder, $strSortDirection, $strClassFilter, $strCharName, $strNameMain, $nScavenger_Hunting, $nThe_Lost_Notebook, $nLost_Gnomes, $nDeserting_the_Ranks, $nOldMember, $strRowType )
	{
		// Declare variables
		$strImageCheck			= '<img src="' . GetSkinDir() . 'images/check.gif" border="0" />';
		$strDeleteChar			= "";
		$strCompleted			= "";
		$strScavenger_Hunting	= "";
		$strThe_Lost_Notebook	= "";
		$strLost_Gnomes			= "";
		$strDeserting_the_Ranks	= "";
	
		// Set the check-image for all filled variables
		if( $nScavenger_Hunting > 0 )		{	$strScavenger_Hunting	= $strImageCheck;	}
		if( $nThe_Lost_Notebook > 0 )		{	$strThe_Lost_Notebook	= $strImageCheck;	}
		if( $nLost_Gnomes > 0 )				{	$strLost_Gnomes			= $strImageCheck;	}
		if( $nDeserting_the_Ranks > 0 )		{	$strDeserting_the_Ranks	= $strImageCheck;	}
		if( ( $nScavenger_Hunting > 0 ) &&
			( $nThe_Lost_Notebook > 0 ) &&
			( $nLost_Gnomes > 0 ) &&
			( $nDeserting_the_Ranks > 0 ) )	{	$strCompleted			= $strImageCheck;	}
	
		// Check if it's an old member
		if( $nOldMember == 1 )
		{
			$strRowType		= "DeletedRow";

			// Allow the deletion of old members
			$strDeleteChar	= ' <a href="form.php?FormName=Character_Delete&UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&ShowAlts=' . $strShowAlts . '&PreviousForm=Dreadspire_Keep&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Delete ' . $strCharName . '\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Delete ' . $strCharName . '"><img src="' . GetSkinDir() . 'images/delete.gif" border="0" /></a>';
		}
	
		// Check if this character belongs to the logged in User
		$strModify	= "";
		if( ( isset( $strUserName ) ) &&
			( isset( $strNameMain ) ) &&
			( $strUserName == $strNameMain ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=Dreadspire_Keep&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify.gif" border="0" />';
		}
		else if( IsAdministrator( $strUserName ) )
		{
			$strModify	= '<a href="form_character_modify.php?UserName=' . $strUserName . '&Password=' . $strPassword . '&CharName=' . $strCharName . '&SortOrder=' . $strSortOrder . '&SortDirection=' . $strSortDirection  . '&PreviousForm=Dreadspire_Keep&ClassFilter=' . $strClassFilter . '"	OnMouseOver="window.status=\'Modify ' . $strCharName . '\\\'s information\';return true;"	OnMouseOut="window.status=\'\'" target="Body" title="Modify ' . $strCharName . '\'s information"><img src="' . GetSkinDir() . 'images/modify_others.gif" border="0" />';
		}
	
		echo '
		  <tr	onMouseOver="this.bgColor=\'' . $this->theSkin->strRowHighlightColor . '\'" onMouseOut="this.bgColor=\'\'">
			<td width= "5%" align="center">'				. $strModify				. '</td>
			<td width="19%" class="' . $strRowType . '">'	. $strCharName				. $strDeleteChar . '</td>
			<td width="16%" align="center">'				. $strScavenger_Hunting		. '</td>
			<td width="16%" align="center">'				. $strThe_Lost_Notebook		. '</td>
			<td width="16%" align="center">'				. $strLost_Gnomes			. '</td>
			<td width="16%" align="center">'				. $strDeserting_the_Ranks	. '</td>
			<td width= "7%"></td>
			<td width= "5%" align="center">'				. $strCompleted				. '</td>
		  </tr>
		';
	}

}

?>
