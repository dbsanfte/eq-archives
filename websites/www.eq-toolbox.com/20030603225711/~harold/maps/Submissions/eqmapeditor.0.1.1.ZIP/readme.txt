EQMapEditor version 0.1.1
--Requires the Microsoft .Net Framework v1.0 or greater--

Control:
The controls right now assume a three button mouse or a mouse with a scroll wheel. In case you don't know that little scroll wheel is a button too.

The right mouse button allows you to pan, or drag the map around to get a better view. The middle mouse button zooms by moving up (zoom in) or down (zoom out). The mouse wheel is an alternate method to zoom. Finally, the left mouse button is to select lines (points are not yet supported) simply click and drag to begin a selection. Pressing and holding SHIFT allows you to add to an existing selection while ALT subtracts from a selection.

There are two selection modes, Points and Lines. These are toggled between in the Tools menu.

Editing:
EQMapEditor can be used to change colors by first making a selection using the left mouse button then selecting Edit -> Color (or pressing F1) from the menu.

Printing:
Printing is simple, the program automatically sizes the map to fit on one page.

History
-------
0.1.1 : Added Export to Image feature.
0.1.0 : Initial Public Release