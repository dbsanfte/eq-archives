EQView - JuiCe 2001
====== = ==========
====== = ==========

EQView is a JScript-driven program that collects various information about your EverQuest settings and computer settings and reports them back to you accordingly.  Currently there are only a few EverQuest variables that EQView reads, but an unlimited number of variables can be added upon request.  This is a useful tool to make sure your settings are correct before you start your game, and also to verify your IP Address and other computer information.  Please send all suggestions/requests to j.ski@angelfire.com.  Thanks! ;)

-JuiCe