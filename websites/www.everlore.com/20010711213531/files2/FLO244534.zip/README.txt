log.pl is released AS IS! The author will not be held responsible for an problems that may be caused to the user's computer after running log.pl.  In short, don't come whining to me if your computer explodes after you run the program.

April 14, 2000