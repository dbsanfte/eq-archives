#!/usr/bin/perl -w
#######################################################################
#Author: Sean Seelye     E-mail: sunymoon@geocities.com  Version: 1.2 #
#URL: http://thedoh.dyndns.org/eqstats/index.shtml                    #
#Date: April 14, 2000, ver 1.0 rel                                    #
#Date: October 16, 2000, ver 1.2 rel                                  #
#Purpose: Analyze an everquest log to find damage stats for a mob     #
#Notes:  To enter the log file, it is necessary to use \\ when you    #
#wish to use a backslash.                                             #
#It is not possible to pass a mob name via command line parameters if #
#the name has more than 1 word.  Instead, invoke the program with no  #
#paremeters and enter the name when prompted.                         #
#######################################################################
#
#
#Change the following line to reflect where the log file is.
#NOTE: YOU MUST USE \\ TO MAKE THE FILE PATH (AS SHOWN BELOW)
#
my $logfile = "g:\\eq\\eqlog.txt";       #Log file to inspect
#
#CHANGE NOTHING BELOW THIS LINE
#######################################################################


my $petname = "";                        #Pet name
my $total = 0; my $totald = 0;           #Total attacks, Total Damage 
my $pierce = 0; my $piercet = 0;         #Total Pierces, Total Pierce Damage
my $bash = 0;  my $basht = 0;            #Total Bashes, Total Bash Damage
my $kick = 0;  my $kickt = 0;            #Total Kicks, Total Kick Damage
my $slash = 0; my $slasht = 0;           #Total Slashes, Total Slash Damage
my $crush = 0; my $crusht = 0;           #Total Crushes, Total Crush Damage
my $punch = 0; my $puncht = 0;           #Total fist hits, Total Fist Hit Damage
my $strike = 0; my $striket = 0;         #Total strikes, Total strike damage
my $backstab = 0; my $backstabt = 0;     #Total Backstabs, Total Backstab Damage
my $bite = 0; my $bitet = 0;             #Total Bites, Total Bite Damage
my $riposte = 0; my $dodge = 0;          
my $block = 0; my $parry = 0;
my $kills = 0; my $hitson = 0;

my $piercem = -1; my $bashm = -1; my $kickm = -1; my $slashm = -1;
my $crushm = -1; my $punchm = -1; my $strikem = -1; my $backstabm = -1;
my $bitem = -1;

my $miss = 0;                            #Total Misses

else { 
  print "Enter name to caclulate for: "; #No? Prompt
  chomp($petname = <STDIN>);             #And assign 
}
#system("cls");                          

sub getnum {
  my $newline = "";                     #Used to extract damage numbers
  my $for;                              #Used for readability to extract damage numbers
  my $points;                           #Used for readability to extract damage numbers

  $points = index($_, "point") - 1;     #Find the position where numbers end
  $for = index($_, "for") + 4;          #Find the position where numbers start          
  $newline = substr($_, $for, $points); #Create new string with numbers
  $newline = substr($newline, 0, 3);    #Take three characters

  if ($newline =~ /p/) {                #Line is 12 p, so take 12
   return substr($newline, 0, 2);
  }
  else {
   return $newline;                     #Line is all numbers
  }

}

sub check {                             #Checks for div by zero
 my $var = ($_[0] != 0);
 return $var;
}

sub rnd {
 return int($_[0] * 100) / 100;
}

open (LOG, $logfile) || die "Can't open $logfile $!";

while (<LOG>) {
 if ($_ =~ /$petname tries to/ || $_ =~ /$petname try/) {        #Pet has missed
  $miss++;                               #So increase misses
 }
 elsif ($_ =~ /$petname kicks/) {        #Pet kicked
   my $num = &getnum($_);                #So get the point damage
   $kick++;                              #So increase kicks
   $kickt += $num;                       #Add to kick total
   if ($num >= $kickm) {
    $kickm = $num;
   }
 }
 elsif ($_ =~ /$petname ripostes/) {
   $riposte++;
 }
 elsif ($_ =~ /$petname dodges/) {
   $dodge++;
 }
 elsif ($_ =~ /$petname blocks/) {
   $block++;
 }
 elsif ($_ =~ /$petname parries/) {
   $parry++;
 }
 elsif ($_ =~ /slain by $petname/) {
   $kills++;
 }
 elsif ($_ =~ /$petname for/) {      #Pet has been hit!
   $hitson++;
 }
 elsif (($_ =~ /$petname hits/) || ($_ =~ /$petname punches/)
       || ($_ =~ /$petname claws/)) {
   my $num = &getnum($_);
   $punch++;
   $puncht += $num;
   if ($num >= $punchm) {
    $punchm = $num;
   }

 }
 elsif ($_ =~ /$petname strikes/) {
   my $num = &getnum($_);
   $strike++;
   $striket += $num;
   if ($num >= $strikem) {
    $strikem = $num;
   }

 }
 elsif ($_ =~ /$petname backstabs/) {
   my $num = &getnum($_);
   $backstab++;
   $backstabt += $num;
   if ($num >= $backstabm) {
    $backstabm = $num;
   }

 }
 elsif ($_ =~ /$petname bites/) {
   my $num = &getnum($_);
   $bite++;
   $bitet += $num;
   if ($num >= $bitem) {
    $bitem = $num;
   }

 }
 elsif ($_ =~ /$petname slashes/) {
   my $num = &getnum($_);
   $slash++;
   $slasht += $num;
   if ($num >= $slashm) {
    $slashm = $num;
   }

 }
 elsif ($_ =~ /$petname crushes/) {
   my $num = &getnum($_);
   $crush++;
   $crusht += $num;
   if ($num >= $crushm) {
    $crushm = $num;
   }

 }
 elsif ($_ =~ /$petname bashes/) {
   my $num = &getnum($_);
   $bash++;
   $basht += $num;
   if ($num >= $bashm) {
    $bashm = $num;
   }

 }
 elsif ($_ =~ /$petname pierces/) {
   my $num = &getnum($_);
   $pierce++;
   $piercet += $num;
   if ($num >= $piercem) {
    $piercem = $num;
   }

 }


$total = $strike + $bite + $backstab + $punch + $pierce + $bash + $crush
         + $slash + $kick + $miss;   #Total Attacks
$totald = $striket + $bitet + $backstabt + $puncht + $piercet + $basht
         + $crusht + $slasht + $kickt;    #Total Attack Damage

}
close LOG;                                          #Close log file


print "Stats for: $petname\n";

if (&check($slash)) {
  print "Slashes: $slash  Max Slash: $slashm Slashed For: $slasht  Average Slash: " . &rnd($slasht / $slash) . "\n";
}
if (&check($bash)) {
  print "Bashes: $bash  Max Bash: $bashm Bashed For: $basht  Average Bash: " . &rnd($basht / $bash) . "\n";
}
if (&check($kick)) {
  print "Kicks: $kick  Max Kick: $kickm  Kicked For: $kickt  Average Kick: " . &rnd($kickt / $kick) . "\n";
}
if (&check($crush)) {                    
  print "Crushes: $crush  Max Crush: $crushm Crushed For: $crusht  Average Crush: " . &rnd($crusht / $crush) . "\n";
}
if (&check($bite)) {
  print "Bites: $bite  Max Bite: $bitem Bit For: $bitet  Average Bite: " . &rnd($bitet / $bite) . "\n";
}
if (&check($pierce)) {
  print "Pierces: $pierce  Max Pierce: $piercem Pierced For: $piercet  Average Pierce: " . &rnd($piercet / $pierce) . "\n";
}
if (&check($strike)) {
  print "Strikes: $strike  Max Strike: $strikem Struck For: $striket  Average Strike: " . &rnd($striket / $strike) . "\n";
}
if (&check($backstab)) {
  print "Backstabs: $backstab  Max Backstab: $backstabm Stabbed for $backstabt  Average Stab: " . &rnd($backstabt / $backstab) . "\n";
}
if (&check($punch)) {
  print "Punches: $punch  Max Punch: $punchm Punched for: $puncht  Average Punch: " . &rnd($puncht / $punch) . "\n";
}
print "Ripostes: $riposte\n";
print "Blocks: $block\n";
print "Parries: $parry\n";
print "Dodges: $dodge\n";
print "Kills: $kills\n";
print "Hits On $petname: $hitson\n";

if (&check($miss)) {
  print "Misses: $miss\n";
}
my $attack_hit = $total - $miss;

print "Total Attack (attempts): $total\n";
print "Total Attacks (successful): " . $attack_hit  . "\n";
print "Hit:Miss Ratio: " . (&rnd($attack_hit / $total) * 100) . "%\n";
print "Total Damage: " . ($striket + $bitet + $backstabt + $puncht + $kickt + $slasht + $basht + $crusht + $piercet) . "\n";
print "Average Attack: " . &rnd(($striket + $bitet + $backstabt + $puncht + $piercet + $kickt + $slasht + $basht + $crusht) / ($total - $miss)) . "\n";

