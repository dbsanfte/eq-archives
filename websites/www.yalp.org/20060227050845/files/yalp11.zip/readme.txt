README.TXT

Disclaimer :-

This software is provided "as is", I make no warranty or representation whatsoever of merchantability or fitness for a particular purpose or use. In no event shall I be held liable for any consequential, incidental, or special damages whatsoever arising from the use or inability to use this software.


Installation :-

Currently, YALP does not require a formal install process. Simply unzip the contents of the archive to the folder of your choice, and you are done. YALP.exe is the main log parser, while Launcher.exe is a helper application that allows you to archive log files, or parse individual play sessions from a large log file.
