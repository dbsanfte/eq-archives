/*
 *  everquest.h
 *  
 *  ShowEQ Distributed under GPL
 *  http://www.hackersquest.gomp.ch/
 */

/* Structures used in the network layer of Everquest */

#ifndef EQSTRUCT_H
#define EQSTRUCT_H

/* Definitions to get datatype widths correct */
#define WORD short int
#define UWORD unsigned short int
#define DWORD long
#define UDWORD unsigned long
#define UBYTE unsigned char
#define BYTE char

/* Compiler override to ensure byte aligned structures */
#pragma pack(1)

/* Generic Structures used in specific structures below */

/* Item structure used for items in shops, on players, etc */
struct itemStruct
{
  char name[35];		// Name of item
  char lore[60];		// Lore text, same as name if no lore
  char idfile[6];		// Don't know what this is used for, eg: IT63
  WORD flag;			// 0x5f31 normal item, 0x3633 player made
  char unknown0[22];		// Placeholder
  UBYTE weight;			// Weight of item
  char nosave;			// Nosave flag 1=normal, 0=nosave, -1=spell?
  char nodrop;			// Nodrop flag 1=normal, 0=nodrop, -1=??
  UBYTE size;			// Size of item
  char unknown5;		// Placeholder
  UWORD itemNr;			// Unique item type number
  UWORD iconNr;			// Icon nr
  char equipSlot;		// Current Equip slot
  char unknown13;		// Placeholder
  UDWORD slots_;		// Slots where this item goes
  DWORD cost;			// Item cost in copper
  char unknown1[20];		// Placeholder
  char STR;			// Strength
  char STA;			// Stamina
  char CHA;			// Charisma
  char DEX;			// Dexterity
  char INT;			// Intelligence
  char AGI;			// Agility
  char WIS;			// Wisdom
  char MR;			// Magic Resistance
  char FR;			// Fire Resistance
  char CR;			// Cold Resistance
  char DR;			// Disease Resistance
  char PR;			// Poison Resistance
  char HP;			// Hitpoints
  char MANA;			// Mana
  char AC;			// Armor Class
  char unknown2[2];		// Placeholder
  UBYTE light;			// Light effect of this item
  char delay;			// Weapon Delay
  char damage;			// Weapon Damage
  char unknown6;		// Placeholder
  UBYTE range;			// Range of weapon
  UBYTE skill;			// Skill of this weapon
  char magic;			// Magic flag, 0(0000=unique?, 1(0001)=magic, 12(1100)=meat?, 14(1110)=normal?, 15(1111)=???
  char level0;			// Casting level
  UBYTE material;		// Material?
  char unknown3_[2];		// Placeholder
  UDWORD color;			// Amounts of RGB in original color 
  char unknown3__[2];		// Placeholder
  UWORD spellId0;		// SpellID of special effect
  UWORD classes;		// Classes that can use this item
  char unknown14[2];		// Placeholder
  UWORD races;			// Races that can use this item
  char unknown15;		// Placeholder
  char numSlots;		// number of slots?-ATB
  char unknown16;               // more padding.
  UBYTE level;			// Casting level
  char number;			// Number of items in stack
  char unknown8;		// Placeholder
  UWORD spellId;		// spellId of special effect
  char unknown9[26];		// Placeholder
};

/* Specific Structures defining opcodes */

/* Item owned by the player */
struct itemPlayerStruct
{
  char opCode;			// Was 0x60, now 0x64
  char version;			// 0x21
  struct itemStruct item;	// Refer to itemStruct for members
};

/* Item received by the player */
struct itemReceivedPlayerStruct
{
  char opCode;			// Always 0x31
  char version;			// 0x21
  struct itemStruct item;	// Refer to itemStruct for members
};

/* Item in a shop */
struct itemShopStruct
{
  char opCode;			// Was 0x14, now 0x0c
  char version;			// 0x21
  char unknown0[4];		// Shopkeeper ID must be in here
  char itemType;		// 0 - item, 1 - container, 2 - book
  struct itemStruct item;	// Refer to itemStruct for members
};

/* Channel Message received */
struct channelMessageStruct
{
  char opCode;			// Always 0x41
  char version;			// 0x21
  unsigned char unknown0[32];		// Placeholder
  char sender[23];		// The senders name (len might be wrong)
  unsigned char unknown1[15];		// Placeholder
  char message[0];		// Variable length message
};

/* Delete Spawn */
struct deleteSpawnStruct
{
  char opCode;			// Always 0x37 was 0x37 now 0xD8
  char version;			// 0x21
  UWORD spawnId;			// Spawn ID to delete
};

/* Spawn generic struct */
struct spawnStruct
{
  char unknown0[49];		// Placeholder
  char heading;
  char deltaHeading;
  WORD yPos;			// Y Position
  WORD xPos;			// X Position
  WORD zPos;
  DWORD deltaY:10,		// Velocity Y
         spacer1:1,
         deltaZ:10,		//  Velocity Z
         spacer2:1,
         deltaX:10;		//  Velocity X

  char unknown1[1];		// Placeholder
  UWORD spawnId;		// Id of new spawn
  char unknown2[2];		// Placeholder
  UWORD petOwnerId;              // Id of pet owner (0 if not a pet)
  WORD maxHp;			// Maximum hp's of Spawn
  WORD curHp;			// Current hp's of Spawn
  WORD unknown3;		// Placeholder
  UBYTE race;			// Race
  UBYTE NPC;			// NPC flag, 0 = player, 1 = NPC, 2 = corpse
  UBYTE class_;			// Class
  UBYTE unknown7;		// Placeholder
  UBYTE level;			// Level of spawn (might be one byte)
  char unknown8[4];             // Placeholder
  UBYTE light;                  // Light emitting
  char unknown4[9];	        // Placeholder
  unsigned char equipment[9];   // Equipment worn
  char name[30];		// Name of spawn (len is 30 or less)
  char lastname[20];	        // Last Name of player
};

/* New Spawn */
struct newSpawnStruct
{
  char opCode;			// Always 0x46
  char version;			// 0x21
  struct spawnStruct spawn;
};

/** DB spawn struct (adds zone spawn was in) **/
struct dbSpawnStruct
{
   struct spawnStruct spawn;
   char zoneName[40];
};

// Pet spawn struct (pets pet and owner in one struct)
struct petStruct 
{
   struct spawnStruct owner;
   struct spawnStruct pet;
};

/* Book belonging to player */
struct bookPlayerStruct
{
  char opCode;			// Was 0x61 now 0x65 (untested)
  char version;			// 0x21
  char name[35];		// Name of item
  char lore[60];		// Lore text, same as name if no lore
  char idfile[6];		// Don't know what this is used for, eg: IT63
  WORD flag;			// 0x5f31 normal item, 0x3633 player made
  //char unknown0[37];		// Placeholder replaced by below
/*22*/  char unknown0[22];		// Placeholder
/*23*/  UBYTE weight;			// Weight of item
/*24*/  char nosave;			// Nosave flag 1=normal, 0=nosave, -1=spell?
/*25*/  char nodrop;			// Nodrop flag 1=normal, 0=nodrop, -1=??
/*26*/  UBYTE size;			// Size of item
/*27*/  char unknown5;		// Placeholder
/*29*/  UWORD itemNr;			// Unique item type number
/*31*/  UWORD iconNr;			// Icon nr
/*32*/  char equipSlot;		// Current Equip slot
/*33*/  char unknown13;		// Placeholder
/*37*/  UDWORD slots_;		// Slots where this item goes
  DWORD cost;			// Item cost in copper
  char unknown1[23];		// Placeholder
  char file[15];		// Filename of text on server
  char unknown2[12];		// Placeholder
};

/* Container Belonging to Player */
struct containerPlayerStruct
{
  char opCode;			// Was 0x62, now 0x66 (untested)
  char version;			// 0x21
  char name[35];		// Name of container 
  char lore[60];		// Lore text, same as name if no lore
//  char unknown0[45];		// Placeholder
//  these replaced unknown0:
/*06*/  char idfile[6];		// Don't know what this is used for, eg: IT63
/*08*/  WORD flag;			// 0x5f31 normal item, 0x3633 player made
/*30*/  char unknown0[22];		// Placeholder
/*31*/  UBYTE weight;			// Weight of item
/*32*/  char nosave;			// Nosave flag 1=normal, 0=nosave, -1=spell?
/*33*/  char nodrop;			// Nodrop flag 1=normal, 0=nodrop, -1=??
/*34*/  UBYTE size;			// Size of item
/*35*/  char unknown5;		// Placeholder
/*37*/  UWORD itemNr;			// Unique item type number
/*39*/  UWORD iconNr;			// Icon nr
/*40*/  char equipSlot;		// Current Equip slot
/*41*/  char unknown13;		// Placeholder
/*45*/  UDWORD slots_;		// Slots where this item goes

  DWORD cost;			// Item cost in copper
//  char unknown1[61];
/*20*/  char unknown1[20];		// Placeholder
/*21*/  char STR;			// Strength
/*22*/  char STA;			// Stamina
/*23*/  char CHA;			// Charisma
/*24*/  char DEX;			// Dexterity
/*25*/  char INT;			// Intelligence
/*26*/  char AGI;			// Agility
/*27*/  char WIS;			// Wisdom
/*28*/  char MR;			// Magic Resistance
/*29*/  char FR;			// Fire Resistance
/*30*/  char CR;			// Cold Resistance
/*31*/  char DR;			// Disease Resistance
/*32*/  char PR;			// Poison Resistance
/*33*/  char HP;			// Hitpoints
/*34*/  char MANA;			// Mana
/*35*/  char AC;			// Armor Class
/*37*/  char unknown2[2];		// Placeholder
/*38*/  UBYTE light;			// Light effect of this item
/*39*/  char delay;			// Weapon Delay
/*41*/  char damage;			// Weapon Damage
/*41*/  char unknown6;		// Placeholder
/*42*/  UBYTE range;			// Range of weapon
/*43*/  UBYTE skill;			// Skill of this weapon
/*44*/  char magic;			// Magic flag, 0(0000=unique?, 1(0001)=magic, 12(1100)=meat?, 14(1110)=normal?, 15(1111)=???
/*45*/  char level0;			// Casting level
/*46*/  UBYTE material;		// Material?
/*48*/  char unknown3_[2];		// Placeholder
/*52*/  UDWORD color;			// Amounts of RGB in original color 
/*53*/  char unknown3__[2];		// Placeholder
/*56*/  UWORD spellId0;		// SpellID of special effect
/*58*/  UWORD classes;		// Classes that can use this item (this is not exactly)
/*60*/  UWORD races;			// Races that can use this item(like items)
/*61*/  char unknown15;		// Placeholder
  char numSlots;		// number of slots in bag.
  char unknown16;               // more padding.
  UBYTE level;			// Casting level
  char number;			// Number of items in stack
  char unknown8;		// Placeholder
  UWORD spellId;		// spellId of special effect
};

/* Server System Message */
struct systemMessageStruct
{
  char opCode;			// Always 0xa4
  char version;			// 0x21
  char message[0];		// Variable length message
};

/* Spawn HP Update */
struct spawnHpUpdateStruct
{
  char opCode;			// Always 0x75
  char version;			// 0x20
  UWORD spawnId;			// Id of spawn to update
  WORD unknown0;		// Placeholder
  WORD curHp;			// Current hp of spawn
  WORD unknown1;		// Placeholder
  WORD maxHp;			// Maximum hp of spawn
  WORD unknown2;		// Placeholder
};

/* Spawn Position Update */
struct spawnPositionUpdateStruct
{
  char opCode;			// Was 0x85, now 0xa1 
  char version;			// 0x20
  DWORD numUpdates;		// Number of SpawnUpdates
  struct
  {
    UWORD spawnId;		// Id of spawn to update  
    char unknown0[1];		// Placeholder
    char heading;		// Heading
    char deltaHeading;		// Heading Change
    WORD yPos;			// New Y position of spawn
    WORD xPos;			// New X position of spawn
    WORD zPos;			// New Z position of spawn
    DWORD deltaY:10,		// Velocities 
         spacer1:1,
         deltaZ:10,		//  Velocity
         spacer2:1,
         deltaX:10;		//  Velocity
  }
  spawnUpdate[0];		// Variable number of updates

};

/* Player Update Packet */
struct playerUpdateStruct
{
  char opCode;			// Always 0xd1
  char version;			// 0x20
  UWORD spawnId;		// Id of player  
  char unknown0[1];		// Placeholder
  char heading;			// Current heading of player
  char deltaHeading;		// Heading Change
  WORD yPos;			// Players Y Position
  WORD xPos;			// Players X Position
  WORD zPos;			// Players Z Position
  DWORD deltaY:10,		// Velocities 
        spacer1:1,
        deltaZ:10,		//  Velocity
        spacer2:1,
        deltaX:10;		//  Velocity
};

/* Player Profile */
struct playerProfileStruct
{
  char opCode;			// Was 0x35, now 0x3D 
  char version;			// 0x21
  char unknown0[4];		// Placeholder
  char name[30];		// Name of player
  char lastName[20];		// Last name of player
  WORD unknown5;		// Placeholder
  UBYTE race;			// Player race
  char unknown1;		// Placeholder
  UBYTE class_;			// Player class
  UBYTE gender;			// Player gender
  UBYTE level;			// Level of player (might be one byte)
  char unknown2[3];		// Placeholder
  UDWORD exp;			// Current Experience
  UDWORD expMax;		// Not expmax, some other number 
  char unknown4[2436];		// Placeholder
  unsigned char skills[74];	// List of skills
  char unknown3[1950];
};

/* Zone Spawns */
struct zoneSpawnsStruct
{
  char opCode;			// Always 0x47
  char version;			// 0x21
  struct spawnStruct spawn[0];	// Variable number of spawns
};

/* New Zone Name */
struct newZoneStruct
{
  char opCode;			// Was 0xcb, now now 0x5b
  char version;			// 0x20
  char unknown0[30];		// Placeholder
  char shortName[15];
  char unknown1[5];		// Placeholder
  char longName[15];
};

/* Door */
struct newDoorStruct
{
  char opCode;			// Always 0x94
  char version;			// 0x20
  char name[8];			// Filename of Door?
  char unknown[40];		// Placeholder
};

/* Special Message */
struct spMesgStruct
{
  char opCode;			// Always 0x80
  char version;			// 0x21
  DWORD msgType;		// Type of message
  char message[0];		// Message, followed by four 0 bytes?
};

/* Reading a book */
struct bookTextStruct
{
  char opCode;			// Always 0x59
  char version;			// 0x20
  char text[0];			// Text of item reading
};

/* Emote text */
struct emoteTextStruct
{
  char opCode;			// Always 0x15
  char version;			// 0x20
  char text[0];			// Text of item reading
};


/* Level up */
struct levelUpStruct
{
  char opCode;			//Always 0x86
  char version;			// 0x21
  UDWORD level;			// New level 
  UDWORD levelOld;		// Old level 
  UDWORD exp;			// Current Experience 
};

/* Exp update */
struct expUpdateStruct
{
  char opCode;			//Always 0x87
  char version;			// 0x21
  UDWORD exp;			// Current experience value
};

/* Time of Day ? */
struct timeOfDayStruct
{
  char opCode;			// Always 0x4d
  char version;			// 0x21
  WORD time0;			// Time value 0?
  WORD time1;			// Time value 1?
  WORD time2;			// Time value 2?
};

struct skillIncreaseStruct
{
  char opCode;			// Always 0x92
  char version;			// 0x20
  WORD skillId;			// Id of skill
  char unknown0[2];		// Placeholder
  WORD value;			// New value of skill
  char unknown1[2];		// New value of skill
};

/* Memorize slot operations, mem, forget, etc */
struct memorizeSlotStruct
{
  char opCode;			// Always 0x82
  char version;			// 0x21
  char slot;			// Memorization slot (0-7)
  char unknown0[3];		// Placeholder
  UWORD spellId;		// Id of spell (offset of spell in spdat.eff)
  char unknown1[6];		// Placeholder 00,00,01,00,00,00
};

/* Begin Casting */
struct beginCastStruct
{
  char opCode;			// Was 0x7d, now 0xb2 (untested)
  char version;			// 0x20
  UWORD spawnId;		// Id of who is casting
  WORD unknown0;		// Placeholder
  UWORD spellId;		// Id of spell
  WORD param1;			// Paramater 1?
  WORD param2;			// Paramater 2?
  WORD param3;			// Parameter 3?
};

/* Interrupted Casting */
struct interruptCastStruct
{
  char opCode;			// Always 0xd3
  char version;			// 0x21
  UWORD spawnId;		// Id of who is casting
  WORD unknown0;		// Placeholder
  char message[0];
};

/* Kill something */
struct spawnKilledStruct
{
  char opCode;			// Always 0x4a
  char verison;			// 0x20
  UWORD spawnId;			// Id of spawn that died
  //From wizzie Wiz:
  WORD unknown0;
  UWORD killerId;
  char unknown1[10];
};

/*When somebody changes what they're wearing or give a pet a weapon (model changes)*/
struct wearChangeStruct{
    WORD opCode; //9220
    UWORD spawnId;
    char unknown0[2];
    unsigned char wearSlotId;
    unsigned char newItemId;
    char unknown1[6];  //first few bytes react to clothing changes
};

struct dropThingOnGround{
/*000*/WORD opCode; //3520
/*002*/unsigned char unknown0a[8]; //working.
/*002*/UWORD itemNr; 
/*002*/unsigned char unknown0b[2]; //working.
/*00E*/UWORD dropId;
/*010*/unsigned char unknown2[26];
/*02A*/float yPos;
/*02E*/float xPos;
/*032*/float zPos;
/*010*/unsigned char unknown3[4];
/*0XX*/char idFile[16];//maybe be 4?
/*0XX*/unsigned char unknown4[168];

};

struct removeThingOnGround{
    WORD opCode; //3620
    UWORD dropId; //guess
    char unknown0[6];  //shrug
};


struct castOnStruct
{
  char opCode;//0x4620
  char version; 
  UWORD targetId;
  char unknown0[2];
  UWORD sourceId;
  char unknown1[26];  // might be some spell info?
};

struct manaDecrementStruct
{
  WORD opCode;//0x7f21
  WORD newMana; // ammount of mana left after cast
  WORD spellID; 
};

struct summonedItemStruct
{
  char opCode; // 0x78
  char version; // 0x21
  struct itemStruct item;
};

struct tradeItemStruct
{
  char opCode; // 0xdf
  char version; // 0x20
  char unknown[6];
  char itemtype;
  struct itemStruct item;
};

struct staminaStruct {
  char opCode; // 0x57
  char version; // 0x21
  WORD food; // (low numbers are more hungry 127-0)
  WORD water; // (low numbers are more thirsty 127-0)
  WORD fatigue; // (high numbers are more fatigued 0-100)
};

// Supplied by Sparr:  Somone give this guy write rights =)

struct dropCoinsStruct{
  WORD opCode; //0720
  unsigned char unknown1[24]; //no clue
  UWORD dropId;
  unsigned char unknown2[22];
  UDWORD amount;
  unsigned char unknown3[4];
  float yPos;
  float xPos;
  float zPos;
  unsigned char unknown4[12]; //blank space
  char type[15]; //silver gold whatever
  unsigned char unknown5[17];
};

struct removeCoinsStruct{
  WORD opCode; //0820
  UWORD dropId; //guess
  char unknown0[6];  //shrug
};

struct attack1Struct{
  WORD opCode; //f520
  UWORD spawnId;
  WORD unknown1;
  WORD unknown2;
  WORD unknown3;
  WORD unknown4;
  WORD unknown5;
};

struct attack2Struct{
  WORD opCode; //9f20
  UWORD spawnId;
  WORD unknown1;
  WORD unknown2;
  WORD unknown3;
  WORD unknown4;
  WORD unknown5;
};

struct considerStruct{ 
  WORD opcode;        /*3721*/ 
  UWORD playerid; 
  char unknown1[2];
  UWORD targetid; 
  char unknown2[2]; 
  DWORD faction;
};

struct newGuildInZoneStruct {
  WORD opcode; /*7b21*/
  char unknown[8];
  char guildname[56]; 
};

struct moneyUpdateStruct{
  WORD opcode; /*3d21*/
  UWORD unknown1;
  char unknown2[2];
  unsigned char cointype;
  char unknown3[3];
  UDWORD amount; 
};

struct bindWoundStruct{
  WORD opcode; /*8321*/
  UWORD playerid;
  char unknown1[2];
  DWORD hpmaybe;
};

struct inspectedStruct{
  WORD opcode; /*bf20*/
  UWORD inspectorid;
  unsigned char blank1[2];
  UWORD inspectedid; /*should be you*/
  unsigned char blank2[2];
};

struct inspectingStruct{
  WORD opcode; //B620
  char unknown1[40];
  char itemNames[21][32];//21 items with names 32 characters long.
  UWORD icons[21];  
  char unknown2[2];
  char mytext[200];
  char unknown3[88];

};

struct randomStruct {
  WORD opcode; /* e7 21 */
  UDWORD bottom; /* Bottom number for random request */
  UDWORD top; /* Top number for random request */
};

struct groupMemberStruct {
  WORD opcode; /*26 40*/
  char yourname[32];
  char membername[32];
  char unknown1[35];
  char bgARC;//Add = 2, Remove = 3, Clear = 0- Bad Guess-ATB
  char unknown2[83];
  char ARC;//Add = 4, Remove = 3
  char ARC2;//?? -  Add = c8, remove 1 = c5, clear = 01 
  char unknown3[131];//what does this stuff MEAN?
};

#endif // EQSTRUCT_H

//. .7...6....,X....D4.M.\.....P.v..>..W....
//123456789012345678901234567890123456789012
//000000000111111111122222222223333333333444
