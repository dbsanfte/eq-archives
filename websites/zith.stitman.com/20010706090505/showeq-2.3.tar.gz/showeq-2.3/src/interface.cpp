/*
 * interface.cpp
 *
 * ShowEQ Distributed under GPL
 * http://www.hackersquest.gomp.ch/
 */

#include <sys/stat.h>
#include <sys/types.h>
#include <sys/time.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include "interface.h"
#include "packet.h"
#include "util.h"
#include "compass.h"
#include "msgdlg.h"
#include "main.h"
#include "spawnlist.h"

#include <qfont.h>
#include <qapplication.h>
#include <qlabel.h>
#include <qpushbutton.h>
#include <qvaluelist.h>
#include <qstatusbar.h>
#include <qvaluelist.h>

//#define DEBUG

#undef DEBUG

// Hiya mack!

/* Called to add a skill to the skills list */
void EQInterface::addSkill (int skillId, int value)
{
  if (!m_pSkillList)
    return;

  char str[64];
  /* Check if this is a valid skill */
  if (value == 255)
    return;
  /* Check if this is a skill not learned yet */
  if (value == 254)
    sprintf (str, " NA");
  else
    sprintf (str, "%3d", value);

  /* If the skill is not added yet, look up the correct skill namd and add it
   * to the list
   */
  if (!skillList[skillId])
    skillList[skillId] =
      new QListViewItem (m_pSkillList, skill_name (skillId), str);
  else
    {
      skillList[skillId]->setText (1, str);
    }
}

/* Skill update */
void EQInterface::changeSkill (int skillId, int value)
{
  if (!m_pSkillList)
    return;

  char str[64];
  /* Update skill value with new value */
  sprintf (str, "%3d", value);
  skillList[skillId]->setText (1, str);
}

/* Delete all skills when zoning */
void EQInterface::deleteSkills() {
  for(int i=0;i<255;i++)
    if(skillList[i]) {
      delete skillList[i];
      skillList[i]=0;
    }
}

void EQInterface::expChanged  (int val, int min, int max) 
{
    if (!m_pStatList)
      return;

    char	buf[64];
    char *	xp;
    xp = Commanate((UDWORD) (val - min));
    statList[0]->setText (1, xp);
    free(xp);

    xp = Commanate((UDWORD) (max - min));
    statList[0]->setText (2, xp);
    free(xp);

    xp = Commanate((UDWORD) ((val - min) * 100 / (max - min)));
    sprintf(buf,"%s %%", xp);
    free(xp);
    statList[0]->setText (3, buf);
}

void EQInterface::hpChanged   (int val, int max) 
{
    if (!m_pStatList)
      return;

  char buf[64];
  sprintf(buf,"%d",val);
  statList[1]->setText (1, buf);
  sprintf(buf,"%d",max);
  statList[1]->setText (2, buf);
  sprintf(buf,"%d %%",val*100/max);
  statList[1]->setText (3, buf);
//printf("Your HP Changed %d, %d\n", val,max);
}

void EQInterface::manaChanged (int val, int max) 
{
    if (!m_pStatList)
      return;

  char buf[64];
  sprintf(buf,"%d",val);
  statList[2]->setText (1, buf);
  //    sprintf(buf,"%d",max);
  //    statList[2]->setText (2, buf);
  //    sprintf(buf,"%d %%",val*100/max);
  //    statList[2]->setText (3, buf);
}

void EQInterface::stamChanged (int Sval, int Smax, 
			       int Fval, int Fmax,
			       int Wval, int Wmax) 
{
    if (!m_pStatList)
      return;

  char buf[64];

  sprintf(buf,"%d",Sval);
  statList[3]->setText (1, buf);
  sprintf(buf,"%d",Smax);
  statList[3]->setText (2, buf);
  sprintf(buf,"%d %%",Sval*100/Smax);
  statList[3]->setText (3, buf);

  sprintf(buf,"%d",Fval);
  statList[4]->setText (1, buf);
  sprintf(buf,"%d",Fmax);
  statList[4]->setText (2, buf);
  sprintf(buf,"%d %%",Fval*100/Fmax);
  statList[4]->setText (3, buf);

  sprintf(buf,"%d",Wval);
  statList[5]->setText (1, buf);
  sprintf(buf,"%d",Wmax);
  statList[5]->setText (2, buf);
  sprintf(buf,"%d %%",Wval*100/Wmax);
  statList[5]->setText (3, buf);
}

// JohnQ -- I changed the interface widget from a QWidget to 
//          A QMainWindow.. this way we get the menubar for free
//          And we can add toolbars and status bars in the future
//          For free as well.

/* The main interface widget */
EQInterface::EQInterface (QWidget * parent, const char *name):
QMainWindow (parent, name)
{
   int x,y,w,h;
   char tempStr[256];

  /* Initialize the skills list */
  for (int a = 0; a < 255; a++)
    skillList[a] = 0;

   // The first call to menuBar() makes it exist
   menuBar()->setSeparator(QMenuBar::InWindowsStyle);

   // The first call to statusBar() makes it exist
   statusBar()->clear();
// can't figure out how to get the 'message' feature of status bar to not be
// clobbered by my permanent widgets
//   statusBar()->message("Initializing...", 2000);

   m_stsbarStatus = 0;
   if (pSEQPrefs->GetPrefBool("Interface_StatusBar_ShowStatus", 0))
   {
     m_stsbarStatus = new QLabel(statusBar(), "Status");
     m_stsbarStatus->setFrameStyle(QFrame::Panel | QFrame::Sunken);
     m_stsbarStatus->setText("Initializing...");
     m_stsbarStatus->setMinimumHeight(m_stsbarStatus->sizeHint().height());
     m_stsbarStatus->setText("");
     m_stsbarStatus->setMinimumWidth(100);
     statusBar()->addWidget(m_stsbarStatus, 8);
   }

   m_stsbarZone = 0;
   if (pSEQPrefs->GetPrefBool("Interface_StatusBar_ShowZone", 0))
   {
     m_stsbarZone = new QLabel(statusBar(), "Zone");
     m_stsbarZone->setFrameStyle(QFrame::Panel | QFrame::Sunken);
     m_stsbarZone->setText("Zone: [unknown]");
     m_stsbarZone->setMinimumHeight(m_stsbarZone->sizeHint().height());
     statusBar()->addWidget(m_stsbarZone, 2, TRUE);
   }
   m_stsbarSpawns = 0;
   if (pSEQPrefs->GetPrefBool("Interface_StatusBar_ShowSpawns", 0))
   {
     m_stsbarSpawns = new QLabel(statusBar(), "Mobs");
     m_stsbarSpawns->setFrameStyle(QFrame::Panel | QFrame::Sunken);
     m_stsbarSpawns->setText("Mobs:");
     m_stsbarSpawns->setMinimumHeight(m_stsbarSpawns->sizeHint().height());
     statusBar()->addWidget(m_stsbarSpawns, 1, TRUE);
   }

   m_stsbarExp = 0;
   if (pSEQPrefs->GetPrefBool("Interface_StatusBar_ShowExp", 0))
   {
     m_stsbarExp = new QLabel(statusBar(), "Exp");
     m_stsbarExp->setFrameStyle(QFrame::Panel | QFrame::Sunken);
     m_stsbarExp->setText("Exp [unknown]");
     m_stsbarExp->setMinimumHeight(m_stsbarExp->sizeHint().height());
     statusBar()->addWidget(m_stsbarExp, 1, TRUE);
   }

   m_stsbarPkt = 0;
   if (pSEQPrefs->GetPrefBool("Interface_StatusBar_ShowPacketCounter", 0))
   {
     m_stsbarPkt = new QLabel(statusBar(), "Pkt");
     m_stsbarPkt->setFrameStyle(QFrame::Panel | QFrame::Sunken);
     m_stsbarPkt->setText("Pkt 0");
     m_stsbarPkt->setMinimumHeight(m_stsbarPkt->sizeHint().height());
     statusBar()->addWidget(m_stsbarPkt, 1, TRUE);
     m_lPacketStartTime = 0;
   }



   // The first call to tooTipGroup() makes it exist
//   toolTipGroup()->addWidget();


   //
   // Main widgets
   //

   // Make a VBox to use as central widget
   QVBox* pCentralBox = new QVBox(this);
   setCentralWidget(pCentralBox);
 
   // Make the horizontal splitter deviding the map from the other objects
   // and add it to the main window
   m_pSplitH =new QSplitter(QSplitter::Horizontal,pCentralBox,"SplitH");
   m_pSplitH->setOpaqueResize(TRUE);

   // make a splitter between the spawnlist and other objects
   m_pSplitV = new QSplitter(QSplitter::Vertical,m_pSplitH,"SplitV");
   m_pSplitV->setOpaqueResize(TRUE);

   // Make a horizontal splitter for the skilllist/statlist/compass
//   QHBox* m_pSplitVtopbox = new QVBox(m_pSplitV);
//   m_pSplitT = new QSplitter(QSplitter::Horizontal,m_pSplitVtopbox,"SplitT");
   m_pSplitT = new QSplitter(QSplitter::Horizontal,m_pSplitV,"SplitT");
   m_pSplitT->setOpaqueResize(TRUE);


   //
   // Create our compass object
   //
   m_pCompass = new QVBox(m_pSplitT);
   QBoxLayout* pCompassLayout = new QVBoxLayout(m_pSplitT);
   Compass* pCompass = new Compass (m_pCompass, "compass");
//   m_pSplitT->setResizeMode(pCompass, QSplitter::KeepSize);
////   m_pCompass = new Compass (m_pSplitT, "compass");
////   Compass* pCompass = m_pCompass;
   QHBox* coordsbox = new QHBox(m_pCompass);
   pCompass->setFixedWidth(120);
   pCompass->setFixedHeight(120);

   QLabel* xPos;
   QLabel* yPos;
   QLabel* zPos;
   for(int a=0;a<2;a++) {
     if((a+showeq_params->retarded_coords)%2 == 0) {
       // Create the x: label
       QLabel *labelx = new QLabel(showeq_params->retarded_coords?"E/W:":"X:",
                                   coordsbox);
       labelx->setFixedHeight(labelx->sizeHint().height());
       labelx->setFont(QFont("Helvetica", 10, QFont::Bold));
       labelx->setAlignment(QLabel::AlignLeft|QLabel::AlignVCenter);

       // Create the xpos label
       xPos = new QLabel("----",coordsbox);
       xPos->setFixedHeight(xPos->sizeHint().height());
       xPos->setFont(QFont("Helvetica", 10));
       xPos->setAlignment(QLabel::AlignRight|QLabel::AlignVCenter);
     } else {
       // Create the y: label
       QLabel *labely = new QLabel(showeq_params->retarded_coords?"N/S:":"Y:",
                                   coordsbox);
       labely->setFixedHeight(labely->sizeHint().height());
       labely->setFont(QFont("Helvetica", 10, QFont::Bold));
       labely->setAlignment(QLabel::AlignLeft|QLabel::AlignVCenter);

       // Create the ypos label
       yPos = new QLabel("----",coordsbox);
       yPos->setFixedHeight(yPos->sizeHint().height());
       yPos->setFont(QFont("Helvetica", 10));
       yPos->setAlignment(QLabel::AlignRight|QLabel::AlignVCenter);
     }
   }

   // Create the z: label
   QLabel *labelz = new QLabel("Z:",coordsbox);
   labelz->setFixedHeight(labelz->sizeHint().height());
   labelz->setFont(QFont("Helvetica", 10, QFont::Bold));
   labelz->setAlignment(QLabel::AlignLeft|QLabel::AlignVCenter);

   // Create the zpos label
   zPos = new QLabel("----",coordsbox);
   zPos->setFixedHeight(zPos->sizeHint().height());      
   zPos->setFont(QFont("Helvetica", 10));
   zPos->setAlignment(QLabel::AlignRight|QLabel::AlignVCenter);

//   pCompassLayout->addWidget(m_pCompass);
//   pCompassLayout->addStretch();
   

   //
   // Create the skills listview
   //
   m_pSkillList = new QListView (m_pSplitT, "skills");
   m_pSkillList->setFont(QFont("Helvetica", showeq_params->fontsize));
   m_pSkillList->addColumn("Skill");
   m_pSkillList->addColumn("Value");
//   m_pSkillList->setMinimumWidth(100);
//   m_pSkillList->setFixedHeight(120);


   //
   // Create the Player Status listview
   //
   m_pStatList = new QListView (m_pSplitT, "skills");
   m_pStatList->setFont(QFont("Helvetica", showeq_params->fontsize));
   m_pStatList->addColumn("Stat");
   m_pStatList->addColumn("Val");
   m_pStatList->addColumn("Max");
   m_pStatList->addColumn("%");
//   m_pStatList->setMinimumWidth(100);
//   m_pStatList->setFixedHeight(120);

   statList[0] = new QListViewItem (m_pStatList,"Exp"  , "??" , "??", "?? %");
   statList[1] = new QListViewItem (m_pStatList,"HP"   , "??" , "??", "?? %");
   statList[2] = new QListViewItem (m_pStatList,"Mana" , "??" , "??", "?? %");
   statList[3] = new QListViewItem (m_pStatList,"Stam" , "??" , "??", "?? %");
   statList[4] = new QListViewItem (m_pStatList,"Food" , "??" , "??", "?? %");
   statList[5] = new QListViewItem (m_pStatList,"Watr" , "??" , "??", "?? %");

   // create the spawns list
////   QVBox* spawnlistbox = new QVBox(m_pSplitV);
////   m_pSpawnList = new QListView (spawnlistbox, "spawns");
//   m_pSpawnList = new QListView (m_pSplitV, "spawns");
   m_pSpawnList = new CSpawnList (m_pSplitV, "spawns");
// sort indicator in Qt2.1
//   m_pSpawnList->setShowSortIndicator(TRUE);
   m_pSpawnList->setRootIsDecorated(TRUE);
//   m_pSpawnList->setMultiSelection(TRUE);
   m_pSpawnList->setFont(QFont("Helvetica", showeq_params->fontsize));
   m_pSpawnList->addColumn ("Name");
   m_pSpawnList->addColumn ("Lvl");
   m_pSpawnList->addColumn ("Hp");
   m_pSpawnList->addColumn ("MaxHP");
   if(showeq_params->retarded_coords) {
     m_pSpawnList->addColumn ("N/S");
     m_pSpawnList->addColumn ("E/W");
   } else {
     m_pSpawnList->addColumn ("X");
     m_pSpawnList->addColumn ("Y");
   }
   m_pSpawnList->addColumn ("Z");
   m_pSpawnList->addColumn ("ID");
   m_pSpawnList->addColumn ("Dist");
   m_pSpawnList->addColumn ("Race");
   m_pSpawnList->addColumn ("Class");
   m_pSpawnList->addColumn ("Info");
//   m_pSpawnList->setMinimumWidth(200);
   m_pSpawnList->setAllColumnsShowFocus(TRUE);

   // Create our map object
//   QVBox* mapbox = new QVBox(m_pSplitH);
//   m_pMap = new Map (m_pSpawnList, mapbox, "map");
   m_pMap = new Map (m_pSpawnList, m_pSplitH, "map");

   // Create the packet object
   m_pPacket = new EQPacket (this, "packet");

   // Initialize the experience window;
   m_expWindow = new ExperienceWindow( m_pPacket );

   // Make the file menu
   QPopupMenu* pFileMenu = new QPopupMenu;
   pFileMenu->insertItem("&Open Map", m_pMap, SLOT(loadMap()), Key_F1);
   pFileMenu->insertItem("&Save Map", m_pMap, SLOT(saveMap()), Key_F2);

   if (pSEQPrefs->GetPrefBool("Filters_UseOldFilters", 0)) {
     pFileMenu->insertItem("&Reload Filters", 
			    m_pPacket, SLOT(initSpawnLists2()), Key_F3);
   } else {
     pFileMenu->insertItem("&Reload Filters", 
			    m_pMap, SLOT(loadFilters()), Key_F3);
   }


   pFileMenu->insertItem("&Save Filters", 
                   m_pMap, SLOT(saveFilters()), Key_F4);
   pFileMenu->insertItem("&List Filters", 
                   m_pMap, SLOT(listFilters()), ALT+Key_L);
   pFileMenu->insertItem("&Hide Selected", 
                   m_pSpawnList, SLOT(toggleHide()), CTRL+Key_H);
//   pFileMenu->insertItem("&UnHide All"         , 
//                   m_pMap, SLOT(UnHideAll()) , ALT+Key_H);
   pFileMenu->insertItem("Toggle Filter Selected",
                   m_pMap, SLOT(ToggleFilterSelected()) , CTRL+Key_F);
   pFileMenu->insertItem("Add Spawn Category",
                   this, SLOT(addCategory()) , ALT+Key_C);
   pFileMenu->insertItem("Rebuild SpawnList",
                   m_pMap, SLOT(rebuildSpawnList()) , ALT+Key_R);
   pFileMenu->insertItem("Reload Categories",
                   this, SLOT(reloadCategories()) , CTRL+Key_R);
   pFileMenu->insertItem("Dump &Spawns", 
                   m_pMap, SLOT(dumpSpawns()), CTRL+Key_S);
   pFileMenu->insertItem("Create MessageBox", 
                   this, SLOT(createMessageBox()), Key_F11);
   pFileMenu->insertItem("Toggle Debug", 
                   m_pMap, SLOT(toggleDebug()), Key_F12);
   pFileMenu->insertItem("Select Next", 
                   m_pMap, SLOT(selectNext()), CTRL+Key_Right);
   pFileMenu->insertItem("Select Prev", 
                   m_pMap, SLOT(selectPrev()), CTRL+Key_Left);
   if ( (showeq_params->playbackpackets)
       || (showeq_params->recordpackets)
      )
   {
     pFileMenu->insertItem("Inc Playback Speed", 
                   m_pPacket, SLOT(incPlayback()), Key_BracketRight);
     pFileMenu->insertItem("Dec Playback Speed", 
                   m_pPacket, SLOT(decPlayback()), Key_BracketLeft);
   }
   pFileMenu->insertItem("&Resync Network", 
                   m_pPacket, SLOT(Resync()));

   pFileMenu->insertItem("&Quit", qApp, SLOT(quit()));
   menuBar()->insertItem("&File", pFileMenu);

   // Make the map menu
   QPopupMenu* pMapMenu = new QPopupMenu;
   pMapMenu->insertItem("Add L&ocation", 
                   m_pMap, SLOT(addLocation()), Key_O);
   pMapMenu->insertItem("Add &Line", 
                   m_pMap, SLOT(startLine()), Key_L);
   pMapMenu->insertItem("Add Line &Point", 
                   m_pMap, SLOT(addLinePoint()), Key_P);
   pMapMenu->insertItem("&Del Line Point", 
                   m_pMap, SLOT(delLinePoint()), Key_D);
   pMapMenu->insertItem("Line properties...", 
                   m_pMap, SLOT(showLineDlg()), CTRL+Key_L);
   pMapMenu->insertItem("Zoom In", m_pMap, SLOT(ZoomIn()), Key_Plus);
   pMapMenu->insertItem("Zoom Out", m_pMap, SLOT(ZoomOut()), Key_Minus);
   pMapMenu->insertItem("Write &Spawn path", m_pMap, SLOT(makeSelectedSpawnLine()), CTRL+Key_T);

   menuBar()->insertItem("&Map", pMapMenu);

   // Make the log menu
   QPopupMenu* pLogMenu = new QPopupMenu;
   mid_log_AllPackets = pLogMenu->insertItem("All Packets"      , 
                   this, SLOT(toggle_log_AllPackets())  , Key_F5);
   mid_log_ZoneData   = pLogMenu->insertItem("Zone Data"        , 
                   this, SLOT(toggle_log_ZoneData())    , Key_F6);
   mid_log_UnknownData= pLogMenu->insertItem("Unkown Zone Data" , 
                   this, SLOT(toggle_log_UnknownData()) , Key_F7);
   pLogMenu->setCheckable(TRUE);
   menuBar()->insertItem("&Log", pLogMenu);
   logAllPackets = logZoneData = logUnknownData = FALSE;
   menuBar()->setItemChecked (mid_log_AllPackets , logAllPackets);
   menuBar()->setItemChecked (mid_log_ZoneData   , logZoneData);
   menuBar()->setItemChecked (mid_log_UnknownData, logUnknownData);
   m_pPacket->setLogAllPackets  (logAllPackets);
   m_pPacket->setLogZoneData    (logZoneData);
   m_pPacket->setLogUnknownData (logUnknownData);

   // Make the view menu
   QPopupMenu* pViewMenu = new QPopupMenu;
   mid_vew_ChannelMsgs = pViewMenu->insertItem("Channel Messages" , 
                   this, SLOT(toggle_vew_ChannelMsgs()));
   mid_vew_UnknownData = pViewMenu->insertItem("Unkown Data"      , 
                   this, SLOT(toggle_vew_UnknownData()) , Key_F8);
//   mid_vew_FilteredSpawns = pViewMenu->insertItem("&Filtered Spawns", 
//                   this, SLOT(toggle_vew_FilteredSpawns()) , Key_F9);
   mid_vew_HiddenSpawns = pViewMenu->insertItem("&Filtered Spawns", 
                   this, SLOT(toggle_vew_HiddenSpawns()) , Key_F10);
   mid_vew_ExpWindow = pViewMenu->insertItem("Experience Window", 
                   this, SLOT(toggle_vew_ExpWindow()) );
   pViewMenu->insertSeparator();
   mid_vew_SpawnList = pViewMenu->insertItem("SpawnList", 
                   this, SLOT(toggle_vew_SpawnList()) );
   mid_vew_PlayerStats = pViewMenu->insertItem("PlayerStats", 
                   this, SLOT(toggle_vew_PlayerStats()) );
   mid_vew_PlayerSkills = pViewMenu->insertItem("PlayerSkills",
                   this,SLOT(toggle_vew_PlayerSkills()) );
   mid_vew_Compass = pViewMenu->insertItem("Compass", 
                   this, SLOT(toggle_vew_Compass()) );
   mid_vew_Map = pViewMenu->insertItem("Map", 
                   this, SLOT(toggle_vew_Map()) );
   pViewMenu->insertSeparator();
   pViewMenu->setCheckable(TRUE);
   menuBar()->insertItem("&View", pViewMenu);
   viewChannelMsgs = TRUE;
   viewUnknownData = FALSE;
   viewFilteredSpawns = FALSE;
   viewHiddenSpawns = FALSE;
   viewExpWindow = false;
   menuBar()->setItemChecked (mid_vew_ChannelMsgs, viewChannelMsgs);
   menuBar()->setItemChecked (mid_vew_UnknownData, viewUnknownData);
//   menuBar()->setItemChecked (mid_vew_FilteredSpawns, viewFilteredSpawns);
   menuBar()->setItemChecked (mid_vew_HiddenSpawns, viewHiddenSpawns);
   menuBar()->setItemChecked (mid_vew_ExpWindow, viewExpWindow);
   menuBar()->setItemChecked (mid_vew_SpawnList, 
                         pSEQPrefs->GetPrefBool("Interface_ShowSpawnList"));
   menuBar()->setItemChecked (mid_vew_PlayerStats, 
                         pSEQPrefs->GetPrefBool("Interface_ShowPlayerStats"));
   menuBar()->setItemChecked (mid_vew_PlayerSkills, 
                         pSEQPrefs->GetPrefBool("Interface_ShowPlayerSkills"));
   menuBar()->setItemChecked (mid_vew_Compass, 
                         pSEQPrefs->GetPrefBool("Interface_ShowCompass"));
   menuBar()->setItemChecked (mid_vew_Map, 
                         pSEQPrefs->GetPrefBool("Interface_ShowMap"));
   if (!pSEQPrefs->GetPrefBool("Interface_ShowSpawnList"))
     m_pSpawnList->hide();
   if (!pSEQPrefs->GetPrefBool("Interface_ShowPlayerStats"))
     m_pStatList->hide();
   if (!pSEQPrefs->GetPrefBool("Interface_ShowPlayerSkills"))
     m_pSkillList->hide();
   if (!pSEQPrefs->GetPrefBool("Interface_ShowCompass"))
     m_pCompass->hide();
   if (!pSEQPrefs->GetPrefBool("Interface_ShowMap"))
     m_pMap->hide();

   m_pPacket->setViewChannelMsgs (viewChannelMsgs);
   m_pPacket->setViewUnknownData (viewUnknownData);

   // Make the options menu
   QPopupMenu* pOptMenu = new QPopupMenu;
   mid_opt_Velocity = pOptMenu->insertItem("Show Velocity Lines",
                   this, SLOT(toggle_opt_Velocity()));
   mid_opt_Animate  = pOptMenu->insertItem("Animate Spawn Movement", 
                   this, SLOT(toggle_opt_Animate()));
   mid_opt_Fast     = pOptMenu->insertItem("Fast Machine?", 
                   this, SLOT(toggle_opt_Fast()));
   mid_opt_ConSelect = pOptMenu->insertItem("Select on Consider?", 
                   this, SLOT(toggle_opt_ConSelect()));
   mid_opt_KeepSelectedVisible = 
                       pOptMenu->insertItem("Keep Selected Visible?"  , 
                   this, SLOT(toggle_opt_KeepSelectedVisible()));
   mid_opt_SparrMessages = pOptMenu->insertItem("Show Sparrs messages", 
                   this, SLOT(toggle_opt_SparrMessages()));
   mid_opt_LogSpawns = pOptMenu->insertItem("Log Spawns", 
                   this, SLOT(toggle_opt_LogSpawns()));
   pOptMenu->setCheckable(TRUE);
   menuBar()->insertItem("&Options", pOptMenu);
   menuBar()->setItemChecked (mid_opt_Velocity, showeq_params->velocity);
   menuBar()->setItemChecked (mid_opt_Animate , showeq_params->animate);
   menuBar()->setItemChecked (mid_opt_Fast    , 
                   showeq_params->fast_machine);
   menuBar()->setItemChecked (mid_opt_ConSelect, 
                   showeq_params->con_select);
   menuBar()->setItemChecked (mid_opt_KeepSelectedVisible, 
                   showeq_params->keep_selected_visible);
   menuBar()->setItemChecked (mid_opt_SparrMessages, 
                   showeq_params->sparr_messages);
   menuBar()->setItemChecked (mid_opt_LogSpawns, 
                   showeq_params->logSpawns);

// Wally59: Took these out...
// JohnQ Put em back

   if(showeq_params->net_stats) {
     QVBox *NetInfo = new QVBox(NULL);
     QLCDNumber* pCounter = new QLCDNumber (7, NetInfo, "pkts");
     pCounter->setSegmentStyle (QLCDNumber::Flat);
     QLCDNumber* pSeqexp = new QLCDNumber (7, NetInfo, "seqexp");
     pSeqexp->setSegmentStyle (QLCDNumber::Flat);
     pSeqexp->setHexMode ();
     QLCDNumber* pSeqcur = new QLCDNumber (7, NetInfo, "seqcur");
     pSeqcur->setSegmentStyle (QLCDNumber::Flat);
     pSeqcur->setHexMode ();
     connect (m_pPacket, SIGNAL (packetReceived (int)), pCounter, 
                                                 SLOT (display (int)));
     connect (m_pPacket, SIGNAL (seqExpect (int)), pSeqexp, SLOT (display (int)));
     connect (m_pPacket, SIGNAL (seqReceive (int)), pSeqcur, SLOT (display (int)));
     NetInfo->show();
   }

   // Now hook up all the signals and slots
   connect (m_pPacket, SIGNAL(headingChanged(int)), 
           pCompass, SLOT(setAngle(int)));
   connect (m_pPacket, SIGNAL(playerChanged(int,int,int,int,int,int,int)),  
           pCompass, SLOT(setPlayer(int,int,int,int,int,int,int)));
   connect (m_pMap, SIGNAL(selSpawnUpdate(int,int)),  
           pCompass, SLOT(selSpawnUpdate(int,int)));
   connect (m_pSpawnList, SIGNAL(selectionChanged(QListViewItem *)),  
           pCompass, SLOT(selectSpawn(QListViewItem *)));
   connect(m_pPacket, SIGNAL(newSpawn(spawnStruct *, int)),
	   m_pMap,    SLOT  (newSpawn(spawnStruct *, int)));
   connect (m_pPacket, SIGNAL(headingChanged(int)),  
           m_pMap, SLOT(setAngle(int)));
   connect (m_pPacket, SIGNAL(playerChanged(int,int,int,int,int,int,int)),  
           m_pMap, SLOT(setPlayer(int,int,int,int,int,int,int)));
   connect (m_pPacket, SIGNAL(setPlayerLevel(int)),  
           m_pMap, SLOT(setPlayerLevel(int)));
   connect (m_pPacket, SIGNAL(setPlayerRace(int)),  
           m_pMap, SLOT(setPlayerRace(int)));
   connect (m_pPacket, SIGNAL(setPlayerClass(int)),  
           m_pMap, SLOT(setPlayerClass(int)));
   connect (m_pPacket, SIGNAL(setPlayerID(int)),  
           m_pMap, SLOT(setPlayerID(int)));
   connect (m_pPacket, SIGNAL(updateSpawn(int,int,int,int,int,int,int)),  
           m_pMap, SLOT(updateSpawn(int,int,int,int,int,int,int)));
   connect (m_pPacket, SIGNAL(spawnWearingUpdate(wearChangeStruct *)),  
           m_pMap, SLOT(spawnWearingUpdate(wearChangeStruct *)));

   connect (m_pPacket, SIGNAL(attack1Hand1(attack1Struct *)),  
           m_pMap, SLOT(attack1Hand1(attack1Struct *)));
   connect (m_pPacket, SIGNAL(attack2Hand1(attack2Struct *)),  
           m_pMap, SLOT(attack2Hand1(attack2Struct *)));

   connect (m_pPacket, SIGNAL(consMessage(considerStruct *)),  
           m_pMap, SLOT(consMessage(considerStruct *)));

   connect (m_pPacket, SIGNAL(updateSpawnHp(int,int,int)),  
           m_pMap, SLOT(updateSpawnHp(int,int,int)));

   connect (m_pPacket, SIGNAL(newGroundItem (dropThingOnGround *)),  
           m_pMap, SLOT(newGroundItem (dropThingOnGround *)));
   connect (m_pPacket, SIGNAL(removeGroundItem(removeThingOnGround*)),  
           m_pMap, SLOT(removeGroundItem(removeThingOnGround*)));

   connect (m_pPacket, SIGNAL(newCoinsItem (dropCoinsStruct *)),  
           m_pMap, SLOT(newCoinsItem (dropCoinsStruct *)));
   connect (m_pPacket, SIGNAL(removeCoinsItem(removeCoinsStruct *)),  
           m_pMap, SLOT(removeCoinsItem(removeCoinsStruct *)));

   connect (m_pPacket, SIGNAL(refreshMap(void)),  
           m_pMap, SLOT(refreshMap(void)));
   connect (m_pPacket, SIGNAL(deleteSpawn(int)),  
           m_pMap, SLOT(deleteSpawn(int)));
   connect (m_pPacket, SIGNAL(killSpawn (int)),  
           m_pMap, SLOT (killSpawn (int)));
   connect (m_pPacket, SIGNAL(infoSpawn(int)),  
           m_pMap, SLOT(infoSpawn(int)));
   connect (m_pPacket, SIGNAL(newZone(char *,char *)),  
           m_pMap, SLOT(newZone(char *, char *)));
   connect (m_pMap, SIGNAL(deleteSkills()), this, SLOT(deleteSkills()));
   connect (m_pPacket, SIGNAL(zoneChanged(void)),  
           m_pMap, SLOT(zoneChanged(void)));
   connect (m_pPacket, SIGNAL(xposChanged(const QString&)),  
           xPos, SLOT(setText(const QString&)));
   connect (m_pPacket, SIGNAL(yposChanged(const QString&)),  
           yPos, SLOT(setText(const QString&)));
   connect (m_pPacket, SIGNAL(zposChanged(const QString&)),  
           zPos, SLOT(setText(const QString&)));

   connect (m_pPacket, SIGNAL(addGroup(char*, int)),  
           m_pMap, SLOT(addGroup(char*, int)));
   connect (m_pPacket, SIGNAL(remGroup(char*, int)),  
           m_pMap, SLOT(remGroup(char*, int)));
   connect (m_pPacket, SIGNAL(clrGroup()),  
           m_pMap, SLOT(clrGroup()));

   if (m_stsbarZone)
   {
     connect (m_pMap, SIGNAL(newZoneName(const QString&)),  
             m_stsbarZone, SLOT(setText(const QString&)));
   }

   if (m_stsbarExp)
   {
     connect (m_pPacket, SIGNAL(expChangedStr(const QString&)),  
             m_stsbarExp, SLOT(setText(const QString&)));
     connect (m_pPacket, SIGNAL(expChangedStr(const QString&)), 
             m_stsbarExp, SLOT(setText(const QString&)));
   }
   connect (m_pPacket, SIGNAL(expChangedInt(int,int,int)),   
           this, SLOT(expChanged(int,int,int)));
   connect (m_pMap   , SIGNAL(hpChanged(int,int)),    
           this, SLOT(hpChanged(int,int)));
   connect (m_pPacket, SIGNAL(stamChanged(int,int,int,int,int,int)),  
           this, SLOT(stamChanged(int,int,int,int,int,int)));
   connect (m_pPacket, SIGNAL(manaChanged(int,int)),  
           this, SLOT(manaChanged(int,int)));
   connect (m_pPacket, SIGNAL(addSkill(int,int)),  
           this, SLOT(addSkill(int,int)));
   connect (m_pPacket, SIGNAL(changeSkill(int,int)),  
           this, SLOT(changeSkill(int,int)));
//   connect (m_pMap, SIGNAL(deSpawnAlert(char*)), 
//           m_pPacket, SLOT(deSpawnAlert(char*)));
   connect (m_pPacket, SIGNAL(expGained(const QString &, int, long, QString )),
           m_expWindow, SLOT(addExpRecord(const QString &, int, long,
           QString )));
//   connect (this  , SIGNAL(ShowFilteredSpawns(int)),  
//           m_pMap, SLOT(ShowFilteredSpawns(int)));
   connect (this  , SIGNAL(ShowHidden(int)),  
           m_pMap, SLOT(ShowHidden(int)));
   if (m_stsbarStatus)
   {
     connect (m_pMap, SIGNAL(stsMessage(const QString &, int)),  
             this, SLOT(stsMessage(const QString &, int)));
     connect (m_pPacket, SIGNAL(stsMessage(const QString &, int)),  
             this, SLOT(stsMessage(const QString &, int)));
   }
   if (m_stsbarSpawns)
   {
     connect (m_pMap, SIGNAL(numSpawns_(int)),  
             this, SLOT(numSpawns_(int)));
   }
   if (m_stsbarPkt)
   {
     connect (m_pPacket, SIGNAL(numPacket(int)),  
             this, SLOT(numPacket(int)));
   }

   if (m_pSpawnList)
   {
     connect (m_pSpawnList, SIGNAL(selectionChanged(QListViewItem *)),  
           m_pMap, SLOT(selectSpawn(QListViewItem *)));
     connect (m_pSpawnList, SIGNAL(listUpdated()),  
           m_pMap, SLOT(spawnListUpdated()));
     connect (m_pSpawnList, SIGNAL(listChanged()),  
           m_pMap, SLOT(rebuildSpawnList()));
     connect (m_pSpawnList, SIGNAL(rightButtonPressed( QListViewItem *, 
           const QPoint&, int )),
           m_pMap, SLOT(rightButtonPressed(QListViewItem*, 
           const QPoint&, int)) );  
     connect (m_pSpawnList, SIGNAL(rightButtonPressed( QListViewItem *, 
           const QPoint&, int )),
           this, SLOT(spawnListRightButton(QListViewItem*, 
           const QPoint&, int)) );  
     connect (m_pSpawnList, SIGNAL(rightButtonClicked( QListViewItem *, 
           const QPoint&, int )),
           m_pMap, SLOT(rightButtonReleased(QListViewItem*, 
           const QPoint&, int)) );  
   }



   // set initial view options
   emit ShowHidden(viewHiddenSpawns);
   if (pSEQPrefs->GetPrefBool("Interface_ShowExpWindow"))
      toggle_vew_ExpWindow();

   /* Start the packet capturing */
   m_pPacket->start (10);

   /* Update the map when we have free time if we are animating */
   mapTimer = new QTimer(this);
   connect(mapTimer, SIGNAL(timeout()), m_pMap, SLOT(refreshMap()));

   if(showeq_params->fast_machine)
     mapTimer->start(1000/showeq_params->framerate,FALSE);

   // Create message boxes defined in config preferences
   char *title = 0;
   int i = 0;
   int j = 0;
   MsgDialog* pMsgDlg;
   for(i = 1; i < 15; i++)
   {
      // attempt to pull a button title from the preferences
      sprintf(tempStr, "MessageBox%d_Title", i);
      if (pSEQPrefs->isPreference(tempStr))
      {
          title = strdup(pSEQPrefs->GetPrefString(tempStr));
//        pMsgDlg = new MsgDialog(topLevelWidget(), title, m_StringList);
//        pMsgDlg = new MsgDialog(this, title, m_StringList);
        // using the parentWidget makes this messagebox isolated from the
        // main application
        pMsgDlg = new MsgDialog(parentWidget(), title, m_StringList);
        m_msgDialogList.append(pMsgDlg);

        // connect signal for new messages
        connect (this, SIGNAL (newMessage(int)), 
           pMsgDlg, SLOT (newMessage(int)));

        // set Additive mode
        sprintf(tempStr, "MessageBox%d_Additive", i);
        pMsgDlg->setAdditive(pSEQPrefs->GetPrefBool(tempStr)); 

        // set control mode
        sprintf(tempStr, "MessageBox%d_HideControls", i);
        pMsgDlg->showControls(!pSEQPrefs->GetPrefBool(tempStr)); 

        // set Msg Type mode
        sprintf(tempStr, "MessageBox%d_ShowMsgType", i);
        pMsgDlg->showMsgType(pSEQPrefs->GetPrefBool(tempStr)); 

        // Configure buttons
        for(j = 1; j < 15; j++)
        {
          bool name = FALSE;
          bool filter = FALSE;

          // attempt to pull button description from the preferences
          sprintf(tempStr, "MessageBox%d_Button%dName", i, j);
          name = pSEQPrefs->isPreference(tempStr);
          QString buttonname(pSEQPrefs->GetPrefString(tempStr)); 
          sprintf(tempStr, "MessageBox%d_Button%dFilter", i, j);
          filter = pSEQPrefs->isPreference(tempStr);
          QString buttonfilter(pSEQPrefs->GetPrefString(tempStr));
          sprintf(tempStr, "MessageBox%d_Button%dColor", i, j);
          QString buttoncolor(pSEQPrefs->GetPrefString(tempStr));
          sprintf(tempStr, "MessageBox%d_Button%dActive", i, j);

          // if we have a name and filter string
          if (name && filter)
          {
            // Add the button
            pMsgDlg->addButton(buttonname, buttonfilter, 
                  buttoncolor, pSEQPrefs->GetPrefBool(tempStr)); 
          }
          else
          {
             if (name || filter)
             {
               fprintf(stderr, "Error: Incomplete definition of Button '%s'\n",
                  title);
             }
// allow skipped numbers
//             break; // no more buttons
          }

        } // end for buttons

        // set Geometry
        QSize s = pMsgDlg->size();
        QPoint p = pMsgDlg->pos();
        int x,y,w,h;
        sprintf(tempStr, "MessageBox%d_WindowX", i);
        x = pSEQPrefs->GetPrefInt(tempStr, p.x() ); 
        sprintf(tempStr, "MessageBox%d_WindowY", i);
        y = pSEQPrefs->GetPrefInt(tempStr, p.y() ); 
        sprintf(tempStr, "MessageBox%d_WindowW", i);
        w = pSEQPrefs->GetPrefInt(tempStr, s.width() ); 
        sprintf(tempStr, "MessageBox%d_WindowH", i);
        h = pSEQPrefs->GetPrefInt(tempStr, s.height() ); 
        pMsgDlg->resize(w,h);
        pMsgDlg->show();
        if (pSEQPrefs->GetPrefBool("Interface_UseWindowPos", 0))
          pMsgDlg->move(x,y);
        
        free(title);

      } // end if dialog config section found

// allow skipped numbers
//      else
//        break;

   } // for all message boxes defined in pref file

   // connect signals for receiving string messages
   connect (m_pPacket, SIGNAL (msgReceived(const QString &)), 
           this, SLOT (msgReceived(const QString &)));
   connect (m_pMap, SIGNAL (msgReceived(const QString &)), 
           this, SLOT (msgReceived(const QString &)));


   //
   // Geometry Configuration
   //
   QSize s;
   QPoint p;

   // SpawnList column sizes
   if (m_pSpawnList)
   {
      sprintf(tempStr, "SpawnList_NameWidth");
      if (pSEQPrefs->isPreference(tempStr)) 
      {
        x = pSEQPrefs->GetPrefInt(tempStr, m_pSpawnList->columnWidth(0)); 
        m_pSpawnList->setColumnWidthMode(0, QListView::Manual);
        m_pSpawnList->setColumnWidth(0, x);
      }
      sprintf(tempStr, "SpawnList_LevelWidth");
      if (pSEQPrefs->isPreference(tempStr)) 
      {
        x = pSEQPrefs->GetPrefInt(tempStr, m_pSpawnList->columnWidth(1)); 
        m_pSpawnList->setColumnWidth(1, x);
        m_pSpawnList->setColumnWidthMode(1, QListView::Manual);
      }
      sprintf(tempStr, "SpawnList_HPWidth");
      if (pSEQPrefs->isPreference(tempStr)) 
      {
        x = pSEQPrefs->GetPrefInt(tempStr, m_pSpawnList->columnWidth(2)); 
        m_pSpawnList->setColumnWidth(2, x);
        m_pSpawnList->setColumnWidthMode(2, QListView::Manual);
      }
      sprintf(tempStr, "SpawnList_MaxHPWidth");
      if (pSEQPrefs->isPreference(tempStr)) 
      {
        x = pSEQPrefs->GetPrefInt(tempStr, m_pSpawnList->columnWidth(3)); 
        m_pSpawnList->setColumnWidth(3, x);
        m_pSpawnList->setColumnWidthMode(3, QListView::Manual);
      }
      sprintf(tempStr, "SpawnList_Coord1Width");
      if (pSEQPrefs->isPreference(tempStr)) 
      {
        x = pSEQPrefs->GetPrefInt(tempStr, m_pSpawnList->columnWidth(4)); 
        m_pSpawnList->setColumnWidth(4, x);
        m_pSpawnList->setColumnWidthMode(4, QListView::Manual);
      }
      sprintf(tempStr, "SpawnList_Coord2Width");
      if (pSEQPrefs->isPreference(tempStr)) 
      {
        x = pSEQPrefs->GetPrefInt(tempStr, m_pSpawnList->columnWidth(5)); 
        m_pSpawnList->setColumnWidth(5, x);
        m_pSpawnList->setColumnWidthMode(5, QListView::Manual);
      }
      sprintf(tempStr, "SpawnList_Coord3Width");
      if (pSEQPrefs->isPreference(tempStr)) 
      {
        x = pSEQPrefs->GetPrefInt(tempStr, m_pSpawnList->columnWidth(6)); 
        m_pSpawnList->setColumnWidth(6, x);
        m_pSpawnList->setColumnWidthMode(6, QListView::Manual);
      }
      sprintf(tempStr, "SpawnList_IDWidth");
      if (pSEQPrefs->isPreference(tempStr)) 
      {
        x = pSEQPrefs->GetPrefInt(tempStr, m_pSpawnList->columnWidth(7)); 
        m_pSpawnList->setColumnWidth(7, x);
        m_pSpawnList->setColumnWidthMode(7, QListView::Manual);
      }
      sprintf(tempStr, "SpawnList_DistWidth");
      if (pSEQPrefs->isPreference(tempStr)) 
      {
        x = pSEQPrefs->GetPrefInt(tempStr, m_pSpawnList->columnWidth(8)); 
        m_pSpawnList->setColumnWidth(8, x);
        m_pSpawnList->setColumnWidthMode(8, QListView::Manual);
      }
      sprintf(tempStr, "SpawnList_RaceWidth");
      if (pSEQPrefs->isPreference(tempStr)) 
      {
        x = pSEQPrefs->GetPrefInt(tempStr, m_pSpawnList->columnWidth(9)); 
        m_pSpawnList->setColumnWidth(9, x);
        m_pSpawnList->setColumnWidthMode(9, QListView::Manual);
      }
      sprintf(tempStr, "SpawnList_ClassWidth");
      if (pSEQPrefs->isPreference(tempStr)) 
      {
        x = pSEQPrefs->GetPrefInt(tempStr, m_pSpawnList->columnWidth(10)); 
        m_pSpawnList->setColumnWidth(10, x);
        m_pSpawnList->setColumnWidthMode(10, QListView::Manual);
      }
      sprintf(tempStr, "SpawnList_InfoWidth");
      if (pSEQPrefs->isPreference(tempStr)) 
      {
        x = pSEQPrefs->GetPrefInt(tempStr, m_pSpawnList->columnWidth(11)); 
        m_pSpawnList->setColumnWidth(11, x);
        m_pSpawnList->setColumnWidthMode(11, QListView::Manual);
      }
   }

   // SkillList column sizes
   if (m_pSkillList)
   {
      sprintf(tempStr, "SkillList_SkillWidth");
      if (pSEQPrefs->isPreference(tempStr)) 
      {
        x = pSEQPrefs->GetPrefInt(tempStr, m_pSkillList->columnWidth(0)); 
        m_pSkillList->setColumnWidthMode(0, QListView::Manual);
        m_pSkillList->setColumnWidth(0, x);
      }
      sprintf(tempStr, "SkillList_ValueWidth");
      if (pSEQPrefs->isPreference(tempStr)) 
      {
        x = pSEQPrefs->GetPrefInt(tempStr, m_pSkillList->columnWidth(1)); 
        m_pSkillList->setColumnWidthMode(1, QListView::Manual);
        m_pSkillList->setColumnWidth(1, x);
      }
   }


   // StatList column sizes
   if (m_pStatList)
   {
      sprintf(tempStr, "StatList_StatWidth");
      if (pSEQPrefs->isPreference(tempStr)) 
      {
        x = pSEQPrefs->GetPrefInt(tempStr, m_pStatList->columnWidth(0)); 
        m_pStatList->setColumnWidthMode(0, QListView::Manual);
        m_pStatList->setColumnWidth(0, x);
      }
      sprintf(tempStr, "StatList_ValueWidth");
      if (pSEQPrefs->isPreference(tempStr)) 
      {
        x = pSEQPrefs->GetPrefInt(tempStr, m_pStatList->columnWidth(1)); 
        m_pStatList->setColumnWidthMode(1, QListView::Manual);
        m_pStatList->setColumnWidth(1, x);
      }
      sprintf(tempStr, "StatList_MaxWidth");
      if (pSEQPrefs->isPreference(tempStr)) 
      {
        x = pSEQPrefs->GetPrefInt(tempStr, m_pStatList->columnWidth(2)); 
        m_pStatList->setColumnWidthMode(2, QListView::Manual);
        m_pStatList->setColumnWidth(2, x);
      }
      sprintf(tempStr, "StatList_PercentWidth");
      if (pSEQPrefs->isPreference(tempStr)) 
      {
        x = pSEQPrefs->GetPrefInt(tempStr, m_pStatList->columnWidth(2)); 
        m_pStatList->setColumnWidthMode(3, QListView::Manual);
        m_pStatList->setColumnWidth(3, x);
      }
   }


   //  Add Category filters to spanwlist from config
   reloadCategories();

   // interface components
#if 1
  // Restore splitter sizes
  QValueList<int> list;
  i = 0;
  for(;;)
  {
    i++;
    sprintf(tempStr, "Interface_SplitV_Size%d", i);
    if (pSEQPrefs->isPreference(tempStr))
    {
      x = pSEQPrefs->GetPrefInt(tempStr);
#ifdef DEBUG
printf("'%s' %d\n", tempStr, x);
#endif
      list.append(x);
    }
    else break;
  }
  m_pSplitV->setSizes(list);
  list.clear();
  i = 0;
  for(;;)
  {
    i++;
    sprintf(tempStr, "Interface_SplitH_Size%d", i);
    if (pSEQPrefs->isPreference(tempStr))
    {
      x = pSEQPrefs->GetPrefInt(tempStr);
#ifdef DEBUG
printf("'%s' %d\n", tempStr, x);
#endif
      list.append(x);
    }
    else break;
  }
  m_pSplitH->setSizes(list);
  list.clear();
  i = 0;
  for(;;)
  {
    i++;
    sprintf(tempStr, "Interface_SplitT_Size%d", i);
    if (pSEQPrefs->isPreference(tempStr))
    {
      x = pSEQPrefs->GetPrefInt(tempStr);
#ifdef DEBUG
printf("'%s' %d\n", tempStr, x);
#endif
      list.append(x);
    }
    else break;
  }
  m_pSplitT->setSizes(list);
#endif

   // have to display window before we can move it
   // for some reason you can't call setGeometry twice (ignores 2nd call)
   // so use 'resize' first then show it, then move it... to minimize 
   // repaints

   // set mainwindow Geometry
   s = size();
   p = pos();
   sprintf(tempStr, "Interface_WindowX");
   x = pSEQPrefs->GetPrefInt(tempStr, p.x() ); 
   sprintf(tempStr, "Interface_WindowY");
   y = pSEQPrefs->GetPrefInt(tempStr, p.y() ); 
   sprintf(tempStr, "Interface_WindowW");
   w = pSEQPrefs->GetPrefInt(tempStr, s.width() ); 
   sprintf(tempStr, "Interface_WindowH");
   h = pSEQPrefs->GetPrefInt(tempStr, s.height() ); 
#ifdef DEBUG
printf("Resizing %d/%d\n", w, h);
#endif
   resize(w,h);


   show();

   // Sorry Maerlyn, I commented this out since it restores
   // the window location without taking the window decorations
   // into account, which moves the window up each time you restart
   // it.
   
   // put this back in via a config option - I'll attempt to get this working
   // on window managers other than KDE later (maybe).  It works great for KDE
   if (pSEQPrefs->GetPrefBool("Interface_UseWindowPos", 0))
   {
#ifdef DEBUG
      printf("Moving window to %d/%d\n", x, y);
#endif
      move(x,y);
   }


   // set caption if we have a nonstandard one 
   // (lets you put config name etc in caption)
   sprintf(tempStr, "Interface_Title");
   if (pSEQPrefs->isPreference(tempStr))
      setCaption(QString(pSEQPrefs->GetPrefString(tempStr)));

} // end constructor


//
// save prefs
//
void
EQInterface::savePrefs(void)
{
  char tempStr[256];
  QRect r;

   // save spawnlist label geometries
   sprintf(tempStr, "SpawnList_SaveWidth");
   if (m_pSpawnList && m_pSpawnList->isVisible() &&
       pSEQPrefs->GetPrefBool(tempStr, 1))
   {
      sprintf(tempStr, "SpawnList_NameWidth");
      pSEQPrefs->SetPrefValue(tempStr, m_pSpawnList->columnWidth(0)); 
      sprintf(tempStr, "SpawnList_LevelWidth");
      pSEQPrefs->SetPrefValue(tempStr, m_pSpawnList->columnWidth(1)); 
      sprintf(tempStr, "SpawnList_HPWidth");
      pSEQPrefs->SetPrefValue(tempStr, m_pSpawnList->columnWidth(2)); 
      sprintf(tempStr, "SpawnList_MaxHPWidth");
      pSEQPrefs->SetPrefValue(tempStr, m_pSpawnList->columnWidth(3)); 
      sprintf(tempStr, "SpawnList_Coord1Width");
      pSEQPrefs->SetPrefValue(tempStr, m_pSpawnList->columnWidth(4)); 
      sprintf(tempStr, "SpawnList_Coord2Width");
      pSEQPrefs->SetPrefValue(tempStr, m_pSpawnList->columnWidth(5)); 
      sprintf(tempStr, "SpawnList_Coord3Width");
      pSEQPrefs->SetPrefValue(tempStr, m_pSpawnList->columnWidth(6)); 
      sprintf(tempStr, "SpawnList_IDWidth");
      pSEQPrefs->SetPrefValue(tempStr, m_pSpawnList->columnWidth(7)); 
      sprintf(tempStr, "SpawnList_DistWidth");
      pSEQPrefs->SetPrefValue(tempStr, m_pSpawnList->columnWidth(8)); 
      sprintf(tempStr, "SpawnList_RaceWidth");
      pSEQPrefs->SetPrefValue(tempStr, m_pSpawnList->columnWidth(9)); 
      sprintf(tempStr, "SpawnList_ClassWidth");
      pSEQPrefs->SetPrefValue(tempStr, m_pSpawnList->columnWidth(10)); 
      sprintf(tempStr, "SpawnList_InfoWidth");
      pSEQPrefs->SetPrefValue(tempStr, m_pSpawnList->columnWidth(11)); 
   }


   // save statlist label geometries
   sprintf(tempStr, "StatList_SaveWidth");
   if (m_pStatList && m_pStatList->isVisible() &&
       pSEQPrefs->GetPrefBool(tempStr, 1))
   {
      sprintf(tempStr, "StatList_StatWidth");
      pSEQPrefs->SetPrefValue(tempStr, m_pStatList->columnWidth(0)); 
      sprintf(tempStr, "StatList_ValueWidth");
      pSEQPrefs->SetPrefValue(tempStr, m_pStatList->columnWidth(1)); 
      sprintf(tempStr, "StatList_MaxWidth");
      pSEQPrefs->SetPrefValue(tempStr, m_pStatList->columnWidth(2)); 
   }

   // save skilllist label geometries
   sprintf(tempStr, "SkillList_SaveWidth");
   if (m_pSkillList && m_pSkillList->isVisible() &&
       pSEQPrefs->GetPrefBool(tempStr, 1))
   {
      sprintf(tempStr, "SkillList_SkillWidth");
      pSEQPrefs->SetPrefValue(tempStr, m_pSkillList->columnWidth(0)); 
      sprintf(tempStr, "SkillList_ValueWidth");
      pSEQPrefs->SetPrefValue(tempStr, m_pSkillList->columnWidth(1)); 
   }

  // save message dialog geometries
  MsgDialog* diag;
  int i = 0;
  int x,y;

  sprintf(tempStr, "Interface_WindowXOffset");
  x = pSEQPrefs->GetPrefInt(tempStr, 0);
  sprintf(tempStr, "Interface_WindowYOffset");
  y = pSEQPrefs->GetPrefInt(tempStr, 0);

  for (diag=m_msgDialogList.first(); diag != 0; diag=m_msgDialogList.next() )
  {
    // determine the message box number from the config file
    for(i=1; i<15; i++)
    {
      sprintf(tempStr, "MessageBox%d_Title", i);
      if (!strcmp(pSEQPrefs->GetPrefString(tempStr,""), diag->name()) )
         break;
    }
        
    // get geometry from dialog
    r = diag->frameGeometry();
    // enlightenment
//    r = diag->topLevelWidget()->geometry();  // x,y take into account frame

    sprintf(tempStr, "MessageBox%d_WindowX", i);
    if (pSEQPrefs->isPreference(tempStr))
      pSEQPrefs->SetPrefValue(tempStr, r.left() + x);
    sprintf(tempStr, "MessageBox%d_WindowY", i);
    if (pSEQPrefs->isPreference(tempStr))
      pSEQPrefs->SetPrefValue(tempStr, r.top() + y);

    sprintf(tempStr, "MessageBox%d_WindowW", i);
    if (pSEQPrefs->isPreference(tempStr))
      pSEQPrefs->SetPrefValue(tempStr, diag->width());
    sprintf(tempStr, "MessageBox%d_WindowH", i);
    if (pSEQPrefs->isPreference(tempStr))
      pSEQPrefs->SetPrefValue(tempStr, diag->height());
  }
  // save main interface geometry (only save if these configs are present)
  r = frameGeometry();  // x,y take into account frame
// enlightenment
//  r = topLevelWidget()->geometry();  // x,y take into account frame
  sprintf(tempStr, "Interface_WindowX");
  if (pSEQPrefs->isPreference(tempStr))
    pSEQPrefs->SetPrefValue(tempStr, r.left() + x);
  sprintf(tempStr, "Interface_WindowY");
  if (pSEQPrefs->isPreference(tempStr))
    pSEQPrefs->SetPrefValue(tempStr, r.top() + y);

  sprintf(tempStr, "Interface_WindowW");
  if (pSEQPrefs->isPreference(tempStr))
    pSEQPrefs->SetPrefValue(tempStr, width());
  sprintf(tempStr, "Interface_WindowH");
  if (pSEQPrefs->isPreference(tempStr))
    pSEQPrefs->SetPrefValue(tempStr, height());
#ifdef DEBUG
printf("Saving W/H %d/%d\n", width(), height());
#endif
  

#if 1
  QValueList<int> list = m_pSplitV->sizes();
  QValueList<int>::Iterator it = list.begin();
  i = 0;
  while(it != list.end())
  {
    i++;
    sprintf(tempStr, "Interface_SplitV_Size%d", i);
    pSEQPrefs->SetPrefValue(tempStr, *it);
#ifdef DEBUG
printf("Saving SplitV%d: %d\n", i, *it);
#endif
    ++it;
  }
  list = m_pSplitH->sizes();
  it = list.begin();
  i = 0;
  while(it != list.end())
  {
    i++;
    sprintf(tempStr, "Interface_SplitH_Size%d", i);
    pSEQPrefs->SetPrefValue(tempStr, *it);
#ifdef DEBUG
printf("Saving SplitH%d: %d\n", i, *it);
#endif
    ++it;
  }
  list = m_pSplitT->sizes();
  it = list.begin();
  i = 0;
  while(it != list.end())
  {
    i++;
    sprintf(tempStr, "Interface_SplitT_Size%d", i);
    pSEQPrefs->SetPrefValue(tempStr, *it);
#ifdef DEBUG
printf("Saving SplitT%d: %d\n", i, *it);
#endif
    ++it;
  }
#endif

  // save visible state of interface objects
  pSEQPrefs->SetPrefValue("Interface_ShowPlayerSkills", 
                                m_pSkillList->isVisible() );
  pSEQPrefs->SetPrefValue("Interface_ShowPlayerStats", 
                                m_pStatList->isVisible() );
  pSEQPrefs->SetPrefValue("Interface_ShowCompass", 
                                m_pCompass->isVisible() );
  pSEQPrefs->SetPrefValue("Interface_ShowSpawnList", 
                                m_pSpawnList->isVisible() );
  pSEQPrefs->SetPrefValue("Interface_ShowMap", 
                                m_pMap->isVisible() );

  // save prefs to file
  pSEQPrefs->Save();

} // end savePrefs 


/* Capture resize events and reset the geometry */
void
EQInterface::resizeEvent (QResizeEvent *e)
{
}


/* Check and uncheck Opt menu options */
void
EQInterface::toggle_opt_Velocity (void)
{
  showeq_params->velocity = !(showeq_params->velocity);
  menuBar()->setItemChecked (mid_opt_Velocity, showeq_params->velocity);
}

void
EQInterface::toggle_opt_Animate (void)
{
  showeq_params->animate = !(showeq_params->animate);
  menuBar()->setItemChecked (mid_opt_Animate, showeq_params->animate);
}

void
EQInterface::toggle_opt_ConSelect (void)
{
  showeq_params->con_select = !(showeq_params->con_select);
  menuBar()->setItemChecked (mid_opt_ConSelect, showeq_params->con_select);
}

void
EQInterface::toggle_opt_Fast (void)
{
  showeq_params->fast_machine = !(showeq_params->fast_machine);
  menuBar()->setItemChecked (mid_opt_Fast, showeq_params->fast_machine);
  if(showeq_params->fast_machine)
    mapTimer->start(1000/showeq_params->framerate,FALSE);
  else
    mapTimer->stop();
}

void
EQInterface::toggle_opt_KeepSelectedVisible (void)
{
  showeq_params->keep_selected_visible = !(showeq_params->keep_selected_visible);
  menuBar()->setItemChecked (mid_opt_KeepSelectedVisible, showeq_params->keep_selected_visible);
}

/* Check and uncheck Log menu options & set EQPacket logging flags */
void
EQInterface::toggle_log_AllPackets (void)
{
    logAllPackets = !logAllPackets;
    menuBar()->setItemChecked (mid_log_AllPackets, logAllPackets);
    m_pPacket->setLogAllPackets (logAllPackets);
}

void
EQInterface::toggle_log_ZoneData (void)
{
    logZoneData = !logZoneData;
    menuBar()->setItemChecked (mid_log_ZoneData, logZoneData);
    m_pPacket->setLogZoneData (logZoneData);
}

void
EQInterface::toggle_log_UnknownData (void)
{
    logUnknownData = !logUnknownData;
    menuBar()->setItemChecked (mid_log_UnknownData, logUnknownData);
    m_pPacket->setLogUnknownData (logUnknownData);
}


/* Check and uncheck View menu options */
void
EQInterface::toggle_vew_ChannelMsgs (void)
{
    viewChannelMsgs = !viewChannelMsgs;
    menuBar()->setItemChecked (mid_vew_ChannelMsgs, viewChannelMsgs);
    m_pPacket->setViewChannelMsgs (viewChannelMsgs);
}

void
EQInterface::toggle_vew_UnknownData (void)
{
    viewUnknownData = !viewUnknownData;
    menuBar()->setItemChecked (mid_vew_UnknownData, viewUnknownData);
    m_pPacket->setViewUnknownData (viewUnknownData);
}

void
EQInterface::toggle_vew_FilteredSpawns(void)
{
    viewFilteredSpawns = !viewFilteredSpawns;
//    menuBar()->setItemChecked (mid_vew_FilteredSpawns, viewFilteredSpawns);

    emit ShowFilteredSpawns(viewFilteredSpawns);
}

void
EQInterface::toggle_vew_HiddenSpawns(void)
{
    viewHiddenSpawns = !viewHiddenSpawns;
    menuBar()->setItemChecked (mid_vew_HiddenSpawns, viewHiddenSpawns);

    emit ShowHidden(viewHiddenSpawns);
}


void
EQInterface::toggle_vew_ExpWindow (void)
{
    viewExpWindow = !viewExpWindow;
    menuBar()->setItemChecked (mid_vew_ExpWindow, viewExpWindow);
    if (viewExpWindow)
       m_expWindow->show();
    else
       m_expWindow->hide();

}

void
EQInterface::toggle_vew_SpawnList(void)
{
    menuBar()->setItemChecked (mid_vew_SpawnList, !m_pSpawnList->isVisible());
    if (m_pSpawnList->isVisible())
       m_pSpawnList->hide();
    else
       m_pSpawnList->show();
}

void
EQInterface::toggle_vew_PlayerStats(void)
{
    menuBar()->setItemChecked (mid_vew_PlayerStats, !m_pStatList->isVisible());
    if (m_pStatList->isVisible())
       m_pStatList->hide();
    else
       m_pStatList->show();
}

void
EQInterface::toggle_vew_PlayerSkills(void)
{
    menuBar()->setItemChecked (mid_vew_PlayerSkills,!m_pSkillList->isVisible());
    if (m_pSkillList->isVisible())
       m_pSkillList->hide();
    else
       m_pSkillList->show();
}

void
EQInterface::toggle_vew_Compass(void)
{
    menuBar()->setItemChecked (mid_vew_Compass, !m_pCompass->isVisible());
    if (m_pCompass->isVisible())
       m_pCompass->hide();
    else
       m_pCompass->show();
}

void
EQInterface::toggle_vew_Map(void)
{
    menuBar()->setItemChecked (mid_vew_Map, !m_pMap->isVisible());
    if (m_pMap->isVisible())
       m_pMap->hide();
    else
       m_pMap->show();
}

void
EQInterface::toggle_opt_SparrMessages (void)
{
    showeq_params->sparr_messages = !(showeq_params->sparr_messages);
    menuBar()->setItemChecked (mid_opt_SparrMessages, showeq_params->sparr_messages);
}

void
EQInterface::toggle_opt_LogSpawns (void)
{
    showeq_params->logSpawns = !(showeq_params->logSpawns);
    menuBar()->setItemChecked (mid_opt_LogSpawns, showeq_params->logSpawns);
}

void
EQInterface::createMessageBox(void)
{
  MsgDialog* pMsgDlg = new MsgDialog(parentWidget(), 
                                "MessageBox", m_StringList);
  m_msgDialogList.append(pMsgDlg);

  // connect signal for new messages
  connect (this, SIGNAL (newMessage(int)), pMsgDlg, SLOT (newMessage(int)));

  pMsgDlg->show();
}


void
//EQInterface::msgReceived(const QString &string)
EQInterface::msgReceived(const QString &instring)
{
  //
  // getting reports of a lot of blank lines being spammed about....
  // thinking its CR's in the msgs themselves.  Putting a CR/LF stripper here
  // WARNING:  If you send a msg with a CR or LF in the middle of it, this will
  // replace it with a space.  So far, I don't think we do that anywhere.
  //  - Maerlyn 3/28
  QString string(instring);
  int index = 0;
  struct stat st;

  while( -1 != (index = string.find('\n')) )
    string.replace(index, 1, " ");
  //  string.remove(index);
  while( -1 != (index = string.find('\r')) )
    string.replace(index, 1, " ");
  //  string.remove(index);

  if (pSEQPrefs->GetPrefBool("Interface_UseStdout")) {
    fprintf(stdout, "%s\n", string.ascii());
    fflush(stdout);
  }

  m_StringList.append(string);

  emit 
    newMessage(m_StringList.count() - 1);
}


//
// TODO:  clear after timeout miliseconds
//
void
EQInterface::stsMessage(const QString &string, int timeout)
{
   m_stsbarStatus->setText(string);
}

void
EQInterface::numSpawns_(int num)
{
  // only update once per sec
  static int lastupdate = 0;
  if ( (mTime() - lastupdate) < 1000)
    return;
  lastupdate = mTime();

   QString tempStr;
   tempStr.sprintf("Mobs: %d", num);
   m_stsbarSpawns->setText(tempStr);
}

void
EQInterface::numPacket(int num)
{
  static int initialcount = 0;

  // if passed 0 reset the average
  if (num == 0)
  {
    m_lPacketStartTime = mTime();
    initialcount = num;
    return;
  }

  // start the timer of not started
  if (!m_lPacketStartTime)
    m_lPacketStartTime = mTime();

  // only update once per sec
  static int lastupdate = 0;
  if ( (mTime() - lastupdate) < 1000)
    return;
  lastupdate = mTime();
  

   QString tempStr;
   int delta = mTime() - m_lPacketStartTime;
   num -=initialcount;
   if (num && delta)
     tempStr.sprintf("Pkt: %d (%2.1f)", num, (float) (num<<10) / (float) delta);
   else   
     tempStr.sprintf("Pkt: %d", num);

   m_stsbarPkt->setText(tempStr);
}

void
EQInterface::addCategory(void)
{
  // Create the filter dialog
  CFilterDlg* dlg = new CFilterDlg(parentWidget(), "FilterDlg");

  SpawnListItem *i = m_pSpawnList->Selected();

//  if (i)
//  {
//  }
//  else
  {
    dlg->m_Filter->setText("Filter");
    dlg->m_FilterOut->setText("");
    dlg->m_Color->setCurrentItem(0);
  }
  dlg->exec();

  // Add Category
  const char *name = 0;
  const char *filter = 0;
  const char *filterout = 0;
  const char *color = 0; 

  color = dlg->m_Color->currentText().ascii();
  name = dlg->m_Name->text().ascii();
  filter = dlg->m_Filter->text().ascii();
  filterout = dlg->m_FilterOut->text().ascii();
  if (!filterout[0])
    filterout = 0;

//printf("Got name: '%s', filter '%s', filterout '%s', color '%s'\n",
//  name?name:"", color?color:"", filter?filter:"", filterout?filterout:""); 

  if (name[0] && filter[0])
          m_pSpawnList->AddCategory(name, filter, filterout, QColor(color));

  if (m_pMap)
     m_pMap->rebuildSpawnList();
}

CFilterDlg::CFilterDlg(QWidget *parent, QString name)
 : QDialog(parent, name, TRUE)
{
#ifdef DEBUG
   debug ("CFilterDlg()");
#endif /* DEBUG */

   QBoxLayout *topLayout = new QVBoxLayout(this);
   QBoxLayout *row4Layout = new QHBoxLayout(topLayout);
   QBoxLayout *row3Layout = new QHBoxLayout(topLayout);
   QBoxLayout *row2Layout = new QHBoxLayout(topLayout);
   QBoxLayout *row1Layout = new QHBoxLayout(topLayout);

   QLabel *colorLabel = new QLabel ("Color", this);
   colorLabel->setFont(QFont("Helvetica", 12, QFont::Bold));
   colorLabel->setFixedHeight(colorLabel->sizeHint().height());
//   colorLabel->setFixedWidth(colorLabel->sizeHint().width()+10);
   colorLabel->setFixedWidth(100);
   colorLabel->setAlignment(QLabel::AlignLeft|QLabel::AlignVCenter);
   row1Layout->addWidget(colorLabel);

   m_Color = new QComboBox(FALSE, this, "Color");
   m_Color->insertItem("black");
   m_Color->insertItem("gray");
   m_Color->insertItem("darkBlue");
   m_Color->insertItem("darkGreen");
   m_Color->insertItem("darkCyan");
   m_Color->insertItem("darkRed");
   m_Color->insertItem("darkMagenta");
   m_Color->insertItem("darkYellow");
   m_Color->insertItem("darkGray");
   m_Color->insertItem("white");
   m_Color->insertItem("blue");
   m_Color->insertItem("green");
   m_Color->insertItem("cyan");
   m_Color->insertItem("red");
   m_Color->insertItem("magenta");
   m_Color->insertItem("yellow");
   m_Color->insertItem("white");

   m_Color->setFont(QFont("Helvetica", 12));
   m_Color->setFixedHeight(m_Color->sizeHint().height());
   m_Color->setFixedWidth(m_Color->sizeHint().width());
   row1Layout->addWidget(m_Color, 0, AlignLeft);

   QLabel *nameLabel = new QLabel ("Name", this);
   nameLabel->setFont(QFont("Helvetica", 12, QFont::Bold));
   nameLabel->setFixedHeight(nameLabel->sizeHint().height());
//   nameLabel->setFixedWidth(nameLabel->sizeHint().width()+5);
   nameLabel->setFixedWidth(100);
   nameLabel->setAlignment(QLabel::AlignLeft|QLabel::AlignVCenter);
   row4Layout->addWidget(nameLabel);

   m_Name = new QLineEdit(this, "Name");
   m_Name->setFont(QFont("Helvetica", 12, QFont::Bold));
   m_Name->setFixedHeight(m_Name->sizeHint().height());
   m_Name->setFixedWidth(150);
   row4Layout->addWidget(m_Name);

   QLabel *filterLabel = new QLabel ("Filter", this);
   filterLabel->setFont(QFont("Helvetica", 12, QFont::Bold));
   filterLabel->setFixedHeight(filterLabel->sizeHint().height());
//   filterLabel->setFixedWidth(filterLabel->sizeHint().width()+5);
   filterLabel->setFixedWidth(100);
   filterLabel->setAlignment(QLabel::AlignLeft|QLabel::AlignVCenter);
   row3Layout->addWidget(filterLabel);

   m_Filter  = new QLineEdit(this, "Filter");
   m_Filter->setFont(QFont("Helvetica", 12, QFont::Bold));
   m_Filter->setFixedHeight(m_Filter->sizeHint().height());
   m_Filter->setFixedWidth(150);
   row3Layout->addWidget(m_Filter);

   QLabel *filteroutLabel = new QLabel ("FilterOut", this);
   filteroutLabel->setFont(QFont("Helvetica", 12, QFont::Bold));
   filteroutLabel->setFixedHeight(filteroutLabel->sizeHint().height());
//   filteroutLabel->setFixedWidth(filteroutLabel->sizeHint().width()+5);
   filteroutLabel->setFixedWidth(100);
   filteroutLabel->setAlignment(QLabel::AlignLeft|QLabel::AlignVCenter);
   row2Layout->addWidget(filteroutLabel);

   m_FilterOut  = new QLineEdit(this, "FilterOut");
   m_FilterOut->setFont(QFont("Helvetica", 12, QFont::Bold));
   m_FilterOut->setFixedHeight(m_FilterOut->sizeHint().height());
   m_FilterOut->setFixedWidth(150);
   row2Layout->addWidget(m_FilterOut);

   QPushButton *ok = new QPushButton("OK", this);
   ok->setFixedWidth(30);
   ok->setFixedHeight(30);
   topLayout->addWidget(ok, 0, AlignCenter);

   // Hook on pressing the OK button
   connect(ok, SIGNAL(clicked()), SLOT(accept()));

   setFixedSize(175, 80);
}


void
EQInterface::reloadCategories(void)
{
   pSEQPrefs->Revert();
   m_pSpawnList->clearCategories();

   int i = 0;
   char tempStr[256];
   for(i = 1; i < 25; i++)
   {
      // attempt to pull a button title from the preferences
      sprintf(tempStr, "SpawnList_Category%d_Name", i);
      if (pSEQPrefs->isPreference(tempStr))
      {
        char *name = strdup(pSEQPrefs->GetPrefString(tempStr));
        sprintf(tempStr, "SpawnList_Category%d_Filter", i);
        char *filter = strdup(pSEQPrefs->GetPrefString(tempStr));
        sprintf(tempStr, "SpawnList_Category%d_Color", i);
        char *color = strdup(pSEQPrefs->GetPrefString(tempStr));
        sprintf(tempStr, "SpawnList_Category%d_Hidden", i);
        bool bHidden = pSEQPrefs->GetPrefBool(tempStr);
        sprintf(tempStr, "SpawnList_Category%d_FilterOut", i);
        char *filterout = 0;
        if (pSEQPrefs->isPreference(tempStr))
            filterout = strdup(pSEQPrefs->GetPrefString(tempStr));

//printf("%d: Got '%s' '%s' '%s'\n", i, name, filter, color);
        if (name[0] && filter[0])
        {
          SpawnListItem *item = m_pSpawnList->AddCategory(name, 
                                         filter, filterout, QColor(color));
          m_pSpawnList->hideSpawn(item, bHidden);
        }
        free(name);
        free(filter);
        free(color);
      }
   }

   if (m_pMap)
      m_pMap->rebuildSpawnList();

   printf("SpawnList Categories Reloaded\n");
}

//
// rightButtonPressed
//
// if you right click on a spawn in the list dump its contents
// and mark the column you selected as the current column for filtering
//
void 
EQInterface::spawnListRightButton(QListViewItem *item, 
                      const QPoint &point, int col)
{
  // Create the filter dialog
  CFilterDlg* dlg = new CFilterDlg(parentWidget(), "FilterDlg");

  struct category* cat = m_pSpawnList->getCategory((SpawnListItem *) item);

  if (!cat)
    return;

  dlg->m_Name->setText(cat->name);
  dlg->m_Filter->setText(cat->filter);
  dlg->m_FilterOut->setText(cat->filterout);
//  dlg->m_Color->setCurrentItem(0);
  dlg->exec();

  // remove category
  m_pSpawnList->RemCategory((SpawnListItem *) item);

  // Add Category
  const char *name = 0;
  const char *filter = 0;
  const char *filterout = 0;
  const char *color = 0; 

  color = dlg->m_Color->currentText().ascii();
  name = dlg->m_Name->text().ascii();
  filter = dlg->m_Filter->text().ascii();
  filterout = dlg->m_FilterOut->text().ascii();
  if (filterout && !filterout[0])
    filterout = 0;

//printf("Got name: '%s', filter '%s', filterout '%s', color '%s'\n",
//  name?name:"", color?color:"", filter?filter:"", filterout?filterout:""); 

  if (name[0] && filter[0])
          m_pSpawnList->AddCategory(name, filter, filterout, QColor(color));

  if (m_pMap)
     m_pMap->rebuildSpawnList();

} // end spawnListRightButton()

