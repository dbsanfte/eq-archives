/*
 * showitem.cpp
 *
 * ShowEQ Distributed under GPL
 * http://www.hackersquest.gomp.ch/
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "util.h"


void
printdata (int len, unsigned char *data)
{
  char hex[1024];
  char col[1024];
  char asc[1024];
  char tmp[1024];

  hex[0] = 0;
  asc[0] = 0;
  int c;
  for (c = 0; c < len; c++)
    {
      if ((!(c % 16)) && c)
	{
	  printf
	    ("<FONT COLOR=BLACK>%03d | </FONT>%s<FONT COLOR=BLACK> | </FONT>%s \n",
	     c - 16, hex, asc);
	  hex[0] = 0;
	  asc[0] = 0;
	}

      sprintf (tmp, "%02x ", data[c]);
      switch (c)
	{
	case 0:
	  strcpy (col, "<FONT COLOR=GREEN>");
	  break;
	case 35:
	  strcpy (col, "</FONT><FONT COLOR=BLUE>");
	  break;
	case 95:
	  strcpy (col, "</FONT><FONT COLOR=GREEN>");
	  break;
	case 101:
	  strcpy (col, "</FONT><FONT COLOR=BLUE>");
	  break;
	case 103:
	  strcpy (col, "</FONT><FONT COLOR=RED>");
	  break;
	case 125:
	  strcpy (col, "</FONT><FONT COLOR=BLUE>");
	  break;
	case 126:
	  strcpy (col, "</FONT><FONT COLOR=GREEN>");
	  break;
	case 127:
	  strcpy (col, "</FONT><FONT COLOR=BLUE>");
	  break;
	case 128:
	  strcpy (col, "</FONT><FONT COLOR=GREEN>");
	  break;
	case 129:
	  strcpy (col, "</FONT><FONT COLOR=RED>");
	  break;
	case 130:
	  strcpy (col, "</FONT><FONT COLOR=GREEN>");
	  break;
	case 132:
	  strcpy (col, "</FONT><FONT COLOR=BLUE>");
	  break;
	case 134:
	  strcpy (col, "</FONT><FONT COLOR=GREEN>");
	  break;
	case 135:
	  strcpy (col, "</FONT><FONT COLOR=RED>");
	  break;
	case 136:
	  strcpy (col, "</FONT><FONT COLOR=BLUE>");
	  break;
	case 140:
	  strcpy (col, "</FONT><FONT COLOR=GREEN>");
	  break;
	case 144:
	  strcpy (col, "</FONT><FONT COLOR=RED>");
	  break;
	case 164:
	  strcpy (col, "</FONT><FONT COLOR=GREEN>");
	  break;
	case 165:
	  strcpy (col, "</FONT><FONT COLOR=BLUE>");
	  break;
	case 166:
	  strcpy (col, "</FONT><FONT COLOR=GREEN>");
	  break;
	case 167:
	  strcpy (col, "</FONT><FONT COLOR=BLUE>");
	  break;
	case 168:
	  strcpy (col, "</FONT><FONT COLOR=GREEN>");
	  break;
	case 169:
	  strcpy (col, "</FONT><FONT COLOR=BLUE>");
	  break;
	case 170:
	  strcpy (col, "</FONT><FONT COLOR=GREEN>");
	  break;
	case 171:
	  strcpy (col, "</FONT><FONT COLOR=BLUE>");
	  break;
	case 172:
	  strcpy (col, "</FONT><FONT COLOR=GREEN>");
	  break;
	case 173:
	  strcpy (col, "</FONT><FONT COLOR=BLUE>");
	  break;
	case 174:
	  strcpy (col, "</FONT><FONT COLOR=GREEN>");
	  break;
	case 175:
	  strcpy (col, "</FONT><FONT COLOR=BLUE>");
	  break;
	case 176:
	  strcpy (col, "</FONT><FONT COLOR=GREEN>");
	  break;
	case 177:
	  strcpy (col, "</FONT><FONT COLOR=BLUE>");
	  break;
	case 178:
	  strcpy (col, "</FONT><FONT COLOR=GREEN>");
	  break;
	case 179:
	  strcpy (col, "</FONT><FONT COLOR=RED>");
	  break;
	case 181:
	  strcpy (col, "</FONT><FONT COLOR=GREEN>");
	  break;
	case 182:
	  strcpy (col, "</FONT><FONT COLOR=BLUE>");
	  break;
	case 183:
	  strcpy (col, "</FONT><FONT COLOR=GREEN>");
	  break;
	case 184:
	  strcpy (col, "</FONT><FONT COLOR=RED>");
	  break;
	case 185:
	  strcpy (col, "</FONT><FONT COLOR=GREEN>");
	  break;
	case 186:
	  strcpy (col, "</FONT><FONT COLOR=BLUE>");
	  break;
	case 187:
	  strcpy (col, "</FONT><FONT COLOR=GREEN>");
	  break;
	case 188:
	  strcpy (col, "</FONT><FONT COLOR=BLUE>");
	  break;
	case 189:
	  strcpy (col, "</FONT><FONT COLOR=GREEN>");
	  break;
	case 190:
	  strcpy (col, "</FONT><FONT COLOR=RED>");
	  break;
	case 192:
	  strcpy (col, "</FONT><FONT COLOR=BLUE>");
	  break;
	case 196:
	  strcpy (col, "</FONT><FONT COLOR=RED>");
	  break;
	case 198:
	  strcpy (col, "</FONT><FONT COLOR=GREEN>");
	  break;
	case 200:
	  strcpy (col, "</FONT><FONT COLOR=BLUE>");
	  break;
	case 202:
	  strcpy (col, "</FONT><FONT COLOR=RED>");
	  break;
	case 204:
	  strcpy (col, "</FONT><FONT COLOR=BLUE>");
	  break;
	case 206:
	  strcpy (col, "</FONT><FONT COLOR=RED>");
	  break;
	case 209:
	  strcpy (col, "</FONT><FONT COLOR=BLUE>");
	  break;
	case 210:
	  strcpy (col, "</FONT><FONT COLOR=GREEN>");
	  break;
	case 211:
	  strcpy (col, "</FONT><FONT COLOR=RED>");
	  break;
	case 212:
	  strcpy (col, "</FONT><FONT COLOR=GREEN>");
	  break;
	case 214:
	  strcpy (col, "</FONT><FONT COLOR=RED>");
	  break;
	}
      strcat (hex, col);
      strcat (hex, tmp);
      strcat (asc, col);
      if ((data[c] >= 32) && (data[c] <= 126))
	sprintf (tmp, "%c", data[c]);
      else
	strcpy (tmp, ".");
      strcat (asc, tmp);

    }
  if (c % 16)
    c = c - (c % 16);
  else
    c -= 16;
  printf
    ("<FONT COLOR=BLACK>%03d |</FONT> %-48s <FONT COLOR=BLACK>|</FONT> %s \n\n",
     c, hex, asc);
}

int
main (int argc, char *argv[])
{
  FILE *idb;
  struct itemStruct item;
  int found = 0;

  printf ("Content-type: text/html\n\n");

  idb = fopen (LOGDIR "/item.db", "r");
  while (fread (&item, sizeof (itemStruct), 1, idb))
    {
      if (item.itemNr == atoi (argv[1]))
	{
	  printf ("<IMG SRC=\"/i/%d.gif\">", item.iconNr);
	  printf ("<H1>%s</H1>\n", item.name);
	  printf ("<B>Lore:</B> %s<BR>\n", item.lore);
	  printf ("<B>Model:</B> %s<BR>\n", item.idfile);
	  printf ("<B>flag:</B> %x<BR>\n", item.flag);
	  printf ("<B>Weight:</B> %d<BR>\n", item.weight);
	  printf ("<B>Flags:</B> ");
	  if (item.nodrop == 0)
	    printf (" NO-DROP");
	  if (item.nosave == 0)
	    printf (" NO-SAVE");
	  if (item.magic == 1)
	    printf (" MAGIC");
	  if (item.lore[0] == '*')
	    printf (" LORE");
	  printf ("<BR>\n");
	  printf ("<B>Size:</B> %d<BR>\n", item.size);
	  printf ("<B>ItemID:</B> %d<BR>\n", item.itemNr);
	  printf ("<B>Icon#:</B> %d<BR>\n", item.iconNr);
	  printf ("<B>Current Slot:</B> %x<BR>\n", item.equipSlot);
	  printf ("<B>Slots:</B> %s<BR>\n", print_slot (item.slots_));
	  printf ("<B>Cost:</B> %dcp<BR>\n", item.cost);
	  if (item.STR)
	    printf ("<B>Str:</B> %d<BR>\n", item.STR);
	  if (item.STA)
	    printf ("<B>Sta:</B> %d<BR>\n", item.STA);
	  if (item.DEX)
	    printf ("<B>Dex:</B> %d<BR>\n", item.DEX);
	  if (item.INT)
	    printf ("<B>Int:</B> %d<BR>\n", item.INT);
	  if (item.AGI)
	    printf ("<B>Agi:</B> %d<BR>\n", item.AGI);
	  if (item.WIS)
	    printf ("<B>Wis:</B> %d<BR>\n", item.WIS);
	  if (item.MR)
	    printf ("<B>Magic:</B> %d<BR>\n", item.MR);
	  if (item.FR)
	    printf ("<B>Fire:</B> %d<BR>\n", item.FR);
	  if (item.CR)
	    printf ("<B>Cold:</B> %d<BR>\n", item.CR);
	  if (item.DR)
	    printf ("<B>Disease:</B> %d<BR>\n", item.DR);
	  if (item.PR)
	    printf ("<B>Poison:</B> %d<BR>\n", item.PR);
	  if (item.HP)
	    printf ("<B>HP:</B> %d<BR>\n", item.HP);
	  if (item.MANA)
	    printf ("<B>Mana:</B> %d<BR>\n", item.MANA);
	  if (item.AC)
	    printf ("<B>AC:</B> %d<BR>\n", item.AC);
	  if (item.light)
	    printf ("<B>Light:</B> %d<BR>\n", item.light);
	  if (item.delay)
	    printf ("<B>Delay:</B> %d<BR>\n", item.delay);
	  if (item.damage)
	    {
	      printf ("<B>Damage:</B> %d<BR>\n", item.damage);
	      printf ("<B>Skill:</B> %s<BR>\n", print_skill (item.skill));
	    }
	  if (item.range)
	    printf ("<B>Range:</B> %d<BR>\n", item.range);
	  printf ("<B>Material:</B> %x (%s)<BR>\n", item.material,
		  print_material (item.material));
	  printf
	    ("<B>Color:</B> %x <B><FONT COLOR=\"#%06x\">###SAMPLE###</FONT></B><BR>\n",
	     item.color, item.color);
	  if (item.spellId0 != 0xffff)
	    printf ("<B>Effect1:</B> %s<BR>\n", spell_name (item.spellId0));
	  printf ("<B>Class:</B> %s<BR>\n", print_class (item.classes));
	  printf ("<B>Race:</B> %s<BR>\n", print_race (item.races));
	  if (item.level)
	    printf ("<B>Casting Level:</B> %d<BR>\n", item.level);
	  if (item.number)
	    printf ("<B>Stack:</B> %d<BR>\n", item.number);
	  if (item.spellId != 0xffff)
	    printf ("<B>Effect2:</B> %s<BR>\n", spell_name (item.spellId));

	  printf ("<B>Packet data:</B>\n");
	  printf ("<PRE>\n");
	  printdata (sizeof (itemStruct), (unsigned char *) &item);
	  printf ("</PRE>\n");
	  found = 1;
	  break;
	}
    }
  fclose (idb);

  if (!found)
    printf ("Item %d not found\n", atoi (argv[1]));
}
