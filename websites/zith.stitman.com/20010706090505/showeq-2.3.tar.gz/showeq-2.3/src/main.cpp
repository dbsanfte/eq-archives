/*
 * main.cpp
 *
 * ShowEQ Distributed under GPL
 * http://www.hackersquest.gomp.ch/
 */

/* main.cpp is the entrypoint to ShowEQ, it parses the commandline
 * options and initializes the application
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <qapplication.h>
#include <sys/stat.h>
#include <qwindowsstyle.h>

#include "interface.h"
#include "main.h"
#include "cpreferences.h"      // prefrence file class

/* Global parameters, so all parts of ShowEQ has access to it */
struct ShowEQParams *showeq_params;
CPreferenceFile *pSEQPrefs; 


int
main (int argc, char **argv)
{
  int opt;
  struct stat ss;
  int o_help = 0;

  /* Print the version number, hmm, version number should actually be moved
   * out of source and into a header or makefile definition
   */
  printf ("ShowEQ 2.3, released under the GPL.\n");

  /* Initialize the parameters with default values */
  char *configfile = "showeq.conf";
  if (stat (LOGDIR "/showeq.conf", &ss) == 0)
    configfile = LOGDIR "/showeq.conf";

  // scan command line arguments for a specified config file
  int i = 1;
  while (i < argc)
  {
    if ( (argv[i][0] == '-') && (argv[i][1] == 'o') )
        configfile = strdup(argv[i+1]);
    i++;
  }

  // see cpreferencefile.cpp for info on how to use prefrences class
  printf("Using config file '%s'\n", configfile);
  pSEQPrefs = new CPreferenceFile(configfile);

  showeq_params =
    (struct ShowEQParams *) malloc (sizeof (struct ShowEQParams));
  showeq_params->device   = 
                  strdup(pSEQPrefs->GetPrefString("Network_Device", "eth0"));
  showeq_params->ip       = 
                  strdup(pSEQPrefs->GetPrefString("Network_IP", "127.0.0.1"));
  showeq_params->realtime = 
                  pSEQPrefs->GetPrefBool("Network_RealTimeThread", 0);
  showeq_params->animate = 
                  pSEQPrefs->GetPrefBool("Map_AnimateSpawnMovement", 0);
  showeq_params->velocity = 
                  pSEQPrefs->GetPrefBool("Map_VelocityLines", 0);
  showeq_params->retarded_coords = 
                  pSEQPrefs->GetPrefBool("Interface_RetardedCoords", 0);
  if (stat ("filter.conf", &ss) == 0){
    showeq_params->spawnfilter_filterfile = "filter.conf";
  }else if (stat (LOGDIR "/filter.conf", &ss) == 0){
    showeq_params->spawnfilter_filterfile = LOGDIR "/filter.conf";
  }else{
    showeq_params->spawnfilter_filterfile = NULL;
  }

  if (stat ("filters.conf", &ss) == 0)
    showeq_params->filterfile = "filters.conf";
  else if (stat (LOGDIR "/filters.conf", &ss) == 0)
    showeq_params->filterfile = LOGDIR "/filters.conf";
  else
    showeq_params->filterfile = NULL;
  showeq_params->filterfile = 
            strdup(pSEQPrefs->GetPrefString("Filters_SpawnFilterFile", 
            showeq_params->filterfile));


  if (stat ("spawns.conf", &ss) == 0)
    showeq_params->spawnfilter_spawnfile = "spawns.conf";
  else if (stat (LOGDIR "/spawns.conf", &ss) == 0)
    showeq_params->spawnfilter_spawnfile = LOGDIR "/spawns.conf";
  else
    showeq_params->spawnfilter_spawnfile = NULL;

  showeq_params->spawnfilter_audio = 
                  pSEQPrefs->GetPrefBool("Filters_SpawnFilterAudio", 0);

  showeq_params->spawnfilter_regexp = 0;

  showeq_params->walkpathrecord = 
                  pSEQPrefs->GetPrefBool("WalkPathRecording", 0);

  showeq_params->walkpathshowselect = 
                  pSEQPrefs->GetPrefBool("WalkPathShowSelect", 0);

  showeq_params->walkpathlength = 
                  pSEQPrefs->GetPrefInt("WalkPathLength", 0);

  showeq_params->logSpawns = 
                  pSEQPrefs->GetPrefBool("logSpawns", 0);
  showeq_params->logItems = 
                  pSEQPrefs->GetPrefBool("logItems", 0);

  showeq_params->spawnfilter_case = 
                pSEQPrefs->GetPrefBool("Filters_SpawnFilterIsCaseSensitive", 0);
  showeq_params->despawnalert = 
                  pSEQPrefs->GetPrefBool("Filters_DeSpawnAlert", 0);
  showeq_params->framerate = pSEQPrefs->GetPrefInt("Map_Framerate", 5);
  showeq_params->fontsize = pSEQPrefs->GetPrefInt("Interface_Fontsize", 8);
  showeq_params->fast_machine = pSEQPrefs->GetPrefBool("Map_FastMachine", 0);
  showeq_params->spawn_alert_plus_plus = 
                  pSEQPrefs->GetPrefBool("Filters_AlertInfo", 0);
  showeq_params->dropItemShow = 
                  pSEQPrefs->GetPrefBool("Map_ShowDroppedItems", 0);
  showeq_params->showUnknownSpawns = 
                  pSEQPrefs->GetPrefBool("Map_ShowUnknownSpawns", 0);
  showeq_params->con_select = 
                  pSEQPrefs->GetPrefBool("Interface_SelectOnCon", 0);
  showeq_params->keep_selected_visible =
                  pSEQPrefs->GetPrefBool("Interface_KeepSelected",1);
  showeq_params->promisc = pSEQPrefs->GetPrefBool("Network_NoPromiscuous", 1);
  showeq_params->sparr_messages = 0;
  showeq_params->net_stats = pSEQPrefs->GetPrefBool("Interface_NetStats", 0);
  showeq_params->playbackpackets = pSEQPrefs->GetPrefBool("VPacket_Playback",0);
  showeq_params->recordpackets = pSEQPrefs->GetPrefBool("VPacket_Record",0);
  showeq_params->playbackspeed = pSEQPrefs->GetPrefBool("VPacket_PlaybackRate",0);
  showeq_params->pvp = pSEQPrefs->GetPrefBool("Interface_PvPTeamColoring", 0);
  showeq_params->broken_decode = 
                  pSEQPrefs->GetPrefBool("Misc_BrokenDecode",0);

  /* Parse the commandline for commandline parameters */
  while ((opt = getopt (argc, argv, "i:rvf:g::j::u:s:ado:RCp:ncFAGKSVPNbtTL:x")) != -1)
    {
      switch (opt)
	{
	case 'd':
          /* Set the request to use a despawn list based off the spawn alert list. */
	  showeq_params->despawnalert = 1;
	  break;
	case 'i':
	  /* Set the interface */
	  showeq_params->device = optarg;
	  break;
	case 'r':
	  /* Set pcap thread to realtime */
	  showeq_params->realtime = 1;
	  break;
	case 'v':
	  /* Draw velocities in map */
	  showeq_params->velocity = 1;
	  break;
	case 'f':
	  /* Set the spawn filter file */
	  showeq_params->spawnfilter_filterfile = optarg;
	  showeq_params->filterfile = optarg;
	  break;
        case 'j':
          /* packet playback mode */
	  if (optarg)
              pSEQPrefs->SetPrefText("VPacket_Filename", optarg, FALSE);
          showeq_params->playbackpackets = 1;
          showeq_params->recordpackets = 0;
          break;
	case 'u':
	  /* Set framerate */
	  showeq_params->framerate = atoi(optarg);
	  break;
        case 'g':
          /* packet record mode */
          if (optarg)
              pSEQPrefs->SetPrefText("VPacket_Filename", optarg, FALSE);
          showeq_params->recordpackets = 1;
          showeq_params->playbackpackets = 0;
          break;
	case 's':
	  /* Set the spawn alert file */
	  showeq_params->spawnfilter_spawnfile = optarg;
	  break;
        case 'o':
          /* config file was already taken care of, ignore */
          break;
	case 'a':
	  /* Enable use of enlightenment audio */
	  showeq_params->spawnfilter_audio = 1;
	  break;
	case 'R':
	  /* Use regular expressions for filter */
	  showeq_params->spawnfilter_regexp = 1;
	  break;
	case 'C':
	  /* Make filter case sensitive */
	  showeq_params->spawnfilter_case = 1;
	  break;
	case 'p':
	  /* Set point size of skills and spawn font */
	  showeq_params->fontsize = atoi(optarg);
	  break;
	case 'n':
	  /* Animate the movement of the spawns */
	  showeq_params->animate = 1;
	  break;
	case 'c':
	  /* Use retarded coordinate system yxz */
	  showeq_params->retarded_coords = 1;
	  break;
	case 'F':
	  /* Fast machine updates.. framerate vs packet based */
	  showeq_params->fast_machine = 1;
	  break;
	case 'A':
	  /* cool spawn alert */
	  showeq_params->spawn_alert_plus_plus = 1;
	  break;
	case 'G':
	  /* cool spawn alert */
	  showeq_params->dropItemShow = 1;
	  break;
	case 'K':
	  /* cool spawn alert */
	  showeq_params->showUnknownSpawns = 1;
	  break;
	case 'S':
	  /* select spawn on 'Consider' */
	  showeq_params->con_select = 1;
	  break;
	case 'V':
	  /* don't force the selected spawn to be visible in scrollbox */
	  showeq_params->keep_selected_visible = 0;
	  break;
	case 'P':
	  /* don't use Promiscuous mode on sniffing */
	  showeq_params->promisc = 0;
	  break;
	case 'N':
	  /* show net info */
	  showeq_params->net_stats = 1;
	  break;
	case 'b':
	  /* 'b'roken decode -- don't deal with spawn packets */
	  showeq_params->broken_decode = 1;
	  break;
        case 'T':
           /* show selected 'T'rack pathing */
           showeq_params->walkpathshowselect = 1;
           //automatically enable pathing if they want to see it.
        case 't':
           /* 't'rack pathing for mobs */
           showeq_params->walkpathrecord = 1;
           break;
	case 'L':
	  /* Set point size of skills and spawn font */
	  showeq_params->walkpathlength = atoi(optarg);
	  break;
        case 'x': //Log spawns!
            showeq_params->logSpawns = 1;
            break;
	case 'h':
	default:
	  /* Default, spit out the help */
	  o_help = 1;
	}
    }
  if (optind < (argc - 1))
    {
        /* If there were arguments we did not understand, print out the help */
        o_help = 1;
    }

  if (o_help)
    {
      /* The default help text */
      printf ("Usage:\n  %s [-i <device>] [-r] <client address>\n\n",
	      argv[0]);
      printf ("  -i <device>    Specify which network device to bind to.\n");
      printf ("  -r             Set the network thread RealTime.\n");
      printf ("  -f <filename>  Sets spawn filter file.\n");
      printf ("  -s <filename>  Sets spawn alert file.\n");
      printf ("  -d             Enables de-spawn alert using spawn alert's file.\n");
      printf ("  -v             Draws velocity lines in map.\n");
      printf ("  -R             Spawn alert and filter uses regexp, not glob.\n");
      printf ("  -C             Spawn alert and filter is case sensitive.\n");
      printf ("  -a             Use ESD to play alert during spawn alert.\n");
      printf ("  -p <size>      Sets the point size of the skill and spawn table fonts.\n");
      printf ("  -n             Animate the movement of the spawns.\n");
      printf ("  -u <FPS>       Framerate of updates (default 5fps).\n");
      printf ("  -c             Use \"retarded\" YXZ coordinates.\n");
      printf ("  -F             Fast machine - Framerate based VS Packet based Update\n");
      printf ("  -A             Use name/race/class/light/equipment for spawn matching\n");
      printf ("  -G             Show items on Ground.\n");
      printf ("  -K             Display unknown spawns.\n");
      printf ("  -S             Select the spawn Considerd.\n");
      printf ("  -V             Don't force the listbox to keep selected spawn visible.\n");
      printf ("  -P             Don't use sniff the network in Promiscous mode.\n");
      printf ("  -N             Show Netwotrk info dialog\n");
      printf ("  -h             Shows this help.\n");
      printf ("  -j<filename>   Playback packets from <filename> prev recorded with -g option.\n");
      printf ("  -g<filename>   Record packets to <filename> to playback with -j option.\n");
      printf ("  -b             broken decode -- don't decode Spawn packets.\n");
      printf ("  -t             track spawn movements (no display).\n");
      printf ("  -T             Track spawn movements (show selected spawns path).\n");
      printf ("  -L  ###        Track spawn maximum track length. (min:3)\n");
      printf ("  -x             Log spawns into spawns.db (default is not to log)\n");
      exit (0);
    }

  /* Create application instance */
  QApplication::setStyle( new QWindowsStyle() );
  QApplication qapp (argc, argv);
  
  if (optind != argc)
    showeq_params->ip = argv[optind];

  /* The main interface widget */
  EQInterface intf (0, 0);
//  intf.setGeometry (100, 100, 1000, 650);
  qapp.setMainWidget (&intf);
  //qapp.setStyle( new QWindowsStyle );

  /* Show the main widget */
// moved to interface.cpp (have to show mainwidget before we can move it)
//  intf.show ();

  /* Return */
  int ret = qapp.exec ();

  intf.savePrefs();
  delete pSEQPrefs;

  return ret;
}
