
/*
 * spawnlist.h
 *
 * ShowEQ Distributed under GPL
 * http://www.hackersquest.gomp.ch/
 */

/*
 * Orig Author - Maerlyn (MaerlynTheWiz@yahoo.com)
 * Date   - 3/16/00
 */

/* 
 * SpawnListItem 
 *
 * SpawnListItem is class intended to store information about an EverQuest
 * Spawn.  It inherits from QListViewItem but overrides functionality to allow
 * paint styles such as color changes
 *
 * It is intended that this class will grow to support all data from a spawn
 * such as holding and managing access to the information such as race, class
 * hitpoints, position, etc etc.
 *
 * currently it just provides a widget and maintains a QColor for the text
 * display of that widget
 */
 
#ifndef SPAWNLIST_H
#define SPAWNLIST_H

#include <qlistview.h>
#include <math.h>
#include <time.h>
#include <stdio.h>
#include <sys/time.h>
#include "everquest.h"

//--------------------------------------------------
// Added by Wally59
//--------------------------------------------------
enum itemType { tUnknown, tCoins, tDrop, tSpawn };
//--------------------------------------------------

#define spawnFiltered  0x01
#define spawnHidden    0x02
#define spawnHighlight 0x04
#define spawnAggressor 0x08

class SpawnListItem : public QListViewItem
{
public:
   //--------------------------------------------------
   // Added by Wally59
   //--------------------------------------------------
   SpawnListItem(QListViewItem *parent);
   SpawnListItem(QListView *parent);
   //--------------------------------------------------

   virtual void paintCell( QPainter *p, const QColorGroup &cg,
                           int column, int width, int alignment );

   const QColor textColor()  { return m_textColor; }
   void setTextColor(const QColor &color)  
                             { m_textColor = QColor(color); m_btextSet = TRUE; }
   int  flags()              { return m_nFlags; }
   void setFlags(int nFlags) { m_nFlags = nFlags; }

   //--------------------------------------------------
   // Added by Wally59
   //--------------------------------------------------
   bool UpdateSpawn(spawnStruct *s = NULL);
   void UpdateCoins(dropCoinsStruct *c = NULL);
   void UpdateDrop(dropThingOnGround *d = NULL);
   
   spawnStruct*       spawn();
   dropCoinsStruct*   coins();
   dropThingOnGround* drop();
   itemType           type();
   timeval            lastUpdate();

   //--------------------------------------------------
private:
   QColor        m_textColor;
   bool          m_btextSet;
   int           m_nFlags;

   //__________________________________________________
   // Added by Wally 59
   //--------------------------------------------------
   itemType          m_type;
   spawnStruct       m_spawn;      
   dropCoinsStruct   m_coins;
   dropThingOnGround m_drop;
   timeval           m_lastUpdate; 
   //--------------------------------------------------
   bool              m_bSet;
};

struct category
{
   const char* name;
   const char* filter;
   const char* filterout;
   QColor color;
//   QListViewItem* listitem;
   SpawnListItem* listitem;
   int flags;
};

//--------------------------------------------------
// Added by Wally59
//--------------------------------------------------
class CSpawnList : public QListView
{
  Q_OBJECT

public:
  CSpawnList(QWidget *parent = 0, const char * name = 0);

public:
  void SelectItem(itemType type, int id);
  SpawnListItem* Selected();
  SpawnListItem* FindItem(itemType type, int id);
  SpawnListItem* FindNext(SpawnListItem* item, itemType type, int id);
  SpawnListItem* InsertSpawn(spawnStruct *s, int flags = 0);
  SpawnListItem* InsertCoins(dropCoinsStruct *c);
  SpawnListItem* InsertDrop(dropThingOnGround *d);
  void DeleteItem(itemType type, int id);
  int calcDist(int xcor, int ycor);
  void UpdateSpawn(spawnStruct *s = NULL);
  void UpdateCoins(dropCoinsStruct *c = NULL);
  void UpdateDrop(dropThingOnGround *d = NULL);
  void TransformName(char * name);
  SpawnListItem* AddCategory(const char* name, const char* filter, 
                             const char* filterout, QColor color = Qt::black);
  void RemCategory(SpawnListItem *);
  void clear();
  void clearCategories();
  QColor pickSpawnColor(spawnStruct *s, QColor def = Qt::black);
  void hideSpawn(SpawnListItem *, bool);
  struct category* getCategory(SpawnListItem *);

signals:
  void listUpdated();   // flags in spawns have changed
  void listChanged();   // categories have changed

public slots: 
  void setPlayer(int x, int y, int z, int Dx, int Dy, int Dz, int degrees); 
  void setPlayerLevel(int x);
  void setDebug(bool bset)       { bDebug = bset; }
  void selectNext(void);
  void selectPrev(void);
  void toggleHide(void);

private:
  const char* filterString(spawnStruct *s, int flags = 0);
  void selectAndOpen(SpawnListItem *);
  int      x;
  int      y;
  int      z;
  int      playerLevel;
  QValueList<struct category*> m_categoryList;
  bool     bDebug;
  QValueList<SpawnListItem*> m_spawnList;
};
//--------------------------------------------------

#endif // SPAWNLIST_H


