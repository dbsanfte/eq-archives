/****************************************************************************
** CLineDlg meta object code from reading C++ file 'map.h'
**
** Created: Tue Jun 6 01:16:16 2000
**      by: The Qt Meta Object Compiler ($Revision: 2.53 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#define Q_MOC_CLineDlg
#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 3
#elif Q_MOC_OUTPUT_REVISION != 3
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "map.h"
#include <qmetaobject.h>
#include <qapplication.h>

#if defined(Q_SPARCWORKS_FUNCP_BUG)
#define Q_AMPERSAND
#else
#define Q_AMPERSAND &
#endif


const char *CLineDlg::className() const
{
    return "CLineDlg";
}

QMetaObject *CLineDlg::metaObj = 0;


#if QT_VERSION >= 199
static QMetaObjectInit init_CLineDlg(&CLineDlg::staticMetaObject);

#endif

void CLineDlg::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QDialog::className(), "QDialog") != 0 )
	badSuperclassWarning("CLineDlg","QDialog");

#if QT_VERSION >= 199
    staticMetaObject();
}

QString CLineDlg::tr(const char* s)
{
    return ((QNonBaseApplication*)qApp)->translate("CLineDlg",s);
}

void CLineDlg::staticMetaObject()
{
    if ( metaObj )
	return;
    QDialog::staticMetaObject();
#else

    QDialog::initMetaObject();
#endif

    typedef void(CLineDlg::*m1_t0)(const QString&);
    m1_t0 v1_0 = Q_AMPERSAND CLineDlg::changeColor;
    QMetaData *slot_tbl = QMetaObject::new_metadata(1);
    slot_tbl[0].name = "changeColor(const QString&)";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    metaObj = QMetaObject::new_metaobject(
	"CLineDlg", "QDialog",
	slot_tbl, 1,
	0, 0 );
}


const char *Map::className() const
{
    return "Map";
}

QMetaObject *Map::metaObj = 0;


#if QT_VERSION >= 199
static QMetaObjectInit init_Map(&Map::staticMetaObject);

#endif

void Map::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QWidget::className(), "QWidget") != 0 )
	badSuperclassWarning("Map","QWidget");

#if QT_VERSION >= 199
    staticMetaObject();
}

QString Map::tr(const char* s)
{
    return ((QNonBaseApplication*)qApp)->translate("Map",s);
}

void Map::staticMetaObject()
{
    if ( metaObj )
	return;
    QWidget::staticMetaObject();
#else

    QWidget::initMetaObject();
#endif

    typedef void(Map::*m1_t0)(char*,int);
    typedef void(Map::*m1_t1)(char*,int);
    typedef void(Map::*m1_t2)();
    typedef void(Map::*m1_t3)(int);
    typedef void(Map::*m1_t4)();
    typedef void(Map::*m1_t5)();
    typedef void(Map::*m1_t6)();
    typedef void(Map::*m1_t7)();
    typedef void(Map::*m1_t8)(QListViewItem*);
    typedef void(Map::*m1_t9)();
    typedef void(Map::*m1_t10)();
    typedef void(Map::*m1_t11)();
    typedef void(Map::*m1_t12)(char*,char*);
    typedef void(Map::*m1_t13)();
    typedef void(Map::*m1_t14)(const QString&);
    typedef void(Map::*m1_t15)(const QString&);
    typedef void(Map::*m1_t16)(attack1Struct*);
    typedef void(Map::*m1_t17)(attack2Struct*);
    typedef void(Map::*m1_t18)(considerStruct*);
    typedef void(Map::*m1_t19)(spawnStruct*,int);
    typedef void(Map::*m1_t20)(dropThingOnGround*);
    typedef void(Map::*m1_t21)(removeThingOnGround*);
    typedef void(Map::*m1_t22)(dropCoinsStruct*);
    typedef void(Map::*m1_t23)(removeCoinsStruct*);
    typedef void(Map::*m1_t24)(int,int,int,int,int,int,int);
    typedef void(Map::*m1_t25)(int,int,int);
    typedef void(Map::*m1_t26)(wearChangeStruct*);
    typedef void(Map::*m1_t27)(int);
    typedef void(Map::*m1_t28)();
    typedef void(Map::*m1_t29)(int);
    typedef void(Map::*m1_t30)(int);
    typedef void(Map::*m1_t31)(int);
    typedef void(Map::*m1_t32)(int);
    typedef void(Map::*m1_t33)();
    typedef void(Map::*m1_t34)();
    typedef void(Map::*m1_t35)(QListViewItem*,const QPoint&,int);
    typedef void(Map::*m1_t36)(QListViewItem*,const QPoint&,int);
    typedef void(Map::*m1_t37)();
    typedef void(Map::*m1_t38)();
    typedef void(Map::*m1_t39)();
    typedef void(Map::*m1_t40)(char*);
    typedef void(Map::*m1_t41)(int,int,int,int,int,int,int);
    typedef void(Map::*m1_t42)(int);
    typedef void(Map::*m1_t43)();
    typedef void(Map::*m1_t44)(int);
    typedef void(Map::*m1_t45)(int);
    typedef void(Map::*m1_t46)();
    typedef void(Map::*m1_t47)();
    typedef void(Map::*m1_t48)();
    typedef void(Map::*m1_t49)();
    typedef void(Map::*m1_t50)(int);
    typedef void(Map::*m1_t51)();
    typedef void(Map::*m1_t52)();
    typedef void(Map::*m1_t53)();
    typedef void(Map::*m1_t54)();
    typedef void(Map::*m1_t55)();
    m1_t0 v1_0 = Q_AMPERSAND Map::addGroup;
    m1_t1 v1_1 = Q_AMPERSAND Map::remGroup;
    m1_t2 v1_2 = Q_AMPERSAND Map::clrGroup;
    m1_t3 v1_3 = Q_AMPERSAND Map::makeSpawnLine;
    m1_t4 v1_4 = Q_AMPERSAND Map::makeSelectedSpawnLine;
    m1_t5 v1_5 = Q_AMPERSAND Map::showLineDlg;
    m1_t6 v1_6 = Q_AMPERSAND Map::ZoomIn;
    m1_t7 v1_7 = Q_AMPERSAND Map::ZoomOut;
    m1_t8 v1_8 = Q_AMPERSAND Map::selectSpawn;
    m1_t9 v1_9 = Q_AMPERSAND Map::dumpSpawns;
    m1_t10 v1_10 = Q_AMPERSAND Map::loadMap;
    m1_t11 v1_11 = Q_AMPERSAND Map::saveMap;
    m1_t12 v1_12 = Q_AMPERSAND Map::newZone;
    m1_t13 v1_13 = Q_AMPERSAND Map::zoneChanged;
    m1_t14 v1_14 = Q_AMPERSAND Map::setLineName;
    m1_t15 v1_15 = Q_AMPERSAND Map::setLineColor;
    m1_t16 v1_16 = Q_AMPERSAND Map::attack1Hand1;
    m1_t17 v1_17 = Q_AMPERSAND Map::attack2Hand1;
    m1_t18 v1_18 = Q_AMPERSAND Map::consMessage;
    m1_t19 v1_19 = Q_AMPERSAND Map::newSpawn;
    m1_t20 v1_20 = Q_AMPERSAND Map::newGroundItem;
    m1_t21 v1_21 = Q_AMPERSAND Map::removeGroundItem;
    m1_t22 v1_22 = Q_AMPERSAND Map::newCoinsItem;
    m1_t23 v1_23 = Q_AMPERSAND Map::removeCoinsItem;
    m1_t24 v1_24 = Q_AMPERSAND Map::updateSpawn;
    m1_t25 v1_25 = Q_AMPERSAND Map::updateSpawnHp;
    m1_t26 v1_26 = Q_AMPERSAND Map::spawnWearingUpdate;
    m1_t27 v1_27 = Q_AMPERSAND Map::setPlayerID;
    m1_t28 v1_28 = Q_AMPERSAND Map::refreshMap;
    m1_t29 v1_29 = Q_AMPERSAND Map::deleteSpawn;
    m1_t30 v1_30 = Q_AMPERSAND Map::killSpawn;
    m1_t31 v1_31 = Q_AMPERSAND Map::infoSpawn;
    m1_t32 v1_32 = Q_AMPERSAND Map::ShowHidden;
    m1_t33 v1_33 = Q_AMPERSAND Map::HideSelected;
    m1_t34 v1_34 = Q_AMPERSAND Map::UnHideAll;
    m1_t35 v1_35 = Q_AMPERSAND Map::rightButtonPressed;
    m1_t36 v1_36 = Q_AMPERSAND Map::rightButtonReleased;
    m1_t37 v1_37 = Q_AMPERSAND Map::saveFilters;
    m1_t38 v1_38 = Q_AMPERSAND Map::loadFilters;
    m1_t39 v1_39 = Q_AMPERSAND Map::listFilters;
    m1_t40 v1_40 = Q_AMPERSAND Map::setFilename;
    m1_t41 v1_41 = Q_AMPERSAND Map::setPlayer;
    m1_t42 v1_42 = Q_AMPERSAND Map::setPlayerLevel;
    m1_t43 v1_43 = Q_AMPERSAND Map::ToggleFilterSelected;
    m1_t44 v1_44 = Q_AMPERSAND Map::setPlayerRace;
    m1_t45 v1_45 = Q_AMPERSAND Map::setPlayerClass;
    m1_t46 v1_46 = Q_AMPERSAND Map::addLocation;
    m1_t47 v1_47 = Q_AMPERSAND Map::startLine;
    m1_t48 v1_48 = Q_AMPERSAND Map::addLinePoint;
    m1_t49 v1_49 = Q_AMPERSAND Map::delLinePoint;
    m1_t50 v1_50 = Q_AMPERSAND Map::setAngle;
    m1_t51 v1_51 = Q_AMPERSAND Map::toggleDebug;
    m1_t52 v1_52 = Q_AMPERSAND Map::selectPrev;
    m1_t53 v1_53 = Q_AMPERSAND Map::selectNext;
    m1_t54 v1_54 = Q_AMPERSAND Map::spawnListUpdated;
    m1_t55 v1_55 = Q_AMPERSAND Map::rebuildSpawnList;
    QMetaData *slot_tbl = QMetaObject::new_metadata(56);
    slot_tbl[0].name = "addGroup(char*,int)";
    slot_tbl[1].name = "remGroup(char*,int)";
    slot_tbl[2].name = "clrGroup()";
    slot_tbl[3].name = "makeSpawnLine(int)";
    slot_tbl[4].name = "makeSelectedSpawnLine()";
    slot_tbl[5].name = "showLineDlg()";
    slot_tbl[6].name = "ZoomIn()";
    slot_tbl[7].name = "ZoomOut()";
    slot_tbl[8].name = "selectSpawn(QListViewItem*)";
    slot_tbl[9].name = "dumpSpawns()";
    slot_tbl[10].name = "loadMap()";
    slot_tbl[11].name = "saveMap()";
    slot_tbl[12].name = "newZone(char*,char*)";
    slot_tbl[13].name = "zoneChanged()";
    slot_tbl[14].name = "setLineName(const QString&)";
    slot_tbl[15].name = "setLineColor(const QString&)";
    slot_tbl[16].name = "attack1Hand1(attack1Struct*)";
    slot_tbl[17].name = "attack2Hand1(attack2Struct*)";
    slot_tbl[18].name = "consMessage(considerStruct*)";
    slot_tbl[19].name = "newSpawn(spawnStruct*,int)";
    slot_tbl[20].name = "newGroundItem(dropThingOnGround*)";
    slot_tbl[21].name = "removeGroundItem(removeThingOnGround*)";
    slot_tbl[22].name = "newCoinsItem(dropCoinsStruct*)";
    slot_tbl[23].name = "removeCoinsItem(removeCoinsStruct*)";
    slot_tbl[24].name = "updateSpawn(int,int,int,int,int,int,int)";
    slot_tbl[25].name = "updateSpawnHp(int,int,int)";
    slot_tbl[26].name = "spawnWearingUpdate(wearChangeStruct*)";
    slot_tbl[27].name = "setPlayerID(int)";
    slot_tbl[28].name = "refreshMap()";
    slot_tbl[29].name = "deleteSpawn(int)";
    slot_tbl[30].name = "killSpawn(int)";
    slot_tbl[31].name = "infoSpawn(int)";
    slot_tbl[32].name = "ShowHidden(int)";
    slot_tbl[33].name = "HideSelected()";
    slot_tbl[34].name = "UnHideAll()";
    slot_tbl[35].name = "rightButtonPressed(QListViewItem*,const QPoint&,int)";
    slot_tbl[36].name = "rightButtonReleased(QListViewItem*,const QPoint&,int)";
    slot_tbl[37].name = "saveFilters()";
    slot_tbl[38].name = "loadFilters()";
    slot_tbl[39].name = "listFilters()";
    slot_tbl[40].name = "setFilename(char*)";
    slot_tbl[41].name = "setPlayer(int,int,int,int,int,int,int)";
    slot_tbl[42].name = "setPlayerLevel(int)";
    slot_tbl[43].name = "ToggleFilterSelected()";
    slot_tbl[44].name = "setPlayerRace(int)";
    slot_tbl[45].name = "setPlayerClass(int)";
    slot_tbl[46].name = "addLocation()";
    slot_tbl[47].name = "startLine()";
    slot_tbl[48].name = "addLinePoint()";
    slot_tbl[49].name = "delLinePoint()";
    slot_tbl[50].name = "setAngle(int)";
    slot_tbl[51].name = "toggleDebug()";
    slot_tbl[52].name = "selectPrev()";
    slot_tbl[53].name = "selectNext()";
    slot_tbl[54].name = "spawnListUpdated()";
    slot_tbl[55].name = "rebuildSpawnList()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    slot_tbl[4].ptr = *((QMember*)&v1_4);
    slot_tbl[5].ptr = *((QMember*)&v1_5);
    slot_tbl[6].ptr = *((QMember*)&v1_6);
    slot_tbl[7].ptr = *((QMember*)&v1_7);
    slot_tbl[8].ptr = *((QMember*)&v1_8);
    slot_tbl[9].ptr = *((QMember*)&v1_9);
    slot_tbl[10].ptr = *((QMember*)&v1_10);
    slot_tbl[11].ptr = *((QMember*)&v1_11);
    slot_tbl[12].ptr = *((QMember*)&v1_12);
    slot_tbl[13].ptr = *((QMember*)&v1_13);
    slot_tbl[14].ptr = *((QMember*)&v1_14);
    slot_tbl[15].ptr = *((QMember*)&v1_15);
    slot_tbl[16].ptr = *((QMember*)&v1_16);
    slot_tbl[17].ptr = *((QMember*)&v1_17);
    slot_tbl[18].ptr = *((QMember*)&v1_18);
    slot_tbl[19].ptr = *((QMember*)&v1_19);
    slot_tbl[20].ptr = *((QMember*)&v1_20);
    slot_tbl[21].ptr = *((QMember*)&v1_21);
    slot_tbl[22].ptr = *((QMember*)&v1_22);
    slot_tbl[23].ptr = *((QMember*)&v1_23);
    slot_tbl[24].ptr = *((QMember*)&v1_24);
    slot_tbl[25].ptr = *((QMember*)&v1_25);
    slot_tbl[26].ptr = *((QMember*)&v1_26);
    slot_tbl[27].ptr = *((QMember*)&v1_27);
    slot_tbl[28].ptr = *((QMember*)&v1_28);
    slot_tbl[29].ptr = *((QMember*)&v1_29);
    slot_tbl[30].ptr = *((QMember*)&v1_30);
    slot_tbl[31].ptr = *((QMember*)&v1_31);
    slot_tbl[32].ptr = *((QMember*)&v1_32);
    slot_tbl[33].ptr = *((QMember*)&v1_33);
    slot_tbl[34].ptr = *((QMember*)&v1_34);
    slot_tbl[35].ptr = *((QMember*)&v1_35);
    slot_tbl[36].ptr = *((QMember*)&v1_36);
    slot_tbl[37].ptr = *((QMember*)&v1_37);
    slot_tbl[38].ptr = *((QMember*)&v1_38);
    slot_tbl[39].ptr = *((QMember*)&v1_39);
    slot_tbl[40].ptr = *((QMember*)&v1_40);
    slot_tbl[41].ptr = *((QMember*)&v1_41);
    slot_tbl[42].ptr = *((QMember*)&v1_42);
    slot_tbl[43].ptr = *((QMember*)&v1_43);
    slot_tbl[44].ptr = *((QMember*)&v1_44);
    slot_tbl[45].ptr = *((QMember*)&v1_45);
    slot_tbl[46].ptr = *((QMember*)&v1_46);
    slot_tbl[47].ptr = *((QMember*)&v1_47);
    slot_tbl[48].ptr = *((QMember*)&v1_48);
    slot_tbl[49].ptr = *((QMember*)&v1_49);
    slot_tbl[50].ptr = *((QMember*)&v1_50);
    slot_tbl[51].ptr = *((QMember*)&v1_51);
    slot_tbl[52].ptr = *((QMember*)&v1_52);
    slot_tbl[53].ptr = *((QMember*)&v1_53);
    slot_tbl[54].ptr = *((QMember*)&v1_54);
    slot_tbl[55].ptr = *((QMember*)&v1_55);
    typedef void(Map::*m2_t0)(int,int,int,int,int,int,int);
    typedef void(Map::*m2_t1)(const QString&);
    typedef void(Map::*m2_t2)(int,int);
    typedef void(Map::*m2_t3)(int,int);
    typedef void(Map::*m2_t4)();
    typedef void(Map::*m2_t5)(const QString&);
    typedef void(Map::*m2_t6)(const QString&,int);
    typedef void(Map::*m2_t7)(int);
    m2_t0 v2_0 = Q_AMPERSAND Map::playerChanged;
    m2_t1 v2_1 = Q_AMPERSAND Map::newZoneName;
    m2_t2 v2_2 = Q_AMPERSAND Map::selSpawnUpdate;
    m2_t3 v2_3 = Q_AMPERSAND Map::hpChanged;
    m2_t4 v2_4 = Q_AMPERSAND Map::deleteSkills;
    m2_t5 v2_5 = Q_AMPERSAND Map::msgReceived;
    m2_t6 v2_6 = Q_AMPERSAND Map::stsMessage;
    m2_t7 v2_7 = Q_AMPERSAND Map::numSpawns_;
    QMetaData *signal_tbl = QMetaObject::new_metadata(8);
    signal_tbl[0].name = "playerChanged(int,int,int,int,int,int,int)";
    signal_tbl[1].name = "newZoneName(const QString&)";
    signal_tbl[2].name = "selSpawnUpdate(int,int)";
    signal_tbl[3].name = "hpChanged(int,int)";
    signal_tbl[4].name = "deleteSkills()";
    signal_tbl[5].name = "msgReceived(const QString&)";
    signal_tbl[6].name = "stsMessage(const QString&,int)";
    signal_tbl[7].name = "numSpawns_(int)";
    signal_tbl[0].ptr = *((QMember*)&v2_0);
    signal_tbl[1].ptr = *((QMember*)&v2_1);
    signal_tbl[2].ptr = *((QMember*)&v2_2);
    signal_tbl[3].ptr = *((QMember*)&v2_3);
    signal_tbl[4].ptr = *((QMember*)&v2_4);
    signal_tbl[5].ptr = *((QMember*)&v2_5);
    signal_tbl[6].ptr = *((QMember*)&v2_6);
    signal_tbl[7].ptr = *((QMember*)&v2_7);
    metaObj = QMetaObject::new_metaobject(
	"Map", "QWidget",
	slot_tbl, 56,
	signal_tbl, 8 );
}

#include <qobjectdefs.h>
#include <qsignalslotimp.h>

// SIGNAL playerChanged
void Map::playerChanged( int t0, int t1, int t2, int t3, int t4, int t5, int t6 )
{
    // No builtin function for signal parameter type int,int,int,int,int,int,int
    QConnectionList *clist = receivers("playerChanged(int,int,int,int,int,int,int)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(int);
    typedef RT1 *PRT1;
    typedef void (QObject::*RT2)(int,int);
    typedef RT2 *PRT2;
    typedef void (QObject::*RT3)(int,int,int);
    typedef RT3 *PRT3;
    typedef void (QObject::*RT4)(int,int,int,int);
    typedef RT4 *PRT4;
    typedef void (QObject::*RT5)(int,int,int,int,int);
    typedef RT5 *PRT5;
    typedef void (QObject::*RT6)(int,int,int,int,int,int);
    typedef RT6 *PRT6;
    typedef void (QObject::*RT7)(int,int,int,int,int,int,int);
    typedef RT7 *PRT7;
    RT0 r0;
    RT1 r1;
    RT2 r2;
    RT3 r3;
    RT4 r4;
    RT5 r5;
    RT6 r6;
    RT7 r7;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	    case 2:
		r2 = *((PRT2)(c->member()));
		(object->*r2)(t0, t1);
		break;
	    case 3:
		r3 = *((PRT3)(c->member()));
		(object->*r3)(t0, t1, t2);
		break;
	    case 4:
		r4 = *((PRT4)(c->member()));
		(object->*r4)(t0, t1, t2, t3);
		break;
	    case 5:
		r5 = *((PRT5)(c->member()));
		(object->*r5)(t0, t1, t2, t3, t4);
		break;
	    case 6:
		r6 = *((PRT6)(c->member()));
		(object->*r6)(t0, t1, t2, t3, t4, t5);
		break;
	    case 7:
		r7 = *((PRT7)(c->member()));
		(object->*r7)(t0, t1, t2, t3, t4, t5, t6);
		break;
	}
    }
}

// SIGNAL newZoneName
void Map::newZoneName( const QString& t0 )
{
    activate_signal_strref( "newZoneName(const QString&)", t0 );
}

// SIGNAL selSpawnUpdate
void Map::selSpawnUpdate( int t0, int t1 )
{
    // No builtin function for signal parameter type int,int
    QConnectionList *clist = receivers("selSpawnUpdate(int,int)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(int);
    typedef RT1 *PRT1;
    typedef void (QObject::*RT2)(int,int);
    typedef RT2 *PRT2;
    RT0 r0;
    RT1 r1;
    RT2 r2;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	    case 2:
		r2 = *((PRT2)(c->member()));
		(object->*r2)(t0, t1);
		break;
	}
    }
}

// SIGNAL hpChanged
void Map::hpChanged( int t0, int t1 )
{
    // No builtin function for signal parameter type int,int
    QConnectionList *clist = receivers("hpChanged(int,int)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(int);
    typedef RT1 *PRT1;
    typedef void (QObject::*RT2)(int,int);
    typedef RT2 *PRT2;
    RT0 r0;
    RT1 r1;
    RT2 r2;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	    case 2:
		r2 = *((PRT2)(c->member()));
		(object->*r2)(t0, t1);
		break;
	}
    }
}

// SIGNAL deleteSkills
void Map::deleteSkills()
{
    activate_signal( "deleteSkills()" );
}

// SIGNAL msgReceived
void Map::msgReceived( const QString& t0 )
{
    activate_signal_strref( "msgReceived(const QString&)", t0 );
}

// SIGNAL stsMessage
void Map::stsMessage( const QString& t0, int t1 )
{
    // No builtin function for signal parameter type const QString&,int
    QConnectionList *clist = receivers("stsMessage(const QString&,int)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(const QString&);
    typedef RT1 *PRT1;
    typedef void (QObject::*RT2)(const QString&,int);
    typedef RT2 *PRT2;
    RT0 r0;
    RT1 r1;
    RT2 r2;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	    case 2:
		r2 = *((PRT2)(c->member()));
		(object->*r2)(t0, t1);
		break;
	}
    }
}

// SIGNAL numSpawns_
void Map::numSpawns_( int t0 )
{
    activate_signal( "numSpawns_(int)", t0 );
}
