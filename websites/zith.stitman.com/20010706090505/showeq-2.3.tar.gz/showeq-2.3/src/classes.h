/*
 *  classes.h
 *  
 *  ShowEQ Distributed under GPL
 *  http://www.hackersquest.gomp.ch/
 */

/* Maps class numbers to strings, included from util.cpp */

case 1:
strcpy (class_, "Warrior");
break;
case 2:
strcpy (class_, "Cleric");
break;
case 3:
strcpy (class_, "Paladin");
break;
case 4:
strcpy (class_, "Ranger");
break;
case 5:
strcpy (class_, "Shadow Knight");
break;
case 6:
strcpy (class_, "Druid");
break;
case 7:
strcpy (class_, "Monk");
break;
case 8:
strcpy (class_, "Bard");
break;
case 9:
strcpy (class_, "Rogue");
break;
case 10:
strcpy (class_, "Shaman");
break;
case 11:
strcpy (class_, "Necromancer");
break;
case 12:
strcpy (class_, "Wizard");
break;
case 13:
strcpy (class_, "Magician");
break;
case 14:
strcpy (class_, "Enchanter");
break;

case 15:
strcpy (class_, "Shopkeeper");
break;
case 16:
strcpy (class_, "Banker");
break;

case 17:
strcpy (class_, "GM Warrior");
break;
case 18:
strcpy (class_, "GM Cleric");
break;
case 19:
strcpy (class_, "GM Paladin");
break;
case 20:
strcpy (class_, "GM Ranger");
break;
case 21:
strcpy (class_, "GM ShadowKnight");
break;
case 22:
strcpy (class_, "GM Druid");
break;
case 23:
strcpy (class_, "GM Monk");
break;
case 24:
strcpy (class_, "GM Bard");
break;
case 25:
strcpy (class_, "GM Rogue");
break;
case 26:
strcpy (class_, "GM Shaman");
break;
case 27:
strcpy (class_, "GM Necromancer");
break;
case 28:
strcpy (class_, "GM Wizard");
break;
case 29:
strcpy (class_, "GM Magician");
break;
case 30:
strcpy (class_, "GM Enchanter");
break;
