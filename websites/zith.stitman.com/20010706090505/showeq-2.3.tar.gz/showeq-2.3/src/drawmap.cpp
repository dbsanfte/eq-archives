/*
 * drawmap.cpp
 *
 * ShowEQ Distributed under GPL
 * http://www.hackersquest.gomp.ch/
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
extern "C" {
#include <gd.h>
#include <gdfonts.h>
}

#include "util.h"
#include "main.h"

int locationX[256];
int locationY[256];
int linePoints[256];
int lineX[256][256];
int lineY[256][256];
int lineColor[256];

int maxX = 50;
int minX = -50;
int maxY = 50;
int minY = -50;
int mapLengthX = 100;
int mapLengthY = 100;
int numLocations = 0;
int numLines = 0;
int screenCenterX = 300;
int screenCenterY = 300;
int screenLengthX = 600;
int screenLengthY = 600;

char zoneLong[128];
char zoneShort[128];
int ZoomAmmount = 2;
int zoomMaxX;
int zoomMaxY;
int zoomMinX;
int zoomMinY;
int zoomMapLengthX;
int zoomMapLengthY;
int x=0;
int y=0;

void reAdjust ()
{
  int xoff = 0, yoff = 0;
  screenLengthX = 600;
  screenLengthY = 600;

  mapLengthX = maxX - minX;
  mapLengthY = maxY - minY;

  if (!mapLengthX)
    {
      mapLengthX = 5000;
      maxX = 2500;
      minX = -2500;
    }
  if (!mapLengthY)
    {
      mapLengthY = 5000;
      maxY = 2500;
      minY = -2500;
    }

  zoomMaxX = x + (mapLengthX / (ZoomAmmount));
  zoomMinX = x - (mapLengthX / (ZoomAmmount));

  zoomMaxY = y + (mapLengthY / (ZoomAmmount));
  zoomMinY = y - (mapLengthY / (ZoomAmmount));

  if (zoomMaxX > maxX)
    {
      zoomMinX -= (zoomMaxX - maxX);
      zoomMaxX -= (zoomMaxX - maxX);
    }

  if (zoomMaxY > maxY)
    {
      zoomMinY -= (zoomMaxY - maxY);
      zoomMaxY -= (zoomMaxY - maxY);
    }

  if (zoomMinX < minX)
    {
      zoomMaxX -= (zoomMinX - minX);
      zoomMinX -= (zoomMinX - minX);
    }

  if (zoomMinY < minY)
    {
      zoomMaxY -= (zoomMinY - minY);
      zoomMinY -= (zoomMinY - minY);
    }

  zoomMapLengthX = zoomMaxX - zoomMinX;
  zoomMapLengthY = zoomMaxY - zoomMinY;

  if (!zoomMapLengthX)
    {
      zoomMapLengthX = 5000;
      zoomMaxX = 2500;
      zoomMinX = -2500;
    }
  if (!mapLengthY)
    {
      zoomMapLengthY = 5000;
      zoomMaxY = 2500;
      zoomMinY = -2500;
    }

  if (zoomMapLengthX > zoomMapLengthY)
    {
      yoff = (zoomMapLengthX - zoomMapLengthY) / 2;
      xoff = 0;
      zoomMapLengthY = zoomMapLengthX;
    }
  else
    {
      yoff = 0;
      xoff = (zoomMapLengthY - zoomMapLengthX) / 2;
      zoomMapLengthX = zoomMapLengthY;
    }

  if (mapLengthX > mapLengthY)
    mapLengthY = mapLengthX;
  else
    mapLengthX = mapLengthY;

  screenCenterX = ((zoomMaxX * 600 + xoff * 600) / zoomMapLengthX);
  screenCenterY = ((zoomMaxY * 600 + yoff * 600) / zoomMapLengthY);
}

void loadFileMap (char *filename)
{
  FILE * fh;
  char line[4096];
  char tempstr[4096];

  maxX = 0;
  minX = 0;
  maxY = 0;
  minY = 0;

  numLocations = 0;
  numLines = 0;

  if ((fh = fopen (filename, "r")) != NULL)
    {
      fgets (line, 4095, fh);
      strcpy (zoneLong, strtok (line, ","));	// Zone name
      strcpy (zoneShort, strtok (NULL, ","));	// Zone short name
      screenCenterX = atoi (strtok (NULL, ","));
      screenCenterY = atoi (strtok (NULL, ","));
      screenLengthX = atoi (strtok (NULL, ","));
      screenLengthY = atoi (strtok (NULL, ","));
      mapLengthX = atoi (strtok (NULL, ","));
      mapLengthY = atoi (strtok (NULL, "\n"));

      while (fgets (line, 4095, fh))
	{
	  strcpy (tempstr, strtok (line, ","));
	  switch (tempstr[0])
	    {
	    case 'L':
	      strtok (NULL, ",");	// Line name
	      lineColor[numLines] = atoi (strtok (NULL, ","));	// Line color
	      linePoints[numLines] = atoi (strtok (NULL, ","));	// Number of points
	      for (int n = 0; n < linePoints[numLines]; n++)
		{
		  lineX[numLines][n] = atoi (strtok (NULL, ",\n"));
		  lineY[numLines][n] = atoi (strtok (NULL, ",\n"));
		  if (lineX[numLines][n] > maxX)
		    maxX = lineX[numLines][n];
		  if (lineY[numLines][n] > maxY)
		    maxY = lineY[numLines][n];
		  if (lineX[numLines][n] < minX)
		    minX = lineX[numLines][n];
		  if (lineY[numLines][n] < minY)
		    minY = lineY[numLines][n];
		}
	      numLines++;
	      break;
	    case 'P':
	      strtok (NULL, ",");	// Location name
	      strtok (NULL, ",");	// Location color
	      locationX[numLocations] = atoi (strtok (NULL, ",\n"));
	      locationY[numLocations] = atoi (strtok (NULL, ",\n"));
	      numLocations++;
	      break;
	    }
	}

      fclose (fh);
      char message[128];
      sprintf (message, "%s [%s]", zoneLong, zoneShort);
      
      reAdjust ();
    }
}


int calcXOffset (int mapCoordinate)
{
  int screenLength = screenLengthX;
  int mapLength = zoomMapLengthX;
  int screenCenter = screenCenterX;

  float ratio = (float) mapLength / (float) screenLength;	/* 9.6 */

  float offset = (float) mapCoordinate / ratio;
  float screenCoordinate = (float) screenCenter - offset;

  return (int) screenCoordinate;

}

int calcYOffset (int mapCoordinate)
{
  int screenLength = screenLengthY;
  int mapLength = zoomMapLengthY;
  int screenCenter = screenCenterY;

  float ratio = (float) mapLength / (float) screenLength;	/* 9.6 */

  float offset = (float) mapCoordinate / ratio;
  float screenCoordinate = (float) screenCenter - offset;

  return (int) screenCoordinate;
}

void paintMap ()
{
  /* Declare the image */
  gdImagePtr im;

  /* Color indexes */
  int black;
  int white;
  int gridgray;
  int mapcolors[16];

  /* Allocate the image */
  im = gdImageCreate(600, 600);

  /* Allocate colors */
  black = gdImageColorAllocate (im, 0, 0, 0);
  white = gdImageColorAllocate (im, 255, 255, 255);
  gridgray = gdImageColorAllocate (im, 64, 64, 64);

  /* Allocate map colors */
  mapcolors[0] = gdImageColorAllocate (im, 196, 196, 196); // gray
  mapcolors[1] = gdImageColorAllocate (im, 0, 0, 128); // darkblue
  mapcolors[2] = gdImageColorAllocate (im, 0, 128, 0); // darkgreen
  mapcolors[3] = gdImageColorAllocate (im, 0, 128, 128); // darkcyan
  mapcolors[4] = gdImageColorAllocate (im, 128, 0, 0); // darkred
  mapcolors[5] = gdImageColorAllocate (im, 128, 0, 128); // darkmagenta
  mapcolors[6] = gdImageColorAllocate (im, 128, 128, 0); // darkyellow
  mapcolors[7] = gdImageColorAllocate (im, 128, 128, 128); // darkgray
  mapcolors[8] = gdImageColorAllocate (im, 255, 255, 255); // white
  mapcolors[9] = gdImageColorAllocate (im, 0, 0, 255); // blue
  mapcolors[10] = gdImageColorAllocate (im, 0, 255, 0); // green
  mapcolors[11] = gdImageColorAllocate (im, 0, 255, 255); // cyan
  mapcolors[12] = gdImageColorAllocate (im, 255, 0, 0); // red
  mapcolors[13] = gdImageColorAllocate (im, 255, 0, 255); // red
  mapcolors[14] = gdImageColorAllocate (im, 255, 255, 0); // red
  mapcolors[15] = gdImageColorAllocate (im, 196, 196, 196); // gray
  
  /* Draw the grid */
  for (int gx = (zoomMinX / 1000) - 1; gx <= (zoomMaxX / 1000) + 1; gx++)
    {
      int sx, sy;
      gdImageLine (im, sx=calcXOffset (gx * 1000), sy=0, calcXOffset (gx *
				      1000), 600, gridgray);
      char label[32];
      sprintf (label, "%d", gx*1000);
      gdImageString (im, gdFontSmall, sx+1, sy, (unsigned char *)label, gridgray);
      gdImageString (im, gdFontSmall, sx+1, sy-10, (unsigned char *)label, gridgray);
    }
  for (int gy = (zoomMinY / 1000) - 1; gy <= (zoomMaxY / 1000) + 1; gy++)
    {
      int sx, sy;
      gdImageLine (im, sx=0, sy=calcYOffset (gy * 1000), 600, calcYOffset (gy
					* 1000), gridgray);  
      char label[32];
      sprintf (label, "%d", gy*1000);
      gdImageString (im, gdFontSmall, sx, sy, (unsigned char *)label, gridgray);
    }
  /* Draw lines */

  for (int l = 0; l < numLines; l++)
    {
      for (int n =0; n<(linePoints[l]-1); n++)
        {
          gdImageLine (im, 
		      calcXOffset (lineX[l][n]), calcYOffset (lineY[l][n]),
		      calcXOffset (lineX[l][n+1]), calcYOffset (lineY[l][n+1]),
			      mapcolors[lineColor[l]]);
        }
    }

  /* Print the http header */
  printf ("Content-type: image/gif\n\n");

  /* Output image */
  gdImageGif(im, stdout);

  /* Destroy image */
  gdImageDestroy(im);

}

int main (int argc, char *argv[])
{
  /* Check if we were passed a map to read */	
  if (argc!=2)
    {
      printf ("Content-type: text/html\n\n");
      printf ("Need map name\n");
    }
  else
    {	  
      char tfilename[256];
      char filename[256];
      strcpy (tfilename, argv[1]);
      /* Strip out any '/'s */
      for (int a=0; a<strlen(tfilename); a++)
	      if (tfilename[a]=='/')
		      tfilename[a]='_';
      sprintf (filename, "%s/%s", MAPDIR,tfilename);
      loadFileMap (filename);
      paintMap();
    }
}
