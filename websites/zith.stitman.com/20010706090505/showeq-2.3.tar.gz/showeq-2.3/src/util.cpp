/*
 * util.cpp
 *
 * ShowEQ Distributed under GPL
 * http://www.hackersquest.gomp.ch/
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>

#include <qcolor.h>

#include "util.h"

#undef DEBUG

/*
 * Generate comma separated string from long int
 */
char *
Commanate(UDWORD number)
{
   UDWORD	threeDigits;
   char *	oldstring;
   char *	newstring;
   char		buffer[4];

   if (number >= 1000L)
     oldstring = Commanate(number / 1000L);
   else
     oldstring = NULL;

   threeDigits = number % 1000L;
   if (oldstring == NULL)
     sprintf(buffer, "%lu", threeDigits);
   else
     sprintf(buffer, "%03lu", threeDigits);

   if (oldstring == NULL)
   {
      if ((newstring = (char *) strdup(buffer)) == NULL)
      {
	 printf("Out of memory....exiting\n");
	 exit(1);
      }

   }
   else
   {
      if ((newstring = (char *) calloc(strlen(oldstring) + strlen(buffer) + 2, sizeof(char))) == NULL)
      {
	 printf("Out of memory....exiting\n");
	 exit(1);
      }
      sprintf(newstring, "%s,%s", oldstring, buffer);
      free(oldstring);
   }
   return(newstring);
} /* END Commanate */


char *
spell_name (int spellId)
{
  static char spellname[256];
  switch (spellId)
    {
#include "spells.h"
    default:
      sprintf (spellname, "%d", spellId);
    }

  return spellname;
}

char *
skill_name (int skillId)
{
  static char skill[256];
  switch (skillId)
    {
#include "skills.h"
    default:
      sprintf (skill, "%d", skillId);
    }

  return skill;
}

char *
light_name (unsigned char lightId)
{
  static char light[256];
  switch (lightId)
    {
    case 0:
      strcpy (light, "");
      break;
      // No light
    case 1:
      strcpy (light, "CDL");
      break;
      // Candle
    case 2:
      strcpy (light, "TR");
      break;
      // Torch
    case 3:
      strcpy (light, "TGS");
      break;
      // Tiny Glowing Skull
    case 4:
      strcpy (light, "SL");
      break;
      // Small lantern
    case 5:
      strcpy (light, "SoM");
      break;
      // Stein of Moggok
    case 6:
      strcpy (light, "LL");
      break;
      // Large lantern
    case 7:
      strcpy (light, "FL");
      break;
      // Flameless lantern, Halo of Light
    case 8:
      strcpy (light, "GOS");
      break;
      // Globe of stars
    case 9:
      strcpy (light, "LG");
      break;
      // Light Globe
    case 10:
      strcpy (light, "LS");
      break;
      // Lightstone, Burnt-out lightstone, wispstone
    case 11:
      strcpy (light, "GLS");
      break;
      // Greater lightstone
    case 12:
      strcpy (light, "FBE");
      break;
      // Fire Beatle Eye, Firefly Globe
    case 13:
      strcpy (light, "CL");
      break;
      // Coldlight
    default:
      sprintf (light, "%d", lightId);
    }
  return light;
}

char *
race_name (int raceId)
{
  static char race[256];
  switch (raceId)
    {
#include "races.h"
    default:
      sprintf (race, "%d", raceId);
    }

  return race;
}

char *
language_name (int langId)
{
  static char lang[256];
  switch (langId)
    {
#include "languages.h"
    default:
      sprintf (lang, "%d", langId);
    }

  return lang;
}


char *
class_name (int classId)
{
  static char class_[256];
  switch (classId)
    {
#include "classes.h"
    default:
      sprintf (class_, "%d", classId);
    }

  return class_;
}
char *
print_addr (unsigned long addr)
{
  static char paddr[64];

  switch (addr)
    {
    case 0x6402a8c0:
      strcpy (paddr, "client");
      break;
    default:
      sprintf (paddr, "%d.%d.%d.%d",
	       addr & 0x000000ff,
	       (addr & 0x0000ff00) >> 8,
	       (addr & 0x00ff0000) >> 16, (addr & 0xff000000) >> 24);
    }
  return paddr;
}

/* Saves item to item DB */
void
itemdb (struct itemStruct *item)
{
  FILE *idb;
  struct itemStruct i;
  int found = 0;

  if ((idb = fopen (LOGDIR "/item.db", "r")) != NULL)
    {
      while (fread (&i, sizeof (itemStruct), 1, idb))
	{
	  if (item->itemNr == i.itemNr)
	    {
	      found = 1;
	      break;
	    }
	}
      fclose (idb);
    }

  if (!found)
    {
      if ((idb = fopen (LOGDIR "/item.db", "a")) != NULL)
	{
          printf("New Item: %s(%i)\n", item->name, item->itemNr);
	  fwrite (item, sizeof (itemStruct), 1, idb);
	  fclose (idb);
	}
    }
}

char *getitemNameFromDB (int itemNr)
{
  FILE *idb;
  struct itemStruct i;
  int found = 0;

  if ((idb = fopen (LOGDIR "/item.db", "r")) != NULL)
    {
      while (fread (&i, sizeof (itemStruct), 1, idb))
	{
	  if (itemNr == i.itemNr)
	    {
	      found = 1;
	      break;
	    }
	}
      fclose (idb);
    }

  if (!found)
    return "";
  else
    return i.lore;
}


/* Saves spawn to spawn DB */
void spawndb (struct dbSpawnStruct *dbSpawn)
{
   FILE *sdb;
   struct dbSpawnStruct s;
   int found=0;
   char thisname[256];
   char dbname[256];

   /* Check if this is not a player or a corpse */
   if (dbSpawn->spawn.NPC == 0 || dbSpawn->spawn.NPC == 2) {
      return;
   }

   strcpy (thisname, dbSpawn->spawn.name);
   for (int a=0; a<strlen(dbSpawn->spawn.name); a++)
     if (thisname[a]<='9')
       thisname[a]=0;

   if ((sdb = fopen (SPAWNFILE, "r")) != NULL)
   {
      while (fread (&s, sizeof(dbSpawnStruct), 1, sdb))
      {
	 strcpy (dbname, s.spawn.name);
	 for (int a=0; a<strlen(s.spawn.name); a++)
	   if (dbname[a]<='9')
	     dbname[a]=0;
	 if (	(!strcmp(dbname, thisname)) &&
		(dbSpawn->spawn.maxHp == s.spawn.maxHp) &&	// Added to catch changed guards
		(dbSpawn->spawn.level == s.spawn.level) &&
		(!strcmp(dbSpawn->zoneName, s.zoneName)) )
	 {
	    found=1;
	    break;
	 }
      }

      fclose (sdb);
   }
   else {
      puts("Error opening spawn file '" SPAWNFILE "'");
   }

   if (!found)
   {
      if ((sdb = fopen (SPAWNFILE, "a")) != NULL)
      {
	 fwrite (dbSpawn, sizeof(dbSpawnStruct), 1, sdb);
	 fclose (sdb);
      }
      else {
         puts("Error opening spawn file '" SPAWNFILE "'");
      }
   }
}

void petdb(struct petStruct *spawn)
{
   FILE *pdb;
   struct petStruct s;
   int found=0;
   char dbname[256];

   if ((pdb = fopen (LOGDIR "/pet.db", "r")) != NULL)
   {
      while (fread (&s, sizeof(petStruct), 1, pdb))
      {
	 // Unique on owner class, owner level and pet level
	 if ((spawn->owner.class_==s.owner.class_) && 
	     (spawn->owner.level==s.owner.level) &&
	     (spawn->pet.level==s.pet.level))
	 {
	    found=1;
	    break;
	 }
      }

      fclose (pdb);
   }

   if (!found)
   {
      if ((pdb = fopen (LOGDIR "/pet.db", "a")) != NULL)
      {
	 fwrite (spawn, sizeof(petStruct), 1, pdb);
	 fclose (pdb);
      }
   }   
}

char *print_race (unsigned int races)
{
  static char race_str[256];

  race_str[0] = 0;

  if (races == 0x0000)
    {
      strcpy (race_str, "NONE");
      return race_str;
    }
  if (races == 0x0fff)
    {
      strcpy (race_str, "ALL");
      return race_str;
    }
  if (races & 1)
    strcat (race_str, "HUM ");
  if (races & 2)
    strcat (race_str, "BAR ");
  if (races & 4)
    strcat (race_str, "ERU ");
  if (races & 8)
    strcat (race_str, "ELF ");
  if (races & 16)
    strcat (race_str, "HIE ");
  if (races & 32)
    strcat (race_str, "DEF ");
  if (races & 64)
    strcat (race_str, "HEF ");
  if (races & 128)
    strcat (race_str, "DWF ");
  if (races & 256)
    strcat (race_str, "TRL ");
  if (races & 512)
    strcat (race_str, "OGR ");
  if (races & 1024)
    strcat (race_str, "HFL ");
  if (races & 2048)
    strcat (race_str, "GNM ");

  return race_str;
}

char *
print_class (unsigned int classes)
{
  static char class_str[256];

  class_str[0] = 0;

  if (classes == 0x0000)
    {
      strcpy (class_str, "NONE");
      return class_str;
    }
  if (classes == 0x3fff)
    {
      strcpy (class_str, "ALL");
      return class_str;
    }

  if (classes & 1)
    strcat (class_str, "WAR ");
  if (classes & 2)
    strcat (class_str, "CLR ");
  if (classes & 4)
    strcat (class_str, "PAL ");
  if (classes & 8)
    strcat (class_str, "RNG ");
  if (classes & 16)
    strcat (class_str, "SHD ");
  if (classes & 32)
    strcat (class_str, "DRU ");
  if (classes & 64)
    strcat (class_str, "MNK ");
  if (classes & 128)
    strcat (class_str, "BRD ");
  if (classes & 256)
    strcat (class_str, "ROG ");
  if (classes & 512)
    strcat (class_str, "SHM ");
  if (classes & 1024)
    strcat (class_str, "NEC ");
  if (classes & 2048)
    strcat (class_str, "WIZ ");
  if (classes & 4096)
    strcat (class_str, "MAG ");
  if (classes & 8192)
    strcat (class_str, "ENC ");

  return class_str;
}

const char *
print_material (unsigned char material)
{
  static char mat_str[256];

  switch (material)
    {
	case 0x00:
		return "None";
	case 0x01:
		return "Leather";
	case 0x02:
		return "Ringmail";
	case 0x03:
		return "Plate";
	case 0x04:
		return "Cured Silk";
	case 0x05:
		return "Chitin";
	case 0x07:
		return "Scale/BlackIron?";
	case 0x0A:
		return "ElementRobe";
	case 0x0B:
		return "BlightedRobe";
	case 0x0D:
		return "OracleRobe";
	case 0x0F:
		return "MetallicRobe";
	case 0x10:
		return "Robe";
	default:
		sprintf(mat_str, "U%02x",material);
		return mat_str;
    }
}

const char *
print_weapon (unsigned char weapon)
{
  static char wstr[256];

  switch (weapon)
    {
	case 0x00:
		return "None";
	case 0x01:
		return "1HSword";
	case 0x02:
		return "2HSword";
	case 0x03:
		return "Axe";
	case 0x04:
		return "Bow";
	case 0x05:
		return "Dagger";
	case 0x06:
		return "Flute";
	case 0x07:
		return "Mace";
	case 0x08:
		return "2HStaff";
        case 0x09:
		return "DwarvenAxe";
	case 0x0A:
		return "Arrow";
	case 0x0e:
		return "WarHammer";
	case 0x0f:
		return "Trumpet";
	case 0x10:
		return "Spear";
	case 0x11:
		return "ShortSpear";
	case 0x12:
		return "Club";
	case 0x13:
		return "MorningStar";
	case 0x14:
		return "Rapier";
	case 0x15:
		return "Lute";
	case 0x17:
		return "Halberd";
	case 0x18:
		return "2HHammer";
	case 0x19:
		return "2HBattleAxe";
	case 0x1A:
		return "IcyBlade(P)";
	case 0x1B:
		return "Book";
	case 0x1C:
		return "DarkBook";
	case 0x1D:
		return "WrithingStaff";
	case 0x1F:
		return "SpikeClub";
	case 0x20:
		return "Broom";
	case 0x21:
		return "HammFlat";
	case 0x22:
		return "Shortsword";
	case 0x23:
		return "Scepter";
	case 0x24:
		return "Torch";
	case 0x25:
		return "Cudgel";
	case 0x26:
		return "Fishing Pole";
	case 0x27:
		return "Scythe";
	case 0x29:
		return "Scimitar";	// Was Bronze....
	case 0x2A:
		return "Falchion";
	case 0x2B:
		return "Pick";
	case 0x2D:
		return "CrystalStaff";
	case 0x2E:
		return "BoneWand";
	case 0x2F:
		return "Wand";
	case 0x30:
		return "Lantern";
	case 0x31:
		return "Maul";		// BIG hammer
	case 0x32:
		return "Dirk";
	case 0x33:
		return "GoldScepter";
	case 0x34:
		return "Shovel";
	case 0x35:
		return "Flamberge";
	case 0x38:
		return "Stein";
	case 0x39:
		return "BroadSword";
	case 0x3a:
		return "BastardSword";
	case 0x3b:
		return "MiningPick";
	case 0x3c:
		return "BattleAxe";
	case 0x3d:
		return "Whip";
	case 0x3e:
		return "FlameSword";
	case 0x3f:
	case 0x40:
		return "Generic";
	case 0x41:
		return "Letter";
	case 0x42:
		return "Forge";
	case 0x43:
		return "Doll";
	case 0x44:
		return "Manastone";
	case 0x45:
		return "Oven";
	case 0x46:
		return "BrewBarrel";
	case 0x47:
		return "Claws";
	case 0x48:
		return "Stone";
	case 0x49:
		return "Kiln";
	case 0x4A:
		return "PotteryWheel";
	case 0x4B:
		return "WoodenCrook";
	case 0x50:
		return "ExecutionerAxe";
	case 0x52:
		return "Fer'Esh";
	case 0x53:
		return "Silver2HAxe";
	case 0x55:
		return "SerratedSword";
	case 0x56:
		return "Falchion";
	case 0x5a:
		return "SwordPassage";
	case 0x5b:
		return "Ulak";
	case 0x5f:
		return "YkeshaTB";
	case 0x57:
		return "YkeshaSS";
	case 0x64:
		return "SheerBlade";
	case 0x67:
		return "PartisanSpear";
	case 0x68:
		return "KunzarKu'juch";
	case 0x69:
		return "Shan'Tok";
	case 0x6e:
		return "LegChopper";
	case 0x80:
		return "Loom";
	case 0x84:
		return "Harpoon";
	case 0xc8:
		return "QeynosShield";
	case 0xc9:
		return "WoodenShield";
	case 0xca:
		return "KiteShield";	// Small..?
	case 0xcb:
		return "RoundShield";	// Small..?
	case 0xcc:
		return "DarkwoodShield";
	case 0xcd:
		return "BoneShield";
	case 0xce:
		return "DarkShield";
	case 0xd2:
		return "ShimmerOrb";
	case 0xd3:
		return "UnicornShield";
	case 0xd4:
		return "NautilusShield";
	case 0xD5:
		return "MistmooreShield";
	case 0xD6:
		return "ChitinShield";
	case 0xD8:
		return "IksTargShield";
	default:
		sprintf(wstr, "U%02x", weapon);
		return wstr;
     }
}

char *
print_skill (unsigned char skill)
{
  static char skill_str[256];

  switch (skill)
    {
    case 0:
      strcpy (skill_str, "1H Slash");
      break;
    case 1:
      strcpy (skill_str, "2H Slash");
      break;
    case 2:
      strcpy (skill_str, "Piercing");
      break;
    case 3:
      strcpy (skill_str, "1H Blunt");
      break;
    case 4:
      strcpy (skill_str, "2H Blunt");
      break;
    default:
      strcpy (skill_str, "Unknown");
    }

  return skill_str;
}
char *
print_slot (unsigned long slots_)
{
  static char slot_str[256];
  slot_str[0] = 0;

  if (slots_ == 0x00000000)
    {
      strcpy (slot_str, "NONE");
    }

  if (slots_ & 0x00000001)
    strcat (slot_str, "SLOT001 ");
  if (slots_ & 0x00000002)
    strcat (slot_str, "EAR1 ");
  if (slots_ & 0x00000004)
    strcat (slot_str, "HEAD ");
  if (slots_ & 0x00000008)
    strcat (slot_str, "FACE ");
  if (slots_ & 0x00000010)
    strcat (slot_str, "EAR2 ");
  if (slots_ & 0x00000020)
    strcat (slot_str, "NECK ");
  if (slots_ & 0x00000040)
    strcat (slot_str, "SHOULDERS ");
  if (slots_ & 0x00000080)
    strcat (slot_str, "ARMS ");
  if (slots_ & 0x00000100)
    strcat (slot_str, "BACK ");
  if (slots_ & 0x00000200)
    strcat (slot_str, "WRIST1 ");
  if (slots_ & 0x00000400)
    strcat (slot_str, "WRIST2 ");
  if (slots_ & 0x00000800)
    strcat (slot_str, "RANGE ");
  if (slots_ & 0x00001000)
    strcat (slot_str, "HANDS ");
  if (slots_ & 0x00002000)
    strcat (slot_str, "MELEE1 ");
  if (slots_ & 0x00004000)
    strcat (slot_str, "MELEE2 ");
  if (slots_ & 0x00008000)
    strcat (slot_str, "FINGER1 ");
  if (slots_ & 0x00010000)
    strcat (slot_str, "FINGER2 ");
  if (slots_ & 0x00020000)
    strcat (slot_str, "CHEST ");
  if (slots_ & 0x00040000)
    strcat (slot_str, "LEGS ");
  if (slots_ & 0x00080000)
    strcat (slot_str, "FEET ");
  if (slots_ & 0x00100000)
    strcat (slot_str, "WAIST ");

  return slot_str;
}

void processEquipment (struct spawnStruct *spawn, char *buffer)
{
  int i;
  static char *locs[]={"H","C","A","W","G","L","F","1","2"};
  char buf[64];
  char *material;
   buffer[0]=0;
   /* Check if it carries a lightsource */
   //printf("Setting light.\n");
   if (spawn->light)
   {
      sprintf(buffer, "Light:%s ", light_name (spawn->light));
   }

  /* Worn Stuff */
  // printf("Setting worn stuff.\n");
  for (i=0;i<7;i++) {
    if (spawn->equipment[i]) {
      sprintf(buf, "%s:%s ",locs[i],print_material(spawn->equipment[i]));
      strcat(buffer, buf);
    }
  }

  /* Worn Weapons */
  // printf("Setting hand stuff.\n");
  for (i=7;i<9;i++) {
     if (spawn->equipment[i]) {
      sprintf(buf, "%s:%s ",locs[i],print_weapon(spawn->equipment[i]));
      strcat(buffer, buf);
    }
  } 
  // printf("done proccessing equipment.\n");
}

char *spawnAlertName(struct spawnStruct *spawn)
{
  static char spawn_alert_name[256];
  sprintf(spawn_alert_name,"%s/%s/%s/%s",
	  spawn->name, race_name(spawn->race), class_name(spawn->class_),
	  light_name (spawn->light));
  
  processEquipment (spawn, spawn_alert_name+strlen(spawn_alert_name));
  return spawn_alert_name;
}

unsigned long calc_exp (int level, UBYTE race, UBYTE class_)
{
	float exp=level*level*level;
	if (level<30)
		exp*=10;
	else if (level<35)
		exp*=11;
	else if (level<40)
		exp*=12;
	else if (level<45)
		exp*=13;
	else if (level<51) //New exp values for 51+
		exp*=14;
	else if (level<52)
		exp*=15;
	else if (level<53)
		exp*=16;
	else if (level<54)
		exp*=17;
	else if (level<55)
		exp*=18;
	else if (level<56)
		exp*=19;
	else if (level<57)
		exp*=20;
	else if (level<58)
		exp*=21;
	else if (level<59)
		exp*=22;
	else if (level<60)
		exp*=23;
	else
		exp*=24;

	// Do the race mod

	switch (race)
	{
	case 1 : exp*=10; break; // human
	case 2 : exp*=10.5; break; // barbarian
	case 3 : exp*=10; break; // erudite
	case 4 : exp*=10; break; // wood elf
	case 5 : exp*=10; break; // high elf
	case 6 : exp*=10; break; // dark elf
	case 7 : exp*=10; break; // half elf
	case 8 : exp*=10; break; // dwarf
	case 9 : exp*=12; break; // troll
	case 10 : exp*=11.5; break; // ogre
	case 11 : exp*=9.5; break; // halfling
	case 12 : exp*=10; break; // gnome
	case 128 : exp*=12; break; // iksar
	default : exp*=10;
	}

	// Do the class mod

	switch (class_)
	{
	case 1 : exp*=9; break; // warrior
	case 2 : exp*=10; break; // cleric
	case 3 : exp*=14; break; // paladin
	case 4 : exp*=14; break; // ranger
	case 5 : exp*=14; break; // shadowknight
	case 6 : exp*=10; break; // druid
	case 7 : exp*=12; break; // monk
	case 8 : exp*=14; break; // bard
	case 9 : exp*=9.05; break; // rogue
	case 10 : exp*=10; break; // shaman
	case 11 : exp*=11; break; // necromancer
	case 12 : exp*=11; break; // wizard
	case 13 : exp*=11; break; // magician
	case 14 : exp*=11; break; // enchanter
	default : exp*=10;
	}
	

	return (unsigned long)(exp);
}

/*
 * return 1 if race1 race2 are on same pvp team
 */
int isSameTeam(int race1, int race2)
{
  switch(race1)
  {
    case 1: // Human
    case 2: // Barb
    case 3:  // Eurodite
      switch(race2)
      {
        case 1:  // Human
        case 2:  // Barb
        case 3:  // Eurodite
          return 1;
          break;
      }
      break;

    case 4: // Wood Elf
    case 5: // High Elf
    case 7: // Half Elf
      switch(race2)
      {
        case 4:  // Wood Elf 
        case 5:  // High Elf 
        case 7:  // Half Elf 
          return 1;
          break;
      }
      break;

    case 6:  // Dark Elf
    case 9:  // Troll
    case 10: // Ogre
      switch(race2)
      {
        case 6:  // Dark Elf 
        case 9:  // Troll 
        case 10:  // Ogre 
          return 1;
          break;
      }
      break;

    case 8:  // Dwarf
    case 11:  // Halfling 
    case 12:  // Gnome 
      switch(race2)
      {
        case 8:  // Dwarf
        case 11:  // Halfling 
        case 12:  // Gnome 
          return 1;
          break;
      }
      break;
  }

  return 0;

} // end isSameTeam()
  

//
// mTime
//
// return time in miliseconds
//
int mTime(void)
{
  static long basetime = 0;
  struct timeval TimeNow;
  struct timezone Zone;
  int rt;

  gettimeofday(&TimeNow, &Zone);

  if (basetime == 0)
    basetime = TimeNow.tv_sec;

  rt = (TimeNow.tv_sec - basetime) * 1000 + TimeNow.tv_usec / 1000L;

  return rt;
} // end mTime


//
// filterString
//
// return a standard format string that can be used for filters that shows all
// info regarding a spawn
const char*
filterString(spawnStruct *s)
{
  static char text[1048];

  sprintf(text,
          "Name:%s:Level:%d:HP:%d:MaxHP:%d:Race:%s:Class:%s:NPC:%d",
          TransformName(s->name), s->level, s->curHp,
          s->maxHp,
          race_name(s->race), class_name(s->class_),
          s->NPC);

  return text;
}

//
// filterString
//
// return a standard format string that can be used for filters that shows all
// info regarding a spawn
const char*
filterString(dropCoinsStruct *s)
{
  static char text[1048];

  sprintf(text,
          "Name:Coins %c %d:Race:Coins:Class:Thing:NPC:5",
          s->type[0], s->amount, 0, 1, 1);
  return text;
}


const char*
filterString(dropThingOnGround *s)
{
  static char text[1048];
  char buff[128], buff2[128];
  int itemId;

  strcpy(buff2, getitemNameFromDB(s->itemNr));
  if (strlen(buff2) == 0) 
  {
    strcpy(buff, s->idFile);
    if (s->idFile[0] == 'I' && s->idFile[1] == 'T')
    {
      strcpy(buff, s->idFile + 2);
    }
    
    itemId = atoi(buff);

    if (itemId > 0) 
      sprintf(buff, "Drop: %s", print_weapon(itemId));
    else 
      sprintf(buff, "Drop: %s", s->idFile);
  }
  else 
  {
    sprintf(buff, "Drop: '%s'",buff2);
  }

  sprintf(text,
          "Name:%s:Race:Drop:Class:Thing:NPC:6",
          buff);

  return text;
}

QColor calcPickConColor (int greenRange, int levelDif)
{

  // Do the greens
  if (greenRange >= levelDif)
  {
     if ((greenRange-10) >= levelDif)
     {
       return QColor(0,95,0);
     }
     else
     {
       int scale=greenRange-levelDif;
       int greenval=255-scale*(160/(10));
       return QColor(0,greenval,0);
     }
  }
  else
  // Ok, now we know its blue
  {
     if ((greenRange/2)<levelDif)
     {
       // white scale
       int scalemax=(greenRange/2)*-1;
       int scale=(levelDif+1)*-1;
       int colorval=127-scale*(127/scalemax);
       return QColor(colorval,colorval,255);
       // 127, 127, 255 --- 0, 0, 255
     }
     else if ((greenRange/2)>levelDif)
     {
       // green scale
       int scalemax=(greenRange/2)*-1;
       int scale=levelDif-(greenRange+1);
       int greenval=127-scale*(127/scalemax);
       int blueval=127+scale*(127/scalemax);
       return QColor(0,greenval,blueval);
       // 0, 127, 127 --- 0, 0, 255
     }
     else 
       return QColor(0,0,255);
  }
}

QColor
pickConColor(int playerLevel, int mobLevel)
{
// This is the info we have to work with
// Level Range, Green, Red
// 1-6,    -4, +3
// 7-12,   -4, +3
// 13-14,  -6, +3
// 15-22,  -6, +3
// 23-24,  -7, +3
// 25-34,  -8, +3
// 35-40, -10, +3
// 41-44, -12, +3
// 45-48, -13, +3
// 49-50, -14, +3

  // All levels have red as +3, yellow as +1 and +2
  // So lets get the those and even con out of the way first
  if  (playerLevel == mobLevel)
    return QColor(255,255,255);
  if  (playerLevel == (mobLevel-1))
    return QColor(255,255,0);
  if  (playerLevel == (mobLevel-2))
    return QColor(255,127,0);
  // Do the red shading
  if  (playerLevel <= (mobLevel-3))
  {
     if (playerLevel <= (mobLevel-13))
     {
       return QColor(95,0,0);
     }
     else
     {
       int scale=(mobLevel-playerLevel)-3;
       int redval=255-scale*(16);
       return QColor(redval,0,0);
     }
  }
  
  //if  (playerLevel <= (mobLevel-3))
  //  return QColor(255,0,0);

  if (playerLevel<7) // 1 - 6
    return calcPickConColor (-4, mobLevel-playerLevel);
  else if (playerLevel<13) // 7 - 12
    return calcPickConColor (-4, mobLevel-playerLevel);
  else if (playerLevel<15) // 13 - 14
    return calcPickConColor (-6, mobLevel-playerLevel);
  else if (playerLevel<23) // 15 - 22
    return calcPickConColor (-6, mobLevel-playerLevel);
  else if (playerLevel<25) // 23 - 24
    return calcPickConColor (-7, mobLevel-playerLevel);
  else if (playerLevel<35) // 25 - 34
    return calcPickConColor (-8, mobLevel-playerLevel);
  else if (playerLevel<41) // 35 - 40
    return calcPickConColor (-10, mobLevel-playerLevel);
  else if (playerLevel<45) // 41 - 44
    return calcPickConColor (-12, mobLevel-playerLevel);
  else if (playerLevel<49) // 45 - 48
    return calcPickConColor (-13, mobLevel-playerLevel);
  else // 49+
    return calcPickConColor (-14, mobLevel-playerLevel);
}

//
// pickConColor
//
// pick a suitable color for the spawn based on consider colors
// (data compliments of 'http://everquest.allakhazam.com')
//
QColor
pickConColorPrev(int playerLevel, int mobLevel)
{
  int diff =  mobLevel - playerLevel;

  if ( (playerLevel >= 1) && (playerLevel <= 6) )
  {
     // looks like a reasonably safe opponent
     if (diff <= -4)
       return Qt::darkGreen;
     // looks like you would have the upper hand
     if ( (diff >= -3) && (diff <= -1) ) 
       return Qt::darkBlue;
     // looks like an even fight
     if (diff == 0)
       return Qt::white;
     // looks like quite a gamble
     if ( (diff >= 1) && (diff <= 2) )
       return Qt::yellow;
     // what would you like your tombstone to say?
     if (diff >= 3)
       return Qt::red;
  }
  else if ( (playerLevel >= 7) && (playerLevel <= 12) )
  {
     // looks like a reasonably safe opponent
     if (diff <= -4)
       return Qt::darkGreen;
     // looks kind of risky, but you might win
     if ( (diff >= -3) && (diff <= -1) ) 
       return Qt::darkBlue;
     // looks kind of risky... you might win
     if (diff == 0)
       return Qt::white;
     // looks like quite a gamble
     if ( (diff >= 1) && (diff <= 2) )
       return Qt::yellow;
     // what would you like your tombstone to say?
     if (diff >= 3)
       return Qt::red;
  }
  else if ( (playerLevel >= 13) && (playerLevel <= 14) )
  {
     // looks like a reasonably safe opponent
     if (diff <= -6)
       return Qt::darkGreen;
     // looks like you would have the upper hand
     if ( (diff >= -5) && (diff <= -4) ) 
       return Qt::blue;
     // looks kind of risky, but you might win
     if ( (diff >= -3) && (diff <= -1) ) 
       return Qt::darkBlue;
     // looks kind of risky... you might win
     if (diff == 0)
       return Qt::white;
     // looks like quite a gamble
     if ( (diff >= 1) && (diff <= 2) )
       return Qt::yellow;
     // what would you like your tombstone to say?
     if (diff >= 3)
       return Qt::red;
  }
  else if ( (playerLevel >= 15) && (playerLevel <= 24) )
  {
     // looks like a reasonably safe opponent
     if (diff <= -6)
       return Qt::darkGreen;
     // You would probably win this fight... its' not certain though
     if ( (diff >= -5) && (diff <= -5) ) 
       return Qt::blue;
     // looks quite risky, but might be worth a try
     if ( (diff >= -4) && (diff <= -4) ) 
       return Qt::blue;
     // looks kind of risky
     if ( (diff >= -3) && (diff <= -3) ) 
       return Qt::darkBlue;
     // looks kind of dangerous 
     if ( (diff >= -2) && (diff <= -1) ) 
       return Qt::darkBlue;
     // appears to be quite formidable
     if (diff == 0)
       return Qt::white;
     // looks like quite a gamble
     if ( (diff >= 1) && (diff <= 2) )
       return Qt::yellow;
     // what would you like your tombstone to say?
     if (diff >= 3)
       return Qt::red;
  }
  else if ( (playerLevel >= 25) && (playerLevel <= 34) )
  {
     // you could probably win this fight
     if (diff <= -11)
       return Qt::green;
     // this creature could pose problems, you would probably defeat it
     if ( (diff >= -10) && (diff <= -8) ) 
       return Qt::darkGreen;
     // appears to be quite formidable
     if ( (diff >= -7) && (diff <= -1) ) 
       return Qt::blue;
     // looks like quite a gamble
     if (diff == 0)
       return Qt::white;
     // looks like it would wipe the floor with you!
     if ( (diff >= 1) && (diff <= 2) )
       return Qt::yellow;
     // what would you like your tombstone to say?
     if (diff >= 3)
       return Qt::red;
  }
  else if ( (playerLevel >= 35) && (playerLevel <= 40) )
  {
     // you could probably win this fight
     if (diff <= -11)
       return Qt::green;
     // this creature could pose problems, you would probably defeat it
     if ( (diff >= -10) && (diff <= -10) ) 
       return Qt::darkGreen;
     // appears to be quite formidable
     if ( (diff >= -9) && (diff <= -1) ) 
       return Qt::blue;
     // looks like quite a gamble
     if (diff == 0)
       return Qt::white;
     // looks like it would wipe the floor with you!
     if ( (diff >= 1) && (diff <= 2) )
       return Qt::yellow;
     // what would you like your tombstone to say?
     if (diff >= 3)
       return Qt::red;
  }
  else if ( (playerLevel >= 41) && (playerLevel <= 44) )
  {
     // you could probably win this fight
     if (diff <= -12)
       return Qt::green;
     // appears to be quite formidable
     if ( (diff >= -11) && (diff <= -1) ) 
       return Qt::blue;
     // looks like quite a gamble
     if (diff == 0)
       return Qt::white;
     // looks like it would wipe the floor with you!
     if ( (diff >= 1) && (diff <= 2) )
       return Qt::yellow;
     // what would you like your tombstone to say?
     if (diff >= 3)
       return Qt::red;
  }
  else if ( (playerLevel >= 45) && (playerLevel <= 49) )
  {
     // you could probably win this fight
     if (diff <= -13)
       return Qt::green;
     // appears to be quite formidable
     if ( (diff >= -12) && (diff <= -1) ) 
       return Qt::blue;
     // looks like quite a gamble
     if (diff == 0)
       return Qt::white;
     // looks like it would wipe the floor with you!
     if ( (diff >= 1) && (diff <= 2) )
       return Qt::yellow;
     // what would you like your tombstone to say?
     if (diff >= 3)
       return Qt::red;
  }
  else if (playerLevel >= 50)
  {
     // you could probably win this fight
     if (diff <= -14)
       return Qt::green;
     // appears to be quite formidable
     if ( (diff >= -13) && (diff <= -1) ) 
       return Qt::blue;
     // looks like quite a gamble
     if (diff == 0)
       return Qt::white;
     // looks like it would wipe the floor with you!
     if ( (diff >= 1) && (diff <= 2) )
       return Qt::yellow;
     // what would you like your tombstone to say?
     if (diff >= 3)
       return Qt::red;
  }

  return Qt::black;

} // end pickConColor


const char *
TransformName(const char *name)
{
  static char newname[64];
  char temp[64];
  char *  strp;

  strcpy(newname, name);

  for (strp = newname; *strp; strp++)
    if (*strp == '_')
      *strp = ' ';
  if (!strncmp(newname, "a ", 2))
  {
    strcpy(temp, newname + 2);
    strcat(temp, ", a");
    strcpy(newname, temp);
  }
  else if (!strncmp(newname, "an ", 3))
  {
    strcpy(temp, newname + 3);
    strcat(temp, ", an");
    strcpy(newname, temp);
  }
  else if (!strncmp(newname, "the ", 4))
  {
    strcpy(temp, newname + 4);
    strcat(temp, ", the");
    strcpy(newname, temp);
  }

  return newname;

} // end TransformName
