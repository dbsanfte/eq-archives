#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "util.h"

int main (int argc, char *argv[])
{
   FILE *sdb;
   struct dbSpawnStruct dbSpawn;
   extern int errno;
   int counter=0;
   char dbname[256];

   printf ("Content-type: text/html\n\n");
   sdb = fopen (SPAWNFILE, "r");
   if (sdb == NULL) {
	   printf("Unable to open file '" SPAWNFILE "' (errno = %d)\n", errno);
	   exit(1);
   }
   printf("<HTML>\n");
   printf("<HEAD><TITLE>Spawn List</TITLE></HEAD>\n");
   printf("</BODY>\n");
   printf("<TABLE border=2 bordercolor=black cellspacing=0 cellpadding=2>\n");
   printf("<TR>\n");
   printf("<TD align=center><STRONG>Short Name</STRONG></TD>\n");
   printf("<TD align=center><STRONG>Long Name</STRONG></TD>\n");
   printf("<TD align=center><STRONG>Zone Name</STRONG></TD>\n");
   printf("<TD align=center><STRONG>Level</STRONG></TD>\n");
   printf("<TD align=center><STRONG>HP</STRONG></TD>\n");
   printf("<TD align=center><STRONG>Race</STRONG></TD>\n");
   printf("<TD align=center><STRONG>Class<STRONG></TD>\n");
   printf("</TR>\n");
   while (fread (&dbSpawn, sizeof(dbSpawnStruct), 1, sdb))
   {
      if (argc>1)
	if (!strstr(dbSpawn.spawn.name,argv[1]))
	  continue;
      strcpy (dbname, dbSpawn.spawn.name);
      for (int a=0; a<strlen(dbSpawn.spawn.name); a++)
	if (dbname[a]<='9')
	  dbname[a]=0;

      printf("<TR>\n");
      printf ("<TD><A HREF=\"showspawn.cgi?%s\">%s</A></TD>\n", dbname,dbname);
      printf ("<TD>%s</TD>\n", dbSpawn.spawn.name);
      printf ("<TD>%s</TD>\n", dbSpawn.zoneName);
      printf ("<TD align=right>%d</TD>\n", dbSpawn.spawn.level);
      printf ("<TD align=right>%d/%d</TD>\n", dbSpawn.spawn.curHp,dbSpawn.spawn.maxHp);
      printf ("<TD>%s</TD>\n", race_name(dbSpawn.spawn.race));
      printf ("<TD>%s</TD>\n", class_name(dbSpawn.spawn.class_));
      printf ("</TR>\n");
      counter++;
   }
   printf("</TABLE>\n");
   fclose (sdb);
   printf ("%d matches found\n", counter);
   printf("</BODY>\n");
   printf("</HTML>\n");
}
