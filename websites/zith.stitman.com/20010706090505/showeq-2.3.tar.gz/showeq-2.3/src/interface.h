/*
 * interface.h
 *
 * ShowEQ Distributed under GPL
 * http://www.hackersquest.gomp.ch/
 */

#ifndef EQINT_H
# define EQINT_H

# include <qwidget.h>
# include <qpushbutton.h>
# include <qlcdnumber.h>
# include <qframe.h>
# include <qlabel.h>
# include <qlistview.h>
# include <qlayout.h>
# include <qmenubar.h>
# include <qpopupmenu.h>
# include <qmainwindow.h>
# include <qhbox.h>
# include <qvbox.h>
# include <qsplitter.h>
# include <qvaluelist.h>
# include <qtimer.h>
# include <qlist.h>

# include "packet.h"
# include "compass.h"
# include "map.h"
# include "experiencelog.h"
# include "msgdlg.h"
# include "spawnlist.h"

class EQInterface:public QMainWindow
{
   Q_OBJECT

 public:
   EQInterface (QWidget * parent = 0, const char *name = 0);

 public slots:
   void addSkill (int skillId, int value);
   void changeSkill (int skillId, int value);
   void deleteSkills();

   void expChanged  (int val, int min, int max);
   void hpChanged   (int val, int max);
   void manaChanged (int val, int max);
   void stamChanged (int Sval, int Smax, int Fval, int Fmax, int Wval, int Wmax);
   void msgReceived(const QString &);
   void stsMessage(const QString &, int timeout = 0);
   void numSpawns_(int);
   void numPacket(int);
   void savePrefs(void);
   void addCategory(void);
   void reloadCategories(void);
   void spawnListRightButton(QListViewItem *item, const QPoint &point, int col); 

 signals:
   void ShowFilteredSpawns(int);
   void ShowHidden(int);
   void newMessage(int index);

 private slots:
   void toggle_log_AllPackets();
   void toggle_log_ZoneData();
   void toggle_log_UnknownData();
   void toggle_opt_Velocity();
   void toggle_opt_Animate();
   void toggle_opt_Fast();
   void toggle_vew_UnknownData();
   void toggle_vew_FilteredSpawns();
   void toggle_vew_HiddenSpawns();
   void toggle_vew_ChannelMsgs();
   void toggle_vew_ExpWindow();
   void toggle_opt_ConSelect();
   void toggle_opt_KeepSelectedVisible();
   void toggle_opt_SparrMessages();
   void toggle_opt_LogSpawns();
   void toggle_vew_SpawnList();
   void toggle_vew_PlayerStats();
   void toggle_vew_Compass();
   void toggle_vew_PlayerSkills();
   void toggle_vew_Map();
   void createMessageBox();

 protected:
   void resizeEvent (QResizeEvent *);

 private:
   QTimer*    mapTimer;
//   QListView* m_pSpawnList;
   CSpawnList* m_pSpawnList;
   QListView* m_pSkillList;
   QListView* m_pStatList;
   EQPacket*  m_pPacket;
   QVBox*     m_pCompass;
//   Compass*     m_pCompass;
   Map*       m_pMap;
   QSplitter* m_pSplitV;
   QSplitter* m_pSplitH;
   QSplitter* m_pSplitT;
   ExperienceWindow* m_expWindow;
   QLabel* m_stsbarSpawns;
   QLabel* m_stsbarStatus;
   QLabel* m_stsbarZone;
   QLabel* m_stsbarID;
   QLabel* m_stsbarExp;
   QLabel* m_stsbarPkt;
   QListViewItem* skillList[255];
   QListViewItem* statList[6]; // HP, Mana, Stam, Exp, Food, Water
   QList<MsgDialog>  m_msgDialogList;

   bool logAllPackets;
   bool logZoneData;
   bool logUnknownData;

   bool viewUnknownData;
   bool viewChannelMsgs;
   bool viewFilteredSpawns;
   bool viewHiddenSpawns;
   bool viewExpWindow;

   int  mid_log_AllPackets;
   int  mid_log_ZoneData;
   int  mid_log_UnknownData;
   int  mid_opt_Velocity;
   int  mid_opt_Animate;
   int  mid_opt_Fast;
   int  mid_vew_UnknownData;
   int  mid_vew_ChannelMsgs;
   int  mid_vew_FilteredSpawns;
   int  mid_vew_HiddenSpawns;
   int  mid_vew_ExpWindow;
   int  mid_vew_SpawnList;
   int  mid_vew_PlayerStats;
   int  mid_vew_PlayerSkills;
   int  mid_vew_Compass;
   int  mid_vew_Map;
   int  mid_opt_ConSelect;
   int  mid_opt_KeepSelectedVisible;
   int  mid_opt_SparrMessages;
   int  mid_opt_LogSpawns;
   int  m_lPacketStartTime;
   QStringList m_StringList;
};

class CFilterDlg : public QDialog
{
   Q_OBJECT
 public:
   CFilterDlg(QWidget *parent, QString name);

   QLineEdit *m_Name;
   QLineEdit *m_Filter;
   QLineEdit *m_FilterOut;
   QComboBox *m_Color;
};

#endif // EQINT_H
