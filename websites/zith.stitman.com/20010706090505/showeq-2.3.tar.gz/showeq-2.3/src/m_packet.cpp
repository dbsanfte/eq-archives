/****************************************************************************
** EQPacket meta object code from reading C++ file 'packet.h'
**
** Created: Tue Jun 6 01:15:18 2000
**      by: The Qt Meta Object Compiler ($Revision: 2.53 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#define Q_MOC_EQPacket
#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 3
#elif Q_MOC_OUTPUT_REVISION != 3
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "packet.h"
#include <qmetaobject.h>
#include <qapplication.h>

#if defined(Q_SPARCWORKS_FUNCP_BUG)
#define Q_AMPERSAND
#else
#define Q_AMPERSAND &
#endif


const char *EQPacket::className() const
{
    return "EQPacket";
}

QMetaObject *EQPacket::metaObj = 0;


#if QT_VERSION >= 199
static QMetaObjectInit init_EQPacket(&EQPacket::staticMetaObject);

#endif

void EQPacket::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QObject::className(), "QObject") != 0 )
	badSuperclassWarning("EQPacket","QObject");

#if QT_VERSION >= 199
    staticMetaObject();
}

QString EQPacket::tr(const char* s)
{
    return ((QNonBaseApplication*)qApp)->translate("EQPacket",s);
}

void EQPacket::staticMetaObject()
{
    if ( metaObj )
	return;
    QObject::staticMetaObject();
#else

    QObject::initMetaObject();
#endif

    typedef void(EQPacket::*m1_t0)();
    typedef void(EQPacket::*m1_t1)();
    typedef void(EQPacket::*m1_t2)(char*);
    typedef void(EQPacket::*m1_t3)();
    typedef void(EQPacket::*m1_t4)();
    typedef void(EQPacket::*m1_t5)();
    m1_t0 v1_0 = Q_AMPERSAND EQPacket::processPackets;
    m1_t1 v1_1 = Q_AMPERSAND EQPacket::initSpawnLists2;
    m1_t2 v1_2 = Q_AMPERSAND EQPacket::deSpawnAlert;
    m1_t3 v1_3 = Q_AMPERSAND EQPacket::incPlayback;
    m1_t4 v1_4 = Q_AMPERSAND EQPacket::decPlayback;
    m1_t5 v1_5 = Q_AMPERSAND EQPacket::Resync;
    QMetaData *slot_tbl = QMetaObject::new_metadata(6);
    slot_tbl[0].name = "processPackets()";
    slot_tbl[1].name = "initSpawnLists2()";
    slot_tbl[2].name = "deSpawnAlert(char*)";
    slot_tbl[3].name = "incPlayback()";
    slot_tbl[4].name = "decPlayback()";
    slot_tbl[5].name = "Resync()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    slot_tbl[4].ptr = *((QMember*)&v1_4);
    slot_tbl[5].ptr = *((QMember*)&v1_5);
    typedef void(EQPacket::*m2_t0)(char*,int);
    typedef void(EQPacket::*m2_t1)(char*,int);
    typedef void(EQPacket::*m2_t2)();
    typedef void(EQPacket::*m2_t3)(int);
    typedef void(EQPacket::*m2_t4)(int,int);
    typedef void(EQPacket::*m2_t5)(int,int);
    typedef void(EQPacket::*m2_t6)(int);
    typedef void(EQPacket::*m2_t7)(int);
    typedef void(EQPacket::*m2_t8)(int);
    typedef void(EQPacket::*m2_t9)(int);
    typedef void(EQPacket::*m2_t10)(const QString&);
    typedef void(EQPacket::*m2_t11)(const QString&);
    typedef void(EQPacket::*m2_t12)(const QString&);
    typedef void(EQPacket::*m2_t13)(int,int,int);
    typedef void(EQPacket::*m2_t14)(int,int,int,int,int,int,int);
    typedef void(EQPacket::*m2_t15)(int);
    typedef void(EQPacket::*m2_t16)(int);
    typedef void(EQPacket::*m2_t17)(int);
    typedef void(EQPacket::*m2_t18)(const QString&);
    typedef void(EQPacket::*m2_t19)(int);
    typedef void(EQPacket::*m2_t20)(attack1Struct*);
    typedef void(EQPacket::*m2_t21)(attack2Struct*);
    typedef void(EQPacket::*m2_t22)(considerStruct*);
    typedef void(EQPacket::*m2_t23)(wearChangeStruct*);
    typedef void(EQPacket::*m2_t24)(dropThingOnGround*);
    typedef void(EQPacket::*m2_t25)(removeThingOnGround*);
    typedef void(EQPacket::*m2_t26)(dropCoinsStruct*);
    typedef void(EQPacket::*m2_t27)(removeCoinsStruct*);
    typedef void(EQPacket::*m2_t28)(spawnStruct*,int);
    typedef void(EQPacket::*m2_t29)(int,int,int,int,int,int,int);
    typedef void(EQPacket::*m2_t30)(int,int,int);
    typedef void(EQPacket::*m2_t31)(int);
    typedef void(EQPacket::*m2_t32)();
    typedef void(EQPacket::*m2_t33)(int);
    typedef void(EQPacket::*m2_t34)(int);
    typedef void(EQPacket::*m2_t35)(int);
    typedef void(EQPacket::*m2_t36)(char*,char*);
    typedef void(EQPacket::*m2_t37)();
    typedef void(EQPacket::*m2_t38)(const QString&);
    typedef void(EQPacket::*m2_t39)(int,int,int);
    typedef void(EQPacket::*m2_t40)(const QString&,int,long,QString);
    typedef void(EQPacket::*m2_t41)(int,int);
    typedef void(EQPacket::*m2_t42)(int,int,int,int,int,int);
    typedef void(EQPacket::*m2_t43)(const QString&,int);
    m2_t0 v2_0 = Q_AMPERSAND EQPacket::addGroup;
    m2_t1 v2_1 = Q_AMPERSAND EQPacket::remGroup;
    m2_t2 v2_2 = Q_AMPERSAND EQPacket::clrGroup;
    m2_t3 v2_3 = Q_AMPERSAND EQPacket::hideSpawn;
    m2_t4 v2_4 = Q_AMPERSAND EQPacket::addSkill;
    m2_t5 v2_5 = Q_AMPERSAND EQPacket::changeSkill;
    m2_t6 v2_6 = Q_AMPERSAND EQPacket::packetReceived;
    m2_t7 v2_7 = Q_AMPERSAND EQPacket::seqReceive;
    m2_t8 v2_8 = Q_AMPERSAND EQPacket::seqExpect;
    m2_t9 v2_9 = Q_AMPERSAND EQPacket::headingChanged;
    m2_t10 v2_10 = Q_AMPERSAND EQPacket::xposChanged;
    m2_t11 v2_11 = Q_AMPERSAND EQPacket::yposChanged;
    m2_t12 v2_12 = Q_AMPERSAND EQPacket::zposChanged;
    m2_t13 v2_13 = Q_AMPERSAND EQPacket::posChanged;
    m2_t14 v2_14 = Q_AMPERSAND EQPacket::playerChanged;
    m2_t15 v2_15 = Q_AMPERSAND EQPacket::setPlayerLevel;
    m2_t16 v2_16 = Q_AMPERSAND EQPacket::setPlayerRace;
    m2_t17 v2_17 = Q_AMPERSAND EQPacket::setPlayerClass;
    m2_t18 v2_18 = Q_AMPERSAND EQPacket::msgReceived;
    m2_t19 v2_19 = Q_AMPERSAND EQPacket::numPacket;
    m2_t20 v2_20 = Q_AMPERSAND EQPacket::attack1Hand1;
    m2_t21 v2_21 = Q_AMPERSAND EQPacket::attack2Hand1;
    m2_t22 v2_22 = Q_AMPERSAND EQPacket::consMessage;
    m2_t23 v2_23 = Q_AMPERSAND EQPacket::spawnWearingUpdate;
    m2_t24 v2_24 = Q_AMPERSAND EQPacket::newGroundItem;
    m2_t25 v2_25 = Q_AMPERSAND EQPacket::removeGroundItem;
    m2_t26 v2_26 = Q_AMPERSAND EQPacket::newCoinsItem;
    m2_t27 v2_27 = Q_AMPERSAND EQPacket::removeCoinsItem;
    m2_t28 v2_28 = Q_AMPERSAND EQPacket::newSpawn;
    m2_t29 v2_29 = Q_AMPERSAND EQPacket::updateSpawn;
    m2_t30 v2_30 = Q_AMPERSAND EQPacket::updateSpawnHp;
    m2_t31 v2_31 = Q_AMPERSAND EQPacket::setPlayerID;
    m2_t32 v2_32 = Q_AMPERSAND EQPacket::refreshMap;
    m2_t33 v2_33 = Q_AMPERSAND EQPacket::deleteSpawn;
    m2_t34 v2_34 = Q_AMPERSAND EQPacket::killSpawn;
    m2_t35 v2_35 = Q_AMPERSAND EQPacket::infoSpawn;
    m2_t36 v2_36 = Q_AMPERSAND EQPacket::newZone;
    m2_t37 v2_37 = Q_AMPERSAND EQPacket::zoneChanged;
    m2_t38 v2_38 = Q_AMPERSAND EQPacket::expChangedStr;
    m2_t39 v2_39 = Q_AMPERSAND EQPacket::expChangedInt;
    m2_t40 v2_40 = Q_AMPERSAND EQPacket::expGained;
    m2_t41 v2_41 = Q_AMPERSAND EQPacket::manaChanged;
    m2_t42 v2_42 = Q_AMPERSAND EQPacket::stamChanged;
    m2_t43 v2_43 = Q_AMPERSAND EQPacket::stsMessage;
    QMetaData *signal_tbl = QMetaObject::new_metadata(44);
    signal_tbl[0].name = "addGroup(char*,int)";
    signal_tbl[1].name = "remGroup(char*,int)";
    signal_tbl[2].name = "clrGroup()";
    signal_tbl[3].name = "hideSpawn(int)";
    signal_tbl[4].name = "addSkill(int,int)";
    signal_tbl[5].name = "changeSkill(int,int)";
    signal_tbl[6].name = "packetReceived(int)";
    signal_tbl[7].name = "seqReceive(int)";
    signal_tbl[8].name = "seqExpect(int)";
    signal_tbl[9].name = "headingChanged(int)";
    signal_tbl[10].name = "xposChanged(const QString&)";
    signal_tbl[11].name = "yposChanged(const QString&)";
    signal_tbl[12].name = "zposChanged(const QString&)";
    signal_tbl[13].name = "posChanged(int,int,int)";
    signal_tbl[14].name = "playerChanged(int,int,int,int,int,int,int)";
    signal_tbl[15].name = "setPlayerLevel(int)";
    signal_tbl[16].name = "setPlayerRace(int)";
    signal_tbl[17].name = "setPlayerClass(int)";
    signal_tbl[18].name = "msgReceived(const QString&)";
    signal_tbl[19].name = "numPacket(int)";
    signal_tbl[20].name = "attack1Hand1(attack1Struct*)";
    signal_tbl[21].name = "attack2Hand1(attack2Struct*)";
    signal_tbl[22].name = "consMessage(considerStruct*)";
    signal_tbl[23].name = "spawnWearingUpdate(wearChangeStruct*)";
    signal_tbl[24].name = "newGroundItem(dropThingOnGround*)";
    signal_tbl[25].name = "removeGroundItem(removeThingOnGround*)";
    signal_tbl[26].name = "newCoinsItem(dropCoinsStruct*)";
    signal_tbl[27].name = "removeCoinsItem(removeCoinsStruct*)";
    signal_tbl[28].name = "newSpawn(spawnStruct*,int)";
    signal_tbl[29].name = "updateSpawn(int,int,int,int,int,int,int)";
    signal_tbl[30].name = "updateSpawnHp(int,int,int)";
    signal_tbl[31].name = "setPlayerID(int)";
    signal_tbl[32].name = "refreshMap()";
    signal_tbl[33].name = "deleteSpawn(int)";
    signal_tbl[34].name = "killSpawn(int)";
    signal_tbl[35].name = "infoSpawn(int)";
    signal_tbl[36].name = "newZone(char*,char*)";
    signal_tbl[37].name = "zoneChanged()";
    signal_tbl[38].name = "expChangedStr(const QString&)";
    signal_tbl[39].name = "expChangedInt(int,int,int)";
    signal_tbl[40].name = "expGained(const QString&,int,long,QString)";
    signal_tbl[41].name = "manaChanged(int,int)";
    signal_tbl[42].name = "stamChanged(int,int,int,int,int,int)";
    signal_tbl[43].name = "stsMessage(const QString&,int)";
    signal_tbl[0].ptr = *((QMember*)&v2_0);
    signal_tbl[1].ptr = *((QMember*)&v2_1);
    signal_tbl[2].ptr = *((QMember*)&v2_2);
    signal_tbl[3].ptr = *((QMember*)&v2_3);
    signal_tbl[4].ptr = *((QMember*)&v2_4);
    signal_tbl[5].ptr = *((QMember*)&v2_5);
    signal_tbl[6].ptr = *((QMember*)&v2_6);
    signal_tbl[7].ptr = *((QMember*)&v2_7);
    signal_tbl[8].ptr = *((QMember*)&v2_8);
    signal_tbl[9].ptr = *((QMember*)&v2_9);
    signal_tbl[10].ptr = *((QMember*)&v2_10);
    signal_tbl[11].ptr = *((QMember*)&v2_11);
    signal_tbl[12].ptr = *((QMember*)&v2_12);
    signal_tbl[13].ptr = *((QMember*)&v2_13);
    signal_tbl[14].ptr = *((QMember*)&v2_14);
    signal_tbl[15].ptr = *((QMember*)&v2_15);
    signal_tbl[16].ptr = *((QMember*)&v2_16);
    signal_tbl[17].ptr = *((QMember*)&v2_17);
    signal_tbl[18].ptr = *((QMember*)&v2_18);
    signal_tbl[19].ptr = *((QMember*)&v2_19);
    signal_tbl[20].ptr = *((QMember*)&v2_20);
    signal_tbl[21].ptr = *((QMember*)&v2_21);
    signal_tbl[22].ptr = *((QMember*)&v2_22);
    signal_tbl[23].ptr = *((QMember*)&v2_23);
    signal_tbl[24].ptr = *((QMember*)&v2_24);
    signal_tbl[25].ptr = *((QMember*)&v2_25);
    signal_tbl[26].ptr = *((QMember*)&v2_26);
    signal_tbl[27].ptr = *((QMember*)&v2_27);
    signal_tbl[28].ptr = *((QMember*)&v2_28);
    signal_tbl[29].ptr = *((QMember*)&v2_29);
    signal_tbl[30].ptr = *((QMember*)&v2_30);
    signal_tbl[31].ptr = *((QMember*)&v2_31);
    signal_tbl[32].ptr = *((QMember*)&v2_32);
    signal_tbl[33].ptr = *((QMember*)&v2_33);
    signal_tbl[34].ptr = *((QMember*)&v2_34);
    signal_tbl[35].ptr = *((QMember*)&v2_35);
    signal_tbl[36].ptr = *((QMember*)&v2_36);
    signal_tbl[37].ptr = *((QMember*)&v2_37);
    signal_tbl[38].ptr = *((QMember*)&v2_38);
    signal_tbl[39].ptr = *((QMember*)&v2_39);
    signal_tbl[40].ptr = *((QMember*)&v2_40);
    signal_tbl[41].ptr = *((QMember*)&v2_41);
    signal_tbl[42].ptr = *((QMember*)&v2_42);
    signal_tbl[43].ptr = *((QMember*)&v2_43);
    metaObj = QMetaObject::new_metaobject(
	"EQPacket", "QObject",
	slot_tbl, 6,
	signal_tbl, 44 );
}

#include <qobjectdefs.h>
#include <qsignalslotimp.h>

// SIGNAL addGroup
void EQPacket::addGroup( char* t0, int t1 )
{
    // No builtin function for signal parameter type char*,int
    QConnectionList *clist = receivers("addGroup(char*,int)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(char*);
    typedef RT1 *PRT1;
    typedef void (QObject::*RT2)(char*,int);
    typedef RT2 *PRT2;
    RT0 r0;
    RT1 r1;
    RT2 r2;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	    case 2:
		r2 = *((PRT2)(c->member()));
		(object->*r2)(t0, t1);
		break;
	}
    }
}

// SIGNAL remGroup
void EQPacket::remGroup( char* t0, int t1 )
{
    // No builtin function for signal parameter type char*,int
    QConnectionList *clist = receivers("remGroup(char*,int)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(char*);
    typedef RT1 *PRT1;
    typedef void (QObject::*RT2)(char*,int);
    typedef RT2 *PRT2;
    RT0 r0;
    RT1 r1;
    RT2 r2;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	    case 2:
		r2 = *((PRT2)(c->member()));
		(object->*r2)(t0, t1);
		break;
	}
    }
}

// SIGNAL clrGroup
void EQPacket::clrGroup()
{
    activate_signal( "clrGroup()" );
}

// SIGNAL hideSpawn
void EQPacket::hideSpawn( int t0 )
{
    activate_signal( "hideSpawn(int)", t0 );
}

// SIGNAL addSkill
void EQPacket::addSkill( int t0, int t1 )
{
    // No builtin function for signal parameter type int,int
    QConnectionList *clist = receivers("addSkill(int,int)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(int);
    typedef RT1 *PRT1;
    typedef void (QObject::*RT2)(int,int);
    typedef RT2 *PRT2;
    RT0 r0;
    RT1 r1;
    RT2 r2;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	    case 2:
		r2 = *((PRT2)(c->member()));
		(object->*r2)(t0, t1);
		break;
	}
    }
}

// SIGNAL changeSkill
void EQPacket::changeSkill( int t0, int t1 )
{
    // No builtin function for signal parameter type int,int
    QConnectionList *clist = receivers("changeSkill(int,int)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(int);
    typedef RT1 *PRT1;
    typedef void (QObject::*RT2)(int,int);
    typedef RT2 *PRT2;
    RT0 r0;
    RT1 r1;
    RT2 r2;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	    case 2:
		r2 = *((PRT2)(c->member()));
		(object->*r2)(t0, t1);
		break;
	}
    }
}

// SIGNAL packetReceived
void EQPacket::packetReceived( int t0 )
{
    activate_signal( "packetReceived(int)", t0 );
}

// SIGNAL seqReceive
void EQPacket::seqReceive( int t0 )
{
    activate_signal( "seqReceive(int)", t0 );
}

// SIGNAL seqExpect
void EQPacket::seqExpect( int t0 )
{
    activate_signal( "seqExpect(int)", t0 );
}

// SIGNAL headingChanged
void EQPacket::headingChanged( int t0 )
{
    activate_signal( "headingChanged(int)", t0 );
}

// SIGNAL xposChanged
void EQPacket::xposChanged( const QString& t0 )
{
    activate_signal_strref( "xposChanged(const QString&)", t0 );
}

// SIGNAL yposChanged
void EQPacket::yposChanged( const QString& t0 )
{
    activate_signal_strref( "yposChanged(const QString&)", t0 );
}

// SIGNAL zposChanged
void EQPacket::zposChanged( const QString& t0 )
{
    activate_signal_strref( "zposChanged(const QString&)", t0 );
}

// SIGNAL posChanged
void EQPacket::posChanged( int t0, int t1, int t2 )
{
    // No builtin function for signal parameter type int,int,int
    QConnectionList *clist = receivers("posChanged(int,int,int)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(int);
    typedef RT1 *PRT1;
    typedef void (QObject::*RT2)(int,int);
    typedef RT2 *PRT2;
    typedef void (QObject::*RT3)(int,int,int);
    typedef RT3 *PRT3;
    RT0 r0;
    RT1 r1;
    RT2 r2;
    RT3 r3;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	    case 2:
		r2 = *((PRT2)(c->member()));
		(object->*r2)(t0, t1);
		break;
	    case 3:
		r3 = *((PRT3)(c->member()));
		(object->*r3)(t0, t1, t2);
		break;
	}
    }
}

// SIGNAL playerChanged
void EQPacket::playerChanged( int t0, int t1, int t2, int t3, int t4, int t5, int t6 )
{
    // No builtin function for signal parameter type int,int,int,int,int,int,int
    QConnectionList *clist = receivers("playerChanged(int,int,int,int,int,int,int)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(int);
    typedef RT1 *PRT1;
    typedef void (QObject::*RT2)(int,int);
    typedef RT2 *PRT2;
    typedef void (QObject::*RT3)(int,int,int);
    typedef RT3 *PRT3;
    typedef void (QObject::*RT4)(int,int,int,int);
    typedef RT4 *PRT4;
    typedef void (QObject::*RT5)(int,int,int,int,int);
    typedef RT5 *PRT5;
    typedef void (QObject::*RT6)(int,int,int,int,int,int);
    typedef RT6 *PRT6;
    typedef void (QObject::*RT7)(int,int,int,int,int,int,int);
    typedef RT7 *PRT7;
    RT0 r0;
    RT1 r1;
    RT2 r2;
    RT3 r3;
    RT4 r4;
    RT5 r5;
    RT6 r6;
    RT7 r7;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	    case 2:
		r2 = *((PRT2)(c->member()));
		(object->*r2)(t0, t1);
		break;
	    case 3:
		r3 = *((PRT3)(c->member()));
		(object->*r3)(t0, t1, t2);
		break;
	    case 4:
		r4 = *((PRT4)(c->member()));
		(object->*r4)(t0, t1, t2, t3);
		break;
	    case 5:
		r5 = *((PRT5)(c->member()));
		(object->*r5)(t0, t1, t2, t3, t4);
		break;
	    case 6:
		r6 = *((PRT6)(c->member()));
		(object->*r6)(t0, t1, t2, t3, t4, t5);
		break;
	    case 7:
		r7 = *((PRT7)(c->member()));
		(object->*r7)(t0, t1, t2, t3, t4, t5, t6);
		break;
	}
    }
}

// SIGNAL setPlayerLevel
void EQPacket::setPlayerLevel( int t0 )
{
    activate_signal( "setPlayerLevel(int)", t0 );
}

// SIGNAL setPlayerRace
void EQPacket::setPlayerRace( int t0 )
{
    activate_signal( "setPlayerRace(int)", t0 );
}

// SIGNAL setPlayerClass
void EQPacket::setPlayerClass( int t0 )
{
    activate_signal( "setPlayerClass(int)", t0 );
}

// SIGNAL msgReceived
void EQPacket::msgReceived( const QString& t0 )
{
    activate_signal_strref( "msgReceived(const QString&)", t0 );
}

// SIGNAL numPacket
void EQPacket::numPacket( int t0 )
{
    activate_signal( "numPacket(int)", t0 );
}

// SIGNAL attack1Hand1
void EQPacket::attack1Hand1( attack1Struct* t0 )
{
    // No builtin function for signal parameter type attack1Struct*
    QConnectionList *clist = receivers("attack1Hand1(attack1Struct*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(attack1Struct*);
    typedef RT1 *PRT1;
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	}
    }
}

// SIGNAL attack2Hand1
void EQPacket::attack2Hand1( attack2Struct* t0 )
{
    // No builtin function for signal parameter type attack2Struct*
    QConnectionList *clist = receivers("attack2Hand1(attack2Struct*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(attack2Struct*);
    typedef RT1 *PRT1;
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	}
    }
}

// SIGNAL consMessage
void EQPacket::consMessage( considerStruct* t0 )
{
    // No builtin function for signal parameter type considerStruct*
    QConnectionList *clist = receivers("consMessage(considerStruct*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(considerStruct*);
    typedef RT1 *PRT1;
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	}
    }
}

// SIGNAL spawnWearingUpdate
void EQPacket::spawnWearingUpdate( wearChangeStruct* t0 )
{
    // No builtin function for signal parameter type wearChangeStruct*
    QConnectionList *clist = receivers("spawnWearingUpdate(wearChangeStruct*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(wearChangeStruct*);
    typedef RT1 *PRT1;
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	}
    }
}

// SIGNAL newGroundItem
void EQPacket::newGroundItem( dropThingOnGround* t0 )
{
    // No builtin function for signal parameter type dropThingOnGround*
    QConnectionList *clist = receivers("newGroundItem(dropThingOnGround*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(dropThingOnGround*);
    typedef RT1 *PRT1;
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	}
    }
}

// SIGNAL removeGroundItem
void EQPacket::removeGroundItem( removeThingOnGround* t0 )
{
    // No builtin function for signal parameter type removeThingOnGround*
    QConnectionList *clist = receivers("removeGroundItem(removeThingOnGround*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(removeThingOnGround*);
    typedef RT1 *PRT1;
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	}
    }
}

// SIGNAL newCoinsItem
void EQPacket::newCoinsItem( dropCoinsStruct* t0 )
{
    // No builtin function for signal parameter type dropCoinsStruct*
    QConnectionList *clist = receivers("newCoinsItem(dropCoinsStruct*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(dropCoinsStruct*);
    typedef RT1 *PRT1;
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	}
    }
}

// SIGNAL removeCoinsItem
void EQPacket::removeCoinsItem( removeCoinsStruct* t0 )
{
    // No builtin function for signal parameter type removeCoinsStruct*
    QConnectionList *clist = receivers("removeCoinsItem(removeCoinsStruct*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(removeCoinsStruct*);
    typedef RT1 *PRT1;
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	}
    }
}

// SIGNAL newSpawn
void EQPacket::newSpawn( spawnStruct* t0, int t1 )
{
    // No builtin function for signal parameter type spawnStruct*,int
    QConnectionList *clist = receivers("newSpawn(spawnStruct*,int)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(spawnStruct*);
    typedef RT1 *PRT1;
    typedef void (QObject::*RT2)(spawnStruct*,int);
    typedef RT2 *PRT2;
    RT0 r0;
    RT1 r1;
    RT2 r2;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	    case 2:
		r2 = *((PRT2)(c->member()));
		(object->*r2)(t0, t1);
		break;
	}
    }
}

// SIGNAL updateSpawn
void EQPacket::updateSpawn( int t0, int t1, int t2, int t3, int t4, int t5, int t6 )
{
    // No builtin function for signal parameter type int,int,int,int,int,int,int
    QConnectionList *clist = receivers("updateSpawn(int,int,int,int,int,int,int)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(int);
    typedef RT1 *PRT1;
    typedef void (QObject::*RT2)(int,int);
    typedef RT2 *PRT2;
    typedef void (QObject::*RT3)(int,int,int);
    typedef RT3 *PRT3;
    typedef void (QObject::*RT4)(int,int,int,int);
    typedef RT4 *PRT4;
    typedef void (QObject::*RT5)(int,int,int,int,int);
    typedef RT5 *PRT5;
    typedef void (QObject::*RT6)(int,int,int,int,int,int);
    typedef RT6 *PRT6;
    typedef void (QObject::*RT7)(int,int,int,int,int,int,int);
    typedef RT7 *PRT7;
    RT0 r0;
    RT1 r1;
    RT2 r2;
    RT3 r3;
    RT4 r4;
    RT5 r5;
    RT6 r6;
    RT7 r7;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	    case 2:
		r2 = *((PRT2)(c->member()));
		(object->*r2)(t0, t1);
		break;
	    case 3:
		r3 = *((PRT3)(c->member()));
		(object->*r3)(t0, t1, t2);
		break;
	    case 4:
		r4 = *((PRT4)(c->member()));
		(object->*r4)(t0, t1, t2, t3);
		break;
	    case 5:
		r5 = *((PRT5)(c->member()));
		(object->*r5)(t0, t1, t2, t3, t4);
		break;
	    case 6:
		r6 = *((PRT6)(c->member()));
		(object->*r6)(t0, t1, t2, t3, t4, t5);
		break;
	    case 7:
		r7 = *((PRT7)(c->member()));
		(object->*r7)(t0, t1, t2, t3, t4, t5, t6);
		break;
	}
    }
}

// SIGNAL updateSpawnHp
void EQPacket::updateSpawnHp( int t0, int t1, int t2 )
{
    // No builtin function for signal parameter type int,int,int
    QConnectionList *clist = receivers("updateSpawnHp(int,int,int)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(int);
    typedef RT1 *PRT1;
    typedef void (QObject::*RT2)(int,int);
    typedef RT2 *PRT2;
    typedef void (QObject::*RT3)(int,int,int);
    typedef RT3 *PRT3;
    RT0 r0;
    RT1 r1;
    RT2 r2;
    RT3 r3;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	    case 2:
		r2 = *((PRT2)(c->member()));
		(object->*r2)(t0, t1);
		break;
	    case 3:
		r3 = *((PRT3)(c->member()));
		(object->*r3)(t0, t1, t2);
		break;
	}
    }
}

// SIGNAL setPlayerID
void EQPacket::setPlayerID( int t0 )
{
    activate_signal( "setPlayerID(int)", t0 );
}

// SIGNAL refreshMap
void EQPacket::refreshMap()
{
    activate_signal( "refreshMap()" );
}

// SIGNAL deleteSpawn
void EQPacket::deleteSpawn( int t0 )
{
    activate_signal( "deleteSpawn(int)", t0 );
}

// SIGNAL killSpawn
void EQPacket::killSpawn( int t0 )
{
    activate_signal( "killSpawn(int)", t0 );
}

// SIGNAL infoSpawn
void EQPacket::infoSpawn( int t0 )
{
    activate_signal( "infoSpawn(int)", t0 );
}

// SIGNAL newZone
void EQPacket::newZone( char* t0, char* t1 )
{
    // No builtin function for signal parameter type char*,char*
    QConnectionList *clist = receivers("newZone(char*,char*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(char*);
    typedef RT1 *PRT1;
    typedef void (QObject::*RT2)(char*,char*);
    typedef RT2 *PRT2;
    RT0 r0;
    RT1 r1;
    RT2 r2;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	    case 2:
		r2 = *((PRT2)(c->member()));
		(object->*r2)(t0, t1);
		break;
	}
    }
}

// SIGNAL zoneChanged
void EQPacket::zoneChanged()
{
    activate_signal( "zoneChanged()" );
}

// SIGNAL expChangedStr
void EQPacket::expChangedStr( const QString& t0 )
{
    activate_signal_strref( "expChangedStr(const QString&)", t0 );
}

// SIGNAL expChangedInt
void EQPacket::expChangedInt( int t0, int t1, int t2 )
{
    // No builtin function for signal parameter type int,int,int
    QConnectionList *clist = receivers("expChangedInt(int,int,int)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(int);
    typedef RT1 *PRT1;
    typedef void (QObject::*RT2)(int,int);
    typedef RT2 *PRT2;
    typedef void (QObject::*RT3)(int,int,int);
    typedef RT3 *PRT3;
    RT0 r0;
    RT1 r1;
    RT2 r2;
    RT3 r3;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	    case 2:
		r2 = *((PRT2)(c->member()));
		(object->*r2)(t0, t1);
		break;
	    case 3:
		r3 = *((PRT3)(c->member()));
		(object->*r3)(t0, t1, t2);
		break;
	}
    }
}

// SIGNAL expGained
void EQPacket::expGained( const QString& t0, int t1, long t2, QString t3 )
{
    // No builtin function for signal parameter type const QString&,int,long,QString
    QConnectionList *clist = receivers("expGained(const QString&,int,long,QString)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(const QString&);
    typedef RT1 *PRT1;
    typedef void (QObject::*RT2)(const QString&,int);
    typedef RT2 *PRT2;
    typedef void (QObject::*RT3)(const QString&,int,long);
    typedef RT3 *PRT3;
    typedef void (QObject::*RT4)(const QString&,int,long,QString);
    typedef RT4 *PRT4;
    RT0 r0;
    RT1 r1;
    RT2 r2;
    RT3 r3;
    RT4 r4;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	    case 2:
		r2 = *((PRT2)(c->member()));
		(object->*r2)(t0, t1);
		break;
	    case 3:
		r3 = *((PRT3)(c->member()));
		(object->*r3)(t0, t1, t2);
		break;
	    case 4:
		r4 = *((PRT4)(c->member()));
		(object->*r4)(t0, t1, t2, t3);
		break;
	}
    }
}

// SIGNAL manaChanged
void EQPacket::manaChanged( int t0, int t1 )
{
    // No builtin function for signal parameter type int,int
    QConnectionList *clist = receivers("manaChanged(int,int)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(int);
    typedef RT1 *PRT1;
    typedef void (QObject::*RT2)(int,int);
    typedef RT2 *PRT2;
    RT0 r0;
    RT1 r1;
    RT2 r2;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	    case 2:
		r2 = *((PRT2)(c->member()));
		(object->*r2)(t0, t1);
		break;
	}
    }
}

// SIGNAL stamChanged
void EQPacket::stamChanged( int t0, int t1, int t2, int t3, int t4, int t5 )
{
    // No builtin function for signal parameter type int,int,int,int,int,int
    QConnectionList *clist = receivers("stamChanged(int,int,int,int,int,int)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(int);
    typedef RT1 *PRT1;
    typedef void (QObject::*RT2)(int,int);
    typedef RT2 *PRT2;
    typedef void (QObject::*RT3)(int,int,int);
    typedef RT3 *PRT3;
    typedef void (QObject::*RT4)(int,int,int,int);
    typedef RT4 *PRT4;
    typedef void (QObject::*RT5)(int,int,int,int,int);
    typedef RT5 *PRT5;
    typedef void (QObject::*RT6)(int,int,int,int,int,int);
    typedef RT6 *PRT6;
    RT0 r0;
    RT1 r1;
    RT2 r2;
    RT3 r3;
    RT4 r4;
    RT5 r5;
    RT6 r6;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	    case 2:
		r2 = *((PRT2)(c->member()));
		(object->*r2)(t0, t1);
		break;
	    case 3:
		r3 = *((PRT3)(c->member()));
		(object->*r3)(t0, t1, t2);
		break;
	    case 4:
		r4 = *((PRT4)(c->member()));
		(object->*r4)(t0, t1, t2, t3);
		break;
	    case 5:
		r5 = *((PRT5)(c->member()));
		(object->*r5)(t0, t1, t2, t3, t4);
		break;
	    case 6:
		r6 = *((PRT6)(c->member()));
		(object->*r6)(t0, t1, t2, t3, t4, t5);
		break;
	}
    }
}

// SIGNAL stsMessage
void EQPacket::stsMessage( const QString& t0, int t1 )
{
    // No builtin function for signal parameter type const QString&,int
    QConnectionList *clist = receivers("stsMessage(const QString&,int)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(const QString&);
    typedef RT1 *PRT1;
    typedef void (QObject::*RT2)(const QString&,int);
    typedef RT2 *PRT2;
    RT0 r0;
    RT1 r1;
    RT2 r2;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	    case 2:
		r2 = *((PRT2)(c->member()));
		(object->*r2)(t0, t1);
		break;
	}
    }
}
