/****************************************************************************
** MsgDialog meta object code from reading C++ file 'msgdlg.h'
**
** Created: Tue Jun 6 01:16:50 2000
**      by: The Qt Meta Object Compiler ($Revision: 2.53 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#define Q_MOC_MsgDialog
#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 3
#elif Q_MOC_OUTPUT_REVISION != 3
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "msgdlg.h"
#include <qmetaobject.h>
#include <qapplication.h>

#if defined(Q_SPARCWORKS_FUNCP_BUG)
#define Q_AMPERSAND
#else
#define Q_AMPERSAND &
#endif


const char *MsgDialog::className() const
{
    return "MsgDialog";
}

QMetaObject *MsgDialog::metaObj = 0;


#if QT_VERSION >= 199
static QMetaObjectInit init_MsgDialog(&MsgDialog::staticMetaObject);

#endif

void MsgDialog::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QWidget::className(), "QWidget") != 0 )
	badSuperclassWarning("MsgDialog","QWidget");

#if QT_VERSION >= 199
    staticMetaObject();
}

QString MsgDialog::tr(const char* s)
{
    return ((QNonBaseApplication*)qApp)->translate("MsgDialog",s);
}

void MsgDialog::staticMetaObject()
{
    if ( metaObj )
	return;
    QWidget::staticMetaObject();
#else

    QWidget::initMetaObject();
#endif

    typedef void(MsgDialog::*m1_t0)(int);
    typedef void(MsgDialog::*m1_t1)(bool);
    typedef void(MsgDialog::*m1_t2)(int);
    typedef void(MsgDialog::*m1_t3)(const QString&,const QString&,const QString&,bool);
    typedef void(MsgDialog::*m1_t4)();
    typedef void(MsgDialog::*m1_t5)(MyButton*,bool);
    typedef void(MsgDialog::*m1_t6)(bool);
    typedef void(MsgDialog::*m1_t7)(bool);
    typedef void(MsgDialog::*m1_t8)(MyButton*);
    typedef void(MsgDialog::*m1_t9)(const QString&);
    typedef void(MsgDialog::*m1_t10)(const QString&);
    typedef void(MsgDialog::*m1_t11)();
    typedef void(MsgDialog::*m1_t12)(MyButton*);
    typedef void(MsgDialog::*m1_t13)(bool);
    typedef void(MsgDialog::*m1_t14)(bool);
    typedef void(MsgDialog::*m1_t15)();
    typedef void(MsgDialog::*m1_t16)();
    typedef void(MsgDialog::*m1_t17)();
    m1_t0 v1_0 = Q_AMPERSAND MsgDialog::newMessage;
    m1_t1 v1_1 = Q_AMPERSAND MsgDialog::setAdditive;
    m1_t2 v1_2 = Q_AMPERSAND MsgDialog::setMargin;
    m1_t3 v1_3 = Q_AMPERSAND MsgDialog::addButton;
    m1_t4 v1_4 = Q_AMPERSAND MsgDialog::toggleControls;
    m1_t5 v1_5 = Q_AMPERSAND MsgDialog::setButton;
    m1_t6 v1_6 = Q_AMPERSAND MsgDialog::showControls;
    m1_t7 v1_7 = Q_AMPERSAND MsgDialog::showMsgType;
    m1_t8 v1_8 = Q_AMPERSAND MsgDialog::editButton;
    m1_t9 v1_9 = Q_AMPERSAND MsgDialog::addFilter;
    m1_t10 v1_10 = Q_AMPERSAND MsgDialog::delFilter;
    m1_t11 v1_11 = Q_AMPERSAND MsgDialog::refresh;
    m1_t12 v1_12 = Q_AMPERSAND MsgDialog::addFilter;
    m1_t13 v1_13 = Q_AMPERSAND MsgDialog::scrollLock;
    m1_t14 v1_14 = Q_AMPERSAND MsgDialog::setIndexing;
    m1_t15 v1_15 = Q_AMPERSAND MsgDialog::menuAboutToShow;
    m1_t16 v1_16 = Q_AMPERSAND MsgDialog::editButton;
    m1_t17 v1_17 = Q_AMPERSAND MsgDialog::addButton;
    QMetaData *slot_tbl = QMetaObject::new_metadata(18);
    slot_tbl[0].name = "newMessage(int)";
    slot_tbl[1].name = "setAdditive(bool)";
    slot_tbl[2].name = "setMargin(int)";
    slot_tbl[3].name = "addButton(const QString&,const QString&,const QString&,bool)";
    slot_tbl[4].name = "toggleControls()";
    slot_tbl[5].name = "setButton(MyButton*,bool)";
    slot_tbl[6].name = "showControls(bool)";
    slot_tbl[7].name = "showMsgType(bool)";
    slot_tbl[8].name = "editButton(MyButton*)";
    slot_tbl[9].name = "addFilter(const QString&)";
    slot_tbl[10].name = "delFilter(const QString&)";
    slot_tbl[11].name = "refresh()";
    slot_tbl[12].name = "addFilter(MyButton*)";
    slot_tbl[13].name = "scrollLock(bool)";
    slot_tbl[14].name = "setIndexing(bool)";
    slot_tbl[15].name = "menuAboutToShow()";
    slot_tbl[16].name = "editButton()";
    slot_tbl[17].name = "addButton()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    slot_tbl[4].ptr = *((QMember*)&v1_4);
    slot_tbl[5].ptr = *((QMember*)&v1_5);
    slot_tbl[6].ptr = *((QMember*)&v1_6);
    slot_tbl[7].ptr = *((QMember*)&v1_7);
    slot_tbl[8].ptr = *((QMember*)&v1_8);
    slot_tbl[9].ptr = *((QMember*)&v1_9);
    slot_tbl[10].ptr = *((QMember*)&v1_10);
    slot_tbl[11].ptr = *((QMember*)&v1_11);
    slot_tbl[12].ptr = *((QMember*)&v1_12);
    slot_tbl[13].ptr = *((QMember*)&v1_13);
    slot_tbl[14].ptr = *((QMember*)&v1_14);
    slot_tbl[15].ptr = *((QMember*)&v1_15);
    slot_tbl[16].ptr = *((QMember*)&v1_16);
    slot_tbl[17].ptr = *((QMember*)&v1_17);
    metaObj = QMetaObject::new_metaobject(
	"MsgDialog", "QWidget",
	slot_tbl, 18,
	0, 0 );
}


const char *MyButton::className() const
{
    return "MyButton";
}

QMetaObject *MyButton::metaObj = 0;


#if QT_VERSION >= 199
static QMetaObjectInit init_MyButton(&MyButton::staticMetaObject);

#endif

void MyButton::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QCheckBox::className(), "QCheckBox") != 0 )
	badSuperclassWarning("MyButton","QCheckBox");

#if QT_VERSION >= 199
    staticMetaObject();
}

QString MyButton::tr(const char* s)
{
    return ((QNonBaseApplication*)qApp)->translate("MyButton",s);
}

void MyButton::staticMetaObject()
{
    if ( metaObj )
	return;
    QCheckBox::staticMetaObject();
#else

    QCheckBox::initMetaObject();
#endif

    typedef void(MyButton::*m1_t0)(const QString&);
    typedef void(MyButton::*m1_t1)(const QString&);
    typedef void(MyButton::*m1_t2)(bool);
    typedef void(MyButton::*m1_t3)(const QColor&);
    m1_t0 v1_0 = Q_AMPERSAND MyButton::setFilter;
    m1_t1 v1_1 = Q_AMPERSAND MyButton::setText;
    m1_t2 v1_2 = Q_AMPERSAND MyButton::toggled;
    m1_t3 v1_3 = Q_AMPERSAND MyButton::setColor;
    QMetaData *slot_tbl = QMetaObject::new_metadata(4);
    slot_tbl[0].name = "setFilter(const QString&)";
    slot_tbl[1].name = "setText(const QString&)";
    slot_tbl[2].name = "toggled(bool)";
    slot_tbl[3].name = "setColor(const QColor&)";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    typedef void(MyButton::*m2_t0)(MyButton*);
    typedef void(MyButton::*m2_t1)(const QString&);
    typedef void(MyButton::*m2_t2)(const QString&);
    typedef void(MyButton::*m2_t3)();
    typedef void(MyButton::*m2_t4)(MyButton*,bool);
    m2_t0 v2_0 = Q_AMPERSAND MyButton::editButton;
    m2_t1 v2_1 = Q_AMPERSAND MyButton::addFilter;
    m2_t2 v2_2 = Q_AMPERSAND MyButton::delFilter;
    m2_t3 v2_3 = Q_AMPERSAND MyButton::refresh;
    m2_t4 v2_4 = Q_AMPERSAND MyButton::setButton;
    QMetaData *signal_tbl = QMetaObject::new_metadata(5);
    signal_tbl[0].name = "editButton(MyButton*)";
    signal_tbl[1].name = "addFilter(const QString&)";
    signal_tbl[2].name = "delFilter(const QString&)";
    signal_tbl[3].name = "refresh()";
    signal_tbl[4].name = "setButton(MyButton*,bool)";
    signal_tbl[0].ptr = *((QMember*)&v2_0);
    signal_tbl[1].ptr = *((QMember*)&v2_1);
    signal_tbl[2].ptr = *((QMember*)&v2_2);
    signal_tbl[3].ptr = *((QMember*)&v2_3);
    signal_tbl[4].ptr = *((QMember*)&v2_4);
    metaObj = QMetaObject::new_metaobject(
	"MyButton", "QCheckBox",
	slot_tbl, 4,
	signal_tbl, 5 );
}

#include <qobjectdefs.h>
#include <qsignalslotimp.h>

// SIGNAL editButton
void MyButton::editButton( MyButton* t0 )
{
    // No builtin function for signal parameter type MyButton*
    QConnectionList *clist = receivers("editButton(MyButton*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(MyButton*);
    typedef RT1 *PRT1;
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	}
    }
}

// SIGNAL addFilter
void MyButton::addFilter( const QString& t0 )
{
    activate_signal_strref( "addFilter(const QString&)", t0 );
}

// SIGNAL delFilter
void MyButton::delFilter( const QString& t0 )
{
    activate_signal_strref( "delFilter(const QString&)", t0 );
}

// SIGNAL refresh
void MyButton::refresh()
{
    activate_signal( "refresh()" );
}

// SIGNAL setButton
void MyButton::setButton( MyButton* t0, bool t1 )
{
    // No builtin function for signal parameter type MyButton*,bool
    QConnectionList *clist = receivers("setButton(MyButton*,bool)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(MyButton*);
    typedef RT1 *PRT1;
    typedef void (QObject::*RT2)(MyButton*,bool);
    typedef RT2 *PRT2;
    RT0 r0;
    RT1 r1;
    RT2 r2;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	    case 2:
		r2 = *((PRT2)(c->member()));
		(object->*r2)(t0, t1);
		break;
	}
    }
}


const char *CButDlg::className() const
{
    return "CButDlg";
}

QMetaObject *CButDlg::metaObj = 0;


#if QT_VERSION >= 199
static QMetaObjectInit init_CButDlg(&CButDlg::staticMetaObject);

#endif

void CButDlg::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QDialog::className(), "QDialog") != 0 )
	badSuperclassWarning("CButDlg","QDialog");

#if QT_VERSION >= 199
    staticMetaObject();
}

QString CButDlg::tr(const char* s)
{
    return ((QNonBaseApplication*)qApp)->translate("CButDlg",s);
}

void CButDlg::staticMetaObject()
{
    if ( metaObj )
	return;
    QDialog::staticMetaObject();
#else

    QDialog::initMetaObject();
#endif

    metaObj = QMetaObject::new_metaobject(
	"CButDlg", "QDialog",
	0, 0,
	0, 0 );
}


const char *MyEdit::className() const
{
    return "MyEdit";
}

QMetaObject *MyEdit::metaObj = 0;


#if QT_VERSION >= 199
static QMetaObjectInit init_MyEdit(&MyEdit::staticMetaObject);

#endif

void MyEdit::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QMultiLineEdit::className(), "QMultiLineEdit") != 0 )
	badSuperclassWarning("MyEdit","QMultiLineEdit");

#if QT_VERSION >= 199
    staticMetaObject();
}

QString MyEdit::tr(const char* s)
{
    return ((QNonBaseApplication*)qApp)->translate("MyEdit",s);
}

void MyEdit::staticMetaObject()
{
    if ( metaObj )
	return;
    QMultiLineEdit::staticMetaObject();
#else

    QMultiLineEdit::initMetaObject();
#endif

    metaObj = QMetaObject::new_metaobject(
	"MyEdit", "QMultiLineEdit",
	0, 0,
	0, 0 );
}
