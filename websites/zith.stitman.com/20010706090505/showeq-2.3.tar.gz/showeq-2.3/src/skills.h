/*
 * skills.h
 *
 * ShowEQ Distributed under GPL
 * http://www.hackersquest.gomp.ch/
 */

case 0:
sprintf (skill, "1H Blunt");
break;
case 1:
sprintf (skill, "1H Slashing");
break;
case 2:
sprintf (skill, "2H Blunt");
break;
case 3:
sprintf (skill, "2H Slashing");
break;
case 4:
sprintf (skill, "Abjuration");
break;
case 5:
sprintf (skill, "Alteration");
break;
case 6:
sprintf (skill, "Apply Poison");
break;
case 7:
sprintf (skill, "Archery");
break;
case 8:
sprintf (skill, "Backstab");
break;
case 9:
sprintf (skill, "Bind Wound");
break;
case 10:
sprintf (skill, "Bash");
break;
case 11:
sprintf (skill, "Block");
break;
case 12:
sprintf (skill, "Brass Instruments");
break;
case 13:
sprintf (skill, "Channeling");
break;
case 14:
sprintf (skill, "Conjuration");
break;
case 15:
sprintf (skill, "Defense");
break;
case 16:
sprintf (skill, "Disarm");
break;
case 17:
sprintf (skill, "Disarm Traps");
break;
case 18:
sprintf (skill, "Divination");
break;
case 19:
sprintf (skill, "Dodge");
break;
case 20:
sprintf (skill, "Double Attack");
break;
case 21:
sprintf (skill, "Dragon Punch");
break;
case 22:
sprintf (skill, "Duel Wield");
break;
case 23:
sprintf (skill, "Eagle Strike");
break;
case 24:
sprintf (skill, "Evocation");
break;
case 25:
sprintf (skill, "Feign Death");
break;
case 26:
sprintf (skill, "Flying Kick");
break;
case 27:
sprintf (skill, "Forage");
break;
case 28:
sprintf (skill, "Hand To Hand");
break;
case 29:
sprintf (skill, "Hide");
break;
case 30:
sprintf (skill, "Kick");
break;
case 31:
sprintf (skill, "Meditate");
break;
case 32:
sprintf (skill, "Mend");
break;
case 33:
sprintf (skill, "Offense");
break;
case 34:
sprintf (skill, "Parry");
break;
case 35:
sprintf (skill, "Pick Lock");
break;
case 36:
sprintf (skill, "Piercing");
break;
case 37:
sprintf (skill, "Riposte");
break;
case 38:
sprintf (skill, "Round Kick");
break;
case 39:
sprintf (skill, "Safe Fall");
break;
case 40:
sprintf (skill, "Sense Heading");
break;
case 41:
sprintf (skill, "Sing");
break;
case 42:
sprintf (skill, "Sneak");
break;
case 43:
sprintf (skill, "Specialize Abjure");
break;
case 44:
sprintf (skill, "Specialize Alteration");
break;
case 45:
sprintf (skill, "Specialize Conjuration");
break;
case 46:
sprintf (skill, "Specialize Divinatation");
break;
case 47:
sprintf (skill, "Specialize Evocation");
break;
case 48:
sprintf (skill, "Pick Pockets");
break;
case 49:
sprintf (skill, "Stringed Instruments");
break;
case 50:
sprintf (skill, "Swimming");
break;
case 51:
sprintf (skill, "Throwing");
break;
case 52:
sprintf (skill, "Tiger Claw");
break;
case 53:
sprintf (skill, "Tracking");
break;
case 54:
sprintf (skill, "Wind Instruments");
break;
case 55:
sprintf (skill, "Fishing");
break;
case 56:
sprintf (skill, "Make Poison");
break;
case 57:
sprintf (skill, "Tinkering");
break;
case 58:
sprintf (skill, "Research");
break;
case 59:
sprintf (skill, "Alchemy");
break;
case 60:
sprintf (skill, "Baking");
break;
case 61:
sprintf (skill, "Tailoring");
break;
case 62:
sprintf (skill, "Sense Traps");
break;
case 63:
sprintf (skill, "Blacksmithing");
break;
case 64:
sprintf (skill, "Fletching");
break;
case 65:
sprintf (skill, "Brewing");
break;
case 66:
sprintf (skill, "Alcohol Tolerance");
break;
case 67:
sprintf (skill, "Begging");
break;
case 68:
sprintf (skill, "Jewelry Making");
break;
case 69:
sprintf (skill, "Pottery");
break;
case 70:
sprintf (skill, "Percussion Instruments");
break;
case 71:
sprintf (skill, "Intimidation");
break;
case 72:
sprintf (skill, "Berserking");
break;
case 73:
sprintf (skill, "Taunt");
break;
