#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "util.h"

void printdata (int len, unsigned char *data)
{
   char hex[128];
   char asc[128];
   char tmp[32];

   hex[0]=0; asc[0]=0;
   int c;
   for (c=0; c<len; c++)
   {
      if ((!(c%16))&&c)
      {                                                                                  printf ("%03d | %s | %s \n", c-16, hex, asc);
	 hex[0]=0; asc[0]=0;
      }

      sprintf (tmp, "%02x ", data[c]);
      strcat (hex, tmp);
      if ((data[c]>=32) && (data[c]<=126))
	sprintf (tmp, "%c", data[c]);
      else
	strcpy (tmp, ".");
      strcat (asc, tmp);

   }
   if (c%16)
     c=c-(c%16);
   else
     c-=16;
   printf ("%03d | %-48s | %s \n\n", c, hex, asc);
}

int main (int argc, char *argv[])
{
   FILE *sdb;
   struct dbSpawnStruct dbSpawn;
   extern int errno;
   int found=0;
   char dbname[256];

   printf ("Content-type: text/html\n\n");

   sdb = fopen (SPAWNFILE, "r");
   if (sdb == NULL) {
	   printf("Unable to open file '" SPAWNFILE "' (error = %d)\n", errno);
   }
   while (fread (&dbSpawn, sizeof(dbSpawnStruct), 1, sdb))
   {
      strcpy (dbname, dbSpawn.spawn.name);
      for (int a=0; a<strlen(dbSpawn.spawn.name); a++)
      {
	 if (dbname[a]<='9')
	   dbname[a]=0;
      }
      if (!strcmp(dbname, argv[1]))
      {
	 printf ("<H1>%s</H1>\n", dbSpawn.spawn.name);

	 printf ("Level: %d<BR>\n", dbSpawn.spawn.level);
	 printf ("HP: %d/%d<BR>\n", dbSpawn.spawn.curHp,dbSpawn.spawn.maxHp);
	 printf ("Race: %s<BR>\n", race_name(dbSpawn.spawn.race));
	 printf ("Class: %s<BR>\n", class_name(dbSpawn.spawn.class_));
	 printf ("Found in Zone: %s<BR>\n", dbSpawn.zoneName);
	 printf ("Position: %d,%d<BR>\n", dbSpawn.spawn.yPos,dbSpawn.spawn.xPos);
	 printf ("Mob ID: %d<BR>\n", dbSpawn.spawn.spawnId);
	 printf ("<B>Packet data:</B>\n");
	 printf ("<PRE>\n");
	 printdata (sizeof(spawnStruct), (unsigned char *)&dbSpawn.spawn);
	 printf ("</PRE>\n");
	 printf ("<HR>\n");
	 found=1;
      }
   }
   fclose (sdb);

   if (!found)
     printf ("Spawn %s not found\n", argv[1]);
}
