/****************************************************************************
** CSpawnList meta object code from reading C++ file 'spawnlist.h'
**
** Created: Tue Jun 6 01:15:05 2000
**      by: The Qt Meta Object Compiler ($Revision: 2.53 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#define Q_MOC_CSpawnList
#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 3
#elif Q_MOC_OUTPUT_REVISION != 3
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "spawnlist.h"
#include <qmetaobject.h>
#include <qapplication.h>

#if defined(Q_SPARCWORKS_FUNCP_BUG)
#define Q_AMPERSAND
#else
#define Q_AMPERSAND &
#endif


const char *CSpawnList::className() const
{
    return "CSpawnList";
}

QMetaObject *CSpawnList::metaObj = 0;


#if QT_VERSION >= 199
static QMetaObjectInit init_CSpawnList(&CSpawnList::staticMetaObject);

#endif

void CSpawnList::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QListView::className(), "QListView") != 0 )
	badSuperclassWarning("CSpawnList","QListView");

#if QT_VERSION >= 199
    staticMetaObject();
}

QString CSpawnList::tr(const char* s)
{
    return ((QNonBaseApplication*)qApp)->translate("CSpawnList",s);
}

void CSpawnList::staticMetaObject()
{
    if ( metaObj )
	return;
    QListView::staticMetaObject();
#else

    QListView::initMetaObject();
#endif

    typedef void(CSpawnList::*m1_t0)(int,int,int,int,int,int,int);
    typedef void(CSpawnList::*m1_t1)(int);
    typedef void(CSpawnList::*m1_t2)(bool);
    typedef void(CSpawnList::*m1_t3)();
    typedef void(CSpawnList::*m1_t4)();
    typedef void(CSpawnList::*m1_t5)();
    m1_t0 v1_0 = Q_AMPERSAND CSpawnList::setPlayer;
    m1_t1 v1_1 = Q_AMPERSAND CSpawnList::setPlayerLevel;
    m1_t2 v1_2 = Q_AMPERSAND CSpawnList::setDebug;
    m1_t3 v1_3 = Q_AMPERSAND CSpawnList::selectNext;
    m1_t4 v1_4 = Q_AMPERSAND CSpawnList::selectPrev;
    m1_t5 v1_5 = Q_AMPERSAND CSpawnList::toggleHide;
    QMetaData *slot_tbl = QMetaObject::new_metadata(6);
    slot_tbl[0].name = "setPlayer(int,int,int,int,int,int,int)";
    slot_tbl[1].name = "setPlayerLevel(int)";
    slot_tbl[2].name = "setDebug(bool)";
    slot_tbl[3].name = "selectNext()";
    slot_tbl[4].name = "selectPrev()";
    slot_tbl[5].name = "toggleHide()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    slot_tbl[4].ptr = *((QMember*)&v1_4);
    slot_tbl[5].ptr = *((QMember*)&v1_5);
    typedef void(CSpawnList::*m2_t0)();
    typedef void(CSpawnList::*m2_t1)();
    m2_t0 v2_0 = Q_AMPERSAND CSpawnList::listUpdated;
    m2_t1 v2_1 = Q_AMPERSAND CSpawnList::listChanged;
    QMetaData *signal_tbl = QMetaObject::new_metadata(2);
    signal_tbl[0].name = "listUpdated()";
    signal_tbl[1].name = "listChanged()";
    signal_tbl[0].ptr = *((QMember*)&v2_0);
    signal_tbl[1].ptr = *((QMember*)&v2_1);
    metaObj = QMetaObject::new_metaobject(
	"CSpawnList", "QListView",
	slot_tbl, 6,
	signal_tbl, 2 );
}

// SIGNAL listUpdated
void CSpawnList::listUpdated()
{
    activate_signal( "listUpdated()" );
}

// SIGNAL listChanged
void CSpawnList::listChanged()
{
    activate_signal( "listChanged()" );
}
