/****************************************************************************
** Compass meta object code from reading C++ file 'compass.h'
**
** Created: Tue Jun 6 01:15:59 2000
**      by: The Qt Meta Object Compiler ($Revision: 2.53 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#define Q_MOC_Compass
#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 3
#elif Q_MOC_OUTPUT_REVISION != 3
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "compass.h"
#include <qmetaobject.h>
#include <qapplication.h>

#if defined(Q_SPARCWORKS_FUNCP_BUG)
#define Q_AMPERSAND
#else
#define Q_AMPERSAND &
#endif


const char *Compass::className() const
{
    return "Compass";
}

QMetaObject *Compass::metaObj = 0;


#if QT_VERSION >= 199
static QMetaObjectInit init_Compass(&Compass::staticMetaObject);

#endif

void Compass::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QWidget::className(), "QWidget") != 0 )
	badSuperclassWarning("Compass","QWidget");

#if QT_VERSION >= 199
    staticMetaObject();
}

QString Compass::tr(const char* s)
{
    return ((QNonBaseApplication*)qApp)->translate("Compass",s);
}

void Compass::staticMetaObject()
{
    if ( metaObj )
	return;
    QWidget::staticMetaObject();
#else

    QWidget::initMetaObject();
#endif

    typedef void(Compass::*m1_t0)(int);
    typedef void(Compass::*m1_t1)(QListViewItem*);
    typedef void(Compass::*m1_t2)(int,int,int,int,int,int,int);
    typedef void(Compass::*m1_t3)(int,int);
    m1_t0 v1_0 = Q_AMPERSAND Compass::setAngle;
    m1_t1 v1_1 = Q_AMPERSAND Compass::selectSpawn;
    m1_t2 v1_2 = Q_AMPERSAND Compass::setPlayer;
    m1_t3 v1_3 = Q_AMPERSAND Compass::selSpawnUpdate;
    QMetaData *slot_tbl = QMetaObject::new_metadata(4);
    slot_tbl[0].name = "setAngle(int)";
    slot_tbl[1].name = "selectSpawn(QListViewItem*)";
    slot_tbl[2].name = "setPlayer(int,int,int,int,int,int,int)";
    slot_tbl[3].name = "selSpawnUpdate(int,int)";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    typedef void(Compass::*m2_t0)(int);
    m2_t0 v2_0 = Q_AMPERSAND Compass::angleChanged;
    QMetaData *signal_tbl = QMetaObject::new_metadata(1);
    signal_tbl[0].name = "angleChanged(int)";
    signal_tbl[0].ptr = *((QMember*)&v2_0);
    metaObj = QMetaObject::new_metaobject(
	"Compass", "QWidget",
	slot_tbl, 4,
	signal_tbl, 1 );
}

// SIGNAL angleChanged
void Compass::angleChanged( int t0 )
{
    activate_signal( "angleChanged(int)", t0 );
}
