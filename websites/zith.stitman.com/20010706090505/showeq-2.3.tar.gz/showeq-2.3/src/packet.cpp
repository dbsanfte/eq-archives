
/*
 * packet.cpp
 *
 * ShowEQ Distributed under GPL
 * http://www.hackersquest.gomp.ch/
 */

/* Implementation of Packet class */
#include <sys/param.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/poll.h>
#include <sys/stat.h>

#ifdef	__FreeBSD__
#include <netinet/in_systm.h>   
#include <net/if.h>
#include <netinet/in.h>
#include <netinet/if_ether.h>
#include <netinet/ip.h>  
#include <netinet/udp.h>
#include <netinet/if_ether.h>
#include <arpa/inet.h>

#else	/* FREEBSD */
#include <net/if.h>
#include <net/if_packet.h>
#include <netinet/if_ether.h>
#include <netinet/in.h>
#include <netinet/ip.h>  
#include <netinet/udp.h>
#include <netinet/if_ether.h>
#include <arpa/inet.h>
#endif	/* FREEBSD */

#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>

#include <time.h>
#include <netdb.h>
#include <qtimer.h>
#include "everquest.h"
#include "packet.h"
#include "util.h"
#include "main.h"
#include "vpacket.h"

//#define DEBUG

#undef DEBUG

// Packet version is a unique number that should be bumped every time packet 
// structure (ie. encryption) changes.  It is checked by the VPacket feature
// (currently the date of the last packet structure change)
#define PACKETVERSION  40100
//unsigned int key;

void preProcessPacket (unsigned char *data, int *len, int direction, UDWORD *state);

/* EQPacket Class - Sets up packet capturing */
EQPacket::EQPacket (QObject * parent, const char *name):
QObject (parent, name)
{
#ifdef DEBUG
   debug ("EQPacket()");
#endif /* DEBUG */

   struct hostent *
     he;
   struct in_addr
     ia;
   char *
     a;

   if (!showeq_params->ip) 
   {
	 printf ("No address specified\n");
	 exit (0);
   }
   if (inet_aton (showeq_params->ip, &ia) == 0)
   {
      he = gethostbyname (showeq_params->ip);
      if (!he)
      {
	 printf ("Invalid address; %s\n", showeq_params->ip);
	 exit (0);
      }
      memcpy (&ia, he->h_addr_list[0], he->h_length);
   }

  client_addr = ia.s_addr;
  showeq_params->ip = strdup (inet_ntoa (ia));
  if (!showeq_params->playbackpackets)
  {
    EQPacketInitPcap (showeq_params->device, showeq_params->ip,
		    showeq_params->realtime);
  }

  busy_decoding = 0;
  packetcount = 0;
  serverSeqExp = 0;
  userResync = 0;
  serverSeqClear = 1;
  serverCacheCount = 0;
  serverAddr = 0;
  serverPort = 0;
  clientSeq = 0;
  clientSeqClear = 1;
  clientCacheCount = 0;
  clientAddr = 0;
  clientPort = 0;
  playerID = 10;
  groupID[0] = 0;
  groupID[1] = 0;
  groupID[2] = 0;
  groupID[3] = 0;
  groupID[4] = 0;
  groupID[5] = 0;
  groupSize = 0;

  logRaw         = FALSE;
  logAllPackets  = FALSE;
  logZoneData    = FALSE;
  logUnknownData = FALSE;
  viewChannelMsgs = TRUE;
  viewUnknownData = FALSE;

  /* Load the spand and filter list */
   //printf("nulling the filterList and the spawnList\n");
   filterList = spawnList = NULL;
   //printf("nullified the filterList and the spawnList\n");
   if (pSEQPrefs->GetPrefBool("Filters_UseOldFilters", 0))
     initSpawnLists ();

  /* Create timer object and connect to slot */
   timer = new QTimer (this);
   connect (timer, SIGNAL (timeout ()), this, SLOT (processPackets ()));

  /* setup VPacket */
  m_pVPacket = NULL;

  // First param to VPacket is the filename
  // Second param is playback speed:  0 = fast as poss, 1 = 1X, 2 = 2X etc
  if (pSEQPrefs->isPreference("VPacket_Filename"))
  {
    const char *filename = pSEQPrefs->GetPrefString("VPacket_Filename");
    if (showeq_params->recordpackets)
    {
       m_pVPacket = new VPacket(filename, 1, TRUE);
       // Must appear befire next call to GetPrefString, which uses a static string
       printf("Recording packets to '%s' for future playback\n", filename);
       if (pSEQPrefs->GetPrefString("VPacket_FlushPackets"))
          m_pVPacket->setFlushPacket(TRUE);
    }
    else if (showeq_params->playbackpackets)
    {
       m_pVPacket = new VPacket(filename, 1, FALSE);
       m_pVPacket->setCompressTime(
                 pSEQPrefs->GetPrefInt("VPacket_CompressTime", 0));
       m_pVPacket->setPlaybackSpeed(
                 pSEQPrefs->GetPrefInt("VPacket_PlaybackRate", 1));
       printf("Playing back packets from '%s'\n", filename);
    }
  }
  else
  {
     showeq_params->recordpackets  = 0;
     showeq_params->playbackpackets = 0;
  }

  m_nPacket = 0;
}

/* Returns string representation of numeric IP address */
char *
  EQPacket::print_addr (int addr)
{
#ifdef DEBUG
   debug ("print_addr()");
#endif /* DEBUG */
   static char
     paddr[64];

   if (addr == client_addr)
   {
      strcpy (paddr, "client");
   }
   else
   {
      sprintf (paddr, "%d.%d.%d.%d",
	       addr & 0x000000ff,
	       (addr & 0x0000ff00) >> 8,
	       (addr & 0x00ff0000) >> 16, (addr & 0xff000000) >> 24);
   }
   return paddr;
}

/* Start the timer to process packets */
void
  EQPacket::start (int delay)
{
#ifdef DEBUG
   debug ("start()");
#endif /* DEBUG */
   timer->start (delay, FALSE);
}

/* Stop the timer to process packets */
void
  EQPacket::stop (void)
{
#ifdef DEBUG
   debug ("stop()");
#endif /* DEBUG */
   timer->stop ();
}

/* Reads packets and processes waiting packets */
void
  EQPacket::processPackets (void)
{
#ifdef DEBUG
//   debug ("processPackets()");
#endif /* DEBUG */
  /* Make sure we are not called while already busy */
   if (busy_decoding)
     return;
  /* Set flag that we are busy decoding */
   busy_decoding = 1;

   struct pollfd
     pfd;
   unsigned char
     buffer[8192];
   struct ip *
     ip;
   int
     size;


   /* if in packet playback mode fetch packets from VPacket class */
   if (showeq_params->playbackpackets)
   {
      time_t now;
      int timein = mTime();
      int i = 0;

//      if (!m_pVPacket->EndOfFile())
      {
         long version = PACKETVERSION;

         // decode packets from the playback buffer
//         while ((size = m_pVPacket->Playback((char *) buffer, 
//             sizeof(buffer), &now, &version)))
         do 
         {
           size = m_pVPacket->Playback((char *) buffer, 
                                         sizeof(buffer), &now, &version);
           if (size)
           {
             i++;
             if (PACKETVERSION == version)
             {
               decodePacket (size - sizeof (struct ether_header), 
                 (unsigned char *) buffer + sizeof (struct ether_header));
             }
             else
             {
               fprintf(stderr, "Error:  The version of the packet stream has " \
                  "changed since '%s' was recorded - disabling playback\n", 
                  pSEQPrefs->GetPrefString("VPacket_Filename"));
               showeq_params->playbackpackets = 0;
               break;
             }

           }
           else
              break;

         } while ( (mTime() - timein) < 100);
      }
   }

   /* otherwise fetch them from pcap */
   else
   {
     while ((size = EQPacketGetPacket (buffer)))
     {
        /* Get pointer to MAC layer header */
        struct ether_header *
  	ep;
        ep = (struct ether_header *) buffer;
        /* If its not an IP packet, discard the packet */
        if (ntohs (ep->ether_type) != ETHERTYPE_IP)
  	continue;
  
        /* Now.. we know the rest is an IP udp packet concerning the
         * host in question, because pcap takes care of that.
         */
  
        /* Now we assume its an everquest packet */
        if (showeq_params->recordpackets)
        {
           time_t now = time(NULL);
           m_pVPacket->Record((const char *) buffer, size, now, PACKETVERSION);
        }

        decodePacket (size - sizeof (struct ether_header), 
            (unsigned char *) buffer + sizeof (struct ether_header));
     }
   } 
  /* Clear decoding flag */
   busy_decoding = 0;
}

void
  EQPacket::logRawData (char *filename, unsigned char *data, unsigned int len)
{
#ifdef DEBUG
   debug ("logRawData()");
#endif /* DEBUG */

   int file;
   char fname[256];
   sprintf (fname, "%s/%s", LOGDIR, filename);
   //printf("FilePath: %s\n", fname);
   file = open (fname, O_CREAT | O_APPEND | O_RDWR);

   if (-1 == file)
   {
      fprintf(stderr,"\aUnable to open file: [%s]\n",fname);
      return;
   }

   write(file, data, len);

   close (file);
}


void
  EQPacket::logData (char *filename, int len, unsigned char *data,
		     long saddr = 0, long daddr = 0, int sport =
		     0, int dport = 0)
{
#ifdef DEBUG
   debug ("logData()");
#endif /* DEBUG */

   FILE *
     lh;
   char
     fname[256];
   sprintf (fname, "%s/%s", LOGDIR, filename);
   //printf("FilePath: %s\n", fname);
   lh = fopen (fname, "a");

   if (lh == NULL)
   {
      fprintf(stderr,"\aUnable to open file: [%s]\n",fname);
      return;
   }

   time_t
     now;

   now = time (NULL);

   if (saddr)
   {
      fprintf (lh, "%s:%d->", print_addr (saddr), sport);
      fprintf (lh, "%s:%d (%d) %s",
	       print_addr (daddr), dport, len, ctime (&now));
   }

   char
     hex[128];
   char
     asc[128];
   char
     tmp[32];

   hex[0] = 0;
   asc[0] = 0;
   int
     c;
   for (c = 0; c < len; c++)
   {
      if ((!(c % 16)) && c)
      {
	 fprintf (lh, "%03d | %s | %s \n", c - 16, hex, asc);
	 hex[0] = 0;
	 asc[0] = 0;
      }

      sprintf (tmp, "%02x ", data[c]);
      strcat (hex, tmp);
      if ((data[c] >= 32) && (data[c] <= 126))
	sprintf (tmp, "%c", data[c]);
      else
	strcpy (tmp, ".");
      strcat (asc, tmp);

   }
   if (c % 16)
     c = c - (c % 16);
   else
     c -= 16;
   fprintf (lh, "%03d | %-48s | %s \n\n", c, hex, asc);
   //printf ("%03d | %-48s | %s \n\n", c, hex, asc);

   fclose (lh);

}

void
  EQPacket::logPacket (char *filename, int size, unsigned char *buffer)
{
#ifdef DEBUG
   debug ("logPacket()");
#endif /* DEBUG */
   u_char *
     data;
   struct ip *
     ip;
   struct udphdr *
     udp;
   int
     hlen, len;

   data = (unsigned char *) buffer;
   ip = (struct ip *) buffer;
   hlen = ip->ip_hl * 4;
   len = ntohs (ip->ip_len);
   len -= hlen;
   data += hlen;

   udp = (struct udphdr *) data;
   len -= sizeof (struct udphdr);
   data += (sizeof (struct udphdr));

#ifdef __FreeBSD__
   logData (filename, len, data, ip->ip_src.s_addr, ip->ip_dst.s_addr,
	    ntohs (udp->uh_sport), ntohs (udp->uh_dport));
#else  /* FreeBSD */
   logData (filename, len, data, ip->ip_src.s_addr, ip->ip_dst.s_addr,
	    ntohs (udp->source), ntohs (udp->dest));
#endif /* FreeBSD */
}

/* This function decides the fate of the Everquest packet */
/* and dispatches it to the correct packet handling function */
void
  EQPacket::decodePacket (int size, unsigned char *buffer)
{
#ifdef DEBUG
   debug ("decodePacket()");
#endif /* DEBUG */
  /* Setup variables */
   u_char *
     data;
   struct ip *
     ip;
   struct udphdr *
     udp;
   int
     hlen, len;
   
   data = (unsigned char *) buffer;
   ip = (struct ip *) buffer;
   hlen = ip->ip_hl * 4;
   len = ntohs (ip->ip_len);
   len -= hlen;
   data += hlen;

   udp = (struct udphdr *) data;
   len -= sizeof (struct udphdr);
   data += (sizeof (struct udphdr));

   emit numPacket(++m_nPacket);

   if (logAllPackets)
     logPacket ("global.log", size, buffer);

  /* Do a couple of checks on the packet */
   if (!data[0])			/* If the first byte of a packet is 0, then its a pure ack
packet */
     return;			/* We don't want this packet, so throw it away */

  /* Check if the packet contains embedded ack information */
  /* and strip it out of exists */
   if (data[1] == 0x04 || data[1] == 0x08)
   {				/* If offset 1 is 4, then its got ack info */

      /* Strip out ack by shifting packet over ack info */
      data[5] = data[3];
      data[4] = data[2];
      data[3] = 0x00;
      data[2] = data[0];
      data += 2;
      len -= 2;
   }
   else if (data[1] == 0x14)
   {
      /* Strip out ack */
      data[6] = data[3];
      data[5] = data[2];
      data[4] = 0x00;
      data[3] = data[0];
      data += 3;
      len -= 3;
   }
   else if (data[1] == 0x18)
   {
      data[6] = data[3];
      data[5] = data[2];
      data[4] = 0x00;
      data[3] = data[0];
      data += 3;
      len -= 3;
   }
   else if (data[1] == 0x24)
   {
      data[7] = data[3];
      data[6] = data[2];
      data[5] = 0x00;
      data[4] = data[0];
      data += 4;
      len -= 4;
   }
   else if (data[1] == 0x34)
   {
      data[8] = data[3];
      data[7] = data[2];
      data[6] = 0x00;
      data[5] = data[0];
      data += 5;
      len -= 5;
   }
   else if (data[1] == 0x44)
   {
      data[9] = data[3];
      data[8] = data[2];
      data[7] = 0x00;
      data[6] = data[0];
      data += 6;
      len -= 6;
   }
   else if (data[1] == 0x64)
   {
      data[5] = data[3];
      data[6] = data[2];
      data[7] = 0x00;
      data[8] = data[0];
      data += 8;
      len -= 8;
   }
   else if (data[1] == 0x74)
   {
      data[12] = data[3];
      data[11] = data[2];
      data[10] = 0x00;
      data[9] = data[0];
      data += 9;
      len -= 9;
   }
   else if (data[1] == 0x02)
   {
      data[1] = 0;
   }

  /* Client packet */
   if (ip->ip_src.s_addr == client_addr)
   {
#ifdef __FreeBSD__
      if (ntohs (udp->uh_dport) == 9000)
#else   /* __FreeBSD__ */
      if (ntohs (udp->dest) == 9000)
#endif  /* __FreeBSD__ */
      {
	  /* World Server Packet */
	  /* Discard for now */
	 return;
      }
#ifdef __FreeBSD__
      if (ntohs (udp->uh_dport) == 5999)
#else   /* __FreeBSD__ */
      if (ntohs (udp->dest) == 5999)
#endif  /* __FreeBSD__ */
      {
	  /* Chat Server Packet */
	  /* Discard for now */
	 return;
      }
      if (data[0] == 0x10)
      {
	  /* Unacknowledged packet */
	  /* Dispatch packet */
	 dispatchZoneData (len - 9, data + 5, DIR_CLIENT);
	 return;
      }
      else
      {
	  /* Acknowledged packet */
	 return;
      }
   }
  /* Server Packet */
   else
   {
#ifdef __FreeBSD__
      if (ntohs (udp->uh_sport) == 9000)
#else   /* __FreeBSD__ */
      if (ntohs (udp->source) == 9000)
#endif  /* __FreeBSD__ */
      {
	  /* World Server Packet */
	  /* Discard for now */
	 return;
      }
#ifdef __FreeBSD__
      if (ntohs (udp->uh_sport) == 5999)
#else   /* __FreeBSD__ */
      if (ntohs (udp->source) == 5999)
#endif  /* __FreeBSD__ */
      {
	  /* Chat Server Packet */
	  /* Discard for now */
	 return;
      }
      /* Check if its an acknowledged or unacknowledged packet */
      if (data[0] == 0x10)
      {
	  /* Unacknowledged packet */
	  /* Packet coming from zone server */
	  /* Dispatch packet */
	 dispatchZoneData (len - 9, data + 5, DIR_SERVER);
	 return;
      }
      else
      {
	 unsigned int
	   serverSeq = data[5] | (data[4] << 8);
	 unsigned int
	   opcode = data[9] | (data[8] << 8);
	 emit
	   seqReceive (serverSeq);
	 // printf ("SEQ Received: %04x - %04x\n", serverSeq, opcode);
	  /* Assume this is an acknowledged packet */

	  /* Is this start of sequence and seq clear? */
	 if ((data[0] == 0x3a)||(data[0]==0x32) || userResync)
	 {
 	    userResync=0;
	    serverSeqExp = serverSeq + 1;
	    serverSeqExp %= 0x10000;
	    emit
	      seqExpect (serverSeqExp);
	    serverSeqClear = 0;
	    serverCacheCount = 0;
	    emit
	      packetReceived (serverCacheCount);
	    if (data[0] == 0x32)
	      dispatchZoneData (len-12, data+8, DIR_SERVER);
	    else
	      dispatchZoneSplitData (len, data);


	 }
	 else if ((!serverSeqClear) && (serverSeq >= serverSeqExp))
	 {			/* Need to fix this for wrap */
	    int
	      found = 0;
	      /* Check if its in our cache already */
	    for (int a = 0; a < serverCacheCount; a++)
	    {
	       if (serverCacheSeq[a] == serverSeq)
		 found = a + 1;
	    }
	    if ((!found) && (serverCacheCount < MAXPACKETCACHECOUNT))
	    {
	       int t;
		  //printf ("Packet not found in cache, adding %x(%d)\n", serverSeq,serverCacheCount);
		  /* A packet we need to put into the cache */
	       serverCacheLen[serverCacheCount] = len;
	       serverCacheSeq[serverCacheCount] = serverSeq;
	       for (int a = 0; a < len; a++)
		 serverCachePkt[serverCacheCount][a] = data[a];
	       serverCacheCount++;
	       emit
		 packetReceived (serverCacheCount);
	       t = pSEQPrefs->GetPrefInt("Network_AutoResync", 0);
	       if(t > 0 && serverCacheCount > t) {
		 userResync = 1;
		 printf("Auto Resyncing the network\n");
	       }
	    }
	      //printf ("Packet already in cache, not adding %x\n",serverSeq);
	 }

	  /* Run through our saved packets and try find match */
	 int
	   packetSent;

	 do
	 {
	    packetSent = 0;
	    int
	      found = 0;
	    for (int a = 0; a < serverCacheCount; a++)
	    {
	       if (serverCacheSeq[a] == serverSeqExp)
		 found = a + 1;
	    }
	    if (found)
	    {
		  /* Dispatch the packet */
		  //printf ("Found packet in cache and removed, %x(%d)\n",serverCacheSeq[found-1], serverCacheCount-1);
	       if ((serverCachePkt[found - 1][0] == 0x3a) ||
		   (serverCachePkt[found - 1][0] == 0x1a) ||
		   (serverCachePkt[found - 1][0] == 0x0a))
		 dispatchZoneSplitData (serverCacheLen[found - 1],
					serverCachePkt[found - 1]);
	       else
		 dispatchZoneData (serverCacheLen[found - 1] - 12,
				   serverCachePkt[found - 1] + 8,
				   DIR_SERVER);
	       serverSeqExp++;
	       serverSeqExp %= 0x10000;

	       emit
		 seqExpect (serverSeqExp);
	       packetSent = 1;
		  /* Remove packet from cache */
	       if (serverCacheCount > 1)
	       {
		  serverCacheLen[found - 1] =
		    serverCacheLen[serverCacheCount - 1];
		  serverCacheSeq[found - 1] =
		    serverCacheSeq[serverCacheCount - 1];
		  for (int a = 0;
		       a < serverCacheLen[serverCacheCount - 1]; a++)
		    serverCachePkt[found - 1][a] =
		    serverCachePkt[serverCacheCount - 1][a];
	       }
	       serverCacheCount--;
	       emit
		 packetReceived (serverCacheCount);
	    }
	 }
	 while (packetSent);

      }
   }
}

/*spawn struct, decode key, 
and unsigned int dbemit:
dbemit & 1 means send to DB
dbemit & 2 means sent to Map.
This way we can start filling the spawns list while we are zoning.
Yet not populate the database until we know where we are!
*/
void EQPacket::processSpawn (struct dbSpawnStruct *dbSpawn, unsigned int key, int dbemit)
{
#ifdef DEBUG
   debug ("processSpawn()");
#endif /* DEBUG */
   int spawnType;
   int alerted = 0;
   char info[1024];
   spawnStruct fSpawn;
   petStruct sPet;
   strcpy (info, "");
   int len;
   len = sizeof(dbSpawn->spawn);

   //printf("A %s\n", dbSpawn->spawn.name);

   if (showeq_params->broken_decode) 
	return;

   //printf("B %s\n", dbSpawn->spawn.name);
   //Remove those annoying a_large_bat##'s.

   //A group member has a new spawn id:
   for(int gp = 0; gp < groupSize; gp++){
       //printf("groupName: %s, tested: %s\n", groupNames[gp], spawns[n].name);
       if (stricmp(groupNames[gp], dbSpawn->spawn.name) == 0){
           groupID[gp] = dbSpawn->spawn.spawnId;
           break;
       }
   }

   //printf("C %s\n", dbSpawn->spawn.name);
   if (dbSpawn->spawn.NPC != 2)	//not dead.
     for (int x = strlen (dbSpawn->spawn.name) - 1; x > 0; x--)
     {
	if ((dbSpawn->spawn.name[x] >= '0')
	    && (dbSpawn->spawn.name[x] <= '9'))
	{
	   dbSpawn->spawn.name[x] = '\0';
	}
	else
	{
	   break;
	}
     }

   //printf("d %s  %i\n", dbSpawn->spawn.name, dbemit);   
   if ((dbemit & 1) && showeq_params->logSpawns) {//send to spawn DB.
   // printf("Adding %s to spawn db\n", dbSpawn->spawn.name);
   // This is a pet if petOwnerId isn't 0
       if (dbSpawn->spawn.petOwnerId != 0)
       {
           if (m_Spawns.contains(dbSpawn->spawn.petOwnerId))
           {
	       fSpawn = m_Spawns[dbSpawn->spawn.petOwnerId];
	       // First see if the pet owner is a player,
	       // if so log it in the pet db.
	       if (fSpawn.NPC == 0)
	       {
	           sPet.owner = fSpawn;
	           sPet.pet   = dbSpawn->spawn;
	           petdb(&sPet);
	       }

	       // Otherwise its a NPC's pet, just log it for now
	       else
	       {
	           spawndb(dbSpawn);
	        }
            }
       }
       else
       {
          /* Log spawn to the database */
          spawndb (dbSpawn);
       }
   }

   //printf("E %s\n", dbSpawn->spawn.name);
   // new filtering moved to map class
   if (pSEQPrefs->GetPrefBool("Filters_UseOldFilters", 0))
   {
     /* Check if this is a spawn alert */
     if(showeq_params->spawn_alert_plus_plus)
       alerted = spawnAlert (spawnAlertName(&dbSpawn->spawn));
     else
       alerted = spawnAlert (dbSpawn->spawn.name);

     /* Check if we are filtering this spawn */
     if (!alerted && spawnFilter (dbSpawn->spawn.name))
       return;
   }

   //printf("F %s  %i\n", dbSpawn->spawn.name, dbemit);

  if (dbemit & 2){
    //printf("Adding %s to spawn list\n", dbSpawn->spawn.name);
    emit newSpawn (&dbSpawn->spawn, alerted);
  }
   //printf("G %s\n", dbSpawn->spawn.name);
}

void EQPacket::dispatchZoneData (int len, unsigned char *data, int direction =
0)
{
   char *	totalExp;
   char *	gainedExp;
   char *       leftExp;
   char *       needKills;
   static UDWORD state;
   QString tempStr("");

   if(len<0)
     return;

   /* pre-process the packets */
   preProcessPacket (data, &len, direction, &state);

#ifdef DEBUG
   debug ("dispatchZoneData()");
#endif /* DEBUG */
   unsigned int
     opCode = data[1] | (data[0] << 8);

   if (logZoneData)
     logData ("zone.log", len, data);

   int
     unk = 1;
   switch (opCode)
   {
    case ItemInShopCode:
      if (ItemInShopVer != opCodeVersion)
	break;
      unk = 0;
      //if (data[6] == 0x00)
	{
	  struct itemShopStruct *
	    items;
	  items = (struct itemShopStruct *) (data);
	  tempStr.sprintf ("Item Shop: %s(%i), %ldcp\n", items->item.lore, 
                         items->item.itemNr, items->item.cost);
          emit
             msgReceived(tempStr);
	  itemdb (&items->item);
	}
      break;
    case ItemOnCorpseCode:
      if (ItemOnCorpseVer != opCodeVersion)
	break;
      unk = 0;
      struct itemReceivedPlayerStruct *
	itemc;
      itemc = (struct itemReceivedPlayerStruct *) (data);
      tempStr.sprintf ("Item Looted: %s(%i), %ldcp", itemc->item.lore, itemc->item.itemNr, itemc->item.cost);
      emit
         msgReceived(tempStr);
      itemdb (&itemc->item);
      break;
    case tradeItemCode:
      if (tradeItemVer != opCodeVersion)
	break;
      unk = 0;
      struct tradeItemStruct *
	itemt;
      itemt = (struct tradeItemStruct *) (data);
      tempStr.sprintf("TradeI: %s(%i), %ldcp", 
            itemt->item.lore, itemt->item.itemNr, itemt->item.cost);
      emit
        msgReceived(tempStr);
      itemdb (&itemt->item);
      break;
    case ItemTradeCode:	// Item received by player
      if (ItemTradeVer != opCodeVersion)
	break;
      unk = 0;
      struct itemReceivedPlayerStruct *
	itemr;
      itemr = (struct itemReceivedPlayerStruct *) (data);
      tempStr.sprintf("ITrade: %s(%i), %ldcp", 
          itemr->item.lore, itemr->item.itemNr, itemr->item.cost);
      emit
        msgReceived(tempStr);
      itemdb (&itemr->item);
      break;
    case PlayerItemCode:
      if (PlayerItemVer != opCodeVersion)
	break;
      unk = 0;
      struct itemPlayerStruct *
	itemp;
      itemp = (struct itemPlayerStruct *) (data);
      tempStr.sprintf("Item: %s(%i), %ldcp", itemp->item.lore, 
                    itemp->item.itemNr, itemp->item.cost);
      emit
         msgReceived(tempStr);
      itemdb (&itemp->item);
      break;
    case summonedItemCode:
      if (summonedItemVer != opCodeVersion)
	break;
      unk = 0;
      struct summonedItemStruct *
	itemsum;
      itemsum = (struct summonedItemStruct *) (data);
      tempStr.sprintf("ITEMSUM: %s(%i), %ldcp", itemsum->item.lore, 
                 itemsum->item.itemNr, itemsum->item.cost);
      emit
         msgReceived(tempStr);
      itemdb (&itemsum->item);
      break;

    case CharProfileCode:	// Character Profile server to client
      if (CharProfileVer != opCodeVersion)
	break;

      /* Entered new zone */
      currentZone = "";
      m_Spawns.clear();
      emit zoneChanged ();
      emit stsMessage(QString("Zoning..."));

      unk = 2;
      struct playerProfileStruct * player;
      player = (struct playerProfileStruct *) (data);
      playerLevel = player->level;
      playerRace = player->race;
      playerClass = player->class_;
      char messag[128];
      //sprintf (messag, "Exp: %ld", player->exp);
      totalExp = Commanate(player->exp);
      sprintf(messag, "Exp: %s", totalExp);
      free(totalExp);
      currentExp = player->exp;
      maxExp = calc_exp(playerLevel,playerRace,playerClass);
      emit expChangedStr (QString (messag));
      emit expChangedInt
		      (player->exp,
		      calc_exp(playerLevel-1,playerRace,playerClass),
		      calc_exp(playerLevel,playerRace,playerClass));
      for (int a = 0; a < 74; a++)
	emit addSkill (a, player->skills[a]);
      emit setPlayerLevel (player->level);
      emit setPlayerRace (player->race);
      emit setPlayerClass (player->class_);

//#if 0
// I think it would be cleaner to create a dummy spawn structure for the
// player and emit that rather than emit all things seperately....
// TODO
      // create a dummy spawn struct for ourselves to send to the other comps
      struct spawnStruct playerspawn;
      //playerspawn = (struct spawnStruct *) malloc(sizeof(struct spawnStruct));
      memset(&playerspawn, 0, sizeof(struct spawnStruct));
      strcpy(playerspawn.name, player->name);
      playerspawn.spawnId = 1;
      playerspawn.race = player->race;
      playerspawn.NPC = 10;
      playerspawn.class_ = player->class_;
      playerspawn.level = player->level;
      playerspawn.curHp = 1;
      playerspawn.maxHp = 1; 
      emit newSpawn (&playerspawn, 1);
//#endif
      break;

    case CorpseCode:
      if (CorpseVer != opCodeVersion)
	break;
      unk = 0;

      struct spawnKilledStruct *
	deadspawn;
      deadspawn = (struct spawnKilledStruct *) (data);
      //printf("setting new dead spawn, id %d\n", deadspawn->spawnId);
      if (m_Spawns.contains( deadspawn->spawnId ))
         m_lastDeadSpawn = m_Spawns[ deadspawn->spawnId ];
      printf("" );

      if (m_Spawns.contains( deadspawn->killerId )){
          int chk=0;
          for(int ng=0; ng < groupSize;ng++){
              if (deadspawn->killerId == groupID[ng]){
                  chk = 1;
                  break;
              }
          }
          if (chk == 1)
              printf("%s(%d) killed by %s(%d)\n", m_lastDeadSpawn.name, m_lastDeadSpawn.spawnId, m_Spawns[ deadspawn->killerId ].name, deadspawn->killerId);
      }
      else if (deadspawn->killerId == playerID){
          printf("%s(%d) killed by you(%i).\n", m_lastDeadSpawn.name, m_lastDeadSpawn.spawnId, deadspawn->killerId);
      }
      else{
           printf("%s(%d) killed by unknown.(%i)\n", m_lastDeadSpawn.name, m_lastDeadSpawn.spawnId, deadspawn->killerId);
      }
      emit
	killSpawn (deadspawn->spawnId);
      break;
    case DeleteSpawnCode:
      if (DeleteSpawnVer != opCodeVersion)
	break;
      unk = 0;
      struct deleteSpawnStruct *
	delspawn;
      delspawn = (struct deleteSpawnStruct *) (data);

      // Remove the spawn from our map
      m_Spawns.remove(delspawn->spawnId);

      emit deleteSpawn (delspawn->spawnId);
      break;
    case ChannelMessageCode:
      if (ChannelMessageVer != opCodeVersion)
	break;
      unk = 0;
      struct channelMessageStruct *
	cmsg;
      cmsg = (struct channelMessageStruct *) (data);

      if (viewChannelMsgs) {
        switch (cmsg->unknown1[11]) {
          case 0:
            tempStr.sprintf("Guild");
            break;
          case 2:
            tempStr.sprintf("Group");
            break;
          case 3:
            tempStr.sprintf("Shout");
            break;
          case 4:
            tempStr.sprintf("Auction");
            break;
          case 5:
            tempStr.sprintf("OOC");
            break;
          case 7:
            tempStr.sprintf("Tell");
            break;
          case 8:
            tempStr.sprintf("Say");
            break;
          default:
            tempStr.sprintf("Chan%02x", cmsg->unknown1[11]);
        }
        if (cmsg->unknown1[9])
        {
          tempStr.sprintf("%s: '%s' - %s {%s}", tempStr.ascii(), 
                 cmsg->sender, cmsg->message, language_name(cmsg->unknown1[9]));
        }
        else // don't show common, its obvious 
        {
          tempStr.sprintf("%s: '%s' - %s", tempStr.ascii(), 
                 cmsg->sender, cmsg->message);
        }
        emit
          msgReceived(tempStr);
      }

      break;
    case NewSpawnCode:
      if (NewSpawnVer != opCodeVersion)
	break;
      unk = 0;
      struct newSpawnStruct *spawn;
      struct dbSpawnStruct adbSpawn;
      spawn = (struct newSpawnStruct *) (data);
      m_Spawns.insert( spawn->spawn.spawnId, spawn->spawn );

      adbSpawn.spawn = spawn->spawn;

      currentZone = adbSpawn.zoneName;

      // Only process the spawn if we have a zone name
      if ( currentZone || showeq_params->showUnknownSpawns)
	{
	  processSpawn (&adbSpawn, key, 3);
	}

      if(!showeq_params->fast_machine)
	emit
	refreshMap ();
      break;
    case ZoneSpawnsCode:

      //printf ("ZONESPAWNS1: %d\n", len);
      if (ZoneSpawnsVer != opCodeVersion)
	break;
      unk = 0;
      struct zoneSpawnsStruct *zspawns;
      zspawns = (struct zoneSpawnsStruct *) (data);
      //printf ("ZONESPAWNS2: %d\n", len);
      //
      // Queue all theses spawns until we have
      // the zone name later
      for (int a = 0; a < (len - 2) / 152; a++)
      {
	 dbSpawnStruct *dbSpawn = new dbSpawnStruct;
	 dbSpawnList *dbList = new dbSpawnList;
	 dbSpawn->spawn = zspawns->spawn[a];
	 dbList->next=m_ZoneSpawns;
	 dbList->spawn=dbSpawn;
	 m_ZoneSpawns=dbList;
         //printf("wahaha: %s\n", zspawns->spawn[a].name);
	 processSpawn (dbSpawn, key, 2);
	 // Decode the data and put this spawn in a temp hash table
	 // so we can look up pet owners when the whole zone is loaded
	 m_Spawns.insert(zspawns->spawn[a].spawnId, zspawns->spawn[a]);
      }
      if(!showeq_params->fast_machine)
	emit
	refreshMap ();
      break;
    case TimeOfDayCode:
      if (TimeOfDayVer != opCodeVersion)
	break;
      unk = 0;
      struct timeOfDayStruct *
	tday;
      tday = (struct timeOfDayStruct *) (data);
      printf("TIME: %05i %05i %05i", tday->time0, tday->time1, tday->time2);
      break;
    case BookTextCode:
      if (BookTextVer != opCodeVersion)
	break;
      unk = 0;
      struct bookTextStruct *
	booktext;
      booktext = (struct bookTextStruct *) (data);
      // printf ("BOOK: %s\n", booktext->text);
      break;
    case RandomCode:
      if (direction != DIR_CLIENT)
        break;
      if (RandomVer != opCodeVersion)
        break;
      unk = 0;
      struct randomStruct *
        randr;
      randr = (struct randomStruct *) (data);
      printf ("RANDOM: Request random number between %d and %d\n",
        randr->bottom, randr->top);
      break;
    case emoteTextCode:
      if (emoteTextVer != opCodeVersion)
	break;
      unk = 0;
      struct emoteTextStruct *
	emotetext;
      emotetext = (struct emoteTextStruct *) (data);
      if (viewChannelMsgs)
      {
        tempStr.sprintf("Emote: %s", emotetext->text);
        emit
          msgReceived(tempStr);
      }
      break;
    case PlayerBookCode:
      if (PlayerBookVer != opCodeVersion)
	break;
      unk = 0;

      struct itemStruct itdbh;
      struct bookPlayerStruct *
	bookp;
      bookp = (struct bookPlayerStruct *) (data);

      memset(&itdbh,0, sizeof(itemStruct));
      memcpy(&itdbh,data + 2, sizeof(bookPlayerStruct));

	itemdb(&itdbh);
      tempStr.sprintf("Item: Book: %s, *%s, %s, %ldcp", bookp->name,bookp->lore,
	      bookp->file, bookp->cost);
      emit
         msgReceived(tempStr);
      break;

    case PlayerContainerCode:
      if (PlayerContainerVer != opCodeVersion)
	break;
      unk = 0;
      struct itemStruct itdbhold;
      struct containerPlayerStruct *
	containp;
      memset(&itdbhold,0, sizeof(itemStruct));
      memcpy(&itdbhold,data + 2, sizeof(containerPlayerStruct));
      containp = (struct containerPlayerStruct *) (data);

      //printf("is: %i, ic: %i\n", sizeof(itemStruct), sizeof(containerPlayerStruct));

      tempStr.sprintf("Item(PlrCnt): %s(%i), %ldcp", itdbhold.lore, 
                    itdbhold.itemNr, itdbhold.cost);
	itemdb(&itdbhold);
      emit
         msgReceived(tempStr);
      tempStr.sprintf("Container: %s, *%s, %d slots, %ldcp", containp->name,
	      containp->lore, containp->numSlots, containp->cost);
      emit
         msgReceived(tempStr);
      break;
    case InspectDataCode:
      if (InspectDataVer != opCodeVersion)
	break;
      unk = 0;
     //  printf ("INSPECT: %d\n", len);
      struct inspectingStruct *
	inspt;
      inspt = (struct inspectingStruct *) (data);
      for (int inp = 0; inp < 21;inp++){
          printf("He has %s (icn:%i)\n", inspt->itemNames[inp], inspt->icons[inp]);
      }
      printf("His info: %s\n", inspt->mytext);

      break;
    case HPUpdateCode:
      if (HPUpdateVer != opCodeVersion)
	break;
      unk = 0;
      struct spawnHpUpdateStruct *
	hpupdate;
      hpupdate = (struct spawnHpUpdateStruct *) (data);
      emit
	updateSpawnHp (hpupdate->spawnId, hpupdate->curHp, hpupdate->maxHp);
      //printf ("HPUPDATE: %x - %d of %d\n",hpupdate->spawnId,hpupdate->curHp,hpupdate->maxHp);
      //printf ("HPUPDATE2: %x - %d of %d or %d\n",hpupdate->spawnId,hpupdate->unknown0,hpupdate->unknown1, hpupdate->unknown2);
      break;
    case GainXPCode:
//{
//      struct spMesgStruct * spmsg1 = (struct spMesgStruct *) data;
//printf("Special (%d): '%s' (%ld)\n", opCodeVersion, spmsg1->message, spmsg1->msgType);
//}
      if (GainXPVer != opCodeVersion)
	break;
      unk = 0;
      struct spMesgStruct *
	spmsg;
      spmsg = (struct spMesgStruct *) (data);

      // seems to be lots of blanks
      if (!spmsg->message[0])
         break;

      // this seems to be several type of message...
      switch(spmsg->msgType)
      {
         case 13:
           if (!strncmp(spmsg->message, "Your target is too far away", 20)) 
              tempStr.sprintf("Attack: %s", spmsg->message);
           if (!strncmp(spmsg->message, "You can't see your target", 18)) 
              tempStr.sprintf("Attack: %s", spmsg->message);
           else if (!strncmp(spmsg->message, "Your target resisted", 18)) 
              tempStr.sprintf("Spell: %s", spmsg->message);
           else 
              tempStr.sprintf("Special: %s (%ld)", spmsg->message, 
                      spmsg->msgType);
           break;
         case 15:
           tempStr.sprintf("Exp: %s", spmsg->message);
           break;
         default:
           tempStr.sprintf("Special: %s (%ld)", spmsg->message, spmsg->msgType);
           break;
      }
      emit
         msgReceived(tempStr);
      break;
    case BeginCastCode:
      if (BeginCastVer != opCodeVersion)
	break;
      unk = 0;
      struct beginCastStruct *
	bcast;
      bcast = (struct beginCastStruct *) (data);
      switch (bcast->param2) {
        case 0:
          tempStr.sprintf("Scribe");
          break;
        case 1:
          tempStr.sprintf("Memorize");
          break;
        case 2:
          tempStr.sprintf("Forget");
          break;
        case 3:
          tempStr.sprintf("Cast");
          break;
        default:
          tempStr.sprintf("Unknown");
      }
      tempStr.sprintf("Cast: %s (%x) - %d,%d,%d ",
              spell_name (bcast->spellId),
	      bcast->spellId, bcast->param1, bcast->param2, bcast->param3);
      emit
         msgReceived(tempStr);
      break;
    case MemSpellCode:
      if (MemSpellVer != opCodeVersion)
	break;
      unk = 0;
      struct memorizeSlotStruct *
	mem;
      mem = (struct memorizeSlotStruct *) (data);
      // printf ("MEM: [%d] - %s\n", mem->slot,spell_name(mem->spellId));
      break;
    case MobUpdateCode:
      if (MobUpdateVer != opCodeVersion)
	break;
      unk = 0;
      struct spawnPositionUpdateStruct *
	updates;
      updates = (struct spawnPositionUpdateStruct *) (data);
      for (int a = 0; a < updates->numUpdates; a++)
      {
	 emit
	   updateSpawn (updates->spawnUpdate[a].spawnId,
			updates->spawnUpdate[a].xPos,
			updates->spawnUpdate[a].yPos,
			updates->spawnUpdate[a].zPos,
			updates->spawnUpdate[a].deltaX,
			updates->spawnUpdate[a].deltaY,
			updates->spawnUpdate[a].deltaZ);
      }
      if(!showeq_params->fast_machine)
	emit
	refreshMap ();
      break;
    case ExpUpdateCode:
      if (ExpUpdateVer != opCodeVersion)
	break;
      unk = 0;
      // Exp update
      struct expUpdateStruct *
	exp;
      exp = (struct expUpdateStruct *) (data);

      totalExp = Commanate(exp->exp);
      gainedExp = Commanate((UDWORD) (exp->exp - currentExp));
      needKills = Commanate(((calc_exp(playerLevel,playerRace,playerClass) -
          exp->exp) / (exp->exp > currentExp ? exp->exp - currentExp : 1)) + 1);
      leftExp = Commanate(((calc_exp(playerLevel,playerRace,playerClass))-
		(calc_exp(playerLevel-1,playerRace,playerClass)))-
	        (exp->exp - (calc_exp(playerLevel-1,playerRace,playerClass))));

      tempStr.sprintf("Exp: %s (%s) [%s]", totalExp, gainedExp, needKills);
      emit expChangedStr (tempStr);

      tempStr.sprintf("Exp: %s (%s)(%s) left %s", totalExp, gainedExp, needKills, leftExp);
      emit msgReceived(tempStr);

      free(totalExp);
      free(gainedExp);
      free(needKills);
      free(leftExp);

      emit expGained( m_lastDeadSpawn.name, m_lastDeadSpawn.level,
         exp->exp - currentExp, currentZone );

      emit
	stsMessage(tempStr);
      emit expChangedInt
		      (exp->exp,
		      calc_exp(playerLevel-1,playerRace,playerClass),
		      calc_exp(playerLevel,playerRace,playerClass));

      currentExp = exp->exp;
      break;
    case LevelUpUpdateCode:
      if (LevelUpUpdateVer != opCodeVersion)
	break;
      unk = 0;

      // exp update
      struct levelUpStruct *
	levelup;
      levelup = (struct levelUpStruct *) (data);
      char
	msg[128];
      //sprintf (msg, "Exp: %ld (%d)", levelup->exp, levelup->exp - currentExp);
      totalExp = Commanate(levelup->exp);
      gainedExp = Commanate((UDWORD) (levelup->exp - currentExp));
      needKills = Commanate(((calc_exp(levelup->level,playerRace,playerClass) -
levelup->exp) / (levelup->exp > currentExp ? levelup->exp - currentExp : 1)));
      tempStr.sprintf ("Exp: %s (%s)(%s)", totalExp, gainedExp, needKills);
      free(totalExp);
      free(gainedExp);
      free(needKills);

      emit expChangedStr (tempStr);
      playerLevel=levelup->level;
      maxExp = calc_exp(playerLevel,playerRace,playerClass);
      emit expChangedInt
		      (levelup->exp,
		      calc_exp(playerLevel-1,playerRace,playerClass),
		      calc_exp(playerLevel,playerRace,playerClass));
      emit
	setPlayerLevel (levelup->level);

      currentExp = levelup->exp;
      break;
    case SkillIncCode:
      if (SkillIncVer != opCodeVersion)
	break;
      unk = 0;

      struct skillIncreaseStruct *
	skilli;
      skilli = (struct skillIncreaseStruct *) (data);
      emit
	changeSkill (skilli->skillId, skilli->value);
      tempStr.sprintf("Skill: %s has increased (%d)", 
                skill_name(skilli->skillId), skilli->value);
      emit
         msgReceived(tempStr);
      emit
         stsMessage(tempStr);
      break;
    case DoorSpawnCode:
      if (DoorSpawnVer != opCodeVersion)
	break;
      unk = 0;
      struct newDoorStruct *
	door;
      door = (struct newDoorStruct *) (data);
      // printf ("DOOR: %s\n", door->name);
      break;
    case DoorOpenCode:
      if (DoorOpenVer != opCodeVersion)
	break;
      unk = 0;
      break;
    case IllusionCode:
      if (IllusionVer != opCodeVersion)
	break;
      unk = 0;
      break;
    case BadCastCode:
      if (BadCastVer != opCodeVersion)
	break;
      unk = 0;

      struct interruptCastStruct *
	icast;
      icast = (struct interruptCastStruct *) (data);
      break;
    case SysMsgCode:
      if (SysMsgVer != opCodeVersion)
	break;
      unk = 0;
      struct systemMessageStruct *
	smsg;

      smsg = (struct systemMessageStruct *) (data);

      // seems to be lots of blanks
      if (!smsg->message[0])
         break;

      // this seems to be several type of message...
      if (!strncmp(smsg->message, "Your faction", 12))
        tempStr.sprintf("Faction: %s", smsg->message);
      else
        tempStr.sprintf("System: %s", smsg->message);
      emit
         msgReceived(tempStr);
      break;
    case NewZoneCode:
      if (NewZoneVer != opCodeVersion)
	break;
      unk = 0;
      struct newZoneStruct *
	nzone;
      nzone = (struct newZoneStruct *) (data);
      dbSpawnStruct *
	dbSpawn;

      if (m_pVPacket)
        printf("New Zone at byte: %d\n", m_pVPacket->FilePos());

      currentZone = nzone->longName;

      // Now dequeue all our spawns adding the name
      // of the zone to each one, then processing it.
      while (m_ZoneSpawns)
      {
	 dbSpawn = m_ZoneSpawns->spawn;
	 strcpy (dbSpawn->zoneName, currentZone);
	 processSpawn (dbSpawn, key, 1);
	 m_ZoneSpawns=m_ZoneSpawns->next;
      }

      emit
	newZone (nzone->longName, nzone->shortName);
      break;
    case PlayerPosCode:
      if (PlayerPosVer != opCodeVersion)
	break;
      unk = 0;
      //printf("PlayerPosCode!\n");
      if (direction == DIR_CLIENT)//important, get false other player updates otherwise.
      {
	 char
	   buff[20];
	 struct playerUpdateStruct *
	   pupdate;
	 pupdate = (struct playerUpdateStruct *) (data);
	 emit
	   headingChanged (360 - (pupdate->heading * 360) / 256);

	 sprintf (buff, "%d", pupdate->xPos);
	 emit
	   xposChanged (QString (buff));
	 sprintf (buff, "%d", pupdate->yPos);
	 emit
	   yposChanged (QString (buff));
	 sprintf (buff, "%d", pupdate->zPos);
	 emit
	   zposChanged (QString (buff));

	 emit
	   setPlayerID (pupdate->spawnId);
         playerID = pupdate->spawnId;

	 emit
	   posChanged (pupdate->xPos, pupdate->yPos, pupdate->zPos);
	 emit
	   playerChanged (pupdate->xPos, pupdate->yPos,  pupdate->zPos,
			  pupdate->deltaX, pupdate->deltaY,  pupdate->deltaZ,
			  360 - (pupdate->heading * 360) / 256);

	 emit updateSpawn (pupdate->spawnId,
			pupdate->xPos,
			pupdate->yPos,
			pupdate->zPos,
			pupdate->deltaX,
			pupdate->deltaY,
			pupdate->deltaZ);

      }
      else if (direction != DIR_CLIENT)
      {
	 char
	   buff[20];
	 struct playerUpdateStruct *
	   pupdate;
	 pupdate = (struct playerUpdateStruct *) (data);
//         printf("PlayerPosCode! (%i)\n", pupdate->spawnId);
	 emit updateSpawn (pupdate->spawnId,
			pupdate->xPos,
			pupdate->yPos,
			pupdate->zPos,
			pupdate->deltaX,
			pupdate->deltaY,
			pupdate->deltaZ);

      }
      break;
    case WearChangeCode:
      if (WearChangeVer != opCodeVersion)
	break;
      unk = 0;
      struct wearChangeStruct *
	wearing;
      wearing = (struct wearChangeStruct *) (data);
      emit
	spawnWearingUpdate (wearing);
      break;
    case GoodCastCode:
      if (GoodCastVer != opCodeVersion)
	break;
      unk = 0;
      break;
    case castOnCode:
      if (castOnVer != opCodeVersion)
	break;
      unk = 0;
      //      struct castOnStruct *
      //      	caston;
      //      caston = (struct castOnStruct *) (data);
      break;
    case manaDecrementCode:
      if (manaDecrementVer != opCodeVersion)
	break;
      unk = 0;
      struct manaDecrementStruct *
	mana;
      mana = (struct manaDecrementStruct *) (data);
      emit
	manaChanged(mana->newMana,0);  // need max mana
      break;

    case staminaCode:
      if(staminaVer != opCodeVersion)
	break;
      unk=0;
      struct staminaStruct *stam;
      stam= (struct staminaStruct *)data;
      emit
	stamChanged(100-(stam->fatigue),100, stam->food, 127, stam->water, 127);
      break;
    case MakeDropCode:
      if (MakeDropVer != opCodeVersion)
	break;
      unk = 0;
      if (!showeq_params->dropItemShow)
        break;
      struct dropThingOnGround * adrop;
      adrop = (struct dropThingOnGround *) (data);
      emit newGroundItem (adrop);
      break;
    case RemDropCode:
      if (RemDropVer != opCodeVersion)
	break;
      unk = 0;
      struct removeThingOnGround * rdrop;
      rdrop = (struct removeThingOnGround *) (data);
      emit removeGroundItem (rdrop);
      break;
    case dropCoinsCode:
      if (dropCoinsVer != opCodeVersion)
	break;
      unk = 0;
      if (!showeq_params->dropItemShow)
        break;
      struct  dropCoinsStruct* cdrop;
      cdrop = (struct  dropCoinsStruct*) (data);
      emit newCoinsItem (cdrop);
      break;
    case removeCoinsCode:
      if (removeCoinsVer != opCodeVersion)
	break;
      unk = 0;
      struct  removeCoinsStruct * crdrop;
      crdrop = (struct removeCoinsStruct *) (data);
      emit removeCoinsItem (crdrop);
      break;
   case openVendorCode:
      if (openVendorVer != opCodeVersion)
	break;
      unk = 0;
      break;
   case closeVendorCode:
      if (closeVendorVer != opCodeVersion)
	break;
      unk = 0;
      break;
   case openGMCode:
      if (openGMVer != opCodeVersion)
	break;
      unk = 0;
      break;
   case closeGMCode:
      if (closeGMVer != opCodeVersion)
	break;
      unk = 0;
      break;
    case attack1Code:
      //printf("hi1\n");
      if (attack1Ver != opCodeVersion)
	break;
      unk = 0;
      struct  attack1Struct * atk1;
      atk1 = (struct attack1Struct *) (data);
      //printf("hi2\n");
      emit attack1Hand1 (atk1);
      break;
    case attack2Code:
      if (attack2Ver != opCodeVersion)
	break;
      unk = 0;
      struct  attack2Struct * atk2;
      atk2 = (struct attack2Struct *) (data);
      emit attack2Hand1 (atk2);
      break;

   case considerCode:
     if(considerVer != opCodeVersion)
	break;
      unk = 0;
      struct considerStruct *con;
      con = (struct considerStruct *) data;
      emit consMessage (con);
      break;

   case newGuildInZoneCode:
     if(newGuildInZoneVer != opCodeVersion)
	break;
      unk = 0;
      break;

   case moneyUpdateCode:
     if(moneyUpdateVer != opCodeVersion)
	break;
      unk = 0;
      tempStr.sprintf("Money: ");
      emit
        msgReceived(tempStr);
      break;

   case moneyThingCode:
     if(moneyThingVer != opCodeVersion)
	break;
      unk = 0;
      tempStr.sprintf("Money: ");
      emit
        msgReceived(tempStr);
      break;


   case bindWoundCode:
     if(bindWoundVer != opCodeVersion)
	break;
      unk = 0;
      break;

    case groupinfoCode:
      if (groupinfoVer != opCodeVersion)
	break;
      unk = 0;//too much still unknown.
      struct groupMemberStruct *gmem;
      gmem = (struct groupMemberStruct *) (data);
      printf ("Member: %s - %s (%i)\n", gmem->yourname, gmem->membername, gmem->ARC);
      int ARC=1; //This will look for him in the current group.
          //If he is there, then we are done looking.  And we remove him.
          //If not, then we add him.
          for(int rmhim = 0 ; rmhim < groupSize; rmhim++){
              if (stricmp(groupNames[rmhim], gmem->membername) == 0){
              ARC = 2;
              break;
              }
          }

      if (stricmp(gmem->membername,"") == 0){
          printf("pkt: clearing out group.\n");
          for (int ngp=0;ngp<groupSize;ngp++){
              groupID[ngp] = 0;
          }
          groupSize = 0;
          emit clrGroup();
      }
      else if (ARC == 1) {
          //lets find this guy's id.
          strcpy(groupNames[groupSize], gmem->membername);
          groupID[groupSize] = 0;
          QMap<unsigned int, spawnStruct>::Iterator sit;
          for(sit = m_Spawns.begin(); sit != m_Spawns.end(); sit++){
              if (stricmp(gmem->membername,sit.data().name) == 0){ 
                  //printf("pkt: we think we found him: %i\n", sit.data().spawnId);
                  groupID[groupSize] = sit.data().spawnId;
                  break;
              }
          }
          emit addGroup(groupNames[groupSize], groupID[groupSize]);
          if (++groupSize>5)
              groupSize = 5;

      }
      else if (ARC == 2) {
          int hl;
          for(int rmhim = 0 ; rmhim < groupSize; rmhim++){
              if (stricmp(groupNames[rmhim], gmem->membername) == 0){
                  hl = groupSize - 1;
                  if (hl<0) hl = 0;
                  emit remGroup(groupNames[rmhim], groupID[rmhim]);
                  groupID[rmhim] = groupID[hl];
                  strcpy(groupNames[rmhim], groupNames[hl]);
                  groupSize--;
              }
          }
      }
      else{
          printf("member odd ARC number: %i\n", gmem->ARC);
      }
      printf("Group Members are (%i):\n", groupSize);
      for(int rmhim = 0 ; rmhim < groupSize; rmhim++){
          printf("Mem#%i: %s(%i)\n", rmhim, groupNames[rmhim], groupID[rmhim]);
      }
      printf("</Members>\n");
      break;

   }

   if (logUnknownData && unk)
   {
      printf ("%04x - %d\n", opCode, len);
      logData ("unknownzone.log", len, data);
    }

  if (viewUnknownData && unk)
    {
      if(len == 2)
        printf ("\nUNKNOWN: %02x version %02x len 2\n\t", data[0], data[1]);
      else {
      printf ("\nUNKNOWN: %02x version %02x len %02d [%d] ID:%i\n\t", data[0],
	      data[1], len, direction, data[3]*256+data[2]);

      unsigned char *
	decodetry = data + 2;
      unsigned short
	combshort;
      int
	combint;
      float * combfloat;

      for (int a = 0; a < len; a++)
	{
	  printf ("(%i[ b:%02x ", a, data[a]);
	  if (a < len - 1)
	    {
	      combshort = data[a] | (data[a + 1] << 8);
              //combfloat = (float*)data + a;
	      printf ("i:%i", combshort);
	    }
	  printf ("]) ");
	}
      printf ("\n");
      for (int a = 0; a < len; a++)
      {
	 if ((data[a] >= 32) && (data[a] <= 126))
	   printf ("%c", data[a]);
	 else
	   printf (".");
      }
      printf ("\n");
      for (int a = 0; a < len; a++)
      {
	 if (data[a] < 32)
	   printf ("%c", data[a] + 95);
	 else if (data[a] > 126)
	   printf ("%c", data[a] - 95);
	 else if (data[a] > 221)
	   printf ("%c", data[a] - 190);
	 else
	   printf ("%c", data[a]);
      }
      printf ("\n");
      }
   }
}

/* Combines data from split packets */
void
  EQPacket::dispatchZoneSplitData (int len, unsigned char *data)
{
#ifdef DEBUG
   debug ("dispatchZoneSplitData()");
#endif /* DEBUG */
   if ((data[0] == 0x3a)||(data[0] == 0x1a))
   {
      /* Clear data */
      serverDataSize = 0;
   }

  /* Add data */
   for (int a = 0; a < (len - 16); a++)
   {
      serverData[serverDataSize] = data[a + 12];
      serverDataSize++;
   }

  /* Check if this is last part of data */
   if (data[9] == (data[11] - 1))
   {
      dispatchZoneData (serverDataSize - 2, serverData + 2);
   }

}

void EQPacket::initSpawnLists2 (void)
{
#ifdef DEBUG
   debug ("initSpawnLists2()");
#endif /* DEBUG */
   printf("Re-initialize spawns list.\n");
   initSpawnLists();
}

//loads in the spawn list into a big string
int
  EQPacket::initSpawnLists (void)
{
#ifdef DEBUG
   debug ("initSpawnLists()");
#endif /* DEBUG */
   FILE *
     in;
   char
     msg[5001];
   char *
     p;
   struct spawnFilter_Regexp *
     re;

   while (filterList)
   {
      re = filterList->next;
      free(filterList);
      filterList = re;
   }
   while (spawnList)
   {
      re = spawnList->next;
      free(spawnList);
      spawnList = re;
   }

   filterList = spawnList = NULL;

   // Parse spawnfilter file
   printf("filter file name: %s\n",showeq_params->spawnfilter_filterfile);

   if (showeq_params->spawnfilter_filterfile)
   {
      in = fopen (showeq_params->spawnfilter_filterfile, "r");
      if (in == 0)
      {
          fprintf (stderr, "Couldn't open filter file. '%s'\n",
                    showeq_params->spawnfilter_filterfile);
      }
      else
      {
	 while (fgets (msg, 5000, in) != NULL)
	 {
	    p = index (msg, '\n');
	    if (p)
	      *p = 0;
	    p = index (msg, '\r');
	    if (p)
	      *p = 0;
	    if (msg[0])
	    {
	       re = (struct spawnFilter_Regexp *)
		 malloc (sizeof (struct spawnFilter_Regexp));
	       re->next = filterList;
	       filterList = re;
	       re->regexp =
		 new QRegExp ((const char *) msg,
			      showeq_params->spawnfilter_case,
			      showeq_params->spawnfilter_regexp ?
			      FALSE : TRUE);
	    }
	 }
	 printf ("Filter file initialized\n");
	 fclose (in);
      }
   }

   // Parse spawnalert file
   printf("spawn alert file: %s\n", showeq_params->spawnfilter_spawnfile);
   if (showeq_params->spawnfilter_spawnfile)
   {
      in = fopen (showeq_params->spawnfilter_spawnfile, "r");
      if (in == 0)
      {
	 fprintf (stderr, "Couldn't open spawn file: '%s'.\n",
		showeq_params->spawnfilter_spawnfile);
      }
      else
      {
	 while (fgets (msg, 5000, in) != NULL)
	 {
	    p = index (msg, '\n');
	    if (p)
	      *p = 0;
	    p = index (msg, '\r');
	    if (p)
	      *p = 0;
	    if (msg[0])
	    {
		re = (struct spawnFilter_Regexp *)
		 malloc (sizeof( struct spawnFilter_Regexp));
		re->next = spawnList;
		spawnList = re;
		re-> regexp =
			new QRegExp (msg,showeq_params->spawnfilter_case,
		        showeq_params->spawnfilter_regexp ? FALSE:TRUE);
	    }
	  }
	  printf ("Spawn file initialized\n");
	  fclose(in);
	}
     }
   return (1);
}

int
  EQPacket::spawnFilter (char *oname)
{
   struct spawnFilter_Regexp *
     re;
#ifdef DEBUG
   debug ("spawnFilter()");
#endif /* DEBUG */

   re = filterList;
   while (re)
   {
      if (re->regexp->match (oname) != -1)
      {
//	printf ("filtered***%s***\n", oname);
	 return 1;
      }
      re = re->next;
   }
   return 0;
}

int
  EQPacket::spawnAlert (char *oname)
{
   struct spawnFilter_Regexp *
     re;
#ifdef DEBUG
   debug ("spawnAlert()");
#endif /* DEBUG */

   re = spawnList;

   while (re)
   {
      if (re->regexp->match (oname) != -1)
      {
	 printf ("SPAWN!!!***%s***\n", oname);

	 // Gereric system beep for those without a soundcard
	 //
	 if (!showeq_params->spawnfilter_audio)
	 {
	    fprintf(stderr,"\a");
	 }
	 else
	 {
	    //plays a wav file
	    system ("/usr/bin/esdplay spawn.wav &");
	 }
	 return 1;
      }
      re = re->next;
   }
   return 0;
}

void
  EQPacket::deSpawnAlert (char *oname)
{
   struct spawnFilter_Regexp *
     re;
#ifdef DEBUG
   debug ("deSpawnAlert()");
#endif /* DEBUG */

   re = spawnList;

   while (re)
   {
      if (re->regexp->match (oname) != -1)
      {
	 printf ("DESPAWN!!!***%s***\n", oname);

	 // Gereric system beep for those without a soundcard
	 //
	 if (!showeq_params->spawnfilter_audio)
	 {
	    fprintf(stderr,"\a");
	 }
	 else
	 {
	    //plays a wav file
	    system ("/usr/bin/esdplay spawn.wav");
	 }
	 return;// 1;
      }
      re = re->next;
    }
  return;// 0;
}


void
EQPacket::setLogAllPackets (bool flag)
{
  logAllPackets = flag;
}

void
EQPacket::setLogZoneData (bool flag)
{
  logZoneData = flag;
}

void
EQPacket::setLogUnknownData (bool flag)
{
   logUnknownData = flag;
}

void
EQPacket::setViewChannelMsgs (bool flag)
{
  viewChannelMsgs = flag;
}

void
EQPacket::setViewUnknownData (bool flag)
{
  viewUnknownData = flag;
}

void
EQPacket::incPlayback(void)
{
  if (m_pVPacket)
  {
    int x = m_pVPacket->playbackSpeed();
    switch(x)
    { 
       // if we were paused go to 1X not full speed
       case -1:
         x = 1;
         break;

       // can't go faster than full speed
       case 0:
         return;
         break;

       case 9:
         x = 0;
         break;

       default:
         x += 1;
         break;
    }
    emit numPacket(0);  // this resets the packet average
    m_pVPacket->setPlaybackSpeed(x);

    QString string("");
    if (x > 0)
      string.sprintf("Playback speed set to %d", x); 
    else
      string.sprintf("Playback speed set Fast as possible", x); 
    emit stsMessage(string, 5000);
  }
}

void
EQPacket::decPlayback(void)
{
  if (m_pVPacket)
  {
    int x = m_pVPacket->playbackSpeed();
    switch(x)
    {
       // paused
       case -1:
         return;
         break;

       // slower than 1 is paused
       case 1:
         x = -1;
         break;
 
       // if we were full speed goto 9
       case 0:
         x = 9;
         break;

       default:
         x -= 1;
         break;
    }
    emit numPacket(0);  // this resets the packet average
    m_pVPacket->setPlaybackSpeed(x);

    QString string("");
    if (x == 0) 
      string.sprintf("Playback speed set Fast as possible", x); 
    else if (x < 0)
      string.sprintf("Playback paused (']' to resume)", x); 
    else
      string.sprintf("Playback speed set to %d", x); 
    emit stsMessage(string, 5000);
  }
}

void
EQPacket::Resync(void) {
  userResync = 1;
}
