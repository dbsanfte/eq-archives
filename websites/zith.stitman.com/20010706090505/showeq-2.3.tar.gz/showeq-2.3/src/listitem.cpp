#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "util.h"

int main (int argc, char *argv[])
{
  FILE *idb;
  struct itemStruct item; 
  int counter=0;
  char buff[100];

  printf ("Content-type: text/html\n\n");
  idb = fopen (LOGDIR "/item.db", "r");

  printf("<TABLE border=2 bordercolor=black cellspacing=0 cellpadding=2>\n");
  printf("<TR>");
  printf("<TD align=center><STRONG>Icon</STRONG></TD>");
  printf("<TD align=center><STRONG>Item #</STRONG></TD>");
  printf("<TD align=center><STRONG>Name</STRONG></TD>");
  printf("<TD align=center><STRONG>Lore</STRONG></TD>");
  printf("<TD align=center><STRONG>Weight</STRONG></TD>");
  printf("<TD align=center><STRONG>Size<STRONG></TD>");
  printf("<TD align=center><STRONG>Cost<STRONG></TD>");
  printf("<TD align=center><STRONG>Material<STRONG></TD>");
  printf("<TD align=center><STRONG>Flags<STRONG></TD>");
  printf("<TD align=center><STRONG>Slots<STRONG></TD>");
  printf("<TD align=center><STRONG>AC<STRONG></TD>");
  printf("<TD align=center><STRONG>Damage<STRONG></TD>");
  printf("<TD align=center><STRONG>Delay<STRONG></TD>");
  printf("<TD align=center><STRONG>Range<STRONG></TD>");
  printf("<TD align=center><STRONG>Skill<STRONG></TD>");
  printf("<TD align=center><STRONG>Bonuses<STRONG></TD>");
  printf("<TD align=center><STRONG>Resistances<STRONG></TD>");
  printf("<TD align=center><STRONG>Effect<STRONG></TD>");
  printf("</TR>\n");
   
  while (fread (&item, sizeof(itemStruct), 1, idb))
  {
    if (argc==2)
      if (!strstr(item.name,argv[1]))
        continue;
    printf("<TR>");
//    if (argc==3)
//      if (item.val3!=atoi(argv[2]))
//        continue;
//    if (argc==4)
//      if (item.val3<atoi(argv[3]))
//        continue;
     
    printf ("<TD><IMG SRC=\"/i/m%d.gif\"></TD>",item.iconNr);
    printf ("<TD><A HREF=\"showitem.cgi?%d\">%d</A></TD>", item.itemNr,item.itemNr); 
    printf ("<TD><A HREF=\"dispitem.cgi?%d\">%s</A></TD>", item.itemNr,item.name);
    if (strcmp(item.name,item.lore))
      printf ("<TD align=center>*</TD>");
    else
      printf("<TD>&nbsp</TD>");
    printf ("<TD align=right>%d</TD>", item.weight); 
    printf ("<TD align=right>%d</TD>", item.size);
    printf ("<TD align=right>%d</TD>", item.cost); 
    if (item.material)
      printf ("<TD align=center><FONT COLOR=\"#%06x\">%s</FONT>", item.color, print_material(item.material)); 
    else
      printf("<TD>&nbsp</TD>");
    
    sprintf(buff, "");
     
    // Flags
    printf("<TD>");
    if (item.nodrop==0)
      sprintf(buff,"NO-DROP ");
    if (item.nosave==0)
      sprintf(buff,"NO-SAVE ");
    if (item.magic==1)
      sprintf(buff,"MAGIC ");
    if (item.lore[0]=='*')
      sprintf(buff,"LORE");
    if (!strcmp(buff, ""))
      sprintf(buff,"&nbsp");
    printf("%s</TD>", buff);
     
    sprintf(buff, "");
    
    if (item.slots_)
      printf ("<TD align=center>%s</TD>", print_slot(item.slots_));
    else
      printf("<TD>&nbsp</TD>");
    if (item.AC)
      printf ("<TD>%d</TD>", item.AC);
    else
      printf("<TD>&nbsp</TD>");
    if (item.damage)
      printf ("<TD>%d</TD>", item.damage);
    else
      printf("<TD>&nbsp</TD>");
    if (item.delay)
      printf ("<TD>%d</TD>", item.delay);
    else
      printf("<TD>&nbsp</TD>");
    if (item.range)
      printf ("<TD>%d</TD>", item.range);
    else
      printf("<TD>&nbsp</TD>");
    if (item.damage)
      printf ("<TD>%s</TD>", print_skill(item.skill));
    else
      printf("<TD>&nbsp</TD>");
    
    // Bonuses
    printf("<TD>");
    if (item.STR)
      sprintf(buff, "Str:%d ", item.STR);
    if (item.AGI)
      sprintf(buff, "Agi:%d ", item.AGI);
    if (item.STA)
      sprintf(buff, "Sta:%d ", item.STA);
    if (item.DEX)
      sprintf(buff, "Dex:%d ", item.DEX);
    if (item.INT)
      sprintf(buff, "Int:%d ", item.INT);
    if (item.WIS)
      sprintf(buff, "Wis:%d ", item.WIS);
    if (item.CHA)
      sprintf(buff, "Cha:%d ", item.CHA);
    if (item.MANA)
      sprintf(buff, "Mana:%d ", item.MANA);
    if (item.HP)
      sprintf(buff, "HP:%d ", item.HP);
    if (item.light)
      sprintf(buff, "Light:%d ", item.light);
    if (!strcmp(buff, ""))
      sprintf(buff,"&nbsp");
    printf("%s</TD>", buff);
  
    sprintf(buff, "");
     
    // Resistances
    printf("<TD>");
    if (item.CR)
      sprintf(buff, "Cold:%d ", item.CR);
    if (item.FR)
      sprintf(buff, "Fire:%d ", item.FR);
    if (item.MR)
      sprintf(buff, "Magic:%d ", item.MR);
    if (item.DR)
      sprintf(buff, "Dis:%d ", item.DR);
    if (item.PR)
      sprintf(buff, "Poison:%d ", item.PR);
    if (!strcmp(buff, ""))
      sprintf(buff,"&nbsp");
    printf("%s</TD>", buff);
     
    sprintf(buff, "");
    
    if (item.spellId0!=0xffff)
      printf ("<TD>%s</TD>", spell_name(item.spellId0));
    else
      printf("<TD>&nbsp</TD>");
    printf ("</TR>\n");
    counter++;
  }
  fclose (idb);
  printf ("</TABLE>\n");
  printf ("%d matches found\n", counter);
}
