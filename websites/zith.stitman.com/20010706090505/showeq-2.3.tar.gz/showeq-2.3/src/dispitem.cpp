/*
 *  dispitem.cpp
 *  
 *  ShowEQ Distributed under GPL
 *  http://www.hackersquest.gomp.ch/
 */

/* CGI program to display details about a specific item - The ID of the item
 * is passed on the commandline
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "util.h"

int
main (int argc, char *argv[])
{
  FILE *idb;
  struct itemStruct item;
  int found = 0;

  /* Print HTML header */
  printf ("Content-type: text/html\n\n");

  /* Open the item database, hmm, no error checking here, must fix that
   * someday */
  idb = fopen (LOGDIR "/item.db", "r");
  /* Step through items in databse until we find the correct one */
  while (fread (&item, sizeof (itemStruct), 1, idb))
    {
      /* Compare itemid with id passed on commandline */
      if (item.itemNr == atoi (argv[1]))
	{
	  /* ID matches, print item details */
	  printf ("<IMG SRC=\"/i/%d.gif\">", item.iconNr);
	  printf ("<H1>%s</H1>\n", item.name);
	  printf ("<B>Lore:</B> %s<BR>\n", item.lore);
	  printf ("<B>Model:</B> %s<BR>\n", item.idfile);
	  printf ("<B>flag:</B> %x<BR>\n", item.flag);
	  printf ("<B>Weight:</B> %d<BR>\n", item.weight);
	  printf ("<B>Flags:</B> ");
	  if (item.nodrop == 0)
	    printf (" NO-DROP");
	  if (item.nosave == 0)
	    printf (" NO-SAVE");
	  if (item.magic == 1)
	    printf (" MAGIC");
	  if (item.lore[0] == '*')
	    printf (" LORE");
	  printf ("<BR>\n");
	  printf ("<B>Size:</B> %d<BR>\n", item.size);
	  printf ("<B>ItemID:</B> %d<BR>\n", item.itemNr);
	  printf ("<B>Icon#:</B> %d<BR>\n", item.iconNr);
	  printf ("<B>Current Slot:</B> %x<BR>\n", item.equipSlot);
	  printf ("<B>Slots:</B> %s<BR>\n", print_slot (item.slots_));
	  printf ("<B>Cost:</B> %dcp<BR>\n", item.cost);
	  if (item.STR)
	    printf ("<B>Str:</B> %d<BR>\n", item.STR);
	  if (item.STA)
	    printf ("<B>Sta:</B> %d<BR>\n", item.STA);
	  if (item.DEX)
	    printf ("<B>Dex:</B> %d<BR>\n", item.DEX);
	  if (item.INT)
	    printf ("<B>Int:</B> %d<BR>\n", item.INT);
	  if (item.AGI)
	    printf ("<B>Agi:</B> %d<BR>\n", item.AGI);
	  if (item.WIS)
	    printf ("<B>Wis:</B> %d<BR>\n", item.WIS);
	  if (item.MR)
	    printf ("<B>Magic:</B> %d<BR>\n", item.MR);
	  if (item.FR)
	    printf ("<B>Fire:</B> %d<BR>\n", item.FR);
	  if (item.CR)
	    printf ("<B>Cold:</B> %d<BR>\n", item.CR);
	  if (item.DR)
	    printf ("<B>Disease:</B> %d<BR>\n", item.DR);
	  if (item.PR)
	    printf ("<B>Poison:</B> %d<BR>\n", item.PR);
	  if (item.HP)
	    printf ("<B>HP:</B> %d<BR>\n", item.HP);
	  if (item.MANA)
	    printf ("<B>Mana:</B> %d<BR>\n", item.MANA);
	  if (item.AC)
	    printf ("<B>AC:</B> %d<BR>\n", item.AC);
	  if (item.light)
	    printf ("<B>Light:</B> %d<BR>\n", item.light);
	  if (item.delay)
	    printf ("<B>Delay:</B> %d<BR>\n", item.delay);
	  if (item.damage)
	    {
	      printf ("<B>Damage:</B> %d<BR>\n", item.damage);
	      printf ("<B>Skill:</B> %s<BR>\n", print_skill (item.skill));
	    }
	  if (item.range)
	    printf ("<B>Range:</B> %d<BR>\n", item.range);
	  printf ("<B>Material:</B> %x (%s)<BR>\n", item.material,
		  print_material (item.material));
	  printf
	    ("<B>Color:</B> %x <B><FONT COLOR=\"#%06x\">###SAMPLE###</FONT></B><BR>\n",
	     item.color, item.color);
	  if (item.spellId0 != 0xffff)
	    printf ("<B>Effect1:</B> %s<BR>\n", spell_name (item.spellId0));
	  printf ("<B>Class:</B> %s<BR>\n", print_class (item.classes));
	  printf ("<B>Race:</B> %s<BR>\n", print_race (item.races));
	  if (item.level)
	    printf ("<B>Casting Level:</B> %d<BR>\n", item.level);
	  if (item.number)
	    printf ("<B>Stack:</B> %d<BR>\n", item.number);
	  if (item.spellId != 0xffff)
	    printf ("<B>Effect2:</B> %s<BR>\n", spell_name (item.spellId));

	  found = 1;
	  break;
	}
    }
  /* Close the item db */
  fclose (idb);

  /* Didn't find a matching ID */
  if (!found)
    printf ("Item %d not found\n", atoi (argv[1]));
}
