/*
 * filter.h
 *
 * ShowEQ Distributed under GPL
 * http://www.hackersquest.gomp.ch/
 */

#ifndef FILTER_H
#define FILTER_H

#include <sys/types.h>
#include <regex.h>

class CRegExp;

class CRegExp
{
public:
  CRegExp(const char *, int cflags = 0);
  ~CRegExp(void); 

  CRegExp* m_pNext;
  regex_t* m_pRegexp; 
  char*  m_pName;
};

class Filter
{
public:
   Filter(const char *file = 0, int cFlags = 0);
   Filter(const char *file = 0, const char *type = 0, int cFlags = 0);
   ~Filter();

   int  loadFilters(void);
   int  saveFilters(void);
   int  isFiltered(const char *);
   void addFilter(const char *); 
   void remFilter(const char *); 
   void toggleFilter(const char *);
   void listFilters(void);

private:
   CRegExp* findFilter(const char*);

   char* m_sFile;
   int   m_nNumFilters;
   CRegExp* m_pList;
   CRegExp* m_pListEnd;
   char  m_cFlags;        // flags passed to regcomp
   char* m_sType;
};

#endif // FILTER_H
