/*
 * sortitem.cpp
 *
 * ShowEQ Distributed under GPL
 * http://www.hackersquest.gomp.ch/
 */

#include <stdlib.h>
#include <stdio.h>

#include "util.h"

unsigned short int largest = 0;

unsigned short int
find_smallest (unsigned short int cur)
{
  FILE *idb;
  struct itemStruct item;
  unsigned short int index = 0xffff;

  idb = fopen (LOGDIR "/item.db", "r");
  while (fread (&item, sizeof (itemStruct), 1, idb))
    {
      if ((item.itemNr > cur) && (item.itemNr < index))
	index = item.itemNr;
      if (item.itemNr > largest)
	largest = item.itemNr;
    }
  fclose (idb);

  return index;
}

void
write_item (unsigned short int index)
{
  FILE *idb, *odb;
  struct itemStruct item;

  idb = fopen (LOGDIR "/item.db", "r");
  odb = fopen (LOGDIR "/sorted.db", "a");
  while (fread (&item, sizeof (itemStruct), 1, idb))
    {
      if (item.itemNr == index)
	{
	  fwrite (&item, sizeof (itemStruct), 1, odb);
	  break;
	}
    }
  fclose (idb);
  fclose (odb);
}

int
main (int argc, char *argv[])
{

  unsigned short int index = 0;

  while ((index = find_smallest (index)) < 0xffff)
    {
      printf ("Sorting = %d\%\r", (index * 100) / largest);
      fflush (stdout);
      write_item (index);
    }
  printf ("\nDone\n");
}
