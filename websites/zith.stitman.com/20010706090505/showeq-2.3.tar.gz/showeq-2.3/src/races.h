/*
 * races.h
 *
 * ShowEQ Distributed under GPL
 * http://www.hackersquest.gomp.ch/
 */

case 1:
strcpy (race, "Human");
break;
case 2:
strcpy (race, "Barbarian");
break;
case 3:
strcpy (race, "Erudite");
break;
case 4:
strcpy (race, "Wood Elf");
break;
case 5:
strcpy (race, "High Elf");
break;
case 6:
strcpy (race, "Dark Elf");
break;
case 7:
strcpy (race, "Half-Elf");
break;
case 8:
strcpy (race, "Dwarf");
break;
case 9:
strcpy (race, "Troll");
break;
case 10:
strcpy (race, "Ogre");
break;
case 11:
strcpy (race, "Halfling");
break;
case 12:
strcpy (race, "Gnome");
break;
case 13:
strcpy (race, "Aviak");
break;
case 14:
strcpy (race, "Highpass Citizen");
break;
case 15:
strcpy (race, "Brownie");
break;
case 16:
strcpy (race, "Centaur");
break;
case 17:
strcpy (race, "Golem");
break;
case 18:
strcpy (race, "Giant/Cyclops");
break;
case 19:
strcpy (race, "Trakenon");
break;
case 20:
strcpy (race, "Venril Sathor");
break;
case 21:
strcpy (race, "Evil Eye");
break;
case 22:
strcpy (race, "Beetle");
break;
case 23:
strcpy (race, "Kerra");
break;
case 24:
strcpy (race, "Fish");
break;
case 25:
strcpy (race, "Fairy");
break;
case 26:
strcpy (race, "Froglok");
break;
case 27:
strcpy (race, "Froglok Ghoul");
break;
case 28:
strcpy (race, "Fungusman");
break;
case 29:
strcpy (race, "Gargoyle");
break;
case 30:
strcpy (race, "Gasbag");
break;
case 31:
strcpy (race, "Gel Cube");
break;
case 32:
strcpy (race, "Ghost");
break;
case 33:
strcpy (race, "Ghoul");
break;
case 34:
strcpy (race, "Bat, Giant");
break;
case 35:
strcpy (race, "Eel, Giant");
break;
case 36:
strcpy (race, "Rat, Giant");
break;
case 37:
strcpy (race, "Snake, Giant");
break;
case 38:
strcpy (race, "Spider, Giant");
break;
case 39:
strcpy (race, "Gnoll");
break;
case 40:
strcpy (race, "Goblin");
break;
case 41:
strcpy (race, "Gorilla");
break;
case 42:
strcpy (race, "Wolf");
break;
case 43:
strcpy (race, "Bear");
break;
case 44:
strcpy (race, "Guard, Freeport");
break;
case 45:
strcpy (race, "Demi Lich");
break;
case 46:
strcpy (race, "Imp");
break;
case 47:
strcpy (race, "Griffin");
break;
case 48:
strcpy (race, "Kobold");
break;
case 49:
strcpy (race, "Dragon, Lava");
break;
case 50:
strcpy (race, "Lion");
break;
case 51:
strcpy (race, "Lizard Man");
break;
case 52:
strcpy (race, "Mimic");
break;
case 53:
strcpy (race, "Minotaur");
break;
case 54:
strcpy (race, "Orc");
break;
case 55:
strcpy (race, "Beggar, Human");
break;
case 56:
strcpy (race, "Pixie");
break;
case 57:
strcpy (race, "Dracnid");
break;
case 58:
strcpy (race, "Solusek Ro");
break;
case 59:
strcpy (race, "Bloodgills");
break;
case 60:
strcpy (race, "Skeleton");
break;
case 61:
strcpy (race, "Shark");
break;
case 62:
strcpy (race, "Tunare");
break;
case 63:
strcpy (race, "Tiger");
break;
case 64:
strcpy (race, "Treant");
break;
case 65:
strcpy (race, "Vampire");
break;
case 66:
strcpy (race, "Rallos Zek");
break;
case 67:
strcpy (race, "Were Wolf");
break;
case 68:
strcpy (race, "Tentacle");
break;
case 69:
strcpy (race, "Will O' Wisp");
break;
case 70:
strcpy (race, "Zombie");
break;
case 71:
strcpy (race, "Citizen, Qeynos");
break;
case 72:
strcpy (race, "Ship");
break;
case 73:
strcpy (race, "Launch");
break;
case 74:
strcpy (race, "Piranha");
break;
case 75:
strcpy (race, "Elemental");
break;
case 76:
strcpy (race, "Boat");
break;
case 77:
strcpy (race, "Citizen, Neriak");
break;
case 78:
strcpy (race, "Citizen, Erudin");
break;
case 79:
strcpy (race, "Bixie");
break;
case 80:
strcpy (race, "Hand");
break;
case 81:
strcpy (race, "Citizen, Rivervale");
break;
case 82:
strcpy (race, "Scarecrow");
break;
case 83:
strcpy (race, "Skunk");
break;
case 84:
strcpy (race, "Elemental, Snake");
break;
case 85:
strcpy (race, "Spectre");
break;
case 86:
strcpy (race, "Sphinx");
break;
case 87:
strcpy (race, "Armadillo");
break;
case 88:
strcpy (race, "Clockwork Gnome");
break;
case 89:
strcpy (race, "Drake");
break;
case 90:
strcpy (race, "Citizen, Halas");
break;
case 91:
strcpy (race, "Alligator");
break;
case 92:
strcpy (race, "Citizen, Grobb");
break;
case 93:
strcpy (race, "Citizen, Oggok");
break;
case 94:
strcpy (race, "Citizen, Kaladim");
break;
case 95:
strcpy (race, "Cazic-Thule");
break;
case 96:
strcpy (race, "Cockatrice");
break;
case 97:
strcpy (race, "Daisy Man");
break;
case 98:
strcpy (race, "Vampire, Elf");
break;
case 99:
strcpy (race, "Denizen");
break;
case 100:
strcpy (race, "Dervish");
break;
case 101:
strcpy (race, "Efreeti");
break;
case 102:
strcpy (race, "Froglok Tadpole");
break;
case 103:
strcpy (race, "Kedge");
break;
case 104:
strcpy (race, "Leech");
break;
case 105:
strcpy (race, "Swordfish");
break;
case 106:
strcpy (race, "Guard, Felwithe");
break;
case 107:
strcpy (race, "Mammoth");
break;
case 108:
strcpy (race, "Eye of Zomm");
break;
case 109:
strcpy (race, "Wasp");
break;
case 110:
strcpy (race, "Mermaid");
break;
case 111:
strcpy (race, "Harpie");
break;
case 112:
strcpy (race, "Guard, Faydark");
break;
case 113:
strcpy (race, "Drixie");
break;
case 114:
strcpy (race, "Ship, Ghost");
break;
case 115:
strcpy (race, "Clam");
break;
case 116:
strcpy (race, "Sea Horse");
break;
case 117:
strcpy (race, "Ghost, Dwarf");
break;
case 118:
strcpy (race, "Ghost, Erudite");
break;
case 119:
strcpy (race, "Sabertooth Cat");
break;
case 120:
strcpy (race, "Elemental, Wolf");
break;
case 121:
strcpy (race, "Gorgon");
break;
case 122:
strcpy (race, "Dragon Skeleton");
break;
case 123:
strcpy (race, "Innoruuk");
break;
case 124:
strcpy (race, "Unicorn");
break;
case 125:
strcpy (race, "Pegasus");
break;
case 126:
strcpy (race, "Djinn");
break;
case 127:
strcpy (race, "Invisible Man");
break;
case 128:
strcpy (race, "Iksar");
break;
case 129:
strcpy (race, "Scorpion");
break;
case 130:
strcpy (race, "Dodo Bird");
break;
case 131:
strcpy (race, "Sarnak");
break;
case 132:
strcpy (race, "Draglock");
break;
case 133:
strcpy (race, "Lycanthrope");
break;
case 134:
strcpy (race, "Mosquito");
break;
case 135:
strcpy (race, "Rhino");
break;
case 136:
strcpy (race, "Xalgoz");
break;
case 137:
strcpy (race, "Kunark Goblin");
break;
case 138:
strcpy (race, "Yeti");
break;
case 139:
strcpy (race, "Citizen, Iksar");
break;
case 140:
strcpy (race, "Giant, Forest");
break;
case 141:
strcpy (race, "Burynai");
break;
case 142:
strcpy (race, "Goo");
break;
case 143:
strcpy (race, "Spectral Sarnak");
break;
case 144:
strcpy (race, "Burynai");
break;
case 145:
strcpy (race, "Goo");
break;
case 146:
strcpy (race, "Iksar Scorpion");
break;
case 147:
strcpy (race, "Erollisi");
break;
case 148:
strcpy (race, "Kunark Fish");
break;
case 149:
strcpy (race, "Bertoxxulous");
break;
case 150:
strcpy (race, "Bristlebane");
break;
case 151:
strcpy (race, "Fay Drake");
break;
case 152:
strcpy (race, "Sarnak Skeleton");
break;
case 153:
strcpy (race, "Ratman");
break;
case 154:
strcpy (race, "Wyvern");
break;
case 155:
strcpy (race, "Wurm");
break;
case 156:
strcpy (race, "Devourer");
break;
case 157:
strcpy (race, "Iksar Golem");
break;
case 158:
strcpy (race, "Iksar Skeleton");
break;
case 159:
strcpy (race, "Man Eating Plant");
break;
case 160:
strcpy (race, "Raptor");
break;
case 161:
strcpy (race, "Iksar Skeleton");
break;
case 162:
strcpy (race, "Water Dragon");
break;
case 163:
strcpy (race, "Iksar Hand");
break;
case 167:
strcpy (race, "Cactus");
break;
