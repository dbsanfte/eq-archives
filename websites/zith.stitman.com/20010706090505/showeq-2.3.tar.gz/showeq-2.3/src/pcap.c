/*
 * pcap.c
 *
 * ShowEQ Distributed under GPL
 * http://www.hackersquest.gomp.ch/
 */

#include <sys/param.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/poll.h>

#ifdef	__FreeBSD__
#include <netinet/in_systm.h>   
#include <net/if.h>
#include <netinet/in.h>
#include <netinet/if_ether.h>
#include <netinet/ip.h>  
#include <netinet/udp.h>
#include <netinet/if_ether.h>
#include <arpa/inet.h>

#else	/* !FREEBSD */
#include <net/if.h>
#include <net/if_packet.h>
#include <netinet/if_ether.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <netinet/if_ether.h>
#include <arpa/inet.h>
#endif	/* FREEBSD */

#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>

#include <pcap.h>
#include <pthread.h>


struct packetCache
{
  struct packetCache *next;
  ssize_t len;
  unsigned char data[0];
};

pthread_mutex_t pcache_mutex;
struct packetCache *pcache_first;
struct packetCache *pcache_last;
pcap_t *pcache_pcap;

unsigned int
EQPacketGetPacket (unsigned char *buff)
{
  int ret;
  struct packetCache *pc = NULL;

  pthread_mutex_lock (&pcache_mutex);

  ret = 0;

  pc = pcache_first;

  if (pc)
    {
      pcache_first = pc->next;

      if (!pcache_first)
	pcache_last = NULL;
    }

  pthread_mutex_unlock (&pcache_mutex);

  if (pc)
    {
      ret = pc->len;
      memcpy (buff, pc->data, ret);
      free (pc);
    }

  return ret;
}

void
EQPacketCallback (u_char * param, const struct pcap_pkthdr *ph,
		  const u_char * data)
{
  struct packetCache *pc;

  pc = (struct packetCache *) malloc (sizeof (struct packetCache) + ph->len);
  pc->len = ph->len;
  memcpy (pc->data, data, ph->len);
  pc->next = NULL;

  pthread_mutex_lock (&pcache_mutex);

  if (pcache_last)
    pcache_last->next = pc;

  pcache_last = pc;

  if (!pcache_first)
    pcache_first = pc;

  pthread_mutex_unlock (&pcache_mutex);
}


void *
EQPacketThread (void *param)
{
  pcap_loop (pcache_pcap, -1, EQPacketCallback, NULL);
}


void
EQPacketInitPcap (const char *device, const char *hostname, int realtime)
{
  char buff[4096];
  struct bpf_program bpp;
  pthread_t tid;
  struct sched_param sp;

  printf ("Opening packet capture on device %s, host %s\n", device, hostname);

  pcache_pcap = pcap_open_live ((char *) device, 1500, 0x0100, 0, buff);

  if (!pcache_pcap)
    {
      // Awwww, man?   
      fprintf (stderr, "PCAP failed to open device %s: %s\n", device, buff);
      exit (0);
    }
  // Yay :) Time to rock.
  // sprintf (buff, "ip and udp and host %s", hostname);
  sprintf (buff, "udp[0:2] > 1024 and udp[2:2] > 1024 and host %s", hostname);

  // May need to be copied... Dunno.
  if (pcap_compile (pcache_pcap, &bpp, buff, 1, 0) == -1)
    {
      // Filter fail. Typical my luck.
      fprintf (stderr,
	       "PCAP failed to compile filter for device %s: %s\n",
	       device, pcap_geterr (pcache_pcap));
      exit (0);
    }

  if (pcap_setfilter (pcache_pcap, &bpp) == -1)
    {
      fprintf (stderr, "PCAP failed to apply filter on device %s: %s\n",
	       device, pcap_geterr (pcache_pcap));
      exit (0);
    }
  // Whoa... WE'RE ALIVE!

  pcache_first = pcache_last = NULL;

  pthread_mutex_init (&pcache_mutex, NULL);
  pthread_create (&tid, NULL, EQPacketThread, NULL);

  if (realtime)
    {
      memset (&sp, 0, sizeof (sp));
      sp.sched_priority = 1;
      if (pthread_setschedparam (tid, SCHED_RR, &sp) != 0)
	{
	  fprintf (stderr, "Failed to set capture thread realtime.");
	}
    }
}
