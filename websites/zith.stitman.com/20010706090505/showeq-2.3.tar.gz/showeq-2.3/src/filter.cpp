/*
 * filter.cpp
 *
 * regex filter module
 *
 * ShowEQ Distributed under GPL
 * http://www.hackersquest.gomp.ch/
 */

/* Implementation of filter class */
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include "filter.h"

//#define DEBUG

#undef DEBUG

#define MAXLEN   5000

/* CRegExp Class - allows easy creation / deletion of regex types */
CRegExp::CRegExp(const char* string, int cflags)
{
  m_pNext = NULL;
  m_pName = strdup(string);
  m_pRegexp = (regex_t *) malloc(sizeof(regex_t));

  switch (regcomp(m_pRegexp, string, cflags))
  {
    case 0:	// no error
      break;
    case REG_BADRPT:
      fprintf(stderr, "Filter Error: '%s' - ", string);
      fprintf(stderr, "Invalid use of repetition operators such as using '*' as the first character.\n");
      break;
    case REG_BADBR:
      fprintf(stderr, "Filter Error: '%s' - ", string);
      fprintf(stderr, "Invalid use of back reference operator\n");
      break;
    case REG_EBRACE:
      fprintf(stderr, "Filter Error: '%s' - ", string);
      fprintf(stderr, "Un-matched bracket list operators\n");
      break;
    case REG_EBRACK:
      fprintf(stderr, "Filter Error: '%s' - ", string);
      fprintf(stderr, "Un-matched bracket list operators.\n");
      break;
    case REG_ERANGE:
      fprintf(stderr, "Filter Error: '%s' - ", string);
      fprintf(stderr, "Invalid use of the range operator, eg. the ending point of the range occurs prior to the starting point.\n");
      break;
    case REG_ECTYPE:
      fprintf(stderr, "Filter Error: '%s' - ", string);
      fprintf(stderr, "Unknown character class name.\n");
      break;
    case REG_ECOLLATE:
      fprintf(stderr, "Filter Error: '%s' - ", string);
      fprintf(stderr, "Invalid collating element.\n");
      break;
    case REG_EPAREN:
      fprintf(stderr, "Filter Error: '%s' - ", string);
      fprintf(stderr, "Un-matched parenthesis group operators.\n");
      break;
    case REG_ESUBREG:
      fprintf(stderr, "Filter Error: '%s' - ", string);
      fprintf(stderr, "Invalid back reference to a subexpression\n");
      break;
    case REG_EEND:
      fprintf(stderr, "Filter Error: '%s' - ", string);
      fprintf(stderr, "Non specific error.\n");
      break;
    case REG_EESCAPE:
      fprintf(stderr, "Filter Error: '%s' - ", string);
      fprintf(stderr, "Trailing backslash.\n");
      break;
    case REG_BADPAT:
      fprintf(stderr, "Filter Error: '%s' - ", string);
      fprintf(stderr, "Invalid use of pattern operators such as group or list.\n");
      break;
    case REG_ESIZE:
      fprintf(stderr, "Filter Error: '%s' - ", string);
      fprintf(stderr, "Compiled regular expression requires a pattern buffer larger than 64 Kb.\n");
      break;
    case REG_ESPACE:
      fprintf(stderr, "Filter Error: '%s' - ", string);
      fprintf(stderr, "The regex routines ran out of memory\n");
      break;
  } // end of error
}

CRegExp::~CRegExp(void)
{
  regfree(m_pRegexp);
  free(m_pName);
}

/* Filter Class - Sets up regex filter */
Filter::Filter(const char* file, int cFlags)
{
  m_sFile = strdup(file);
  m_nNumFilters = 0;
  m_pList = NULL;
  m_pListEnd = NULL;
  m_cFlags = cFlags;
  m_sType = NULL;

  loadFilters();

} // end Filter()

/* Filter Class - Sets up regex filter */
Filter::Filter(const char* file, const char* type, int cFlags)
{
  m_sFile = strdup(file);
  m_nNumFilters = 0;
  m_pList = NULL;
  m_pListEnd = NULL;
  m_cFlags = cFlags;
  m_sType = strdup(type);

  loadFilters();

} // end Filter()

Filter::~Filter(void)
{
  CRegExp *re = m_pList;

  free(m_sFile);
  if (m_sType)
    free(m_sType);
  
  // Free the list
  while(m_pList)
  {
    re = m_pList->m_pNext;

    free(m_pList);
    m_pList = re;
  }

} // end ~Filter()


//
// loadFilters
//
// parses the filter file and builds filter list
//
int
Filter::loadFilters(void)
{
#ifdef DEBUG
   printf("loadFilter()\n");
#endif /* DEBUG */

   FILE* in;
   char msg[MAXLEN + 1];
   char* p;

   // Free any current list
   while(m_pList)
     remFilter(m_pList->m_pName);

   m_pList = NULL;
   m_nNumFilters = 0;

   // Parse spawnfilter file
   if (m_sFile)
   {
      in = fopen (m_sFile, "r");
      if (in == 0)
      {
	 fprintf (stderr, "Couldn't open filter file. '%s' - %s\n", 
           m_sFile, strerror(errno));
      }
      else
      {
         char *sType = NULL;

	 while (fgets (msg, MAXLEN, in) != NULL)
	 {
            // treat lines beginning with # or ; as comments
            if ( (msg[0] == '#') || (msg[0] == ';'))
            {
               msg[0] = 0;
               continue;
            }
	    p = index (msg, '\n');
	    if (p)
	      *p = 0;
	    p = index (msg, '\r');
	    if (p)
	      *p = 0;
            if (!msg[0])
              continue;

            // if this filter uses different types make sure we are in ours
            if (m_sType)
            {
              if (msg[0] == '[')
              {
                p = index(msg, ']');
                if (p)
                  *p = 0;
                if (sType)
                  free(sType);
                sType = strdup(msg + 1);
                continue;
              }

              if (!strcmp(sType, m_sType))
              {
                 addFilter(msg);
              }
            } 
            else if (msg[0])
               addFilter(msg);

	 }
         if (sType)
            free(sType);
	 fclose (in);
      }
   }

#ifdef DEBUG
if (m_sType)
  printf("Loaded %d filters from section '%s' in file '%s'\n", 
       m_nNumFilters, m_sType, m_sFile);
else 
  printf("Loaded %d filters from section '%s' in file '%s'\n", 
       m_nNumFilters, m_sFile);
#endif

//listFilters();
   return (1);

} // end loadFilter()

int
Filter::isFiltered(const char *string)
{
   CRegExp *re = m_pList;
   regmatch_t matchArray[1];

#ifdef DEBUG
//   printf("isFiltered(%s)\n", string);
#endif /* DEBUG */

   while (re)
   {
      if (!regexec(re->m_pRegexp, string, 1, matchArray, m_cFlags))
	 return 1;
      re = re->m_pNext;
   }

   return 0;

} // end isFiltered()


int
Filter::saveFilters(void)
{
   FILE *in;
   FILE *out;
   CRegExp* re;
   char msg[MAXLEN + 1];
   char *p;
   int count = 0;
   int done = 0;
   int start = 0;

#ifdef DEBUG
printf("Filter::saveFilters(void)\n");
#endif

   // Save spawnfilter file
   if (m_sFile)
   {
      // Open source and destination files
      char *outfilename = NULL;
      const char *infilename = m_sFile;

      outfilename = (char *) malloc(strlen(infilename) + 64); 
      sprintf(outfilename, "%s%s", m_sFile, ".new");
      in = fopen (infilename, "r");
      out = fopen (outfilename, "w+");
      if (in == 0)
      {
	 fprintf (stderr, "Couldn't open filter file. '%s' - %s\n", 
           infilename, strerror(errno));
      }
      if (out == 0)
      {
	 fprintf (stderr, "Couldn't open filter file. '%s' - %s\n", 
           outfilename, strerror(errno));
         return 0;
      }
      else
      {
         char *sType = NULL;

         if (in)
         {
           // Parse source file
           while (fgets (msg, MAXLEN, in) != NULL)
           {
              // terminate the line
              p = index (msg, '\n');
              if (p)
	        *p = 0;
	      p = index (msg, '\r');
	      if (p)
	        *p = 0;

              // terminate on CF or LF 
              // if this filter uses section names
              if (m_sType)
              {
                // end of section - dump all items left in list that belong here
                if (sType && !msg[0])
                {
                   // if this is our section
                   if (!strcmp(sType, m_sType))
                   {
                     // done copying filters that existed in file already
                     // dump whatever is left in list
                     re = m_pList;
                     while (re)
                     {
#ifdef DEBUG
  printf("OUT: '%s'\n", re->m_pName);
#endif
                       fprintf(out, "%s\n", re->m_pName);
                       re = re->m_pNext;
	             }
                     done = 1;
                     start = 0;
                   } // end if our section
                   free(sType);
                   sType = 0;
                } // end if end of section
              }

              // treat lines beginning with # or ; as comments
              if ( (msg[0] == '#') || (msg[0] == ';'))
              {
#ifdef DEBUG
  printf("OUT: '%s'\n", msg);
#endif
                 fprintf(out, "%s", msg);
                 msg[0] = 0;
              }

              // preserve blank lines
              if (!msg[0])
                fprintf(out, "\n");

              if (m_sType)
              {
                // check for section name
                if (msg[0] == '[')
                {
                  p = index(msg, ']');
                  if (p)
                    *p = 0;
                  p = index(msg, '\r');
                  if (p)
                    *p = 0;
                  if (sType)
                    free(sType);
                  sType = strdup(msg + 1);
#ifdef DEBUG
  printf("OUT: '[%s]'\n", sType);
#endif
                  fprintf(out, "[%s]\n", sType);
                  start = 1;
                  msg[0] = 0;
                }
              } // end if filter uses section names  

	      if (msg[0])
	      {
                // if this is our section
                if (sType && m_sType && !strcmp(sType, m_sType))
                { 
                   // look for a match, if found put it in the file and 
                   // remove it from the list
                   re = m_pList;
                   while (re)
                   {
                     // if we found a match, output it
                     if (!strcmp(re->m_pName, msg))
                     {
#ifdef DEBUG
  printf("OUT: '%s'\n", msg);
#endif
                        fprintf(out, "%s\n", msg);
                        count++;
                        remFilter(msg);
                        break;
                     }
                     else
                       re = re->m_pNext;
                   } // for all items in list
                 } // end if our section

                 // someone elses section, just output it without alteration
                 else
                 {
#ifdef DEBUG
  printf("OUT: '%s'\n", msg);
#endif
                     fprintf(out, "%s\n", msg);
                 }

              } // end if msg

            }  // end while lines in source file

          } // end if source file

          // if we still have filters in our list, we never found our section
          // add it
          if (!done)
          {
             if (m_sType && !start)
             {
#ifdef DEBUG
  printf("done parsing file... creating section '%s'\n", m_sType);
#endif
                fprintf(out, "\n[%s]\n", m_sType);
             }

             // done copying filters that existed in file already
             // dump whatever is left in list
             re = m_pList;
             while (re)
             {
#ifdef DEBUG
  printf("OUT: '%s'\n", re->m_pName);
#endif
               fprintf(out, "%s\n", re->m_pName);
               re = re->m_pNext;
	     }
          }
          if (fflush (out))
	    fprintf (stderr, "Couldn't flush filter file. '%s' - %s\n", 
              outfilename, strerror(errno));
	  if (fclose (out))
	    fprintf (stderr, "Couldn't flush filter file. '%s' - %s\n", 
              outfilename, strerror(errno));
          if (in)
	    fclose (in);

//  printf ("Filter file saved '%s'\n", outfilename);

#if 1
          // rename files
          char tempstr[MAXLEN];
          sprintf(tempstr, "cp %s %s.bak", infilename, infilename);     
#ifdef DEBUG
  printf("%s\n", tempstr);
#endif
          if (-1 == system(tempstr))
          {
            fprintf(stderr, "'%s' - failed\n", tempstr);
          }
          sprintf(tempstr, "mv -f %s %s", outfilename, infilename);     
#ifdef DEBUG
  printf("%s\n", tempstr);
#endif
          if (-1 == system(tempstr))
          {
            fprintf(stderr, "'%s' - failed\n", tempstr);
          }
#endif
          if (sType)
            free(sType);
       }
       if (outfilename)
         free(outfilename);
   }

   // re-read the filters from file
   loadFilters();

   return 1;

} // end saveFilters



//
// remFilter
//
// Remove a filter from the list
void
Filter::remFilter(const char *string)
{
   CRegExp *re;
   CRegExp *prev;

   re = m_pList;
   prev = m_pList;

   // Find a match in the list and the one previous to it
   while(re)
   {
     if (!strcmp(re->m_pName, string)) // if match
     {
       if (prev == m_pList)      // if first in the list
         m_pList = re->m_pNext;
       else if (!re->m_pNext)    // else if last in the list
       {
         prev->m_pNext = NULL;
         m_pListEnd = prev;
       }
       else                      // else somewhere in middle, break and re-attach
         prev->m_pNext = re->m_pNext;

#ifdef DEBUG
printf("Removed '%s' from List\n", string);
#endif
       delete(re);
       m_nNumFilters--;
       break;
     }
   }
}


//
// addFilter
//
// Add a filter to the list
//
void
Filter::addFilter(const char *string)
{
  CRegExp* re;
  CRegExp* end;

  // no duplicates allowed
  if (findFilter(string))
    return;

  re = new CRegExp(string, m_cFlags);

  // if nothing in the list, create it as the head and return
  if (!m_pList)
  {
    m_pList = re;
    m_pListEnd = m_pList;
    m_nNumFilters++;
  }

  else
  {
    // tack it on the end
    m_pListEnd->m_pNext = re; 
    m_pListEnd = re; 
    m_nNumFilters++;
  }

#ifdef DEBUG
printf("Added Filter '%s'\n", string);
#endif
} // end addFilter

//
// findFilter
//
// Find a filter in the list
//
CRegExp *
Filter::findFilter(const char *string)
{
  CRegExp* re = m_pList;

  while(re)
  {
    if (!strcmp(re->m_pName, string))
      return re;
    re = re->m_pNext;
  }

  return NULL;
}


/*
void
EQPacket::ToggleFilter(const char *string)
{
  struct spawnFilter_Regexp *re;
  struct spawnFilter_Regexp *end;
  int found = 0;

  // find the filter 
  re = filterList;
  while(re->next)
  {
    if (!strcmp(re->regexp->pattern().ascii(), string))
    {
      found = 1;
      break;
    }
    re = re->next;
  }

  if (found)
    remSpawnFilter(string);
  else
    addSpawnFilter(string);
}
*/

void
Filter::listFilters(void)
{
  CRegExp *re = m_pList;

#ifdef DEBUG
//  printf("Filter::listFilters\n");
#endif

  while(re)
  {
    printf("'%s'\n", re->m_pName);
    re = re->m_pNext;
  }
}
