* EQW beta 2.32 (c) 2002 just some dude - www.eqwindows.com - justsomedude@hotmail.com *

EQW is freeware and may not be sold in any way.  If you paid anything for this
program you have been the victim of a scam and should report it as such.  Use
this program at your own risk.  The author assumes no responsibility for damages
resulting from the use or misuse of this program.

    EQW is a program that allows you to play EQ in a window rather than fullscreen.
This not only gives you access to other programs while playing EQ but allows
you to run multiple copies of EQ at the same time.

    EQW supports 16 and 32-bit color modes.  Your display color depth must match the
VideoModeBitsPerPixel value in eqclient.ini.

-- Installation instructions --

    Unzip all files into some directory and run eqw.exe.  Select the appropriate EQ
executable to run (if you aren't sure which to use, pick any of the 4 and use the
"run patch" and "play on test" check boxes to fix it).

-- Usage --

Currently three hotkeys are defined for EQW:

Ctrl Alt R: release/recapture mouse when EQ is using it in exclusive mode
Ctrl Alt I: reload ini file
Ctrl Alt S: cycle through EQW windows

These hotkeys can be changed in eqw.ini.

-- Ini file settings --

Ini file settings are stored in eqw.ini.  This file will be automatically created
the first time EQW is run.

[Hotkeys]: Valid values for hotkeys are: Ctrl, Alt, Shift, F1-F12, Tab and/or any
combination of other keys.  Each item must be separated by a space.

ReleaseMouse=Ctrl Alt R

    Hotkey to release mouse.

ReloadIni=Ctrl Alt I

    Hotkey to reload ini file.

EQWSwitch=Ctrl Alt S

    Hotkey to cycle through open EQW windows.

-- Known bugs --

- if you change your screen resolution or press ctrl alt del in win2k EQ will
   need to be restarted
