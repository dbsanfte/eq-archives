#ifndef ICON_BUTTON_H
#define ICON_BUTTON_H

#include <Bitmap.h>
#include <PopUpMenu.h>
#include <Messenger.h>

#include "IconInfo.h"

/*
	Displays an icon and allows the user to start the app/doc/folder
*/
class IconButton : public BView
{
	public:
		IconButton( entry_ref );
		IconButton( IconInfo *);
		
		virtual ~IconButton();
		
		virtual void MessageReceived( BMessage * );
		virtual void Draw( BRect );
		
		virtual void AttachedToWindow();
		virtual void DetachedFromWindow();
				
		virtual void MouseDown( BPoint );
		virtual void MouseMoved( BPoint, uint32, const BMessage * );
		virtual void MouseUp( BPoint );
		
		const IconInfo *	Info() const;
		
		void		Run( BMessage * msg = NULL );
		void		Run( const char * );
		
	private:
		IconInfo	info;
		BBitmap		* large_icon, * small_icon;
		
		int32		buttons;
		bool		mouse_down, moved;
		
		BPopUpMenu	* menu;
		BMessenger	window_messenger;
		
	private:
		void		CommonInit();
};

#endif
