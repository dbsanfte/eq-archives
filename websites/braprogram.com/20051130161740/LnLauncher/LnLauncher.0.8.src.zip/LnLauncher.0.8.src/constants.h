/*constants.h
	Any global constants should be declared here
*/
#ifndef EE_CONSTANTS_H
#define EE_CONSTANTS_H

//Einsteinium_engine application signature
#define e_engine_sig "application/x-vnd.Einsteinium_Engine"

//Messages
#define E_PRINT_RECENT_APPS	'Epra'
#define E_REPLY_RECENT_APPS	'Erra'
#define E_RECENT_APPS_REPLY	'Eapr'

#endif