#ifndef ICON_INFO_H
#define ICON_INFO_H

#include <Path.h>
#include <String.h>
#include <Archivable.h>
#include <Entry.h>

/*
	Contains all info on an icon, such as the path and mime signature
*/
class IconInfo : BArchivable
{
	public:
		IconInfo();
		IconInfo( BMessage * );
		~IconInfo();
		
		static BArchivable *	Instantiate( BMessage * );
		virtual status_t		Archive( BMessage *, bool ) const;
		
		const char *	Path() const;
		const char *	Leaf() const;
		entry_ref *		EntryRef();
		const char *	MimeType() const; // only if application/x.*
		
		const char *	GetArgs();
		void			SetArgs( const char * );

		bool			IsValid() const;
		
		bool			SetTo( entry_ref );

	private:
		entry_ref	ref, real_ref;
		BPath		path, real_path;
		BString		mime_type;
		bool		valid;
		char		args[512];
};

#endif
