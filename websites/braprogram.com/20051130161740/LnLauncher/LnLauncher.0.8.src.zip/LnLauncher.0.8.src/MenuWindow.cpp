#include "MenuWindow.h"

#include "defs.h"
#include "IconButton.h"
#include "constants.h" // einsteinium constants

#include <Application.h>
#include <Screen.h>
#include <MessageQueue.h>
#include <stdio.h>

// MAIN WINDOW

MenuWindow::MenuWindow( BMessage * settings )
:	BWindow( BRect(0,0,9,35), "menu", 
		B_NO_BORDER_WINDOW_LOOK,
		B_FLOATING_ALL_WINDOW_FEEL,
		B_NOT_MOVABLE|B_NOT_ZOOMABLE|B_NOT_RESIZABLE|B_ASYNCHRONOUS_CONTROLS|B_WILL_ACCEPT_FIRST_CLICK ),
	expanded( false ),
	dock_edge(-1)
{
	bool	t_bool;
	int32	t_int32;

	// load color
	ssize_t col_sz;
	rgb_color * col;
	handle_color = ui_color( B_MENU_BACKGROUND_COLOR ); // load/save this!
	icon_color = ui_color( B_MENU_BACKGROUND_COLOR ); // load/save this!
	if (settings->FindData("handle_color", B_RAW_TYPE, (const void**)&col, &col_sz ) == B_OK)
		memcpy(&handle_color,col,col_sz);
	if (settings->FindData("icon_color", B_RAW_TYPE, (const void**)&col, &col_sz ) == B_OK)
		memcpy(&icon_color,col,col_sz);
	
	SetWorkspaces( B_ALL_WORKSPACES );
	
	expandButton = new ExpandButton( Bounds(), settings );
	expandButton->SetViewColor( handle_color );
	AddChild( expandButton );
	int32 temp;
	
	// load always on top
	always_on_top = true;
	if (settings->FindBool("always_on_top",&t_bool) == B_OK)
		always_on_top = t_bool;
	if (!always_on_top)
		SetFeel( B_NORMAL_WINDOW_FEEL );
	
	// load pos
	curr_pos = BPoint(0,0);
	settings->FindPoint("pos",&curr_pos);
	MoveTo( curr_pos );
	
	// load expanded
	expanded = false;
//	if (settings->FindBool("expanded",&t_bool) == B_OK)
//		expanded = t_bool;
	
	// load edge
	temp = LEFT;
	settings->FindInt32("edge",&temp);
	MoveToEdge( temp );
	
	// load expand on mouse over
	expand_on_mouse_over = false;
	if (settings->FindBool("expand_on_mouse_over",&t_bool) == B_OK)
		expand_on_mouse_over = t_bool;
	if ( expand_on_mouse_over )
		expanded = false; // always atart with a closed menu if eomo
	
	// load scroll delay
	scroll_delay = 20000;
	if (settings->FindInt32("scroll_delay",&t_int32) == B_OK)
		scroll_delay = t_int32;
	
	// load icons
	BMessage  i_msg;
	for (int c=0; settings->FindMessage( "icon", c, &i_msg) == B_OK; c++)
	{
		BArchivable * arch = instantiate_object(&i_msg);
		if ( arch )
		{
			IconInfo * info	= (IconInfo*)arch;
			if ( info )
			{
				IconButton * icon = new IconButton( info );
				if ( dock_edge == RIGHT )
					icon->SetResizingMode( B_FOLLOW_LEFT|B_FOLLOW_TOP );
				icon->SetViewColor( icon_color );
//				AddChild( icon );
				icons += icon;
			}
		}
	}
	// rearrange icons
	RearrangeIcons();
	
	// load icon size
	large_icons = true;
	if ( settings->FindBool("large_icons",&t_bool) == B_OK)
		large_icons = t_bool;
	if ( !large_icons )
		SetIconSize( B_MINI_ICON );
	else
		SetIconSize( B_LARGE_ICON );
	
	// adjust size
//	SetExpanded( expanded );
};

MenuWindow::~MenuWindow()
{
}

void
MenuWindow::Save( BMessage * settings )
{
	settings->what = MenuWindow::WIN_SETTINGS;
	
	// icons
	for (int c=0; icons[c]; c++)
	{
		BMessage icon_msg;
		IconButton * icon = (IconButton*)icons[c];
		icon->Info()->Archive( &icon_msg, true );
		
		settings->AddMessage( "icon", &icon_msg );
	}
	// settings
	settings->AddPoint("pos", curr_pos);
	settings->AddBool("expanded",expanded);
	settings->AddInt32("edge",dock_edge);
	settings->AddBool("expand_on_mouse_over",expand_on_mouse_over);
	settings->AddBool("always_on_top",always_on_top);
	settings->AddBool("large_icons",large_icons);
	settings->AddInt32("scroll_delay",scroll_delay);
	settings->AddData("handle_color", B_RAW_TYPE, &handle_color, sizeof(rgb_color) );
	settings->AddData("icon_color", B_RAW_TYPE, &icon_color, sizeof(rgb_color) );
}

bool
MenuWindow::QuitRequested()
{
	be_app->PostMessage( B_QUIT_REQUESTED );
	return false;
}

void
MenuWindow::MessageReceived( BMessage * msg )
{
	switch (msg->what)
	{
		case REMOVE_WINDOW:
			msg->AddPointer("window",this);
			be_app->PostMessage( msg );
			break;
		case 'DATA':		// a file was dropped
			if ( msg->IsReply() )
			{
				const char * data;
				ssize_t size;
				
				if ( msg->FindData(	"_previous_", B_RAW_TYPE, 0, 
									(const void**)&data, &size) == B_OK)
				{
					BMessage prev;
					if (prev.Unflatten(data) == B_OK)
						RemoveIcon( &prev );
				}
			} else
				FileDrop( msg );
			break;
		case NEW_WINDOW:	// create new window
		case NEW_RECENT_WINDOW:	// create new recent window
			be_app->PostMessage( msg );
			break;
		case ADJUST_SIZE:	// change size to contain all icons
			AdjustSize();
			break;
		case TOGGLE_EXPANDED:
			ToggleExpanded();
			break;
		case REMOVE_ICON:
			RemoveIcon( msg );
			break;
		case MOVE_ICON:
			MoveIcon( msg );
			break;
		case MOVE_TO_POS:	// move to new position on screen
			MoveToPos( msg );
			break;
		case SET_EXPANDED:
		{
			bool e;
			if (msg->FindBool("expanded",&e) == B_OK && expand_on_mouse_over)
				SetExpanded( e );
		}
			break;
		case SET_ALWAYS_ON_TOP:
		{
			bool e;
			if (msg->FindBool("always_on_top",&e) == B_OK )
			{
				always_on_top = e;
				if (always_on_top)
					SetFeel( B_FLOATING_ALL_WINDOW_FEEL );
				else
					SetFeel( B_NORMAL_WINDOW_FEEL );
			}
		}
			break;
		case SET_HANDLE_COLOR:
		case SET_ICON_COLOR:
		case SET_ALL_COLOR:
			SetColor( msg );
			break;
		case SET_EXPAND_ON_MOUSE_OVER:
		{
			bool e;
			if (msg->FindBool("expand",&e) == B_OK)
				expand_on_mouse_over = e;
		}
			break;
		case SET_LARGE_ICONS:	// display small/large icons
		{
			bool e;
			if (msg->FindBool("large_icons",&e) == B_OK)
			{
				icon_size sz = B_LARGE_ICON;
				if (!e) sz = B_MINI_ICON;
				SetIconSize(sz);
			}
		}
			break;
		case SET_SCROLL_SPEED:
		{
			int32 temp;
			if (msg->FindInt32("delay",&temp) == B_OK )
			{
				scroll_delay = temp;
			}
		}
			break;
		default:
			BWindow::MessageReceived( msg );
	}
}

void
MenuWindow::ToggleExpanded()
{
	SetExpanded(!expanded);
}

void
MenuWindow::SetExpanded( bool e )
{
	bool changed = (e != expanded);
	
	expanded = e;
	
	if (changed && expanded)
	{
		for (int c=0; icons[c]; c++)
			AddChild( icons[c] );
	}
	
	AdjustSize();
	
	if (changed && !expanded)
	{
		for (int c=0; icons[c]; c++)
			RemoveChild( icons[c] );
	}
}

void
MenuWindow::AdjustSize()
{
	BRect new_size = Bounds();
	float dx;
	
	float size = ChildAt(0)->Bounds().Height()+1;
	
	if (!expanded)
	{ // minimize
		new_size.right = 10;
		dx = -size;
	} else 
	{ // expand
		new_size.right = size*icons.NumItems()+10; // change to num_views * 32
		dx = size;
	}
	
	bigtime_t	target_time;
	
	BScreen scr( this );
	
	BMessageQueue * queue = MessageQueue();
	
	if ( scroll_delay > 0 )
	{ // only scroll if delay > 0
		if ( dx < 0 )
		{ // scrolling left
			while ( Bounds().right > new_size.right )
			{
				target_time = system_time() + scroll_delay;
				BRect temp = Bounds();
				temp.right += dx;
				ResizeTo( temp.Width(), temp.Height() );
				if ( dock_edge == RIGHT )
					MoveTo( scr.Frame().right-Bounds().Width(), Frame().top );
			
				UpdateIfNeeded();
				if ( queue->CountMessages() > 1 )
					break;

				snooze_until( target_time, B_SYSTEM_TIMEBASE);
			}
		} else
		{ // scrolling right
			while ( Bounds().right < new_size.right )
			{
				target_time = system_time() + scroll_delay;
				BRect temp = Bounds();
				temp.right += dx;
				ResizeTo( temp.Width(), temp.Height() );
				if ( dock_edge == RIGHT )
					MoveTo( scr.Frame().right-Bounds().Width(), Frame().top );
				UpdateIfNeeded();
				if ( queue->CountMessages() > 1 )
					break;
				snooze_until( target_time, B_SYSTEM_TIMEBASE);
			}
		}
	}

	// make sure we arrive at the correct size
	ResizeTo( new_size.Width(), new_size.Height() );
	if ( dock_edge == RIGHT )
		MoveTo( scr.Frame().right-Bounds().Width(), Frame().top );
}

void
MenuWindow::FileDrop( BMessage * msg )
{
	entry_ref ref;
	
	for (int c=0; msg->FindRef("refs",c,&ref) == B_OK; c++)
	{	// for each file dropped
		bigtime_t next_add_at_time = system_time() + scroll_delay;
		
		BEntry entry(&ref);
		BPath path( &entry );
		
		// add a button
		IconButton * icon = new IconButton( ref );
		if ( dock_edge == RIGHT )
			icon->SetResizingMode( B_FOLLOW_LEFT|B_FOLLOW_TOP );
		float sz = ChildAt(0)->Bounds().Height();
		icon->ResizeTo( sz,sz );
		icon->SetViewColor( icon_color );
		if (expanded)
			AddChild( icon );
		
		// add at position
		if ( icons.NumItems() == 0 )
		{ // only one icon
			icons += icon;
			continue;
		}
		
		int trg_pos = 0;
		BView * sender_view = NULL;
		if ( msg->FindPointer("icon",(void**)&sender_view) == B_OK )
		{ // move to position where it was dropped
			for (int c=1; ChildAt(c); c++)
				if ( ChildAt(c) == sender_view )
					trg_pos = c;

			List<BView> temp;
		
			for (int i=0; i<trg_pos; i++)
				temp += icons[i];
		
			temp += icon;

			for (int j=trg_pos; icons[j]; j++)
				temp += icons[j];

			for (; icons[0]; )
				icons -= icons[0];
			
			for (; temp[0]; )
			{
				icons += temp[0];
				temp -= temp[0];
			}
		} else // end move position
		{
			icons += icon;
		}
		
		RearrangeIcons();
//		AdjustSize();
		snooze_until( next_add_at_time, B_SYSTEM_TIMEBASE );
	}
	
	BMessage app_msg(SAVE);
	be_app->PostMessage( &app_msg );
}

void
MenuWindow::RemoveIcon( BMessage * msg )
{
	BView * icon;
	if (msg->FindPointer("icon",(void**)&icon) == B_OK)
	{
		for (int c=0; icons[c]; c++)
		{ // remove icon
			if ( icons[c] == icon )
			{ // match, remove
				// remove view
				RemoveChild( icon );
				
				// delete icon
				delete icon;
				icons -= icon;
			}
		}
	}
	RearrangeIcons();
	AdjustSize();
}

void
MenuWindow::RearrangeIcons()
{	// move all icons to their correct places. needed after add/remove.
	if ( icons.NumItems() == 0 )
		return; // no icons, no need to rearrange
	
	BRect icon_rect = icons[0]->Bounds();
	
	for (int c=0; icons[c]; c++)
	{
		BRect temp = icon_rect;
		if ( dock_edge == LEFT )
		{
			temp.OffsetBy( Bounds().RightTop() );
			temp.OffsetBy( -(c+1)*(icon_rect.Width()+1)+1, 0 );
		} else
		{
			temp.OffsetBy( c*(icon_rect.Width()+1), 0 );
		}
		
		icons[c]->MoveTo( temp.LeftTop() );
	}

	if (expanded)
		ResizeTo( (icon_rect.Width()+1)*icons.NumItems()+10, Bounds().Height() );
	if ( dock_edge == RIGHT )
	{
		BScreen scr( this );
		MoveTo( scr.Frame().right-Bounds().Width(), Frame().top );
	}
}

void
MenuWindow::MoveIcon( BMessage * msg )
{
	if ( icons.NumItems() < 2 )
		return;

	BView * view;
	if (msg->FindPointer("icon",(void**)&view) == B_OK)
	{
		// some voodoo to move the icon
		List<BView> temp;

		int32 dir = LEFT;
		msg->FindInt32("dir",&dir);
		
		
		bool found = false;
		int c;
		for (c=0; icons[c]; c++)
			if ( icons[c] == view )
			{
				found = true;
				break;
			}
		
		if (!found)
			return;
		
		
		icons -= view;
		
		for ( ; icons[0] ; )
		{
			BView * cv = icons[0];
			temp += cv;
			icons -= cv;
		}

		// move in what direction?
		int insert_at = 0;
		if ( dock_edge == LEFT )
		{
			if ( dir == LEFT )
				insert_at = c + 1;

			if ( dir == RIGHT )
				insert_at = c - 1;
		}
		
		if ( dock_edge == RIGHT )
		{
			if ( dir == LEFT )
				insert_at = c - 1;

			if ( dir == RIGHT )
				insert_at = c + 1;
		}
		
		// move it
		if ( insert_at < 0 )
			insert_at = 0; // already in the correct place
		
		for (int i=0; i >= 0 && i < insert_at && temp[i]; i++)
			icons += temp[i];
			
		icons += view;
			
		for (int i=insert_at; temp[i]; i++)
			icons += temp[i];

		RearrangeIcons();
		
		Flush();
	}
}

void
MenuWindow::MoveToEdge( int32 e )
{	// dock to edge e (LEFT/RIGHT) if needed
	if ( dock_edge == e )
		return;
	
	dock_edge = e;
			
	if ( dock_edge == LEFT )
	{
		MoveTo( 0, curr_pos.y );
		// move expandButton too
//		BPoint new_exp_pos( Bounds().RightTop() );
//		new_exp_pos.x -= expandButton->Bounds().Width();
		expandButton->MoveTo( Bounds().LeftTop() );
		ChildAt(0)->SetResizingMode( B_FOLLOW_LEFT|B_FOLLOW_TOP );
		for (int c=0; icons[c]; c++)
			icons[c]->SetResizingMode( B_FOLLOW_RIGHT|B_FOLLOW_TOP );
	} else
	{
		BScreen scr(this);
		
		MoveTo( scr.Frame().right-Frame().Width(), curr_pos.y );
		// move expandButton too
		expandButton->MoveTo( Bounds().RightTop() );
		expandButton->MoveBy( -expandButton->Bounds().Width(), 0 );
		
		ChildAt(0)->SetResizingMode( B_FOLLOW_RIGHT|B_FOLLOW_TOP );
		for (int c=0; icons[c]; c++)
//			ChildAt(c)->SetResizingMode( B_FOLLOW_LEFT|B_FOLLOW_TOP );
			icons[c]->SetResizingMode( B_FOLLOW_LEFT|B_FOLLOW_TOP );
	}
		
	curr_pos = Frame().LeftTop();
	
	RearrangeIcons();
}

void
MenuWindow::MoveToPos( BMessage * msg )
{	// move menu, change docking if needed
	BPoint pos;
	if (msg->FindPoint("pos",&pos) == B_OK )
	{
		BScreen scr( this );
		
		if ( pos.y + Frame().Height() > scr.Frame().bottom )
			pos.y = scr.Frame().bottom - Frame().Height();
		MoveTo( Frame().left, pos.y );
		
		if ( pos.x < scr.Frame().right/2 )
			MoveToEdge( LEFT );
		else
			MoveToEdge( RIGHT );

		curr_pos = Frame().LeftTop();
	}
}

void
MenuWindow::WorkspaceActivated( int32 ws, bool active )
{	// workspace activated, move to correct position
	if (active)
	{
		BScreen scr( this );

		MoveTo( curr_pos );

		// adjust to new screen frame
		if ( dock_edge == RIGHT )
		{
			MoveTo( scr.Frame().right-Frame().Width(), curr_pos.y );
			curr_pos = Frame().LeftTop();
		}
		
		MoveToEdge( dock_edge );
		
		// sanity check, bottom of screen
		if ( Frame().bottom > scr.Frame().bottom )
			MoveTo( Frame().left, scr.Frame().bottom - Frame().Height() );
	}
}

void
MenuWindow::WindowActivated( bool active )
{
	if (expand_on_mouse_over)
	{
		SetExpanded( active );
	}
}

void
MenuWindow::SetIconSize( icon_size size )
{	// set large/small icon size and resize as needed
	// retract menu before changing size
	bool was_expanded = expanded;
	SetExpanded( false );
	
	BRect icon_rect;
	if ( size == B_LARGE_ICON )
		icon_rect = BRect(0,0,35,35);
	else
		icon_rect = BRect(0,0,19,19);
	
	large_icons = (size == B_LARGE_ICON);
	
	ChildAt(0)->ResizeTo(10,icon_rect.Height());
	ChildAt(0)->Invalidate();
	
	for (int c=0; icons[c]; c++)
		icons[c]->ResizeTo( icon_rect.Width(), icon_rect.Height() );
	
	RearrangeIcons();
	ResizeTo(10,icon_rect.Height());
	
	if ( dock_edge == RIGHT )
	{
		BScreen scr( this );
		MoveTo( scr.Frame().right-Bounds().Width(), Frame().top );
	}
	
	if ( was_expanded )
		SetExpanded( true );
}

void
MenuWindow::SetColor( BMessage * msg )
{	// set background color of icons and handle
	ssize_t col_sz;
	rgb_color * col;
	rgb_color color;
	if (msg->FindData("color", B_RAW_TYPE, (const void**)&col, &col_sz ) == B_OK)
		memcpy(&color,col,col_sz);

	int start=0, end=0;
	switch ( msg->what )
	{
		case SET_ALL_COLOR:
			start = 0; end = 50000;
			handle_color = color;
			icon_color = color;
			break;
		case SET_HANDLE_COLOR:
			start = 0; end = 1;
			handle_color = color;
			break;
		case SET_ICON_COLOR:
			start = 1; end = 50000;
			icon_color = color;
			break;
	}

	for (int c=start; c < end && ChildAt(c); c++)
	{
		ChildAt(c)->SetViewColor( c > 0 ? icon_color : handle_color );
		ChildAt(c)->Invalidate();
	}
}


// RECENT MENU WINDOW

RecentMenuWindow::RecentMenuWindow( BMessage * msg )
:	MenuWindow( msg )
{
}

RecentMenuWindow::~RecentMenuWindow()
{
}

void
RecentMenuWindow::SetExpanded( bool e )
{
	bool changed = (e != expanded);
	
	expanded = e;

	if (changed && e)
	{
		// request list of apps from einsteinium engine
		BMessenger msgr(e_engine_sig);
		BMessage msg(E_REPLY_RECENT_APPS), reply;
		msgr.SendMessage( &msg, &reply );
		
		List<entry_ref> ref_list;
		ref_list.SetDeleteItems(true);
		
		for (int32 c=0; reply.FindString("app_path",c); c++)
		{
			BEntry entry( reply.FindString("app_path",c) );
			entry_ref eref;
			if ( entry.GetRef( &eref ) == B_OK )
			{
				entry_ref * t = new entry_ref;
				*t = eref;
				ref_list += t;
			}
		}
		
		if ( ref_list.NumItems() > 0 )
		{
			BMessage file_drop_dummy;
			for (int c=ref_list.NumItems()-1; c>= 0; c--)
			{
				file_drop_dummy.AddRef("refs", ref_list[c]);
			}
			FileDrop( &file_drop_dummy );
		}
	}
	
	if (changed && !expanded)
	{
		AdjustSize();

		// delete children
		for (; ChildAt(1);)
		{
			IconButton * icon = (IconButton*)ChildAt(1);
			
			RemoveChild( icon );
			icons -= icon;
			delete icon;
		}
	}
}

void
RecentMenuWindow::Save( BMessage * msg )
{
	MenuWindow::Save(msg);
	msg->what = MenuWindow::RECENT_SETTINGS;
}
