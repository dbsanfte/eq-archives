#include "IconInfo.h"

#include <NodeInfo.h>
#include <SymLink.h>
#include <stdio.h>
#include <AppFileInfo.h>
#include <Roster.h>

// ICON INFO
IconInfo::IconInfo()
:	valid(true)
{
	args[0] = 0;
}

IconInfo::IconInfo( BMessage * msg )
:	valid(true)
{
	path.SetTo( msg->FindString("path") );
	mime_type = msg->FindString("mime");
	
	SetArgs( msg->FindString("args") );
	
	BEntry entry( path.Path() );
	entry.GetRef( &ref );
	
	if ( entry.SetTo( path.Path(), true ) != B_OK )
	{ // file not found, try to find it via the Roster if it's an app
		if ( strncmp(MimeType(), "application/", 12) == 0 )
		{
			printf("App [%s] not found, checking with the Roster\n", MimeType() );
			BRoster roster;
			if (roster.FindApp( MimeType(), &real_ref) != B_OK)
				printf("  Roster didn't find it :P\n");
		}
	} else
	{ // file exists
		entry.GetRef( &real_ref );
	}
	
	real_path.SetTo( &real_ref );
}

IconInfo::~IconInfo()
{
}

BArchivable *
IconInfo::Instantiate( BMessage * msg )
{
	if ( validate_instantiation(msg, "IconInfo") ) 
		return new IconInfo(msg);
	return NULL; 
}

status_t
IconInfo::Archive( BMessage * msg, bool deep ) const
{
	BArchivable::Archive(msg, deep);
	
	msg->AddString("path", path.Path() );
	msg->AddString("mime", mime_type.String() );
	msg->AddString("args", args );
	
	return B_OK;
}

const char *
IconInfo::Path() const
{
	if ( real_path.Path() )
		return real_path.Path();
	else
		return path.Path();
}

const char *
IconInfo::Leaf() const
{
	if ( real_path.Leaf() )
		return real_path.Leaf();
	else
		return path.Leaf();
}

entry_ref *
IconInfo::EntryRef()
{
	return &real_ref;
}

const char *
IconInfo::MimeType() const
{
	return mime_type.String();
}

bool
IconInfo::SetTo( entry_ref e_ref )
{
	ref = e_ref;
	BEntry entry( &ref, true );
	if ( entry.GetRef( &real_ref ) != B_OK )
		real_ref = ref;
	
	path.SetTo( &ref );
	real_path.SetTo( &real_ref );
	
	BNode node( path.Path() );
	BNodeInfo  ninfo( &node );
	char msig[512];
	if ( ninfo.GetType( msig ) == B_OK )
		mime_type = msig;
	else
		mime_type = "";
	
	if ( strncmp(mime_type.String(), "application/", 12) == 0 )
	{ // application, set mime_type to signature (if any)
		if ( mime_type != "application/x-vnd.Be-symlink" )
		{
			BFile file( path.Path(), B_READ_ONLY );
			BAppFileInfo info( &file );
			
			char mime[B_MIME_TYPE_LENGTH];
			if ( info.GetSignature( mime ) == B_OK )
				mime_type = mime;
		}
	}
	
	return true;
}

const char *
IconInfo::GetArgs()
{
	return args;
}

void
IconInfo::SetArgs( const char * a )
{
	if ( a )
	{
		strcpy(args, a);
	} else
		args[0] = 0;
}

bool
IconInfo::IsValid() const
{
	return valid;
}
