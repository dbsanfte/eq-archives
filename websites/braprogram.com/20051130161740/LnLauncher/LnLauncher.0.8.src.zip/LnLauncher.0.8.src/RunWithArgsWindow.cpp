#include "RunWithArgsWindow.h"
#include "defs.h"

#include <stdio.h>
#include <Button.h>
#include <Path.h>

// RUN WITH ARGS WINDOW
RunWithArgs::RunWithArgs( BMessenger msgr, const char * _path, const char * _argv )
:	BWindow( 
		BRect(50,50,300,75), "Run with args", 
		B_FLOATING_WINDOW_LOOK,
		B_NORMAL_WINDOW_FEEL,B_NOT_RESIZABLE|B_NOT_ZOOMABLE
	),
	target(msgr)
{
	BRect rect = Bounds();
	rect.right -= 40;
	
	float pref_h, pref_w;
	
	if (!_argv)
		_argv = "";
	
	argsText = new BTextControl(rect,"argv","Args", _argv, new BMessage(B_OK));
	argsText->SetDivider( 50 );
	argsText->GetPreferredSize( &pref_w, &pref_h );
	argsText->ResizeTo( rect.Width(), pref_h );
	
	AddChild( argsText );
	
	ResizeTo( Bounds().Width(), argsText->Bounds().Height() );
	
	rect = Bounds();
	rect.left = argsText->Frame().right + 1;
	
	BButton * okButton = new BButton( rect, "go-button", "Go", new BMessage(B_OK) );
	AddChild( okButton );
	okButton->MoveTo( rect.left+5, rect.top );
	okButton->ResizeTo( rect.Width()-5, rect.Height() );
	
	SetDefaultButton( okButton );
	
	argsText->SetTarget( this );
	okButton->SetTarget( this );
	
	BPath path(_path);
	char title[512];
	sprintf(title,"Run [%s] with args", path.Leaf() );
	SetTitle( title );
}

RunWithArgs::~RunWithArgs()
{
}

void
RunWithArgs::MessageReceived( BMessage * msg )
{
	switch (msg->what)
	{
		case B_OK:
		{ // run!
			BMessage icon_msg(RUN_WITH_ARGS);
			icon_msg.AddString( "args", argsText->Text() );
			
			target.SendMessage( &icon_msg );
			
			PostMessage( B_QUIT_REQUESTED );
		}
			break;
		default:
			BWindow::MessageReceived( msg );
	}
}

bool
RunWithArgs::QuitRequested()
{
	return true;
}

