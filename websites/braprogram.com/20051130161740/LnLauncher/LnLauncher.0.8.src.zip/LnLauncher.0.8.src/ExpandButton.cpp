#include "ExpandButton.h"

#include "defs.h"

#include <String.h>
#include <Window.h>
#include <Dragger.h>
#include <Roster.h>

// from private_roster.h (or something like that, stolen from Deskbar src :)
const uint32 CMD_SHUTDOWN_SYSTEM = 301;
const uint32 CMD_REBOOT_SYSTEM = 302;
const uint32 CMD_SUSPEND_SYSTEM = 304;

// EXPAND BUTTON

ExpandButton::ExpandButton( BRect r, BMessage * settings )
:	BView( r, "expander", B_FOLLOW_RIGHT|B_FOLLOW_TOP, B_WILL_DRAW ),
	mouse_down( false )
{
	SetViewColor( B_TRANSPARENT_COLOR );

	bool t_bool;
	int32 t_int32;
	
	// expand on mouse-over
	expand_on_mouse_over = false;
	settings->FindBool("expand_on_mouse_over",&expand_on_mouse_over);
	item_on_mouse_over = new BMenuItem("Expand on mouse-over", new BMessage(SET_EXPAND_ON_MOUSE_OVER));
	item_on_mouse_over->SetMarked(expand_on_mouse_over);

	// icon size
	large_icons = true;
	if (settings->FindBool("large_icons",&t_bool) == B_OK)
		large_icons = t_bool;
	item_large_icons = new BMenuItem("Large icons", new BMessage(SET_LARGE_ICONS));
	item_large_icons->SetMarked(large_icons);
	
	// always on top
	always_on_top = true;
	if (settings->FindBool("always_on_top",&t_bool) == B_OK)
		always_on_top = t_bool;
	item_always_on_top = new BMenuItem("Always on top", new BMessage(SET_ALWAYS_ON_TOP));
	item_always_on_top->SetMarked(always_on_top);

	// select scroll delay menu
	int32 delay = 20000;
	if ( settings->FindInt32("scroll_delay",&t_int32) == B_OK)
		delay = t_int32;
	
	menu_scroll_speed = new BPopUpMenu("Scroll delay", false, false);
	menu_scroll_speed->SetRadioMode( true );
	for (int c=0; c <= 5; c++)
	{
		BString name;
		name << (int32)c*20 << " ms";
		BMessage * msg = new BMessage(SET_SCROLL_SPEED);
		msg->AddInt32("delay", c*20000);
		BMenuItem * item = new BMenuItem( name.String(), msg );
		
		if ( c*20000 == delay )
			item->SetMarked( true );
		
		menu_scroll_speed->AddItem( item );
	}

	// select color menu
	BMessage * col_msg;
	rgb_color color_default = ui_color(B_MENU_BACKGROUND_COLOR);
	rgb_color color_gray    = (rgb_color){216,216,216,255};
	rgb_color color_green   = (rgb_color){ 86,156, 86,255};
	rgb_color color_red     = (rgb_color){200, 85, 85,255};
	rgb_color color_brown   = (rgb_color){168,115, 85,255};
	rgb_color color_blue    = (rgb_color){156,156,216,255};
	rgb_color color_purple  = (rgb_color){134,102,152,255};
	rgb_color color_t_blue  = (rgb_color){ 81,115,152,255};

	menu_color = new BPopUpMenu("Color", false, false);
	menu_color->SetRadioMode( true );
		// default
		col_msg = new BMessage(SET_ALL_COLOR);
		col_msg->AddData("color",B_RAW_TYPE,&color_default,sizeof(rgb_color));
		menu_color->AddItem( new BMenuItem( "[default]", col_msg ) );
		// gray
		col_msg = new BMessage(SET_ALL_COLOR);
		col_msg->AddData("color",B_RAW_TYPE,&color_gray,sizeof(rgb_color));
		menu_color->AddItem( new BMenuItem( "Gray", col_msg ) );
		// red
		col_msg = new BMessage(SET_ALL_COLOR);
		col_msg->AddData("color",B_RAW_TYPE,&color_red,sizeof(rgb_color));
		menu_color->AddItem( new BMenuItem( "Red", col_msg ) );
		// brown (rust red)
		col_msg = new BMessage(SET_ALL_COLOR);
		col_msg->AddData("color",B_RAW_TYPE,&color_brown,sizeof(rgb_color));
		menu_color->AddItem( new BMenuItem( "Rust red", col_msg ) );
		// green
		col_msg = new BMessage(SET_ALL_COLOR);
		col_msg->AddData("color",B_RAW_TYPE,&color_green,sizeof(rgb_color));
		menu_color->AddItem( new BMenuItem( "Green", col_msg ) );
		// blue
		col_msg = new BMessage(SET_ALL_COLOR);
		col_msg->AddData("color",B_RAW_TYPE,&color_blue,sizeof(rgb_color));
		menu_color->AddItem( new BMenuItem( "Blue", col_msg ) );
		// tic blue
		col_msg = new BMessage(SET_ALL_COLOR);
		col_msg->AddData("color",B_RAW_TYPE,&color_t_blue,sizeof(rgb_color));
		menu_color->AddItem( new BMenuItem( "Dark blue", col_msg ) );
		// purple
		col_msg = new BMessage(SET_ALL_COLOR);
		col_msg->AddData("color",B_RAW_TYPE,&color_purple,sizeof(rgb_color));
		menu_color->AddItem( new BMenuItem( "Dark purple", col_msg ) );
	
	// rescue menu
	menu_rescue = new BPopUpMenu("Rescue",false,false);
	menu_rescue->AddItem( new BMenuItem("Launch Tracker", new BMessage(RESCUE_TRACKER)) );
	menu_rescue->AddItem( new BMenuItem("Launch Deskbar", new BMessage(RESCUE_DESKBAR)) );
	menu_rescue->AddItem( new BMenuItem("Launch Terminal", new BMessage(RESCUE_TERMINAL)) );
	
	// window menu
	menu_window = new BPopUpMenu("Menu",false,false);
	menu_window->AddItem( new BMenuItem("New menu", new BMessage(NEW_WINDOW)) );
	menu_window->AddItem( new BMenuItem("New recent", new BMessage(NEW_RECENT_WINDOW)) );
	menu_window->AddItem( new BMenuItem("Remove", new BMessage(REMOVE_WINDOW)) );
	
	// window menu
	menu_replicants = new BPopUpMenu("Replicants",false,false);
	menu_replicants->AddItem( new BMenuItem("Show", new BMessage(SHOW_REPLICANTS)) );
	menu_replicants->AddItem( new BMenuItem("Hide", new BMessage(HIDE_REPLICANTS)) );
	
	// shutdown menu
	menu_shutdown = new BPopUpMenu("Shutdown",false,false);
	menu_shutdown->AddItem( new BMenuItem("Power off", new BMessage(CMD_SHUTDOWN_SYSTEM)) );
	menu_shutdown->AddItem( new BMenuItem("Restart", new BMessage(CMD_REBOOT_SYSTEM)) );

	menu = new BPopUpMenu("options",false,false );
//	menu->SetRadioMode( false );
	// quit
	menu->AddItem( new BMenuItem("Quit", new BMessage(B_QUIT_REQUESTED)) );
	// settings
	menu->AddItem( new BSeparatorItem() );
	menu->AddItem( item_on_mouse_over );
	menu->AddItem( item_large_icons );
	menu->AddItem( item_always_on_top );
	// sub-menus
	menu->AddItem( new BSeparatorItem() );
	menu->AddItem( menu_window );
	menu->AddItem( menu_scroll_speed );
	menu->AddItem( menu_color );
	// system options
	menu->AddItem( new BSeparatorItem() );
	menu->AddItem( menu_replicants );
	menu->AddItem( menu_rescue );
	menu->AddItem( menu_shutdown );
}

ExpandButton::~ExpandButton()
{
	delete menu;
}

void
ExpandButton::MessageReceived( BMessage * msg )
{
	switch (msg->what)
	{
		case 'PSTE':
		{ // color drop
			rgb_color * col;
			ssize_t sz;
			if (msg->FindData("RGBColor",B_RGB_COLOR_TYPE, (const void**)&col, &sz) == B_OK)
			{
				BMessage win_msg(SET_HANDLE_COLOR);
				win_msg.AddData("color", B_RAW_TYPE, col, sizeof(rgb_color) );
				Window()->PostMessage( &win_msg );
			}
		}
			break;
		case SET_EXPAND_ON_MOUSE_OVER:
		{
			expand_on_mouse_over = !expand_on_mouse_over;
			item_on_mouse_over->SetMarked( expand_on_mouse_over );
			
			BMessage win_msg(SET_EXPAND_ON_MOUSE_OVER);
			win_msg.AddBool( "expand", expand_on_mouse_over );
			Window()->PostMessage( &win_msg );
		}
			break;
		case SET_LARGE_ICONS:
		{
			large_icons = !large_icons;
			item_large_icons->SetMarked( large_icons );
			
			BMessage win_msg(SET_LARGE_ICONS);
			win_msg.AddBool( "large_icons", large_icons );
			Window()->PostMessage( &win_msg );
		}
			break;
		case SET_ALWAYS_ON_TOP:
		{
			always_on_top = !always_on_top;
			item_always_on_top->SetMarked( always_on_top );
			
			BMessage win_msg(SET_ALWAYS_ON_TOP);
			win_msg.AddBool( "always_on_top", always_on_top );
			Window()->PostMessage( &win_msg );
		}
			break;
		case SHOW_REPLICANTS:
			BDragger::ShowAllDraggers();
			break;
		case HIDE_REPLICANTS:
			BDragger::HideAllDraggers();
			break;
		case RESCUE_TRACKER:
		case RESCUE_DESKBAR:
		case RESCUE_TERMINAL:
		{
			BRoster roster;
			if (msg->what == RESCUE_TRACKER)
				roster.Launch("application/x-vnd.Be-TRAK");
			if (msg->what == RESCUE_DESKBAR)
				roster.Launch("application/x-vnd.Be-TSKB");
			if (msg->what == RESCUE_TERMINAL)
				roster.Launch("application/x-vnd.Be-SHEL");
		}
			break;
		case CMD_SHUTDOWN_SYSTEM:
		case CMD_REBOOT_SYSTEM:
		{ // forward to Roster
			BMessenger msgr("application/x-vnd.Be-ROST");
			msgr.SendMessage( msg );
		}
			break;
		// forward these to Window()
		case REMOVE_WINDOW:
		case SET_ALL_COLOR:
		case SET_SCROLL_SPEED:
		case B_QUIT_REQUESTED:
		case 'DATA':
			Window()->PostMessage( msg );
			break;
		default:
			BView::MessageReceived( msg );
	}
}

void
ExpandButton::MouseDown( BPoint pos )
{
	mouse_down = true;
	Window()->CurrentMessage()->FindInt32("buttons",&buttons);
	SetMouseEventMask( B_POINTER_EVENTS, B_LOCK_WINDOW_FOCUS );
	mouse_down = true;
	has_moved = false;
	mouse_click_at = pos;
	
	Invalidate();
}

void
ExpandButton::MouseMoved( BPoint pos, uint32 transit, const BMessage * msg )
{
	int32 buttons = 0;
	if ( Window()->CurrentMessage()->FindInt32("buttons",&buttons) == B_OK)
	{
		if (mouse_down && (buttons & B_SECONDARY_MOUSE_BUTTON))
		{
			BPoint scr_pos = ConvertToScreen( BPoint(pos.x,pos.y) );
			
			float dx = pos.x - mouse_click_at.x;
			float dy = pos.y - mouse_click_at.y;
			
			if (has_moved || sqrt( dx*dx + dy*dy) > 3)
			{ // test threshold
				has_moved = true;
				
				// move window
				BMessage pos_msg(MOVE_TO_POS);
				pos_msg.AddPoint("pos", scr_pos );
				Window()->PostMessage( &pos_msg );
			}
		}
	}
	
	if ( transit != B_INSIDE_VIEW && !mouse_down)
	{ // moved, no buttons
		BMessage win_msg(SET_EXPANDED);
		if ( Window()->Frame().Contains( ConvertToScreen(pos) ) )
		{
			win_msg.AddBool("expanded", true );
		} else
		{
			win_msg.AddBool("expanded", false );
		}
		Window()->PostMessage( &win_msg );
	}
}

void
ExpandButton::MouseUp( BPoint pos )
{
	if (!mouse_down)
		return;
	
	mouse_down = false;
	Invalidate();
	if (buttons & B_PRIMARY_MOUSE_BUTTON)
		if ( Bounds().Contains( pos ) && !expand_on_mouse_over )
			Window()->PostMessage( TOGGLE_EXPANDED );
	
	if (buttons & B_SECONDARY_MOUSE_BUTTON)
		if ( Bounds().Contains( pos ) && !has_moved)
		{ // display options menu
			menu->Go( 
				ConvertToScreen( pos ), 
				true, // delivers message
				true, // open even if no button pressed
				true  // click to close
			);
		}
}

void
ExpandButton::AttachedToWindow()
{
	menu->SetTargetForItems( this );
	menu_scroll_speed->SetTargetForItems( this );
	menu_color->SetTargetForItems( this );
	menu_window->SetTargetForItems( this );
	menu_rescue->SetTargetForItems( this );
	menu_replicants->SetTargetForItems( this );
	menu_shutdown->SetTargetForItems( this );
}

void
ExpandButton::Draw( BRect )
{
	rgb_color light  = ViewColor();
	rgb_color bright = ViewColor();
	rgb_color dark   = ViewColor();

	// set up colors
	if ( bright.red < 175 )   bright.red += 80;   else bright.red = 255;
	if ( bright.green < 175 ) bright.green += 80; else bright.green = 255;
	if ( bright.blue < 175 )  bright.blue += 80;  else bright.blue = 255;

	if ( dark.red > 79 )   dark.red -= 80;   else dark.red = 0;
	if ( dark.green > 79 ) dark.green -= 80; else dark.green = 0;
	if ( dark.blue > 79 )  dark.blue -= 80;  else dark.blue = 0;
	
	if ( mouse_down )
	{
		light	= tint_color( light, B_HIGHLIGHT_BACKGROUND_TINT );
		bright	= tint_color( bright, B_HIGHLIGHT_BACKGROUND_TINT );
		dark	= tint_color( dark, B_HIGHLIGHT_BACKGROUND_TINT );
	}
	
	BRect bounds = Bounds();

	// border
	MovePenTo( bounds.RightTop() );
	
	SetHighColor( bright );		
	StrokeLine( bounds.LeftTop() );
	StrokeLine( bounds.LeftBottom() );
	
	SetHighColor( dark );
	StrokeLine( bounds.RightBottom() );
	StrokeLine( bounds.RightTop() );
	
	// interior
	BRect temp = bounds; temp.InsetBy(1,1);
	SetHighColor( light );		FillRect( temp );
	
	// grip-friendly surface look
	BPoint pos;
	
	float dy = 2 + (bounds.bottom < 30);
	
	SetHighColor( bright );
	for (int x=0; x < 2; x++)
		for (int y=0; y < 11; y++)
		{
			pos = BPoint(4+x*3, y*3+dy+1); 
			if ( pos.y <= bounds.bottom-2)
				StrokeLine( pos,pos );
		}
	SetHighColor( dark );
	for (int x=0; x < 2; x++)
		for (int y=0; y < 11; y++)
		{
			pos = BPoint(3+x*3, y*3+dy); 
			if ( pos.y <= bounds.bottom-2)
				StrokeLine( pos,pos );
		}
}
