#include "IconButton.h"

#include "defs.h"
#include "RunWithArgsWindow.h"

#include <stdio.h>
#include <NodeInfo.h>
#include <Roster.h>
#include <AppFileInfo.h>
#include <MenuItem.h>

// APP BUTTON

IconButton::IconButton( entry_ref er )
:	BView( BRect(0,0,35,35), "icon", B_FOLLOW_RIGHT|B_FOLLOW_TOP, B_WILL_DRAW ),
	large_icon( new BBitmap(BRect(0,0,31,31), B_CMAP8) ),
	small_icon( new BBitmap(BRect(0,0,15,15), B_CMAP8) ),
	mouse_down(false)
{
	info.SetTo( er );

	CommonInit();
}

IconButton::IconButton( IconInfo * ii )
:	BView( BRect(0,0,35,35), "icon", B_FOLLOW_RIGHT|B_FOLLOW_TOP, B_WILL_DRAW ),
	large_icon( new BBitmap(BRect(0,0,31,31), B_CMAP8) ),
	small_icon( new BBitmap(BRect(0,0,15,15), B_CMAP8) ),
	mouse_down(false)
{
	info = *ii;
	delete ii;
	
	CommonInit();
}

void
IconButton::CommonInit()
{
	printf("adding icon [%s] [%s]\n", info.Path(), info.MimeType() );
	
	SetViewColor( B_TRANSPARENT_COLOR );
	
	BNode node( info.EntryRef() );
	BNodeInfo n_info( &node );
	
	bool found_large = true, found_small = true;
	// large icon
	if ( n_info.GetTrackerIcon( large_icon, B_LARGE_ICON ) != B_OK )
	{
		if ( strncmp(info.MimeType(), "application/", 12) == 0 )
		{ // application, try to find app via mime signature
			entry_ref app_ref;
			
			BRoster roster;
			if ( roster.FindApp( info.MimeType(), &app_ref) == B_OK )
			{ // found!
				BFile file( &app_ref, B_READ_ONLY );
				BAppFileInfo fi( &file );
					
				if ( fi.GetIcon( large_icon, B_LARGE_ICON ) != B_OK )
					found_large = false;
			}
		} else
		{ // not an application, we're out of luck here :P
			found_large = false;
		}
	}
	// small icon
	if ( n_info.GetTrackerIcon( small_icon, B_MINI_ICON ) != B_OK )
	{
		if ( strncmp(info.MimeType(), "application/", 12) == 0 )
		{ // application, try to find app via mime signature
			entry_ref app_ref;
			
			BRoster roster;
			if ( roster.FindApp( info.MimeType(), &app_ref) == B_OK )
			{ // found!
				BFile file( &app_ref, B_READ_ONLY );
				BAppFileInfo fi( &file );
					
				if ( fi.GetIcon( small_icon, B_MINI_ICON ) != B_OK )
					found_small = false;
			}
		} else
		{ // not an application, we're out of luck here :P
			found_small = false;
		}
	}

	
	// if not found, use broken link icon
	BMimeType mt("application/x-vnd.Be-symlink");

	if (!found_large)
		if ( mt.GetIcon( large_icon, B_LARGE_ICON ) != B_OK )
			{ delete large_icon; large_icon = NULL; }
	if (!found_small)
		if ( mt.GetIcon( small_icon, B_MINI_ICON ) != B_OK )
			{ delete small_icon; small_icon = NULL; }

	// menu
	menu = new BPopUpMenu("menu");
	menu->SetRadioMode( false );
	
	menu->AddItem( new BMenuItem("Remove", new BMessage(REMOVE_ICON)) );
	menu->AddItem( new BMenuItem("Open parent folder", new BMessage(OPEN_FOLDER)) );
	menu->AddItem( new BMenuItem("Run with args", new BMessage(SHOW_RUN_WITH_ARGS_WINDOW)) );

	// helper bubble
	bubbler.SetHelp( this, info.Leaf() );
}

IconButton::~IconButton()
{
	printf( "removing icon [%s]\n",info.Path() );
	
	if (large_icon) delete large_icon;
	if (small_icon) delete small_icon;
	
	delete menu; // hm?!
	
	// remove helper text
	bubbler.SetHelp( this, NULL );
}

void
IconButton::MessageReceived( BMessage * msg )
{
	switch (msg->what)
	{
		case RUN_WITH_ARGS:
			info.SetArgs( msg->FindString("args") );
			Run( info.GetArgs() );
			break;
		case SHOW_RUN_WITH_ARGS_WINDOW:
		{
			BMessenger msgr( this, Window() );
			RunWithArgs * win = new RunWithArgs(msgr,info.Path(),info.GetArgs());
			win->Show();
		}
			break;
		case REMOVE_ICON:
			msg->AddPointer("icon", this);
			Window()->PostMessage( msg );
			break;
		case OPEN_FOLDER:
		{ // open parent folder
			BNode node( info.EntryRef() ); // make sure file exists
			
			BPath path( info.EntryRef() );
			
			if ( node.InitCheck() != B_OK )
			{ // check that path exists, try to find a correct path if not
				if ( strncmp(info.MimeType(), "application/", 12) == 0 )
				{ // application, try to find via mime signature
					BRoster roster;
					entry_ref app_ref;
					if ( roster.FindApp( info.MimeType(), &app_ref ) == B_OK )
						path.SetTo( &app_ref );
				}
			}
			BPath dir;
			path.GetParent( &dir );
			
			entry_ref ref;
			get_ref_for_path( dir.Path(), &ref );
			
			BMessage run_msg(B_REFS_RECEIVED);
			run_msg.AddRef("refs", &ref);
			
			BMimeType mime_type("application/x-vnd.Be-directory");
			char pref_sig[512];
			
			if (mime_type.GetPreferredApp(pref_sig) == B_OK)
			{
				printf("Opening folder [%s]\n", dir.Path() );
	
				BRoster roster;
				roster.Launch( pref_sig, &run_msg );
			}
		}
			break;
		case 'PSTE':
		{ // color drop
			rgb_color * col;
			ssize_t sz;
			if (msg->FindData("RGBColor",B_RGB_COLOR_TYPE, (const void**)&col, &sz) == B_OK)
			{
				BMessage win_msg(SET_ICON_COLOR);
				win_msg.AddData("color", B_RAW_TYPE, col, sizeof(rgb_color) );
				Window()->PostMessage( &win_msg );
			}
		}
			break;
		case 'DATA':
		{ // file drop
			if ( msg->IsReply() )
			{ // a reply from drop-target
				if (msg->FindString("LnLauncher"))
				{ // icon was dropped in another menu, remove from this one
					printf("Remove due to drag-n-drop\n");
					BMessage remove(REMOVE_ICON);
					remove.AddPointer("icon",this);
					window_messenger.SendMessage( &remove );
				}
			} else
			{ // a file was dropped
				int32 buttons;
				if ( msg->FindInt32("buttons",&buttons) == B_OK && (buttons & B_SECONDARY_MOUSE_BUTTON))
				{
					BMessage run_msg(*msg);
					run_msg.what = B_REFS_RECEIVED;
					Run( &run_msg );
				} else
				{
					msg->AddPointer("icon",this);
					Window()->MessageReceived( msg );
					
					BMessage reply('DATA');
					reply.AddString("LnLauncher","");
					
					msg->SendReply( &reply );
				}
			}
		}
			break;
		default:
			BView::MessageReceived( msg );
	}
}

void
IconButton::AttachedToWindow()
{
	mouse_down = false;
	menu->SetTargetForItems( this );
	
	window_messenger = BMessenger( Window() );
}

void
IconButton::DetachedFromWindow()
{
}

void
IconButton::MouseDown( BPoint )
{
	Window()->CurrentMessage()->FindInt32("buttons",&buttons);
	SetMouseEventMask( B_POINTER_EVENTS, B_LOCK_WINDOW_FOCUS );
	mouse_down = true;
	moved = false;
	
	Invalidate();
}

void
IconButton::MouseMoved( BPoint pos, uint32 transit, const BMessage * msg )
{
	if ( mouse_down && (buttons & B_PRIMARY_MOUSE_BUTTON) )
	{ // check to see if moved
		if ( !Bounds().Contains( pos ) )
		{
			int32 dir = RIGHT + 1;
			if ( pos.x < Bounds().left )
				dir = LEFT;
			if ( pos.x > Bounds().right )
				dir = RIGHT;
		
			if ( dir <= RIGHT )
			{
				BMessage msg(MOVE_ICON);
				msg.AddPointer("icon", this );
				msg.AddInt32("dir", dir );
				Window()->PostMessage( &msg );

				moved = true;
			}
		}
	}
	
	if ( mouse_down && Window() )
	{ // check to see if dragged
		if ( !Window()->Frame().Contains( ConvertToScreen( pos ) ) )
		{
			BMessage drag_msg('DATA');
			drag_msg.AddRef( "refs", info.EntryRef() );
			drag_msg.AddPointer( "icon", this );
			drag_msg.AddString("LnLauncher","");
			
			// copy icon
			BMessage msg;
			if ( large_icon && Bounds().Width() > 30 )
				large_icon->Archive( &msg );
			if ( small_icon && Bounds().Width() < 30 )
				small_icon->Archive( &msg );

			BBitmap * temp = new BBitmap( &msg );
			
			BPoint bitmap_center( temp->Bounds().Width()/2,temp->Bounds().Height()/2);
			DragMessage( &drag_msg, temp, B_OP_ALPHA, bitmap_center, Window() );
			
			mouse_down = false;
			
			Invalidate();
		}
	}

	if ( transit != B_INSIDE_VIEW && !mouse_down)
	{ // moved, no buttons
		BMessage win_msg(SET_EXPANDED);
		if ( Window()->Frame().Contains( ConvertToScreen(pos) ) )
		{
			win_msg.AddBool("expanded", true );
		} else
		{
			win_msg.AddBool("expanded", false );
		}
		Window()->PostMessage( &win_msg );
	}
}

void
IconButton::MouseUp( BPoint pos )
{
	if (!mouse_down)
		return;
	
	mouse_down = false;
	Invalidate();
	
	if ( !Bounds().Contains( pos ) || moved )
		return;
	
	if (buttons & B_PRIMARY_MOUSE_BUTTON)
	{
		Run();
	}
	if (buttons & B_SECONDARY_MOUSE_BUTTON)
	{
		menu->Go( 
			ConvertToScreen( pos ), 
			true, // delivers message
			true, // open even if no button pressed
			true  // click to close
		);
	}
}

void
IconButton::Run( BMessage * refs_msg )
{
	printf( "launching [%s]\n", info.Path() );
	BRoster roster;
	status_t launch_res = roster.Launch( info.EntryRef(), refs_msg );
	
	if (launch_res != B_OK && launch_res != B_ALREADY_RUNNING && refs_msg == NULL)
	{ // fail, try default app + entry_ref, don't try if refs_msg
		BNode node( info.Path() );
		BNodeInfo node_info( &node );
		
		// find preferred application
		bool sig_found = false;
		char pref_sig[512];
		if ( node_info.GetPreferredApp( pref_sig ) != B_OK )
		{
			BMimeType mime( info.MimeType() );
			sig_found = (mime.GetPreferredApp( pref_sig ) == B_OK);
		} else
			sig_found = true;

		if (sig_found)
		{
			printf("  fail, trying with preferred app [%s]\n",pref_sig);

			BMessage msg(B_REFS_RECEIVED);
			msg.AddRef("refs", info.EntryRef() );
			launch_res = roster.Launch( pref_sig, &msg );
		}
	}
	
	if ( launch_res != B_OK  && launch_res != B_ALREADY_RUNNING)
	{ // launch fail
		if ( strncmp(info.MimeType(), "application/", 12) == 0 )
		{ // application, try to start via mime signature
			printf("  fail, trying with signature [%s]\n",info.MimeType() );
			launch_res = roster.Launch( info.MimeType(), refs_msg );
		}
	}
}

void
IconButton::Run( const char * args )
{
	if (!args)
	{
		printf("Invalid args argument\n");
		return;
	}
	
	if ( strncmp(info.MimeType(), "application/", 12) != 0 )
	{
		printf("Can only launch applications with arguments!\n");
		return;
	}
	
	printf("Launching [%s] with args [%s]\n",info.Path(), args );
	char * argv[256];
	int num_arg = 0;
	/*
		convert single string to array of strings
	*/
	const char * curr = args;
	const char * start = NULL;
	while ( *curr )
	{
		while ( *curr == ' ' ) curr++;
		start = curr;

		if ( *curr == '"' )
		{ // multi-word arg
			curr++; start++;
			while ( *curr && *curr != '"' ) curr++;
		} else {
			while ( *curr && *curr != ' ' ) curr++;
		}
		
		uint32 len = (uint32)curr - (uint32)start;

		if ( *curr == '"' ) curr++; // skip '"' if needed

		argv[num_arg] = new char[ len + 1 ];
		strncpy(argv[num_arg], start, len );
		argv[num_arg][len] = 0;
		
		num_arg++;
	}
	
	/*
		Launch
	*/
	BRoster roster;
	status_t launch_res = roster.Launch( info.EntryRef(), num_arg, argv );

	if ( launch_res != B_OK  && launch_res != B_ALREADY_RUNNING)
	{ // launch fail, try with mime signature
		printf("  fail, trying with signature [%s]\n",info.MimeType() );
		launch_res = roster.Launch( info.MimeType(), num_arg, argv );
		if ( launch_res != B_OK )
			printf("  fail\n");
	}

	for (int c=0; c<num_arg; c++)
	{ // free argv
		delete [] argv[c];
	}
}

void
IconButton::Draw( BRect )
{
	rgb_color light  = ViewColor();
	rgb_color bright = ViewColor();
	rgb_color dark   = ViewColor();

	// set up colors
	if ( bright.red < 175 )   bright.red += 80;   else bright.red = 255;
	if ( bright.green < 175 ) bright.green += 80; else bright.green = 255;
	if ( bright.blue < 175 )  bright.blue += 80;  else bright.blue = 255;

	if ( dark.red > 79 )   dark.red -= 80;   else dark.red = 0;
	if ( dark.green > 79 ) dark.green -= 80; else dark.green = 0;
	if ( dark.blue > 79 )  dark.blue -= 80;  else dark.blue = 0;
	
	if ( mouse_down )
	{
		light	= tint_color( light, B_HIGHLIGHT_BACKGROUND_TINT );
		bright	= tint_color( bright, B_HIGHLIGHT_BACKGROUND_TINT );
		dark	= tint_color( dark, B_HIGHLIGHT_BACKGROUND_TINT );
	}
	
	BRect bounds = Bounds();
	
	// border
	MovePenTo( bounds.RightTop() );
	
	SetHighColor( bright );		
	StrokeLine( bounds.LeftTop() );
	StrokeLine( bounds.LeftBottom() );
	
	SetHighColor( dark );
	StrokeLine( bounds.RightBottom() );
	StrokeLine( bounds.RightTop() );
	
	// interior
	BRect temp = bounds; temp.InsetBy(1,1);
	SetHighColor( light );		FillRect( temp );

	if (large_icon && Bounds().Width() > 30)
	{
		SetBlendingMode( B_PIXEL_ALPHA, B_ALPHA_OVERLAY );
		SetDrawingMode( B_OP_ALPHA );
		DrawBitmap( large_icon, BPoint(2,2) );
	} else
	if (small_icon)
	{
		SetBlendingMode( B_PIXEL_ALPHA, B_ALPHA_OVERLAY );
		SetDrawingMode( B_OP_ALPHA );
		DrawBitmap( small_icon, BPoint(2,2) );
	}

}

const IconInfo *
IconButton::Info() const
{
	return &info;
}
