#ifndef DEFS_H
#define DEFS_H

#include "BubbleHelper.h"

enum {
	TOGGLE_EXPANDED,			
	SET_EXPANDED,				
	ADJUST_SIZE,				
	REMOVE_ICON,				
	MOVE_ICON,					
	MOVE_TO_POS,				
	SET_EXPAND_ON_MOUSE_OVER,	// bool
	SET_SCROLL_SPEED,			// int32
	SET_LARGE_ICONS,			// bool
	NEW_WINDOW,					// forward to MyApp
	NEW_RECENT_WINDOW,			// forward to MyApp
	SET_ICON_COLOR,				
	SET_HANDLE_COLOR,			
	SET_ALL_COLOR,				
	SET_ALWAYS_ON_TOP,			
	REMOVE_WINDOW,				
	OPEN_FOLDER,				// used by IconButton
	SAVE,						
	RESCUE_TRACKER,				
	RESCUE_DESKBAR,				
	RESCUE_TERMINAL,			
	HIDE_REPLICANTS,			
	SHOW_REPLICANTS,			
	SHOW_RUN_WITH_ARGS_WINDOW,	
	RUN_WITH_ARGS				
};
enum { // which side of the screen is the menu attached to?
	LEFT,
	RIGHT
};

extern BubbleHelper bubbler;

#endif
