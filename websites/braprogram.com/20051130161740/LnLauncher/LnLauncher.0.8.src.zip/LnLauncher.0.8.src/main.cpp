#include "main.h"
#include "defs.h"

#include <Application.h>
#include <stdio.h>
#include <String.h>
#include <Directory.h>
#include <FindDirectory.h>
#include <Path.h>

BubbleHelper bubbler;

MyApp::MyApp()
:	BApplication("application/x-vnd.m_eiman.LnLauncher"),
	saved(false)
{
}

thread_id
MyApp::Run()
{
	bool settings_ok = false;
	BMessage settings;
	
	// find settings dir+file
	BPath path;
	find_directory(B_USER_SETTINGS_DIRECTORY, &path);
	
	BString path_str = path.Path();
	path_str += "/LnLauncher.data";
	BFile file(path_str.String(), B_READ_ONLY);
	
	if ( file.InitCheck() == B_OK )
	{	// read settings
		off_t file_size;
		file.GetSize( &file_size );
		
		char * buf = new char[file_size];
		if ( file.Read( buf, file_size ) == file_size )
		{
			if (settings.Unflatten( buf ) == B_OK && settings.what == APP_SETTINGS)
				settings_ok = true;
		}
	}
	
	if ( settings_ok )
	{	// load settings
		printf("settings ok\n");
		BMessage win_settings;
		for (int c=0; settings.FindMessage("window",c,&win_settings) == B_OK;c++)
		{
			switch ( win_settings.what )
			{
				case MenuWindow::WIN_SETTINGS:
					NewWindow( &win_settings );
					break;
				case MenuWindow::RECENT_SETTINGS:
					NewRecentWindow( &win_settings );
					break;
			}
		}
	}
	
	if ( windows.NumItems() == 0 ) 
	{ // add default window if needed
		BMessage dummy;
		NewWindow( &dummy );
	}
	
	return BApplication::Run();
}

MyApp::~MyApp()
{
}

void
MyApp::MessageReceived( BMessage * msg )
{
	switch (msg->what)
	{
		case SAVE:
			Save();
			break;
		case REMOVE_WINDOW:
		{
			BWindow * win = NULL;
			if ( msg->FindPointer("window", (void**)&win) == B_OK )
			{
				if (windows.NumItems() > 1)
				{ // don't remove the last window
					windows -= (MenuWindow*)win;
					win->Lock();
					win->Quit();

					Save();
				}
			}
		}
			break;
		case NEW_WINDOW:
			NewWindow( msg );
			break;
		case NEW_RECENT_WINDOW:
			NewRecentWindow( msg );
			break;
		default:
			BApplication::MessageReceived(msg);
	}
}

bool
MyApp::QuitRequested()
{
	Save();
	return true;
}

void
MyApp::NewWindow( BMessage * settings )
{
	MenuWindow * win = new MenuWindow( settings );
	win->Show();
	win->Lock();
	win->WorkspaceActivated( 0, true );
	win->Unlock();
	windows += win;

	float ypos = windows[windows.NumItems()-1]->Frame().top;
	win->MoveTo( win->Frame().left, ypos );
}

void
MyApp::NewRecentWindow( BMessage * settings )
{
	MenuWindow * win = new RecentMenuWindow( settings );
	win->Show();
	win->Lock();
	win->WorkspaceActivated( 0, true );
	win->Unlock();
	windows += win;

	float ypos = windows[windows.NumItems()-1]->Frame().top;
	win->MoveTo( win->Frame().left, ypos );
}

void
MyApp::Save()
{	// save settings (saves all menus)
	BMessage file_msg(APP_SETTINGS);
	
	// save window settings
	for (int c=0; windows[c]; c++)
	{
		BMessage settings;
		windows[c]->Save( &settings );

		file_msg.AddMessage("window", &settings);
	}

	// write to disk
	BPath path;
	find_directory(B_USER_SETTINGS_DIRECTORY, &path);
	
	BString path_str = path.Path();
	path_str += "/LnLauncher.data";

	BDirectory dir; dir.CreateFile(path_str.String(), NULL);
	BFile file(path_str.String(), B_WRITE_ONLY);
	
	if ( file.InitCheck() == B_OK )
	{
		ssize_t sz = file_msg.FlattenedSize();
		
		char * buf = new char[sz];
		file_msg.Flatten( buf, sz );
		
		printf("wrote %ld bytes to settings\n",file.Write( buf, sz ));
	}
}

// MAIN

int main()
{
	MyApp app;
			
	app.Run();

	return 0;
};
