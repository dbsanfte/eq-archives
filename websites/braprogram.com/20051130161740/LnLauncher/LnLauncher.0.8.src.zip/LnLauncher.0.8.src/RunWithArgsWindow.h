#ifndef RUN_WITH_ARGS_H
#define RUN_WITH_ARGS_H

#include <Window.h>
#include <TextControl.h>

/*
	A small window containing a BtextControl, to edit commandline arguments
	for apps
*/
class RunWithArgs : public BWindow
{
	public:
		RunWithArgs( BMessenger, const char * _path, const char * _argv );
		virtual ~RunWithArgs();
		
		virtual void MessageReceived( BMessage * );
		virtual bool QuitRequested();
	
	protected:
		BMessenger		target;
		BTextControl	* argsText;
};

#endif
