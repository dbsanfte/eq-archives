#ifndef EXPAND_BUTTON_H
#define EXPAND_BUTTON_H

#include <PopUpMenu.h>
#include <MenuItem.h>

/*
	The handle that controls the menu
*/
class ExpandButton : public BView
{
	public:
		ExpandButton( BRect, BMessage * );
		virtual ~ExpandButton();
		
		virtual void MessageReceived( BMessage * );
		virtual void Draw( BRect );
		virtual void MouseDown( BPoint );
		virtual void MouseMoved( BPoint, uint32, const BMessage *);
		virtual void MouseUp( BPoint );
		virtual void AttachedToWindow();

	protected:
		BPopUpMenu	* menu;
		BPopUpMenu	* menu_scroll_speed;
		BPopUpMenu	* menu_color;
		BPopUpMenu	* menu_window;
		BPopUpMenu	* menu_rescue;
		BPopUpMenu	* menu_replicants;
		BPopUpMenu	* menu_shutdown;
		BMenuItem	* item_on_mouse_over;
		BMenuItem	* item_large_icons;
		BMenuItem	* item_always_on_top;
		
		int32		buttons;
		BPoint		mouse_click_at;
		bool		mouse_down;
		bool		expanded;
		bool		expand_on_mouse_over;
		bool		large_icons;
		bool		has_moved;
		bool		always_on_top;
};

#endif
