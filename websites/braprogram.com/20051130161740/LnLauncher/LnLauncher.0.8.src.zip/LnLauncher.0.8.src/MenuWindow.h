#ifndef MENU_WINDOW_H
#define MENU_WINDOW_H

#include "ExpandButton.h"

#include "LnList.h"

#include <Window.h>
#include <NodeInfo.h>

/*
	Container for the menu, also redirects and broadcasts certain BMessages
*/
class MenuWindow : public BWindow
{
	public:
		MenuWindow( BMessage * );
		virtual ~MenuWindow();
		
		virtual bool QuitRequested();
		virtual void MessageReceived( BMessage * );
		virtual void WorkspaceActivated( int32, bool );
		virtual void WindowActivated( bool );
						
		void ToggleExpanded();
		virtual void SetExpanded( bool );
		void AdjustSize();
		void FileDrop( BMessage * );
		void RemoveIcon( BMessage * );
		void RearrangeIcons();
		void MoveIcon( BMessage * );
		void MoveToEdge( int32 );
		void MoveToPos( BMessage * );
		void SetIconSize( icon_size );
		void SetColor( BMessage * );
		
		virtual void Save( BMessage * );

		enum {
			WIN_SETTINGS = 'llWS',
			RECENT_SETTINGS = 'llRS'
		};
		
	protected:
		List<BView>		icons;
		bool			expanded;
		ExpandButton	* expandButton;
		int32			dock_edge;
		int32			scroll_delay;
		bool			expand_on_mouse_over;
		bool			large_icons;
		bool			always_on_top;
		rgb_color		handle_color, icon_color;
		BPoint			curr_pos;
};


class RecentMenuWindow : public MenuWindow
{
	public:
		RecentMenuWindow( BMessage * );
		virtual ~RecentMenuWindow();
		
		virtual void SetExpanded( bool );
		virtual void Save( BMessage * );
};

#endif
