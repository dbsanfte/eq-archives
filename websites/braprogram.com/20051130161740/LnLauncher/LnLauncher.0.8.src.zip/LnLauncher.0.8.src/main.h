#ifndef MAIN_H
#define MAIN_H

#include <Application.h>

#include "LnList.h"

#include "MenuWindow.h"

/*
	Fairly simple application class. Handles saving/loading of settings.
*/
class MyApp : public BApplication
{
	public:
		MyApp();
		virtual ~MyApp();
	
		virtual bool QuitRequested();
		virtual thread_id Run();		
		virtual void MessageReceived( BMessage * );
		
		void Save();
		void NewWindow( BMessage * ); // msg == settings
		void NewRecentWindow( BMessage * ); // msg == settings
		
	protected:
		List<MenuWindow>	windows;
		enum {
			APP_SETTINGS = 'llAS'
		};
		bool	saved;
};

#endif
