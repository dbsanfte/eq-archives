EQClient INI Writer

Thanks for using this app. I didn't put a lot of work into it so dog it all you want! =)

If have any bugs let me know at enoch100@hotmail.com


General Usage Notes:

When you start the app, you see an open dialog box on your screen. If you don't have
and INI file already setup, than select cancel. Otherwise, find your INI file and select
OPEN. You should than see a list of color names with a small box next to each. To change
a color, click on that box and set you Red, Green and Blue values with the scroll bars.
Once you have the color you like, hit the select key. Do this for each color. Than select
your runmode and screenmode. When all is finished, either save and exit. Than run EQ as normal.



Hope you enjoy!
Gresham Dagor, Erudite Enchanter, Seekers of Lore on Veeshan

Version Update: Fixed Numbering scheme in INI to actually work again.



FREEWARE! USE THIS ALL YOU WANT. SEND IT AROUND! PUT IT ON WEBSITES! JUST BE SURE
TO GIVE CREDIT WHERE CREDIT IS DUE. (um, that would be me... hehe)