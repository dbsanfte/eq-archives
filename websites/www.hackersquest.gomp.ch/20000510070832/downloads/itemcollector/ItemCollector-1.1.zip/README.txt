(WARNING: If you did not download this files from www.hackersquest.gomp.ch
 please delete them and download them from the above site.)
 
ItemCollector 1.1

What it does:
It records all items and their stats.

What it does not:
Anything beside recording items.
It does NOT open a connection to any other computer than the everquest servers.
It does NOT send / save your password anywhere.
It does NOT interfer with the gameplay in any way.
It does NOT change packets in any way.

This tool will help us to collect all kinds of items and their stats.
Due to the sheer amount of different items in EverQuest its impossible
for us to record them alone (all that fancy no drop items are hard to come by).

Currently the database has 1869 items recorded. Please help us to get as many as possible.

How to use:
Unzip the EqDll.dll and the ItemCollector.exe into your EverQuest Directory.
Just start ItemCollector.exe. It will record the items you see ingame
(trade window, vendor, on you, on your bank, on corpses).
The item data is saved to a file called items.crc in your EverQuest Directory.

How to submit the recorded items:
Go to your EverQuest Directory and rename the items.crc file to your nickname.crc.
(So I know whom to credit). 
Email the file as attachment to ashran@mcb.at.
Please delete the item file after!
(To reduce the CPU amount takes by the program I have chosen to make the database 
as simple as possible, it wont overwrite duplicate items, but just ignore them ..
and because of that I would not get updated stats if you keep the old file)

If you dont trust me, just change your password, enter the game with one or more characters,
camp out or /quit and change your password again.


.........
Soon I will either have up a script to view those items online, or a program to browse the
items offline. (Depends if i find a host which allows NT executables on servers :)

-- (c) HackersQuest
-- Ashran ( ashran@mcb.at )
-- www.hackersquest.gomp.ch

EverQuest is a registered trademark, and 989 Studios and the 989 Studios logo are 
trademarks of Sony Computer Entertainment America, Inc.

This program and / or HackersQuest is in no way affilated with Verant.