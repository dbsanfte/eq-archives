EthernalQuest Initial Beta release notes.
(www.ethernalquest.org)

You need to edit all of the script files in the /script/ directory!
(Scripts contains instructions)

If you want other peoples to log into your server, 
just edit the ip.ini file in EmuLog.zip to reflect your ip.
Then distribute it. =)

Have fun!

ps.: if you are the only person who will use the emu, you dont need to edit anything.
just extract emulog into the EQ directory, start the emulator executables, 
and start EmuLog =)

Have fun!
