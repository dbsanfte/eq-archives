function OnInit()
{
	/* Banner text */
	SetBanner("Welcome to EthernalQuest. www.EthernalQuest.org");
	
	/* Name of the world server */
	SetWorldServerName("EthernalQuest Beta Server");
	
	/* IP of the pc with the world server (char select) running on */
	SetWorldServerIP("127.0.0.1");
	
	/* Enter Local IP here  */
	SetChatServerIP("127.0.0.1");	
	
	/* Client Version .. Do not modify */
	SetVersion("6-13-2000 19:15");
}