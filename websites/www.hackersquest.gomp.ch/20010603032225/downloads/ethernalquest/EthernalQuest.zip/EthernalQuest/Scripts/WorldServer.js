function OnInit()
{
	/* IP of the pc with the zone server running on */
	SetZoneServerIP("127.0.0.1");

	/* which zone name shows up on the char select */
	SetZone("qeynos");
}