function OnInit()
{
	/* which zone to boot */
	SetZone("qeynos");
	
	/* starting location */
	SetStartingLocation(100 /* x */, 100 /* y */, 300 /* z */);
	
	/*
		A few valid locations:
					x		 y		   z
		solb		-212.31  -459.48   -108.84
		veeshan		1650     10        200
		TimDeep     2750     6500      200
	*/
}