(WARNING: If you did not download this file from www.hackersquest.gomp.ch
 please delete it and download it from the above site.)
 
ItemCollector 2.01

What it does:
It records item stats.

Everything 
.... you wear.
.... in your inventory.
.... you see in a tradewindow.
.... you see on a corpse.
.... you see on a vendor.

How to see item stats:
Double click on an item in the list view.

What it does not:
Anything beside recording items.
It does NOT send / save your EverQuest Username / Password anywhere.
It does NOT interfer with the gameplay in any way.
It does NOT change packets in any way.

This tool will help us to collect all kinds of items and their stats.
Due to the sheer amount of different items in EverQuest its impossible
for us to record them alone (all that fancy no drop items are hard to come by).

Currently the database has over 4000 items recorded. Please help us to get as many as possible.

How to use:
Unzip the EqDll.dll and the ItemCollector.exe into your EverQuest Directory.
Just start ItemCollector.exe. It will record the items you see ingame
(trade window, vendor, on you, on your bank, on corpses).

You will be able to see what items you have recorded after you quit EQ.
Please press submit to send us the current item stats. No backtraceable info is submitted.



.........

-- (c) HackersQuest
-- Ashran ( ashran@mcb.at )
-- www.hackersquest.gomp.ch

EverQuest is a registered trademark, and 989 Studios and the 989 Studios logo are 
trademarks of Sony Computer Entertainment America, Inc.

This program and / or HackersQuest is in no way affilated with Verant.

This program is free. The current version is 2.01 and it's still beta, 
although I couldn't find any errors. Use it at your own risk, 
I'm not responsible for anything the program does 
[now don't worry this is just some legal stuff I have to mention =)]. 