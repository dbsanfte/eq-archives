/****************************************************************************
** EQInterface meta object code from reading C++ file 'interface.h'
**
** Created: Tue Jun 6 01:15:45 2000
**      by: The Qt Meta Object Compiler ($Revision: 2.53 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#define Q_MOC_EQInterface
#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 3
#elif Q_MOC_OUTPUT_REVISION != 3
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "interface.h"
#include <qmetaobject.h>
#include <qapplication.h>

#if defined(Q_SPARCWORKS_FUNCP_BUG)
#define Q_AMPERSAND
#else
#define Q_AMPERSAND &
#endif


const char *EQInterface::className() const
{
    return "EQInterface";
}

QMetaObject *EQInterface::metaObj = 0;


#if QT_VERSION >= 199
static QMetaObjectInit init_EQInterface(&EQInterface::staticMetaObject);

#endif

void EQInterface::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QMainWindow::className(), "QMainWindow") != 0 )
	badSuperclassWarning("EQInterface","QMainWindow");

#if QT_VERSION >= 199
    staticMetaObject();
}

QString EQInterface::tr(const char* s)
{
    return ((QNonBaseApplication*)qApp)->translate("EQInterface",s);
}

void EQInterface::staticMetaObject()
{
    if ( metaObj )
	return;
    QMainWindow::staticMetaObject();
#else

    QMainWindow::initMetaObject();
#endif

    typedef void(EQInterface::*m1_t0)(int,int);
    typedef void(EQInterface::*m1_t1)(int,int);
    typedef void(EQInterface::*m1_t2)();
    typedef void(EQInterface::*m1_t3)(int,int,int);
    typedef void(EQInterface::*m1_t4)(int,int);
    typedef void(EQInterface::*m1_t5)(int,int);
    typedef void(EQInterface::*m1_t6)(int,int,int,int,int,int);
    typedef void(EQInterface::*m1_t7)(const QString&);
    typedef void(EQInterface::*m1_t8)(const QString&,int);
    typedef void(EQInterface::*m1_t9)(int);
    typedef void(EQInterface::*m1_t10)(int);
    typedef void(EQInterface::*m1_t11)();
    typedef void(EQInterface::*m1_t12)();
    typedef void(EQInterface::*m1_t13)();
    typedef void(EQInterface::*m1_t14)(QListViewItem*,const QPoint&,int);
    typedef void(EQInterface::*m1_t15)();
    typedef void(EQInterface::*m1_t16)();
    typedef void(EQInterface::*m1_t17)();
    typedef void(EQInterface::*m1_t18)();
    typedef void(EQInterface::*m1_t19)();
    typedef void(EQInterface::*m1_t20)();
    typedef void(EQInterface::*m1_t21)();
    typedef void(EQInterface::*m1_t22)();
    typedef void(EQInterface::*m1_t23)();
    typedef void(EQInterface::*m1_t24)();
    typedef void(EQInterface::*m1_t25)();
    typedef void(EQInterface::*m1_t26)();
    typedef void(EQInterface::*m1_t27)();
    typedef void(EQInterface::*m1_t28)();
    typedef void(EQInterface::*m1_t29)();
    typedef void(EQInterface::*m1_t30)();
    typedef void(EQInterface::*m1_t31)();
    typedef void(EQInterface::*m1_t32)();
    typedef void(EQInterface::*m1_t33)();
    typedef void(EQInterface::*m1_t34)();
    typedef void(EQInterface::*m1_t35)();
    m1_t0 v1_0 = Q_AMPERSAND EQInterface::addSkill;
    m1_t1 v1_1 = Q_AMPERSAND EQInterface::changeSkill;
    m1_t2 v1_2 = Q_AMPERSAND EQInterface::deleteSkills;
    m1_t3 v1_3 = Q_AMPERSAND EQInterface::expChanged;
    m1_t4 v1_4 = Q_AMPERSAND EQInterface::hpChanged;
    m1_t5 v1_5 = Q_AMPERSAND EQInterface::manaChanged;
    m1_t6 v1_6 = Q_AMPERSAND EQInterface::stamChanged;
    m1_t7 v1_7 = Q_AMPERSAND EQInterface::msgReceived;
    m1_t8 v1_8 = Q_AMPERSAND EQInterface::stsMessage;
    m1_t9 v1_9 = Q_AMPERSAND EQInterface::numSpawns_;
    m1_t10 v1_10 = Q_AMPERSAND EQInterface::numPacket;
    m1_t11 v1_11 = Q_AMPERSAND EQInterface::savePrefs;
    m1_t12 v1_12 = Q_AMPERSAND EQInterface::addCategory;
    m1_t13 v1_13 = Q_AMPERSAND EQInterface::reloadCategories;
    m1_t14 v1_14 = Q_AMPERSAND EQInterface::spawnListRightButton;
    m1_t15 v1_15 = Q_AMPERSAND EQInterface::toggle_log_AllPackets;
    m1_t16 v1_16 = Q_AMPERSAND EQInterface::toggle_log_ZoneData;
    m1_t17 v1_17 = Q_AMPERSAND EQInterface::toggle_log_UnknownData;
    m1_t18 v1_18 = Q_AMPERSAND EQInterface::toggle_opt_Velocity;
    m1_t19 v1_19 = Q_AMPERSAND EQInterface::toggle_opt_Animate;
    m1_t20 v1_20 = Q_AMPERSAND EQInterface::toggle_opt_Fast;
    m1_t21 v1_21 = Q_AMPERSAND EQInterface::toggle_vew_UnknownData;
    m1_t22 v1_22 = Q_AMPERSAND EQInterface::toggle_vew_FilteredSpawns;
    m1_t23 v1_23 = Q_AMPERSAND EQInterface::toggle_vew_HiddenSpawns;
    m1_t24 v1_24 = Q_AMPERSAND EQInterface::toggle_vew_ChannelMsgs;
    m1_t25 v1_25 = Q_AMPERSAND EQInterface::toggle_vew_ExpWindow;
    m1_t26 v1_26 = Q_AMPERSAND EQInterface::toggle_opt_ConSelect;
    m1_t27 v1_27 = Q_AMPERSAND EQInterface::toggle_opt_KeepSelectedVisible;
    m1_t28 v1_28 = Q_AMPERSAND EQInterface::toggle_opt_SparrMessages;
    m1_t29 v1_29 = Q_AMPERSAND EQInterface::toggle_opt_LogSpawns;
    m1_t30 v1_30 = Q_AMPERSAND EQInterface::toggle_vew_SpawnList;
    m1_t31 v1_31 = Q_AMPERSAND EQInterface::toggle_vew_PlayerStats;
    m1_t32 v1_32 = Q_AMPERSAND EQInterface::toggle_vew_Compass;
    m1_t33 v1_33 = Q_AMPERSAND EQInterface::toggle_vew_PlayerSkills;
    m1_t34 v1_34 = Q_AMPERSAND EQInterface::toggle_vew_Map;
    m1_t35 v1_35 = Q_AMPERSAND EQInterface::createMessageBox;
    QMetaData *slot_tbl = QMetaObject::new_metadata(36);
    slot_tbl[0].name = "addSkill(int,int)";
    slot_tbl[1].name = "changeSkill(int,int)";
    slot_tbl[2].name = "deleteSkills()";
    slot_tbl[3].name = "expChanged(int,int,int)";
    slot_tbl[4].name = "hpChanged(int,int)";
    slot_tbl[5].name = "manaChanged(int,int)";
    slot_tbl[6].name = "stamChanged(int,int,int,int,int,int)";
    slot_tbl[7].name = "msgReceived(const QString&)";
    slot_tbl[8].name = "stsMessage(const QString&,int)";
    slot_tbl[9].name = "numSpawns_(int)";
    slot_tbl[10].name = "numPacket(int)";
    slot_tbl[11].name = "savePrefs()";
    slot_tbl[12].name = "addCategory()";
    slot_tbl[13].name = "reloadCategories()";
    slot_tbl[14].name = "spawnListRightButton(QListViewItem*,const QPoint&,int)";
    slot_tbl[15].name = "toggle_log_AllPackets()";
    slot_tbl[16].name = "toggle_log_ZoneData()";
    slot_tbl[17].name = "toggle_log_UnknownData()";
    slot_tbl[18].name = "toggle_opt_Velocity()";
    slot_tbl[19].name = "toggle_opt_Animate()";
    slot_tbl[20].name = "toggle_opt_Fast()";
    slot_tbl[21].name = "toggle_vew_UnknownData()";
    slot_tbl[22].name = "toggle_vew_FilteredSpawns()";
    slot_tbl[23].name = "toggle_vew_HiddenSpawns()";
    slot_tbl[24].name = "toggle_vew_ChannelMsgs()";
    slot_tbl[25].name = "toggle_vew_ExpWindow()";
    slot_tbl[26].name = "toggle_opt_ConSelect()";
    slot_tbl[27].name = "toggle_opt_KeepSelectedVisible()";
    slot_tbl[28].name = "toggle_opt_SparrMessages()";
    slot_tbl[29].name = "toggle_opt_LogSpawns()";
    slot_tbl[30].name = "toggle_vew_SpawnList()";
    slot_tbl[31].name = "toggle_vew_PlayerStats()";
    slot_tbl[32].name = "toggle_vew_Compass()";
    slot_tbl[33].name = "toggle_vew_PlayerSkills()";
    slot_tbl[34].name = "toggle_vew_Map()";
    slot_tbl[35].name = "createMessageBox()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    slot_tbl[4].ptr = *((QMember*)&v1_4);
    slot_tbl[5].ptr = *((QMember*)&v1_5);
    slot_tbl[6].ptr = *((QMember*)&v1_6);
    slot_tbl[7].ptr = *((QMember*)&v1_7);
    slot_tbl[8].ptr = *((QMember*)&v1_8);
    slot_tbl[9].ptr = *((QMember*)&v1_9);
    slot_tbl[10].ptr = *((QMember*)&v1_10);
    slot_tbl[11].ptr = *((QMember*)&v1_11);
    slot_tbl[12].ptr = *((QMember*)&v1_12);
    slot_tbl[13].ptr = *((QMember*)&v1_13);
    slot_tbl[14].ptr = *((QMember*)&v1_14);
    slot_tbl[15].ptr = *((QMember*)&v1_15);
    slot_tbl[16].ptr = *((QMember*)&v1_16);
    slot_tbl[17].ptr = *((QMember*)&v1_17);
    slot_tbl[18].ptr = *((QMember*)&v1_18);
    slot_tbl[19].ptr = *((QMember*)&v1_19);
    slot_tbl[20].ptr = *((QMember*)&v1_20);
    slot_tbl[21].ptr = *((QMember*)&v1_21);
    slot_tbl[22].ptr = *((QMember*)&v1_22);
    slot_tbl[23].ptr = *((QMember*)&v1_23);
    slot_tbl[24].ptr = *((QMember*)&v1_24);
    slot_tbl[25].ptr = *((QMember*)&v1_25);
    slot_tbl[26].ptr = *((QMember*)&v1_26);
    slot_tbl[27].ptr = *((QMember*)&v1_27);
    slot_tbl[28].ptr = *((QMember*)&v1_28);
    slot_tbl[29].ptr = *((QMember*)&v1_29);
    slot_tbl[30].ptr = *((QMember*)&v1_30);
    slot_tbl[31].ptr = *((QMember*)&v1_31);
    slot_tbl[32].ptr = *((QMember*)&v1_32);
    slot_tbl[33].ptr = *((QMember*)&v1_33);
    slot_tbl[34].ptr = *((QMember*)&v1_34);
    slot_tbl[35].ptr = *((QMember*)&v1_35);
    typedef void(EQInterface::*m2_t0)(int);
    typedef void(EQInterface::*m2_t1)(int);
    typedef void(EQInterface::*m2_t2)(int);
    m2_t0 v2_0 = Q_AMPERSAND EQInterface::ShowFilteredSpawns;
    m2_t1 v2_1 = Q_AMPERSAND EQInterface::ShowHidden;
    m2_t2 v2_2 = Q_AMPERSAND EQInterface::newMessage;
    QMetaData *signal_tbl = QMetaObject::new_metadata(3);
    signal_tbl[0].name = "ShowFilteredSpawns(int)";
    signal_tbl[1].name = "ShowHidden(int)";
    signal_tbl[2].name = "newMessage(int)";
    signal_tbl[0].ptr = *((QMember*)&v2_0);
    signal_tbl[1].ptr = *((QMember*)&v2_1);
    signal_tbl[2].ptr = *((QMember*)&v2_2);
    metaObj = QMetaObject::new_metaobject(
	"EQInterface", "QMainWindow",
	slot_tbl, 36,
	signal_tbl, 3 );
}

// SIGNAL ShowFilteredSpawns
void EQInterface::ShowFilteredSpawns( int t0 )
{
    activate_signal( "ShowFilteredSpawns(int)", t0 );
}

// SIGNAL ShowHidden
void EQInterface::ShowHidden( int t0 )
{
    activate_signal( "ShowHidden(int)", t0 );
}

// SIGNAL newMessage
void EQInterface::newMessage( int t0 )
{
    activate_signal( "newMessage(int)", t0 );
}


const char *CFilterDlg::className() const
{
    return "CFilterDlg";
}

QMetaObject *CFilterDlg::metaObj = 0;


#if QT_VERSION >= 199
static QMetaObjectInit init_CFilterDlg(&CFilterDlg::staticMetaObject);

#endif

void CFilterDlg::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QDialog::className(), "QDialog") != 0 )
	badSuperclassWarning("CFilterDlg","QDialog");

#if QT_VERSION >= 199
    staticMetaObject();
}

QString CFilterDlg::tr(const char* s)
{
    return ((QNonBaseApplication*)qApp)->translate("CFilterDlg",s);
}

void CFilterDlg::staticMetaObject()
{
    if ( metaObj )
	return;
    QDialog::staticMetaObject();
#else

    QDialog::initMetaObject();
#endif

    metaObj = QMetaObject::new_metaobject(
	"CFilterDlg", "QDialog",
	0, 0,
	0, 0 );
}
