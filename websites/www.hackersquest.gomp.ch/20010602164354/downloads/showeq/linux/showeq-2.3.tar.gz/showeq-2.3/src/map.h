/*
 * map.h
 *
 * ShowEQ Distributed under GPL
 * http://www.hackersquest.gomp.ch/
 */

#ifndef EQMAP_H
#define EQMAP_H

#include <qwidget.h>
#include <qlistview.h>
#include <qpixmap.h>
#include <qsize.h>
#include <qmap.h>
#include <qdialog.h>
#include <qcombobox.h>
#include <qlineedit.h>
#include <qlabel.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>

#include "everquest.h"
#include "spawnlist.h"

class Filter;

class CLineDlg : public QDialog
{
   Q_OBJECT
 public:
   CLineDlg(QWidget *parent, QString name, QWidget *map);

   QComboBox *m_LineColor;
   QLineEdit *m_LineName;
   QFrame    *m_ColorPreview;
 public slots:
   void changeColor(const QString &);
};

struct trackPoint{
int x, y, z;
struct trackPoint *next;
};

class Map :public QWidget
{
   Q_OBJECT

 public:
//   Map (QListView * lv = 0, QWidget * parent =
   Map (CSpawnList* lv = 0, QWidget * parent =
	0, const char *name = 0);
   ~Map(void);

   QSize sizeHint() const; // preferred size
   QSize minimumSizeHint() const; // minimum size
   QSizePolicy sizePolicy() const; // size policy
   QRect getRect()         { return rect(); }
   
   QString curLineColor;
   QString curLineName;

 public slots:   

   void addGroup(char*, int);
   void remGroup(char*, int);
   void clrGroup();

   void makeSpawnLine(int n);
   void makeSelectedSpawnLine();

   void showLineDlg();
   void ZoomIn ();
   void ZoomOut ();
   void selectSpawn (QListViewItem * slv);
   void dumpSpawns (void);
   void loadMap (void);
   void saveMap (void);
   void newZone (char *zLong, char *zShort);
   void zoneChanged (void);
   void setLineName(const QString &);
   void setLineColor(const QString &);

   void attack1Hand1(attack1Struct *);
   void attack2Hand1(attack2Struct *);

   void consMessage(considerStruct *);
   
  /*void newSpawn (char *name, int level, int x, int y, int hp, int maxhp,
		 int spawntype, int id, char * race, char * class_, char * info,
		 int selected);*/

  void newSpawn (spawnStruct *aspawn, int selected);

  void newGroundItem (dropThingOnGround *);
  void removeGroundItem(removeThingOnGround*);
  void newCoinsItem (dropCoinsStruct *);
  void removeCoinsItem(removeCoinsStruct *);

  void updateSpawn (int id, int x, int y, int z, int xVel, int yVel, int zVel);
  void updateSpawnHp (int id, int hp, int maxhp);
  void spawnWearingUpdate(wearChangeStruct *wearing);
  void setPlayerID (int);

  void refreshMap (void);
  void deleteSpawn (int id);
  void killSpawn (int id);
  void infoSpawn (int id);
  void ShowHidden(int);
  void HideSelected(void);
  void UnHideAll(void);
  void rightButtonPressed(QListViewItem *, const QPoint &, int);
  void rightButtonReleased(QListViewItem *, const QPoint &, int);
  void saveFilters(void);
  void loadFilters(void);
  void listFilters(void);
  void setFilename (char *newfilename);
  void setPlayer (int x, int y, int z, int Dx, int Dy, int Dz, int degrees);
  void setPlayerLevel (int level);
  void ToggleFilterSelected(void);
  void setPlayerRace(int race);
  void setPlayerClass(int class_);
  void addLocation ();
  void startLine ();
  void addLinePoint ();
  void delLinePoint(void);
  void setAngle (int degrees);
  void toggleDebug(void);
  void selectPrev(void);
  void selectNext(void);
  void spawnListUpdated();
  void rebuildSpawnList();

signals: 
  void playerChanged (int, int, int, int, int, int, int);
  void newZoneName (const QString &); 
  void selSpawnUpdate(int x,int y);   
  void hpChanged(int,int);
  void deleteSkills();
  void msgReceived(const QString &);
  void stsMessage(const QString &, int timeout = 0);
  void numSpawns_(int);

protected:
   void paintEvent (QPaintEvent *);
   void mousePressEvent (QMouseEvent *);
   void resizeEvent (QResizeEvent *);
 private:   
   
   void makeSimpleLine(trackPoint *walk, int numpnts, int n);
   int  indexOfMyChild(int);
   int  ID2Index(int);
   int  isFiltered(int n);
   const char* spawnAlertName(int n);
   void hideSpawn (int n);
   void unhideSpawn (int n);
   void refreshSpawnList(void);
   void createSpawnListItem(int n);
   void updateSpawnStatus(int n);
   const char* dumpSpawn(int n);
   CLineDlg *dlgLineProps;
   int ZoomAmmount;
   int playerAngle;
   int mapClicked;
   int mapClickedX;
   int mapClickedY;
   void loadFileMap (void);
   char filename[128];
   int calcDist (int xcor, int ycor);
   int calcXOffset (int mapX);
   int calcYOffset (int mapY);
   void reAdjust (void);
   void checkPos (int x, int y);
   void paintMap (QPainter *);
   QRect mapRect () const;
   QPixmap mapImage;
   int ang;
   int x;
   int y;
   int z;
   int curPlayerX;
   int curPlayerY;
   int DeltaX;
   int DeltaY;
   int DeltaZ;
   struct timeval playerTime;
   int playerID;
   int playerRace;
   int playerClass;
   int maxX, maxY, minX, minY;
   int iZMaxX, iZMinX, iZMaxY, iZMinY;
   int nomap;
   int showhidden;
   int viewfilteredspawns;
   int m_nFlash;
   bool m_bFlash;
   bool m_bKeepUpdated;

   unsigned int groupID[6];
   char groupNames[6][32];
   unsigned int groupSize;

   double m_RatioX;
   double m_RatioY;
   int m_XOffset, m_YOffset;

   QListView *listView;
   unsigned int selectedSpawnId;
   unsigned int selectedColumn;

   QListViewItem *NPClist, *PClist, *DROPlist;
   int screenCenterX, screenCenterY,
     screenLengthX, screenLengthY, mapLengthX, mapLengthY;   

   int zoomMapLengthX, zoomMapLengthY;

   int numLocations;
   int numLines;
   struct trackPoint linePoint[4096];
   int lineType[4096];
   int locationX[256];
   int locationY[256];
   int linePoints[4096];
   //int lineX[256][256];
   //int lineY[256][256];

   QString locationColor[256];
   QString locationName[256];

   QString lineColor[256];
   QString lineName[256];
       
   int playerLevel;

   int numDrops;
   dropThingOnGround drops[512]; 
   char dropInfo[512][64];
   int numCoins;
   dropCoinsStruct coins[512]; 

   int numSpawns;
   spawnStruct spawns[4096];
   char spawnInfo[4096][128];
   struct timeval spawnTime[4096];
   struct timezone tz;
   struct trackPoint firstPoint[4096];
   char zoneShort[128];
   char zoneLong[128];
   int m_FlagsArray[4096];

   Filter* m_pSpawnFilter;
   Filter* m_pAlertFilter;
   Filter* m_pSpawnFilter_Level;
   Filter* m_pSpawnFilter_HP;
   Filter* m_pSpawnFilter_MaxHP;
   Filter* m_pSpawnFilter_Dist;
   Filter* m_pSpawnFilter_Race;
   Filter* m_pSpawnFilter_Class;
   Filter* m_pSpawnFilter_Info;

   CSpawnList* m_pSpawnList;
};

#endif // EQMAP_H
