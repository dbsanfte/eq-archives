/*
 * languages.h
 *
 * ShowEQ Distributed under GPL
 * http://www.hackersquest.gomp.ch/
 */

case 0:
  strcpy(lang, "Common Tongue");
  break;
case 1:
  strcpy(lang, "Barbarian");
  break;
case 2:
  strcpy(lang, "Erudian");
  break;
case 3:
  strcpy(lang, "Elvish");
  break;
case 4:
  strcpy(lang, "Teir'Dal");
  break;
case 5:
  strcpy(lang, "Dwarvish");
  break;
case 6:
  strcpy(lang, "Troll");
  break;
case 7:
  strcpy(lang, "Ogre");
  break;
case 8:
  strcpy(lang, "Gnomish");
  break;
case 9:
  strcpy(lang, "Halfling");
  break;
case 10:
  strcpy(lang, "Thieves Cant");
  break;
case 11:
  strcpy(lang, "Old Erudian");
  break;
case 12:
  strcpy(lang, "Elder Elvish");
  break;
case 13:
  strcpy(lang, "Froglok");
  break;
case 14:
  strcpy(lang, "Goblin");
  break;
case 15:
  strcpy(lang, "Gnoll");
  break;
case 16:
  strcpy(lang, "Giant Tongue");
  break;
case 17:
  strcpy(lang, "Kobold");
  break;
case 18:
  strcpy(lang, "Lizardman");
  break;
case 19:
  strcpy(lang, "Orcish");
  break;
case 20:
  strcpy(lang, "Faerie");
  break;
case 21:
  strcpy(lang, "Dragon");
  break;
case 22:
  strcpy(lang, "Elder Dragon");
  break;
case 23:
  strcpy(lang, "Dark Speech");
  break;
