/*
 * packet.h
 *
 * ShowEQ Distributed under GPL
 * http://www.hackersquest.gomp.ch/
 */

#ifndef EQPACKET_H
# define EQPACKET_H

# define MAXPACKETCACHECOUNT 255
# define MAXPACKETCACHESIZE  640
# define MAXSPAWNDATA	    49152

# define DIR_CLIENT 1
# define DIR_SERVER 2

# include <qqueue.h>
# include <qmap.h>
# include <qobject.h>
# include <qregexp.h>
# include "everquest.h"

# define opCodeVersion 		2
//#define printunk

# define NewZoneVer 		2
# define NewZoneCode		0x5b20

//no work on this yet
# define BetterNewZoneVer 	2
# define BetterNewZoneCode	0x2d20

# define moneyThingVer    	2
# define moneyThingCode 	0x2820

# define PlayerPosVer 		2
# define PlayerPosCode		0xf320

# define RandomVer		2
# define RandomCode		0xe721

# define MobUpdateVer 		2
# define MobUpdateCode		0xa120

# define ZoneSpawnsVer 		2
# define ZoneSpawnsCode		0x6121
# define NewSpawnVer 		2
# define NewSpawnCode		0x4921

# define DeleteSpawnVer 		2
# define DeleteSpawnCode		0x2b20

# define CharProfileVer 		2
# define CharProfileCode		0x2d20

# define ItemInShopVer 		2
# define ItemInShopCode		0x0c20
# define ItemOnCorpseVer 	2
# define ItemOnCorpseCode	0x5220
# define ItemTradeVer 		2
# define ItemTradeCode		0x3120
# define summonedItemVer        2
# define summonedItemCode       0x7821
# define tradeItemVer           2
# define tradeItemCode          0xdf20

# define ChannelMessageVer 	2
# define ChannelMessageCode	0x0721

# define TimeOfDayVer 		0
# define TimeOfDayCode		0x4d20

# define BookTextVer 		2
# define BookTextCode		0xce20

# define PlayerItemVer 		2
# define PlayerItemCode		0x6421
# define PlayerBookVer 		2
# define PlayerBookCode		0x6521
# define PlayerContainerVer	2
# define PlayerContainerCode	0x6621
# define InspectDataVer 	2
# define InspectDataCode	0xb620

# define HPUpdateVer 		2
# define HPUpdateCode		0xb220

# define GainXPVer 		2
# define GainXPCode		0x8021
# define BeginCastVer 		2
# define BeginCastCode		0x8221
# define MemSpellVer 		2
# define MemSpellCode		0xa920

# define ExpUpdateVer 		2
# define ExpUpdateCode		0x9921

# define LevelUpUpdateVer 	2
# define LevelUpUpdateCode	0x9821

# define SkillIncVer 		2
# define SkillIncCode		0x8921

# define DoorSpawnVer 		2
# define DoorSpawnCode		0x9520

# define DoorOpenVer 		2
# define DoorOpenCode		0x8e20

# define IllusionVer 		2
# define IllusionCode		0x9120

# define SysMsgVer 		2
# define SysMsgCode		0x1420
# define GoodCastVer 		2
# define GoodCastCode		0x5820
# define BadCastVer 		2
# define BadCastCode		0xd321

# define CorpseVer 		2
# define CorpseCode		0x4a20
# define WearChangeVer		2
# define WearChangeCode		0x9220

# define castOnVer              2
# define castOnCode             0x4620
# define manaDecrementVer       2
# define manaDecrementCode      0x7f21


# define staminaVer             2
# define staminaCode            0x5721

# define MakeDropVer            2
# define MakeDropCode           0x3520
# define RemDropVer             2
# define RemDropCode            0x3620

# define dropCoinsVer            2
# define dropCoinsCode           0x0720
# define removeCoinsVer          2
# define removeCoinsCode         0x0820

# define openVendorVer           2
# define openVendorCode          0x0b20

# define closeVendorVer          2
# define closeVendorCode         0x4521

# define openGMVer               2
# define openGMCode              0x9c20

# define closeGMVer              2
# define closeGMCode             0x4321

# define attack1Ver              2
# define attack1Code             0xf520

# define attack2Ver              2
# define attack2Code             0x9f20

# define emoteTextVer            2
# define emoteTextCode           0x1520

# define considerVer             2
# define considerCode            0x3721

# define newGuildInZoneVer       2
# define newGuildInZoneCode      0x7b21
# define moneyUpdateVer          2
# define moneyUpdateCode         0x3d21
# define bindWoundVer            2
# define bindWoundCode           0x8321

# define groupinfoVer            2
# define groupinfoCode           0x2640


class VPacket;

// Cached Regexps.
struct spawnFilter_Regexp
{
   struct spawnFilter_Regexp *next;
   QRegExp *regexp;
};

struct dbSpawnList
{
   struct dbSpawnList *next;
   dbSpawnStruct *spawn;
};

class EQPacket:public QObject
{
   Q_OBJECT public:
   EQPacket (QObject * parent = 0, const char *name = 0);
   void start (int delay = 0);
   void stop (void);
   void setLogAllPackets (bool);
   void setLogZoneData (bool);
   void setLogUnknownData (bool);
   void setViewChannelMsgs (bool);
   void setViewUnknownData (bool);

 public slots:
   void processPackets (void);
   void initSpawnLists2 (void);
   void deSpawnAlert(char*);
   void incPlayback(void);
   void decPlayback(void);
   void Resync(void);

   signals:
   void addGroup(char*, int);
   void remGroup(char*, int);
   void clrGroup();
   void hideSpawn(int);
   void addSkill(int,int);
   void changeSkill(int,int);
   void packetReceived(int);
   void seqReceive(int);
   void seqExpect(int);
   void headingChanged(int);
   void xposChanged(const QString &);
   void yposChanged(const QString &);
   void zposChanged(const QString &);
   void posChanged(int,int,int);
   void playerChanged(int,int,int,int,int,int,int);
   void setPlayerLevel(int);
   void setPlayerRace(int);
   void setPlayerClass(int);
   void msgReceived(const QString &);
   void numPacket(int);

   void attack1Hand1(attack1Struct *);
   void attack2Hand1(attack2Struct *);

   void consMessage(considerStruct *);

   void spawnWearingUpdate(wearChangeStruct *);

   void newGroundItem (dropThingOnGround *);
   void removeGroundItem(removeThingOnGround*);
   void newCoinsItem (dropCoinsStruct *);
   void removeCoinsItem(removeCoinsStruct *);

   //   void newSpawn (char *, int, int, int, int, int, int, int, char *, char*, char *, int);
   void newSpawn (spawnStruct *, int);
   void updateSpawn(int,int,int,int,int,int,int);
   void updateSpawnHp (int id, int hp, int maxhp);
   void setPlayerID(int);
   void refreshMap(void);
   void deleteSpawn(int);
   void killSpawn (int);
   void infoSpawn(int);
   void newZone(char *, char *);
   void zoneChanged(void);
   void expChangedStr (const QString &);
   void expChangedInt (int,int,int);
   void expGained( const QString &, int, long, QString );
   void manaChanged (int,int);
   void stamChanged (int,int, int,int, int,int);
   void stsMessage(const QString &, int = 0);

 public:

   // ExperienceWindow needs this
   unsigned long currentExp;
   unsigned long maxExp;
   unsigned int playerID;
   unsigned int groupID[6];
   char groupNames[6][32];
   unsigned int groupSize;

 private:
   // This map is now kept updated with all current spawns in zone
   // Pet code uses this, as well as the experience logging feature
   QMap<unsigned int, spawnStruct> m_Spawns;

   unsigned long client_addr;
   int playerLevel;
   unsigned int key;
   UBYTE playerClass;
   UBYTE playerRace;
   char *print_addr (int addr);
   char *getSkillName (int offset);
   void decodePacket (int size, unsigned char *buffer);
   void processSpawn (struct dbSpawnStruct *dbSpawn, unsigned int key, int dbemit);
   //void processEquipment (struct spawnStruct *spawn, char *buffer);
   void logPacket (char *filename, int size, unsigned char *buffer);
   void logData (char *filename, int len, unsigned char *data, long saddr =
		 0, long daddr = 0, int sport = 0, int dport = 0);
   void logRawData (char *filename, unsigned char *data, unsigned int len);

   /* Most recent encryptopn tackes by Catjj and he came up with a wonderful
      temporary hack  until we find the key */
   void decData (int len, unsigned char *data, unsigned int key);
   unsigned int getKey ( unsigned char* data, int len);

   /* Worked for last encryption */
   void olddecData2 (int len, unsigned char *data, unsigned int key);
   unsigned int oldgetKey ( unsigned char* data, int len);

   /* First encryption attempt by verant */
   void oldDecData (int len, unsigned char *data);

   int busy_decoding;
   int fd;
   unsigned long packetcount;
   QTimer *timer;
   void dispatchZoneData (int len, unsigned char *data, int direction = 0);
   void dispatchZoneSplitData (int len, unsigned char *data);

   int serverSeqClear;
   int serverCacheCount;
   int serverAddr;
   int serverPort;

   int clientSeqClear;
   int clientCacheCount;
   int clientAddr;
   int clientPort;
   int m_nPacket;

   QString currentZone;
//   Freaks in QT 2.1.0
//   QQueue<dbSpawnStruct> m_ZoneSpawns;
   dbSpawnList *m_ZoneSpawns;

   int userResync;
   unsigned int serverSeqExp;
   int serverCacheLen[MAXPACKETCACHECOUNT];
   unsigned int serverCacheSeq[MAXPACKETCACHECOUNT];
   unsigned char serverCachePkt[MAXPACKETCACHECOUNT][MAXPACKETCACHESIZE];
   unsigned char serverData[MAXSPAWNDATA];
   int serverDataSize;

   unsigned int clientSeq;
   int clientCacheLen[MAXPACKETCACHECOUNT];
   unsigned int clientCacheSeq[MAXPACKETCACHECOUNT];
   unsigned char clientCachePkt[MAXPACKETCACHECOUNT][MAXPACKETCACHESIZE];
   unsigned char clientData[MAXSPAWNDATA];
   int clientDataSize;

   struct spawnFilter_Regexp *filterList;
   struct spawnFilter_Regexp *spawnList;
   int spawnAlert (char *oname);
   int initSpawnLists (void);

   bool logRaw;
   bool logAllPackets;
   bool logZoneData;
   bool logUnknownData;

   bool viewChannelMsgs;
   bool viewUnknownData;

   VPacket* m_pVPacket;

 public:
   int spawnFilter (char *oname);
   spawnStruct m_lastDeadSpawn;

};

// From pcap.c
//
extern "C"
{
   unsigned int EQPacketGetPacket (unsigned char *buff);
   void EQPacketInitPcap (const char *device, const char *hostname, int
			  realtime);
}
#endif				// EQPACKET_H
