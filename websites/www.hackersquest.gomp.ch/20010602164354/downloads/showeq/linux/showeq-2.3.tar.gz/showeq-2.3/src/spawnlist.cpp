/*
 * spawnlist.cpp
 *
 * ShowEQ Distributed under GPL
 * http://www.hackersquest.gomp.ch/
 */

/*
 * Orig Author - Maerlyn (MaerlynTheWiz@yahoo.com)
 * Date   - 3/16/00
 */

/*
 * SpawnListItem
 *
 * SpawnListItem is class intended to store information about an EverQuest
 * Spawn.  It inherits from QListViewItem but overrides functionality to allow
 * paint styles such as color changes
 *
 * It is intended that this class will grow to support all data from a spawn
 */

#include <qpainter.h>
#include <qfont.h>
#include <qregexp.h>
#include <regex.h>

#include "spawnlist.h"
#include "util.h"

//#define DEBUG
//#define DEBUGFIND
//#define DEBUGUPDATE

#undef DEBUG

//----------------------------------------------------------------------
// Added by Wally59
//----------------------------------------------------------------------
SpawnListItem::SpawnListItem(QListViewItem *parent) : QListViewItem(parent)
{
  m_btextSet = FALSE;
  m_textColor = Qt::black;
  m_type = tUnknown;
  m_nFlags = 0;
  m_bSet = FALSE;
}

SpawnListItem::SpawnListItem(QListView *parent) : QListViewItem(parent)
{
  m_btextSet = FALSE;
  m_textColor = Qt::black; 
  m_type = tUnknown;
  m_nFlags = 0;
  m_bSet = FALSE;
}
//----------------------------------------------------------------------


//
// paintCell 
//
// overridden from base class in order to change color and style attributes
//
void
SpawnListItem::paintCell( QPainter *p, const QColorGroup &cg,
                           int column, int width, int alignment )
{
    QColorGroup _cg( cg );
    QColor c = _cg.text();

    if (m_btextSet)
       _cg.setColor( QColorGroup::Text, m_textColor);

    // color hidden spawns grey
    if (m_nFlags & spawnHidden)
       _cg.setColor( QColorGroup::Text, Qt::gray);

    QListViewItem::paintCell( p, _cg, column, width, alignment );

    _cg.setColor( QColorGroup::Text, c );
}

//----------------------------------------------------------------------
// Added by Wally 59
//----------------------------------------------------------------------
spawnStruct* SpawnListItem::spawn()
{
  if (m_type == tSpawn)
  {
    return &m_spawn;
  }
  else 
  {
    return NULL;
  }
}

dropCoinsStruct* SpawnListItem::coins()
{
  if (m_type == tCoins)
  {
    return &m_coins;
  }
  else 
  {
    return NULL;
  }
}
   
dropThingOnGround* SpawnListItem::drop()
{
  if (m_type == tDrop)
  {
    return &m_drop;
  }
  else 
  {
    return NULL;
  }
}

itemType SpawnListItem::type()
{
  return m_type;
}

timeval SpawnListItem::lastUpdate()
{
  return m_lastUpdate;
}

void SpawnListItem::UpdateCoins(dropCoinsStruct *c)
{
#ifdef DEBUG
   printf ("SpawnListItem::UpdateCoins()\n");
#endif /* DEBUG */
  char buff[200];
  CSpawnList *l = (CSpawnList*)listView();

  m_type = tCoins;
  
  if (c != NULL)
  {
    m_coins = *c;
  }

  struct timezone tz;
  gettimeofday(&m_lastUpdate,&tz);

  // Name
  sprintf(buff, "Coins: %c %d", m_coins.type[0], m_coins.amount);
  setText(0, buff);

  // Level
  sprintf(buff, "%2d", 0);
  setText(1, buff);

  // Hitpoints
  sprintf(buff, "%5d", 1);
  setText(2, buff);

  // Maximum Hitpoints
  sprintf(buff, "%5d", 1);
  setText(3, buff);

  // X position
  sprintf(buff, "%5d", (int)m_coins.xPos);
  setText(4+showeq_params->retarded_coords, buff);

  // Y position
  sprintf(buff, "%5d", (int)m_coins.yPos);
  setText(5-showeq_params->retarded_coords, buff);

  // Z position
  sprintf(buff, "%5d", (int)m_coins.zPos);
  setText(6, buff);

  // Id
  sprintf(buff, "%d", 0-m_coins.dropId);
  setText(7, buff);

  // Distance
  sprintf(buff, "%5d", l->calcDist((int)m_coins.xPos, (int)m_coins.yPos));
  setText(8, buff);

  // Race
  sprintf(buff, "%s", "Coins");
  setText(9, buff);

  // Class
  sprintf(buff, "%s", "Thing");
  setText(10, buff);

  // Info
  setText(11, "");
}

void SpawnListItem::UpdateDrop(dropThingOnGround *d)
{
#ifdef DEBUG
   printf("SpawnListItem::UpdateDrop()\n");
#endif /* DEBUG */

  char buff[200];
  char buff2[200];
  int itemId;
  CSpawnList *l = (CSpawnList*)listView();

  m_type = tDrop;
  if (d != NULL) 
  {
    m_drop = *d;
  }

  struct timezone tz;
  gettimeofday(&m_lastUpdate,&tz);

  strcpy(buff2, getitemNameFromDB(m_drop.itemNr));
  if (strlen(buff2) == 0) 
  {
    strcpy(buff, m_drop.idFile);
    if (m_drop.idFile[0] == 'I' && m_drop.idFile[1] == 'T')
    {
      strcpy(buff, m_drop.idFile + 2);
    }
    
    itemId = atoi(buff);

    if (itemId > 0) 
      sprintf(buff, "Drop: %s", print_weapon(itemId));
    else 
      sprintf(buff, "Drop: %s", m_drop.idFile);
  }
  else 
  {
    sprintf(buff, "Drop: '%s'", buff2);
  }

  // Name
  setText(0, buff);

  // Level
  sprintf(buff, "%2d", 0);
  setText(1, buff);

  // HitPoints
  sprintf(buff, "%5d", 1);
  setText(2, buff);

  // Max HitPoints
  sprintf(buff, "%5d", 1);
  setText(3, buff);

  // X Position
  sprintf(buff, "%5d", (int)m_drop.xPos);
  setText(4+showeq_params->retarded_coords, buff);

  // Y Position
  sprintf(buff, "%5d", (int)m_drop.yPos);
  setText(5-showeq_params->retarded_coords, buff);
   
  // Z Position
  sprintf(buff, "%5d", (int)m_drop.zPos);
  setText(6, buff);

  // ID
  sprintf(buff, "%d", 0-m_drop.dropId);
  setText(7, buff);

  // Distance
  sprintf(buff, "%5d", l->calcDist((int)m_drop.xPos, (int)m_drop.yPos));
  setText(8, buff);

  // Race
  sprintf(buff, "%s", "Drop");
  setText(9, buff);

  // Class
  sprintf(buff, "%s", "Thing");
  setText(10, buff);

  // Info
  sprintf(buff, "%i", m_drop.itemNr);
  setText(11, buff);
}


bool
SpawnListItem::UpdateSpawn(spawnStruct *s)
{
  bool bChanged = FALSE;
#ifdef DEBUG
   printf ("SpawnListItem::UpdateSpawn() '%s' (%d)\n", s->name, s->spawnId);
#endif /* DEBUG */
  char buff[200];
  CSpawnList *l = (CSpawnList*)listView();

  m_type = tSpawn;

  // detect a change that could cause this spawn to move in the spawnList
  if (s && m_bSet)
  {
    if (m_spawn.NPC != s->NPC)
      bChanged = TRUE;
    if (m_spawn.level != s->level)
      bChanged = TRUE;
//if (bChanged)
//  printf("%s changed\n", m_spawn.name);
  }

  if (s != NULL) 
  {
    m_spawn = *s;
    m_bSet = TRUE;
  }

  struct timezone tz;
  gettimeofday(&m_lastUpdate,&tz);

  // Name
  strcpy(buff, m_spawn.name);
  if (m_spawn.NPC == 3)
    strcat(buff, "'s corpse");

//  if (!text(0) || bChanged)
    setText(0, TransformName((const char*) buff));
  
  // Level
  sprintf(buff, "%2d", m_spawn.level);
  setText(1, buff);

  // HitPoints
  if (m_spawn.curHp <= 0) 
    sprintf(buff, "%s", "<=0");
  else
    sprintf(buff, "%5d", m_spawn.curHp);
  setText(2, buff);

  // Max HitPoints
  sprintf(buff, "%5d", m_spawn.maxHp);
  setText(3, buff);

  // X Position
  sprintf(buff, "%5d", m_spawn.xPos);
  setText(4+showeq_params->retarded_coords, buff);

  // Y Position
  sprintf(buff, "%5d", m_spawn.yPos);
  setText(5-showeq_params->retarded_coords, buff);

  // Z Position
  sprintf(buff, "%5d", m_spawn.zPos);
  setText(6, buff);

  // ID
  sprintf(buff, "%d", m_spawn.spawnId);
  setText(7, buff);  

  // Distance
  sprintf(buff, "%5d", l->calcDist(m_spawn.xPos, m_spawn.yPos));
  setText(8, buff);

  // Race
  sprintf(buff, "%s", race_name(m_spawn.race));
  setText(9, buff);

  // Class
  sprintf(buff, "%s", class_name(m_spawn.class_));
  setText(10, buff);

  // Info
  processEquipment(&m_spawn, buff);
  setText(11, buff);

  return bChanged;
}

CSpawnList::CSpawnList(QWidget *parent, const char* name)
  : QListView(parent, name)
{
  playerLevel = 0;
  bDebug = FALSE;
//  bDebug = TRUE;
}

SpawnListItem*
CSpawnList::AddCategory(const char* name, const char* filter, 
                        const char* filterout, QColor color)
{
//printf("AddCategory() '%s' - '%s':'%s'\n", name, filter, filterout?filterout:"null");
  struct category* newcat = (struct category *) malloc(sizeof(struct category));

  newcat->name = 0;
  newcat->filter = 0;
  newcat->filterout = 0;
  newcat->color = color;

  if (name && filter)
  {
    newcat->name = strdup(name);
    newcat->filter = strdup(filter);
    if (filterout)
      newcat->filterout = strdup(filterout);
    newcat->color = color;
    newcat->listitem = new SpawnListItem(this);
    QString temp(newcat->name);
    temp += " (0)";
    newcat->listitem->setText(0, temp); 
    m_categoryList.append(newcat);
  }

//  emit listChanged();

//printf("Added '%s'-'%s' '%s' %d\n", newcat->name, newcat->filter, newcat->listitem->text(0).ascii(), newcat->listitem);

  return newcat->listitem;
}

void
CSpawnList::RemCategory(SpawnListItem *i)
{
//printf("RemCategory()\n");

  struct category* cat = getCategory(i);

  // remove all children from list
  SpawnListItem *child;
  child = (SpawnListItem *) cat->listitem->firstChild();
  while (child)
  {
    m_spawnList.remove(child);
    child = (SpawnListItem *) child->nextSibling();
  }

  m_categoryList.remove(cat);
  delete(cat->listitem);
//  emit listChanged();
printf("done\n");
}


void
CSpawnList::clearCategories(void)
{
//printf("clearCategories()\n");
  QListView::clear();
  m_spawnList.clear();
  m_categoryList.clear();
}

void
CSpawnList::clear(void)
{
#ifdef DEBUG
   printf("CSpawnList::clear()\n");
#endif
  
  QListView::clear();
  m_spawnList.clear();

  // rebuild headers
  QValueList<struct category*>::Iterator it;
  for(it = m_categoryList.begin(); it != m_categoryList.end(); ++it)
  { 
//printf("clear():  Adding '%s'\n", (*it)->name);
    (*it)->listitem = new SpawnListItem(this);
    QString temp((*it)->name);
    temp += " (0)";
    (*it)->listitem->setText(0, temp); 
    (*it)->listitem->setTextColor((*it)->color);

    if ((*it)->flags & spawnHidden)
      hideSpawn((*it)->listitem, TRUE);
  }
} // end clear


void CSpawnList::setPlayerLevel(int newlvl)
{
  playerLevel = newlvl;
}

void CSpawnList::setPlayer(int newX, int newY, int newZ, int newDX, int newDY, int newDZ, int degrees)
{
#ifdef DEBUG
   printf ("CSpawnList::setPlayer()\n");
#endif /* DEBUG */
  char buff[200];  
  
  if ((x == newX) && (y == newY) && (z == newZ))
    return;
   
  x = newX;
  y = newY;
  z = newZ;

  SpawnListItem *i = (SpawnListItem*)firstChild();
  while (i != NULL)
  {   
    switch (i->type()) 
    {
    case tSpawn:
      sprintf(buff, "%5d", calcDist(i->spawn()->xPos, i->spawn()->yPos));
      i->setText(8, buff);
      break;
    case tCoins:
      sprintf(buff, "%5d", calcDist((int)i->coins()->xPos, (int)i->coins()->yPos));
      i->setText(8, buff);
      break;
    case tDrop:
      sprintf(buff, "%5d", calcDist((int)i->drop()->xPos, (int)i->drop()->yPos));
      i->setText(8, buff);
      break;
    } 
    i = (SpawnListItem*)i->nextSibling();
  }
}

int CSpawnList::calcDist (int xcor, int ycor)
{
#ifdef DEBUG
   printf ("CSpawnList::calcDist()\n");
#endif /* DEBUG */
  double distance;
  if ((xcor == x) && (ycor == y))
    return 0;

//  distance = sqrt(pow((double)ycor - (double)y, 2) +
//		  pow((double)xcor - (double)x, 2));
  distance = abs(ycor-y)+abs(xcor-x);  //much faster than sqrt() and accurate enough for me
  return (int) rint (distance);
}

SpawnListItem* CSpawnList::InsertSpawn(spawnStruct *s, int flags)
{
#ifdef DEBUG
   printf ("CSpawnList::InsertSpawn() '%s'\n", s->name);
#endif /* DEBUG */
  SpawnListItem *i;

  // if id already in list, update it
  i = FindItem(tSpawn, s->spawnId);
  if (i)
  {
    UpdateSpawn(s);
    return i;
  }

  // if none found in list, add 
  int count = 0;

     // if this is a pet, make it the child of the owner
     if (s->petOwnerId)
     {
       // loop through all matches on owner and add as child
       i = FindItem(tSpawn, s->petOwnerId);
       while (i)
       {
          SpawnListItem *j;
          j = new SpawnListItem(i);
          m_spawnList.append(j);
          j->setFlags(flags);
          j->UpdateSpawn(s);
#ifdef DEBUGUPDATE
count++;
QString text = j->text(0);
text.sprintf("%s (%d)", text.ascii(), count);
j->setText(0, text);
#endif
          j->setTextColor(pickSpawnColor(s));
          i = FindNext(i, tSpawn, s->petOwnerId);
       }
     }
     
     // otherwise add the spawn to each appropriate category
// add pets to categories also
//     else
     {
       if (m_categoryList.count())
       {
         QValueList<struct category*>::Iterator it;
         for(it = m_categoryList.begin(); it != m_categoryList.end(); ++it)
         { 
if (bDebug)
printf("Checking '%s' in category '%s'-'%s':'%s' %d %d\n", 
 filterString(s,flags), (*it)->name, (*it)->filter, (*it)->filterout, 
 (*it)->listitem->flags(), (*it)->listitem );

// skip filtered spawns 
if ( (flags & spawnFiltered) && strcmp((*it)->filter, "Filtered"))
{
if (bDebug) printf("Skipping\n");
  continue;
}
            regex_t re;
            regmatch_t matchArray[1];
            int cflags = REG_EXTENDED | REG_ICASE;
            int eflags = 0;
            int error = 0;
            if (error = regcomp(&re, (*it)->filter, cflags))
            {
              char buf[1024]; 
              regerror(error, &re, buf, sizeof(buf));
              fprintf(stderr, "Filter error: '%s' - '%s'\n", 
                    (*it)->filter, buf); 
            }

            // if we have a match, create a listitem in this category
            if (!regexec(&re, filterString(s, flags), 
                         1, matchArray, eflags))
// QRegExp doesn't handle extended regular expressions
//            QRegExp re(QString((*it)->filter), FALSE, FALSE);
//            if (-1 != re.match(QString(filterString(s, flags ))))
            {
// if anyone can explain to me how to combine an expression such as:
// matches ELF but not CORPSE, please let me know... then this 'filterout'
// wouldn't be needed - Maerlyn
              // check to see if this is an exception
              if ((*it)->filterout)
              {
                regex_t re;
                regmatch_t matchArray[1];
                int cflags = REG_EXTENDED | REG_ICASE;
                int eflags = 0;
                int error = 0;
                if (error = regcomp(&re, (*it)->filterout, cflags))
                {
                  char buf[1024]; 
                  regerror(error, &re, buf, sizeof(buf));
                  fprintf(stderr, "Filter error: '%s' - '%s'\n", 
                        (*it)->filterout, buf); 
                }

                // if we have a match, treat it as an exception
                if (!regexec(&re, filterString(s, flags),
                       1, matchArray, eflags))
                {
                   regfree(&re);
                   continue; 
                } 
                regfree(&re);
              } 
              i = new SpawnListItem((*it)->listitem);
//printf("Adding\n");
              m_spawnList.append(i);
              i->setFlags(flags);
              i->UpdateSpawn(s);
              if ((*it)->listitem->flags() & spawnHidden)
              {
                i->setFlags(i->flags() | spawnHidden);
                emit listUpdated();
              }
#ifdef DEBUGUPDATE
count++;
QString text = i->text(0);
text.sprintf("%s (%d)", text.ascii(), count);
i->setText(0, text);
#endif

              // color spawn
//            i->setTextColor((*it)->color);
              i->setTextColor(pickSpawnColor(s, (*it)->color));

              // update childcount in header
              QString temp;
              temp.sprintf("%s (%d)", 
                     (*it)->name,(*it)->listitem->childCount()); 
              (*it)->listitem->setText(0, temp); 
             } // end if spawn should be in this category
        
             regfree(&re);

         } // end for all categories
       } // end if categories

       else
       {
          i = new SpawnListItem(this);
          m_spawnList.append(i);
          i->setFlags(flags);
          i->UpdateSpawn(s);

#ifdef DEBUGUPDATE
count++;
QString text = i->text(0);
text.sprintf("%s (%d)", text.ascii(), count);
i->setText(0, text);
#endif
          // color spawn
          i->setTextColor(pickSpawnColor(s));
       }
     }

  return i;

} // end InsertSpawn

SpawnListItem* CSpawnList::InsertCoins(dropCoinsStruct *c)
{
  int flags = 0;
#ifdef DEBUG
   printf ("CSpawnList::InsertCoins()\n");
#endif /* DEBUG */
  SpawnListItem *i;

  // Look up this spawn id, if it isn't already 
  // inserted, then insert a new item
  i = FindItem(tCoins, c->dropId);
  if (i) 
  {
    i->UpdateCoins(c);
    return i;
  }
  
  // if none found in list, add 
  int count = 0;

     
     // otherwise add the spawn to each appropriate category
       if (m_categoryList.count())
       {
         QValueList<struct category*>::Iterator it;
         for(it = m_categoryList.begin(); it != m_categoryList.end(); ++it)
         { 
             if (bDebug)
                printf("Checking '%s' in category '%s'-'%s':'%s' %d %d\n", 
             ::filterString(c), (*it)->name, (*it)->filter, (*it)->filterout, 
             (*it)->listitem->flags(), (*it)->listitem );
             // skip filtered spawns 
             if ( (flags & spawnFiltered) && strcmp((*it)->filter, "Filtered")){
                 if (bDebug) printf("Skipping\n");
                 continue;
             }
             regex_t re;
             regmatch_t matchArray[1];
             int cflags = REG_EXTENDED | REG_ICASE;
             int eflags = 0;
             int error = 0;
             if (error = regcomp(&re, (*it)->filter, cflags))
             {
               char buf[1024]; 
               regerror(error, &re, buf, sizeof(buf));
               fprintf(stderr, "Filter error: '%s' - '%s'\n", 
                     (*it)->filter, buf); 
             }

            // if we have a match, create a listitem in this category
            if (!regexec(&re, ::filterString(c), 
                         1, matchArray, eflags))
// QRegExp doesn't handle extended regular expressions
//            QRegExp re(QString((*it)->filter), FALSE, FALSE);
//            if (-1 != re.match(QString(::filterString(c))))
            {
// if anyone can explain to me how to combine an expression such as:
// matches ELF but not CORPSE, please let me know... then this 'filterout'
// wouldn't be needed - Maerlyn
              // check to see if this is an exception
              if ((*it)->filterout)
              {
                regex_t re;
                regmatch_t matchArray[1];
                int cflags = REG_EXTENDED | REG_ICASE;
                int eflags = 0;
                int error = 0;
                if (error = regcomp(&re, (*it)->filterout, cflags))
                {
                  char buf[1024]; 
                  regerror(error, &re, buf, sizeof(buf));
                  fprintf(stderr, "Filter error: '%s' - '%s'\n", 
                        (*it)->filterout, buf); 
                }

                // if we have a match, treat it as an exception
                if (!regexec(&re, ::filterString(c),
                       1, matchArray, eflags))
                {
                   regfree(&re);
                   continue; 
                } 
                regfree(&re);
              } 
              i = new SpawnListItem((*it)->listitem);
//printf("Adding\n");
              m_spawnList.append(i);
              i->setFlags(flags);
              i->UpdateCoins(c);
              if ((*it)->listitem->flags() & spawnHidden)
              {
                i->setFlags(i->flags() | spawnHidden);
                emit listUpdated();
              }
#ifdef DEBUGUPDATE
count++;
QString text = i->text(0);
text.sprintf("%s (%d)", text.ascii(), count);
i->setText(0, text);
#endif

              // color spawn
//            i->setTextColor((*it)->color);
              //i->setTextColor(pickSpawnColor(s, (*it)->color));

              // update childcount in header
              QString temp;
              temp.sprintf("%s (%d)", 
                     (*it)->name,(*it)->listitem->childCount()); 
              (*it)->listitem->setText(0, temp); 
             } // end if spawn should be in this category
        
             regfree(&re);

         } // end for all categories
       } // end if categories

       else
       {
          i = new SpawnListItem(this);
          m_spawnList.append(i);
          i->setFlags(flags);
          i->UpdateCoins(c);

#ifdef DEBUGUPDATE
count++;
QString text = i->text(0);
text.sprintf("%s (%d)", text.ascii(), count);
i->setText(0, text);
#endif
          // color spawn
          //i->setTextColor(pickSpawnColor(s));
       }
     //}

  return i;

}

SpawnListItem* CSpawnList::InsertDrop(dropThingOnGround *d)
{
int flags = 0;
#ifdef DEBUG
   printf ("CSpawnList::InsertDrop()\n");
#endif /* DEBUG */
  SpawnListItem *i;

  // Look up this spawn id, if it isn't already 
  // inserted, then insert a new item
  i = FindItem(tDrop, d->dropId);
  if (i) 
  {
      //i = new SpawnListItem(this);
      //m_spawnList.append(i);
      i->UpdateDrop(d);
      return i;
  }
  

  // if none found in list, add 
  int count = 0;
  char filtStr[1024];
  strcpy(filtStr,  ::filterString(d));
     
     // otherwise add the spawn to each appropriate category
       if (m_categoryList.count())
       {
         QValueList<struct category*>::Iterator it;
         for(it = m_categoryList.begin(); it != m_categoryList.end(); ++it)
         { 
             if (bDebug)
                printf("Checking '%s' in category '%s'-'%s':'%s' %d %d\n", 
             filtStr, (*it)->name, (*it)->filter, (*it)->filterout, 
             (*it)->listitem->flags(), (*it)->listitem );
             // skip filtered spawns 
             if ( (flags & spawnFiltered) && strcmp((*it)->filter, "Filtered")){
                 if (bDebug) printf("Skipping\n");
                 continue;
             }
             regex_t re;
             regmatch_t matchArray[1];
             int cflags = REG_EXTENDED | REG_ICASE;
             int eflags = 0;
             int error = 0;
             if (error = regcomp(&re, (*it)->filter, cflags))
             {
               char buf[1024]; 
               regerror(error, &re, buf, sizeof(buf));
               fprintf(stderr, "Filter error: '%s' - '%s'\n", 
                     (*it)->filter, buf); 
             }

            // if we have a match, create a listitem in this category
            if (!regexec(&re, filtStr, 
                         1, matchArray, eflags))
// QRegExp doesn't handle extended regular expressions
//            QRegExp re(QString((*it)->filter), FALSE, FALSE);
//            if (-1 != re.match(QString(filtStr)))
            {
// if anyone can explain to me how to combine an expression such as:
// matches ELF but not CORPSE, please let me know... then this 'filterout'
// wouldn't be needed - Maerlyn
              // check to see if this is an exception
              if ((*it)->filterout)
              {
                regex_t re;
                regmatch_t matchArray[1];
                int cflags = REG_EXTENDED | REG_ICASE;
                int eflags = 0;
                int error = 0;
                if (error = regcomp(&re, (*it)->filterout, cflags))
                {
                  char buf[1024]; 
                  regerror(error, &re, buf, sizeof(buf));
                  fprintf(stderr, "Filter error: '%s' - '%s'\n", 
                        (*it)->filterout, buf); 
                }

                // if we have a match, treat it as an exception
                if (!regexec(&re, filtStr,
                       1, matchArray, eflags))
                {
                   regfree(&re);
                   continue; 
                } 
                regfree(&re);
              } 
              i = new SpawnListItem((*it)->listitem);
//printf("Adding\n");
              m_spawnList.append(i);
              i->setFlags(flags);
              i->UpdateDrop(d);
              if ((*it)->listitem->flags() & spawnHidden)
              {
                i->setFlags(i->flags() | spawnHidden);
                emit listUpdated();
              }
#ifdef DEBUGUPDATE
count++;
QString text = i->text(0);
text.sprintf("%s (%d)", text.ascii(), count);
i->setText(0, text);
#endif

              // color spawn
//            i->setTextColor((*it)->color);
              //i->setTextColor(pickSpawnColor(s, (*it)->color));

              // update childcount in header
              QString temp;
              temp.sprintf("%s (%d)", 
                     (*it)->name,(*it)->listitem->childCount()); 
              (*it)->listitem->setText(0, temp); 
             } // end if spawn should be in this category
        
             regfree(&re);

         } // end for all categories
       } // end if categories

       else
       {
          i = new SpawnListItem(this);
          m_spawnList.append(i);
          i->setFlags(flags);
          i->UpdateDrop(d);

#ifdef DEBUGUPDATE
count++;
QString text = i->text(0);
text.sprintf("%s (%d)", text.ascii(), count);
i->setText(0, text);
#endif
          // color spawn
          //i->setTextColor(pickSpawnColor(s));
       }
     //}

  return i;

}

SpawnListItem* CSpawnList::FindItem(itemType type, int id)
{
#ifdef DEBUG
   printf ("CSpawnList::FindItem()\n");
#endif /* DEBUG */

  return FindNext(NULL, type, id);
}


SpawnListItem* 
CSpawnList::FindNext(SpawnListItem *first, itemType type, int id)
{
#ifdef DEBUG
   printf ("CSpawnList::FindNext()\n");
#endif /* DEBUG */
  SpawnListItem *i = first;
  QValueList<SpawnListItem*>::Iterator it;
  bool bAdvance = 0;

//if (bDebug)
//printf("FindNext %d\n", id);
  if (first) 
  {
    it = m_spawnList.find(first);
    if (it != m_spawnList.end())
      ++it;
  }
  else 
    it = m_spawnList.begin();

  do
  {
    i = *it;

    if (i)
    {
//if (bDebug)
//printf("Checking '%s'\n", i->text(0).ascii());
      // check this item
      if (i->type() == type)
      {
        switch (i->type()) 
        {
          case tSpawn:
            if (i->spawn()->spawnId == id)
//{
//if (bDebug)
//printf("FindNext:  Found '%s'\n", i->text(0).ascii());
             return i;
//}
           break;
         case tCoins:
           if (i->coins()->dropId == id)
             return i;
           break;
         case tDrop:
           if (i->drop()->dropId == id)
             return i;
           break;
        }
      } 
    } // end if match

    if (it != m_spawnList.end())
      ++it;

  } while (it != m_spawnList.end()); // end for all in list

  return NULL;

} // end FindNext


void
CSpawnList::DeleteItem(itemType type, int id)
{
#ifdef DEBUG
   printf ("CSpawnList::DeleteItem()\n");
#endif /* DEBUG */
  SpawnListItem *i;

  do
  {
     i = FindItem(type, id);
     if (i)
     {
       // delete children
       SpawnListItem *child = (SpawnListItem *) i->firstChild();
       while(child)
       {
          m_spawnList.remove(child);
          delete child;
          child = (SpawnListItem *) child->nextSibling();
       }
       m_spawnList.remove(i);
       delete i;
     }
  } while (i);
}

void
CSpawnList::SelectItem(itemType type, int id)
{
#ifdef DEBUG
   printf ("CSpawnList::SelectItem()\n");
#endif /* DEBUG */
  SpawnListItem *i;

  i = FindItem(type, id);

  // attempt to find a match on an item that is not collapsed (open)
  do
  {
    if (i)
    {
       QListViewItem* item = (SpawnListItem*) i->parent();
       bool bOpen = TRUE;
  
       while (item)
       {
          if (!item->isOpen())
          {
            bOpen = FALSE;
            break;
          } 
          item = (SpawnListItem*) item->parent();
       }

       if (bOpen)
         break;
    }

    i = FindNext(i, type, id);

  } while (i);

  if (i)
  {
     setSelected (i, 1);
     if (showeq_params->keep_selected_visible)
       ensureItemVisible(i);
  }

  // try again forcing open
  else
  {
    i = FindItem(type, id);
    if (i)
       selectAndOpen(i);
  }
  
} // end SelectItem


SpawnListItem*
CSpawnList::Selected()
{
   return ( (SpawnListItem*) selectedItem());
}


void
CSpawnList::selectAndOpen(SpawnListItem *i)
{
   QListViewItem* item = i;

   while (item)
   {
      item->setOpen(TRUE);
      item = (SpawnListItem*) item->parent();
   }
   setSelected (i, 1);
   if (showeq_params->keep_selected_visible)
     ensureItemVisible(i);
}


void
CSpawnList::UpdateSpawn(spawnStruct *s)
{
#ifdef DEBUG
   printf ("CSpawnList::UpdateSpawn() '%s' (%d)\n", s->name, s->spawnId);
#endif /* DEBUG */
  SpawnListItem *i;

#ifdef DEBUGUPDATE
if (bDebug)
  printf("UpdateSpawn(): Looking for '%s' (%d)\n", s->name, s->spawnId);
#endif

  i = FindItem(tSpawn, s->spawnId);

  while (i)
  {
     if (i->UpdateSpawn(s))
//i->UpdateSpawn(s);
//if (0)
     {
#ifdef DEBUGUPDATE
if (bDebug)
  printf("UpdateSpawn(): Found and changed '%s', deleting and recreating\n",
     i->text(0).ascii() );
#endif
       // if the Update modified something that we should refilter for, remove
       // the item and readd it
       DeleteItem(tSpawn, s->spawnId);
       InsertSpawn(s);
       i = NULL;
     }
     else
     {
#ifdef DEBUGUPDATE
if (bDebug)
  if (i && i->spawn() ) printf("UpdateSpawn(): Found '%s' (%d)\n", i->text(0).ascii(), i->spawn()->spawnId);
#endif
       i = FindNext(i, tSpawn, s->spawnId);
     }
  }

//#ifdef DEBUGUPDATE
//if (bDebug)
//  printf("UpdateSpawn(): No more found: Returning\n");
//#endif
}

void
CSpawnList::selectNext(void)
{
#ifdef DEBUG
   printf ("CSpawnList::selectNext()\n");
#endif /* DEBUG */
  SpawnListItem *i;
  SpawnListItem *cur;

  i = cur = (SpawnListItem *) selectedItem();

  if (!i)
     return;

//printf("SelectNext(): Current selection '%s'\n", i->text(0).ascii());

  int id;
  switch(i->type())
  {
      case tUnknown:
        break;
      case tDrop:
        id = i->drop()->dropId;
        break;
      case tCoins:
        id = i->coins()->dropId;
        break;
      case tSpawn:
        id = i->spawn()->spawnId;
        break;
  }
  i = FindNext(i, i->type(), id);

  if (!i)
     i = FindItem(cur->type(), id);

  if (i)
  {
//printf("SelectNext(): Next selection '%s'\n", i->text(0).ascii());
     selectAndOpen(i);
  }
} // end selectNext


void
CSpawnList::selectPrev(void)
{
#ifdef DEBUG
   printf ("CSpawnList::SelectPrev()\n");
#endif /* DEBUG */
  SpawnListItem *i;
  SpawnListItem *last;
  SpawnListItem *cur;

  i = cur = (SpawnListItem *) selectedItem();

  if (!i)
     return;

//printf("SelectPrev(): Current selection '%s'\n", i->text(0).ascii());

  int id;

  do
  {
    switch(i->type())
    {
        case tUnknown:
          break;
        case tDrop:
          id = i->drop()->dropId;
          break;
        case tCoins:
          id = i->coins()->dropId;
          break;
        case tSpawn:
          id = i->spawn()->spawnId;
          break;
    }
    last = i;
    i = FindNext(i, i->type(), id);

    if (!i)
       i = FindItem(cur->type(), id);
    if (!i)
       break;

  } while (i != cur);

  if (last)
  {
     i = last;
//printf("SelectPrev(): Prev selection '%s'\n", i->text(0).ascii());
     selectAndOpen(i);
  }

} // end SelectPrev


void
CSpawnList::UpdateCoins(dropCoinsStruct *c)
{
#ifdef DEBUG
   printf ("CSpawnList::Updatecoins()\n");
#endif /* DEBUG */
  SpawnListItem *i;

  i = FindItem(tCoins, c->dropId);

  if (i)
    i->UpdateCoins(c);
}

void
CSpawnList::UpdateDrop(dropThingOnGround *d)
{
#ifdef DEBUG
   printf ("CSpawnList::UpdateDrop()\n");
#endif /* DEBUG */
  SpawnListItem *i;

  i = FindItem(tDrop, d->dropId);

  if (i)
    i->UpdateDrop(d);
}


//----------------------------------------------------------------------

//
// pickSpawnColor
// 
// insert color schemes here
//
QColor
CSpawnList::pickSpawnColor(spawnStruct *s, QColor def)
{
   // color by pvp team
   if (showeq_params->pvp)
   {
      switch(s->race)
      {
       case 1: // Human
       case 2: // Barb
       case 3:  // Eurodite
          return (Qt::blue);
          break;
   
       case 4: // Wood Elf
       case 5: // High Elf
       case 7: // Half Elf
          return (QColor(196,206,12));
          break;
   
       case 6:  // Dark Elf
       case 9:  // Troll
       case 10: // Ogre
          return (QColor(206,151,33));
          break;
   
       case 8:  // Dwarf
       case 11:  // Halfling
       case 12:  // Gnome
          return (Qt::magenta);
          break;
      }
   }

   // color by consider difficulty
   else
   {
     QColor color = pickConColor(playerLevel, s->level);
     if (color == Qt::white)
        color = Qt::black;
     if (color == Qt::yellow)
        color = (QColor(206,151,33));
     return color;
   }
   
   return def;
   
} // end pickSpawnColor

const char*
CSpawnList::filterString(spawnStruct *s, int flags)
{
  static char text[2048];

  sprintf(text, "%s%s%s%s%s", 
     (flags & spawnHidden)?"Hidden:":"",
     (flags & spawnFiltered)?"Filtered:":"", 
     (flags & spawnAggressor)?"Aggressor:":"", 
     (flags & spawnHighlight)?"Highlight:":"", 
    ::filterString(s)); 

  return text;
}

void
CSpawnList::toggleHide(void)
{
  SpawnListItem *i = (SpawnListItem*) selectedItem();

  if (i)
     hideSpawn(i, !(i->flags() & spawnHidden));
}


void
CSpawnList::hideSpawn(SpawnListItem *i, bool bHide)
{
//printf("hideSpawn: '%s' - %s %d\n", i->text(0).ascii(), bHide?"Hidden":"Unhidden", i);
  if (!bHide)
    i->setFlags(i->flags() & ~spawnHidden);
  else
    i->setFlags(i->flags() | spawnHidden);
//printf("%s\n", (i->flags() & spawnHidden)?"Hidden":"UnHidden");
  i->repaint();

  // if this is a category do all children
  if (!i->text(7) )
  {
    QValueList<struct category*>::Iterator it;
    for(it = m_categoryList.begin(); it != m_categoryList.end(); ++it)
    { 
      if (i == (*it)->listitem)
      {
         if (!bHide)
           (*it)->flags &= ~spawnHidden;
         else
           (*it)->flags |= spawnHidden;
      }
    }

    i = (SpawnListItem *) i->firstChild();

    while(i)
    {
       if (!bHide)
         i->setFlags(i->flags() & ~spawnHidden);
       else
         i->setFlags(i->flags() | spawnHidden);
//printf("ToggleHiden Category: '%s'", i->text(0).ascii());
//printf("%s\n", (i->flags() & spawnHidden)?"Hidden":"UnHidden");
       i->repaint();
       i = (SpawnListItem *) i->nextSibling();
    }
  }

  emit listUpdated();
}

struct category*
CSpawnList::getCategory(SpawnListItem *i)
{
    QValueList<struct category*>::Iterator it;
    for(it = m_categoryList.begin(); it != m_categoryList.end(); ++it)
    { 
      if (i == (*it)->listitem)
         return (*it);
    }

   return NULL;
}
