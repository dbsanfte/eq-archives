/*
 * main.h
 *
 * ShowEQ Distributed under GPL
 * http://www.hackersquest.gomp.ch/
 */

#ifndef _SHOWEQ_MAIN_H
#define _SHOWEQ_MAIN_H

#ifdef __cplusplus
#include "cpreferences.h"

extern class CPreferenceFile *pSEQPrefs;
#endif

struct ShowEQParams
{
  const char *device;
  const char *ip;
  int realtime;
  int velocity;
  const char *spawnfilter_filterfile;
  const char *spawnfilter_spawnfile;
  const char *filterfile;
  int despawnalert;
  int spawnfilter_regexp;
  int spawnfilter_case;
  int spawnfilter_audio;
  int framerate;
  int fontsize;
  int animate;
  int retarded_coords; // verant style YXZ instead of XYZ
  int fast_machine;
  int spawn_alert_plus_plus;
  int dropItemShow;
  int showUnknownSpawns;
  int con_select;
  int keep_selected_visible;
  int promisc;
  int sparr_messages;
  int net_stats;
  int recordpackets;
  int playbackpackets;
  int playbackspeed;
  int pvp;
  int broken_decode;
  int walkpathrecord;
  int walkpathshowselect;
  int walkpathlength;
  int logSpawns;
  int logItems;
};

#ifndef LOGDIR
#define LOGDIR "../logs"
#endif

#ifndef MAPDIR
#define MAPDIR "../maps"
#endif

#ifndef SPAWNFILE
#define SPAWNFILE	LOGDIR "/spawn.db"
#endif

extern struct ShowEQParams *showeq_params;

#endif
