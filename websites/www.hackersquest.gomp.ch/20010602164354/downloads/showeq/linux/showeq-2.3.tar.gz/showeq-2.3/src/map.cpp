/*
 * map.cpp
 *
 * ShowEQ Distributed under GPL
 * http://www.hackersquest.gomp.ch/
 */

#include "map.h"
#include <qpainter.h>
#include <qpixmap.h>
#include <qfont.h>
#include <qfiledialog.h>
#include <qevent.h>
#include <qpushbutton.h>
#include <qlayout.h>

#include <math.h>
#include <stdlib.h>
#include <stdio.h>

#include "util.h"
#include "main.h"
#include "filter.h"
#include "spawnlist.h"

//#define DEBUG

//#define DEBUGMAP

#undef DEBUG

CLineDlg::CLineDlg(QWidget *parent, QString name, QWidget *map) : QDialog(parent, name, FALSE)
{
#ifdef DEBUG
   debug ("CLineDlg()");
#endif /* DEBUG */
   
   
   Map *pMap = (Map*)map;

   QBoxLayout *topLayout = new QVBoxLayout(this);
   QBoxLayout *row2Layout = new QHBoxLayout(topLayout);
   QBoxLayout *row1Layout = new QHBoxLayout(topLayout);

   QLabel *colorLabel = new QLabel ("Color", this);
   colorLabel->setFont(QFont("Helvetica", 12, QFont::Bold));
   colorLabel->setFixedHeight(colorLabel->sizeHint().height());
   colorLabel->setFixedWidth(colorLabel->sizeHint().width()+10);
   colorLabel->setAlignment(QLabel::AlignLeft|QLabel::AlignVCenter);
   row1Layout->addWidget(colorLabel);

   m_LineColor = new QComboBox(FALSE, this, "LineColor");
   m_LineColor->insertItem("gray");
   m_LineColor->insertItem("darkBlue");
   m_LineColor->insertItem("darkGreen");
   m_LineColor->insertItem("darkCyan");
   m_LineColor->insertItem("darkRed");
   m_LineColor->insertItem("darkMagenta");
   m_LineColor->insertItem("darkYellow");
   m_LineColor->insertItem("darkGray");
   m_LineColor->insertItem("white");
   m_LineColor->insertItem("blue");
   m_LineColor->insertItem("green");
   m_LineColor->insertItem("cyan");
   m_LineColor->insertItem("red");
   m_LineColor->insertItem("magenta");
   m_LineColor->insertItem("yellow");
   m_LineColor->insertItem("white");

   m_LineColor->setFont(QFont("Helvetica", 12));
   m_LineColor->setFixedHeight(m_LineColor->sizeHint().height());
   m_LineColor->setFixedWidth(m_LineColor->sizeHint().width());
   row1Layout->addWidget(m_LineColor, 0, AlignLeft);

   m_ColorPreview = new QFrame(this);
   m_ColorPreview->setFrameStyle(QFrame::Box|QFrame::Raised);
   m_ColorPreview->setFixedWidth(50);
   m_ColorPreview->setFixedHeight(m_LineColor->sizeHint().height());
   m_ColorPreview->setPalette(QPalette(QColor(gray)));
   row1Layout->addWidget(m_ColorPreview);

   // Hook on when a color changes
   connect(m_LineColor, SIGNAL(activated(const QString &)), map, SLOT(setLineColor(const QString &)));
   connect(m_LineColor, SIGNAL(activated(const QString &)), SLOT(changeColor(const QString &)));

   QLabel *nameLabel = new QLabel ("Name", this);
   nameLabel->setFont(QFont("Helvetica", 12, QFont::Bold));
   nameLabel->setFixedHeight(nameLabel->sizeHint().height());
   nameLabel->setFixedWidth(nameLabel->sizeHint().width()+5);
   nameLabel->setAlignment(QLabel::AlignLeft|QLabel::AlignVCenter);
   row2Layout->addWidget(colorLabel);

   m_LineName  = new QLineEdit(this, "LineName");
   m_LineName->setFont(QFont("Helvetica", 12, QFont::Bold));
   m_LineName->setFixedHeight(m_LineName->sizeHint().height());
   m_LineName->setFixedWidth(150);
   row2Layout->addWidget(m_LineName);

   // Hook on when the line name changes
   connect(m_LineName, SIGNAL(textChanged(const QString &)), map, SLOT(setLineName(const QString &)));

   QPushButton *ok = new QPushButton("OK", this);
   ok->setFixedWidth(30);
   ok->setFixedHeight(30);
   topLayout->addWidget(ok, 0, AlignCenter);

   // Hook on pressing the OK button
   connect(ok, SIGNAL(clicked()), SLOT(accept()));

   for (int i=0; i<m_LineColor->count(); i++)
   {
      if (m_LineColor->text(i) == pMap->curLineColor)
      {
	 m_LineColor->setCurrentItem(i);
      }
   }
   m_LineName->setText(pMap->curLineName);

   //setFixedSize(175, 80); 

}

void CLineDlg::changeColor(const QString &color)
{
#ifdef DEBUG
   debug ("changeColor()");
#endif /* DEBUG */
   m_ColorPreview->setPalette(QPalette(QColor(color)));
}

//Map::Map (QListView * lv, QWidget * parent, const char *name):QWidget (parent, name)
Map::Map (CSpawnList* lv, QWidget * parent, const char *name):QWidget (parent, name)
{
#ifdef DEBUG
   debug ("Map()");
#endif /* DEBUG */
   ang = 0;
   curPlayerX=0;
   curPlayerY=0;

   m_pSpawnList = lv;

   x = 0;
   y = 0;
   z = 0;
   DeltaX = 0;
   DeltaY = 0;
   DeltaZ = 0;
   memset(&playerTime,0,sizeof(playerTime));
   
   groupSize = 0;
   m_bKeepUpdated = 0;
   m_nFlash = 0;
   m_bFlash = FALSE;
   selectedColumn = 0;
   playerID=1;
   playerRace=0;
   playerClass=0;
   maxX = 50;
   minX = -50;
   maxY = 50;
   minY = -50;
   mapLengthX = 100;
   mapLengthY = 100;
   numLocations = 0;
   playerAngle = -1;
   ZoomAmmount = 1;
   nomap = 1;
   screenCenterX = 300;
   screenCenterY = 300;
   screenLengthX = 600;
   screenLengthY = 600;
   m_XOffset = 0;
   m_YOffset = 0;
   m_RatioX = 1;
   m_RatioY = 1;
   playerLevel = 1;
   numLocations = 0;
   numLines = 0;
   numSpawns = 0;
   numDrops = 0;
   numCoins = 0;
   curLineColor = "gray";
   curLineName = "line";
   strcpy (zoneShort, "unknown");
   strcpy (zoneLong, "Unknown Zone");
   sprintf(filename, "%s/unknown.map", MAPDIR);
   listView = lv;

// Appologies to whoever put this in... there was no changelog with a name
// I was just committing category support.  I think this should be done 
// with categories  - Maerlyn
#if 0
   NPClist = new SpawnListItem(listView, "NPC", "0", "0", 
                  "0", "0", "0", "0", "0"); 
   PClist = new SpawnListItem(listView, "PC", "0", "0", 
                  "0", "0", "0", "0", "0"); 
   DROPlist = new SpawnListItem(listView, "DROP", "0", "0", 
                  "0", "0", "0", "0", "0"); 
#endif
   
   mapImage.resize(screenLengthX, screenLengthY);
   mapImage.fill(black);
   for (x = 0; x<4096;x++){
        firstPoint[x].next = 0;
        linePoint[x].next = 0;
   }
   x = 0;

   dlgLineProps = NULL;

   // Initialize spawn filters
   int cFlags = 0;
   if (showeq_params->spawnfilter_case)
   {
     cFlags |= REG_ICASE;
   }
   m_pSpawnFilter = new Filter(showeq_params->filterfile, 
        "Spawn", cFlags);
   m_pAlertFilter = new Filter(showeq_params->filterfile, 
        "Alert", cFlags);
   m_pSpawnFilter_Level = new Filter(showeq_params->filterfile, 
        "Level", cFlags);
   m_pSpawnFilter_HP = new Filter(showeq_params->filterfile, 
        "HP", cFlags);
   m_pSpawnFilter_MaxHP = new Filter(showeq_params->filterfile, 
        "MaxHP", cFlags);
   m_pSpawnFilter_Dist = new Filter(showeq_params->filterfile, 
        "Dist", cFlags);
   m_pSpawnFilter_Race = new Filter(showeq_params->filterfile, 
        "Race", cFlags);
   m_pSpawnFilter_Class = new Filter(showeq_params->filterfile, 
        "Class", cFlags);
   m_pSpawnFilter_Info = new Filter(showeq_params->filterfile, 
        "Info", cFlags);

} // end Map() constructor

Map::~Map(void)
{
   m_pSpawnFilter->saveFilters();
   m_pAlertFilter->saveFilters();
   m_pSpawnFilter_Level->saveFilters();
   m_pSpawnFilter_HP->saveFilters();
   m_pSpawnFilter_MaxHP->saveFilters();
   m_pSpawnFilter_Dist->saveFilters();
   m_pSpawnFilter_Race->saveFilters();
   m_pSpawnFilter_Class->saveFilters();
   m_pSpawnFilter_Info->saveFilters();

   delete m_pSpawnFilter;
   delete m_pAlertFilter;
   delete m_pSpawnFilter_Level;
   delete m_pSpawnFilter_HP;
   delete m_pSpawnFilter_MaxHP;
   delete m_pSpawnFilter_Dist;
   delete m_pSpawnFilter_Race;
   delete m_pSpawnFilter_Class;
   delete m_pSpawnFilter_Info;
}


int
Map::ID2Index(int id)
{
   for (int n = 0; n < numSpawns; n++)
   {
      if (spawns[n].spawnId == id)
        return n;
   }

   return -1;
}


QSize Map::sizeHint() const // preferred size
{
#ifdef DEBUG
   debug ("sizeHint()");
#endif /* DEBUG */

   return QSize(600, 600);
}

QSize Map::minimumSizeHint() const // minimum size
{
#ifdef DEBUG
   debug ("minimumSizeHint()");
#endif /* DEBUG */
   return QSize(300, 300);
}

QSizePolicy Map::sizePolicy() const // size policy
{
#ifdef DEBUG
   debug ("sizePolicy()");
#endif /* DEBUG */
   return QSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
}

void Map::mousePressEvent (QMouseEvent * me)
{
#ifdef DEBUG
   debug ("mousePressEvent()");
#endif /* DEBUG */
   if (me->button () == RightButton)
     printf ("%d, %d\n", me->x (), me->y ());

   mapClicked = 1;
   mapClickedX = me->x ();
   mapClickedY = me->y ();
   if(!showeq_params->fast_machine)
     refreshMap ();
}

void Map::ZoomIn()
{
#ifdef DEBUG
   debug("Map::ZoomIn()");
#endif DEBUG
   ZoomAmmount *= 2;

   reAdjust ();
   if(!showeq_params->fast_machine)
     refreshMap ();
}

void Map::ZoomOut()
{
#ifdef DEBUG
   debug("Map::ZoomOut()");
#endif DEBUG
   if (ZoomAmmount > 1)
   {
      ZoomAmmount /= 2;
   }

   reAdjust();
   if(!showeq_params->fast_machine)
     refreshMap ();
}

void Map::resizeEvent (QResizeEvent *qs)
{
#ifdef DEBUG
   debug ("resizeEvent()");
#endif /* DEBUG */
   screenLengthX = qs->size().width();
   screenLengthY = qs->size().height();

   screenCenterX = screenLengthX/2;
   screenCenterY = screenLengthY/2;

   mapImage.resize(screenLengthX,screenLengthY);
   mapImage.fill();

   reAdjust();
}

void Map::dumpSpawns (void)
{
#ifdef DEBUG
   debug ("dumpSpawns()");
#endif /* DEBUG */

   for (int n = 0; n < numSpawns; n++)
      printf("%s\n", dumpSpawn(n));
}

void Map::zoneChanged (void)
{
#ifdef DEBUG
   debug ("zoneChanged()");
#endif /* DEBUG */
   ang = 0;
   x = 0;
   y = 0;

   maxX=50; minX=-50; maxY=50; minY=-50;
   mapLengthX = 100;
   mapLengthY = 100;
   numLocations=0;
   numLines=0;

   mapImage.resize(screenLengthX, screenLengthY);
   mapImage.fill(black);

   for (int i = 0; i < 4096; i++)
      m_FlagsArray[i] = 0;

   // Delete listItems
   if (m_pSpawnList)
     m_pSpawnList->clear();
   for (int n=0; n<numSpawns; n++)
   {
      struct trackPoint *walk = firstPoint[n].next, *walk2 = 0;
      while (walk){
          walk2 = walk->next;
          free(walk);
          walk = walk2;
      }
   }
   for (int n=0; n<numLines; n++)
   {
      struct trackPoint *walk = linePoint[n].next, *walk2 = 0;
      while (walk){
          walk2 = walk->next;
          free(walk);
          walk = walk2;
      }
   }
   numLines = 0;
   numSpawns=0;

   numDrops = 0;
   numCoins = 0;
   numSpawns=0;

#if 0
   if (listView){

   NPClist = new SpawnListItem(listView, "NPC", "0", "0", 
                  "0", "0", "0", "0", "0"); 
   PClist = new SpawnListItem(listView, "PC", "0", "0", 
                  "0", "0", "0", "0", "0"); 
   DROPlist = new SpawnListItem(listView, "DROP", "0", "0", 
                  "0", "0", "0", "0", "0"); 
   }
#endif

   ZoomAmmount = 1;
   if(!showeq_params->fast_machine)
     refreshMap();
   emit newZoneName (QString("- Unknown -"));
   emit stsMessage(QString("- Busy Zoning -"));
   emit deleteSkills();
}

void Map::newZone (char *zLong, char *zShort)
{
#ifdef DEBUG
   debug ("newZone()");
#endif /* DEBUG */

   if (pSEQPrefs->GetPrefBool("Interface_UseStdout"))
      printf("newZone - '%s'\n", zShort);

   char
     newfname[4096];
   sprintf (newfname, "%s/%s.map", MAPDIR,zShort);
   strcpy (zoneShort, zShort);
   strcpy (zoneLong, zLong);
   setFilename (newfname);

//   char
//     message[128];
//   sprintf (message, "%s [%s]", zoneLong, zoneShort);
//   emit newZoneName (QString (message));
   emit newZoneName (QString(zoneLong));
   emit stsMessage(QString(""));
   loadFileMap ();
}

void Map::infoSpawn (int id)
{
   printf ("Printing info on spawn ID %d\n", id);

   int
     found = 0;
   for (int n = 0; n < numSpawns; n++)
   {
      if (spawns[n].spawnId == id)
      {
	 found = n + 1;
	 break;
      }
   }

   if (!found)
   {
      printf ("ID Not found\n");
      return;
   }

}

void Map::deleteSpawn (int id)
{
#ifdef DEBUG
   debug ("deleteSpawn()");
#endif /* DEBUG */

   int n = ID2Index(id);
   n = n;

   if (-1 != n)
   {
     if (showeq_params->despawnalert)
     {
       // DeSpawn Alerting
//       if (m_pAlertFilter->isFiltered(spawns[n].name))
       if (m_pAlertFilter->isFiltered(spawnAlertName(n)))
       {
          QString temp("DeSpawn: ");
          if (pSEQPrefs->GetPrefBool("Filters_AlertInfo"))
          {
             char tempstr[256];
             processEquipment(&spawns[n], tempstr);
             temp.sprintf("%s%s/%s/%s/%s", temp.ascii(),
                 spawns[n].name, race_name(spawns[n].race), 
                 class_name(spawns[n].class_),
                 light_name(spawns[n].light), tempstr);
          }
          else 
            temp += spawns[n].name;
          emit
            msgReceived(temp);
 
          // Gereric system beep for those without a soundcard
          //
          if (!pSEQPrefs->GetPrefBool("Filters_SpawnFilterAudio"))
          {
            printf ("\a");
          }
          else
          {
            //plays a wav file
            const char *command;

            command = pSEQPrefs->GetPrefString("Filters_DeSpawnAudioCommand");
            if (*command)
            {
//               system ("/usr/bin/esdplay spawn.wav &");
                 system (command);
            }
          }
        }
      } // end if despawnalert

      // delete from spawnlist 
      m_pSpawnList->DeleteItem(tSpawn, id);

      // delete from map array
      // copy the last spawn into this array slot
      memcpy(&spawns[n], &spawns[numSpawns - 1], sizeof(spawnStruct));
      memcpy(&spawnTime[n], &spawnTime[numSpawns - 1], sizeof(struct timeval));
      struct trackPoint *walk = firstPoint[n].next, *walk2 = 0;
      while (walk){
          walk2 = walk->next;
          free(walk);
          walk = walk2;
      }
      memcpy(&firstPoint[n],&firstPoint[numSpawns - 1], sizeof(struct trackPoint));
      strcpy (spawnInfo[n], spawnInfo[numSpawns - 1]);
      n = 50;
      // delete the last spawn
      if (numSpawns > 0)
	numSpawns--;
   }

} // end deleteSpawn


void Map::spawnWearingUpdate(wearChangeStruct *wearing)
{
#ifdef DEBUG
   debug ("spawnWearingUpdate()");
#endif /* DEBUG */

//printf("Spawn %i was going to wear %i in slot %i.\n", wearing->spawnId, wearing->newItemId, wearing->wearSlotId);
   
   if ((wearing->wearSlotId < 9))
   {
     int n = ID2Index(wearing->spawnId);
     if (-1 != n)
     {
	spawns[n].equipment[wearing->wearSlotId] = wearing->newItemId;
	processEquipment (&spawns[n], spawnInfo[n]);

        // update spawnlist
        if (m_pSpawnList)
           m_pSpawnList->UpdateSpawn(&spawns[n]);

	/* Buh-Bye silly Wearing updates   - JohnQ
        if (*spawnInfo[n])
        {
          QString temp("");
          temp.sprintf("Wearing: '%s' - '%s'", spawns[n].name, spawnInfo[n]);
          emit
             msgReceived(temp);
        }
	*/
     }
   }

} // end spawnWearingUpdate()

void Map::killSpawn (int id)
{
#ifdef DEBUG
   debug ("killSpawn\n");
#endif /* DEBUG */
   
   int n = ID2Index(id);
   if (-1 != n)
   {
      // Spawn Death Alerting
      if (m_pAlertFilter->isFiltered(spawnAlertName(n)))
      {
         QString temp("Died: ");
         temp += spawns[n].name;
         emit
           msgReceived(temp);
      }
      spawns[n].curHp = -1;
      if (spawns[n].NPC == 0)
        spawns[n].NPC = 2;	//player corpse
      else
        spawns[n].NPC = 3;	//monster corpse

      // update spawnlist
      if (m_pSpawnList)
      {
        m_pSpawnList->UpdateSpawn(&spawns[n]);

        if (isFiltered(n))
        {
          SpawnListItem *i;
          i = m_pSpawnList->FindItem(tSpawn, spawns[n].spawnId);

          while(i)
          {
             i->setFlags(i->flags() | spawnFiltered);
             m_FlagsArray[n] = i->flags();
             i = m_pSpawnList->FindNext(i, tSpawn, spawns[n].spawnId);
          }
          refreshMap();
        }
      }


      // update status bar if we had this spawn selected
      if (id == selectedSpawnId)
      {
        QString string("");
        string.sprintf("%s died", spawns[n].name);
        emit stsMessage(string);
      }
   }

} // end killSpawn(id)

void Map::refreshMap (void)
{
#ifdef DEBUG
   debug ("refreshMap()");
#endif /* DEBUG */
   repaint (mapRect (), FALSE);
}

void Map::setPlayerID (int id) {
  int n;
  //if (playerID != id)     
  //   printf("Your player's id is %i\n", id);
  playerID=id;
  for (n = 0;n<numSpawns;n++)
  {
      if (spawns[n].NPC == 10) //Self NPC number.
      {
         spawns[n].spawnId = id;
         // update spawnlist
         if (m_pSpawnList)
            m_pSpawnList->UpdateSpawn(&spawns[n]);
      }
  }
}

void Map::setPlayerRace (int race) {
//  if (playerRace != race) 
//    printf("Your player's race is %s\n", race_name(race));
  playerRace=race;
}

void Map::setPlayerClass(int class_) {
//  if (playerClass != class_) 
//    printf("Your player's class is %s\n", class_name(class_));
  playerClass=class_;
}

void 
Map::attack1Hand1(attack1Struct * atk1)
{
#if 0
printf("Attack1: '%s' hit by %d damage (%d:%d:%d:%d:%d:%d)\n", 
  spawns[ID2Index(atk1->spawnId)].name, atk1->unknown2, 
  atk1->unknown1,
  atk1->unknown2,
  atk1->unknown3,
  atk1->unknown4,
  atk1->unknown5
 );
#endif
  if (showeq_params->sparr_messages)
  {
    //if (atk1->spawnId == playerID || atk1->spawnId == selectedSpawnId)
    {
        QString temp("");
        temp.sprintf("ATTACK1: %i, u1:%i, u2:%i, u3:%i, u4:%i, u5:%i",
           atk1->spawnId,
	   atk1->unknown1,
	   atk1->unknown2,
	   atk1->unknown3,
	   atk1->unknown4,
	   atk1->unknown5);
        emit
           msgReceived(temp);
    }
  }
}

void 
Map::attack2Hand1(attack2Struct * atk2)
{
#if 0
printf("Attack2: '%s' hit by %d damage (%d:%d:%d:%d:%d:%d)\n", 
  spawns[ID2Index(atk2->spawnId)].name, atk2->unknown2, 
  atk2->unknown1,
  atk2->unknown2,
  atk2->unknown3,
  atk2->unknown4,
  atk2->unknown5
 );
#endif
  if (showeq_params->sparr_messages)
  {
    //if (atk2->spawnId == playerID || atk2->spawnId == selectedSpawnId)
    {
        QString temp("");
        temp.sprintf("ATTACK2: %i, u1:%i, u2:%i, u3:%i, u4:%i, u5:%i",
           atk2->spawnId,
	   atk2->unknown1,
	   atk2->unknown2,
	   atk2->unknown3,
	   atk2->unknown4,
	   atk2->unknown5);
        emit
           msgReceived(temp);
    }
  }
}


void Map::updateSpawnHp (int id, int hp, int maxhp)
{
#ifdef DEBUG
   debug ("updateSpawnHp()");
#endif /* DEBUG */

   if(id==playerID) {
     emit hpChanged(hp,maxhp);
     //return;
   }

   int n = ID2Index(id);
   if (-1 != n)
   {
	 spawns[n].curHp = hp;
	 spawns[n].maxHp = maxhp;

         // update status bar if we had this spawn selected
         if (id == selectedSpawnId)
         {
            emit selSpawnUpdate(x,y);
            updateSpawnStatus(n);

            if (spawns[n].NPC == 3)
            {
              QString string("");
              string.sprintf("%s died", spawns[n].name);
              emit stsMessage(string);
            }
         }

         // update spawnlist
         if (m_pSpawnList)
            m_pSpawnList->UpdateSpawn(&spawns[n]);
   }

} // end updateSpawnHP

void Map::checkPos (int x, int y)
{
   int
     flag = 0;

#ifdef DEBUG
   debug ("checkPos()");
   printf("in x: %i, in y: %i, max(%i,%i) Min(%i,%i)\n", x,y,maxX,maxY, minX,minY);
#endif /* DEBUG */

   if (x && y)
   {
      if (x > maxX)
      {
	 maxX = x;
	 flag = 1;
      }
      if (y > maxY)
      {
	 maxY = y;
	 flag = 1;
      }
      if (x < minX)
      {
	 minX = x;
	 flag = 1;
      }
      if (y < minY)
      {
	 minY = y;
	 flag = 1;
      }

      if (flag)
	reAdjust ();
   }
}

void Map::updateSpawn (int id, int x, int y, int z, int xVel, int yVel, int zVel)
{
#ifdef DEBUG
   debug ("updateSpawn()");
#endif /* DEBUG */

   checkPos (x, y);

   int n = ID2Index(id);
   if (-1 != n)
   {
	 spawns[n].xPos = x;
	 spawns[n].yPos = y;
	 spawns[n].zPos = z;
	 spawns[n].deltaX = xVel;
	 spawns[n].deltaY = yVel;
	 spawns[n].deltaZ = zVel;
	 gettimeofday( &spawnTime[n] , &tz);

         // update spawnlist
         if (m_pSpawnList)
            m_pSpawnList->UpdateSpawn(&spawns[n]);
         if (spawns[n].NPC == 10 && firstPoint[n].x == 0 && firstPoint[n].y == 0){
             //Clean up that annoying line from origin to your first real spot.
             firstPoint[n].x = x;
             firstPoint[n].y = y;
             firstPoint[n].z = z;             
         }
            if(showeq_params->walkpathrecord)
            {
                struct trackPoint *walk = firstPoint[n].next, *walk2;
                //printf("Following %i's trail.\n", n);
                int cnt = 1;
                walk2 = &firstPoint[n];
                while (walk){
                    //printf("%i (%i,%i) spot.\n", cnt, walk->x, walk->y);
                    walk2 = walk;
                    walk = walk->next;
                    cnt++;
                }
                if (walk2 && (walk2->x !=spawns[n].xPos || walk2->y != spawns[n].yPos)){
                    if (showeq_params->walkpathlength>0 && cnt > 2 && cnt > showeq_params->walkpathlength && walk2 != 0){
                        walk2->next = firstPoint[n].next;
                        firstPoint[n].x = firstPoint[n].next->x;
                        firstPoint[n].y = firstPoint[n].next->y;
                        firstPoint[n].z = firstPoint[n].next->z;
                        firstPoint[n].next = firstPoint[n].next->next;
                    }
                    else{
                        walk2->next = (trackPoint*) malloc(sizeof(struct trackPoint));
                    }
                    walk = walk2->next;
                    if(walk){
                       walk->x = spawns[n].xPos;
                       walk->y = spawns[n].yPos;
                       walk->z = spawns[n].zPos;
                       walk->next = 0;
                    }
                }//if walk2
            }

	 return;
   }

   // We didn't find them, lets put a dot out for them.
   // This happens if you didn't catch the zone packets
   // only id, position, velocity is sent 
   else if (showeq_params->showUnknownSpawns) 
   {
     spawnStruct aspawn;
     memset (&aspawn, 0, sizeof(spawnStruct));
     sprintf(aspawn.name ,"unknown");
     aspawn.spawnId = id;
     aspawn.xPos = x;
     aspawn.yPos = y;
     aspawn.zPos = z;
     aspawn.deltaX = xVel;
     aspawn.deltaY = yVel;
     aspawn.deltaZ = zVel;
     aspawn.NPC = 5;
     newSpawn(&aspawn, 0);
   }

   // if we have this spawn selected, update its info on the status bar
   if ( (id == selectedSpawnId) && m_bKeepUpdated)
      updateSpawnStatus(n);

} // end updateSpawn

void Map::selectSpawn (QListViewItem * slv)
{

  /* printf ("%s\n", slv->text(0)); */
   if (slv && slv->text(7))
     selectedSpawnId = atoi (slv->text (7));
   else
     selectedSpawnId = 0;
   if(!showeq_params->fast_machine)
     refreshMap ();

   // update the spawn info on the statusbar
   updateSpawnStatus(ID2Index(selectedSpawnId));
}

void Map::newSpawn (spawnStruct *aspawn, int selected)
{
#ifdef DEBUG
   printf ("newSpawn(%s)\n",aspawn->name);
#endif /* DEBUG */

  /* Check if we don't already have this spawn */
   int n, i;
   char sinfo[256];
   char buff[80];
   if (aspawn->NPC == 10)
       aspawn->spawnId = playerID;
   n = ID2Index(aspawn->spawnId);
   if (-1 == n)
   {
     if (numSpawns >=4095)
     {
        printf("We lost a spawn %s\n  No more room for spawns.\n\a", 
           aspawn->name);
        return;
     }
     n = numSpawns;  
     numSpawns++;
     emit numSpawns_(numSpawns);
   }


   /* This is a new spawn, add it */
   memcpy (&spawns[n], aspawn, sizeof(spawnStruct));
   gettimeofday( &spawnTime[n] , &tz);
   //no extra space in memory for this, and it's safer to have this here.
   firstPoint[n].x = spawns[n].xPos;
   firstPoint[n].y = spawns[n].yPos;
   firstPoint[n].next = 0;
//printf("NewSpawn: '%s' %d\n", aspawn->name, n);

   processEquipment (aspawn, spawnInfo[n]);

   // Add to spawnlist if we are showing all spawns
   int spawnFlags = 0;
   if (isFiltered(n))
     spawnFlags |= spawnFiltered;

   if (m_pSpawnList)
     SpawnListItem* i = m_pSpawnList->InsertSpawn(&spawns[n], spawnFlags);

   // Select spawn in spawnlist
   if (selected)
   {
      if (m_pSpawnList)
         m_pSpawnList->SelectItem(tSpawn, spawns[n].spawnId);
   }

   // Spawn Alerting
   if (m_pAlertFilter->isFiltered(spawnAlertName(n)))
   {
      QString temp("Spawn: ");
      if (pSEQPrefs->GetPrefBool("Filters_AlertInfo"))
      {
         char tempstr[256];
         processEquipment(&spawns[n], tempstr);
         temp.sprintf("%s%s/%s/%s/%s", temp.ascii(),
             spawns[n].name, race_name(spawns[n].race), 
             class_name(spawns[n].class_),
             light_name(spawns[n].light), tempstr);
      }
      else 
        temp += spawns[n].name;
      emit
        msgReceived(temp);

      // Gereric system beep for those without a soundcard
      //
      if (!pSEQPrefs->GetPrefBool("Filters_SpawnFilterAudio"))
      {
        printf ("\a");
      }
      else
      {
        //plays a wav file
        const char *command;

        command = pSEQPrefs->GetPrefString("Filters_SpawnAudioCommand");
        if (*command)
        {
//           system ("/usr/bin/esdplay spawn.wav &");
             system (command);
        }
      }
   }

} // end newSpawn()


void 
Map::newGroundItem (dropThingOnGround *adrop)
{
//printf("dropThingOnGround()\n");
   int n, newdrop = 1, thingnum;
   char sinfo[256]="";
   char sinfo2[128];
   for (n = 0; n < numDrops; n++)
   {
      if (drops[n].dropId == adrop->dropId)
      {
	 newdrop = 0;
	 break;
      }
   }
   if (n >=512)
   {
      printf("We lost a drop %s\n  No more room for new dropped items.\n\a", 
          adrop->idFile);
      return;
   }
  /* This is a new spawn, add it */

   memcpy (&drops[n], adrop, sizeof(dropThingOnGround));

   strcpy(sinfo, getitemNameFromDB(drops[n].itemNr));
   if (strlen(sinfo) == 0){
     strcpy(sinfo, drops[n].idFile);
     //printf("idfile: %s\n", sinfo);
     if(drops[n].idFile[0] == 'I' && drops[n].idFile[1] == 'T'){
        strcpy(sinfo, drops[n].idFile + 2);
     }
     //printf("trimmed: %s\n", sinfo);
     thingnum = atoi(sinfo);
     //printf("thingnum: %i\n", thingnum);
     if (thingnum > 0)
         sprintf(sinfo,"Drop: %s", print_weapon(thingnum));
     else
         sprintf(sinfo,"Drop: %s", drops[n].idFile);
   }//not found thing in DB 
   else{
        strcpy(sinfo2,sinfo);
	sprintf(sinfo,"Drop: '%s'", sinfo2);
   }
   dropInfo[n][0] = 0;
   sprintf(dropInfo[n], "%i", drops[n].itemNr);

   // insert the item into the list
   if (m_pSpawnList)
     m_pSpawnList->InsertDrop(&drops[n]);

#if 0
   {
      dropItem[n]->setText (0, name);
      dropItem[n]->setText (1, strL);
      dropItem[n]->setText (2, strHP);
      dropItem[n]->setText (3, strMaxHP);
      dropItem[n]->setText (4+showeq_params->retarded_coords, strX);
      dropItem[n]->setText (5-showeq_params->retarded_coords, strY);
      dropItem[n]->setText (6, strZ);
	      /*  7 = id */
      dropItem[n]->setText (8, strDist);
   }
   else
   {
      QListViewItem *pck;
      if (DROPlist)
        dropItem[n] =
          new QListViewItem (DROPlist, name, strL, strHP, strMaxHP, strX,
			   strY, strZ, strId);
      else if (listView)
        dropItem[n] =
          new QListViewItem (listView, name, strL, strHP, strMaxHP, strX,
			   strY, strZ, strId);

   }
   //dropInfo[n][0]=0;
   dropItem[n]->setText (8, strDist);
   dropItem[n]->setText (9, srace);
   dropItem[n]->setText (10, sclass);
   dropItem[n]->setText (11, dropInfo[n]);

   //return;

#endif 1.74
   if (n == numDrops) numDrops++;

}

void Map::newCoinsItem (dropCoinsStruct *adrop)
{
printf("newCoinsItem()\n");
   int n, newcoin = 1, thingnum;
   for (n = 0; n < numCoins; n++)
   {
      if (coins[n].dropId == adrop->dropId)
      {
	 newcoin = 0;
	 break;
      }
   }
   if (n >=512)
   {
      printf("We lost a coin %s %d\n  No more room for new dropped items.\n\a", adrop->type,adrop->amount);
      return;
   }

   // add to our local copy
   memcpy (&coins[n], adrop, sizeof(dropCoinsStruct));
#if 0
   char
     strX[64], strY[64], strZ[64], strL[64], strHP[64], strMaxHP[64], strId[64],
     strDist[64], name[64], srace[64], sclass[64];
   sprintf (strX, "%5d", (int)coins[n].xPos);
   sprintf (strY, "%5d", (int)coins[n].yPos);
   sprintf (strZ, "%5d", (int)coins[n].zPos);
   sprintf (strL, "%2d", 0);
   sprintf (strHP, "%5d", 1);
   sprintf (strMaxHP, "%5d", 1);
   sprintf (strId, "%d", 0 - coins[n].dropId);
   sprintf (strDist, "%5d", calcDist ((int)coins[n].xPos, (int)coins[n].yPos));
   sprintf (name,"Coins: %c %d",adrop->type[0],adrop->amount);
   sprintf (srace, "%s", "Coins");
   sprintf (sclass, "%s", "Thing");

   if (coinItem[n])
   {
      coinItem[n]->setText (0, name);
      coinItem[n]->setText (1, strL);
      coinItem[n]->setText (2, strHP);
      coinItem[n]->setText (3, strMaxHP);
      coinItem[n]->setText (4+showeq_params->retarded_coords, strX);
      coinItem[n]->setText (5-showeq_params->retarded_coords, strY);
      coinItem[n]->setText (6, strZ);
	      /*  7 = id */
      coinItem[n]->setText (8, strDist);
   }
   else
   {
      if (DROPlist)
        coinItem[n] =
          new QListViewItem (DROPlist, name, strL, strHP, strMaxHP, strX,
			   strY, strZ, strId);
      else if (listView)
          new QListViewItem (listView, name, strL, strHP, strMaxHP, strX,
			   strY, strZ, strId);
   }
#endif

   // add coin to spawnlist
   if (m_pSpawnList)
      m_pSpawnList->InsertCoins(&coins[n]);

   if (n == numCoins) numCoins++;
}

void Map::removeGroundItem(removeThingOnGround* adrop)
{
//printf("removeGroundItem()\n");
   int found = 0;
   for (int n = 0; n < numDrops; n++)
   {
      if (drops[n].dropId == adrop->dropId)
      {
	 found = n + 1;
	 break;
      }
   }

   if (found && numDrops)
   {
      // remove the item from the spawnlist
      if (m_pSpawnList)
         m_pSpawnList->DeleteItem(tDrop, drops[found - 1].dropId);

      memcpy(&drops[found - 1], &drops[numDrops - 1], sizeof(dropThingOnGround));
      strcpy (dropInfo[found - 1], dropInfo[numDrops - 1]);

      if (numDrops > 0)
	numDrops--;
   }
}

void Map::removeCoinsItem(removeCoinsStruct* adrop)
{
//printf("removeCoinsItem()\n");
   int found = 0;
   for (int n = 0; n < numCoins; n++)
   {
      if (coins[n].dropId == adrop->dropId)
      {
	 found = n + 1;
	 break;
      }
   }

   if (found && numCoins)
   {
      // delete item from spawnlist
      if (m_pSpawnList)
         m_pSpawnList->DeleteItem(tCoins, coins[found - 1].dropId);

      memcpy(&coins[found - 1], &coins[numCoins - 1], sizeof(dropCoinsStruct));

      if (numCoins > 0)
	numCoins--;
   }
}


void Map::setFilename (char *newfilename)
{
#ifdef DEBUG
   debug ("setFilename()");
#endif /* DEBUG */
   strcpy (filename, newfilename);
}

void Map::saveMap ()
{
#ifdef DEBUG
   debug ("saveMap()");
#endif /* DEBUG */
   FILE *
     fh;

   fh = fopen (filename, "w");
   fprintf (fh, "%s,%s,%d,%d,%d,%d,%d,%d\n", zoneLong, zoneShort,
	    screenCenterX, screenCenterY, screenLengthX, screenLengthY,
	    mapLengthX, mapLengthY);
   for (int l = 0; l < numLines; l++)
   {
      if (linePoints[l]> 1)
      {
	 //Don't save lines where they just hit the line button. Andrew
         if (lineType[l] == 0){
	     fprintf (fh, "L,%s,%s,%d", (const char*)lineName[l], (const char*)lineColor[l], linePoints[l]);
         }else{
	     fprintf (fh, "M,%s,%s,%d", (const char*)lineName[l], (const char*)lineColor[l], linePoints[l]);
         }//line type
         struct trackPoint *walk = &linePoint[l];
         while (walk != 0)
	 //for (int n = 0; n < linePoints[l]; n++)
	 {
             if (lineType[l] == 0){
   	         fprintf (fh, ",%d,%d", walk->x, walk->y);
             }else{
   	         fprintf (fh, ",%d,%d,%d", walk->x, walk->y, walk->z);
             }//line type
             walk = walk->next;
	 }//each point
	 fprintf (fh, "\n");
      }//enough pointes
   }//lines

   for (int n = 0; n < numLocations; n++)
   {
      fprintf (fh, "P,%s,0,%d,%d\n", (const char*)locationName[n], locationX[n], locationY[n]);
   }

#ifdef DEBUGMAP
   printf("saveMap() - map '%s' saved with %d lines, %d locations\n", filename,
      numLines, numLocations);
#endif
   fclose (fh);
}


void Map::loadMap ()
{
#ifdef DEBUG
   debug ("loadMap()");
#endif /* DEBUG */

   QString s(QFileDialog::getOpenFileName (MAPDIR, "*.map"));
   if (s.isNull ())
     return;

   strcpy(filename, s);
   loadFileMap();
}

void Map::setLineName(const QString &name)
{
   if (numLines)
     lineName[numLines-1] = name;

   curLineName = name;
}

void Map::setLineColor(const QString &color)
{
   if (numLines)
     lineColor[numLines-1] = color;

   curLineColor = color;

   if(!showeq_params->fast_machine)
     refreshMap ();
}

void Map::showLineDlg()
{
   // Creat the line properties dialog the first time it is needed
   if (dlgLineProps == NULL)
   {
      dlgLineProps = new CLineDlg(parentWidget(), "LineDlg", this);
   }

   dlgLineProps->show();
}

void Map::reAdjust ()
{
#ifdef DEBUG
   debug("Map::reAdjust()");
#endif DEBUG
   static int norecurse=0;
   if (norecurse){
       //printf("Tried to call reAdjust while IN reAjust already!\n");
       return;
   }
   norecurse = 1;
   double screenRatio= 1.0, xrat,yrat;
   int mScreenLength = screenLengthX<screenLengthY?screenLengthX:screenLengthY;
   int iZLenX, iZLenY;
   int iDeltaX, iDeltaY;
   int iMapCenX, iMapCenY;
   int iPlOffsetX, iPlOffsetY;
   int xoff=0, yoff=0;
   int pxrat,pyrat;
   //printf("re-adjust group 1\n");
   mapLengthX=maxX-minX;
   mapLengthY=maxY-minY;

   //printf("re-adjust group 2\n");
   // Zoom if we are zooming now
   //Andy:  Always execute zoom code, if it always works, then it is good code.
   //Andy:  I gave up on figuring out his zoom logic and decided to rebuild mine.

      pxrat=zoomMapLengthX=((mapLengthX)/(ZoomAmmount));
      pyrat=zoomMapLengthY=((mapLengthY)/(ZoomAmmount));

      if (zoomMapLengthX <= 8 || zoomMapLengthY <= 8){
	  norecurse = 0;
          ZoomOut();
          return;
      }
    
      xrat = (double)screenLengthX/zoomMapLengthX;
      yrat = (double)screenLengthY/zoomMapLengthY;

    if (xrat < yrat){
      zoomMapLengthY=(int)(screenLengthY/xrat);
      yoff = (zoomMapLengthY - pyrat)/2;
    }else{ 
      zoomMapLengthX=(int)(screenLengthX/yrat);
      xoff = (zoomMapLengthX - pxrat)/2;
    }
    if (ZoomAmmount > 1){
          yoff = 0;//(zoomMapLengthY - pyrat)/2;
          xoff = 0;//(zoomMapLengthX - pxrat)/2;
    }
    

   iZMaxX = curPlayerX + zoomMapLengthX/2;
   iZMinX = curPlayerX - zoomMapLengthX/2;

   iZMaxY = curPlayerY + zoomMapLengthY/2;
   iZMinY = curPlayerY - zoomMapLengthY/2;


      if (iZMinX < minX)
      {
	 iZMaxX -= (iZMinX - minX);
	 iZMinX -= (iZMinX - minX);
      }
      if (iZMinY < minY)
      {
	 iZMaxY -= (iZMinY - minY);
	 iZMinY -= (iZMinY - minY);
      }

      if (iZMaxX > maxX)
      {
	 iZMinX -= iZMaxX-maxX;
	 iZMaxX -= iZMaxX-maxX;
      }
      if (iZMaxY > maxY)
      {
	 iZMinY -= (iZMaxY-maxY);
	 iZMaxY -= (iZMaxY-maxY);
      }


    m_RatioX = (double)zoomMapLengthX/(double)screenLengthX;
    m_RatioY = (double)zoomMapLengthY/(double)screenLengthY;
    
    screenCenterX = (((iZMaxX + xoff)*screenLengthX) / zoomMapLengthX);
    screenCenterY = (((iZMaxY + yoff)*screenLengthY) / zoomMapLengthY);


   //printf("Done readjust(group 4)\n");
   norecurse = 0;
}

void Map::loadFileMap ()
{
#ifdef DEBUG
   debug ("loadFileMap()");
#endif /* DEBUG */
#define	MAX_LINE_LENGTH	16384
   FILE *fh;
   char line[MAX_LINE_LENGTH];
   char tempstr[MAX_LINE_LENGTH];
   int mx,my,mz, cnt;
   struct trackPoint *walk, *walk2;

   maxX = 0;
   minX = 0;
   maxY = 0;
   minY = 0;
   nomap = 1;
   showhidden = 0;

   for (int n=0; n<numLines; n++)
   {
      struct trackPoint *walk = linePoint[n].next, *walk2 = 0;
      while (walk){
          walk2 = walk->next;
          free(walk);
          walk = walk2;
      }
   }

   numLocations = 0;
   numLines = 0;

  /* Adjust X and Y for spawns on map */
   for (int n = 0; n < numSpawns; n++)
   {
      if (spawns[n].xPos > maxX)
	maxX = spawns[n].xPos;
      if (spawns[n].yPos > maxY)
	maxY = spawns[n].yPos;
      if (spawns[n].xPos < minX)
	minX = spawns[n].xPos;
      if (spawns[n].yPos < minY)
	minY = spawns[n].yPos;
   }

   if ((fh = fopen (filename, "r")) != NULL)
   {
      fgets (line, MAX_LINE_LENGTH, fh);
      strcpy (zoneLong, strtok (line, ","));	// Zone name
      strcpy (zoneShort, strtok (NULL, ","));	// Zone short name
      mapLengthX = atoi (strtok (NULL, ","));
      mapLengthY = atoi (strtok (NULL, "\n"));

      while (fgets (line, MAX_LINE_LENGTH, fh))
      {
	 strcpy (tempstr, strtok (line, ","));
	 switch (tempstr[0])
	 {

	  case 'L':
          case 'M':
            if (tempstr[0]=='M'){
                lineType[numLines]=1;
            }else if (tempstr[0]=='L'){
                lineType[numLines]=0;
            }

	    lineName[numLines] = strtok(NULL, ","); // Line Name
	    lineColor[numLines] = strtok(NULL, ","); // Line Color
	    linePoints[numLines] = atoi (strtok (NULL, ","));	// Number of points

            //printf("new Line:\n");

            walk = linePoint[numLines].next;
            //printf("Following %i's trail.\n", numLines);
            cnt = 1;
            walk = &linePoint[numLines];

	    for (int n = 0; n < linePoints[numLines]; n++)
	    {
                mx = atoi (strtok (NULL, ",\n"));
                my = atoi (strtok (NULL, ",\n"));
                if (lineType[numLines]==1){
                    mz = atoi (strtok (NULL, ",\n"));
                }else{
                    mz = 0;
                }

                if(walk){
                   walk->x = mx;
                   walk->y = my;
                   walk->z = mz;
                   //printf("new point: %i,%i,%i\n", mx,my,mz);
                   if (n < linePoints[numLines] -1){
                       walk->next = (trackPoint*) malloc(sizeof(struct trackPoint));
                       walk = walk->next;
                   }
                   walk->next = 0;
                } // walk
 
            
	       if (mx > maxX)
		 maxX = mx;
	       if (my > maxY)
		 maxY = my;
	       if (mx < minX)
		 minX = mx;
	       if (my < minY)
		 minY = my;
	    }
	    numLines++;
	    break;

	  case 'P':
	    locationName[numLocations] = strtok (NULL,","); // Location name
	    strtok(NULL, ","); // Location color
	    locationX[numLocations] = atoi (strtok (NULL, ",\n"));
	    locationY[numLocations] = atoi (strtok (NULL, ",\n"));
	    numLocations++;
	    break;
	 }
      }

      fclose (fh);
//      char message[128];
//      sprintf (message, "%s [%s]", zoneLong, zoneShort);
      char gfxfilename[64];
      sprintf (gfxfilename, "%s/%s.pgm", MAPDIR, zoneShort);

      reAdjust();
      mapImage.resize(screenLengthX, screenLengthY);
      mapImage.fill(black);

      if (mapImage.load (gfxfilename))
      {
	 nomap=0;
      }

//      emit newZoneName (QString(message));
      emit newZoneName (QString(zoneLong));
   }

   if (nomap)
   {
      mapImage.resize(screenLengthX, screenLengthY);
      mapImage.fill(black);
   }

   if(!showeq_params->fast_machine)
     refreshMap();
}

void Map::addLocation (void)
{
   //   locationName[numLocations] = curLocationName;
   //   locationColor[numLocations] = curLocationColor;
   locationName[numLocations].sprintf ("Loc#%d", numLocations);
   locationX[numLocations] = x;
   locationY[numLocations] = y;
   numLocations++;
   if(!showeq_params->fast_machine)
     refreshMap ();
#ifdef DEBUGMAP
   printf("addLocation(): Location %d added at %d/%d\n", numLocations, x, y); 
#endif
}

void Map::startLine (void)
{
#ifdef DEBUG
   debug ("startLine()");
#endif /* DEBUG */

   if (numLines > 4096)
   {
      printf("You have run out of lines, sorry.\n");
      return;
   }

   linePoints[numLines] = 1;
   linePoint[numLines].x = x;
   linePoint[numLines].y = y;
   linePoint[numLines].z = z;
   linePoint[numLines].next = 0;
   lineType[numLines] = 1;
   lineColor[numLines] = curLineColor;
   lineName[numLines] = curLineName;
   numLines++;

#ifdef DEBUGMAP
   printf("startLine():  Line %d started at %d/%d\n", numLines, x, y);
#endif
}

void Map::addLinePoint (void)
{
#ifdef DEBUG
   debug ("addLinePoint()");
#endif /* DEBUG */
    if (numLines == 0){
        startLine();
        return;
    }
        
                struct trackPoint *walk = linePoint[numLines-1].next, *walk2;
                //printf("Following %i's trail.\n", n);
                int cnt = 1;
                walk2 = &linePoint[numLines-1];
                while (walk){
                    //printf("%i (%i,%i) spot.\n", cnt, walk->x, walk->y);
                    walk2 = walk;
                    walk = walk->next;
                    cnt++;
                }
                if (walk2){
                    walk2->next = (trackPoint*) malloc(sizeof(struct trackPoint));
                    walk = walk2->next;
                    if(walk){
                       walk->x = x;
                       walk->y = y;
                       walk->z = z;
                       walk->next = 0;
                       linePoints[numLines - 1]++;
                    }
                    else
                    {
                        printf("You have run out of points, sorry.\n");
                     }
                }//if walk2
   if(!showeq_params->fast_machine)
     refreshMap ();
#ifdef DEBUGMAP
   printf("addLinePoint() - Point %d added: %d/%d\n", 
      linePoints[numLines - 1], x, y);
#endif
}


void Map::delLinePoint(void)
{
#ifdef DEBUG
   debug ("delLinePoint()");
#endif /* DEBUG */
    if (numLines == 0){
        return;
    }

   if (!linePoints[numLines])
   {
      printf("You have no more points, sorry.\n");
      return;
   }
                struct trackPoint *walk = linePoint[numLines-1].next, *walk2, *walk3;
                //printf("Following %i's trail.\n", n);
                int cnt = 1;
                walk3 = 0;
                walk2 = &linePoint[numLines-1];
                while (walk){
                    //printf("%i (%i,%i) spot.\n", cnt, walk->x, walk->y);
                    walk3 = walk2;
                    walk2 = walk;
                    walk = walk->next;
                    cnt++;
                }
                if (walk3){
                    walk3->next = 0;
                     
                    if(walk2 && cnt > 1){
                       free(walk2);
                       linePoints[numLines - 1]--;
                    }
                    else
                    {
                        printf("You have run out of points, sorry.\n");
                     }
                }//if walk2
   if(!showeq_params->fast_machine)
     refreshMap ();

#ifdef DEBUGMAP
   printf("delLinePoint() - Point %d removed\n", linePoints[numLines - 1] + 1);
#endif
}


void Map::setPlayerLevel (int level)
{
#ifdef DEBUG
   debug ("setPlayerLevel()");
#endif /* DEBUG */
   playerLevel = level;

   if (m_pSpawnList)
      m_pSpawnList->setPlayerLevel(level);
}

void Map::setPlayer (int newX, int newY, int newZ, int newDX, int newDY, int newDZ, int degrees)
{
#ifdef DEBUG
   printf ("setPlayer()\n");
#endif /* DEBUG */
   if ((ang == ((360 - degrees) + 90)) && (x == newX) && (y == newY) && (z == newZ) &&
       (DeltaX == newDX) && (DeltaY == newDY) && (DeltaZ == newDZ))
     return;
   x = newX;
   y = newY;
   z = newZ;
   DeltaX = newDX;
   DeltaY = newDY;
   DeltaZ = newDZ;

   gettimeofday(&playerTime,&tz);

   if (ZoomAmmount > 1)
   {
      reAdjust();
   }
   else
   {
      checkPos (x,y);
   }

   if (m_pSpawnList)
      m_pSpawnList->setPlayer(newX, newY, newZ, newDX, newDY, newDZ, degrees);

   ang = (360 - degrees) + 90;
   if(!showeq_params->fast_machine)
     refreshMap ();
   emit playerChanged (x, y, z, DeltaX, DeltaY, DeltaZ, ang);
}

QRect Map::mapRect () const
{
#ifdef DEBUG
   debug ("mapRect()");
   static int rendercount = 0;
   rendercount++;
   printf("%i, (0,0,%i,%i)\n",rendercount, width (), height ());
#endif /* DEBUG */
   QRect r (0, 0, width (), height ());
   r.moveBottomLeft (rect ().bottomLeft ());
#ifdef DEBUG
   printf("hmm2\n");
   rendercount--;
#endif
   return r;
}

int Map::calcDist (int xcor, int ycor)
{
// double
   int
     distance = abs(ycor-y)+abs(xcor-x);  // faster than sqrt and pow and accurate enough for me
//   if ((xcor == x) && (ycor == y))
//     return 0;

//   distance =
//     sqrt (pow ((double) ycor - (double) y, 2) +
//	   pow ((double) xcor - (double) x, 2));

   return distance;
}

void Map::setAngle (int degrees)
{
#ifdef DEBUG
   debug ("setAngle()");
#endif /* DEBUG */

   if (playerAngle != degrees)
   {
      playerAngle = degrees;
      if(!showeq_params->fast_machine)
	refreshMap ();
   }
}

int Map::calcXOffset (int mapCoordinate)
{
   return screenCenterX - (int)(mapCoordinate/m_RatioX);


   int sCoord, mapCen;
#ifdef DEBUG
//   debug ("calcXOffset()");
#endif /* DEBUG */
   sCoord = screenCenterX - (int)(mapCoordinate/m_RatioX);
   return sCoord;
}

int Map::calcYOffset (int mapCoordinate)
{
   return screenCenterY - (int)(mapCoordinate/m_RatioY);


   int sCoord, mapCen;
#ifdef DEBUG
   //debug("calcYOffset()");
#endif DEBUG
   sCoord = screenCenterY - (int)(mapCoordinate/m_RatioY);
   return sCoord;
}

void Map::paintMap (QPainter * p)
{
#ifdef DEBUG
   debug ("paintMap()");
#endif /* DEBUG */
   mapImage.fill(black);
   QRect cr = mapRect ();
   QPixmap pix (mapImage);
   QPainter tmp;
   int closestDistance = 1000;
   int closestSpawn = -1;
   int lostboy;
   struct timeval currtime;
   int sd,usd;
   double sec;
   
     // if we are not animating, the player is where we left him.
     //Always compare map to real current.

     curPlayerX=x;
     curPlayerY=y;
     sec = 1.1;
     gettimeofday(&currtime, &tz);

   if(showeq_params->animate) {
     // compute the number of seconds since the spawns update
     sd =currtime.tv_sec - playerTime.tv_sec;
     usd=currtime.tv_usec - playerTime.tv_usec;
     if(usd<0) {
       usd=usd+=1000000;
       sd--;
     }
     sec= ((double)usd)/((double)1000000)+((double)sd);
	
     // If its more than 30 seconds stale assume somthings wrong.
     //sec=(sec > 30.0 || spawns[n].NPC == 2 || spawns[n].NPC == 3)?0:sec;
     sec=(sec > 30.0)?0:sec; //player doesn't die!

     // Figure where the player should be... 1.3 was figured empiraccly.. feel free to
     // change it.. it seems to be preety close though.
     curPlayerX=(int)(x + (DeltaX * sec * 1.3));
     curPlayerY=(int)(y + (DeltaY * sec * 1.3));
	
   }
   
   if (ZoomAmmount > 1)
   {
      reAdjust();
   }
   else
   {//Don't allow map to over-extend itself.
     curPlayerX=x;
     curPlayerY=y;
     checkPos (curPlayerX,curPlayerY);
   }
   
   //Now, if we're animating, allow player to walk off. Grr, centering issue.


  /* Begin painting */
   tmp.begin (&pix);
   tmp.setPen (NoPen);
   tmp.setFont (QFont("Helvetica", 8, QFont::Normal));

  /* Paint player position background */
   tmp.setPen (QColor (80, 80, 80));
   tmp.setBrush (QColor (80, 80, 80));
   tmp.drawEllipse (calcXOffset (curPlayerX) - 40, calcYOffset (curPlayerY) - 40, 80, 80);

  /* Paint the grid */
   tmp.setPen (QColor (64, 64, 64));
   // Need to put in some stuff to auto resize the gridres
   // based on the screenLength and map size
   int gridres=1000;
   for (int gx=(minX/gridres)-1; gx<=(maxX/gridres)+1; gx++)
   {
     QString ts;
     tmp.drawLine(calcXOffset(gx*gridres),0,calcXOffset(gx*gridres),screenLengthY);
     ts.sprintf ("%d", gx*gridres);
     tmp.drawText(calcXOffset(gx*gridres), screenLengthY, ts);
   }
   for (int gy=(minY/gridres)-1; gy<=(maxY/gridres)+1; gy++)
   {
     QString ts;
     tmp.drawLine(0,calcYOffset(gy*gridres),screenLengthX,calcYOffset(gy*gridres));
     ts.sprintf ("%d", gy*gridres);
     tmp.drawText(0,calcYOffset(gy*gridres), ts);
   }  

  /* Paint the player direction */

   int const player_x = calcXOffset(curPlayerX);
   int const player_y = calcYOffset(curPlayerY);
   int const player_vis_radius = 128;

   float ratio = (float)(mapLengthX/ZoomAmmount)/(float)screenLengthX;
   int const player_vis_proradius_x = (int)((float)player_vis_radius/ratio);
   int const player_vis_proradius_y = (int)((float)player_vis_radius/ratio);
   int const player_vis_x1 = calcXOffset(curPlayerX + player_vis_radius);
   int const player_vis_x2 = calcXOffset(curPlayerX - player_vis_radius);
   int const player_vis_y1 = calcYOffset(curPlayerY + player_vis_radius);
   int const player_vis_y2 = calcYOffset(curPlayerY - player_vis_radius);

   int const player_circle_radius = 4;//(int)(2.0/ratio);
   int const aura_radius = player_circle_radius + 5;//(int)(5.0/ratio);

   if (playerAngle != -1)
   {

      double const pi = 3.14159265358979323846;
      double const radians_per_circle = pi * 2;
      double const angle = (360 - playerAngle - 180) / 360.0 * radians_per_circle;
      float compass_ratio = ratio;//(float)iZLenX/(float)mapLengthX;
      int const compass_length = 39 + ZoomAmmount;  //(int)player_vis_proradius_x/(ZoomAmmount + 1); // in pixels
												       int start_offset_x = int(sin( angle - radians_per_circle * 0.25 ) * player_circle_radius);
      int start_offset_y = int(cos( angle - radians_per_circle * 0.25 ) * player_circle_radius);
      double const fov_angle = radians_per_circle * 0.25;
      double fox_angle_offset = fov_angle / 2;

      tmp.setPen(yellow); // color
      tmp.drawLine( player_x, player_y,
		   player_x + int (sin( angle ) * compass_length),
		   player_y + int (cos( angle ) * compass_length) );

      tmp.setPen(red); // color
      for ( int n = 2; n--; )
      {
	 int const start_x = player_x + start_offset_x;
	 int const start_y = player_y + start_offset_y;

	 tmp.drawLine( start_x, start_y,
		      start_x + int (sin( angle - fox_angle_offset ) * compass_length),
		      start_y + int (cos( angle - fox_angle_offset ) * compass_length) );
	 start_offset_x *= -1;
	 start_offset_y *= -1;
	 fox_angle_offset *= -1;
      }

   }

// screen center crosshairs
/*
        tmp.setPen(cyan);

	tmp.drawLine(screenCenterX ,screenLengthY/2 - 55,screenCenterX,screenLengthY/2 + 55);
	tmp.drawLine(screenLengthX/2 - 55,screenCenterY,screenLengthX/2 + 55,screenCenterY);
*/


  /* Paint the lines */
   tmp.setPen (blue);
   //printf("Draw Lines\n");
   for (int l = 0; l < numLines; l++)
   {
      tmp.setPen(lineColor[l]);

      //tmp.moveTo (calcXOffset (lineX[l][0]), calcYOffset (lineY[l][0]));
      //for (int n = 1; n < linePoints[l]; n++)
      //{
	// tmp.lineTo (calcXOffset (lineX[l][n]), calcYOffset (lineY[l][n]));
      //}
          //printf("Line has %i points:\n", linePoints[l]);
          struct trackPoint *walk = linePoint[l].next;
          tmp.moveTo (calcXOffset (linePoint[l].x), calcYOffset (linePoint[l].y));
          while(walk){
              //printf("Point: %i, %i, %i\n", walk->x, walk->y, walk->z);
              tmp.lineTo (calcXOffset (walk->x), calcYOffset (walk->y));
              walk = walk->next;
          }

   }

  /* Paint the locations */
   tmp.setPen (gray);
   tmp.setBrush (white);
   
   for (int n = 0; n < numLocations; n++)
   {
     //tmp.drawEllipse (calcXOffset (locationX[n]) - 2,
     //		      calcYOffset (locationY[n]) - 2, 4, 4);
     tmp.drawText (calcXOffset (locationX[n]) - 2,
     		      calcYOffset (locationY[n]) - 2, 
		      locationName[n]);
     }

  /* Paint player position */
   tmp.setPen (gray);
   tmp.setBrush (white);
   tmp.drawEllipse (calcXOffset (curPlayerX) - 3, calcYOffset (curPlayerY) - 3, 6, 6);

  /* Paint the dropped items */
      int ixl;
      int iyl;
      int drawsize = 3;

   for (int n = 0; n < numDrops; n++){
        tmp.setPen(yellow);
        ixl = (int)drops[n].xPos;
        iyl = (int)drops[n].yPos;
        //fixed size:
	tmp.drawLine(calcXOffset(ixl)-drawsize,calcYOffset(iyl)-drawsize,calcXOffset(ixl)+drawsize,calcYOffset(iyl)+drawsize);
	tmp.drawLine(calcXOffset(ixl)-drawsize,calcYOffset(iyl)+drawsize,calcXOffset(ixl)+drawsize,calcYOffset(iyl)-drawsize);
	//tmp.drawLine(calcXOffset(ixl-drawsize),calcYOffset(iyl-drawsize),calcXOffset(ixl+drawsize),calcYOffset(iyl+drawsize));
	//tmp.drawLine(calcXOffset(ixl-drawsize),calcYOffset(iyl+drawsize),calcXOffset(ixl+drawsize),calcYOffset(iyl-drawsize));
      if (drops[n].dropId == -selectedSpawnId)
      {
	 tmp.setPen (green);
	 tmp.drawLine (calcXOffset (curPlayerX), calcYOffset (curPlayerY),
		       calcXOffset (ixl), calcYOffset (iyl));
      }

   }


   /* Paint the coin items */
   /* Andy -- can you "make em yellow circles with a smaller colored circle inside for
      coin type (brown=copper, yellow=gold, grey=silver, white=plat)" Thats what Sparr 
      wants  -- JohnQ*/
   for (int n = 0; n < numCoins; n++){
        tmp.setPen(yellow);
        ixl = (int)coins[n].xPos;
        iyl = (int)coins[n].yPos;
        //fixed size:
	tmp.drawLine(calcXOffset(ixl)-drawsize,calcYOffset(iyl)-drawsize,calcXOffset(ixl)+drawsize,calcYOffset(iyl)+drawsize);
	tmp.drawLine(calcXOffset(ixl)-drawsize,calcYOffset(iyl)+drawsize,calcXOffset(ixl)+drawsize,calcYOffset(iyl)-drawsize);

	//tmp.drawLine(calcXOffset(ixl-drawsize),calcYOffset(iyl-drawsize),calcXOffset(ixl+drawsize),calcYOffset(iyl+drawsize));
	//tmp.drawLine(calcXOffset(ixl-drawsize),calcYOffset(iyl+drawsize),calcXOffset(ixl+drawsize),calcYOffset(iyl-drawsize));
      if (coins[n].dropId == -selectedSpawnId)
      {
	 tmp.setPen (green);
	 tmp.drawLine (calcXOffset (curPlayerX), calcYOffset (curPlayerY),
		       calcXOffset (ixl), calcYOffset (iyl));
      }

   }


  /* Paint the spawns */
   if ((mTime() - m_nFlash) > 100)  // miliseconds between flashing
   {
      m_bFlash = !m_bFlash;
      m_nFlash = mTime();
   }

   for (int n = 0; n < numSpawns; n++)
   {
    // only paint if the spawn is not hidden or the showhidden flag is on
    if (!(m_FlagsArray[n] & spawnHidden) || showhidden)
    {
      int xlocation;
      int ylocation;

      // compute the current best guess if we are animating
	sd =currtime.tv_sec - spawnTime[n].tv_sec;
	usd=currtime.tv_usec - spawnTime[n].tv_usec;
	if(usd<0) {
	  usd+=1000000;
	  sd--;
	}
	sec= ((double)usd)/((double)1000000)+((double)sd);
	
        // If it is more than 30 seconds, we want to draw x's for players too.
        lostboy = (sec > 30.0)?1:0;

	// If its more than 30 seconds stale stop moving them.
	// Same is true if they are DEAD. duh... Dunno why I forgot that.
	sec=(sec > 30.0 || spawns[n].NPC == 2 || spawns[n].NPC == 3)?0:sec;

      if(showeq_params->animate) {			      
	// Figure where the mob should be... 1.3 was figured empiraccly.. feel free to
	// change it.. it seems to be preety close though.
	xlocation=(int)(spawns[n].xPos + (spawns[n].deltaX * sec * 1.3));
	ylocation=(int)(spawns[n].yPos + (spawns[n].deltaY * sec * 1.3));
	
      } else {
	// if we are not animating, the mob is where we left him.
	xlocation=spawns[n].xPos;
	ylocation=spawns[n].yPos;
      }
      
      /* Draw velocities */
      if (showeq_params->velocity && spawns[n].NPC != 10) //Don't draw the velocity line for the user's player.
      {
	 tmp.setPen (darkGray);
	 if (spawns[n].deltaX || spawns[n].deltaY)
	   tmp.drawLine (
			 calcXOffset (xlocation),
			 calcYOffset (ylocation),
			 calcXOffset (xlocation)-spawns[n].deltaX,
			 calcYOffset (ylocation)-spawns[n].deltaY
			 );
      }

      if (showeq_params->walkpathshowselect == 1 && spawns[n].spawnId == selectedSpawnId){
          tmp.setPen (blue);
          struct trackPoint *walk = firstPoint[n].next;
          tmp.moveTo (calcXOffset (firstPoint[n].x), calcYOffset (firstPoint[n].y));
          while(walk){
              tmp.lineTo (calcXOffset (walk->x), calcYOffset (walk->y));
              walk = walk->next;
          }
          tmp.lineTo (calcXOffset (xlocation), calcYOffset (ylocation));
      }


      /* Check if mouse was clicked, find closest spawn */
      if (mapClicked)
      {
	 double
	   distance;
// this just wasted time as far as i can see
//	 if ((calcXOffset (xlocation) == mapClickedX)
//	     && (calcYOffset (ylocation) == mapClickedY))
//	 {
//	    distance = 0;
//	 }
//	 else
//	 {
	    distance =
// sqrt here was a waste of time since if sqrt(x)<sqrt(y) then x<y when they are both +, which pow insures
//	      sqrt (
                  pow ((double) calcYOffset (ylocation) - (double) mapClickedY, 2) + 
                  pow ((double) calcXOffset (xlocation) - (double) mapClickedX, 2);
//	 }

	 if ( (distance < closestDistance) && spawns[n].NPC != 10)
	 {
	    closestDistance = (int) distance;
	    closestSpawn = n;
	 }
      }

      // pick pen color
      if (spawns[n].NPC == 4)
      {
	 tmp.setPen (blue);
	 tmp.drawLine (calcXOffset (curPlayerX), calcYOffset (curPlayerY),
		       calcXOffset (xlocation), calcYOffset (ylocation));
      }
      if (spawns[n].spawnId == selectedSpawnId)
      {
	 tmp.setPen (magenta);
	 tmp.drawLine (calcXOffset (curPlayerX), calcYOffset (curPlayerY),
		       calcXOffset (xlocation), calcYOffset (ylocation));
      }

      switch (spawns[n].NPC)
      {
       case 0:  // player 
	 tmp.setPen (magenta);
	 break;
       case 3:  // monster corpse
	 tmp.setPen (cyan);
	 break;
       case 2:  // player corpse
	 tmp.setPen (cyan);
	 break;
       default:
	 tmp.setPen (black);
      }


      // select brush color
      if (spawns[n].level == 0)
      {
	 tmp.setBrush (gray);
      }
      else
      {
         tmp.setBrush (pickConColor(playerLevel, spawns[n].level));
      }
      
      // if hidden from spawnList grey brush
      if (m_FlagsArray[n] & spawnHidden)
      {
         tmp.setBrush(QColor (128,128,128));
         tmp.setPen(QColor (0,0,0));
      }

      //
      // Misc decorations
      //

      // box for corpse, otherwise circle
      switch (spawns[n].NPC)
      {
       case 0:	// player 
       case 2:	// player corpse
         if (spawns[n].NPC == 0 && lostboy){
             ixl = xlocation;
             iyl = ylocation;
	     //tmp.drawRect (calcXOffset (xlocation) - 3, calcYOffset (ylocation) - 3, 6, 6);
             //fixed size
	     tmp.drawLine(calcXOffset(ixl),calcYOffset(iyl)-drawsize,calcXOffset(ixl),calcYOffset(iyl)+drawsize);
    	     tmp.drawLine(calcXOffset(ixl)-drawsize,calcYOffset(iyl),calcXOffset(ixl)+drawsize,calcYOffset(iyl));
             //scales:
	     //tmp.drawLine(calcXOffset(ixl),calcYOffset(iyl-drawsize),calcXOffset(ixl),calcYOffset(iyl+drawsize));
    	     //tmp.drawLine(calcXOffset(ixl-drawsize),calcYOffset(iyl),calcXOffset(ixl+drawsize),calcYOffset(iyl));
         }
         else{
           //Fixed size:
 	     tmp.drawRect (calcXOffset (xlocation) - drawsize, calcYOffset (ylocation) - drawsize, 2 * drawsize, 2 * drawsize);
           //Scaled:
           //ixl = calcXOffset (xlocation + drawsize) - calcXOffset (xlocation - drawsize) + 1;
           //iyl = calcYOffset (ylocation + drawsize) - calcYOffset (ylocation - drawsize) + 1;
	   //tmp.drawRect (calcXOffset (xlocation - drawsize) ,
	   //	       calcYOffset (ylocation - drawsize), ixl, iyl);
         }
	 break;
       case 10: //This player's avatar. (list item version.)
         break; //don't draw it.
       default:
           //ixl = calcXOffset (xlocation + drawsize) - calcXOffset (xlocation - drawsize);
           //iyl = calcYOffset (ylocation + drawsize) - calcYOffset (ylocation - drawsize);
	   //tmp.drawEllipse (calcXOffset (xlocation - drawsize), calcYOffset (ylocation - drawsize), ixl, iyl);
	     tmp.drawEllipse (calcXOffset (xlocation) - drawsize, calcYOffset (ylocation) - drawsize, 2 * drawsize, 2 * drawsize);

      }

      // if spawn is another pc, on a different team, and within 8 levels
      // highlight it flashing
    if (m_bFlash)
    {
      if (m_FlagsArray[n] & spawnHighlight)
      {
         tmp.setPen(yellow); 
         tmp.setBrush(NoBrush);
         tmp.drawRect (calcXOffset (xlocation) - 4,
                      calcYOffset (ylocation) - 4, 8, 8);
         tmp.setBrush(SolidPattern);
      }

      if (showeq_params->pvp && (spawns[n].NPC == 0) )
      {
         // if not the same team as us
         if (!isSameTeam(playerRace, spawns[n].race))
         {
            int diff = spawns[n].level - playerLevel;
            if (diff < 0) diff *= -1;
            // if we are within 8 levels of other player
            if (diff <= 8)
            {
              // they are in your range
              switch ( (spawns[n].level - playerLevel) + 8)
              {
                 // easy
                 case 0:  // you are 8 above them
                 case 1:  // you are 7 above them
                    tmp.setPen(green); 
                    break;
                 case 2:  // you are 6 above them
                 case 3:  // you are 5 above them
                    tmp.setPen(darkGreen); 
                    break;

                 // moderate
                 case 4:  // you are 4 above them
                 case 5:  // you are 3 above them
                    tmp.setPen(blue); 
                    break;
                 case 6:  // you are 2 above them
                 case 7:  // you are 1 above them
                    tmp.setPen(darkBlue); 
                    break;

                 // even
                 case 8:  // you are even with them
                    tmp.setPen(white); 
                    break;

                 // difficult 
                 case 9:  // you are 1 below them
                 case 10:  // you are 2 below them
                    tmp.setPen(yellow); 
                    break;

                 // downright hard
                 case 11:  // you are 3 below them
                 case 12:  // you are 4 below them
                    tmp.setPen(magenta); 
                    break;
                 case 13:  // you are 5 below them
                 case 14:  // you are 6 below them
                    tmp.setPen(red); 
                    break;
                 case 15:  // you are 7 below them
                 case 16:  // you are 8 below them
                    tmp.setPen(darkRed); 
                    break;
              }
              tmp.setBrush(NoBrush);
              tmp.drawRect (calcXOffset (xlocation) - drawsize - 1,
                      calcYOffset (ylocation) - drawsize - 1, 
                      2 * (drawsize + 1), 2 * (drawsize + 1));
              tmp.setBrush(SolidPattern);
            }
         }
      } // if decorate pvp

      // circle around pvp pets
      if (showeq_params->pvp && (spawns[n].petOwnerId != 0) )
      {
         if (!isSameTeam(playerRace, spawns[ID2Index(spawns[n].petOwnerId)].race))
         {
            tmp.setBrush(NoBrush);
            tmp.setPen(pickConColor(playerLevel, spawns[n].level));
//	    tmp.drawEllipse (calcXOffset (xlocation) - 4,
//                calcYOffset (ylocation) - 4, 8, 8);
	    tmp.drawEllipse (calcXOffset (xlocation) - 3,
                calcYOffset (ylocation) - 3, 6, 6);
            tmp.setBrush(SolidPattern);
         }
      }

     } // end if flash 
    } // end if shoudl be painted
   } // end for spawns

   tmp.end ();
  /* p->drawPixmap (cr.topLeft(), pix); */
   p->drawPixmap (0, 0, pix);

   if (mapClicked && listView)
   {
      mapClicked = 0;
      if (closestSpawn != -1)
      {
	 selectedSpawnId = spawns[closestSpawn].spawnId;
         // Select spawn in spawnlist
         if (m_pSpawnList)
            m_pSpawnList->SelectItem(tSpawn, selectedSpawnId);

         // update statusbar
         updateSpawnStatus(ID2Index(selectedSpawnId));

	 if(!showeq_params->fast_machine)
	   refreshMap ();
      }
   }
}

void Map::paintEvent (QPaintEvent * e)
{
#ifdef DEBUG
   debug ("paintEvent()");
#endif /* DEBUG */
   QRect updateR = e->rect ();
   QPainter p;
   p.begin (this);
   if (updateR.intersects (mapRect ()))
     paintMap (&p);
   p.end ();
}

void 
Map::consMessage(considerStruct * con) 
{
   int printed;
   printed = 0;
   QString str("");

   if (con->playerid == con->targetid) 
   {
      str.sprintf("Faction: Your faction standing with YOU is %d!",
          con->faction);
   } 
   else 
   {
     int n = ID2Index(con->targetid);
    
     if (-1 != n)
     {
       if (listView && showeq_params->con_select) 
       {
          selectedSpawnId = spawns[n].spawnId;

          // Select spawn in spawnlist
          if (m_pSpawnList)
             m_pSpawnList->SelectItem(tSpawn, selectedSpawnId);

          // update statusbar
          updateSpawnStatus(n);

          if(!showeq_params->fast_machine)
             refreshMap ();
       }
       str.sprintf("Faction: Your faction standing with %s is %d!",
           spawns[n].name,con->faction);
     } // end if spawn found
   } // else not yourself

   if (str.length() < 1) 
   {
      str.sprintf("Faction: Your faction standing with Spawn:%4.4x is %d!",
             con->targetid,con->faction);
   }

   emit
      msgReceived(str);

} // end consMessage()


void Map::refreshSpawnList(void)
{
   SpawnListItem *i;

   for (int n = 0; n < numSpawns; n++)
   {
     if (isFiltered(n))
     {
       i = m_pSpawnList->FindItem(tSpawn, spawns[n].spawnId);
       while(i)
       {
         i->setFlags(i->flags() | spawnFiltered);
         m_FlagsArray[n] = i->flags();
         i = m_pSpawnList->FindNext(i, tSpawn, spawns[n].spawnId);
       }
     }
     else
     {
       i = m_pSpawnList->FindItem(tSpawn, spawns[n].spawnId);
       while(i)
       {
         i->setFlags(i->flags() & ~spawnFiltered);
         m_FlagsArray[n] = i->flags();
         i = m_pSpawnList->FindNext(i, tSpawn, spawns[n].spawnId);
       }
     }
   }
}

void Map::saveFilters(void)
{
  printf("Saveing Filters\n");

  m_pSpawnFilter->saveFilters();
  m_pAlertFilter->saveFilters();
}

void Map::loadFilters(void)
{
  printf("Loading Filters\n");

  m_pSpawnFilter->loadFilters();
  m_pAlertFilter->loadFilters();
  m_pSpawnFilter_Level->loadFilters();
  m_pSpawnFilter_HP->loadFilters();
  m_pSpawnFilter_MaxHP->loadFilters();
  m_pSpawnFilter_Dist->loadFilters();
  m_pSpawnFilter_Race->loadFilters();
  m_pSpawnFilter_Class->loadFilters();
  m_pSpawnFilter_Info->loadFilters();

  // reflect changes in list and map
  refreshSpawnList();
  refreshMap();
}

void Map::listFilters(void)
{
  printf("\n");
  printf("Alert Filters:\n");
  m_pAlertFilter->listFilters();

  printf("\n");
  printf("Spawn Filters:\n");
  m_pSpawnFilter->listFilters();

  printf("\n");
  printf("Level Filters:\n");
  m_pSpawnFilter_Level->listFilters();

  printf("\n");
  printf("HP Filters:\n");
  m_pSpawnFilter_HP->listFilters();

  printf("\n");
  printf("MaxHP Filters:\n");
  m_pSpawnFilter_MaxHP->listFilters();

  printf("\n");
  printf("Dist Filters:\n");
  m_pSpawnFilter_Dist->listFilters();

  printf("\n");
  printf("Race Filters:\n");
  m_pSpawnFilter_Race->listFilters();

  printf("\n");
  printf("Class Filters:\n");
  m_pSpawnFilter_Class->listFilters();

  printf("\n");
  printf("Info Filters:\n");
  m_pSpawnFilter_Info->listFilters();

} // listFilters


//
// rightButtonPressed
//
// if you right click on a spawn in the list dump its contents
// and mark the column you selected as the current column for filtering
//
void Map::rightButtonPressed(QListViewItem *item, const QPoint &point, int col)
{
  selectedColumn = col;

  m_bKeepUpdated = TRUE;
//  emit stsMessage(QString(dumpSpawn(ID2Index(selectedSpawnId))));
  printf("%s\n", dumpSpawn(ID2Index(selectedSpawnId)));
}

void Map::rightButtonReleased(QListViewItem *item, const QPoint &point, int col)
{
  selectedColumn = 0;
}



//
// isFiltered
//
// purpose: Check to see if something is filtered based on current spawn filters
// args:  int n - the index to check
// returns: int 0 = not filtered, 1 = filtered
//
int Map::isFiltered(int n)
{
   char strBuf[64];

   if ((n < 0) || (n > numSpawns))
   {
     fprintf(stderr, "Warning: passed spawn index out of range: %d\n", n);
     return 0;
   }

   // test name
   if (m_pSpawnFilter->isFiltered(spawns[n].name))
     return 1;

   // test Level
   sprintf(strBuf, "%d", spawns[n].level);
   if (m_pSpawnFilter_Level->isFiltered(strBuf))
     return 1;

   // test HP
   sprintf(strBuf, "%d", spawns[n].curHp);
   if (m_pSpawnFilter_HP->isFiltered(strBuf))
     return 1;

   // test MaxHP
   if (spawns[n].curHp<=0)
     sprintf(strBuf, "<=0");
   else
     sprintf(strBuf, "%d", spawns[n].maxHp);
   if (m_pSpawnFilter_MaxHP->isFiltered(strBuf))
     return 1;

   // test Dist 
   sprintf(strBuf, "%d", calcDist(spawns[n].xPos, spawns[n].yPos));
   if (m_pSpawnFilter_Dist->isFiltered(strBuf))
     return 1;
  
   // test Race 
   if (m_pSpawnFilter_Race->isFiltered(race_name(spawns[n].race)))
     return 1;
  
   // test Class 
   if (m_pSpawnFilter_Class->isFiltered(class_name(spawns[n].class_)))
     return 1;
  
   // test Info 
   if (m_pSpawnFilter_Info->isFiltered(spawnInfo[n]))
     return 1;
  
   return 0;

} // end isFiltered(n)


const char*
Map::dumpSpawn(int n)
{
   return filterString(&spawns[n]);
#if 0
   static char text[1024];
   char name[30];

   text[0] = 0;

   if ((n < 0) || (n > numSpawns))
   {
     fprintf(stderr, "Warning: passed spawn index out of range: %d\n", n);
     return text;
   }

   strncpy(name, spawns[n].name, 20);
   if (strlen(spawns[n].name) > 20)
   {
     strncpy(name, spawns[n].name, 17);
     sprintf(name + 16, "...");
   }

   sprintf(text, "%03d - %-20s lvl:%02d HP:%05d MaxHP:%05d Dist:%04d Race:%-15s Class:%-15s NPC:%d Info:%s",
          n, name, spawns[n].level, spawns[n].curHp,
          spawns[n].maxHp, calcDist(spawns[n].xPos, spawns[n].yPos), 
          race_name(spawns[n].race), class_name(spawns[n].class_), 
          spawns[n].NPC, spawnInfo[n]);

//   printf("%s\n", text);

   return text;
#endif
}



//
// HideSelected
//
//
void Map::HideSelected(void)
{
   int n = ID2Index(selectedSpawnId);

   if (-1 != n)
   {
     SpawnListItem *i = m_pSpawnList->FindItem(tSpawn, spawns[n].spawnId);
     while(i)
     {
       i->setFlags(i->flags() | spawnFiltered);
       m_FlagsArray[n] = i->flags();
       i = m_pSpawnList->FindNext(i, tSpawn, spawns[n].spawnId);
     }
   }
}


//
// UnHideAll 
//
//
void Map::UnHideAll(void)
{
   for (int n = 0; n < numSpawns; n++)
   {
     SpawnListItem *i = m_pSpawnList->FindItem(tSpawn, spawns[n].spawnId);
     while(i)
     {
       i->setFlags(i->flags() & ~spawnHidden);
       m_FlagsArray[n] = i->flags();
       i = m_pSpawnList->FindNext(i, tSpawn, spawns[n].spawnId);
     }
   }
}


//
// ShowHidden
//
// Toggle viewing of hidden spawns in map - they will show as grey dots
//
void
Map::ShowHidden(int view)
{
  showhidden = view;
//printf("Map::ShowHidden(%d)\n", view);

  refreshMap();
}


//
// ToggleFilterSelected
//
// This will toggle something from the current filters.  It will use
// the column selected which is changed by 'right clicking' on a column
// in the spawnlist display.
//
// For example:  If you clicked on an 'orc' and then right clicked on the 
//   'Race' column, then hit the hotkey that called this routine
//    all spawns that have a race identical to the orc will be filtered.
//    If a filter already matches this, it will be remmoved.
//
void
Map::ToggleFilterSelected(void)
{
#ifdef DEBUG
printf("Map::ToggleFilterSelected() - Selected ID %d, col %d\n", 
   selectedSpawnId, selectedColumn);
#endif

  int n = ID2Index(selectedSpawnId);

  if (-1 != n)
  {
    // derive filter string based on column selected
    char strBuf[64];
    char *filter = strBuf;
    class Filter* pFilter = NULL;

//printf("selectedColumn %d\n", selectedColumn);
    switch(selectedColumn)
    {
      default:
      case 0:    // Name
         filter  = spawns[n].name;
         pFilter = m_pSpawnFilter;
         break;
      case 1:    // level
         sprintf(strBuf, "%d", spawns[n].level);
         pFilter = m_pSpawnFilter_Level;
         break;
      case 2:    // HP's
         sprintf(strBuf, "%d", spawns[n].level);
         pFilter = m_pSpawnFilter_HP;
         break;
      case 3:    // MaxHP
         sprintf(strBuf, "%d", spawns[n].level);
         pFilter = m_pSpawnFilter_MaxHP;
         break;
      case 8:    // Dist 
         sprintf(strBuf, "%d", calcDist(spawns[n].xPos, spawns[n].yPos));
         pFilter = m_pSpawnFilter_Dist;
         break;
      case 9:   // Race 
         filter = race_name(spawns[n].race);
         pFilter = m_pSpawnFilter_Race;
         break;
      case 10:   // Class 
         filter = class_name(spawns[n].class_);
         pFilter = m_pSpawnFilter_Class;
         break;
      case 11:   // Info 
         filter = spawnInfo[n];
         pFilter = m_pSpawnFilter_Info;
         break;
    }
    if (pFilter->isFiltered(filter))
    {
      // Remove this name from the filters 
      pFilter->remFilter(filter);

      // Display spawn info (shoudl put in a statusbar)
      QString temp("");
      temp.sprintf("Removed filter for '%s'", filter);
      emit stsMessage(temp);
    }
    else
    {
      // Filter this name
      pFilter->addFilter(filter);

      // Display spawn info (shoudl put in a statusbar)
      QString temp("");
      temp.sprintf("Added filter for '%s'", filter);
      emit stsMessage(temp);
    } // end else remove

    // Re-apply filters to current spawns and repaint map with changes
    refreshSpawnList();
    refreshMap();

    return;
  }
#ifdef DEBUG
printf("ToggleFilterSelected - cannot find selection\n");
#endif
}


void
Map::updateSpawnStatus(int n)
{
   if ( (n > 0) && (n < numSpawns))
   {
     QString string("");
     string.sprintf("%d: %s:%d (%d/%d) Pos:%d/%d/%d (%d) %s %s Item:%s", 
          spawns[n].spawnId,
          spawns[n].name, spawns[n].level, spawns[n].curHp,
          spawns[n].maxHp, spawns[n].xPos, spawns[n].yPos, spawns[n].zPos,
          calcDist(spawns[n].xPos, spawns[n].yPos), 
          race_name(spawns[n].race), class_name(spawns[n].class_), 
          spawnInfo[n]);

     emit stsMessage(string);
   }
}

const char*
Map::spawnAlertName(int n)
{
  static char spawn_alert_name[512];

  sprintf(spawn_alert_name,"%s/%s/%s/%s",
          spawns[n].name, race_name(spawns[n].race), class_name(spawns[n].class_),
          spawnInfo[n]);

  return spawn_alert_name;
}

void
Map::toggleDebug(void)
{
  static bool bDebug = FALSE;

//  bDebug = !bDebug;
  bDebug = TRUE;

printf("Debug %s\n", bDebug?"On":"Off");

  if (m_pSpawnList)
     m_pSpawnList->setDebug(bDebug);


  m_pSpawnList->UpdateSpawn(&spawns[ID2Index(selectedSpawnId)]);
}

void
Map::selectNext(void)
{
  if (m_pSpawnList)
     m_pSpawnList->selectNext();
}

void
Map::selectPrev(void)
{
  if (m_pSpawnList)
     m_pSpawnList->selectPrev();
}
 
void
Map::spawnListUpdated(void)
{
  if (m_pSpawnList)
  {
    // update flags
    for (int n = 0; n < numSpawns; n++)
    {
      m_FlagsArray[n] = 0; 

      SpawnListItem *i;

      i = m_pSpawnList->FindItem(tSpawn, spawns[n].spawnId);
      while (i)
      {
        m_FlagsArray[n] |= i->flags();
        i = m_pSpawnList->FindNext(i, tSpawn, spawns[n].spawnId);
      }
    }
  }
} // end spawnListUpdated


void
Map::rebuildSpawnList(void)
{
//printf("Rebuilding spawnlist\n");
  if (m_pSpawnList)
  {
    // clear list and rebuild
    m_pSpawnList->clear();
    for (int n = 0; n < numSpawns; n++)
    {
      int spawnFlags = 0;
      if (isFiltered(n))
        spawnFlags |= spawnFiltered;

      m_pSpawnList->InsertSpawn(&spawns[n], spawnFlags);
    }
  }
//printf("Done Rebuilding spawnlist\n");
} // end rebuildSpawnList


void Map::addGroup(char* nm, int sid){
          strcpy(groupNames[groupSize], nm);
          groupID[groupSize] = sid;
          int newnum;
          if (sid == 0)
          for(int n = 0; n < numSpawns; n++){
              if (stricmp(nm,spawns[n].name) == 0){ 
                  //printf("map: we think we found him: %i\n", spawns[n].spawnId);
                  groupID[groupSize] = spawns[n].spawnId;
                  break;
              }
          }
          newnum = groupSize;
          if (++groupSize>5)
              groupSize = 5;

          //printf("addGroup %i\n", groupID[newnum]);
          if (groupID[newnum] > 0){
              int myn = ID2Index(groupID[newnum]);
              //printf("myn %i\n", myn);
              if (myn>=0){
                  //printf("Hiding\n");
//                  hideSpawn(myn);
                  //printf("unhiding\n");
//                  unhideSpawn(myn);  
                  //printf("Shown\n");
              }
          }

}
void Map::remGroup(char* nm, int sid){
          int hl, myn;
          for(int rmhim = 0 ; rmhim < groupSize; rmhim++){
              if (stricmp(groupNames[rmhim], nm) == 0){
                  hl = groupSize - 1;
                  if (hl<0) hl = 0;
                  //emit remGroup(groupNames[rmhim], groupID[rmhim]);
                  myn = groupID[rmhim];
                  groupID[rmhim] = groupID[hl];
                  strcpy(groupNames[rmhim], groupNames[hl]);
                  if(--groupSize<0) groupSize = 0;
              }
          }
          if (myn > 0){
              myn = ID2Index(groupID[myn]);
              if (myn>=0){
//                  hideSpawn(myn);
//                  unhideSpawn(myn);  
              }
          }
}
void Map::clrGroup(){
          int myn;
          printf("map: clearing out group.\n");
          for (int ngp=0;ngp<groupSize;ngp++){
              strcpy(groupNames[ngp],"-UKN-");
              myn = groupID[ngp];
              if (myn > 0){
                  myn = ID2Index(groupID[ngp]);
                  if(myn>=0){
//                      hideSpawn(myn);
//                      unhideSpawn(myn);  
                  }
              }
              groupID[ngp] = 0;
          }
          groupSize = 0;
}

void Map::makeSelectedSpawnLine(){
    makeSpawnLine(ID2Index(selectedSpawnId));
}

void Map::makeSpawnLine(int n){
      struct trackPoint *walk = &firstPoint[n];
      int cnt=0;
      cnt = cnt;
      while (walk){
          cnt++;
          walk = walk->next;
      }  
      walk = &firstPoint[n];
      while (cnt>254){
          makeSimpleLine(walk, 255, n);
          for (int c = 0;c < 254;c++,cnt--,walk = walk->next){
             //we back up one point.
 	     //For loops are fun!
             if (!walk) break;
          }
      }
      if (cnt > 1)
          makeSimpleLine(walk, cnt, n);
}

void Map::makeSimpleLine(trackPoint *walk, int numpnts, int n){

         trackPoint *walk2;
         //Don't save lines where they just hit the line button. Andrew
         FILE *fh = fopen("mobpath.map","a");
         if (!fh) return;
	 fprintf (fh, "M,%s,%s,%d", (const char*)spawns[n].name, "blue", numpnts);
	 for (int c = 0; c < numpnts && walk != 0; c++, walk=walk->next)
	 {
	    fprintf (fh, ",%d,%d,%d", walk->x, walk->y, walk->z);
            walk2 = walk;
	 }
	 fprintf (fh, "\n");
         fflush(fh);
         fclose(fh);
         walk = walk2;//move back one point.

}

