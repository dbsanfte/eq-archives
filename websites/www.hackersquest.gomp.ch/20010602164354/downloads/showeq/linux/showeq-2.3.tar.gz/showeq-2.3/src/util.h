/*
 * util.h
 *
 * ShowEQ Distributed under GPL
 * http://www.hackersquest.gomp.ch/
 */

#ifndef EQUTIL_H
#define EQUTIL_H

#include <qcolor.h>

#include "everquest.h"
#include "main.h"

char *print_addr (unsigned long addr);

char *Commanate (UDWORD number);
char *spell_name (int spellId);
char *race_name (int raceId);
char *class_name (int classId);
char *language_name (int langId);
char *skill_name (int skillId);
char *light_name (unsigned char lightId);
char *getitemNameFromDB(int itemNr);
void itemdb (struct itemStruct *item);
void spawndb (struct dbSpawnStruct *spawn);
void petdb(struct petStruct *spawn);

char *print_class (unsigned int classes);
char *print_race (unsigned int races);
char *print_slot (unsigned long slots);
const char *print_material (unsigned char material);
const char *print_weapon (unsigned char weapon);
char *print_skill (unsigned char skill);

void processEquipment (struct spawnStruct *spawn, char *buffer);
char *spawnAlertName(struct spawnStruct *spawn);
unsigned long calc_exp (int level, UBYTE race, UBYTE class_);
const char* filterString(spawnStruct* s);
const char* filterString(dropCoinsStruct* s);
const char* filterString(dropThingOnGround* s);
QColor pickConColor(int, int);
const char* TransformName(const char* name);

int  isSameTeam(int race, int race);
int  mTime(void);

#endif // EQUTIL_U
