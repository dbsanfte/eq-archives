ItemDB 1.1 Readme

Theres no help or support or whatever for this tool...

If you dont know how to use it, dont use it at all ;)

You can get the newest ItemDB files from www.hackersquest.gomp.ch