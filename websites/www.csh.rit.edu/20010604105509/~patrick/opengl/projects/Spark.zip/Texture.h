//-------------------------------------------------------------------
//	File:		Texture.h
//	Created:	05/26/99 2:30:AM
//	Author:		Aaron Hilton
//	Comments:	Create and manage OpenGL textures.
//-------------------------------------------------------------------
#ifndef __Texture_h_
#define __Texture_h_

#define MAX_TEXTURE_NAME_LENGTH 64

class CTexture
{
public:
	CTexture();
	~CTexture();

	// Create and load the files.
	bool LoadBMP(char* szFileName);
    bool LoadJPG(char* szFileName, bool asAlpha = false);
	bool LoadTGA( char *szFilename );
	// Added DJT 12/03/1999
    bool LoadFromData(char *pszName,
	                  const char* pRaw, 
	                  GLint nWidth, 
	                  GLint nHeight, 
	                  GLint nComponents, 
	                  GLenum format,
	                  GLenum type);

	void Toast();

	void Use();

protected:
	// Generates the nesessary internal data.
	bool Create(char* szFileName);

	char m_szName[MAX_TEXTURE_NAME_LENGTH];
	unsigned int m_nID;

	// Status information.
	UInt32 m_nWidth, m_nHeight;
};

#endif // __Texture_h_
//-------------------------------------------------------------------
//	History:
//	$Log:$
//-------------------------------------------------------------------
