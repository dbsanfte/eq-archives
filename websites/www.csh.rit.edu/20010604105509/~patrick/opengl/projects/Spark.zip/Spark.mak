# Microsoft Developer Studio Generated NMAKE File, Based on Spark.dsp
!IF "$(CFG)" == ""
CFG=Spark - Win32 Debug
!MESSAGE No configuration specified. Defaulting to Spark - Win32 Debug.
!ENDIF 

!IF "$(CFG)" != "Spark - Win32 Release" && "$(CFG)" != "Spark - Win32 Debug"
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "Spark.mak" CFG="Spark - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "Spark - Win32 Release" (based on "Win32 (x86) Application")
!MESSAGE "Spark - Win32 Debug" (based on "Win32 (x86) Application")
!MESSAGE 
!ERROR An invalid configuration is specified.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 

CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "Spark - Win32 Release"

OUTDIR=.\Release
INTDIR=.\Release
# Begin Custom Macros
OutDir=.\Release
# End Custom Macros

ALL : "$(OUTDIR)\Spark.exe" "$(OUTDIR)\Spark.bsc"


CLEAN :
	-@erase "$(INTDIR)\Spark.obj"
	-@erase "$(INTDIR)\Spark.sbr"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\StdAfx.sbr"
	-@erase "$(INTDIR)\SVector.obj"
	-@erase "$(INTDIR)\SVector.sbr"
	-@erase "$(INTDIR)\Texture.obj"
	-@erase "$(INTDIR)\Texture.sbr"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\Windows.obj"
	-@erase "$(INTDIR)\Windows.sbr"
	-@erase "$(OUTDIR)\Spark.bsc"
	-@erase "$(OUTDIR)\Spark.exe"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP_PROJ=/nologo /ML /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /FR"$(INTDIR)\\" /Fp"$(INTDIR)\Spark.pch" /YX /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
MTL_PROJ=/nologo /D "NDEBUG" /mktyplib203 /o "NUL" /win32 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\Spark.bsc" 
BSC32_SBRS= \
	"$(INTDIR)\Spark.sbr" \
	"$(INTDIR)\StdAfx.sbr" \
	"$(INTDIR)\SVector.sbr" \
	"$(INTDIR)\Texture.sbr" \
	"$(INTDIR)\Windows.sbr"

"$(OUTDIR)\Spark.bsc" : "$(OUTDIR)" $(BSC32_SBRS)
    $(BSC32) @<<
  $(BSC32_FLAGS) $(BSC32_SBRS)
<<

LINK32=link.exe
LINK32_FLAGS=opengl32.lib glu32.lib ijl.lib kernel32.lib user32.lib gdi32.lib winmm.lib /nologo /subsystem:windows /incremental:no /pdb:"$(OUTDIR)\Spark.pdb" /machine:I386 /out:"$(OUTDIR)\Spark.exe" 
LINK32_OBJS= \
	"$(INTDIR)\Spark.obj" \
	"$(INTDIR)\StdAfx.obj" \
	"$(INTDIR)\SVector.obj" \
	"$(INTDIR)\Texture.obj" \
	"$(INTDIR)\Windows.obj"

"$(OUTDIR)\Spark.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "Spark - Win32 Debug"

OUTDIR=.\Debug
INTDIR=.\Debug
# Begin Custom Macros
OutDir=.\Debug
# End Custom Macros

ALL : "$(OUTDIR)\Spark.exe"


CLEAN :
	-@erase "$(INTDIR)\Spark.obj"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\SVector.obj"
	-@erase "$(INTDIR)\Texture.obj"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\vc60.pdb"
	-@erase "$(INTDIR)\Windows.obj"
	-@erase "$(OUTDIR)\Spark.exe"
	-@erase "$(OUTDIR)\Spark.ilk"
	-@erase "$(OUTDIR)\Spark.pdb"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP_PROJ=/nologo /MLd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /Fp"$(INTDIR)\Spark.pch" /YX /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
MTL_PROJ=/nologo /D "_DEBUG" /mktyplib203 /o "NUL" /win32 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\Spark.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=opengl32.lib glu32.lib ijl.lib kernel32.lib user32.lib gdi32.lib winmm.lib /nologo /subsystem:windows /incremental:yes /pdb:"$(OUTDIR)\Spark.pdb" /debug /machine:I386 /out:"$(OUTDIR)\Spark.exe" /pdbtype:sept 
LINK32_OBJS= \
	"$(INTDIR)\Spark.obj" \
	"$(INTDIR)\StdAfx.obj" \
	"$(INTDIR)\SVector.obj" \
	"$(INTDIR)\Texture.obj" \
	"$(INTDIR)\Windows.obj"

"$(OUTDIR)\Spark.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ENDIF 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<


!IF "$(NO_EXTERNAL_DEPS)" != "1"
!IF EXISTS("Spark.dep")
!INCLUDE "Spark.dep"
!ELSE 
!MESSAGE Warning: cannot find "Spark.dep"
!ENDIF 
!ENDIF 


!IF "$(CFG)" == "Spark - Win32 Release" || "$(CFG)" == "Spark - Win32 Debug"
SOURCE=.\Spark.cpp

!IF  "$(CFG)" == "Spark - Win32 Release"


"$(INTDIR)\Spark.obj"	"$(INTDIR)\Spark.sbr" : $(SOURCE) "$(INTDIR)"


!ELSEIF  "$(CFG)" == "Spark - Win32 Debug"


"$(INTDIR)\Spark.obj" : $(SOURCE) "$(INTDIR)"


!ENDIF 

SOURCE=.\StdAfx.cpp

!IF  "$(CFG)" == "Spark - Win32 Release"


"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\StdAfx.sbr" : $(SOURCE) "$(INTDIR)"


!ELSEIF  "$(CFG)" == "Spark - Win32 Debug"


"$(INTDIR)\StdAfx.obj" : $(SOURCE) "$(INTDIR)"


!ENDIF 

SOURCE=.\SVector.cpp

!IF  "$(CFG)" == "Spark - Win32 Release"


"$(INTDIR)\SVector.obj"	"$(INTDIR)\SVector.sbr" : $(SOURCE) "$(INTDIR)"


!ELSEIF  "$(CFG)" == "Spark - Win32 Debug"


"$(INTDIR)\SVector.obj" : $(SOURCE) "$(INTDIR)"


!ENDIF 

SOURCE=.\Texture.cpp

!IF  "$(CFG)" == "Spark - Win32 Release"


"$(INTDIR)\Texture.obj"	"$(INTDIR)\Texture.sbr" : $(SOURCE) "$(INTDIR)"


!ELSEIF  "$(CFG)" == "Spark - Win32 Debug"


"$(INTDIR)\Texture.obj" : $(SOURCE) "$(INTDIR)"


!ENDIF 

SOURCE=.\Windows.cpp

!IF  "$(CFG)" == "Spark - Win32 Release"


"$(INTDIR)\Windows.obj"	"$(INTDIR)\Windows.sbr" : $(SOURCE) "$(INTDIR)"


!ELSEIF  "$(CFG)" == "Spark - Win32 Debug"


"$(INTDIR)\Windows.obj" : $(SOURCE) "$(INTDIR)"


!ENDIF 


!ENDIF 

