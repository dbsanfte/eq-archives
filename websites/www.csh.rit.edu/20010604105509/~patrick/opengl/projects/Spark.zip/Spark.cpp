//-------------------------------------------------------------------
//	File:		YourCode.cpp
//	Comments:	Write your visual effect here.
//-------------------------------------------------------------------
#include "stdafx.h"
#include "Texture.h"

#define MAX_DIF 0.075f
#define LAYERS 12
#define LENGTH 41


//----------------------------------------
// Usefull debugger thingy.
void DebugOut(const char *szFormat, ...);
//----------------------------------------

// Change your App Name.
char szAppName[] = "Spark";

// Timer info.  Very useful for keeping animated stuff in sync on different computers.
extern float fTime, fDeltaTime;

extern HWND hWnd;

// Current window dimensions.
extern GLsizei g_w, g_h;

// Use the demonstration texture.
CTexture floorTexture;
CTexture prongTexture;	


float spark_y[LENGTH], spark_z[LENGTH], spark_add[LAYERS][LENGTH];
float addTime=0.0f,angle=0.0f;

// Random Function
float random(float high)
{
    return((float)((double)rand()/32768)*high);
}

// Startup Stuff.
bool Init()	// Called right after the window is created, and OpenGL is initialized.
{
	int i, j;

	glViewport( 0, 0, g_w, g_h );
	
	// Reset the matrix to something we know.
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	gluPerspective( 55.0, (GLfloat) g_w / (GLfloat) g_h, 1.0, 20.0 );

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glTranslatef( 0.0, 0.0, -3.0 );
	glClearColor( 0.0, 0.0, 0.0, 0.0 );
	glEnable(GL_DEPTH_TEST);

	floorTexture.LoadJPG("floor.jpg");
	prongTexture.LoadJPG("metal.jpg");
	
	// Init the spark's position
	spark_y[0] = spark_y[LENGTH-1] = 0.0f;
	for( i=1; i<LENGTH-1; i++ ) 
	{
		spark_y[i] = random(0.5f) - 0.25f;
	}

	spark_z[0] = spark_z[LENGTH-1] = 0.0f;
	for( i=1; i<LENGTH-1; i++ ) 
	{
		spark_z[i] = random(0.5f) - 0.25f;
	}

	for( i=0; i<LAYERS; i++ ) 
	{
		for( j=0; j<LENGTH; j++ ) 
		{
			spark_add[i][j] = random(0.05f) - 0.025f;
		}
	}
		
	// If everything went well, then return true.
	// Returning false will cause the program to quit right away.
	return true;
}

void Shutdown() // Called right after the window is destroyed.
{
}

void updateSparkPos()
{
	int i, j;

	for( i=1; i<LENGTH-1; i++ ) 
	{
		spark_y[i] += 0.1f * ( random(1.0f)-0.5f );
		
		if( spark_y[i] > spark_y[i-1] + MAX_DIF ) spark_y[i] = spark_y[i-1] + MAX_DIF;
		if( spark_y[i] < spark_y[i-1] - MAX_DIF ) spark_y[i] = spark_y[i-1] - MAX_DIF;
		if( spark_y[i] > spark_y[i+1] + MAX_DIF ) spark_y[i] = spark_y[i+1] + MAX_DIF;
		if( spark_y[i] < spark_y[i+1] - MAX_DIF ) spark_y[i] = spark_y[i+1] - MAX_DIF;

		if( spark_y[i] >  0.5f ) spark_y[i] =  0.5f;
		if( spark_y[i] < -0.5f ) spark_y[i] = -0.5f;
	}

	for( i=1; i<LENGTH-1; i++ ) 
	{
		spark_z[i] += 0.05f * ( random(1.0f)-0.5f );
		
		if( spark_z[i] > spark_z[i-1] + MAX_DIF ) spark_z[i] = spark_z[i-1] + MAX_DIF;
		if( spark_z[i] < spark_z[i-1] - MAX_DIF ) spark_z[i] = spark_z[i-1] - MAX_DIF;
		if( spark_z[i] > spark_z[i+1] + MAX_DIF ) spark_z[i] = spark_z[i+1] + MAX_DIF;
		if( spark_z[i] < spark_z[i+1] - MAX_DIF ) spark_z[i] = spark_z[i+1] - MAX_DIF;

		if( spark_z[i] >  0.25f ) spark_z[i] =  0.25f;
		if( spark_z[i] < -0.25f ) spark_z[i] = -0.25f;
	}

	for( i=0; i<LAYERS; i++ )
	{
		for( j=0; j<LENGTH; j++ )
		{
			spark_add[i][j]+=0.015f*( random(1.0f)-0.5f );
	
			if( spark_add[i][j] >  0.025f ) spark_add[i][j] =  0.025f;
			if( spark_add[i][j] < -0.025f ) spark_add[i][j] = -0.025f;
		}
	}

}

void drawSpark()
{
	int x, y;
	float t;

	for( x=0; x<LAYERS; x++ ) 
	{
		glBegin(GL_TRIANGLE_STRIP);
		for( y=0; y<LENGTH; y++ ) 
		{
			t = spark_add[x][y];
			glVertex3f(-1 + (float) y * 0.05f+t,-0.01f+spark_y[y]+t, spark_z[y]);
			glVertex3f(-1 + (float) y * 0.05f+t, 0.01f+spark_y[y]+t, spark_z[y]);
		}
		glEnd();	
	}

}

// Draw all the scene related stuff.
void Render()
{
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

	glDepthFunc(GL_ALWAYS);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);

	glPushMatrix();

	// Rotate so we look down onto the scene
	glRotatef( 25, 1.0f, 0.0f, 0.0f );	

	// Rotate the room around
	angle = angle + 30 * fDeltaTime;
	if( angle > 360.0f )	angle -= 360.0f;
	glRotatef( angle, 0.0f, 1.0f, 0.0f );

	// Draw the main spark
	glPushMatrix();
	glTranslatef( 0.0f, 0.75f, 0.0f );
	glColor3f( 0.1f, 0.075f, 0.2f );
	drawSpark();
	glPopMatrix();
	
	// Draw the reflection
	glPushMatrix();
	glScalef( 1.0f, -1.0f, 1.0f );
	glTranslatef( 0.0f, 0.75f, 0.0f );
	glColor3f( 0.05f, 0.0375f, 0.1f );
	drawSpark();
	glPopMatrix();

	// Don't want the spark showing through the prongs
	glDisable(GL_BLEND);
	glDepthFunc(GL_LESS);
	
	// Draw the prongs
	prongTexture.Use();
	glEnable(GL_TEXTURE_2D);

	glBegin(GL_QUADS);
		glColor3f( 0.65f, 0.65f, 0.65f );
		glTexCoord2f( 0.0f, 0.0f );		glVertex3f( -1.03f, 0.75f, -0.1f );
		glTexCoord2f( 1.0f, 0.0f );		glVertex3f( -1.03f, 0.75f,  0.1f );
		glTexCoord2f( 1.0f, 1.0f );		glVertex3f( -1.03f, 0.00f,  0.1f );
		glTexCoord2f( 0.0f, 1.0f );		glVertex3f( -1.03f, 0.00f, -0.1f );

		glTexCoord2f( 0.0f, 0.0f );		glVertex3f( 1.03f, 0.75f, -0.1f );
		glTexCoord2f( 1.0f, 0.0f );		glVertex3f( 1.03f, 0.75f,  0.1f );
		glTexCoord2f( 1.0f, 1.0f );		glVertex3f( 1.03f, 0.00f,  0.1f );
		glTexCoord2f( 0.0f, 1.0f );		glVertex3f( 1.03f, 0.00f, -0.1f );

		glColor3f( 0.13f, 0.13f, 0.13f );
		glTexCoord2f( 0.0f, 0.0f );		glVertex3f( -1.03f, -0.75f, -0.1f );
		glTexCoord2f( 1.0f, 0.0f );		glVertex3f( -1.03f, -0.75f,  0.1f );
		glTexCoord2f( 1.0f, 1.0f );		glVertex3f( -1.03f,  0.00f,  0.1f );
		glTexCoord2f( 0.0f, 1.0f );		glVertex3f( -1.03f,  0.00f, -0.1f );

		glTexCoord2f( 0.0f, 0.0f );		glVertex3f( 1.03f, -0.75f, -0.1f );
		glTexCoord2f( 1.0f, 0.0f );		glVertex3f( 1.03f, -0.75f,  0.1f );
		glTexCoord2f( 1.0f, 1.0f );		glVertex3f( 1.03f,  0.00f,  0.1f );
		glTexCoord2f( 0.0f, 1.0f );		glVertex3f( 1.03f,  0.00f, -0.1f );

	glEnd();

	// Enable blend to show the reflection through the floor
	glEnable(GL_BLEND);

	// Draw the floor
	floorTexture.Use();
	glBegin(GL_QUADS);
		glColor3f( 0.65f,0.65f,0.65f );
		glTexCoord2f( 0.0f, 0.0f );		glVertex3f( -1.75f, 0.0f, -1.75f );
		glTexCoord2f( 1.0f, 0.0f );		glVertex3f( -1.75f, 0.0f,  1.75f );
		glTexCoord2f( 1.0f, 1.0f );		glVertex3f(  1.75f, 0.0f,  1.75f );
		glTexCoord2f( 0.0f, 1.0f );		glVertex3f(  1.75f, 0.0f, -1.75f );
	glEnd();

	glDisable(GL_TEXTURE_2D);

	glPopMatrix();


	addTime += fDeltaTime;
	if( addTime > 0.015f ) 
	{
		updateSparkPos();
		addTime -= 0.015f;

	}

	// Framerate
	static float secTime=fTime;
	static int numFrames;
	if (fTime-secTime>=1.0)
	{ 
		char buf[256];
		sprintf(buf,"%s - %3.2f fps",szAppName, numFrames/(fTime-secTime));
		SetWindowText(hWnd, buf);
		secTime = fTime;
		numFrames = 0;
	}

	numFrames++;
}
