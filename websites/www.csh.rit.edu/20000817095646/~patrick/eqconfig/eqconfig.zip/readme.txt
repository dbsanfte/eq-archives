EQ Config version 0.95b  **NOTE - This software is still in beta.


Installation:
Just copy to any directory, EQ Config finds your eqclient.ini 
file.  It is recommended you back up your eqclient.ini file 
just in case a bug has escaped my testing.


Usage:
Upon start, EQ Config finds and read in the settings from 
the eqclient.ini file or uses the default options if this file
cannot be read.  You can open another INI file by clicking on
File/Save As.  Change the values as desired and export the 
new values to eqclient.ini by clicking on the File/Export 
menu.  You can also save the settings to another filename 
by clicking on File/Save As


TODO List:
1.	Option to allow users to specify a background color.
2.	Add in key shortcuts.
3.	Anything that is a good idea that someone suggests.


Disclaimer:
This software is freeware.  It works as intended on my 
system, but use at your own risk.  I accept no 
responsibility for any ill affects resulting from this 
program.  You may distribute this program freely, just give 
credit where credit is due.


Hope you Enjoy!

Patrick Moore 
Morriso Fortissimo  -  Lanys T'Val
Fold of the Black Talon
patrick@csh.rit.edu