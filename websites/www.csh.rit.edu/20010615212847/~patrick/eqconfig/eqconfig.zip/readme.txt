EQ Config version 1.0  -  Updated 09/19/2000
	

Installation:
Just copy to any directory, EQ Config finds your eqclient.ini 
file.  It is recommended you back up your eqclient.ini file 
just in case a bug has escaped my testing.


Usage:
Upon start, EQ Config finds and read in the settings from 
the eqclient.ini file or uses the default options if this file
cannot be read.  You can open another INI file by clicking on
File/Open.  Change the values as desired and export the 
new values to eqclient.ini by clicking on the File/Export 
menu.  You can also save the settings to another filename 
by clicking on File/Save As.


Changes from v.965b to v1.0
	- Added controls to change the background color
	- Some very minor bug fixes

Changes from v.96b to v.965b
	- Added support for the new eqclient.ini options for the 8/24/00 patch

Changes from v.95b to v.96b 
	- Added support for the new eqclient.ini options for the 8/17/00 patch 

Changes from v.9b to v.95b 
	- Cleaned up the code 
	- Minor UI Improvements 
	- Added more error checking code 
	- Added option to load the default settings 
	- Added option to open or save to/from other files 


Disclaimer:
This software is freeware.  It works as intended on my 
system, but use at your own risk.  I accept no 
responsibility for any ill affects resulting from this 
program.  You may distribute this program freely, just give 
credit where credit is due.


Hope you Enjoy!

Patrick Moore 
Morriso Fortissimo  -  Lanys T'Val
Fold of the Black Talon
http://www.csh.rit.edu/~patrick/eqconfig
patrick@csh.rit.edu