// PlanetsDlg.h : header file
//

#if !defined(AFX_PLANETSDLG_H__75C5DAF5_5CA0_11D3_B2B1_0080C82BE26F__INCLUDED_)
#define AFX_PLANETSDLG_H__75C5DAF5_5CA0_11D3_B2B1_0080C82BE26F__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CPlanetsDlg dialog

class CPlanetsDlg : public CDialog
{
// Construction
public:

	CPlanetsDlg(CWnd* pParent = NULL);	// standard constructor

	BOOL SetWindowPixelFormat(HDC hDC);
	BOOL CreateViewGLContext(HDC hDC);
	void RenderScene();
	
// Dialog Data
	//{{AFX_DATA(CPlanetsDlg)
	enum { IDD = IDD_PLANETS_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPlanetsDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CPlanetsDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	HGLRC m_hGLContext;
	int m_GLPixelIndex;

	int m_day, m_month1, m_month2, m_year, m_year2;

	GLuint start_list;
	GLUquadricObj *qobj;


};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PLANETSDLG_H__75C5DAF5_5CA0_11D3_B2B1_0080C82BE26F__INCLUDED_)
