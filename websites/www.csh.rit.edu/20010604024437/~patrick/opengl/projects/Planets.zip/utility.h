void glPrintf(GLuint x, GLuint y, GLfloat scale, char* format, ...);
float FPS(int LastFrameTime);
