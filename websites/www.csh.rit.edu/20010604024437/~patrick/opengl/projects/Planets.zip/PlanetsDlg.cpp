// PlanetsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Planets.h"
#include "PlanetsDlg.h"
#include "math.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPlanetsDlg dialog

CPlanetsDlg::CPlanetsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPlanetsDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPlanetsDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_day = 0;
	m_month1 = 0;
	m_month2 = 0;
	m_year = 0;
	m_year2 = 0;

}

void CPlanetsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPlanetsDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPlanetsDlg, CDialog)
	//{{AFX_MSG_MAP(CPlanetsDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_SIZE()
	ON_WM_KEYDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPlanetsDlg message handlers

BOOL CPlanetsDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	GLfloat no_mat[] = { 0.0, 0.0, 0.0, 1.0 };  // Lighting Properties
	GLfloat diffuse[] = { 1.0, 1.0, 1.0, 1.0 };

	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);

	glClearColor(0.0, 0.0, 0.0, 0.0);
	glShadeModel(GL_SMOOTH);
	
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_DEPTH_TEST);

	glColorMaterial(GL_FRONT, GL_DIFFUSE);
	glEnable(GL_COLOR_MATERIAL);

	start_list = glGenLists(4);
	qobj = gluNewQuadric();

	// Sun sphere	
	gluQuadricDrawStyle(qobj, GLU_FILL);
	gluQuadricNormals(qobj, GLU_SMOOTH);
	glNewList(start_list, GL_COMPILE);
		gluSphere(qobj, .5, 20, 8);
	glEndList();

	// Earth sphere
	gluQuadricDrawStyle(qobj, GLU_FILL);
	gluQuadricNormals(qobj, GLU_SMOOTH);
	glNewList(start_list+1, GL_COMPILE);
		gluSphere(qobj, 0.05, 10, 7);
	glEndList();

	// Mars Sphere
	gluQuadricDrawStyle(qobj, GLU_FILL);
	gluQuadricNormals(qobj, GLU_SMOOTH);
	glNewList(start_list+2, GL_COMPILE);
		gluSphere(qobj, 0.09, 10, 8);
	glEndList();


	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CPlanetsDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CPaintDC dc(this);
		RenderScene();
		SwapBuffers(dc.m_ps.hdc);
		CDialog::OnPaint();

	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CPlanetsDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

BOOL CPlanetsDlg::SetWindowPixelFormat(HDC hDC)
{
	PIXELFORMATDESCRIPTOR pixelDesc;
	
	pixelDesc.nSize = sizeof(PIXELFORMATDESCRIPTOR);
	pixelDesc.nVersion = 1;
	
	pixelDesc.dwFlags = PFD_DRAW_TO_WINDOW | 
						PFD_SUPPORT_OPENGL |
						PFD_DOUBLEBUFFER |
						PFD_STEREO_DONTCARE;
	
	pixelDesc.iPixelType = PFD_TYPE_RGBA;
	pixelDesc.cColorBits = 32;
	pixelDesc.cRedBits = 8;
	pixelDesc.cRedShift = 16;
	pixelDesc.cGreenBits = 8;
	pixelDesc.cGreenShift = 8;
	pixelDesc.cBlueBits = 8;
	pixelDesc.cBlueShift = 0;
	pixelDesc.cAlphaBits = 0;
	pixelDesc.cAlphaShift = 0;
	pixelDesc.cAccumBits = 64;
	pixelDesc.cAccumRedBits = 16;
	pixelDesc.cAccumGreenBits = 16;
	pixelDesc.cAccumBlueBits = 16;
	pixelDesc.cAccumAlphaBits = 0;
	pixelDesc.cDepthBits = 32;
	pixelDesc.cStencilBits = 8;
	pixelDesc.cAuxBuffers = 0;
	pixelDesc.iLayerType = PFD_MAIN_PLANE;
	pixelDesc.bReserved = 0;
	pixelDesc.dwLayerMask = 0;
	pixelDesc.dwVisibleMask = 0;
	pixelDesc.dwDamageMask = 0;
	
	m_GLPixelIndex = ChoosePixelFormat(hDC,&pixelDesc);
	if(m_GLPixelIndex==0) // Choose default
	{
		m_GLPixelIndex = 1;
		if(DescribePixelFormat(hDC,m_GLPixelIndex,
			sizeof(PIXELFORMATDESCRIPTOR),&pixelDesc)==0)
		{
			return FALSE;
		}
	}

	if(SetPixelFormat(hDC,m_GLPixelIndex,&pixelDesc)==FALSE)
	{
		return FALSE;
	}

	return TRUE;
}


BOOL CPlanetsDlg::CreateViewGLContext(HDC hDC)
{
	m_hGLContext = wglCreateContext(hDC);

	if(m_hGLContext==NULL)
		return FALSE;

	if(wglMakeCurrent(hDC,m_hGLContext)==FALSE)
		return FALSE;

	return TRUE;
}

int CPlanetsDlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	HWND hWnd = GetSafeHwnd();
	HDC hDC = ::GetDC(hWnd);

	if(SetWindowPixelFormat(hDC) == FALSE)
		return 0;

	if(CreateViewGLContext(hDC) == FALSE)
		return 0;

	glClearColor(0.0, 0.0, 0.0, 1.0);
	glShadeModel(GL_SMOOTH);

	// Antialiasing stuff
	glEnable(GL_LINE_SMOOTH);
	glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);

	return 0;
}

void CPlanetsDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	if(wglGetCurrentContext() != NULL)
		wglMakeCurrent(NULL,NULL);

	if(m_hGLContext != NULL)
	{
		wglDeleteContext(m_hGLContext);
		m_hGLContext = NULL;
	}	
}

void CPlanetsDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	GLsizei width, height;

	width = cx;
	height = cy;

	glViewport(0, 0, width, height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60.0, (GLfloat)width / (GLfloat)height, 1.0, 20.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt( 0.0, 0.0, 5.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0 );
}

void CPlanetsDlg::RenderScene()
{
	GLfloat light_position[] = { 0.0f, 0.0f, 1.2f, 1.0f };

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glColor3f(1.0, 1.0, 1.0);

	glLightfv(GL_LIGHT0, GL_POSITION, light_position);	


	glPushMatrix();
	glColor3f(1.0, 1.0, 0.0);
	glCallList(start_list);	
	glPopMatrix();


	glPushMatrix();
	glRotatef( (GLfloat) m_year, 0.0, 1.0, 0.0 );
	glTranslatef(2.0, 0.0, 0.0);

	glColor3f(0.5f, 0.5f, 0.5f); 

	// Moon 1
	glPushMatrix();
	glRotatef( (GLfloat) m_month2, 0.0, 1.0, 0.0);
	glTranslatef((GLfloat) 0.4, 0.0, 0.0);
	glCallList(start_list+1);
	glPopMatrix();

	// Moon 2 
	glPushMatrix();
	glRotatef( (GLfloat) m_month1, 0.0, 1.0, 0.0);
	glTranslatef((GLfloat) 0.2, 0.0, 0.0);
	glCallList(start_list+1);
	glPopMatrix();

	// Planet
	glRotatef( 23, -cos(m_year), 0, -sin(m_year));
	glRotatef( (GLfloat)m_day, 0.0, 1.0, 0.0 );
	glColor3f(0.0, 0.0, 1.0);
	glCallList(start_list+2);
	glPopMatrix();

	// 2nd Planet
	glPushMatrix();
	glRotatef( (GLfloat) m_year2, 0.0, 1.0, 0.0 );
	glTranslatef(3.0f, 0.0f, 0.0f);
	glRotatef( 14, -cos(m_year2), 0, -sin(m_year2));
	glRotatef( (GLfloat)m_day, 0.0, 1.0, 0.0 );
	glColor3f(1.0, 0.0, 0.0);
	glCallList(start_list+2);
	glPopMatrix();
	
}

void CPlanetsDlg::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	switch(nChar) 
	{
		case 'd':
			m_day = (m_day + 10) % 360;
			InvalidateRect(NULL,FALSE);
			break;
		case 'D':
			m_day = (m_day - 10) % 360;
			InvalidateRect(NULL,FALSE);
			break;
		case 'y':
			m_year = (m_year + 5) % 360;
			m_year2 = (m_year2 + 2) % 360;
			InvalidateRect(NULL,FALSE);
			break;
		case 'Y':
			m_year = (m_year - 5) % 360;
			m_year2 = (m_year2 - 2) % 360;
			InvalidateRect(NULL,FALSE);
			break;
		case 'm':
			m_month1 = (m_month1 + 5) % 360;
			m_month2 = (m_month2 + 1) % 360;
			InvalidateRect(NULL,FALSE);
			break;
		case 'M':
			m_month1 = (m_month1 - 5) % 360;
			m_month2 = (m_month2 - 1) % 360;
			InvalidateRect(NULL,FALSE);
			break;
		default:
			break;
	}


	
	CDialog::OnKeyDown(nChar, nRepCnt, nFlags);
}
