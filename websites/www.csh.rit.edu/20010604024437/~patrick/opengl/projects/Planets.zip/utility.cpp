#include <stdio.h>
#include <stdarg.h>
#include <assert.h>
#include <math.h>
#include "utility.h"

/** general purpose vector text routine.  
   It draws a string according to the
   format in a stroke font at x, y after scaling it by the scale
   specified.  x, y and scale are all in window-space [i.e., pixels]
   with origin at the lower-left.
*/

void glPrintf(GLuint x, GLuint y, GLfloat scale, char* format, ...)
{
    va_list args;
    char buffer[255], *p;
    GLfloat font_scale = 119.05f + 33.33f;

    va_start(args, format);
    vsprintf(buffer, format, args);
    va_end(args);

    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0, glutGet(GLUT_WINDOW_WIDTH), 0, glutGet(GLUT_WINDOW_HEIGHT));

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();

    glPushAttrib(GL_ENABLE_BIT);
    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LINE_SMOOTH);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE);
    glTranslatef(x, y, 0.0);

    glScalef(scale/font_scale, scale/font_scale, scale/font_scale);

    for(p = buffer; *p; p++)
			glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, *p);
  
    glPopAttrib();

    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
}

/** Generic routine to calculate averaged Frame per Second.
It should be called every redraw with the time needed to redraw it.
It returns the average of the last 10 renddering times
 */ 
float FPS(int LastFrameTime)
{
	static int LastTimes[10]={0,0,0,0,0,0,0,0,0,0};
	static int c=0;
	int i;
	float average=0;
	c=(c+1)%10;
	LastTimes[c]=LastFrameTime;
	
	for(i=0;i<10;i++)
		average+=LastTimes[i];
	return 1000.0/(average/10.0);
}
