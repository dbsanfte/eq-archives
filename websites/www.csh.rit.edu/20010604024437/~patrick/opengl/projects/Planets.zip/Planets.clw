; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CPlanetsDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "Planets.h"

ClassCount=2
Class1=CPlanetsApp
Class2=CPlanetsDlg

ResourceCount=3
Resource2=IDR_MAINFRAME
Resource3=IDD_PLANETS_DIALOG

[CLS:CPlanetsApp]
Type=0
HeaderFile=Planets.h
ImplementationFile=Planets.cpp
Filter=N

[CLS:CPlanetsDlg]
Type=0
HeaderFile=PlanetsDlg.h
ImplementationFile=PlanetsDlg.cpp
Filter=D
LastObject=CPlanetsDlg
BaseClass=CDialog
VirtualFilter=dWC



[DLG:IDD_PLANETS_DIALOG]
Type=1
Class=CPlanetsDlg
ControlCount=1
Control1=IDC_BUTTON1,button,1342242816

