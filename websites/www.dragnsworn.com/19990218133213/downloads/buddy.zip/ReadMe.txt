Battle.net Buddy Monitor
Copyright (c) 1998  Matthew Everett
All Rights Reserved

IMPORTANT
=========
You must assume the entire risk of using this program.  I assume no
responsibility whatsoever.  Please read the license agreement in the file
LICENSE.DOC for details.


What is the Buddy Monitor?
==========================
The buddy monitor is a program that runs in the background on your computer and
tells you which of your friends are currently logged onto battle.net.  This
information is displayed graphically and is color-coded to make using the buddy
monitor as easy as possible.  It also features a graphical interface that makes
maintaining your buddy list and controlling the output of the program extremely
simple to do.


Getting Started
======= =======
Installing the buddy monitor and creating your buddy list should only take a
minute by following the installation instructions:

	1) Extract the executable file bnetbuddy.exe into the directory in
	   which you would like the buddy monitor to reside.

	2) Run the program.

	3) For each friend that you would like to monitor, click the Add button,
	   type in their name and handle.  Note that the Name field is for the
	   person's actual name, and the Handle field is for their battle.net
	   ID.

The buddy monitor should start reporting whether your friends are online or not
within a minute.  Your list will be saved as soon as you exit the program and
will be reloaded whenever the program is restarted.


Features
========

Add
---
The Add button simply adds a person to your buddy list.  Type the person's name
in the Name field, and type their battle.net ID in the Handle field.  If you
accidentally click the Add button, simply hit ESC or click the Cancel button to
cancel.  You can also add a person by clicking the right mouse button anywhere
in the dialog and selecting Add.

Remove
------
The Remove button will permanently remove someone from your buddy list.  To
remove someone from the list, click on the person's name and click on the Remove
button.  You will be prompted to confirm your action, and the person will then
be deleted.  If you wish to add the person again at a later time, you can do so
using the Add button.  You may also remove a person from the list by right-
clicking on their name and selecting Remove.

Properties
----------
The Properties button allows you to change some of the major features of the
buddy monitor.  The choices that you are given are:

	* Refresh Time: This option sets how frequently the buddy monitor logs
	  on to battle.net to check whether your friends are online or not.
	  The default setting is once every 60 seconds or once a minute.

	* Sound when buddy online: When this option is selected, a sound will
	  be played whenever one of your friends comes online.  You may select
	  the sound that is played by clicking on the Browse button to the
	  right of the option.  When the program is first run, this option is
	  turned off.

	* Sound when buddy offline: This option is identical to the previous
	  option except that a sound is played whenever one of your friends
	  logs off.  You can select the sound file to be played by clicking on
	  the Browse button to the right of the option.  When you first launch
	  the buddy monitor, this option will not be selected.

The properties dialog box can also be accessed by clicking the right mouse
button in the dialog and selecting properties.

Options
-------
If you click on the icon in the upper-left corner of the program, the system
menu will appear, including the options submenu.  The options that you are
given are:

	* Always On Top: When this item is checked, the buddy monitor will
	  always appear on top of other windows even when another window is
	  dragged in front of it.  This option is selected by default and is
	  always on when the Minimize To System Tray option is used.

	* Minimize To System Tray: When you turn on this option, the buddy
	  monitor will not appear in the task bar.  Instead, it will appear as
	  an icon in the system tray that you can double-click to make the
	  window reappear after you have minimized it.  The icon will be color-
	  coded to indicate whether your friends are online or not.  A green
	  magnifying glass indicates that at least one friend is online.  A red
	  glass means that none of your friends is online.  A blue glass means
	  that the buddy monitor cannot get any information about any of your
	  friends.

Edit
----
You can edit a person's entry in the buddy list in three ways.  First, if you
only need to change the person's name, you can simply click on the person's name
wait a second, and click again.  Then, type the new name and hit ENTER.  If
you also need to change the person's handle, you can either double-click on the
person, or you can right-click on the person and select Edit.  You can then
change the person's name and handle.

The Edit command will also display the exact location of the person double-
clicked.  It will tell you if they are in a game or a channel and the name of
the game or channel if available.  Note that this report may not agree with the
main list because the main list is only updated at regular intervals while the
Edit dialog box does an immediate check as to the person's status.

Sorting
-------
You can sort the output based on the person's name, handle, or status by
clicking on the appropriate header at the top of the list.  If you sort
by status, people who are online will appear first, followed by people who
are offline and then people whose status is unknown.  Sorting in this way
sorts the list only once, and future changes to the list will not be
sorted.  So, if, for example,  the online status of one of your friends
changes, the list will not resort itself to reflect the changes.


Known Problems
===== ========

	* Under some conditions, the Edit dialog box may not be able to locate
	  the person double-clicked and will report their location as Unknown.
	  If this problem occurs, simply try again, and the program will usually
	  report the person's location correctly.


Future Expansion
====== =========

	* In the future, I hope to add some chat capabilities to the program to
	  make it act more like ICQ.  This step will require me to rewrite all
	  the code that accesses battle.net, however, so I probably will not be
	  adding this ability soon.


Questions, Problems, and Suggestions
========== ========= === ===========
Any questions, problems, or suggestions should be directed to Cardinal at:

BNetBuddy@Aol.com

For those of you who are wondering, I do not use AOL as my primary service
provider.  I just wanted a devoted e-mail address for questions about this
program.

Please note that although I may not be able to respond immediately to your
e-mails, I will try my best to answer you in a reasonable amount of time.  I
would truly appreciate any feedback that you may have concerning any aspect of
the buddy monitor.


Thank you very much for downloading the Battle.net Buddy Monitor.  I hope that
it proves to be useful.

-Cardinal


Battle.net is a registered trademark of Blizzard Entertainment.
