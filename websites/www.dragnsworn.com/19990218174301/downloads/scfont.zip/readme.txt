THE STARCRAFT FONT PACK
Created by EXoDuS of SCAs
http://sla.pudzone.com
email:  kbell@dhc.net

 Thank you for downloading this fontpack!
-----------------------------------------------------------
I created this font pack for public use.  You may distribute it freely.  I suggest using it for things such as creating your own headers on your personal Starcraft pages.  You can also write interesting things with it.  But to do so you will need to have some copying and pasting skills!  Otherwise, have fun with it!

EXoDuS