Feekle Log! Readme v1.0
-------------------------------

Thanks for trying Feekle Log! To start logging in EQ, type /log on. To install, just unzip the contents into any directory and load Feekle Log.exe. Select the log file by going to Configuration>Log Path. Then you can switch through the different information panels.

If you see any bugs please E-Mail me exactly what happend and send your log file if you can to:

poiuyt@bit-net.com

Also, please send in features that you want to be seen in the next version! If people do not mail me then i wont know if you want to see new things!

Thanks for EQVault for posting my program on their site!

-Feekle... Troll Shadow Knight on Talloz Zek
(Peter)