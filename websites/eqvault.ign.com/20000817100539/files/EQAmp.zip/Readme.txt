Jenovah's Everquest Skin Make 5 Build 1 Aplha
-----------
To install the skin load up winamp (www.winamp.com) and right click and select Skin Browser.  Just browse your HD until you find the place where you unzipped the zip file.  Highlight it and Winamp should transform into EQAmp! :)
-----------
Special Thanks to:

EQVault where I found the main graphic of the amp.
Verant for making the graphic in the first place.
Myself for taking the time to make this incredibly colorful little skin.
WinampShrine for providing a link to the program that helped make this skin.
-----------
Release Notes:
 This version includes a "useable" skin, not much else.  The next version will include the playlist editor skin and equalizer skin.
 Includes: My own custom color arrangement for the buttons (oooh)
-----------
www.gamerealm.com/gtk
  This page is mine for now which hosts a guild on another game :)  But it will soon host my Everquest site (In the works)
Go check out my HTML and Java :D
-----------
Copyright: No there is no copyright although I would hope you will not claim this as your own masterpiece :)  Distribute it freely as long as you say who made it. Me (Jenovah)
-----------
Most Important!
  Have fun :)
-----------