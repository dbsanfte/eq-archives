<html>
<head>
	<title>EverQuest Roster: Update Database Tables</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<link rel="stylesheet" href="roster.css" type="text/css">
</head>

<body>


<?php
// Includes
require( './includes/functions.inc' );
require( './config.php' );

// Main PHP code
{
	// Define queries
	// PoP Tier 1 Flags
	$strCreatePoP_Tier_1_FlagsQuery	=	"	CREATE TABLE PoP_Tier_1_Flags ( " . 
										"	  CharID smallint(3) NOT NULL default '0', " . 
										"	  Any_PoJ_Trial tinyint(1) NOT NULL default '0', " . 
										"	  All_PoJ_Trials tinyint(1) NOT NULL default '0', " . 
										"	  PoI_Xanamech tinyint(1) NOT NULL default '0', " . 
										"	  PoI_Behemoth tinyint(1) NOT NULL default '0', " . 
										"	  PoD_Grimror_Quest tinyint(1) NOT NULL default '0', " . 
										"	  PoD_Grummus tinyint(1) NOT NULL default '0', " . 
										"	  PoN_Hedge_Quest tinyint(1) NOT NULL default '0', " . 
										"	  PoNb_Terris_Thule tinyint(1) NOT NULL default '0', " . 
										"	  PRIMARY KEY  (CharID) " . 
										"	) TYPE=MyISAM COMMENT='PoP Tier 1 Flags' ";
	// PoP Tier 2 Flags
	$strCreatePoP_Tier_2_FlagsQuery	=	"	CREATE TABLE PoP_Tier_2_Flags ( " . 
										"	  CharID smallint(3) NOT NULL default '0', " . 
										"	  PoS_Askr_Quest tinyint(1) NOT NULL default '0', " . 
										"	  PoV_Grenic_Quest tinyint(1) NOT NULL default '0', " . 
										"	  PoV_AerinDar tinyint(1) NOT NULL default '0', " . 
										"	  CoD_Carprin_Event tinyint(1) NOT NULL default '0', " .
										"	  CoD_Bertoxxulous tinyint(1) NOT NULL default '0', " . 
										"	  PoTorment_Saryrn tinyint(1) NOT NULL default '0', " . 
										"	  PoS_Wembly_Quest tinyint(1) NOT NULL default '0', " . 
										"	  PRIMARY KEY  (CharID) " . 
										"	) TYPE=MyISAM COMMENT='PoP Tier 2 Flags' ";
	// PoP Tier 3 Flags
	$strCreatePoP_Tier_3_FlagsQuery	=	"	CREATE TABLE PoP_Tier_3_Flags ( " . 
										"	  CharID smallint(3) NOT NULL default '0', " . 
										"	  HoH_Trials tinyint(1) NOT NULL default '0', " . 
										"	  HoH_Trial1_RyddaDar tinyint(1) NOT NULL default '0', " . 
										"	  HoH_Trial2_Ogre tinyint(1) NOT NULL default '0', " . 
										"	  HoH_Trial3_Madmen tinyint(1) NOT NULL default '0', " . 
										"	  HoHb_Mithanial_Marr tinyint(1) NOT NULL default '0', " . 
										"	  PoTactics_Tallon_Zek tinyint(1) NOT NULL default '0', " . 
										"	  PoTactics_Vallon_Zek tinyint(1) NOT NULL default '0', " . 
										"	  PoTactics_Rallos_Zek_Quest tinyint(1) NOT NULL default '0', " . 
										"	  BoT_Rescue_Karana_Quest tinyint(1) NOT NULL default '0', " . 
										"	  SolRoTower_Jiva tinyint(1) NOT NULL default '0', " . 
										"	  SolRoTower_Xuzl tinyint(1) NOT NULL default '0', " . 
										"	  SolRoTower_Arlyxir tinyint(1) NOT NULL default '0', " . 
										"	  SolRoTower_Rizlona tinyint(1) NOT NULL default '0', " . 
										"	  SolRoTower_Protector_of_Dresolik tinyint(1) NOT NULL default '0', " . 
										"	  SolRoTower_Solusek_Ro tinyint(1) NOT NULL default '0', " . 
										"	  PRIMARY KEY  (CharID) " . 
										"	) TYPE=MyISAM COMMENT='PoP Tier 3 Flags' ";
	// PoP Tier 4 Flags
	$strCreatePoP_Tier_4_FlagsQuery	=	"	CREATE TABLE PoP_Tier_4_Flags ( " . 
										"	  CharID smallint(3) NOT NULL default '0', " . 
										"	  PoAir_Xegony tinyint(1) NOT NULL default '0', " . 
										"	  PoFire_Fennin_Ro tinyint(1) NOT NULL default '0', " . 
										"	  PoWater_Coirnav tinyint(1) NOT NULL default '0', " . 
										"	  PoEarthb_The_Rathe tinyint(1) NOT NULL default '0', " . 
										"	  PoTime_Time_Phased_Quintessence tinyint(1) NOT NULL default '0', " . 
										"	  PRIMARY KEY  (CharID) " . 
										"	) TYPE=MyISAM COMMENT='PoP Tier 4 Flags' ";
	// GoD Flags
	$strCreateGoD_FlagsQuery		=	"	CREATE TABLE GoD_Flags ( " . 
										"	  CharID smallint(3) NOT NULL default '0', " . 
										"	  Purifying_Plant tinyint(1) NOT NULL default '0', " . 
										"	  Emanating_Furnace tinyint(1) NOT NULL default '0', " . 
										"	  Lair_of_Trapped_Ones tinyint(1) NOT NULL default '0', " . 
										"	  Pool_of_Sludge tinyint(1) NOT NULL default '0', " . 
										"	  Smith_Rondo tinyint(1) NOT NULL default '0', " . 
										"	  Vxed tinyint(1) NOT NULL default '0', " . 
										"	  Tipt tinyint(1) NOT NULL default '0', " . 
										"	  Vrex_Barxt_Qurat tinyint(1) NOT NULL default '0', " . 
										"	  Cynosure_Kvanjji tinyint(1) NOT NULL default '0', " . 
										"	  Noqufiel_in_Inktuta tinyint(1) NOT NULL default '0', " . 
										"	  ZunMuram_Tkarish_Zyk tinyint(1) NOT NULL default '0', " . 
										"	  PRIMARY KEY  (CharID) " . 
										"	) TYPE=MyISAM COMMENT='GoD Flags' ";
	// DoN Flags
	$strCreateDoN_FlagsQuery		=	"	CREATE TABLE DoN_Flags ( " . 
										"	  CharID smallint(3) NOT NULL default '0', " . 
										"	  T1_Create_an_Antidote tinyint(1) NOT NULL default '0', " . 
										"	  T1_Greed_of_the_Goblins tinyint(1) NOT NULL default '0', " . 
										"	  T1_Burning_Arrows tinyint(1) NOT NULL default '0', " . 
										"	  T1_Children_of_Gimblax tinyint(1) NOT NULL default '0', " . 
										"	  T2_Defend_the_Kirin_Contact tinyint(1) NOT NULL default '0', " . 
										"	  T2_Recover_the_Lost_Map tinyint(1) NOT NULL default '0', " . 
										"	  T2_Turn_the_Tides_of_the_Sand tinyint(1) NOT NULL default '0', " . 
										"	  T2_Sickness_of_the_Spirit tinyint(1) NOT NULL default '0', " . 
										"	  T2_Calling_Emoush tinyint(1) NOT NULL default '0', " . 
										"	  T3_Protect_the_Waters tinyint(1) NOT NULL default '0', " . 
										"	  T3_Snowfoots_Revenge tinyint(1) NOT NULL default '0', " . 
										"	  T3_The_Sacred_Scrolls tinyint(1) NOT NULL default '0', " . 
										"	  T3_History_of_the_Isle tinyint(1) NOT NULL default '0', " . 
										"	  T3_Trial_of_Perserverance tinyint(1) NOT NULL default '0', " . 
										"	  T3_Volkaras_Bite tinyint(1) NOT NULL default '0', " . 
										"	  T4_Goblin_Dojo tinyint(1) NOT NULL default '0', " . 
										"	  T4_Guardian_of_the_Sands tinyint(1) NOT NULL default '0', " . 
										"	  T4_An_End_to_the_Storms tinyint(1) NOT NULL default '0', " . 
										"	  T5_Origins_of_the_Curse tinyint(1) NOT NULL default '0', " . 
										"	  T5_The_Curse_of_JuRek tinyint(1) NOT NULL default '0', " . 
										"	  T5_In_the_Shadows tinyint(1) NOT NULL default '0', " .
										"	  PRIMARY KEY  (CharID) " . 
										"	) TYPE=MyISAM COMMENT='DoN Flags' ";

	// DoD Spells
	$strCreateDoD_SpellsQuery		=	"	CREATE TABLE `DoD_Spells` ( " . 
										"	  `CharID` smallint(3) NOT NULL default '0', " . 
										"	  `A_Rogues_Trust` tinyint(1) NOT NULL default '0', " . 
										"	  `Scouting_the_City` tinyint(1) NOT NULL default '0', " . 
										"	  `Building_the_Disguise` tinyint(1) NOT NULL default '0', " . 
										"	  `The_Search_for_Illsuras` tinyint(1) NOT NULL default '0', " . 
										"	  `The_Rage_of_Kelliad` tinyint(1) NOT NULL default '0', " . 
										"	  `The_Lost_Notebook` tinyint(1) NOT NULL default '0', " . 
										"	  `Cavern_Botany` tinyint(1) NOT NULL default '0', " . 
										"	  `The_Search_for_Clues` tinyint(1) NOT NULL default '0', " . 
										"	  `Rescue_Cicero` tinyint(1) NOT NULL default '0', " . 
										"	  `Preemptive_Strike` tinyint(1) NOT NULL default '0', " . 
										"	  `Praetorian_Guard` tinyint(1) NOT NULL default '0', " . 
										"	  `The_Fall_of_Illsalin` tinyint(1) NOT NULL default '0', " . 
										"	  `Flights_of_the_Seeker` tinyint(1) NOT NULL default '0', " . 
										"	  `Into_the_Shadows` tinyint(1) NOT NULL default '0', " . 
										"	  PRIMARY KEY  (CharID) " . 
										"	) TYPE=MyISAM COMMENT='DoD Spells' ";

	// OoW Citadel of Anguish
	$strCreateOoW_CoAQuery			=	"	CREATE TABLE `OoW_CoA` ( " . 
										"	  `CharID` smallint(3) NOT NULL default '0', " . 
										"	  `Mastery_of_Adaptation` tinyint(1) NOT NULL default '0', " . 
										"	  `Mastery_of_Corruption` tinyint(1) NOT NULL default '0', " . 
										"	  `Mastery_of_Endurance` tinyint(1) NOT NULL default '0', " . 
										"	  `Mastery_of_Foresight` tinyint(1) NOT NULL default '0', " . 
										"	  `Mastery_of_Hate` tinyint(1) NOT NULL default '0', " . 
										"	  `Mastery_of_Specialization` tinyint(1) NOT NULL default '0', " . 
										"	  `Seal_Mastery_of_All` tinyint(1) NOT NULL default '0', " . 
										"	  `Signet_Crystal_Gemmed` tinyint(1) NOT NULL default '0', " . 
										"	  `Signet_Discolored` tinyint(1) NOT NULL default '0', " . 
										"	  `Signet_Dust_Marred` tinyint(1) NOT NULL default '0', " . 
										"	  `Signet_Glimmering` tinyint(1) NOT NULL default '0', " . 
										"	  `Signet_Tarnished` tinyint(1) NOT NULL default '0', " . 
										"	  `Signet_Two_Toned` tinyint(1) NOT NULL default '0', " . 
										"	  `Signet_Weather_Worn` tinyint(1) NOT NULL default '0', " . 
										"	  PRIMARY KEY  (`CharID`) " . 
										"	) TYPE=MyISAM COMMENT='OoW CoA'; ";

	// Print header
	echo '
		<center>
	
		<strong>
		<font size="+2" color="#33FF00"><a>
		  Updating database to latest version (v3.4.0)
		</a></font>
		<br />
		</strong>

		<hr />
	';

	// Add the "LastOn", "FlowingThought" and "Epic" Field to the "Characters" table
	AddFieldToTable( "LastOn",			"Characters", "date NOT NULL default '0000-00-00'",	"OldMember" );
	AddFieldToTable( "FlowingThought",	"Characters", "smallint(2) NOT NULL default '0'",	"GLP" );
	AddFieldToTable( "Epic",			"Characters", "tinyint(1) NOT NULL default '0'",	"FlowingThought" );

	// Modify the "Race" Field   (adding an Empty '' tag to the enum)
	ModifyFieldInTable( "Race",		"Characters",	"enum('','Barbarian','Dark Elf','Dwarf','Erudite','Froglok','Gnome','Half Elf','Halfling','High Elf','Human','Iksar','Ogre','Troll','Vah Shir','Wood Elf') NOT NULL default ''" );
	// Modify the "Gender" Field (adding an Empty '' tag to the enum)
	ModifyFieldInTable( "Gender",	"Characters",	"enum('','Female','Male') NOT NULL default ''" );
	// Modify the "GLP" Field    (raise width from 2 to 3 positions)
	ModifyFieldInTable( "GLP",		"Characters",	"tinyint(3) NOT NULL default '0'" );


	////////////////////
	// Version 2.0.0  //
	////////////////////
	// Create the PoP_Tier_1_Flags table
	CreateTable( "PoP_Tier_1_Flags", $strCreatePoP_Tier_1_FlagsQuery ); 
	// Create the PoP_Tier_2_Flags table
	CreateTable( "PoP_Tier_2_Flags", $strCreatePoP_Tier_2_FlagsQuery ); 
	// Create the PoP_Tier_3_Flags table
	CreateTable( "PoP_Tier_3_Flags", $strCreatePoP_Tier_3_FlagsQuery ); 
	// Create the PoP_Tier_4_Flags table
	CreateTable( "PoP_Tier_4_Flags", $strCreatePoP_Tier_4_FlagsQuery ); 
	// Create the GoD_Flags table
	CreateTable( "GoD_Flags", $strCreateGoD_FlagsQuery ); 

	// Convert old Flags to PoP_Flags
	ConvertOldFlagsToPoPFlags();

	// Drop the old Flag fields
	DropOldFlagFields();

	// Rename the KeysAndFlag table to Keys
	RenameKeysAndFlagToKeys();
	// Rename the BoT_Flag table to PoS_Askr_Quest
	RenameBoT_FlagToPoS_Askr_Quest();


	////////////////////
	// Version 2.1.0  //
	////////////////////
	// Add the "Research" and "Tinkering" Field to the "TradeSkills" table
	AddFieldToTable( "Research",	"TradeSkills", "smallint(3) NOT NULL default '0'",	"Pottery" );
	AddFieldToTable( "Tinkering",	"TradeSkills", "smallint(3) NOT NULL default '0'",	"Tailoring" );


	////////////////////
	// Version 2.2.4  //
	////////////////////
	// Modify the EMail field
	ModifyFieldInTable( "EMailAddress",	"Users",	"varchar(100) NOT NULL default ''" );


	////////////////////
	// Version 3.0.0  //
	////////////////////
	// Create the DoN_Flags table
	CreateTable( "DoN_Flags", $strCreateDoN_FlagsQuery ); 

	// Add the "PoTime_Time_Phased_Quintessence" to the "PoP_Tier4_Flags" table
	AddFieldToTable( "PoTime_Time_Phased_Quintessence",	"PoP_Tier_4_Flags", "tinyint(1) NOT NULL default '0'",	"PoEarthb_The_Rathe" );

	// Add the HP, Mana, AC, Regen, 
	AddFieldToTable( "HP",		"Characters", "smallint(5) NOT NULL default '0'",	"GLP" );
	AddFieldToTable( "Mana",	"Characters", "smallint(5) NOT NULL default '0'",	"HP" );
	AddFieldToTable( "AC",		"Characters", "smallint(4) NOT NULL default '0'",	"Mana" );
	AddFieldToTable( "Regen",	"Characters", "smallint(2) NOT NULL default '0'",	"FlowingThought" );
	AddFieldToTable( "Atk",		"Characters", "smallint(3) NOT NULL default '0'",	"Regen" );
	AddFieldToTable( "Str",		"Characters", "smallint(3) NOT NULL default '0'",	"Atk" );
	AddFieldToTable( "Sta",		"Characters", "smallint(3) NOT NULL default '0'",	"Str" );
	AddFieldToTable( "Agi",		"Characters", "smallint(3) NOT NULL default '0'",	"Sta" );
	AddFieldToTable( "Dex",		"Characters", "smallint(3) NOT NULL default '0'",	"Agi" );
	AddFieldToTable( "Wis",		"Characters", "smallint(3) NOT NULL default '0'",	"Dex" );
	AddFieldToTable( "Int",		"Characters", "smallint(3) NOT NULL default '0'",	"Wis" );
	AddFieldToTable( "Cha",		"Characters", "smallint(3) NOT NULL default '0'",	"Int" );
	AddFieldToTable( "PR",		"Characters", "smallint(3) NOT NULL default '0'",	"Cha" );
	AddFieldToTable( "MR",		"Characters", "smallint(3) NOT NULL default '0'",	"PR" );
	AddFieldToTable( "DR",		"Characters", "smallint(3) NOT NULL default '0'",	"MR" );
	AddFieldToTable( "FR",		"Characters", "smallint(3) NOT NULL default '0'",	"DR" );
	AddFieldToTable( "CR",		"Characters", "smallint(3) NOT NULL default '0'",	"FR" );


	////////////////////
	// Version 3.0.5  //
	////////////////////
	// Modify the "AA" Field    (raise width from 3 to 4 positions)
	ModifyFieldInTable( "AA", "Characters", "smallint(4) NOT NULL default '0'" );


	////////////////////
	// Version 3.0.7  //
	////////////////////
	// Add the CoD Carprin Event to PoP Tier2 Flags
	AddFieldToTable( "CoD_Carprin_Event",	"PoP_Tier_2_Flags", "tinyint(1) NOT NULL default '0'",	"PoV_AerinDar" );


	////////////////////
	// Version 3.1.1  //
	////////////////////
	// Modify the "GLP" Field    (from tinyint to smallint)
	ModifyFieldInTable( "GLP",		"Characters",	"smallint(3) NOT NULL default '0'" );


	////////////////////
	// Version 3.2.0  //
	////////////////////
	// Create the DoD_Spells table
	CreateTable( "DoD_Spells", $strCreateDoD_SpellsQuery ); 


	////////////////////
	// Version 3.4.0  //
	////////////////////
	// Create the OoW_CoA table
	CreateTable( "OoW_CoA", $strCreateOoW_CoAQuery ); 

	// Add Keeper of the Altar to GoD Flags
	AddFieldToTable( "Keeper_of_the_Altar",			"GoD_Flags", "tinyint(1) NOT NULL default '0'",	"Vrex_Barxt_Qurat" );
	// Add Ixt Hsek Syat to GoD Flags
	AddFieldToTable( "Ixt_Hsek_Syat",				"GoD_Flags", "tinyint(1) NOT NULL default '0'",	"Noqufiel_in_Inktuta" );
	// Add High Priest Nkosi Bakari to GoD Flags
	AddFieldToTable( "High_Priest_Nkosi_Bakari",	"GoD_Flags", "tinyint(1) NOT NULL default '0'",	"Ixt_Hsek_Syat" );


	////////////////////
	// Done           //
	////////////////////
	echo '
		<br />
		<font color="#FF3333"><a>
		  Script completed.<br />
		  Make sure you move the update_tables.php file out of your EQRoster dir.
		</a></font>
		
		</center>
	';
}



// Add a Field to a Table using a FieldDefinition 
function AddFieldToTable( $strField, $strTable, $strFieldDefinition, $strAfterField )
{
	// Define the query
	$strUpdateQuery	= "ALTER TABLE `$strTable` ADD `$strField` $strFieldDefinition";

	// Add the AFTER tag
	if( ( isset( $strAfterField ) ) &&
		( !empty($strAfterField) ) )
	{
		$strUpdateQuery	.= " AFTER `$strAfterField`";
	}

	// Connect to the database
	$nLinkID	= DBConnect();

	// Update the characters
	$nResult	= mysql_query( $strUpdateQuery, $nLinkID );
	// Check if the update was succesfull
	if( $nResult == 1 )
	{
		echo '
			<font size="+1" color="#33FF00"><a>
			  The "' . $strField . '" Field has been added to the "' . $strTable . '" Table...
			</a></font>
			<br />
		';
	}
	else
	{
		if( mysql_errno() == 1060 )
		{
			echo '
				<font size="+1" color="#C0C0FF"><a>
				  The "' . $strField . '" Field was already present in the "' . $strTable . '" Table...
				</a></font>
				<br />
			';
		}
		else if( ( mysql_errno() == 1044 ) ||
				 ( mysql_errno() == 1142 ) )
		{
			// Show the User Permissions Error
			ShowUserPermissionsError();
		}
		else
		{
			echo '
				<font size="+1" color="#FF3300"><a>
				  The "' . $strField . '" Field could not be added to the "' . $strTable . '" Table!<br />
				  Query used: ' . $strUpdateQuery . '<br />
				  (' . mysql_errno() . ') ' . mysql_error() . '
				</a></font>
				<br />
			';
		}
	}

	// Close the connection
	DBDisconnect( $nLinkID );

	return;
}



// Modify a Field in a Table to FieldDefinition
function ModifyFieldInTable( $strField, $strTable, $strFieldDefinition )
{
	// Declare variables
	$strUpdateQuery	= "ALTER TABLE `$strTable` MODIFY `$strField` $strFieldDefinition ";
 
	// Connect to the database
	$nLinkID	= DBConnect();

	// Update the characters
	$nResult	= mysql_query( $strUpdateQuery, $nLinkID );
	// Check if the update was succesfull
	if( $nResult == 1 )
	{
		echo '
			<font size="+1" color="#33FF00"><a>
			  The Field "' . $strField . '" has been succesfully modified...
			</a></font>
			<br />
		';
	}
	else
	{
		if( ( mysql_errno() == 1044 ) ||
			( mysql_errno() == 1142 ) )
		{
			// Show the User Permissions Error
			ShowUserPermissionsError();
		}
		else
		{
			echo '
				<font size="+1" color="#FF3300"><a>
				  The Field "' . $strField . '" could not be modified!<br />
				  Query used: "' . $strUpdateQuery . '<br />
				  (' . mysql_errno() . ') ' . mysql_error() . '
				</a></font>
				<br />
			';
		}
	}

	// Close the connection
	DBDisconnect( $nLinkID );

	return;
}



// Create a table using a query
function CreateTable( $strTable, $strCreateQuery )
{
	// Connect to the database
	$nLinkID	= DBConnect();

	// Update the characters
	$nResult	= mysql_query( $strCreateQuery, $nLinkID );
	// Check if the query was succesfull
	if( $nResult == 1 )
	{
		echo '
			<font size="+1" color="#33FF00"><a>
			  The table "' . $strTable . '" has been succesfully created...
			</a></font>
			<br />
		';
	}
	else
	{
		if( mysql_errno() == 1050 )
		{
			echo '
				<font size="+1" color="#C0C0FF"><a>
				  The "' . $strTable . '" Table was already present...
				</a></font>
				<br />
			';
		}
		else if( ( mysql_errno() == 1044 ) ||
				 ( mysql_errno() == 1142 ) )
		{
			// Show the User Permissions Error
			ShowUserPermissionsError();
		}
		else
		{
			echo '
				<font size="+1" color="#FF3300"><a>
				  The table "' . $strTable . '" could not be created...<br />
				  ' . $strCreateQuery . '<br />
				  (' . mysql_errno() . ') ' . mysql_error() . '
				</a></font>
				<br />
			';
		}
	}

	// Close the connection
	DBDisconnect( $nLinkID );

	return;
}



// Convert old Flags to PoP_Flags
function ConvertOldFlagsToPoPFlags()
{
	// Declare variables
	$strSelectQuery	= "SELECT CharID, BoT_Flag, PoJ_Trial_Flag, PoT_Flag \n" .
					  "FROM KeysAndFlags \n" .
					  "WHERE	BoT_Flag > 0		OR \n" .
					  "			PoJ_Trial_Flag > 0	OR \n" .
					  "			PoT_Flag > 0		   \n";

	// Connect to the database
	$nLinkID	= DBConnect();

	// Retrieve all the records
	$nResult	= mysql_query( $strSelectQuery, $nLinkID );

	// Check if the table was (probably) already renamed
	if( ( mysql_errno() == 1054 ) ||
		( mysql_errno() == 1146 ) )
	{
		echo '
			<font size="+1" color="#C0C0FF"><a>
			  The old flags had already been imported into the PoP tables...
			</a></font>
			<br />
		';
	}
	else
	{	
		// Show the records one by one
	    while( $aResult	= mysql_fetch_row( $nResult ) ) 
		{
			// Retrieve the variables out of the array
			$nCharID			= $aResult[0];
			$nPoS_Askr_Quest	= $aResult[1];
			$nAny_PoJ_Trial		= $aResult[2];
			$nPoI_Behemoth		= $aResult[3];
			
			// Create the insert statement for PoP_Tier_1_Flags
			$strInsertQuery1	= "INSERT INTO PoP_Tier_1_Flags \n" .
								  "(CharID, Any_PoJ_Trial, PoI_Behemoth) \n" .
								  "VALUES ($nCharID, '$nAny_PoJ_Trial', '$nPoI_Behemoth')";
			// Insert the record
			$nInsertResult1	= mysql_query( $strInsertQuery1, $nLinkID );
	
			// Create the insert statement for PoP_Tier_2_Flags
			$strInsertQuery2	= "INSERT INTO PoP_Tier_2_Flags \n" .
								  "(CharID, PoS_Askr_Quest) \n" .
								  "VALUES ($nCharID, '$nPoS_Askr_Quest')";
			// Insert the record
			$nInsertResult2	= mysql_query( $strInsertQuery2, $nLinkID );
		}
	
		echo '
			<font size="+1" color="#33FF00"><a>
			  All old flags have been succesfully imported into the PoP tables...
			</a></font>
			<br />
		';
	}

	// Close the connection
	DBDisconnect( $nLinkID );
}



// Drop the old Flag fields
function DropOldFlagFields()
{
	// Declare variables
	$strDropQuery	= "ALTER TABLE `KeysAndFlags` DROP BoT_Flag, DROP PoJ_Trial_Flag, DROP PoT_Flag";
 
	// Connect to the database
	$nLinkID	= DBConnect();

	// Update the characters
	$nResult	= mysql_query( $strDropQuery, $nLinkID );
	// Check if the update was succesfull
	if( $nResult == 1 )
	{
		echo '
			<font size="+1" color="#33FF00"><a>
			  The old Flag fields (BoT_Flag, PoJ_Trial_Flag and PoT_Flag) have been dropped from the "KeysAndFlags" Table...
			</a></font>
			<br />
		';
	}
	else
	{
		if( ( mysql_errno() == 1091 ) ||
			( mysql_errno() == 1146 ) )
		{
			echo '
				<font size="+1" color="#C0C0FF"><a>
				  The old Flag fields (BoT_Flag, PoJ_Trial_Flag and PoT_Flag) had already been dropped from the "KeysAndFlags" Table...
				</a></font>
				<br />
			';
		}
		else if( ( mysql_errno() == 1044 ) ||
				 ( mysql_errno() == 1142 ) )
		{
			// Show the User Permissions Error
			ShowUserPermissionsError();
		}
		else
		{
			echo '
				<font size="+1" color="#FF3300"><a>
				  The old Flag fields (BoT_Flag, PoJ_Trial_Flag and PoT_Flag) could not be dropped from the "KeysAndFlags" Table!<br />
				  (' . mysql_errno() . ') ' . mysql_error() . '
				</a></font>
				<br />
			';
		}
	}

	// Close the connection
	DBDisconnect( $nLinkID );

	return;
}



// Rename the KeysAndFlag table to Keys
function RenameKeysAndFlagToKeys()
{
	// Declare variables
	$strSelectQuery	= "SELECT COUNT(*) FROM `Keys`";
	$strRenameQuery	= "RENAME TABLE `KeysAndFlags` TO `Keys`";
 
	// Connect to the database
	$nLinkID	= DBConnect();

	// Check if the table has already been renamed
	$nResult	= mysql_query( $strSelectQuery, $nLinkID );
	if( mysql_errno() != 1146 )
	{
		echo '
			<font size="+1" color="#C0C0FF"><a>
			  The "KeysAndFlags" Table had already been renamed to "Keys"...
			</a></font>
			<br />
		';
	}
	else
	{
		// Update the characters
		$nResult	= mysql_query( $strRenameQuery, $nLinkID );
		// Check if the update was succesfull
		if( $nResult == 1 )
		{
			echo '
				<font size="+1" color="#33FF00"><a>
				  The "KeysAndFlags" Table has been renamed to "Keys"...
				</a></font>
				<br />
			';
		}
		else
		{
			if( mysql_errno() == 1050 )
			{
				echo '
					<font size="+1" color="#C0C0FF"><a>
					  The "KeysAndFlags" Table had already been renamed to "Keys"...
					</a></font>
					<br />
				';
			}
			else if( ( mysql_errno() == 1044 ) ||
					 ( mysql_errno() == 1142 ) )
			{
				echo '
					<font size="+1" color="#FF3300"><a>
					  The "KeysAndFlags" Table could not be renamed to "Keys"!
					</a></font>
					<br />
				';
				// Show the User Permissions Error
				ShowUserPermissionsError();
			}
			else
			{
				echo '
					<font size="+1" color="#FF3300"><a>
					  The "KeysAndFlags" Table could not be renamed to "Keys"!<br />
					  (' . mysql_errno() . ') ' . mysql_error() . '
					</a></font>
					<br />
				';
			}
		}
	}

	// Close the connection
	DBDisconnect( $nLinkID );

	return;
}



// Rename the BoT_Flag table to PoS_Askr_Quest
function RenameBoT_FlagToPoS_Askr_Quest()
{
	// Declare variables
	$strSelectQuery	= "SELECT COUNT(*) FROM `PoS_Askr_Quest`";
	$strRenameQuery	= "RENAME TABLE `BoT_Flag` TO `PoS_Askr_Quest`";
 
	// Connect to the database
	$nLinkID	= DBConnect();

	// Check if the table has already been renamed
	$nResult	= mysql_query( $strSelectQuery, $nLinkID );
	if( mysql_errno() != 1146 )
	{
		echo '
			<font size="+1" color="#C0C0FF"><a>
			  The "BoT_Flag" Table had already been renamed to "PoS_Askr_Quest"...
			</a></font>
			<br />
		';
	}
	else
	{
		// Update the characters
		$nResult	= mysql_query( $strRenameQuery, $nLinkID );
		// Check if the update was succesfull
		if( $nResult == 1 )
		{
			echo '
				<font size="+1" color="#33FF00"><a>
				  The "BoT_Flag" Table has been renamed to "PoS_Askr_Quest"...
				</a></font>
				<br />
			';
		}
		else
		{
			if( mysql_errno() == 1050 )
			{
				echo '
					<font size="+1" color="#C0C0FF"><a>
					  The "BoT_Flag" Table had already been renamed to "PoS_Askr_Quest"...
					</a></font>
					<br />
				';
			}
			else if( ( mysql_errno() == 1044 ) ||
					 ( mysql_errno() == 1142 ) )
			{
				echo '
					<font size="+1" color="#FF3300"><a>
					  The "BoT_Flag" Table could not be renamed to "PoS_Askr_Quest"!
					</a></font>
					<br />
				';
				// Show the User Permissions Error
				ShowUserPermissionsError();
			}
			else
			{
				echo '
					<font size="+1" color="#FF3300"><a>
					  The "BoT_Flag" Table could not be renamed to "PoS_Askr_Quest"!<br />
					  (' . mysql_errno() . ') ' . mysql_error() . '
					</a></font>
					<br />
				';
			}
		}
	}

	// Close the connection
	DBDisconnect( $nLinkID );

	return;
}



// Show the User Permissions Error
function ShowUserPermissionsError()
{
	  
	echo '
	<font size="+1" color="#FF3300"><a>
	  (' . mysql_errno() . ') ' . mysql_error() . '
	</a></font>
	<br />
	<br />
	<font color="#CCCCFF"><a>
	  Make sure the user has the following Database privileges:<br />
	  Data: SELECT, INSERT, UPDATE<br />
	  Structure: CREATE, ALTER, DROP*<br />
	  (*DROP is only needed to rename tables, make sure you disable it after running this script)
	</a></font>
	<br />
	';
	
	// Abort the update
	exit();
}

?>

</body>
</html>
