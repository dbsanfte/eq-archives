         Action Required V1.4 Notes and Installation Instructions
         

Introduction
------------

Action Required allows you to post single line reminder messages to yourself
(or anyone else) via electronic mail.  It sends a simple mail message with a
subject line containing text you provide to any user you designate, via an
SMTP server.  You can specify a number of options to customize the program
for your needs.

Action Required is a Win32 program which has been tested on Windows NT 3.51,
Windoes NT 4.0, and Windows 95.  It also runs on Win16 with Win32s, if there
is a TCP/IP stack that works with WinSock.  Action Required was written in
Microsoft Visual C++, V4.0.

The latest version of Action Required may be found at:

	http://www.teleport.com/~rbk/software/


Installation
------------

The .zip file should contain:

    ar.exe:      the executable
    ar.hlp:      the help file
    ReadMe.txt:  this file

Make a directory and copy ar.exe, ar.hlp, and ReadMe.txt to the directory.

The first time you run the program you'll find yourself staring at the
preferences dialog.  Click on the "Help" button for assistance in filling it
out.

Version History
---------------

Version 1.4 (12/28/96) adds automatic expansion of file names into full, long
name, case preserved form.

Version 1.3 (2/10/96) adds always on top, save dialog position, drag & drop
from file manager or explorer, and a bit of cleanup

Acknowledgments and Distribution Rights
---------------------------------------

Action Required was written by Bob Beck (rbk@teleport.com, RDBeck@aol.com,
71674.106@compuserve.com).  The binary of the program has been placed in the
public domain.  Please distribute it as widely as you like, as long as this
file is sent with it.

The SMTP client code in Action Required is based (with modification) on the
public domain source code in blat11.zip.  Thanks to blat authors Mark Neal
(mjn@aber.ac.uk) and Pedro Mendes (prm@aber.ac.uk) for making this code
available.  The modifications have been returned to the authors for possible
inclusion in a future version of blat.

I hope you find this program as useful as I do.  Please feel free to send
comments, complaints, feature requests, etc.


Bob Beck
rbk@teleport.com
CIS: 71674,106
AOL: RDBeck
December 28, 1996
