UO Map 1.2 Readme
-----------------------------------------------------------

Table of Contents

	1) New Stuff in 1.2
	2) MapHack
	3) UO Map Commands
	4) How Locations Work
	5) How Destinations Work
	6) How to Calibrate UO Map yourself
	7) Credits
	8) The End
	

------------------ New Stuff in 1.1 -----------------------

Changes in this version:

	- Network support!  See your friend's locations in real time
          with UO Map Server (downloaded separately)
		

------------------ MapHack --------------------------------

This archive does not include the map files needed to run UO Map.
They must be created with maphack.exe before you can run UO Map.
You cannot be running UO while MapHack is creating the map files.

Instructions for MapHack:
	Run MapHack.exe

	By default, only the low-resolution maps are extracted,
	and they require about 8 megs of disk space.

	You can choose which maps to extract by checking or
	unchecking them.  Note, the high resolution map requires
	an additional 25 megs of disk space, but won't take
	any additional time to create (it must calculate the
	large map to create the small maps; checking the boxes
	just determines whether it saves it or not)

	Ignore the 'advanced options' button, none of them work currently.


------------------ UO Map Commands ------------------------


Simple commands:
  When the program starts, it doesn't read your coords from UO.
  You have to tell it to do these things from the file
  menu.  You can also set it to automatically attempt to
  attach to UO when it starts up (from the options window).
 
  You can pan around by right clicking on the map, and zoom in and out
  with the + and - keys (or using the zoom menu).

  

More advanced stuff:
  The name of the icon used to mark your location is changeable from the
  options menu.  It should read 'images/x.ico' initially.  You can either
  edit x.ico, or make a new icon, and change this option to the new file.
  UO Map only supports 16x16, 256 color windows icons.



Here's a description of what all the menu commands do:

File
   Attach to UO:  
                  Attempts to open the UO client memory space,
                  If successful, it starts automatically reading
                  your location coordinates.  (as long as the
		  calibration is set right)

   Connect to Default Server:
		  Attempts to connect to the default UO Map Server.

   Connect to...:
		  Prompts you for the ip address and port number of
		  a UO Map Server to connect to.

   Transfer:
		  Lets you transfer your icon to the server.  Then other people
		  on the server can download them by right clicking on your
		  name in the player list window.
    
   About:         About box

   Exit:          Hmmm.. don't know what this does yet.



Options
    Sextant Coords: Sets the program to display your location in sextant
		    format in the title bar.

    Where Coords:   Sets the program to display your location in .where
		    format in the title bar.

    Autocenter Mode: When reading coordinates from the UO client, this 
		     mode automatically centers your map around your 
		     current location.

    Stationary Mode: Keeps the map stationary around the point you last
		     right clicked, and the location markers move.

    Edgecenter Mode: Re-centers the map on your current location when you
		     get near the edge.

    Always on Top:   When set, the uomap window will stay on top of most other
                     windows.

    Options:         Opens up the options window.


    
Zoom menu:  pretty self explanatory I should hope.  Zoom 1 is a 1:1 pixel 
	    to tile ratio (every pixel corresponds to 1 ultima online tile).
	    Zoom 2 is one pixel for every 2x2 block of tiles, and so on.


View menu:
    Display Locations: Toggles the display of location markers on the map.
		       If you have the location list window open, then they
	 	       are automatically displayed.

    Display Location Names: When set, labels each location on the map.

    Popup Descriptions: Displays the 'Notes' text for locations when you hold
		        your mouse cursor over the icon.

    Locations Window: opens up the location list window

    Player List Window: opens up the player list window


Track menu:
    Broadcast My Coords: toggle the broadcast of your coordinates to the UO Map
			 Server when you are connected.  Note that it actually
			 sends the coordinates of your marker, so if you aren't
			 attached to UO, you can change your coordinates by clicking
			 around.  You can change how often they are sent in the
			 options window.

    Request Coords: toggle the request of other players coordinates from the UO Map
		    Server.  This only applies to those players you have marked
		    as 'Track by Request'.  You can change how often the request
		    is sent in the options window

    Track None: Turn off tracking for all players.

    Track All Request: Track all players by request

    Track All Realtime:  Track all players in realtime.  When a player is set to
			 Track by Realtime, the server will send you his
			 coordinates every time he broadcasts them.

    <Players>:  When connected to a UO Map Server, you will see the names of other players
		on this menu.  Selecting them will pop up a menu allowing you to change
		their tracking state.

------------------ How Locations Work ---------------------

This is really in-depth.  If you want, you can just fool around with it,
rather than reading through all this.  I tried to make it as intuitive
as possible.  E-mail me if you have any suggestions.

Locations have three properties: a name, an icon, and a coordinate.

The locations window displays a list of the locations
marked, grouped under headings (which appear in bold).


Double clicking on something will set its show/hide status.
If a location or heading is hidden, its icon in the list is
crossed out, it is not shown on the map, and no locations
inside it (if it is a heading) are shown.

Right clicking on a location or heading will give you 
a menu of things you can do to it. 

I.E. if you click on the Dungeons heading, you should get a menu
that looks like this:

 Dungeons		<-- Checked if shown, unchecked if hidden
 ----------
 Show All		<-- Shows everything in 'Dungeons'
 Hide All		<-- Hides everything in 'Dungeons'
 ----------
 New Location		<-- Adds a new location under Dungeons
 New Heading		<-- Adds a new heading under Dungeons
 Insert New File	<-- Adds a new heading under Dungeons, to be stored in a file
 ----------
 Delete			<-- Deletes 'Dungeons' and everything in it
 ----------
 Properties		<-- Gives you a properties window


Similarly, clicking on a location, like the "Covetous" (under Dungeons),
will give you a menu like this:

 Covetous		<-- Again, checked if shown, unchecked if not
 ----------
 Center on		<-- Centers the map on 'Covetous'
 Set to current pos.	<-- Sets 'Covetous' to your location in UO
 ----------
 New Location		<-- Adds a new location above 'Covetous'
 New Heading		<-- Adds a new heading above 'Covetous'
 Insert New File	<-- Adds a new file-heading above 'Covetous'
 ----------
 Delete			<-- Deletes 'Covetous'
 ----------
 Properties		<-- Gives you a properties window


The properties window contains several things:

First there is an icon button, which can be clicked to change that
location or heading's icon.  Next to the icon button is the
name or label of the location. (i.e. "Dungeons" or "Covetous")

Under that is the file name.  This is only used for file-headings,
and gives the name of the file under which everything in the heading
is stored.

Next is the x and y coordinates of the location (not used for headings).



To load an existing file-heading, just Insert a New File,
goto the properties, change it's File: to the existing file,
and hit OK.  It should ask you whether you want to load
the file, or overwrite (clear) it.


If you want to change the main location file (default is lists.txt),
goto the options window; there you can also change the size of the
font used to display location names on the map.


And, last but not least, you can rearrange locations and headings
by dragging and dropping them in the list.  The default action is
to 'insert above' on locations, and 'drop into' on headings.  If
you want to 'insert above' on a heading, hold down shift.
You can also drag and drop the locations onto the map, to place them
in a new position.



------------------ How Destinations Work ------------------

Destinations are to help you find your way to a certain location or coordinate.
To activate them, hit 'd'.  (Make sure the map is in the foreground)

This should bring up the 'Set Destination Window', which contains an input box,
a 'Visible' check box, and three buttons.

To set a destination, simply enter it into the input box and hit enter.
You can enter coordinates (2498 914), or the name of a location 
(covetous), or even a partial name (covet).  This highlights the
destination, and shows you the general direction it is in (follow the dotted
line).

Checking on the 'Visible' check box will set the destination's visibility.
Use this to get rid of it when you don't need it anymore.

Clicking on the "Copy to Marker List" will copy the current destination
to your list of location markers.  Note that anything you enter doesn't
become the current destination until after you hit OK.


------------------ How to Calibrate -----------------------

In order for UO Map to figure out where you are standing in UO, it needs to
know exactly where to find the coordinates in the Ultima Online client's
memory space.  Unfortunately, the memory location of the coordinates changes
almost every time Origin releases a new patch to Ultima Online.  But you
can now quickly get the latest calibration numbers yourself.  

It is easy to tell if your calibration is out of date.  If you are logged into
a character in UO, but UO Map shows your location to be the upper left corner of
the map, then your calibration is probably out of whack.

To calibrate, UO Map must be 'attached' to the Ultima Online client.
And, you must be able to have your character in UO stand a spot
that you know the exact coordinates for.  The easiest way to do this
is to drop a location marker somewhere, like the corner of a specific
building.  Unfortunately, you can only do this if you already have
it calibrated correctly.. therefore, I have included several calibration
locations that are ready to use.

Just open up the location properties box, have your character stand
at the exact location it describes, and click on the 'calibrate' button
(under the 'calibration' tab).

If all else fails, you can still go to http://www.f-ckheads.com/uomap 
or http://www.f-ckheads.com/tom to ask someone for the latest calibration,
or for help in setting it up to get them yourself.


------------------ Credits --------------------------------

Name			Nick		Contribution
--------------          ----------      -----------------------------

Chris Tchou		Tesla		Programming just about everything
					Some of the icons and location lists
					    
Patrick Nelson		Ravalier	Porting MapHack to MFC and fixing VC++

Michael Cornelius	Newton Dragon	Making MapHack alot nicer

Ben Czerwinski		Kurva		Initial concept, suggestions, webpage updates

Bruce Lucas		Brucifer	Initial concept, suggestions, webpage updates

Rob Lockhart		Trahkcol	Suggestions, testing, webpage animation

			Xylothan	Initial concept, suggestions, UNIX server

			Chankiki	Nice location icons, town location lists, suggestions, testing

Allen Childress		Falcon		Spawn map location list, suggestions, testing			

Yanick Girouard				Nice location icons, suggestions, testing

Chanur Silvarian			Town location lists

David Loeser				Suggestions, testing

Peter Templeton				Suggestions

Blaine Curtis				Suggestions, testing

			Clark Kent	Suggestions

Gianmarco Giovanelli			Suggestions, testing

James Shields				Suggestions

Cedric Reinartz				Suggestions

And all the others I forgot..


------------------ The End


I think that's it.  As always, if anything is really confusing or you have a suggestion
or whatever, talk to me on irc (beyondirc, try the server babylon.beyondirc.net,
my nick is Tesla), or send mail to tesla@f-ckheads.com


