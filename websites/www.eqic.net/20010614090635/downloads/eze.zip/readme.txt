EQ Zone Explorer (EZE.exe)
 
 
Notice:
I have recently discovered that there are, at least, seven (sigh) different versions of the tutorial.exe program floating around.  This explains why the program (Eze.exe) does not properly load the selected zone for some users.  Each different version of the tutorial.exe will most likely have a different load zone offset.  Upon finding the new offset for a particular version, there is a chance that the zones will still be unable to load if that version is radically different. 
As different versions of the tutorial.exe program are made available to me, I will find their offsets and test them.  Versions that are verified to work will be listed below in green, and versions that did not work, listed in red:

Size (in KB)	Last modified date	Offset
-----------------------------------------------
1,800		02/16/99 11:03 PM	1669008
1,802		03/17/99 07:23 PM	1669500 
1,802		03/19/99 03:23 PM 	1669500
1,802		03/28/99 01:34 PM 	1669500
1,802		04/01/99 10:43 AM	1669500
1,802 		07/16/99 07:28 PM 	1669500
1,802 		10/03/99 10:02 AM 	1669500


Description:
EQ Zone Explorer (EZE.exe) is a freeware program which allows you to explore EverQuest zones, offline. 
Unzip the files in a separate directory.  DO NOT place them in your EverQuest directory.


Limitations:
EQ Zone Explorer (EZE.exe) requires access to the EverQuest Tutorial program (tutorial.exe).  There are a few limitations to be aware of, regarding the Tutorial:

* You are restricted to using the tutorial dummy character, Soandso, who lacks infavision and can only walk. 
* None of the buttons work in the tutorial (i.e. Abilities, Combat, Options etc.). 
* The tutorial runs in 640x480 resolution mode. 
* The tutorial will start you in the position that is set for the tutorial zone, regardless of what zone you explore. Therefore, your starting point might seems strange.  For example, the tutorial starting point equates to the top of Castle Mistmoore in the mistmoore zone. 
* The tutorial will only display the tutorial NPCs and not the actual zone's NPCs. The tutorial NPCs retain their coordinates from the tutorial, so they will appear in strange locations in the zone you're exploring. 

Limitations aside, you can walk freely about the level and explore every nook and cranny, finding any hidden passages along the way.


Technical Info:
The EQ Zone Explorer program (EZE.exe) was developed using Borland's Delphi 4 on the Windows 98 SE platform. 

The program uses an initialization file, EZE.ini, to store the following information:

* The location of your EverQuest Tutorial program, tutorial.exe.  Usually "C:\Program Files\EverQuest\tutorial.exe". 
* The load zone offset.  Usually 1669500 or 1669008. 
* The complete listing of zone names and zone internal names.  For example: "Castle Mistmoore=mistmoore".  The first part being the zone name and the second part being the internal name. 

Feel free to change the location of the Tutorial program if it does not match the location on your hard drive.  The load zone offset should only be changed if 989 Studios changes their Tutorial program.  Feel free to append new zones to the zone section as they become available from 989 Studios.  You will recognize a zone because each zone has six files associated with it (*.s3d, *.xmi, *_chr.s3d, *_obj.s3d, *_sndbnk.eff, and *_sounds.eff) in the EverQuest directory.  So, for Castle Mistmoore, the corresponding files are: mistmoore.s3d, mistmoore.xmi, mistmoore_chr.s3d, mistmoore_obj.s3d, mistmoore_sndbnk.eff and mistmoore_sounds.eff. Therefore, the internal name for the Castle Mistmoore zone is, mistmoore.
The program creates a temporary file, copies the Tutorial program (tutorial.exe) to the newly created temporary file, modifies the temporary file and runs it.  The EverQuest Tutorial program is never modified directly; only the temporary copies of it are.  All temporary copies of the Tutorial program are prefixed with "EZE".  An example of a temporary copy of the Tutorial program would be something like: "Eze3022.exe".  All temporary copies created in the EverQuest directory are deleted each time EZE.exe runs.


Contact:
E-Mail: eqzoneexplorer@hotmail.com
Web Page: http://home.tampabay.rr.com/estembler/tristram/eze.htm


EQ Zone Explorer (EZE.exe) is Freeware.  Distribute freely.
EverQuest is a registered trademark of Verant Interactive, Inc.



