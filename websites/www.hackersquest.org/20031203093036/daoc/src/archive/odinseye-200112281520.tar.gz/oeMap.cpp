/*
 * Copyright 2001 Slicer/HackersQuest (slicer@hackersquest.org)
 *
 * This file is part of Odin's Eye.
 *
 * Odin's Eye is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Odin's Eye is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 */


#include "oeMap.h"
#include "oeMob.h"
#include <math.h>
#include <GL/glut.h>
#include <qaction.h>
#include <qinputdialog.h>
#include <qregexp.h>
#include <qmessagebox.h>
#include <qtextstream.h>
#include <qslider.h>

oeMap::oeMap(QWidget *parent, const char *name)
 : QGLWidget(QGLFormat(DoubleBuffer|DepthBuffer|Rgba|DirectRendering),parent,name) {
  objsize = 100; 
  range = 8000;
  c = NULL; 
  is_dirty = true; 
  map_load = false; 
  mobDarken = false;
  _lastDarken = 0;
  mi = NULL;
  edit_xofs = edit_yofs = 0;
  map.setAutoDelete(true);
}

oeMap::~oeMap() {
  if (mi)
    delete mi;
}

void oeMap::dirty() {
  if (! is_dirty) { 
    qApp->postEvent(this, new QPaintEvent(QRect(0,0,0,0)));
    is_dirty = true;
  }
}

void oeMap::setConnection(oeConnection *nc) {
  c=nc;
}

void oeMap::setMap(oeMapInfo *m) {
  if (mi)
    delete mi;
 
  mi=m;
  map_load=true;
  editelem = NULL;
  mode_edit = FALSE;
  c->oe->EditMode->setOn(FALSE);
}

void oeMap::setObjectSize(int nsize) {
  objsize=nsize;
  makeObjects(prefs.map_simple);
}

oeMapInfo *oeMap::getMap() {
   return mi;
}

void oeMap::makeObjects(bool simple) {
  int w=objsize;
  int l=w*2;

  glNewList(listTriangle, GL_COMPILE);

  glBegin(GL_TRIANGLES);

  if (simple) {
    glNormal3f(0.0,0.0,1.0);
    glVertex3i(w,-w,0);
    glVertex3i(-w,-w,0);
    glVertex3i(0,l,0);
  } else {
    glNormal3f(l+w,w,l);
    glVertex3i(w,-w,0);
    glVertex3i(0,0,w);
    glVertex3i(0,l,0);

    glNormal3f(-(l+w),w,l);
    glVertex3i(0,0,w);
    glVertex3i(-w,-w,0);
    glVertex3i(0,l,0);

    glNormal3f(0,-w,w);
    glVertex3i(w,-w,0);
    glVertex3i(-w,-w,0);
    glVertex3i(0,0,w);
  }

  glEnd();

  glEndList();

  glNewList(listCircle, GL_COMPILE);
  glBegin(GL_TRIANGLES);
  glNormal3f(0.0,0.0,1.0);

  glVertex3f(w*1.5,-w*1.5,-1);
  glVertex3f(-w*1.5,-w*1.5,-1);
  glVertex3f(0,l*1.5,-1);

  glEnd();
  glEndList();
}


void oeMap::initializeGL() {
  static GLfloat lightpos[4]={0.5,-1.0,1.0,0.0};
  static GLfloat diffuse[4]={0.5,0.5,0.5,1.0};
  static GLfloat ambient[4]={-0.0,-0.0,-0.0,1.0};
  static GLfloat material[4]={0.5,0.5,0.5,1.0};

  if (! format().doubleBuffer())
    qWarning("Single Buffer GL only - Flicker might happen");
  if (! format().depth())
    qWarning("NO GL DEPTH BUFFER - No polygon sorting");
  if (! format().directRendering()) 
    qWarning("No Direct Render - This will be SLOW");

  glClearColor(0.0,0.0,0.0,0.0);
  glEnable(GL_CULL_FACE);

  glShadeModel(GL_FLAT);
  glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);

  glEnable(GL_LIGHTING);
  glEnable(GL_LIGHT0);
  glEnable(GL_COLOR_MATERIAL);
  glEnable(GL_NORMALIZE);
  
  glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
  glLightfv(GL_LIGHT0, GL_POSITION, lightpos);
  glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
  glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
  glMaterialfv(GL_FRONT, GL_AMBIENT, material);
  glMaterialfv(GL_FRONT, GL_DIFFUSE, material);

  listTriangle=glGenLists(1);
  listCircle=glGenLists(1);

  makeObjects(prefs.map_simple);
}

void oeMap::resizeGL(int w, int h) {
  glViewport(0,0,w,h);
}

void oeMap::paintGL() {
  const QPtrDict<oeMob> mobs=c->getMobs();
  QPtrDictIterator<oeMob> mobi(mobs);
  oeMapElement *mapel;
  oeMob *m;
  int quanta, ldif;
  int l;
  double playerhead;
  double playerrad;

  if (map_load) {
    map_load=false;
    if (mi) {
      mapRead();
    }
  }
  
  if (prefs.map_simple) {
    glClear(GL_COLOR_BUFFER_BIT);
    glDisable(GL_BLEND);
  } else {
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    glEnable(GL_BLEND);
  }

  if (prefs.gl_smooth_lines)
    glEnable(GL_LINE_SMOOTH);
  else
    glDisable(GL_LINE_SMOOTH);
  
  if (prefs.gl_smooth_points)
    glEnable(GL_POINT_SMOOTH);
  else
    glDisable(GL_POINT_SMOOTH);

  if (prefs.gl_smooth_polygons)
    glEnable(GL_POLYGON_SMOOTH);
  else
    glDisable(GL_POLYGON_SMOOTH);

  glDisable(GL_LIGHTING);

  playerhead=(c->playerhead * 360.0) / 4096.0;
  playerrad=playerhead * M_PI / 180.0;

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  if (mi)
    glRotatef(mi->getRotate() * 1.0,0.0,0.0,1.0);
  if (prefs.map_rotate)
    glRotatef(180.0+playerhead, 0.0, 0.0, 1.0);
  glRotatef(180.0,1.0,0.0,0.0);

  glOrtho((c->playerx-range) + edit_xofs,(c->playerx+range) + edit_xofs,(c->playery-range) + edit_yofs,(c->playery+range)+edit_yofs,0.0,-25000.0);

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

  glLineWidth(1.0);
  glPointSize(3.0);
  
  for (mapel=map.first(); mapel; mapel=map.next()) {
     mapel->draw(this);
  }

  if (prefs.map_rulers) {
    qglColor( darkGray );
    glLineWidth ( 1.0 );
    glBegin(GL_LINES);
    glVertex3i(c->playerx - range * 2, c->playery, 500);
    glVertex3i(c->playerx + range * 2, c->playery, 500);
    glVertex3i(c->playerx, c->playery - range * 2, 500);
    glVertex3i(c->playerx, c->playery + range * 2, 500);
    glVertex3f(c->playerx * 1.0, c->playery * 1.0, 500.0);
    glVertex3f(c->playerx + cos(playerrad + M_PI_2) * range * 2, c->playery + sin(playerrad + M_PI_2) * range * 2, 500.0);
    glEnd();
  }

  if (! prefs.map_simple ) {
    glEnable(GL_LIGHTING);
    glEnable(GL_DEPTH_TEST);
  } else {
    glDisable(GL_DEPTH_TEST);
  }

  qglColor( white );

  glPushMatrix();
  glTranslated(c->playerx,c->playery,c->playerz);
  objRotate(c->playerhead);
  glCallList(listTriangle);
  glPopMatrix();

  if ((oeTick - _lastDarken) > 250) {
    mobDarken = ! mobDarken;
    _lastDarken = oeTick;
  }

  for(;mobi.current();++mobi) {
    m=mobi.current();

    if (m->isCurrent()) {
      glPushMatrix();
      glTranslated(m->getX(),m->getY(),m->getZ());
      objRotate(m->getHead());

      if (! m->isMob()) {
        if (m->isDead()) {
          setGLColor (m->getColor().dark(160), m->getZ());
        } else if (! m->isInvader()) {
          setGLColor (m->getColor(), m->getZ());
        } else {
          setGLColor ( (mobDarken) ? m->getColor().dark(150) : m->getColor().light(150), m->getZ());
        }
        glCallList(listCircle);
      }

      if (c->playerlevel <= 10)
        quanta=1;
      else if (c->playerlevel <= 20)
        quanta=2;
      else if (c->playerlevel <= 35)
        quanta=3;
      else
        quanta=5;
      ldif=quanta;
      l=m->getLevel();
      if (l <= (c->playerlevel - ldif * 3)) 
        setGLColor(0.5,0.5,0.5,m->getZ());
      else if (l <= (c->playerlevel - ldif * 2))
        setGLColor(0.0,1.0,0.0,m->getZ());
      else if (l <= (c->playerlevel - ldif * 1))
        setGLColor(0.0,0.0,1.0,m->getZ());
      else if (l <= c->playerlevel)
        setGLColor(1.0,1.0,0.0,m->getZ());
      else if (l <= (c->playerlevel + ldif * 1))
        setGLColor(1.0,0.5,0.0,m->getZ());
      else if (l <= (c->playerlevel + ldif * 2))
        setGLColor(1.0,0.0,0.0,m->getZ());
      else 
        setGLColor(1.0,0.0,1.0,m->getZ());

      glCallList(listTriangle);
      glPopMatrix();
    }
    m->stale();
  }

  m=mobs.find((void *)c->selectedid);
  if (m && m->isCurrent()) {
    qglColor( white );
    glLineWidth ( 2.0 );
    glBegin(GL_LINES);
    glVertex3i(c->playerx,c->playery,c->playerz);
    glVertex3i(m->getX(),m->getY(),m->getZ());
    glEnd();
  }

  is_dirty = false;

  glFlush();
}

void oeMap::mousePressEvent(QMouseEvent *e) {
  oeMob *m;
  unsigned int bestid = 0;
  double bestdist=0.0;
  double xdif;
  double ydif;
  GLdouble cx;
  GLdouble cy;
  GLdouble cz;
  double thisdist;
  GLdouble projmatrix[16];
  GLdouble modmatrix[16];
  GLint viewport[4];
  oeMapElement *mapel;

  const QPtrDict<oeMob> mobs=c->getMobs();
  QPtrDictIterator<oeMob> mobi(mobs);

  makeCurrent();

  glGetDoublev(GL_PROJECTION_MATRIX, projmatrix);
  glGetDoublev(GL_MODELVIEW_MATRIX, modmatrix);
  glGetIntegerv(GL_VIEWPORT, viewport);
  
  gluUnProject(e->x(), size().height()-e->y(), 100, modmatrix, projmatrix, viewport, &cx, &cy, &cz);

  if (mode_edit) {
    c->selectID(0);
    editelem=NULL;
    bestdist = -1.0;
    for(mapel=map.first();mapel;mapel=map.next()) {
      thisdist=mapel->clickAt((int)cx,(int)cy,0);
      if ((thisdist != -1.0) && ((bestdist == -1.0) || (thisdist < bestdist))) {
        bestdist=thisdist;
        editelem=mapel;
      }
    }
    if (editelem) {
      QAction *act=(QAction *) c->oe->EditColors->child(QString("color_").append(editelem->getColor()));
      if (act) 
        act->setOn(TRUE);
    }
  } else {
    for(; mobi.current(); ++mobi) {
      m=mobi.current();
      if (m->isCurrent()) {
        xdif=m->getX()-cx;
        ydif=m->getY()-cy;
        thisdist=sqrt(xdif*xdif+ydif*ydif);
        if (! bestid || (thisdist < bestdist)) {
          bestid=m->getInfoID();
          bestdist=thisdist;
        }
      }
    }

    if (bestid) {
      c->selectID(bestid);
    }
  }
}

void oeMap::keyPressEvent(QKeyEvent *e) {
  double angle=0.0;
  double dist=c->oe->MapSlider->value();

  switch( e->key() ) {
    case Qt::Key_Right:
      angle=0.0;
      break;
    case Qt::Key_Up:
      angle=1.0;
      break;
    case Qt::Key_Left:
      angle=2.0;
      break;
    case Qt::Key_Down:
      angle=3.0;
      break;
    case Qt::Key_Home:
      edit_xofs = 0;
      edit_yofs = 0;
      dirty();
      return;
      break;
    case Qt::Key_Next:
      c->oe->MapSlider->setValue((int)(dist * 1.5));
      return;
      break;
    case Qt::Key_Prior:
      c->oe->MapSlider->setValue((int)(dist / 1.5));
      return;
      break;
    default:
      e->ignore();
      return;
      break;
  }
  if (mi)
    angle = (mi->getRotate() / 90.0 ) + angle;
  angle = angle * M_PI / 2.0;
  edit_xofs += (int)(cos(angle)*dist / 2.0);
  edit_yofs -= (int)(sin(angle)*dist / 2.0);
  dirty();
}

void oeMap::setGLColor(double r, double g, double b, int z) {
  double darken;

  if (! prefs.map_fade) {
     glColor4f(r,g,b,1.0);
     return;
  }
  
  darken=abs(c->playerz - z) / 500.0;
  if (darken < 0.60) {
    darken=1.0 - darken;
  } else {
    darken=0.40;
  }

  if (prefs.map_simple) {
    glColor4f(r * darken, g * darken, b * darken, 1.0);
  } else {
    glColor4f(r,g,b,darken);
  }
}

void oeMap::setGLColor(QColor col, int z) {
  setGLColor(col.red() / 255.0, col.green() / 255.0, col.blue() / 255.0, z);
}


void oeMap::objRotate(unsigned int daocheading) {
  double r=daocheading;
  r*=360;
  r/=0x1000;
  glRotatef(r,0.0,0.0,1.0);
}

int oeMap::stringInt(QString s, int sec) {
  bool ok;
  int v=s.section(",",sec,sec).toInt(&ok, 10);
  if (!ok) {
    qWarning("Line %s contains nonnumber %s",(const char *)s, (const char *)s.section(",",sec,sec));
    return 0;
  }
  return v;
}


#define SEC(x) (line.section(",",x,x))

void oeMap::mapRead() {
  QString line;
  QString cmd;
  QString color;
  QString title;
  oeMapElementPoint *mappoint;
  oeMapElementLine *mapline;
  int xadd;
  int yadd;
  int num;
  int x;
  int y;
  int z;
  int i;

  editelem=NULL;

  map.clear();

  QFile f(mi->getName());
  if (! f.open(IO_ReadOnly)) {
    qWarning("Failed to open map named %s",(const char *) mi->getName());
    return;
  }

  f.readLine(line, 0x10000);

  xadd=mi->getBaseX();
  yadd=mi->getBaseY();


  while (f.readLine(line, 0x10000)!=-1) {
    line=line.simplifyWhiteSpace().stripWhiteSpace();
    cmd=line.section(",",0,0);
    if (cmd.length() != 1) {
      qWarning("MapRead: %s is not a command",(const char *)cmd);
    }
    switch (cmd[0].latin1()) {
      case 'M':
        title=SEC(1);
        color=SEC(2).lower();
        mapline=new oeMapElementLine(color);
        mapline->setText(title);
        num=stringInt(line,3);
        for(i=0;i<num;i++) {
          x=stringInt(line, i*3+4);
          y=stringInt(line, i*3+5);
          z=stringInt(line, i*3+6);
          mapline->addPoint(abs(x) + xadd, abs(y) + yadd, z);
        }
        map.append(mapline);

        break;
      case 'P':
        title=SEC(1);
        color=SEC(2).lower();
        x=stringInt(line,3);
        y=stringInt(line,4);
        z=stringInt(line,5);
        x=abs(x)+xadd;
        y=abs(y)+yadd;

        mappoint=new oeMapElementPoint(x,y,z,color,title);
        map.append(mappoint);

        break;
      default:
        qWarning("Unhandled command %c",cmd[0].latin1());
        break;
    }
  }
}

void oeMap::editLineNew() {
  editelem=new oeMapElementLine(editcolor);
  map.append(editelem);
}

void oeMap::editLinePoint() {
  if (! editelem || (editelem->getElemType() != oeMapElement::Line))
    return;
  ((oeMapElementLine *)editelem)->addPoint(c->playerx, c->playery, c->playerz);
  dirty();
}

void oeMap::editPointNew() {
  bool ok = FALSE;
  QString text;

  text=QInputDialog::getText("Point information", "What text should appear at the point?", QLineEdit::Normal, QString::null, &ok, this);
  if (ok) {
    editelem=new oeMapElementPoint(c->playerx,c->playery,c->playerz,editcolor,text);
    map.append(editelem);
  }
  dirty();
}

void oeMap::editDelete() {
  if (! editelem)
    return;
  if (editelem->getElemType() == oeMapElement::Point) {
    map.remove(editelem);
    editelem=NULL;
  } else {
    ((oeMapElementLine *)editelem)->deletePoint();
  }
  dirty();
}

void oeMap::editRename() {
  bool ok;
  QString text;

  if (! editelem) 
    return;

  text=QInputDialog::getText("New Name", "What's the new name?", QLineEdit::Normal, editelem->getText(), &ok, this);
  if (ok) {
    editelem->setText(text);
    dirty();
  }
}

void oeMap::editClean() {
  QStringList lst;
  QString str;
  oeMapElement *elem;
  editelem = NULL;
  bool wipe;

  for(elem=map.first(); elem; elem=map.next()) {
    wipe=false;

    if (! elem->valid()) {
      qWarning("Element named %s was invalid",(const char *) elem->getText());
      wipe=true;
    } else {
      str=elem->getString(0,0);
      for ( QStringList::Iterator it = lst.begin(); it != lst.end(); ++it ) {
        if (str.compare(*it)==0) {
          qWarning("Found identical objects in map named %s -- Last one removed",(const char *)elem->getText());
          wipe=true;
        }
      }
      if (! wipe)
        lst+=str;
    }
    if (wipe) {
      map.remove(elem);
      elem=map.first();
    }
  }

  dirty();
}

double oeMap::editSimplify() {
  double worstw;
  double w;
  oeMapElement *elem;


  editClean();

  worstw=-1.0;

  for(elem=map.first(); elem; elem=map.next()) {
    if (elem->getElemType() == oeMapElement::Line) {
      w=((oeMapElementLine *)elem)->weight();
      if ((w != -1.0) && ((worstw == -1.0) || (w<worstw))) {
        editelem=elem;
        worstw=w;
      }
    }
  }
  editMovePoint();
  return worstw;
}

void oeMap::editMovePoint() {
  if (!editelem)
    return;
  edit_xofs=editelem->x() - c->playerx;
  edit_yofs=editelem->y() - c->playery;
}

void oeMap::editSave() {
  if (! mi)
    return;

  editClean();

  QStringList firstline;
  QStringList lst;
  QStringList filename;
  QString fname, oriname;
  oeMapElement *elem;

  filename=QStringList::split("/",mi->getName());
  fname=filename.last().replace(QRegExp("\\.map$"),"");
  oriname=fname.append("");
  fname=fname.replace(QRegExp("_")," ");

  firstline+=fname;
  firstline+=oriname;
  firstline+=QString::number(0);  
  firstline+=QString::number(0);  
  firstline+=QString::number(0);  
  firstline+=QString::number(0);  
  firstline+=QString::number(0);  
  firstline+=QString::number(0);  

  for(elem=map.first(); elem; elem=map.next()) {
   lst+=elem->getString(mi->getBaseX(),mi->getBaseY());
  }

  lst.sort();
  lst.prepend(firstline.join(","));

  fname=lst.join("\n");

  QFile f(mi->getName());
  if (! f.open(IO_WriteOnly)) {
    qWarning("Could not open %s for writing",(const char *)mi->getName());
    return;
  }
  QTextStream ts(&f);
  ts << fname;
  QMessageBox::information(this, "Odin's Eye Map", "Map saved successfully");
}

void oeMap::editSetColor(QString col) {
  if (mode_edit && editelem) {
    editelem->setColor(col);
  }
  editcolor=col;
}

oeMapElement::oeMapElement() {
}

oeMapElement::~oeMapElement() {
}

void oeMapElement::setColor(QString col) {
  colorstring=col;
  color=QColor(col);
}

QString oeMapElement::getColor() {
  return colorstring;
}

void oeMapElement::setText(QString ntext) {
  text=ntext;
}

QString oeMapElement::getText() {
  return text;
}

bool oeMapElement::valid() {
  int h,s,v;

  color.hsv(&h,&s,&v);
  if (text.length() == 0)
    return FALSE;
  if (v < 10) 
    return FALSE;
  return TRUE;
}

oeMapElementPoint::oeMapElementPoint(int nx, int ny, int nz, QString col, QString txt) {
  xpos=nx;
  ypos=ny;
  zpos=nz;
  setColor(col);
  text=txt;
}

oeMapElement::ElementType oeMapElementPoint::getElemType() {
  return Point;
}

void oeMapElementPoint::draw(oeMap *map) {
  unsigned int i;

  map->setGLColor(color, zpos);

  if ((! map->mode_edit) || (map->editelem != this)) {
   glBegin(GL_POINTS);
   glVertex3i(xpos,ypos,zpos);
   glEnd();
  } else {
   glPointSize(8.0);
   glBegin(GL_POINTS);
   glVertex3i(xpos,ypos,zpos);
   glEnd();
   glPointSize(3.0);
  }
  map->setGLColor(1.0,1.0,1.0,zpos);

  glRasterPos3i(xpos+50,ypos+20,zpos);
  for (i=0;i<text.length();i++) 
    glutBitmapCharacter(GLUT_BITMAP_HELVETICA_10, text[i].latin1());
}

double oeMapElementPoint::clickAt(int xv, int yv, int) {
  double xd, yd;
  xd=xpos-xv;
  yd=ypos-yv;
  return sqrt(xd*xd+yd*yd);
}

QString oeMapElementPoint::getString(int basex, int basey) {
  QStringList lst;
  lst+="P";
  lst+=text;
  lst+=colorstring;
  lst+=QString::number(xpos - basex);
  lst+=QString::number(ypos - basey);
  lst+=QString::number(zpos);
  return lst.join(",");
}

int oeMapElementPoint::x() {
  return xpos;
}

int oeMapElementPoint::y() {
  return ypos;
}

oeMapElementLinePoint::oeMapElementLinePoint(int nx, int ny, int nz) {
  x=nx;
  y=ny;
  z=nz;
}


oeMapElementLine::oeMapElementLine(QString col) {
  setColor(col);
  selnode=0;
  points.setAutoDelete(TRUE);
  text="Line";
}

oeMapElement::ElementType oeMapElementLine::getElemType() {
  return Line;
}

void oeMapElementLine::addPoint(int x, int y, int z) {
  selnode++;
  if (selnode>=points.count())
    selnode=points.count();
  points.insert(selnode,new oeMapElementLinePoint(x, y, z));
}

void oeMapElementLine::deletePoint() {
  if (points.count() == 0)
    return;
  points.remove(selnode);
  if (selnode > (points.count()-1))
    selnode=points.count()-1;
}

void oeMapElementLine::draw(oeMap *map) {
  oeMapElementLinePoint *p;

  if (map->mode_edit && map->editelem == this)
    glLineWidth(2.0);
  glBegin(GL_LINE_STRIP);
  for (p=points.first(); p; p=points.next()) { 
    map->setGLColor(color, p->z);
    glVertex3i(p->x,p->y,p->z);
  }
  glEnd();  
  if (map->mode_edit) {
    glLineWidth(1.0);
    glPointSize((map->editelem == this) ? 4.0 : 3.0);
    glBegin(GL_POINTS);
    for (p=points.first(); p; p=points.next()) { 
      map->setGLColor(color, p->z);
      glVertex3i(p->x,p->y,p->z);
    }
    glEnd();  
    if ((map->editelem == this) && (points.count() > 0)) {
      p=points.at(selnode);
      if (p) {
        glPointSize(8.0);
        glBegin(GL_POINTS);
        map->setGLColor(color, p->z);
        glVertex3i(p->x,p->y,p->z);
        glEnd();
        if (selnode != 0) {
          p=points.at(0);
          glPointSize(6.0);
          glBegin(GL_POINTS);
          map->setGLColor(color,p->z);
          glVertex3i(p->x,p->y,p->z);
          glEnd();
        }
      }
    }
    glPointSize(3.0);
  }
}

double oeMapElementLine::clickAt(int xv, int yv, int) {
  double best;
  double xd, yd;
  double dist;
  int i;
  oeMapElementLinePoint *p;

  best = -1.0;
  selnode = 0;
  i=0;
  for(p=points.first(); p ; p=points.next()) {
    xd=p->x-xv;
    yd=p->y-yv;
    dist=sqrt(xd*xd+yd*yd);
    if ((best == -1.0) || (dist < best)) {
      best=dist;
      selnode=i;
    }    
    i++;
  }
  return best;
}

QString oeMapElementLine::getString(int basex, int basey) {
  QStringList lst;
  oeMapElementLinePoint *p;
  lst+="M";
  lst+=text;
  lst+=colorstring;
  lst+=QString::number(points.count());
  for(p=points.first(); p ; p=points.next()) {
    lst+=QString::number(p->x - basex);
    lst+=QString::number(p->y - basey);
    lst+=QString::number(p->z);
  }
  return lst.join(",");
}

bool oeMapElementLine::valid() {
  if (! oeMapElement::valid()) 
    return FALSE;
  if (points.count() < 2)
    return FALSE;
  return TRUE;
}

double oeMapElementLine::weight() {
  double w;
  double angle;
  double dist;
  double worstw;
  double xd, yd, zd;
  unsigned int i;

  oeMapElementLinePoint *p;
  oeMapElementLinePoint *t;
  oeMapElementLinePoint *n;

  if (points.count() < 3) 
    return -1.0;

  worstw=-1.0;

  for(i=1;i<points.count()-1;i++) {
    p=points.at(i-1);
    t=points.at(i);
    n=points.at(i+1);

    xd=p->x - t->x;
    yd=p->y - t->y;
    zd=p->z - t->z;
    dist=sqrt(xd*xd+yd*yd+zd*zd);
    angle=atan2(xd, yd);

    xd=n->x - t->x;
    yd=n->y - t->y;
    zd=n->z - t->z;
    dist+=sqrt(xd*xd+yd*yd+zd*zd);
    angle=angle-atan2(xd,yd);

    angle=fabs(angle);

    while (angle > 2 * M_PI)
      angle-=2 * M_PI;
    if (angle > M_PI)
      angle=2 * M_PI - angle;

    // "Inverse" angle to keep the sharpest corners.
    angle=M_PI - angle;

    angle+=0.01;

    w=angle*dist;
    if ((worstw == -1.0) || (w < worstw)) {
      selnode=i;
      worstw=w;
    }
  }
  return worstw;
}

int oeMapElementLine::x() {
  oeMapElementLinePoint *p=points.at(selnode);
  return p->x;
}

int oeMapElementLine::y() {
  oeMapElementLinePoint *p=points.at(selnode);
  return p->y;
}
 