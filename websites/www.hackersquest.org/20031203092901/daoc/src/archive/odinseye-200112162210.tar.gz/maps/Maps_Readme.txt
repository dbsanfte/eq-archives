The maps used in conjunction with Odin's Eye were created, for the most part
by Mapfiend (As of the alpha release) using tools available on 
http://www.k-r-g.com/mapfiend . They are released under the GPL. You are free 
to do with them as you will, but if you create any maps, or make improvements 
to the existing ones, I ask that you please upload them to my site. Visit the
site often for the latest maps.

Mapfiend