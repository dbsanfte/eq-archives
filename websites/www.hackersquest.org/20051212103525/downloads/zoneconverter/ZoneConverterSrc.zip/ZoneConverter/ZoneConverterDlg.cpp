/*
Copyright (C) HackersQuest	(www.hackersquest.gomp.ch / www.ethernalquest.org)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

// ZoneConverterDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ZoneConverter.h"
#include "ZoneConverterDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CZoneConverterDlg dialog

CZoneConverterDlg::CZoneConverterDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CZoneConverterDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CZoneConverterDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CZoneConverterDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CZoneConverterDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CZoneConverterDlg, CDialog)
	//{{AFX_MSG_MAP(CZoneConverterDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_DRAW, OnDraw)
	ON_BN_CLICKED(IDC_OPEN, OnOpen)
	ON_BN_CLICKED(IDC_SAVE, OnSave)
	ON_BN_CLICKED(IDC_EXPORTOBJ, OnExportobj)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CZoneConverterDlg message handlers

BOOL CZoneConverterDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	m_loaded      = false;
	xAng = 1.21;
	zAng = -0.23;
	zoom = 1;

	CStatic *st = (CStatic *)GetDlgItem(IDC_VERTECESCOUNT);
	st->SetWindowText("ZoneConverter 1.1 ready!");

	SetWindowText("ZoneConverter 1.1 BETA");
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CZoneConverterDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CZoneConverterDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CZoneConverterDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CZoneConverterDlg::AddData(Node & node, Data21 * tree, CArray<Data22 *, Data22 *> & regions, DWORD root) 
{
	nodes[root] = &node;
	if(tree->data1[root].params2[0])
	{
		node.final   = true;

		Data22 * region = regions[tree->data1[root].params2[0]];
		Data36 * sprite = /*dynamic_cast<Data36 *>*/(Data36 *)(region->fragment3.fragment);
		if(sprite) 
		{
			node.regions  = new SimpleRegion[sprite->size5];
			node.nRegions = sprite->size5;
			float scale = float(1 << sprite->size10);
			for(DWORD i=0; i<sprite->size5; i++) 
			{
				SimpleRegion & r = node.regions[i];
				Point p;
				p.x = sprite->params1[0] + sprite->data1[sprite->data5[i][1]][0]/scale;
				p.y = sprite->params1[1] + sprite->data1[sprite->data5[i][1]][1]/scale;
				p.z = sprite->params1[2] + sprite->data1[sprite->data5[i][1]][2]/scale;
				ExpandSphera(node, p); r.Add(p);
				p.x = sprite->params1[0] + sprite->data1[sprite->data5[i][2]][0]/scale;
				p.y = sprite->params1[1] + sprite->data1[sprite->data5[i][2]][1]/scale;
				p.z = sprite->params1[2] + sprite->data1[sprite->data5[i][2]][2]/scale;
				ExpandSphera(node, p); r.Add(p);
				p.x = sprite->params1[0] + sprite->data1[sprite->data5[i][3]][0]/scale;
				p.y = sprite->params1[1] + sprite->data1[sprite->data5[i][3]][1]/scale;
				p.z = sprite->params1[2] + sprite->data1[sprite->data5[i][3]][2]/scale;
				ExpandSphera(node, p); r.Add(p);
			}
		}
	} 
	else 
	{
		if(tree->data1[root].index1[0]) 
		{
			node.frontNode = new Node;
			AddData(*(node.frontNode), tree, regions, tree->data1[root].index1[0]-1);
			ExpandSphera(node, node.frontNode->sphera.p1);
			ExpandSphera(node, node.frontNode->sphera.p2);
		}
		if(tree->data1[root].index1[1]) 
		{
			node.backNode = new Node;
			AddData(*(node.backNode), tree, regions, tree->data1[root].index1[1]-1);
			ExpandSphera(node, node.backNode->sphera.p1);
			ExpandSphera(node, node.backNode->sphera.p2);
		}
		node.a = tree->data1[root].params1[0];
		node.b = tree->data1[root].params1[1];
		node.c = tree->data1[root].params1[2];
		node.d = -1 * tree->data1[root].params1[3];
	}
}

void CZoneConverterDlg::ExpandSphera(Node & node, Point p) 
{
	if(!node.hasSphera) 
	{
		node.sphera.p1 = p;
		node.sphera.p2 = p;
		node.hasSphera = true;
	} 
	else 
	{
		if(p.x < node.sphera.p1.x) node.sphera.p1.x = p.x;
		if(p.x > node.sphera.p2.x) node.sphera.p2.x = p.x;
		if(p.y < node.sphera.p1.y) node.sphera.p1.y = p.y;
		if(p.y > node.sphera.p2.y) node.sphera.p2.y = p.y;
		if(p.z < node.sphera.p1.z) node.sphera.p1.z = p.z;
		if(p.z > node.sphera.p2.z) node.sphera.p2.z = p.z;
	}
}

void CZoneConverterDlg::TranslatePos(float xf, float yf, float zf, long & x, long & y) 
{
	x = int(xOff + (xf * xxTran + yf * yxTran + zf * zxTran) * zoom);
	y = int(yOff + (xf * xyTran + yf * yyTran + zf * zyTran) * zoom);
}

void CZoneConverterDlg::DrawNode(FILE *output, Node * node) 
{
	if(!node) 
		return;

	if(node->final) 
	{
		for(int i = node->nRegions; i--; ) 
		{
			SimpleRegion & r = node->regions[i];
			POINT * p = new POINT[r.GetSize()+1];

			fprintf(output, "3DFACE\n");

			for(int j=r.GetSize(); j--; ) 
			{
				fprintf(output, "%f,%f,%f\n", r[j].x, r[j].y, r[j].z);
				VertexCount++;
			}

			fprintf(output, "\n\n");

			delete p;
		}
	} 
	else if(xPro * node->a + yPro * node->b + zPro * node->c > 0) 
	{
		DrawNode(output, node->backNode);
		DrawNode(output, node->frontNode);
	} 
	else 
	{
		DrawNode(output, node->frontNode);
		DrawNode(output, node->backNode);
	}
}

void CZoneConverterDlg::ExportToOBJ(FILE *output, Node * node) 
{
	if(!node) 
		return;

	if(node->final) 
	{
		for(int i = node->nRegions; i--; ) 
		{
			SimpleRegion & r = node->regions[i];
			POINT * p = new POINT[r.GetSize()+1];

			for(int j=r.GetSize(); j--; ) 
			{
				fprintf(output, "v %f %f %f\n", r[j].x, r[j].y, r[j].z);
				VertexCount++;
			}
			fprintf(output, "f -3 -2 -1\n", r[j].x, r[j].y, r[j].z);

			fprintf(output, "\n\n");

			delete p;
		}
	} 
	else if(xPro * node->a + yPro * node->b + zPro * node->c > 0) 
	{
		ExportToOBJ(output, node->backNode);
		ExportToOBJ(output, node->frontNode);
	} 
	else 
	{
		ExportToOBJ(output, node->frontNode);
		ExportToOBJ(output, node->backNode);
	}
}

void CZoneConverterDlg::OnDraw() 
{
/*	if(m_loaded) 
	{
		DrawNode(GetDC(), rootNode);
		MessageBox("Done");
	}*/
}

void CZoneConverterDlg::OnOK() 
{
	if(m_loaded) 
	{
		data.Free();

		ClearNodes(nodes[0]);
		delete mainNode;
	}

	PostQuitMessage(1);
	CDialog::OnOK();
}

void CZoneConverterDlg::ClearNodes(Node * node) 
{
	if(!node) return;
	if(node->final) 
	{
		delete [] node->regions;
		node->regions = NULL;
	} 
	else if(xPro * node->a + yPro * node->b + zPro * node->c > 0) 
	{
		ClearNodes(node->backNode);
		ClearNodes(node->frontNode);
		delete node->backNode;
		node->backNode = NULL;
		delete node->frontNode;
		node->frontNode = NULL;
	} 
	else 
	{
		ClearNodes(node->frontNode);
		ClearNodes(node->backNode);
		delete node->frontNode;
		node->frontNode = NULL;
		delete node->backNode;
		node->backNode = NULL;
	}
}

void CZoneConverterDlg::OnOpen() 
{
	try
	{
		CFileDialog dlg(TRUE, NULL, NULL, OFN_HIDEREADONLY | OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST, "WLD Files (*.wld)|*.wld||");
		switch (dlg.DoModal())
		{
		case IDOK:
			{
				CString tmp = dlg.GetFileExt();
				if (tmp.CompareNoCase("wld"))
				{
					AfxMessageBox("Please open a WLD file.", 0, 0);
					return;
				}
				
				tmp = dlg.GetPathName();
				
				if (m_loaded)
				{
					data.Free();
					m_loaded = false;
				}
				
				data.Decode(tmp.GetBuffer(2560));
				BuildTree();
			}
			break;
		case IDCANCEL:
			break;
		}
	}
	catch(...)
	{
		AfxMessageBox("Couldnt find / open file", 0, 0);
		PostQuitMessage(1);
	}	

}

void CZoneConverterDlg::OnSave() 
{
	if(!m_loaded) 
	{
		AfxMessageBox("Nothing to save.", 0);
		return;
	}

	try
	{
		CFileDialog dlg(FALSE, "scr", "Zone.scr", NULL, "ICAD Script(*.scr)|*.scr||");
		switch (dlg.DoModal())
		{
		case IDOK:
			{
				CString tmp = dlg.GetFileExt();
				if (tmp.CompareNoCase("scr"))
				{
					AfxMessageBox("Please open a SCR file.", 0, 0);
					return;
				}
				
				tmp = dlg.GetPathName();
				
				if(m_loaded) 
				{
					FILE *save = fopen (tmp.GetBuffer(2560), "wb");
					
					if (save != NULL)
					{
						DrawNode(save, rootNode);

						CStatic *st = (CStatic *)GetDlgItem(IDC_VERTECESCOUNT);
						char tmp1[128];
						sprintf(tmp1, "Verteces Saved = %d", VertexCount);
						st->SetWindowText(tmp1);
					}else
						MessageBox("Error opening the file!");

					fclose(save);
				}else
				{
					AfxMessageBox("Nothing to save.", 0);
				}
			}
			break;
		case IDCANCEL:
			break;
		}
	}
	catch(...)
	{
		AfxMessageBox("Couldnt open file for writing.", 0, 0);
		PostQuitMessage(1);
	}

}


void CZoneConverterDlg::BuildTree()
{
	VertexCount = 0;

	CStatic *st = (CStatic *)GetDlgItem(IDC_VERTECESCOUNT);
	st->SetWindowText("ZoneConverter 1.1 ready!");

	currentRoot = 0;
	if(!m_loaded) 
	{
		for(DWORD i = 0; i < data.nFragment; i++)
		{
			if(data.fragments[i] && data.fragments[i]->Id() == 0x21) break;
		}
		if(i == data.nFragment) return;
		Data21 *tree = dynamic_cast<Data21 *>(data.fragments[i]);
		
		CArray<Data22 *, Data22 *> regions;
		regions.Add(NULL);
		for(i=0; i<data.nFragment; i++) 
		{
			if(data.fragments[i] && data.fragments[i]->Id() == 0x22) 
			{
				regions.Add(dynamic_cast<Data22 *>(data.fragments[i]));
			}
		}
		mainNode = new Node;
		AddData(*mainNode, tree, regions, 0);
		
		m_loaded = true;
	}
	rootNode = nodes[currentRoot];
}

void CZoneConverterDlg::OnExportobj() 
{
	if(!m_loaded) 
	{
		AfxMessageBox("Nothing to save.", 0);
		return;
	}

	try
	{
		CFileDialog dlg(FALSE, "obj", "Zone.obj", NULL, "OBJ File (*.obj)|*.obj||");
		switch (dlg.DoModal())
		{
		case IDOK:
			{
				CString tmp = dlg.GetFileExt();
				if (tmp.CompareNoCase("obj"))
				{
					AfxMessageBox("Please open a OBJ file.", 0, 0);
					return;
				}
				
				tmp = dlg.GetPathName();
				
				if(m_loaded) 
				{
					FILE *save = fopen (tmp.GetBuffer(2560), "wb");
					
					if (save != NULL)
					{
						ExportToOBJ(save, rootNode);

						CStatic *st = (CStatic *)GetDlgItem(IDC_VERTECESCOUNT);
						char tmp1[128];
						sprintf(tmp1, "Verteces Saved = %d", VertexCount);
						st->SetWindowText(tmp1);
					}else
						MessageBox("Error opening the file!");

					fclose(save);
				}else
				{
					AfxMessageBox("Nothing to save.", 0);
				}
			}
			break;
		case IDCANCEL:
			break;
		}
	}
	catch(...)
	{
		AfxMessageBox("Couldnt open file for writing.", 0, 0);
		PostQuitMessage(1);
	}	
}
