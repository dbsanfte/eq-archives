/*
Copyright (C) HackersQuest	(www.hackersquest.gomp.ch / www.ethernalquest.org)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include <stdio.h>
#include <string.h>
#include "EQWldData.h"

FragmentReference::FragmentReference() 
{
	name     = NULL;
	fragment = 0;
}

FragmentReference::FragmentReference(const FragmentReference &f)
{
	if(f.name)
	{
		name = new char[strlen(f.name)+1];
		strcpy(name, f.name);
	}else 
	{
		name = NULL;
	}
	
	fragment = f.fragment;
}

void FragmentReference::SetName(const char *n)
{
	delete [] name;
	if(n) 
	{
		name = new char[strlen(n)+1];
		strcpy(name, n);
	}else 
	{
		name = NULL;
	}
}

void FragmentReference::SetFragment(EQWldDataFragment *f) 
{
	fragment = f;
}

FragmentReference & FragmentReference::operator=(const FragmentReference &f) 
{
	if(&f != this) 
	{
		SetName(f.name);
		fragment = f.fragment;
	}
	return *this;
}

FragmentReference::~FragmentReference()
 {
	delete [] name;
}

bool FragmentReference::operator!() const
{
	return !(name || fragment);
}

const char *FragmentReference::GetName()
{
	if(fragment && fragment->Name()) 
		return fragment->Name();

	return name;
}

EQWldDataFragment::EQWldDataFragment(EQWldData *p, DWORD i, BYTE *n)
{
	parent = p;
	id     = i;
	if(n) 
	{
		name = new char[strlen((char *)n)+1];
		strcpy(name, (char *)n);
	}else 
	{
		name = 0;
	}
}

EQWldDataFragment::~EQWldDataFragment()
 {
	Clear();
}

bool EQWldDataFragment::Decode(Buffer &buffer) 
{
	Clear();
	name = DecodeNameReference(buffer);
	return name != 0;
}

void EQWldDataFragment::Encode(Buffer &buffer) 
{
	buffer.PutDWORD(0);
}

void EQWldDataFragment::Clear() 
{
	if(name) 
		delete [] name;
}

char *EQWldDataFragment::DecodeNameReference(Buffer & buffer) 
{
	int pos = buffer.GetInt();
	char *n = NULL;

	if(pos == 0xFF000000 || pos == 0xFF191919)
	{ // 0x35 has that :(
		n = "0xFF000000";
	}else 
	{
		if(pos > 0) 
			return false;

		n = (char*)parent->GetName(pos);
	}

	if(!n) 
		return false;

	name = new char[strlen((char *)n)+1];
	strcpy(name, (char *)n);

	return name;
}

void EQWldDataFragment::DecodeDataPair(Buffer & buffer, DataPair & result)
 {
	result.data1 = buffer.GetDWORD();
	result.data2 = buffer.GetFLOAT();
}

void EQWldDataFragment::PrintAscHeader() 
{
	printf("DATA_%02X", Id());

	if(Name()) 
		printf(": %s", Name());

	printf("\n");
}

void EQWldDataFragment::PrintAscFooter() 
{
	printf("END_DATA_%02X\n", Id());
}

FragmentReference EQWldDataFragment::DecodeFragmentReference(Buffer & buffer) 
{
	DWORD fragmentIndex = buffer.GetDWORD();

	EQWldDataFragment *f = parent->GetFragment(fragmentIndex);
	FragmentReference result;
	result.SetFragment(f);
	
	if(f) 
	{
		const char *name = f->Name();

		if(!name || !*name) 
		{
			char b[255];
			sprintf(b, "FRG(%d)", parent->GetFragmentIndex(this, f));
			result.SetName(b);
		}
	} 
	else if(int(fragmentIndex) < 0) 
	{
		char b[255];
		const char *name = (char *)parent->GetName(fragmentIndex);
		
		if(name) 
		{
			sprintf(b, "(%s)", name);
			result.SetName(b);
		}
	}
	return result;
}

EQWldDataFragmentWithReference::EQWldDataFragmentWithReference(EQWldData *p, DWORD i, BYTE *n) : EQWldDataFragment(p, i, n) 
{
}

EQWldDataFragmentWithReference::~EQWldDataFragmentWithReference()
{
	Clear();
}

void EQWldDataFragmentWithReference::Clear()
{
}

bool EQWldDataFragmentWithReference::Decode(Buffer & buffer)
{
	Clear();
	fragment = DecodeFragmentReference(buffer);
	
	if(!fragment)
		return false;

	return true;
}

SubData01::SubData01()
{
	data1 = 0;
	size1 = 0;
}

SubData01::~SubData01() 
{
	Clear();
}

void SubData01::Clear() 
{
	delete [] data1;
	size1 = 0;
}

bool SubData01::Decode(Buffer & buffer, EQWldDataFragment * parent)
{
	Clear();
	params1[0] = buffer.GetDWORD();
	flags    = buffer.GetDWORD();
	
	if(flags & 1)
		params2[0] = buffer.GetDWORD();

	if(flags & 2) 
		params3[0] = buffer.GetFLOAT();

	if(flags & 4) 
		params4[0] = buffer.GetFLOAT();

	if(flags & 8) 
		fragment = parent->DecodeFragmentReference(buffer);
	
	if(flags & 0x10) 
	{
		for(DWORD i=0; i<3; i++) 
		{
			for(DWORD j=0; j<3; j++) 
			{
				params5[i][j] = buffer.GetDWORD();
			}
		}
	}

	if(flags & 0x20) 
	{
		size1 = buffer.GetDWORD();
		data1 = new BYTE[size1][8];
		memcpy(data1, buffer.GetBYTE(size1 * 8), size1 * 8);
	}

	return buffer.AtEnd();
}

void SubData01::PrintAsc(char * prefix) 
{
	printf("%sFLAGS: %08X\n", prefix, flags);
	printf("%sPARAMS1: %08X\n", prefix, params1[0]);
	
	if(flags & 1)
		printf("%sPARAMS2: %08X\n", prefix, params2[0]);

	if(flags & 2) 
		printf("%sPARAMS3: %g\n", prefix, params3[0]);

	if(flags & 4)
		printf("%sPARAMS4: %g\n", prefix, params4[0]);

	if(flags & 8) 
		printf("%sFRAGMENT: %s\n", prefix, fragment.GetName());
		
	if(flags & 0x10) 
	{
		for(DWORD i=0; i<3; i++) 
		{
			printf("%sPARAMS5_%d: %08X %08X %08X\n", prefix, i, params5[i][0], params5[i][1], params5[i][2]);
		}
	}

	if(flags & 0x20) 
	{
		printf("%sSIZE1: %X\n", prefix, size1);
		EQWldData::PrintHex(data1, size1, 8, 1, 0, prefix);
	}
}

Data03::Data03(EQWldData * p, BYTE * n) : EQWldDataFragment(p, 3, n)
{
	size1 = 0;
	data1  = NULL;
}

Data03::~Data03() 
{
	Clear();
}

void Data03::Clear() 
{
	for(DWORD i=size1; i--; ) delete [] data1[i];
	delete [] data1;
	data1 = 0;
	size1 = 0;
}

bool Data03::Decode(Buffer & buffer)
{
	Clear();
	
	if(!EQWldDataFragment::Decode(buffer)) 
		return false;
	
	size1 = buffer.GetDWORD() + 1;
	data1 = new char*[size1];

	for(DWORD i=0; i<size1; i++)
	{
		WORD size = buffer.GetWORD();
		data1[i] = new char[size];
		memcpy(data1[i], buffer.GetBYTE(size), size);
		parent->Decode((BYTE *)data1[i], size);
	}

	buffer.GetBYTE((buffer.ptr & 3) ? 4 - (buffer.ptr & 3) : 0);
	return buffer.AtEnd();
}

void Data03::PrintAsc() 
{
	PrintAscHeader();
	printf("    SIZE1: %X\n", size1);
	for(DWORD i=0; i<size1; i++) printf("    %04X NAME: %s\n", i, data1[i]);
	PrintAscFooter();
}

Data04::Data04(EQWldData * p, BYTE * n) : EQWldDataFragment(p, 4, n)
{
	size1 = 0;
	data1 = NULL;
}

Data04::~Data04()
{
	Clear();
}

void Data04::Clear()
{
	delete [] data1;
	data1 = NULL;
	size1 = 0;
}

bool Data04::Decode(Buffer & buffer)
{
	Clear();

	if(!EQWldDataFragment::Decode(buffer)) 
		return false;

	flags   = buffer.GetDWORD();
	DWORD size = buffer.GetDWORD();
	params1[0] = (flags & 0x4) ? buffer.GetDWORD() : 0;
	params2[0] = (flags & 0x8) ? buffer.GetDWORD() : 0;

	data1 = new FragmentReference[size];
	
	for(size1=0; size1 < size; size1++) 
	{
		data1[size1] = DecodeFragmentReference(buffer);

		if(!data1[size1]) 
			return false;
	}
	return buffer.AtEnd();
}

void Data04::PrintAsc() 
{
	PrintAscHeader();
	printf("    FLAGS: %X\n", flags);

	if(flags & 0x4)
		printf("    PARAM1: %X\n", params1[0]);

	if(flags & 0x8) 
		printf("    PARAM2: %X\n", params2[0]);

	printf("    SIZE1: %X\n", size1);
	
	for(DWORD i=0; i<size1; i++) 
		printf("    %04X FRAGMENT1: %s\n", i, data1[i].GetName());

	PrintAscFooter();
}

Data05::Data05(EQWldData * p, BYTE * n) : EQWldDataFragmentWithReference(p, 5, n) 
{
}

bool Data05::Decode(Buffer & buffer) 
{
	if(!EQWldDataFragment::Decode(buffer))
		return false;

	EQWldDataFragmentWithReference::Decode(buffer);
	flags    = buffer.GetDWORD();

	return buffer.AtEnd();
}

void Data05::PrintAsc()
{
	PrintAscHeader();
	printf("    FLAGS: %X\n    FRAGMENT1: %s\n", flags, fragment.GetName());
	PrintAscFooter();
}

Data06::Data06(EQWldData * p, BYTE * n) : EQWldDataFragment(p, 0x06, n) 
{
	data1    = 0;
	size1    = 0;
}

Data06::~Data06() 
{
	Clear();
}

void Data06::Clear() 
{
	for(DWORD i=0; i<size1; i++) 
	{
		for(DWORD j=0; j<data1[i].size1; j++)
		{
			delete [] data1[i].data1[j].fragments;
		}
		delete [] data1[i].data1;
	}

	delete [] data1;
	data1 = 0;
	size1 = 0;
	params7.Clear();
}

bool Data06::Decode(Buffer & buffer) 
{
	Clear();

	if(!EQWldDataFragment::Decode(buffer)) 
		return false;

	flags      = buffer.GetDWORD();
	subSize1   = buffer.GetDWORD();
  	size1      = buffer.GetDWORD();
	params1[0] = buffer.GetFLOAT();
	params1[1] = buffer.GetFLOAT();
	fragment   = DecodeFragmentReference(buffer);

	if(flags & 0x80) 
		params2[0] = buffer.GetFLOAT();

	if(flags & 1) 
	{
		params3[0] = buffer.GetDWORD();
		params3[1] = buffer.GetDWORD();
		params3[2] = buffer.GetDWORD();
	}

	if(flags & 2)
		params4[0] = buffer.GetFLOAT();

	if(flags & 4) 
		params5[0] = buffer.GetDWORD();

	if(flags & 8) 
		params6[0] = buffer.GetDWORD();

	data1 = new SubData[size1];

	for(DWORD i=0; i<size1; i++) 
	{
		data1[i].params1[0] = buffer.GetDWORD();
		data1[i].size1      = buffer.GetDWORD();
		data1[i].flags      = data1[i].size1 & 0x80000000;
		data1[i].size1     &= 0x7FFFFFFF;
		data1[i].data1      = new SubData::SubSubData[data1[i].size1];
		
		for(DWORD j =0; j<data1[i].size1; j++) 
		{
			data1[i].data1[j].params1[0] = buffer.GetDWORD();
			data1[i].data1[j].fragments  = new FragmentReference[subSize1];
			for(DWORD k=0; k<subSize1; k++)
			{
				data1[i].data1[j].fragments[k] = DecodeFragmentReference(buffer);
			}
		}
	}

	params7.Decode(buffer, this);
	return buffer.AtEnd();
}

void Data06::PrintAsc() 
{
	PrintAscHeader();
	printf("    FLAGS: %08X\n    SUB_SIZE1: %X\n    PARAMS1: %g %g\n    FRAGMENT: %s\n", flags, subSize1, params1[0], params1[1], fragment.GetName());
	
	if(flags & 0x80) printf("    PARAMS2: %g\n", params2[0]);
	
	if(flags & 1)
		printf("    PARAMS3: %08X %08X %08X\n", params3[0], params3[1], params3[2]);
	
	if(flags & 2) 
		printf("    PARAMS4: %g\n", params4[0]);
	
	if(flags & 4) 
		printf("    PARAMS5: %08X\n", params5[0]);
	
	if(flags & 8)
		printf("    PARAMS6: %08X\n", params6[0]);

	params7.PrintAsc("    PARAMS7.");
	printf("    SIZE1: %X\n", size1);

	for(DWORD i=0; i<size1; i++)
	{
		printf("    %04X PARAMS1: %X\n", i, data1[i].params1[0]);
		printf("    %04X FLAGS: %08X\n", i, data1[i].flags);
		printf("    %04X SIZE1: %X\n", i, data1[i].size1);

		for(DWORD j=0; j<size1; j++)
		{
			printf("    %04X %04X PARAMS1: %X\n", i, j, data1[i].data1[j].params1[0]);

			for(DWORD k=0; k<subSize1; k++)
			{
				printf("    %04X %04X %04X FRAGMENT: %s\n", i, j, k, data1[i].data1[j].fragments[k].GetName());
			}
		}
	}

	PrintAscFooter();
}

Data07::Data07(EQWldData * p, BYTE * n) : EQWldDataFragmentWithReference(p, 0x07, n) 
{
}

bool Data07::Decode(Buffer & buffer) 
{
	if(!EQWldDataFragment::Decode(buffer))
		return false;

	EQWldDataFragmentWithReference::Decode(buffer);

	if(buffer.GetDWORD() != 0)
		return false;

	return buffer.AtEnd();
}

void Data07::PrintAsc()
{
	PrintAscHeader();
	printf("    FRAGMENT1: %s\n", fragment.GetName());
	PrintAscFooter();
}

Data10::Data10(EQWldData * p, BYTE * n) : EQWldDataFragment(p, 0x10, n)
{
	data1 = 0;
	data2 = 0;
	data3 = 0;
	size1 = size2 = 0;
}

Data10::~Data10()
{
	Clear();
}

void Data10::Clear() 
{
	DWORD i;
	for(i=0; i<size1; i++) 
	{
		delete [] data1[i].name;
		delete [] data1[i].data;
	}

	delete [] data1;
	delete [] data2;
	data1 = 0;
	data2 = 0;
	data3 = 0;
	size1 = size2 = 0;
}

bool Data10::Decode(Buffer & buffer) 
{
	Clear();

	if(!EQWldDataFragment::Decode(buffer)) 
		return false;

	DWORD i;
	flags    = buffer.GetDWORD();
	size1    = buffer.GetDWORD();

	if(flags & 0x20000) 
	{
		fragment = DecodeFragmentReference(buffer);
	}else 
	{
		if(buffer.GetDWORD() != 0) 
			return false;
	}

	if(flags & 0x1) 
		memcpy(params1, buffer.GetBYTE(sizeof(DWORD[3])), sizeof(DWORD[3]));

	if(flags & 0x2) 
		params2[0] = buffer.GetDWORD();

	data1 = new SubData[size1];
	
	for(i=0; i<size1; i++)
	{
		data1[i].name      = DecodeNameReference(buffer);
		data1[i].flags     = buffer.GetDWORD();
		data1[i].fragment1 = DecodeFragmentReference(buffer);
		data1[i].fragment2 = DecodeFragmentReference(buffer);
		data1[i].size      = buffer.GetDWORD();
		data1[i].data      = new DWORD[data1[i].size];
		memcpy(data1[i].data, buffer.GetBYTE(sizeof(DWORD) * data1[i].size), sizeof(DWORD) * data1[i].size);
	}

	if(flags & 0x200) 
	{
		size2 = buffer.GetDWORD();
		data2 = new FragmentReference[size2];
		data3 = new DWORD[size2];
	
		for(i=0; i<size2; i++) 
			data2[i] = DecodeFragmentReference(buffer);

		for(i=0; i<size2; i++) 
			data3[i] = buffer.GetDWORD();
	}
	return buffer.AtEnd();
}

void Data10::PrintAsc() 
{
	DWORD i;
	PrintAscHeader();
	printf("    FLAGS: %X\n", flags);

	if(flags & 0x20000) 
		printf("    FRAGMENT1: %s\n", fragment.GetName());

	if(flags & 0x1) 
		printf("    PARAMS1: %08X %08X %8X\n", params1[0], params1[1], params1[2]);

	if(flags & 0x2) 
		printf("    PARAMS2: %08X\n", params2[0]);

	printf("    SIZE1: %X\n", size1);

	for(i=0; i<size1; i++) 
	{
		char prefix[256];
		sprintf(prefix, "    %04X ", i);
		printf("%sNAME: %s\n", prefix, data1[i].name);
		printf("%sFLAGS: %X\n", prefix, data1[i].flags);
		printf("%sFRAGMENT1: %s\n", prefix, data1[i].fragment1.GetName());
		printf("%sFRAGMENT2: %s\n", prefix, data1[i].fragment2.GetName());
		printf("%sSIZE: %X\n", prefix, data1[i].size);
		parent->PrintHex(data1[i].data, data1[i].size, sizeof(DWORD), sizeof(DWORD), 0, prefix);
	}

	printf("    SIZE2: %X\n", size2);
	for(i=0; i<size2; i++)
		printf("    %04X FRAGMENT1: %s\n", i, data2[i].GetName());

	for(i=0; i<size2; i++) 
		printf("    %04X PARAMS1: %08X\n", i, data3[i]);

	PrintAscFooter();
}

Data11::Data11(EQWldData * p, BYTE * n) : EQWldDataFragment(p, 0x11, n)
{
}

Data11::~Data11()
{
	Clear();
}

void Data11::Clear()
{
}

bool Data11::Decode(Buffer & buffer)
{
	Clear();

	if(!EQWldDataFragment::Decode(buffer))
		return false;

	fragment = DecodeFragmentReference(buffer);
	
	if(buffer.GetDWORD() != 0) 
		return false;

	return buffer.AtEnd();
}

void Data11::PrintAsc() 
{
	PrintAscHeader();
	printf("    FRAGMENT1: %s\n", fragment.GetName());
	PrintAscFooter();
}

Data12::Data12(EQWldData * p, BYTE * n) : EQWldDataFragment(p, 0x12, n) 
{
	size1 = 0;
}

Data12::~Data12() 
{
	Clear();
}

void Data12::Clear() 
{
	if(size1) 
	{
		if(flags & 8) 
		{
			delete [] data4;
		}else 
		{
			delete [] data8;
		}
		size1 = 0;
	}
}

bool Data12::Decode(Buffer & buffer) 
{
	Clear();

	if(!EQWldDataFragment::Decode(buffer)) 
		return false;

	flags = buffer.GetDWORD();
	size1 = buffer.GetDWORD();

	if(flags & 8) 
	{
		data4 = new DWORD[size1][4];
		memcpy(data4, buffer.GetBYTE(size1 * sizeof(DWORD[4])), size1 * sizeof(DWORD[4]));
	}else
	{
		data8 = new DWORD[size1][8];
		memcpy(data8, buffer.GetBYTE(size1 * sizeof(DWORD[8])), size1 * sizeof(DWORD[8]));
	}

	return buffer.AtEnd();
}

void Data12::PrintAsc() 
{
	PrintAscHeader();
	printf("    FLAGS: %X\n    SIZE1: %X\n", flags, size1);
	
	if(flags & 8) 
	{
		parent->PrintHex(data4, size1 * 4, sizeof(DWORD[4]), sizeof(DWORD));
	}else
	{
		parent->PrintHex(data8, size1 * 8, sizeof(DWORD[8]), sizeof(DWORD));
	}

	PrintAscFooter();
}

Data13::Data13(EQWldData * p, BYTE * n) : EQWldDataFragmentWithReference(p, 0x13, n) 
{
}

bool Data13::Decode(Buffer & buffer) 
{
	if(!EQWldDataFragment::Decode(buffer)) 
		return false;

	EQWldDataFragmentWithReference::Decode(buffer);
	flags    = buffer.GetDWORD();
	
	if(flags & 1)
		params1[0] = buffer.GetDWORD();

	return buffer.AtEnd();
}

void Data13::PrintAsc()
{
	PrintAscHeader();
	printf("    FLAGS: %X\n    FRAGMENT1: %s\n", flags, fragment.GetName());

	if(flags & 1) 
		printf("    PARAMS1: %08X\n", params1[0]);

	PrintAscFooter();
}

Data14::Data14(EQWldData * p, BYTE * n) : EQWldDataFragment(p, 0x14, n) 
{
	data1 = 0;
	data2 = 0;
	data3 = 0;
	size1 = size2 = size3 = 0;
}

Data14::~Data14() 
{
	Clear();
}

void Data14::Clear() 
{
	DWORD i;
	
	for(i=0; i<size1; i++) 
		delete [] data1[i].data;

	delete [] data1;
	delete [] data2;
	delete [] data3;
	data1 = 0;
	data2 = 0;
	data3 = 0;
	size1 = size2 = size3 = 0;
}

bool Data14::Decode(Buffer & buffer)
{
	Clear();

	if(!EQWldDataFragment::Decode(buffer)) 
		return false;

	DWORD i;

	flags     = buffer.GetDWORD();
	fragment1 = DecodeFragmentReference(buffer);
	size1     = buffer.GetDWORD();
	size2     = buffer.GetDWORD();

	if(!(flags & 0x80))
	{
		fragment2  = DecodeFragmentReference(buffer);
	}else 
	{
		if(buffer.GetDWORD() != 0) 
			return false;
	}

	if(flags  & 0x01) 
		params1[0] = buffer.GetDWORD();

	if(flags  & 0x02) 
		for(i=0; i<7; i++) params2[i] = buffer.GetDWORD();

	data1     = new SubData[size1];

	for(i=0; i<size1; i++) 
	{
		data1[i].size = buffer.GetDWORD();
		data1[i].data = new DataPair[data1[i].size];
		
		for(DWORD j=0; j<data1[i].size; j++)
			DecodeDataPair(buffer, data1[i].data[j]);
	}

	data2 = new FragmentReference[size2];

	for(i=0; i<size2; i++) 
		data2[i] = DecodeFragmentReference(buffer);

	size3 = buffer.GetDWORD();

	if(size3) 
	{
		data3 = new char[size3];
		memcpy(data3, buffer.GetBYTE(size3), size3);
		parent->Decode((BYTE *)data3, size3);
	}

	return buffer.AtEnd();
}

void Data14::PrintAsc() 
{
	DWORD i;

	PrintAscHeader();
	printf("    FLAGS: %X\n    FRAGMENT1: %s\n", flags, fragment1.GetName());

	if(flags & 0x80) 
		printf("    FRAGMENT2: %s\n", fragment2.GetName());

	if(flags & 0x1) 
		printf("    PARAMS1: %08X\n", params1[0]);

	if(flags & 0x2)  
		parent->PrintHex(params2, 7, 7 * sizeof(DWORD), sizeof(DWORD), -1, "    PARAMS2:");

	printf("    SIZE1: %X\n", size1);

	for(i=0; i<size1; i++) 
	{
		printf("    %04X SIZE: %X\n", i, data1[i].size);

		for(DWORD j=0; j<data1[i].size; j++)
		{
			printf("    %04X %04X DATA_PAIR: %08X %g\n", i, j, data1[i].data[j].data1, data1[i].data[j].data2);
		}
	}

	printf("    SIZE2: %X\n", size2);

	for(i=0; i<size2; i++) 
		printf("    %04X FRAGMENT1: %s\n", i, data2[i].GetName());

	if(data3) 
		printf("    STRING: %s\n", data3);

	PrintAscFooter();
}

Data17::Data17(EQWldData * p, BYTE * n) : EQWldDataFragment(p, 0x17, n) 
{
	data1 = 0;
	data2 = 0;
	size1 = size2 = 0;
}

Data17::~Data17() 
{
	Clear();
}

void Data17::Clear()
{
	delete [] data1;

	for(DWORD i=0; i<size2; i++) 
		delete [] data2[i].data;

	delete [] data2;
}

bool Data17::Decode(Buffer & buffer) 
{
	Clear();

	if(!EQWldDataFragment::Decode(buffer)) 
		return false;

	flags      = buffer.GetDWORD();
	size1      = buffer.GetDWORD();
	size2      = buffer.GetDWORD();
	params1[0] = buffer.GetDWORD();
	
	if(flags & 1) 
	{
		params2[0] = buffer.GetFLOAT();
	}else 
	{
		params2[0] = 1; // 0x3F800000;
		buffer.GetFLOAT();
	}

	data1 = new BYTE[size1][12];
	memcpy(data1, buffer.GetBYTE(size1 * 12), size1 * 12);
	data2 = new SubData[size2];

	for(DWORD i=0; i<size2; i++) 
	{
		data2[i].size = buffer.GetDWORD();
		data2[i].data = new DWORD[data2[i].size];
		memcpy(data2[i].data, buffer.GetBYTE(data2[i].size * sizeof(DWORD)), data2[i].size * sizeof(DWORD));
	}

	return buffer.AtEnd();
}

void Data17::PrintAsc() 
{
	PrintAscHeader();
	printf("    FLAGS: %08X\n", flags);
	printf("    PARAMS1: %08X\n", params1[0]);

	if(flags & 1) 
		printf("    PARAMS2: %g\n", params2[0]);

	printf("    SIZE1: %X\n", size1);
	parent->PrintHex(data1, size1, 12);
	printf("    SIZE2: %X\n", size2);

	for(DWORD i=0; i<size2; i++) 
	{
		char prefix[256];
		sprintf(prefix, "    %04X ", i);
		printf("    %s SIZE: %X\n", prefix, data2[i].size);
		parent->PrintHex(data2[i].data, data2[i].size, 4, 4, 0, prefix);
	}

	PrintAscFooter();
}

Data18::Data18(EQWldData * p, BYTE * n) : EQWldDataFragment(p, 0x18, n) 
{
}

Data18::~Data18() 
{
	Clear();
}

void Data18::Clear() 
{
}

bool Data18::Decode(Buffer & buffer) 
{
	Clear();

	if(!EQWldDataFragment::Decode(buffer)) 
		return false;

	fragment = DecodeFragmentReference(buffer);
	flags    = buffer.GetDWORD();

	if(flags & 1) 
		params1[0] = buffer.GetFLOAT();

	return buffer.AtEnd();
}

void Data18::PrintAsc() 
{
	PrintAscHeader();
	printf("    FLAGS: %X\n    FRAGMENT1: %s\n", flags, fragment.GetName());

	if(flags & 1) 
		printf("    PARAMS1: %f\n", params1[0]);

	PrintAscFooter();
}

Data21::Data21(EQWldData * p, BYTE * n) : EQWldDataFragment(p, 0x21, n) 
{
	data1 = 0;
	size1 = 0;
}

Data21::~Data21() 
{
	Clear();
}

void Data21::Clear() 
{
	delete [] data1;
	data1 = 0;
	size1 = 0;
}

bool Data21::Decode(Buffer & buffer) 
{
	Clear();

	if(!EQWldDataFragment::Decode(buffer)) 
		return false;

	size1 = buffer.GetDWORD();
	data1 = new SubData[size1];

	for(DWORD i=0; i<size1; i++) 
	{
		data1[i].params1[0] = buffer.GetFLOAT();
		data1[i].params1[1] = buffer.GetFLOAT();
		data1[i].params1[2] = buffer.GetFLOAT();
		data1[i].params1[3] = buffer.GetFLOAT();
		data1[i].params2[0] = buffer.GetDWORD();
		data1[i].index1[0]  = buffer.GetDWORD();
		data1[i].index1[1]  = buffer.GetDWORD();
	}

	return buffer.AtEnd();
}

void Data21::Encode(Buffer & buffer) 
{
	EQWldDataFragment::Encode(buffer);
	buffer.PutDWORD(size1);

	for(DWORD i=0; i<size1; i++) 
	{
		buffer.PutFLOAT(data1[i].params1[0]);
		buffer.PutFLOAT(data1[i].params1[1]);
		buffer.PutFLOAT(data1[i].params1[2]);
		buffer.PutFLOAT(data1[i].params1[3]);
		buffer.PutDWORD(data1[i].params2[0]);
		buffer.PutDWORD(data1[i].index1[0]);
		buffer.PutDWORD(data1[i].index1[1]);
	}
}

void Data21::PrintAsc() 
{
	PrintAscHeader();
	
	for(DWORD i=0; i<size1; i++) 
	{
		printf("    %04X INDEX: %04X %04X PARAMS: %9.6f %9.6f %9.6f %9g %04X\n", 
			i+1, 
			data1[i].index1[0], 
			data1[i].index1[1], 
			data1[i].params1[0], 
			data1[i].params1[1], 
			data1[i].params1[2], 
			data1[i].params1[3], 
			data1[i].params2[0]);
	}
	
	PrintAscFooter();
}

Data22::Data22(EQWldData * p, BYTE * n) : EQWldDataFragment(p, 0x22, n) 
{
	data1 = 0;
	data2 = 0;
	data3 = 0;
	data4 = 0;
	data5 = 0;
	data6 = 0;
	data7 = 0;
	size1 = size2 = size3 = size4 = size5 = size6 = size7 = 0;
}

Data22::~Data22() 
{
	Clear();
}

void Data22::Clear() 
{
	DWORD i;

	delete [] data1;
	delete [] data2;

	for(i=0; i<size3; i++) 
		delete [] data3[i].data1;

	delete [] data3;

	for(i=0; i<size4; i++) 
		delete [] data4[i].data1;

	delete [] data4;
	delete [] data5;

	for(i=0; i<size6; i++) 
	{
		if(flags & 0x20)
		{
			delete [] data6[i].data1_w;
		}else 
		{
			delete [] data6[i].data1_b;
		}
	}

	delete [] data6;
	delete [] data7;
	data1 = 0;
	data2 = 0;
	data3 = 0;
	data4 = 0;
	data5 = 0;
	data6 = 0;
	data7 = 0;
	size1 = size2 = size3 = size4 = size5 = size6 = size7 = 0;
}

bool Data22::Decode(Buffer & buffer) 
{
	DWORD i;

	Clear();
	if(!EQWldDataFragment::Decode(buffer)) 
		return false;

	flags = buffer.GetDWORD();

	if(flags == 0x00000101)
	{
		// not a known configuration of this chunk
		return true;
	}
	else
	{
		fragment1 = DecodeFragmentReference(buffer);
		size1 = buffer.GetDWORD();
		size2 = buffer.GetDWORD();
		params1[0] = buffer.GetDWORD();
		size3 = buffer.GetDWORD();
		size4 = buffer.GetDWORD();
		params2[0] = buffer.GetDWORD();
		size5 = buffer.GetDWORD();
		size6 = buffer.GetDWORD();
		data1 = new BYTE[size1][12];
		memcpy(data1, buffer.GetBYTE(size1*12), size1*12);
		data2 = new BYTE[size1][8];
		memcpy(data2, buffer.GetBYTE(size2*8), size2*8);
		data3 = new SubData3[size3];
	
		for(i=0; i<size3; i++) 
		{
			data3[i].flags = buffer.GetDWORD();
			data3[i].size1 = buffer.GetDWORD();
			data3[i].data1 = new DWORD[data3[i].size1];
			memcpy(data3[i].data1, buffer.GetBYTE(sizeof(DWORD) * data3[i].size1), sizeof(DWORD) * data3[i].size1);
			
			if(data3[i].flags & 2) 
			{
				data3[i].params1[0] = buffer.GetDWORD();
				data3[i].params1[1] = buffer.GetDWORD();
				data3[i].params1[2] = buffer.GetDWORD();
				data3[i].params2[0] = buffer.GetDWORD();
			}
		}

		data4 = new SubData4[size4];
		
		for(i=0; i<size4; i++) 
		{
			data4[i].flags      = buffer.GetDWORD();
			data4[i].params1[0] = buffer.GetDWORD();
			data4[i].type       = buffer.GetDWORD();

			switch(data4[i].type)
			{
			  case 0x8:
			  case 0x9:
				data4[i].params2_89[0] = buffer.GetDWORD();
				break;
			  case 0xA:
			  case 0xB:
				data4[i].params2_AB[0] = buffer.GetDWORD();
				data4[i].params2_AB[1] = buffer.GetDWORD();
				break;
			  case 0xC:
				data4[i].params2_C[0] = buffer.GetDWORD();
				data4[i].params2_C[1] = buffer.GetDWORD();
			  case 0xD:
				data4[i].params2_D[0] = buffer.GetDWORD();
				break;
			  case 0x12:
				data4[i].params2_12[0] = buffer.GetDWORD();
				break;
			  case 0xE:
			  case 0xFFFFFFF1:
				data4[i].params2_EF[0] = buffer.GetDWORD();
				break;
			  default:
				return false;
			}

			if(data4[i].flags & 4) 
			{
				data4[i].size1 = buffer.GetDWORD();
				data4[i].data1 = new BYTE[data4[i].size1];
				memcpy(data4[i].data1, buffer.GetBYTE(data4[i].size1), data4[i].size1);
				parent->Decode(data4[i].data1, data4[i].size1);
			}
		}

		data5 = new SubData5[size5];

		for(i=0; i<size5; i++) 
		{
			data5[i].params1[0] = buffer.GetDWORD();
			data5[i].params1[1] = buffer.GetDWORD();
			data5[i].params1[2] = buffer.GetDWORD();
			data5[i].params2[0] = buffer.GetDWORD();
			data5[i].params3[0] = buffer.GetDWORD();
			data5[i].params4[0] = buffer.GetDWORD();
			data5[i].params5[0] = buffer.GetDWORD();
		}

		data6 = new SubData6[size6];

		for(i=0; i<size6; i++) 
		{
			data6[i].size1 = buffer.GetWORD();

			if(flags & 0x20) 
			{
				data6[i].data1_w = new WORD[data6[i].size1];
				memcpy(data6[i].data1_w, buffer.GetBYTE(sizeof(WORD)*data6[i].size1), sizeof(WORD)*data6[i].size1);
			}else if(flags & 0x80) 
			{
				data6[i].data1_b = new BYTE[data6[i].size1];
				memcpy(data6[i].data1_b, buffer.GetBYTE(data6[i].size1), data6[i].size1);
			}else 
			{
				return false;
			}
		}

		if(flags & 1)
		{
			params3[0] = buffer.GetFLOAT();
			params3[1] = buffer.GetFLOAT();
			params3[2] = buffer.GetFLOAT();
			params3[3] = buffer.GetFLOAT();
		}

		if(flags & 2) 
			params5[0] = buffer.GetDWORD();

		if(flags & 4) 
			params6[0] = buffer.GetDWORD();

		size7 = buffer.GetDWORD();
		data7 = new BYTE[size7];
		memcpy(data7, buffer.GetBYTE(size7), size7);
		parent->Decode(data7, size7);

		if(flags & 0x040) 
			fragment2 = DecodeFragmentReference(buffer);

		if(flags & 0x100) 
			fragment3 = DecodeFragmentReference(buffer);

		buffer.GetBYTE((buffer.ptr & 3) ? 4 - (buffer.ptr & 3) : 0);

		return buffer.AtEnd();
	}
}

void Data22::Encode(Buffer & buffer)
{
	DWORD i;
	EQWldDataFragment::Encode(buffer);
	buffer.PutDWORD(flags);
	buffer.PutDWORD(0);
	buffer.PutDWORD(size1);
	buffer.PutDWORD(size2);
	buffer.PutDWORD(params1[0]);
	buffer.PutDWORD(size3);
	buffer.PutDWORD(size4);
	buffer.PutDWORD(params2[0]);
	buffer.PutDWORD(size5);
	buffer.PutDWORD(size6);
	buffer.PutBYTE(data1, size1*12);
	buffer.PutBYTE(data2, size2*8);

	for(i=0; i<size3; i++)
	{
		buffer.PutDWORD(data3[i].flags);
		buffer.PutDWORD(data3[i].size1);
		buffer.PutBYTE(data3[i].data1, sizeof(DWORD) * data3[i].size1);

		if(data3[i].flags & 2) 
		{
			buffer.PutDWORD(data3[i].params1[0]);
			buffer.PutDWORD(data3[i].params1[1]);
			buffer.PutDWORD(data3[i].params1[2]);
			buffer.PutDWORD(data3[i].params2[0]);
		}
	}

	for(i=0; i<size4; i++) 
	{
		buffer.PutDWORD(data4[i].flags);
		buffer.PutDWORD(data4[i].params1[0]);
		buffer.PutDWORD(data4[i].type);

		switch(data4[i].type) 
		{
		  case 0x8:
		  case 0x9:
			buffer.PutDWORD(data4[i].params2_89[0]);
			break;
		  case 0xA:
		  case 0xB:
			buffer.PutDWORD(data4[i].params2_AB[0]);
			buffer.PutDWORD(data4[i].params2_AB[1]);
			break;
		  case 0xC:
			buffer.PutDWORD(data4[i].params2_C[0]);
			buffer.PutDWORD(data4[i].params2_C[1]);
		  case 0xD:
			buffer.PutDWORD(data4[i].params2_D[0]);
			break;
		  case 0x12:
			buffer.PutDWORD(data4[i].params2_12[0]);
			break;
		  case 0xE:
		  case 0xFFFFFFF1:
			buffer.PutDWORD(data4[i].params2_EF[0]);
			break;
		}

		if(data4[i].flags & 4)
		{
			buffer.PutDWORD(data4[i].size1);
			BYTE * b = new BYTE[data4[i].size1];
			memcpy(b, data4[i].data1, data4[i].size1);
			parent->Decode(b, data4[i].size1);
			buffer.PutBYTE(b, data4[i].size1);
			delete [] b;
		}
	}

	for(i=0; i<size5; i++) 
	{
		buffer.PutDWORD(data5[i].params1[0]);
		buffer.PutDWORD(data5[i].params1[1]);
		buffer.PutDWORD(data5[i].params1[2]);
		buffer.PutDWORD(data5[i].params2[0]);
		buffer.PutDWORD(data5[i].params3[0]);
		buffer.PutDWORD(data5[i].params4[0]);
		buffer.PutDWORD(data5[i].params5[0]);
	}

	for(i=0; i<size6; i++) 
	{
		buffer.PutWORD(data6[i].size1);

		if(flags & 0x20)
		{
			buffer.PutBYTE(data6[i].data1_w, sizeof(WORD)*data6[i].size1);
		}else if(flags & 0x80)
		{
			buffer.PutBYTE(data6[i].data1_b, data6[i].size1);
		}
	}

	if(flags & 1)
	{
		buffer.PutFLOAT(params3[0]);
		buffer.PutFLOAT(params3[1]);
		buffer.PutFLOAT(params3[2]);
		buffer.PutFLOAT(params3[3]);
	}

	if(flags & 2) 
		buffer.PutDWORD(params5[0]);

	if(flags & 4) 
		buffer.PutDWORD(params6[0]);

	buffer.PutDWORD(size7);
	BYTE * b = new BYTE[size7];
	memcpy(b, data7, size7);
	parent->Decode(b, size7);
	buffer.PutBYTE(b, size7);
	delete [] b;

	if(flags & 0x040) 
		buffer.PutDWORD(0);

	if(flags & 0x100) 
		buffer.PutDWORD(0);
}

void Data22::PrintAsc() 
{
	DWORD i;

	PrintAscHeader();
	printf("    FLAGS: %08X\n", flags);
	printf("    FRAGMENT1: %s\n", fragment1.GetName());

	if(flags & 0x040) 
		printf("    FRAGMENT2: %s\n", fragment2.GetName());

	if(flags & 0x100) 
		printf("    FRAGMENT3: %s\n", fragment3.GetName());

	if(flags & 1)    
		printf("    PARAMS3: %g %g %g %g\n", params3[0], params3[1], params3[2], params3[3]);

	if(flags & 2) 
		printf("    PARAMS5: %08X\n", params5[0]);

	if(flags & 4)
		printf("    PARAMS6: %08X\n", params6[0]);

	printf("    SIZE1: %X\n", size1);
	parent->PrintHex(data1, size1, 12);
	printf("    SIZE2: %X\n", size2);
	parent->PrintHex(data2, size2, 8);
	printf("    PARAMS1: %08X\n", params1[0]);
	printf("    SIZE3: %X\n", size3);

	for(i=0; i<size3; i++)
	{
		char prefix[256];
		sprintf(prefix, "    %04X ", i);
		printf("%sFLAGS: %08X\n", prefix, data3[i].flags);
		printf("%sSIZE1: %08X\n", prefix, data3[i].size1);
		parent->PrintHex(data3[i].data1, data3[i].size1 * sizeof(DWORD), sizeof(DWORD), sizeof(DWORD), 0, prefix);
		
		if(data3[i].flags & 2)
		{
			printf("%sPARAMS1: %08X %08X %08X\n", params1[0], params1[1], params1[2]);
			printf("%sPARAMS2: %08X\n", params2[0]);
		}
	}

	printf("    SIZE4: %X\n", size4);

	for(i=0; i<size4; i++) 
	{
		char prefix[256];
		sprintf(prefix, "    %04X ", i);
		printf("%sFLAGS: %08X\n", prefix, data4[i].flags);
		printf("%sPARAMS1: %08X\n", prefix, data4[i].params1[0]);
		printf("%sTYPE: %X\n", prefix, data4[i].type);
		
		switch(data4[i].type) 
		{
		  case 0x8: case 0x9:
			printf("%sPARAMS2: %08X %08X\n", prefix, data4[i].params2_89[0], data4[i].params2_89[1]);
			break;
		  case 0xA: case 0xB:
			printf("%sPARAMS2: %08X %08X\n", prefix, data4[i].params2_AB[0], data4[i].params2_AB[1]);
			break;
		  case 0xC:
			printf("%sPARAMS2: %08X %08X\n", prefix, data4[i].params2_C[0], data4[i].params2_C[1]);
			break;
		  case 0xD:
			printf("%sPARAMS2: %08X\n", prefix, data4[i].params2_D[0]);
			break;
		  case 0x12:
			printf("%sPARAMS2: %08X\n", prefix, data4[i].params2_12[0]);
			break;
		  case 0xE: case 0xFFFFFFF1:
			printf("%sPARAMS2: %08X\n", prefix, data4[i].params2_EF[0]);
			break;
		}

		if(data4[i].size1) 
			printf("%sSTRING: %s\n", prefix, data4[i].data1);
	}

	printf("    SIZE5: %X\n", size5);

	for(i=0; i<size5; i++) 
	{
		char prefix[256];
		sprintf(prefix, "    %04X ", i);
		printf("%sPARAMS1: %08X %08X %08X\n", prefix, data5[i].params1[0], data5[i].params1[1], data5[i].params1[2]);
		printf("%sPARAMS2: %08X\n", prefix, data5[i].params2[0]);
		printf("%sPARAMS3: %08X\n", prefix, data5[i].params3[0]);
		printf("%sPARAMS4: %08X\n", prefix, data5[i].params4[0]);
		printf("%sPARAMS5: %08X\n", prefix, data5[i].params5[0]);
	}

	printf("    SIZE6: %X\n", size6);

	for(i=0; i<size6; i++) 
	{
		char prefix[256];
		sprintf(prefix, "    %04X ", i);
		printf("%sSIZE1: %X\n", prefix, data6[i].size1);

		if(flags & 0x20) 
		{
			parent->PrintHex(data6[i].data1_w, data6[i].size1 * sizeof(WORD), 16, sizeof(WORD), 0xFFFFFFFF, prefix);
		}else 
		{
			parent->PrintHex(data6[i].data1_b, data6[i].size1, 16, 1, 0xFFFFFFFF, prefix);
		}
	}

	if(size7) 
		printf("    STRING: %s\n", data7);

	PrintAscFooter();
}

Data26::Data26(EQWldData * p, BYTE * n) : EQWldDataFragment(p, 0x26, n) 
{
}

Data26::~Data26() 
{
	Clear();
}

void Data26::Clear() 
{
}

bool Data26::Decode(Buffer & buffer) 
{
	Clear();
	if(!EQWldDataFragment::Decode(buffer)) 
		return false;

	if(buffer.GetDWORD() != 0) 
		return false;

	fragment   = DecodeFragmentReference(buffer);
	params1[0] = buffer.GetDWORD();

	return buffer.AtEnd();
}

void Data26::PrintAsc()
{
	PrintAscHeader();
	printf("    FRAGMENT1: %s\n    PARAMS1: %08X\n", fragment.GetName(), params1[0]);
	PrintAscFooter();
}

Data27::Data27(EQWldData * p, BYTE * n) : EQWldDataFragment(p, 0x27, n)
{
}

Data27::~Data27() 
{
	Clear();
}

void Data27::Clear() 
{
}

bool Data27::Decode(Buffer & buffer) 
{
	Clear();

	if(!EQWldDataFragment::Decode(buffer)) 
		return false;

	fragment = DecodeFragmentReference(buffer);

	if(buffer.GetDWORD() != 0) 
		return false;

	return buffer.AtEnd();
}

void Data27::PrintAsc() 
{
	PrintAscHeader();
	printf("    FRAGMENT1: %s\n", fragment.GetName());
	PrintAscFooter();
}

Data2C::Data2C(EQWldData * p, BYTE * n) : EQWldDataFragment(p, 0x2C, n) 
{
	data1 = 0;
	data2 = 0;
	data3 = 0;
	data4 = 0;
	data5 = 0;
	data6 = 0;
	data7 = 0;
	data8 = 0;
	data9 = 0;
	data10 = 0;
}

Data2C::~Data2C()
{
	Clear();
}

void Data2C::Clear() 
{
	delete [] data1;
	delete [] data2;
	delete [] data3;
	delete [] data4;
	delete [] data5;
	delete [] data6;
	delete [] data7;

	if(flags & 0x200 )
		delete [] data8;

	if(flags & 0x800 ) 
		delete [] data9;

	if(flags & 0x1000) 
		delete [] data10;

	data1 = 0;
	data2 = 0;
	data3 = 0;
	data4 = 0;
	data5 = 0;
	data6 = 0;
	data7 = 0;
	data8 = 0;
	data9 = 0;
	data10 = 0;
}

bool Data2C::Decode(Buffer & buffer) 
{
	Clear();

	if(!EQWldDataFragment::Decode(buffer)) 
		return false;

	flags     = buffer.GetDWORD();
	size1     = buffer.GetDWORD();
	size2     = buffer.GetDWORD();
	size3     = buffer.GetDWORD();
	size4     = buffer.GetDWORD();
	size5     = buffer.GetDWORD();
	size6     = buffer.GetDWORD();
	size7     = buffer.GetDWORD();
	fragment1 = DecodeFragmentReference(buffer);

	if(!fragment1)
		return false;

	fragment2 = DecodeFragmentReference(buffer);

	if(buffer.GetDWORD() != 0) 
		return false;

	fragment3 = DecodeFragmentReference(buffer);
	
	if(flags & 1)
	{
		params1[0] = buffer.GetDWORD();
		params1[1] = buffer.GetDWORD();
		params1[2] = buffer.GetDWORD();
	}else
	{
		params1[0] = params1[1] = params1[2] = 0;
		buffer.GetBYTE(sizeof(DWORD[3]));
	}

	if(flags & 2) 
	{
		params2[0] = buffer.GetDWORD();
	}else 
	{
		params2[0] = 0x3F800000;
		buffer.GetDWORD();
	}

	data1 = new BYTE[size1][0x0C];
	memcpy(data1, buffer.GetBYTE(size1 * sizeof(BYTE[0x0C])), size1 * sizeof(BYTE[0x0C]));
	data2 = new BYTE[size1][0x08];
	memcpy(data2, buffer.GetBYTE(size2 * sizeof(BYTE[0x08])), size2 * sizeof(BYTE[0x08]));
	data3 = new BYTE[size3][0x0C];
	memcpy(data3, buffer.GetBYTE(size3 * sizeof(BYTE[0x0C])), size3 * sizeof(BYTE[0x0C]));
	data4 = new BYTE[size4][0x04];
	memcpy(data4, buffer.GetBYTE(size4 * sizeof(BYTE[0x04])), size4 * sizeof(BYTE[0x04]));
	data5 = new BYTE[size5][0x10];
	memcpy(data5, buffer.GetBYTE(size5 * sizeof(BYTE[0x10])), size5 * sizeof(BYTE[0x10]));
	data6 = new BYTE[size6][0x0C];
	memcpy(data6, buffer.GetBYTE(size6 * sizeof(BYTE[0x0C])), size6 * sizeof(BYTE[0x0C]));
	data7 = new BYTE[size7][0x04];
	memcpy(data7, buffer.GetBYTE(size7 * sizeof(BYTE[0x04])), size7 * sizeof(BYTE[0x04]));

	if(flags & 0x200) 
	{
		size8 = buffer.GetDWORD();

		if(size8 > 0) 
		{
			data8 = new BYTE[size8][0x04];
			memcpy(data8, buffer.GetBYTE(size8 * sizeof(BYTE[0x04])), size8 * sizeof(BYTE[0x04]));
		}
	}

	if(flags & 0x800) 
	{
		size9 = buffer.GetDWORD();
		if(size9 > 0) 
		{
			data9 = new BYTE[size9][0x04];
			memcpy(data9, buffer.GetBYTE(size9 * sizeof(BYTE[0x04])), size9 * sizeof(BYTE[0x04]));
		}
	}

	if(flags & 0x1000) 
	{
		size10 = buffer.GetDWORD();
		if(size10 > 0) 
		{
			data10 = new BYTE[size10][0x04];
			memcpy(data10, buffer.GetBYTE(size10 * sizeof(BYTE[0x04])), size10 * sizeof(BYTE[0x04]));
		}
	}

	if(flags & 0x2000) 
	{
		params3[0] = buffer.GetDWORD();
		params3[1] = buffer.GetDWORD();
		params3[2] = buffer.GetDWORD();
	}else 
	{
		params3[0] = params3[1] = params3[2] = 0;
	}

	return buffer.AtEnd();
}

void Data2C::Encode(Buffer & buffer)
{
	EQWldDataFragment::Encode(buffer);
	buffer.PutDWORD(flags);
	buffer.PutDWORD(size1);
	buffer.PutDWORD(size2);
	buffer.PutDWORD(size3);
	buffer.PutDWORD(size4);
	buffer.PutDWORD(size5);
	buffer.PutDWORD(size6);
	buffer.PutDWORD(size7);
	buffer.PutDWORD(0);
	buffer.PutDWORD(0);
	buffer.PutDWORD(0);
	buffer.PutDWORD(0);

	if(flags & 1)
	{
		buffer.PutDWORD(params1[0]);
		buffer.PutDWORD(params1[1]);
		buffer.PutDWORD(params1[2]);
	}

	if(flags & 2)
	{
		buffer.PutDWORD(params2[0]);
	}

	buffer.PutBYTE(data1, size1 * sizeof(BYTE[0x0C]));
	buffer.PutBYTE(data2, size1 * sizeof(BYTE[0x08]));
	buffer.PutBYTE(data3, size1 * sizeof(BYTE[0x0C]));
	buffer.PutBYTE(data4, size1 * sizeof(BYTE[0x04]));
	buffer.PutBYTE(data5, size1 * sizeof(BYTE[0x10]));
	buffer.PutBYTE(data6, size1 * sizeof(BYTE[0x0C]));
	buffer.PutBYTE(data7, size1 * sizeof(BYTE[0x04]));

	if(flags & 0x200)
	{
		buffer.PutDWORD(size8);
		buffer.PutBYTE(data8, size8 * sizeof(BYTE[0x04]));
	}

	if(flags & 0x800) 
	{
		buffer.PutDWORD(size9);
		buffer.PutBYTE(data9, size9 * sizeof(BYTE[0x04]));
	}

	if(flags & 0x1000) 
	{
		buffer.PutDWORD(size10);
		buffer.PutBYTE(data10, size10 * sizeof(BYTE[0x04]));
	}

	if(flags & 0x2000) 
	{
		buffer.PutDWORD(params3[0]);
		buffer.PutDWORD(params3[1]);
		buffer.PutDWORD(params3[2]);
	}
}		

void Data2C::PrintAsc() 
{
	PrintAscHeader();
	printf("    FLAGS: %X\n", flags);
	printf("    FRAGMENT1: %s\n", fragment1.GetName());

	if(!!fragment2) 
		printf("    FRAGMENT2: %s\n", fragment2.GetName());

	if(!!fragment3)
		printf("    FRAGMENT3: %s\n", fragment3.GetName());

	if(flags & 1)      
		printf("    PARAMS1: %08X %08X %08X\n", params1[0], params1[2], params1[3]);

    if(flags & 2)     
		printf("    PARAMS2: %08X\n", params2[0]);

    if(flags & 0x2000) 
		printf("    PARAMS3: %08X %08X %08X\n", params3[0], params3[2], params3[3]);

	printf("    SIZE1: %X\n", size1);
	parent->PrintHex(data1, size1 * 0xC, 0xC);
	printf("    SIZE2: %X\n", size2);
	parent->PrintHex(data2, size2 * 0x8, 0x8);
	printf("    SIZE3: %X\n", size3);
	parent->PrintHex(data3, size3 * 0xC, 0xC);
	printf("    SIZE4: %X\n", size4);
	parent->PrintHex(data4, size4 * 0x4, 0x4);
	printf("    SIZE5: %X\n", size5);
	parent->PrintHex(data5, size5 * 0x10, 0x10);
	printf("    SIZE6: %X\n", size6);
	parent->PrintHex(data6, size6 * 0xC, 0xC);
	printf("    SIZE7: %X\n", size7);
	parent->PrintHex(data7, size7 * 0x4, 0x4);
	
	if(flags & 0x200) 
	{
		printf("    SIZE8: %X\n", size8);
		parent->PrintHex(data8, size8 * 0x4, 0x4);
	}

	if(flags & 0x800) 
	{
		printf("    SIZE9: %X\n", size9);
		parent->PrintHex(data9, size9 * 0x4, 0x4);
	}

	if(flags & 0x800)
	{
		printf("    SIZE10: %X\n", size10);
		parent->PrintHex(data10, size10 * 0x4, 0x4);
	}

	PrintAscFooter();
}

Data2D::Data2D(EQWldData * p, BYTE * n) : EQWldDataFragmentWithReference(p, 0x2D, n) 
{
}

bool Data2D::Decode(Buffer & buffer)
{
	if(!EQWldDataFragment::Decode(buffer))
		return false;

	EQWldDataFragmentWithReference::Decode(buffer);

	if(buffer.GetDWORD() != 0)
		return false;

	return buffer.AtEnd();
}

void Data2D::PrintAsc() 
{
	PrintAscHeader();
	printf("    FRAGMENT1: %s\n", fragment.GetName());
	PrintAscFooter();
}

Data30::Data30(EQWldData * p, BYTE * n) : EQWldDataFragmentWithReference(p, 0x30, n)
{
}

bool Data30::Decode(Buffer & buffer) 
{
	Clear();

	if(!EQWldDataFragment::Decode(buffer)) 
		return false;

	flags      = buffer.GetDWORD();
	params1[0] = buffer.GetDWORD();
	params2[0] = buffer.GetDWORD();

	params3[0] = buffer.GetFLOAT();
	params3[1] = buffer.GetFLOAT();
	EQWldDataFragmentWithReference::Decode(buffer);
	
	if(flags & 2)
		DecodeDataPair(buffer, pair);

	return buffer.AtEnd();
}

void Data30::PrintAsc() 
{
	PrintAscHeader();
	printf("    FLAGS: %08X\n", flags);
	printf("    PARAMS1: %08X\n", params1[0]);
	printf("    PARAMS2: %08X\n", params2[0]);
	printf("    PARAMS3: %f %f\n", params3[0], params3[1]);
	printf("    FRAGMENT1: %s\n", fragment.GetName());

	if(flags & 2) 
		printf("    DATA_PAIR: %08X %g\n", pair.data1, pair.data2);

	PrintAscFooter();
}

Data31::Data31(EQWldData * p, BYTE * n) : EQWldDataFragment(p, 0x31, n) 
{
	size1 = 0;
	data1 = NULL;
}

Data31::~Data31()
{
	Clear();
}

void Data31::Clear() 
{
	delete [] data1;
	data1 = 0;
	size1 = 0;
}

bool Data31::Decode(Buffer & buffer) 
{
	Clear();

	if(!EQWldDataFragment::Decode(buffer))
		return false;

	if(buffer.GetDWORD() != 0) 
		return false;

	DWORD size = buffer.GetDWORD();

	data1 = new FragmentReference[size];

	for(size1=0; size1 < size; size1++) 
	{
		data1[size1] = DecodeFragmentReference(buffer);

		if(!data1[size1])
			return false;
	}

	return buffer.AtEnd();
}

void Data31::PrintAsc() 
{
	PrintAscHeader();
	printf("    SIZE1: %X\n", size1);

	for(DWORD i=0; i<size1; i++) 
		printf("    %04X FRAGMENT1: %s\n", i, data1[i].GetName());

	PrintAscFooter();
}

Data34::Data34(EQWldData * p, BYTE * n) : EQWldDataFragment(p, 0x34, n)
{
}

Data34::~Data34() 
{
	Clear();
}

void Data34::Clear()
{
}

bool Data34::Decode(Buffer & buffer) 
{
	DWORD i;
	Clear();

	if(!EQWldDataFragment::Decode(buffer)) 
		return false;

	flags = buffer.GetDWORD();

	for(i=0; i<0x13; i++)
		params1[i] = buffer.GetDWORD();

	if(flags & 1) 
	{
		for(i=0; i<2; i++) 
		{
			params2[i][0] = buffer.GetDWORD();
			params2[i][1] = buffer.GetDWORD();
			params2[i][2] = buffer.GetDWORD();
		}
	}

	if(flags & 2) 
	{
		for(i=0; i<2; i++) 
		{
			params3[i][0] = buffer.GetDWORD();
			params3[i][1] = buffer.GetDWORD();
			params3[i][2] = buffer.GetDWORD();
		}
	}

	if(flags & 4) 
		fragment = DecodeFragmentReference(buffer);

	return buffer.AtEnd();
}

void Data34::PrintAsc()
{
	PrintAscHeader();
	printf("    FLAGS: %08X\n", flags);
	parent->PrintHex(params1, 0x13, 16, 4, 0xFFFFFFFF, "    PARAMS1.");

	DWORD i;

	if(flags & 1)
	{
		for(i=0; i<2; i++) 
		{
			printf("    PARAMS2_%d: %08X %08X %08X\n", params2[i], params2[i], params2[i]);
		}
	}

	if(flags & 2) 
	{
		for(i=0; i<2; i++)
		{
			printf("    PARAMS3_%d: %08X %08X %08X\n", params2[i], params2[i], params2[i]);
		}
	}

	if(flags & 4) 
		printf("    FRAGMENT: %s\n", fragment.GetName());

	PrintAscFooter();
}

Data36::Data36(EQWldData * p, BYTE * n) : EQWldDataFragment(p, 0x36, n) 
{
	data1 = 0;
	data2 = 0;
	data3 = 0;
	data4 = 0;
	data5 = 0;
	data6 = 0;
	data7 = 0;
	data8 = 0;
	size1 = size2 = size3 = size4 = size5 = size6 = size7 = size8 = size9 = size10 = 0;
}

Data36::~Data36()
{
	Clear();
}

void Data36::Clear() 
{
	delete [] data1;
	delete [] data2;
	delete [] data3;
	delete [] data4;
	delete [] data5;
	delete [] data6;
	delete [] data7;
	delete [] data8;
	data1 = 0;
	data2 = 0;
	data3 = 0;
	data4 = 0;
	data5 = 0;
	data6 = 0;
	data7 = 0;
	data8 = 0;
	size1 = size2 = size3 = size4 = size5 = size6 = size7 = size8 = size9 = size10 = 0;
}

bool Data36::Decode(Buffer & buffer) 
{
	Clear();

	if(!EQWldDataFragment::Decode(buffer)) 
		return false;

	flags = buffer.GetDWORD();
	fragment1 = DecodeFragmentReference(buffer);
	fragment2 = DecodeFragmentReference(buffer);
	fragment3 = DecodeFragmentReference(buffer);

	if(flags & 0x10000)
	{
		fragment4 = DecodeFragmentReference(buffer);
	}else 
	{
		buffer.GetDWORD();
	}

	if(flags & 1) 
	{
		params1[0] = buffer.GetFLOAT();
		params1[1] = buffer.GetFLOAT();
		params1[2] = buffer.GetFLOAT();
	}else 
	{
		buffer.GetFLOAT();
		buffer.GetFLOAT();
		buffer.GetFLOAT();
	}

	if(flags & 0x200) 
	{
		params2[0] = buffer.GetDWORD();
		params2[1] = buffer.GetDWORD();
		params2[2] = buffer.GetDWORD();
	}else
	{
		buffer.GetDWORD();
		buffer.GetDWORD();
		buffer.GetDWORD();
	}

	if(flags & 0x2) 
	{
		params3[0] = buffer.GetFLOAT();
	}else
	{
		buffer.GetFLOAT();
	}

	if(flags & 0x4000) 
	{
		params4[0] = buffer.GetFLOAT();
		params4[1] = buffer.GetFLOAT();
		params4[2] = buffer.GetFLOAT();
		params4[3] = buffer.GetFLOAT();
		params4[4] = buffer.GetFLOAT();
		params4[5] = buffer.GetFLOAT();
	}else 
	{
		buffer.GetDWORD();
		buffer.GetDWORD();
		buffer.GetDWORD();
		buffer.GetDWORD();
		buffer.GetDWORD();
		buffer.GetDWORD();
	}

	size1 = buffer.GetWORD();
	size2 = buffer.GetWORD();
	size3 = buffer.GetWORD();
	size4 = buffer.GetWORD();
	size5 = buffer.GetWORD();
	size6 = buffer.GetWORD();
	size7 = buffer.GetWORD();
	size8 = buffer.GetWORD();
	size9 = buffer.GetWORD();
	size10 = buffer.GetWORD();
	data1 = new SHORT[size1][3];
	data2 = new BYTE [size2][4];
	data3 = new BYTE [size3][3];
	data4 = new BYTE [size4][4];
	data5 = new WORD [size5][4];
	data6 = new BYTE [size6][4];
	data7 = new BYTE [size7][4];
	data8 = new BYTE [size8][4];
	memcpy(data1, buffer.GetBYTE(6* size1), 6*size1);
	memcpy(data2, buffer.GetBYTE(4* size2), 4*size2);
	memcpy(data3, buffer.GetBYTE(3* size3), 3*size3);
	memcpy(data4, buffer.GetBYTE(4* size4), 4*size4);
	memcpy(data5, buffer.GetBYTE(8* size5), 8*size5);
	memcpy(data6, buffer.GetBYTE(4* size6), 4*size6);
	memcpy(data7, buffer.GetBYTE(4* size7), 4*size7);
	memcpy(data8, buffer.GetBYTE(4* size8), 4*size8);
	buffer.GetBYTE((buffer.ptr & 3) ? 4 - (buffer.ptr & 3) : 0);

	return buffer.AtEnd();
}

void Data36::PrintAsc() 
{
	PrintAscHeader();
	printf("    FLAGS: %X\n", flags);
	printf("    FRAGMENT1: %s\n", fragment1.GetName());

	if(!!fragment2) 
		printf("    FRAGMENT2: %s\n", fragment2.GetName());

	if(!!fragment3) 
		printf("    FRAGMENT3: %s\n", fragment3.GetName());

	if(flags & 0x10000) 
		printf("    FRAGMENT4: %s\n", fragment4.GetName());

	if(flags & 0x00001) 
		printf("    PARAMS1: %g %g %g\n", params1[0], params1[1], params1[2]);

	if(flags & 0x00200) 
		printf("    PARAMS2: %08X %08X %08X\n", params2[0], params2[1], params2[2]);

	if(flags & 0x00002) 
		printf("    PARAMS3: %g\n", params3[0]);

	if(flags & 0x04000) 
		printf("    PARAMS4: %g %g %g %g %g %g\n", params4[0], params4[1], params4[2], params4[3], params4[4], params4[5]);

	printf("    SIZE1: %X\n", size1);

	double val = 1<<size10;

	for(int i=0; i<size1; i++) 
	{
		printf("    %04X: %9.3f %9.3f %9.3f\n", i, data1[i][0]/val, data1[i][1]/val, data1[i][2]/val);
	};

//	parent->PrintHex(data1, size1 * 6, 6);
	printf("    SIZE2: %X\n", size2);
	parent->PrintHex(data2, size2 * 4, 4);
	printf("    SIZE3: %X\n", size3);
	parent->PrintHex(data3, size3 * 3, 3);
	printf("    SIZE4: %X\n", size4);
	parent->PrintHex(data4, size4 * 4, 4);
	printf("    SIZE5: %X\n", size5);
	parent->PrintHex(data5, size5 * 8, 8);
	printf("    SIZE6: %X\n", size6);
	parent->PrintHex(data6, size6 * 4, 4);
	printf("    SIZE7: %X\n", size7);
	parent->PrintHex(data7, size7 * 4, 4);
	printf("    SIZE8: %X\n", size8);
	parent->PrintHex(data8, size8 * 4, 4);
	printf("    SIZE9: %X\n", size9);
	printf("    SIZE10: %X\n", size10);
	PrintAscFooter();
}

DataWithName::DataWithName(EQWldData * p, DWORD i, BYTE * n) : EQWldDataFragment(p, i, n) 
{
	size = 0;
	data = NULL;
}

DataWithName::~DataWithName() 
{
	Clear();
}

void DataWithName::Clear()
{
	delete [] data;
	data = NULL;
	size = 0;
}

bool DataWithName::Decode(Buffer & buffer)
{
	if(!EQWldDataFragment::Decode(buffer)) 
		return false;

	size = buffer.length - buffer.ptr;
	data = new BYTE[size];
	memcpy(data, buffer.GetBYTE(size), size);

	return buffer.AtEnd();
};

void DataWithName::PrintAsc() 
{
	printf("R");
	PrintAscHeader();
	parent->PrintHex(data, size, 16, 1, 4);
	printf("R");
	PrintAscFooter();
};
