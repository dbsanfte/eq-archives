/*
Copyright (C) HackersQuest	(www.hackersquest.gomp.ch / www.ethernalquest.org)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

// WldData.h: interface for the CWldData class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_WLDDATA_H__57894531_4657_11D4_A74E_F06DCA3EEE2D__INCLUDED_)
#define AFX_WLDDATA_H__57894531_4657_11D4_A74E_F06DCA3EEE2D__INCLUDED_

#include <stdlib.h>
#include <string.h>

typedef unsigned char  BYTE;
typedef unsigned short WORD;
typedef          short SHORT;
typedef unsigned long  DWORD;

class Buffer 
{
public:
	BYTE * buffer;
	DWORD  ptr;
	DWORD  length;
	DWORD  bufferLength;
	bool   allocate;
	
	Buffer(BYTE * b = 0, DWORD l = 0) 
	{
		buffer = b;
		ptr    = 0;
		length = l;
		bufferLength = l;
		allocate = !b;
	}
	
	~Buffer() { if(allocate) free(buffer); }
	
	bool Allocate(int size)
	{
		if(ptr+size > bufferLength)
		{
			if(!allocate) return false;
			buffer = (BYTE*)realloc(buffer, bufferLength += 1024);
		}
		return true;
	}
	
	int GetInt() { ptr += 4; return *(int*)(buffer+ptr-4); }

	void PutDWORD(DWORD d)
	{ 
		if(!Allocate(4))
			return;

		*(DWORD*)(buffer+ptr) = d;
		ptr += 4;

		if(length<ptr)
			length = ptr;
	}

	void PutWORD(WORD d) 
	{
		if(!Allocate(2)) 
			return;

		*(WORD*)(buffer+ptr) = d;
		ptr += 2;

		if(length<ptr)
			length = ptr;
	}

	void PutFLOAT(float f) 
	{
		if(!Allocate(4)) 
			return;

		*(float*)(buffer+ptr) = f;
		ptr += 4;

		if(length<ptr)
			length = ptr;
	}

	void PutBYTE(void * data, DWORD size)
	{
		if(!Allocate(size)) 
			return;
		memcpy(buffer+ptr, data, size);
		ptr += size;

		if(length<ptr)
			length = ptr;
	}

	DWORD GetDWORD() { ptr += 4; return *(DWORD*)(buffer+ptr-4); }
	WORD GetWORD() { ptr += 2; return *(WORD*)(buffer+ptr-2); }
	BYTE * GetBYTE(DWORD length = 1) { ptr += length; return buffer+ptr-length; }
	float GetFLOAT() { ptr += 4; return *(float*)(buffer+ptr-4); }
	double GetDOUBLE() { ptr += 8; return *(double*)(buffer+ptr-8); }
	bool AtEnd() { return ptr == length; }
};

class EQWldDataFragment;

class EQWldData  
{
public:
	DWORD               maxFragment;
	DWORD               nFragment;
	EQWldDataFragment **fragments;
	BYTE               *nameHash;
	
	BYTE              *GetName(int pos);
	EQWldDataFragment *GetFragment(int pos);
	
	int GetFragmentIndex(EQWldDataFragment *f);
	int GetFragmentIndex(EQWldDataFragment *f, EQWldDataFragment *t);
	
	void Free();
	
	bool Decode(const char *filename);
	void PrintAsc(/*const char *filename*/);
	
	void Encode(const char *filename);
	
	static void Decode(BYTE *data, DWORD size);
	static void PrintHex(void *data, DWORD size, DWORD base = 16, DWORD eSize = 1, DWORD offset = 0, char * prefix = "    ");
};

struct DataPair
{
	DWORD data1;
	float data2;
};

struct FragmentReference;

class EQWldDataFragment
{
protected:
	DWORD      id;
	char      *name;
	EQWldData *parent;

public:
	EQWldDataFragment(EQWldData *, DWORD id, BYTE *name);
	virtual ~EQWldDataFragment();
	
	const char *Name() { return name; };
	DWORD  Id() { return id; };
	
	void Clear();
	
	virtual bool Decode(Buffer &b);
	virtual void Encode(Buffer &b);
	virtual void PrintAsc() = 0;
	virtual bool LoadAsc(Buffer &b) { return true; };
	
	char			  *DecodeNameReference(Buffer &buffer);
	FragmentReference  DecodeFragmentReference(Buffer &b);
	void               DecodeDataPair(Buffer &buffer, DataPair &result);
	
	void PrintAscHeader();
	void PrintAscFooter();
};

struct FragmentReference 
{
	FragmentReference();
	FragmentReference(const FragmentReference&);
	~FragmentReference();
	
	FragmentReference & operator=(const FragmentReference&);
	bool operator!() const;
	
	const char *GetName();
	
	void SetName(const char *);
	void SetFragment(EQWldDataFragment *);
	
	char              *name;
	EQWldDataFragment *fragment;
};

class SubData01
{
public:
	SubData01();
	~SubData01();
	
	bool Decode(Buffer &buffer, EQWldDataFragment *parent);
	void PrintAsc(char *prefix = "");
	void Clear();
	
	DWORD  flags;
	DWORD  params1[1];
	DWORD  params2[1];
	float  params3[1];
	float  params4[1];
	DWORD  params5[3][3];
	FragmentReference fragment;
	DWORD  size1;
	BYTE   (*data1)[8];
};

class EQWldDataFragmentWithReference : public EQWldDataFragment 
{
public:
	EQWldDataFragmentWithReference(EQWldData *, DWORD, BYTE *name = NULL);
	~EQWldDataFragmentWithReference();
	
	bool Decode(Buffer &buffer);
	void Clear();
	
	DWORD   flags;
	FragmentReference fragment;
};

class Data03 : public EQWldDataFragment 
{
public:
	enum { MAX_FILE = 0x10 };
	Data03(EQWldData *, BYTE *name = NULL);
	~Data03();
	
	bool Decode(Buffer &buffer);
	void PrintAsc();
	void Clear();
	
	DWORD    size1;
	char   **data1;
};

class Data04 : public EQWldDataFragment 
{
public:
	Data04(EQWldData *, BYTE *name = NULL);
	~Data04();
	
	bool Decode(Buffer &buffer);
	void PrintAsc();
	void Clear();
	
	DWORD              flags;
	DWORD              params1[1];
	DWORD              params2[1];
	DWORD              size1;
	FragmentReference *data1;
};

class Data05 : public EQWldDataFragmentWithReference
{
public:
	Data05(EQWldData *, BYTE *name = NULL);
	
	bool Decode(Buffer &buffer);
	void PrintAsc();
	
	DWORD    flags;
};

class Data06 : public EQWldDataFragment
{
public:
	Data06(EQWldData *, BYTE *name = NULL);
	~Data06();
	
	bool Decode(Buffer &buffer);
	void PrintAsc();
	void Clear();
	
	struct SubData 
	{
		struct SubSubData 
		{
			DWORD              params1[1];
			FragmentReference *fragments;
		};
		DWORD       params1[1];
		DWORD       flags;
		DWORD       size1;
		SubSubData *data1;
	};
	
	DWORD     flags;
	DWORD     subSize1;
	DWORD     size1;
	float     params1[2];
	FragmentReference fragment;
	float     params2[1];
	DWORD     params3[3];
	float     params4[1];
	DWORD     params5[1];
	DWORD     params6[1];
	SubData  *data1;
	SubData01 params7;
};

class Data07 : public EQWldDataFragmentWithReference
{
public:
	Data07(EQWldData *, BYTE *name = NULL);
	
	bool Decode(Buffer &buffer);
	void PrintAsc();
};

class Data10 : public EQWldDataFragment
{
public:
	Data10(EQWldData *, BYTE *name = NULL);
	~Data10();
	
	bool Decode(Buffer &buffer);
	void PrintAsc();
	void Clear();
	
	struct SubData
	{
		char   *name;
		DWORD   flags;
		FragmentReference fragment1;
		FragmentReference fragment2;
		DWORD   size;
		DWORD  *data;
	};
	
	DWORD flags;
	FragmentReference fragment;
	DWORD params1[3];
	DWORD params2[1];
	DWORD size1;
	SubData  *data1;
	DWORD size2;
	FragmentReference *data2;
	DWORD  *data3;
};

class Data11 : public EQWldDataFragment
{
public:
	Data11(EQWldData *, BYTE *name = NULL);
	~Data11();
	
	bool Decode(Buffer &buffer);
	void PrintAsc();
	void Clear();
	
	FragmentReference fragment;
};

class Data12 : public EQWldDataFragment 
{
public:
	Data12(EQWldData *, BYTE *name = NULL);
	~Data12();
	
	bool Decode(Buffer &buffer);
	void PrintAsc();
	void Clear();
	
	DWORD    flags;
	DWORD    size1;
	
	union 
	{
		DWORD (*data4)[4];
		DWORD (*data8)[8];
	};
};

class Data13 : public EQWldDataFragmentWithReference
{
public:
	Data13(EQWldData *, BYTE *name = NULL);
	
	bool Decode(Buffer &buffer);
	void PrintAsc();
	
	DWORD    flags;
	DWORD    params1[1];
};

class Data14 : public EQWldDataFragment
{
public:
	Data14(EQWldData *, BYTE *name = NULL);
	~Data14();
	
	bool Decode(Buffer &buffer);
	void PrintAsc();
	void Clear();
	
	struct SubData {
		DWORD     size;
		DataPair *data;
	};
	
	DWORD flags;
	FragmentReference fragment1;
	FragmentReference fragment2;
	DWORD  params1[1];
	DWORD  params2[7];
	DWORD  size1;
	DWORD  size2;
	DWORD  size3;
	SubData   *data1;
	FragmentReference *data2;
	char      *data3;
};

class Data17 : public EQWldDataFragment
{
public:
	Data17(EQWldData *, BYTE *name = NULL);
	~Data17();
	
	bool Decode(Buffer &buffer);
	void PrintAsc();
	void Clear();
	
	struct SubData 
	{
		DWORD  size;
		DWORD *data;
	};
	
	DWORD flags;
	DWORD size1;
	DWORD size2;
	DWORD params1[1];
	float params2[1];
	BYTE  (*data1)[12];
	SubData *data2;
};

class Data18 : public EQWldDataFragment
{
public:
	Data18(EQWldData *, BYTE *name = NULL);
	~Data18();
	
	bool Decode(Buffer &buffer);
	void PrintAsc();
	void Clear();
	
	DWORD  flags;
	FragmentReference fragment;
	float  params1[1];
};

class Data21 : public EQWldDataFragment
{
public:
	Data21(EQWldData *, BYTE * name = NULL);
	~Data21();
	
	bool Decode(Buffer &b);
	void Encode(Buffer &b);
	void PrintAsc();
	void Clear();
	
	struct SubData
	{
		float params1[4];
		DWORD params2[1];
		DWORD index1[2];
	};
	DWORD    size1;
	SubData *data1;
};

class Data22 : public EQWldDataFragment 
{
public:
	Data22(EQWldData *, BYTE *name = NULL);
	~Data22();
	
	bool Decode(Buffer &buffer);
	void Encode(Buffer &buffer);
	void PrintAsc();
	void Clear();
	
	struct SubData3
	{
		DWORD  flags;
		DWORD  size1;
		DWORD *data1;
		DWORD  params1[3];
		DWORD  params2[1];
	};
	
	struct SubData4 
	{
		DWORD  flags;
		DWORD  params1[1];
		DWORD  type;
		union 
		{
			DWORD params2_89[2];
			DWORD params2_AB[2];
			DWORD params2_C[2];
			DWORD params2_D[1];
			DWORD params2_12[1];
			DWORD params2_EF[1];
		};
		DWORD  size1;
		BYTE  *data1;
	};
	struct SubData5 
	{
		DWORD  params1[3];
		DWORD  params2[1];
		DWORD  params3[1];
		DWORD  params4[1];
		DWORD  params5[1];
	};
	struct SubData6
	{
		WORD   size1;
		union 
		{
			BYTE *data1_b;
			WORD *data1_w;
		};
	};
	
	DWORD  flags;
	FragmentReference fragment1;
	FragmentReference fragment2;
	FragmentReference fragment3;
	
	DWORD  params1[1];
	DWORD  params2[1];
	float  params3[4];
	DWORD  params5[1];
	DWORD  params6[1];
	
	DWORD  size1;
	DWORD  size2;
	DWORD  size3;
	DWORD  size4;
	DWORD  size5;
	DWORD  size6;
	DWORD  size7;
	
	BYTE (*data1)[12];
	BYTE (*data2)[8];
	SubData3 *data3;
	SubData4 *data4;
	SubData5 *data5;
	SubData6 *data6;
	BYTE     *data7;
};

class Data26 : public EQWldDataFragment 
{
public:
	Data26(EQWldData *, BYTE *name = NULL);
	~Data26();
	
	bool Decode(Buffer &buffer);
	void PrintAsc();
	void Clear();
	
	FragmentReference fragment;
	DWORD  params1[1];
};

class Data27 : public EQWldDataFragment 
{
public:
	Data27(EQWldData *, BYTE *name = NULL);
	~Data27();
	
	bool Decode(Buffer &buffer);
	void PrintAsc();
	void Clear();
	
	FragmentReference fragment;
};

class Data2C : public EQWldDataFragment
{
public:
	Data2C(EQWldData *, BYTE *name = NULL);
	~Data2C();
	
	bool Decode(Buffer &buffer);
	void Encode(Buffer &buffer);
	void PrintAsc();
	void Clear();
	
	DWORD    flags;
	DWORD	 size1;
	DWORD	 size2;
	DWORD	 size3;
	DWORD	 size4;
	DWORD	 size5;
	DWORD	 size6;
	DWORD	 size7;
	DWORD	 size8;
	DWORD	 size9;
	DWORD	 size10;
	
	DWORD    params1[3];
	DWORD    params2[1];
	DWORD    params3[3];
	
	BYTE     (*data1)[0x0C];
	BYTE     (*data2)[0x08];
	BYTE     (*data3)[0x0C];
	BYTE     (*data4)[0x04];
	BYTE     (*data5)[0x10];
	BYTE     (*data6)[0x0C];
	BYTE     (*data7)[0x04];
	BYTE     (*data8)[0x04];
	BYTE     (*data9)[0x04];
	BYTE     (*data10)[0x04];
	
	FragmentReference fragment1;
	FragmentReference fragment2;
	FragmentReference fragment3;
};

class Data2D : public EQWldDataFragmentWithReference 
{
public:
	Data2D(EQWldData *, BYTE *name = NULL);
	
	bool Decode(Buffer &buffer);
	void PrintAsc();
};

class Data30 : public EQWldDataFragmentWithReference 
{
public:
	Data30(EQWldData *, BYTE *name = NULL);
	
	bool Decode(Buffer &buffer);
	void PrintAsc();
	
	DWORD    flags;
	DWORD    params1[1];
	DWORD    params2[1];
	float    params3[2];
	DataPair pair;
};

class Data31 : public EQWldDataFragment 
{
public:
	Data31(EQWldData *, BYTE *name = NULL);
	~Data31();
	
	bool Decode(Buffer &buffer);
	void PrintAsc();
	void Clear();
	
	DWORD              size1;
	FragmentReference *data1;
};

class Data34 : public EQWldDataFragment 
{
public:
	Data34(EQWldData *, BYTE *name = NULL);
	~Data34();
	
	bool Decode(Buffer &buffer);
	void PrintAsc();
	void Clear();
	
	DWORD   flags;
	DWORD   params1[0x13];
	DWORD   params2[2][3];
	DWORD   params3[2][3];
	FragmentReference fragment;
};

class Data36 : public EQWldDataFragment 
{
public:
	Data36(EQWldData *, BYTE *name = NULL);
	~Data36();
	
	bool Decode(Buffer &buffer);
	void PrintAsc();
	void Clear();
	
	DWORD flags;
	FragmentReference fragment1;
	FragmentReference fragment2;
	FragmentReference fragment3;
	FragmentReference fragment4;
	float  params1[3];
	DWORD  params2[3];
	float  params3[1];
	float  params4[6];
	WORD   size1;
	WORD   size2;
	WORD   size3;
	WORD   size4;
	WORD   size5;
	WORD   size6;
	WORD   size7;
	WORD   size8;
	WORD   size9;
	WORD   size10;
	SHORT  (*data1)[3];
	BYTE   (*data2)[4];
	BYTE   (*data3)[3];
	BYTE   (*data4)[4];
	WORD   (*data5)[4];
	BYTE   (*data6)[4];
	BYTE   (*data7)[4];
	BYTE   (*data8)[4];
};

class DataWithName : public EQWldDataFragment 
{
public:
	DataWithName(EQWldData *, DWORD id, BYTE *name = NULL);
	~DataWithName();
	
	bool Decode(Buffer &buffer);
	void PrintAsc();
	void Clear();
	
	DWORD  size;
	BYTE  *data;
};

#endif // !defined(AFX_WLDDATA_H__57894531_4657_11D4_A74E_F06DCA3EEE2D__INCLUDED_)
