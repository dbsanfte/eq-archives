/*
Copyright (C) HackersQuest	(www.hackersquest.gomp.ch / www.ethernalquest.org)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

// ZoneConverterDlg.h : header file
//

#if !defined(AFX_ZONECONVERTERDLG_H__C2F28307_4B5A_11D4_A74E_B749BA1DE02D__INCLUDED_)
#define AFX_ZONECONVERTER_H__C2F28307_4B5A_11D4_A74E_B749BA1DE02D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "EQWldData.h"
#include <afxtempl.h>

/////////////////////////////////////////////////////////////////////////////
// CZoneConverterDlg dialog

class CZoneConverterDlg : public CDialog
{
// Construction
public:
	CZoneConverterDlg(CWnd* pParent = NULL);	// standard constructor
	
	EQWldData data;
	int       currentRoot;
	unsigned int VertexCount;

	void BuildTree();
// Dialog Data
	//{{AFX_DATA(CZoneConverterDlg)
	enum { IDD = IDD_ZONECONVERTER_DIALOG };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CZoneConverterDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	struct Point {
		Point(float xs = 0, float ys = 0, float zs = 0) : x(xs), y(ys), z(zs) {};
		float x;
		float y;
		float z;
	};
	struct Vector {
		Vector(float x1s = 0, float y1s = 0, float z1s = 0, float x2s = 0, float y2s = 0, float z2s = 0) :
			p1(x1s, y1s, z1s), p2(x2s, y2s, z2s)
		{}
		Point p1;
		Point p2;
	};

	typedef CArray<Point, Point&> SimpleRegion;

	struct Node {
		Node() {
			frontNode = backNode = 0;
			regions = 0;
			nRegions = 0;
			final = hasSphera = false;
		};
		~Node() {
			delete [] frontNode;
			delete [] backNode;
			delete [] regions;
		};
		bool           final;
		Node         * frontNode;
		Node         * backNode;
		SimpleRegion * regions;
		int            nRegions;
		float  a, b, c, d;
		bool   hasSphera;
		Vector sphera;
	};

	bool   m_loaded;
	Node * mainNode;
	Node * rootNode;
	CMap<DWORD, DWORD, Node *, Node *> nodes;

	CArray<Vector, Vector&> wires;

	int xOff;
	int yOff;

	double xAng;
	double zAng;
	double zoom;
	double xxTran;
	double yxTran;
	double zxTran;

	double xyTran;
	double yyTran;
	double zyTran;

	double xPro;
	double yPro;
	double zPro;
	
	void AddData(Node & node, Data21 * tree, CArray<Data22 *, Data22 *> & regions, DWORD root);
	void ExpandSphera(Node & node, Point p);
	void TranslatePos(float xf, float yf, float zf, long & x, long & y);
	void DrawNode(FILE *save, Node * node);
	void ClearNodes(Node * node);

	void ExportToOBJ(FILE *output, Node * node);

	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CZoneConverterDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnDraw();
	virtual void OnOK();
	afx_msg void OnOpen();
	afx_msg void OnSave();
	afx_msg void OnExportobj();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ZONECONVERTERDLG_H__C2F28307_4B5A_11D4_A74E_B749BA1DE02D__INCLUDED_)
