/*
Copyright (C) HackersQuest	(www.hackersquest.gomp.ch / www.ethernalquest.org)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ZoneConverter.rc
//
#define IDC_OPEN                        3
#define IDC_SAVE                        4
#define IDC_EXPORTOBJ                   5
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_ZONECONVERTER_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDI_MAINFRAME                   130
#define IDC_BUILDTREE                   1000
#define IDC_DRAW                        1001
#define IDC_VERTECESCOUNT               1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
