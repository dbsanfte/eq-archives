/*
Copyright (C) HackersQuest	(www.hackersquest.gomp.ch / www.ethernalquest.org)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

// WldData.cpp: implementation of the CWldData class.
//
//////////////////////////////////////////////////////////////////////

#include "EQWldData.h"
#include "stdio.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

bool EQWldData::Decode(const char *filename)
{
    FILE *f = fopen(filename, "rb");
	
	if(!f) return false;
	
	unsigned long header[7];
	
	/* Check for stuff that required special handling that isnt implemented yet */
	if(fread(header, sizeof(DWORD), 7, f) != 7) 
	{
		fclose(f);
		return false;
	}
	
	if(header[0] != 0x54503D02) 
	{
		fclose(f);
		return false;
	}
	if((header[1] & 0xFFFFFFFE) != 0x00015500) 
	{
		fclose(f);
		return false;
	}
	
	if(header[1] & 1) 
	{
		fclose(f);
		return false;
	}
	
	maxFragment  = header[2];
	fragments    = new EQWldDataFragment*[maxFragment+1];
	fragments[0] = 0;
	nFragment    = 1;
	
	nameHash = new BYTE[header[5]];
	
	if(fread(nameHash, 1, header[5], f) != header[5]) 
	{
		fclose(f);
		return false;
	}
	
	Decode(nameHash, header[5]);
	
	while(nFragment <= maxFragment) 
	{
		DWORD  size   = getw(f);
		if(size == 0xFFFFFFFF) break;
		DWORD  object = getw(f);
		
		BYTE *b = new BYTE[size];
		Buffer buffer(b, size);
		
		if(fread(b, 1, size, f) != size)
		{
			delete [] b;
			return false;
		}
		
		switch(object) 
		{
		case 0x03:
			fragments[nFragment++] = new Data03(this);
			break;
		case 0x04:
			fragments[nFragment++] = new Data04(this);
			break;
		case 0x05:
			fragments[nFragment++] = new Data05(this);
			break;
		case 0x06:
			fragments[nFragment++] = new Data06(this);
			break;
		case 0x07:
			fragments[nFragment++] = new Data07(this);
			break;
		case 0x10:
			fragments[nFragment++] = new Data10(this);
			break;
		case 0x11:
			fragments[nFragment++] = new Data11(this);
			break;
		case 0x12:
			fragments[nFragment++] = new Data12(this);
			break;
		case 0x13:
			fragments[nFragment++] = new Data13(this);
			break;
		case 0x14:
			fragments[nFragment++] = new Data14(this);
			break;
		case 0x17:
			fragments[nFragment++] = new Data17(this);
			break;
		case 0x18:
			fragments[nFragment++] = new Data18(this);
			break;
		case 0x21:
			fragments[nFragment++] = new Data21(this);
			break;
		case 0x22:
			fragments[nFragment++] = new Data22(this);
			break;
		case 0x26:
			fragments[nFragment++] = new Data26(this);
			break;
		case 0x27:
			fragments[nFragment++] = new Data27(this);
			break;
		case 0x2C:
			fragments[nFragment++] = new Data2C(this);
			break;
		case 0x2D:
			fragments[nFragment++] = new Data2D(this);
			break;
		case 0x30:
			fragments[nFragment++] = new Data30(this);
			break;
		case 0x31:
			fragments[nFragment++] = new Data31(this);
			break;
		case 0x34:
			fragments[nFragment++] = new Data34(this);
			break;
		case 0x36:
			fragments[nFragment++] = new Data36(this);
			break;
		default:
			fragments[nFragment++] = new DataWithName(this, object);
			break;
		}
		if(!fragments[nFragment-1]->Decode(buffer)) 
		{
			fclose(f);
			delete [] b;
			return false;
		}
		
		delete [] b;
	}
	fclose(f);
	return true;
}

void EQWldData::PrintHex(void *data, DWORD size, DWORD base, DWORD eSize, DWORD offset, char *prefix) 
{
	DWORD pos = offset;
	
	if(pos == 0xFFFFFFFF) 
		pos = 0;
	
	char achTemp[64];
	
	achTemp[0] = '\0';
	
	int j = 0;
	for(DWORD i=0; i<size; i++) 
	{
		if(i % (base/eSize) != 0) 
		{
			printf(" ");
		} 
		else 
		{
			if(offset >= 0) 
			{
				printf("%s%04X ", prefix, offset ? pos / eSize : pos / base);
			}
			else
			{
				printf("%s ", prefix);
			}
		}
		pos += eSize;
		switch(eSize) 
		{
		default:
		case 1:
			if(((BYTE *)data)[i] < 33)
			{
				achTemp[i - j] = '.';
			}
			else
			{
				achTemp[i - j] = ((BYTE *)data)[i];
			}
			printf("%02X", ((BYTE *)data)[i]);
			break;
		case 2:
			printf("%04X", ((WORD *)data)[i]);
			break;
		case 4:
			printf("%08X", ((DWORD *)data)[i]);
			break;
		}

		if(i % (base/eSize) == (base/eSize) - 1) 
		{
			if(eSize == 1)
			{
				achTemp[i - j + 1] = '\0';
				printf(" %s\n", achTemp);
				achTemp[0] = '\0';
				j = i + 1;
			}
			else
			{
				printf("\n");
			}
		}
	}

	if(i % (base/eSize))
	{
		if(eSize == 1)
		{
			achTemp[i - j + 1] = '\0';
			printf(" %s\n", achTemp);
			achTemp[0] = '\0';
		}
		else
		{
			printf("\n");
		}
	}
}

void EQWldData::Decode(BYTE *data, DWORD size) 
{
	static BYTE codes[8] = { 0x95, 0x3A, 0xC5, 0x2A, 0x95, 0x7A, 0x95, 0x6A };
	for(DWORD i=0; i<size; i++)
	{
		data[i] ^= codes[i&7];
	}
}

BYTE *EQWldData::GetName(int pos) 
{
	if(pos > 0) return NULL;
	return nameHash - pos;
}

EQWldDataFragment *EQWldData::GetFragment(int pos) 
{
	unsigned int i;
	if(pos < 0) 
	{
		char *name = (char *)nameHash - pos;
		for(i=1; i<nFragment; i++) 
		{
			if(fragments[i]->Name() && !strcmp(fragments[i]->Name(), name)) break;
		}
	}
	if((DWORD)pos >= nFragment) return NULL;
	
	return fragments[pos];
}

int EQWldData::GetFragmentIndex(EQWldDataFragment *f) 
{
	for(DWORD i=0; i<nFragment; i++) 
	{
		if(fragments[i] == f) return i;
	}
	return -1;
}

int EQWldData::GetFragmentIndex(EQWldDataFragment *f, EQWldDataFragment *t) 
{
	return GetFragmentIndex(t) - GetFragmentIndex(f);
}

void EQWldData::Free() 
{
	delete [] nameHash;
	for(DWORD i=0; i<nFragment; i++) delete [] fragments[i];
}

void EQWldData::PrintAsc(/*const char *name*/)
{
	for(DWORD i=0; i<nFragment; i++) 
	{
		if(fragments[i]) 
			fragments[i]->PrintAsc();
	}
}

void EQWldData::Encode(const char *name) 
{
	FILE *f = fopen(name, "wb");
	DWORD header[7];
	header[0] = 0x54503D02;
	header[1] = 0x00015500;
	header[2] = 1;
	header[3] = 0x1DBB;
	header[4] = 0x680D4;
	header[5] = 1;
	header[6] = 1;
	
	fwrite(header, sizeof(DWORD), 7, f);
	putc(0x95, f);
	for(DWORD i=0; i<nFragment; i++) 
	{
		if(fragments[i] && fragments[i]->Id() == 0x2C) 
		{
			Buffer b;
			fragments[i]->Encode(b);
			while(b.length % 4 != 0) b.PutBYTE("", 1);
			putw(b.length, f);
			putw(fragments[i]->Id(), f);
			fwrite(b.buffer, 1, b.length, f);
			break;
		}
	}
	putw(-1, f);
}
