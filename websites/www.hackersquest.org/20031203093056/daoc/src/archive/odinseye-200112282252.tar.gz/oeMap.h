/*
 * Copyright 2001 Slicer/HackersQuest (slicer@hackersquest.org)
 *
 * This file is part of Odin's Eye.
 *
 * Odin's Eye is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Odin's Eye is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 */

#ifndef _OEMAP_H
#define _OEMAP_H

#include <qgl.h>
#include <qfile.h>
#include "oeConnection.h"
#include "oeMapInfo.h"

class oeMapElement {
  public:
    enum ElementType {
      Line, Point
    };
  protected:
    double r,g,b;
    QColor color;
    QString colorstring;
    QString text;
  public:
    oeMapElement();
    virtual ~oeMapElement();
    void setColor(QString col);
    QString getColor();
    QString getText();
    void setText(QString newtext);

    virtual QString getString(int basex, int basey) = 0;
    virtual void draw(oeMap *map) = 0;
    virtual double clickAt(int x, int y, int z) = 0;
    virtual oeMapElement::ElementType getElemType() = 0;
    virtual bool valid();
    virtual int x() = 0;
    virtual int y() = 0;
    virtual bool visible(int minx, int maxx, int miny, int maxy) = 0;
};

class oeMapElementPoint : public oeMapElement {
  protected:
    int xpos, ypos, zpos;
  public:
    oeMapElementPoint(int px, int py, int pz, QString col, QString txt);
    void draw(oeMap *map);
    double clickAt(int x, int y, int z);
    oeMapElement::ElementType getElemType();
    QString getString(int basex, int basey);
    int x();
    int y();
    bool visible(int minx, int maxx, int miny, int maxy);
};

class oeMapElementLinePoint {
  public:
    int x, y, z;
    oeMapElementLinePoint(int nx, int ny, int nz);
};

class oeMapElementLine : public oeMapElement {
  protected:
    QPtrList<oeMapElementLinePoint> points;
    unsigned int selnode;
    int bounds_minx, bounds_maxx, bounds_miny, bounds_maxy;
    bool dirty;
  public:
    oeMapElementLine(QString col);
    void addPoint(int x, int y, int z);
    void deletePoint();
    double weight();
    void changed();
    void DouglasPeucker(double sigma);
     
    void draw(oeMap *map);
    double clickAt(int x, int y, int z);
    oeMapElement::ElementType getElemType();
    QString getString(int basex, int basey);
    bool valid();
    int x();
    int y();
    bool visible(int minx, int maxx, int miny, int maxy);        
};

class oeMap : public QGLWidget {
protected:
  bool is_dirty;
  bool map_load;
  GLuint listTriangle;
  GLuint listCircle;
  oeMapInfo *mi;
  int objsize;
  oeTimeType _lastDarken;
  bool mobDarken;
  QPtrList<oeMapElement> map;
  int edit_xofs;
  int edit_yofs;
public:
  oeConnection *c;
  int range;
  bool mode_edit;
  oeMapElement *editelem;
  QString editcolor;
  
  oeMap(QWidget *parent, const char *name);
  ~oeMap();
  void initializeGL();
  void resizeGL(int w, int h);
  void paintGL();
  void mousePressEvent(QMouseEvent *e);
  void keyPressEvent(QKeyEvent *e);

  void editLineNew();
  void editLinePoint();
  void editPointNew();
  void editDelete();
  void editClean();
  double editSimplify();
  void editSave();
  void editSetColor(QString col);
  void editRename();
  void editMovePoint();

  void setGLColor(double r, double g, double b, int z);
  void setGLColor(QColor col, int z);
  void dirty();
  void setConnection(oeConnection *nc);
  void objRotate(unsigned int daocheading);
  void setMap(oeMapInfo *m);
  void mapRead();
  void textGL(QString text, int x, int y, int z);
  void setObjectSize(int nsize);
  int stringInt(QString s, int sec);
  oeMapInfo *getMap();
  void makeObjects(bool simple);
};


#else
class oeMapElement; 
class oeMapElementPoint;
class oeMapElementLine;
class oeMap;
#endif
