/*
 * Copyright 2001 Slicer/HackersQuest (slicer@hackersquest.org)
 *
 * This file is part of Odin's Eye.
 *
 * Odin's Eye is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Odin's Eye is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 */

/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you wish to add, delete or rename slots use Qt Designer which will
** update this file, preserving your code. Create an init() slot in place of
** a constructor, and a destroy() slot in place of a destructor.
*****************************************************************************/

#include <qgl.h>
#include <qsettings.h>
#include <qvaluelist.h>

void FormOdinsEye::resizeEvent(QResizeEvent *e) {
    HSplitter->resize(centralWidget()->size());
    QWidget::resizeEvent(e);
 }

void FormOdinsEye::showEvent(QShowEvent *e) {
    HSplitter->resize(centralWidget()->size());
    QMainWindow::showEvent(e);
}

void FormOdinsEye::GLSimpleObjects_toggled( bool ena)
{
  Map->makeCurrent();
  Map->makeObjects(ena);
}

void FormOdinsEye::GLSmoothPolygons_toggled( bool ena)
{
    Map->smooth_polygons=ena;
}

void FormOdinsEye::GLSmoothPoints_toggled( bool ena)
{
    Map->smooth_points=ena;
}

void FormOdinsEye::GLSmoothLines_toggled( bool ena)
{
    Map->smooth_lines=ena;
}

void FormOdinsEye::init()
{
    loadSettings();
}

void FormOdinsEye::closeEvent( QCloseEvent *e )
{
  saveSettings();
  QMainWindow::closeEvent(e);
}

void FormOdinsEye::loadSettings()
{
  QSettings s;
  QValueList<int> sz;
  
  resize(s.readNumEntry("/OdinsEye/MainWindowW",750),s.readNumEntry("/OdinsEye/MainWindowH",550));
  
  sz.clear();
  sz.append(s.readNumEntry("/OdinsEye/SplitH1",200));
  sz.append(s.readNumEntry("/OdinsEye/SplitH2",550));
  HSplitter->setSizes(sz);
  
  sz.clear();
  sz.append(s.readNumEntry("/OdinsEye/SplitV1",100));
  sz.append(s.readNumEntry("/OdinsEye/SplitV2",450));
  VSplitter->setSizes(sz);
  
  GLSimpleObjects->setOn(s.readBoolEntry("/OdinsEye/GLSimpleObjects",TRUE));
  GLSmoothPolygons->setOn(s.readBoolEntry("/OdinsEye/GLSmoothPolygons",FALSE));
  GLSmoothPoints->setOn(s.readBoolEntry("/OdinsEye/GLSmoothPoints",TRUE));
  GLSmoothLines->setOn(s.readBoolEntry("/OdinsEye/GLSmoothLines",FALSE));
  AutoSelectTarget->setOn(s.readBoolEntry("/OdinsEye/AutoSelectTarget",FALSE));
  GroupPlayers->setOn(s.readBoolEntry("/OdinsEye/GroupPlayers",FALSE));
  SortDistance->setOn(s.readBoolEntry("/OdinsEye/SortDistance",FALSE));
  RotateMap->setOn(s.readBoolEntry("/OdinsEye/RotateMap",FALSE));
  GLRulers->setOn(s.readBoolEntry("/OdinsEye/GLRulers",TRUE));
  MapSlider->setValue(s.readNumEntry("/OdinsEye/MapRange",8000));
  switch (s.readNumEntry("/OdinsEye/GLObjectSizes",1)) {
  case 0:
      GLObjectsSmall->setOn(TRUE);
      break;
   case 1:
      GLObjectsMedium->setOn(TRUE);
      break;
      default:
      GLObjectsLarge->setOn(TRUE);
      break;
  }     
  switch (s.readNumEntry("/OdinsEye/SortWhen",0)) {
  case 0:
      SortNever->setOn(TRUE);
      break;
   case 1:
      SortPlayer->setOn(TRUE);
      break;
    default:
      SortAlways->setOn(TRUE);
      break;
  }     
}

void FormOdinsEye::saveSettings()
{
  QSettings s;
  QValueList<int> sz;
  s.writeEntry("/OdinsEye/MainWindowW",width());
  s.writeEntry("/OdinsEye/MainWindowH",height());
  
  sz=HSplitter->sizes();
  s.writeEntry("/OdinsEye/SplitH1",(int) *(sz.at(0)));
  s.writeEntry("/OdinsEye/SplitH2",(int) *(sz.at(1)));
  
  sz=VSplitter->sizes();
  s.writeEntry("/OdinsEye/SplitV1",(int) *(sz.at(0)));
  s.writeEntry("/OdinsEye/SplitV2",(int) *(sz.at(1)));
 
  s.writeEntry("/OdinsEye/GLSimpleObjects",GLSimpleObjects->isOn());
  s.writeEntry("/OdinsEye/GLSmoothPolygons",GLSmoothPolygons->isOn());
  s.writeEntry("/OdinsEye/GLSmoothPoints",GLSmoothPoints->isOn());
  s.writeEntry("/OdinsEye/GLSmoothLines",GLSmoothLines->isOn());
  s.writeEntry("/OdinsEye/AutoSelectTarget",AutoSelectTarget->isOn());
  s.writeEntry("/OdinsEye/GroupPlayers",GroupPlayers->isOn());
  s.writeEntry("/OdinsEye/SortDistance",SortDistance->isOn());
  s.writeEntry("/OdinsEye/RotateMap",RotateMap->isOn());
  s.writeEntry("/OdinsEye/GLRulers",GLRulers->isOn());
  s.writeEntry("/OdinsEye/MapRange",MapSlider->value());
  s.writeEntry("/OdinsEye/GLObjectSizes",(int) (GLObjectsSmall->isOn() ? 0 : 
						(GLObjectsMedium->isOn() ? 1 : 2)));	
  s.writeEntry("/OdinsEye/SortWhen",(int) (SortNever->isOn() ? 0 : 
						(SortPlayer->isOn() ? 1 : 2)));	
}


void FormOdinsEye::ReloadMaps_activated()
{
  qWarning("Reloading Maps...");
  oeMapInfo::setup("maps/mapinfo.txt","maps/");
  Map->setMap(NULL);
}


void FormOdinsEye::MapSlider_valueChanged( int range)
{
  Map->range=range;
  Map->dirty();
}



void FormOdinsEye::GroupPlayers_toggled( bool ena )
{
  Map->group_players=ena;
  ListViewMobs->sort();
}


void FormOdinsEye::RotateMap_toggled( bool ena )
{
  Map->rotate_map=ena;
  Map->dirty();
}

void FormOdinsEye::GLObjectSizes_selected( QAction * act)
{
    if (act == GLObjectsSmall)
      Map->setObjectSize(40);
    else if (act == GLObjectsMedium)
      Map->setObjectSize(80);
    else
      Map->setObjectSize(160);
}

void FormOdinsEye::GLRulers_toggled( bool ena )
{
  Map->draw_rulers=ena;
}


void FormOdinsEye::SortWhen_selected( QAction * act)
{
    ListViewMobs->sort();
}

void FormOdinsEye::SortDistance_toggled( bool ena)
{
  Map->sort_distance=ena;
  ListViewMobs->sort();
}
