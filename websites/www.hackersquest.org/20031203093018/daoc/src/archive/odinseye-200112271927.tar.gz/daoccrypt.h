typedef int (*daoccryptfunc)(char *data, int datalen, const char *key, int keylen);
extern daoccryptfunc daoccrypt;
