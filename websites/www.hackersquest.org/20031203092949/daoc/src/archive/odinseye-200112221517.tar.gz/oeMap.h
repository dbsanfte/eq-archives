/*
 * Copyright 2001 Slicer/HackersQuest (slicer@hackersquest.org)
 *
 * This file is part of Odin's Eye.
 *
 * Odin's Eye is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Odin's Eye is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 */

#ifndef _OEMAP_H
#define _OEMAP_H

#include <qgl.h>
#include <qfile.h>
#include "oeConnection.h"
#include "oeMapInfo.h"

class oeMapElement {
  protected:
    QColor color;
    void setColor(QString col);
  public:
    oeMapElement();
    virtual ~oeMapElement();
    virtual void draw(oeMap *map) = 0;
};

class oeMapElementPoint : public oeMapElement {
  protected:
    int x, y, z;
    QString text;
  public:
    oeMapElementPoint(int px, int py, int pz, QString col, QString txt);
    void draw(oeMap *map);
};

class oeMapElementLinePoint {
  public:
    int x, y, z;
    oeMapElementLinePoint(int nx, int ny, int nz);
};

class oeMapElementLine : public oeMapElement {
  protected:
    QPtrList<oeMapElementLinePoint> points;
  public:
    oeMapElementLine(QString col);
    void addPoint(int x, int y, int z);
    void draw(oeMap *map);
};


class oeMap : public QGLWidget {
protected:
  bool is_dirty;
  bool map_load;
  GLuint listTriangle;
  GLuint listCircle;
  oeMapInfo *mi;
  int objsize;
  oeTimeType _lastDarken;
  bool mobDarken;
  QPtrList<oeMapElement> map;
public:
  oeConnection *c;
  int range;
  
  oeMap(QWidget *parent, const char *name);
  ~oeMap();
  void initializeGL();
  void resizeGL(int w, int h);
  void paintGL();
  void mousePressEvent(QMouseEvent *e);
  void setGLColor(double r, double g, double b, int z);
  void setGLColor(QColor col, int z);

  void dirty();
  void setConnection(oeConnection *nc);
  void objRotate(unsigned int daocheading);
  void setMap(oeMapInfo *m);
  void mapRead();
  void textGL(QString text, int x, int y, int z);
  void setObjectSize(int nsize);
  int stringInt(QString s, int sec);
  oeMapInfo *getMap();
  void makeObjects(bool simple);
};


#else
class oeMapElement; 
class oeMapElementPoint;
class oeMapElementLine;
class oeMap;
#endif
