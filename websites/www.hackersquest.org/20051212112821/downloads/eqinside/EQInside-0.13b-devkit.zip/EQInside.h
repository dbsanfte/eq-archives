/*

  EQInside.h -- interface of the 'EQInside.dll'
  Version 0.13 beta September 21th, 1999

  Copyright (C) 1999 Viktor Voroshylo

  This software is provided 'as-is', without any express or implied
  warranty.  In no event will the authors be held liable for any damages
  arising from the use of this software.

  Permission is granted to anyone to use this software for any purpose,
  including commercial applications, subject to the following restrictions:

  1. The origin of this software must not be misrepresented; you must not
     claim that you wrote the original software. If you use this software
     in a product, an acknowledgment in the product documentation would be
     appreciated but is not required.
  2. This notice may not be removed or altered from any distribution.

  Viktor Voroshylo
  rpginside@yahoo.com

  This file contains only public interface and no data members,
  so described classes can not be correctly subclassed by your applications.
*/

#ifndef __EQInsideDLL__EQInside_h__
#define __EQInsideDLL__EQInside_h__

#define EQInsideDllSpec __declspec(dllimport)

typedef int EQ_RESULT;

#define EQINSIDE_OK 0

#define EQINSIDE_INTERNAL_ERROR  -1

#define EQINSIDE_NO_FILE_NAME     1
#define EQINSIDE_CANT_OPEN_FILE   2
#define EQINSIDE_CANT_WRITE_FILE  3
#define EQINSIDE_CANT_READ_FILE   4
#define EQINSIDE_NOT_VALID_FILE   5
#define EQINSIDE_BUFFER_TOO_SMALL 6
#define EQINSIDE_NOT_VALID_DATA   7

#define EQINSIDE_NOT_PACKED      0xFFFFFFFF

class EQDataFileEntry {
  public:
	// Returns the name of the entry
	const char * GetName();

	// Set the name of the entry
	void SetName(const char *);

	// Returns the unpacked length of this entry
	unsigned int GetLength();

	// Returns the packed length of this entry
	// This function will return valid value
	// only if data was read from the packed file and
	// was not modifyed by SetData or LoadData functions
	// In all other cases it will return EQINSIDE_NOT_PACKED
	unsigned int GetPackedLength();

	// Returns the checksum of this entry.
	// Currenty I don't know how to calculate this checksum,
	// and I am not sure of EQ check this field upon loading
	unsigned int GetCheckSum();

	// Returns unpacked data
	// Make sure the buffer is at least as long as result of GetLength()
	//    EQINSIDE_OK
	//    EQINSIDE_NOT_VALID_DATA - packed stream was corrupted
	EQ_RESULT GetData(void * buffer);

	// Saves unpacked data into the file
	// Returns:
	//    EQINSIDE_OK
	//    EQINSIDE_CANT_OPEN_FILE
	//    EQINSIDE_CANT_WRITE_FILE
	EQ_RESULT SaveData(const char * file);

	// Set unpacked data for this entry
	// Data will be correctly packed and saved into the file
	// by EQDataFile::Save function
	void SetData(void * buffer, unsigned int bufLength);

	// Load unpacked data for this entry from the file
	// Data will be correctly packed and saved into the file
	// by EQDataFile::Save function
	// Returns:
	//    EQINSIDE_OK
	//    EQINSIDE_CANT_OPEN_FILE
	//    EQINSIDE_CANT_READ_FILE
	EQ_RESULT LoadData(const char * file);

	// Will be removed as soon as I will find
	// how to calculate it correctly
	void SetCheckSum(unsigned int);
};

class EQInsideDllSpec EQDataFile {
  public:
	// Check if the file is valid 
	// This function didn't really unpack all file
	// but just does quick check of some header information
	// So you still will have have to check return codes from 
	// EQDataFile::Load, EQDataFileEntry::GetData, EQDataFileEntry::SaveData
	// Returns:
	//    EQINSIDE_OK
	//    EQINSIDE_NO_FILE_NAME
	//    EQINSIDE_CANT_OPEN_FILE
	//    EQINSIDE_NOT_VALID_FILE
	EQ_RESULT CheckFile(const char * fileName = NULL);

	// Load directory structure from specified fileName
	// if fileName is empty the file name from last call of
	// Load, Save or CreateEQDataFile will be used
	// If you modified this object all your changes will be lost.
	// Returns:
	//    EQINSIDE_OK
	//    EQINSIDE_NO_FILE_NAME
	//    EQINSIDE_CANT_OPEN_FILE
	//    EQINSIDE_NOT_VALID_FILE
	EQ_RESULT Load(const char * fileName = NULL);

	// Compress all modifyed data and save file to the disk
	// If fileName is empty the file name from last call of
	// Load, Save or CreateEQDataFile will be used
	// Returns:
	//    EQINSIDE_OK
	//    EQINSIDE_NO_FILE_NAME
	//    EQINSIDE_CANT_OPEN_FILE
	//    EQINSIDE_NOT_VALID_FILE
	EQ_RESULT Save(const char * fileName = NULL);

	// Returns the number of directory entries in data file
	unsigned int      GetNumEntries();

	// Returns the selected directory entry
	// If index out of range NULL will be returned
	EQDataFileEntry * GetEntry(unsigned int index);

	// Almost all files have some signature at the end
	// This signature can be different from file to file but it is not a control sum
	// or something like that because many files have the same one.
	// So, I provide this functions in case if you would like to change it
	void * GetSignature(unsigned int & size);
	void   SetSignature(void * data, unsigned int size);

	// Following functions are used to create your own EQData files

	// Will free all menory allocated by this object
	// And create empty directory
	void ResetContent();

	// Will add a new data entry at the end of directory list
	// You can then use GetEntry function to modify it
	// Return: index of new entry
	unsigned int AddEntry();

	// Will delete data entry specifyed by index
	void         DelEntry(unsigned int index);
};

// Use following function to create/destroy EQDataFile objects

EQDataFile * EQInsideDllSpec CreateEQDataFile(const char * fileName = NULL);
void         EQInsideDllSpec DestroyEQDataFile(EQDataFile *);

// following function calculate CheckSum of network packets send/received by EQ client
// (last 4 byte of each packet)

unsigned int EQInsideDllSpec CheckSum(void * buffer, unsigned int size, unsigned int lastSum = 0);

#endif // __EQInsideDLL__EQInside_h__
