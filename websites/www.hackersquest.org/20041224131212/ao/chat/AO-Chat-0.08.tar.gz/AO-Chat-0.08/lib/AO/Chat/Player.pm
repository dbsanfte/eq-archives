package AO::Chat::Player;

require 5.004;
use strict;
use warnings;

sub new {
  my ($proto, $chat, $id, $name) = @_;
  my $class = ref($proto) || $proto;
  my $self = {};
  if (! $id || $id == 0 || $id == 0xFFFFFFFF) {
    return undef;
  }
  $self->{NAME}=$name;
  $self->{ID}=$id;
  $self->{CHAT}=$chat;
  bless($self,$class);
  return $self;
}

sub name {
  return $_[0]->{NAME};
}

sub tell {
  my ($self, $message, $blob)=@_;
  if (! ref $blob || ! $blob->isa("AO::Chat::Blob")) {
    $blob="\0";
  } else {
    $blob = $blob->blob(1);
  }
  $self->{CHAT}->queue(new AO::Chat::Packet(30,$self->{ID},$message,$blob));
}

sub addbuddy {
  my ($self,$list)=@_;
  if (! defined $list) {
    $list=0;
  }
  $self->{CHAT}->send(new AO::Chat::Packet(40,$self->{ID},pack("C",($list ? 1 : 0))));
}

sub rembuddy {
  my ($self)=@_;
  $self->{CHAT}->send(new AO::Chat::Packet(41,$self->{ID}));
}

sub pginvite {
  my ($self)=@_;
  $self->{CHAT}->send(new AO::Chat::Packet(50,$self->{ID}));
}

sub pgkick {
  my ($self)=@_;
  $self->{CHAT}->send(new AO::Chat::Packet(51,$self->{ID}));
}

sub pgjoin {
  my ($self)=@_;
  $self->{CHAT}->send(new AO::Chat::Packet(52,$self->{ID}));
}

sub pgmsg {
  my ($self,$msg,$blob)=@_;
  if (! ref $blob || ! $blob->isa("AO::Chat::Blob")) {
    $blob = '';
  } else {
    $blob = $blob->blob();
  }
  $self->{CHAT}->send(new AO::Chat::Packet(57,$self->{ID},$msg,$blob));
}

1;

__END__

# Below is stub documentation for your module. You better edit it!

=head1 NAME

AO::Chat::Player - Methods dealing with AO players.

=head1 SYNOPSIS

  use AO::Chat;

  package MyCallback;

  use base qw(AO::Chat::Callback);

  sub tell {
    my ($self,$player,$message,$blob)=@_;
    print "Private Message :: $message\n";
    $player->tell("Hi");
  }

=head1 DESCRIPTION

This is the interface that deals with other players in the AO universe.
Methods here cover sending messages and the administration of buddies and
private chat groups. 
You will never create a player object on your own, you will either use
AO::Chat::player() or pick it up from a passed parameter in the callback
functions.

=head1 METHODS

=over 4

=item name()

Returns player's name.

=item tell("Message" [,$blob])

Sends a /tell to the player. The blob, if included, must be a valid blob.
Please note that the server limits the ammount of /tells that can be sent in
a given time period, so no tells are sent immediately; they are queued on
the AO::Chat object. The AO::Chat::packet() function handles dequeuing in a
timely manner.

=item addbuddy($list)

Adds this player to your buddy list. If $list is 1, the player will be added as a
permanent buddy, otherwise it will be just a '?' buddy.

=item rembuddy()

Removed this player from your buddy list.

=item pginvite()

Invites this player to your private chat group.

=item pgkick()

Kicks this player from your private chat group.

=item pgjoin()

Join the private chat group of this player.

=item pgmsg("Message" [,$blob])

Sends a message to the private chat group of this player. The player can
of course be yourself (See AO::Chat::me()). The blob, if included, must be a
valid blob.

=back

=head1 AUTHOR

Slicer, slicer@ethernalquest.org

=head1 SEE ALSO

AO::Chat, AO::Chat::Callback, AO::Chat::Group, AO::Chat::Blob, perl(1).

=cut

