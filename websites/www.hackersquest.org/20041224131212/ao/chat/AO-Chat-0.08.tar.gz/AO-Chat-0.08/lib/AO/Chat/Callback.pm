package AO::Chat::Callback;

require 5.004;
use strict;
use warnings;

sub new {
  my ($proto) = @_;
  my $class = ref($proto) || $proto;
  my $self = {};
  bless($self,$class);
  return $self;
}

sub chat {
  return $_[0]->{CHAT};
}

sub tell {
}

sub say {
}

sub anonsay {
}

sub system {
}

sub addbuddy {
}

sub rembuddy {
}

sub pginvited {
}

sub pgkicked {
}

sub pgpart {
}

sub pgclientjoin {
}

sub pgclientpart {
}

sub pgmsg {
}

sub groupjoin {
}

sub grouppart {
}

sub groupmsg {
}

sub lag {
}

1;

__END__

# Below is stub documentation for your module. You better edit it!

=head1 NAME

AO::Chat::Callback - Parent object for callback objects.

=head1 SYNOPSIS

  use AO::Chat;

  package MyCallback;

  use base qw(AO::Chat::Callback);

  sub groupmsg {
    my ($self,$player,$message,$blob)=@_;
    print "Group Message :: $message\n";
    $group->msg("Hi");
  }

=head1 DESCRIPTION

To utilize the preparsed callback functions, create your subclass of this
module and pass an instance of it when you create a new AO::Chat object. For
each received packet, different functions on this object will then be
called. The parent object just defined all of these function as empty ones,
with the exception of chat().

For all the methods here, $player and $pg will refer to a valid AO::Chat::Player
object, and $group will refer to a valid AO::Chat::Group object. Likewise,
$blob will either refer to a valid AO::Chat::Blob object, or will be undef.

=head1 METHODS

=over 4

=item chat()

Convenience function to return the current AO::Chat object.

=item tell($player, $message, $blob)

This method will be called when a /tell is received.

=item say($player, $message, $blob)

This method is called when someone did a /say near you.

=item anonsay($source, $message, $blob)

This method is called when a nonplayer did a /say near you. $source is the
text representation of the originator.

=item system($message)

This method is called when you receive a system message.

=item addbuddy($player, $online, $listed)

This method is called when there's a change in a buddy's status. $online
represents whether the buddy is online or offline, and $listed represents
whether the buddy is listed in the "upper" part of the buddy list or is
simply a "?" buddy.

=item rembuddy($player)

This method is called when a buddy has been removed from your buddy list,
usually at your request.

=item pginvited($pg)

This method is called when you have been invited to another player's private
chat group.

=item pgkicked($pg)

This method is called when you have been kicked from another player's
private chat group.

=item pgpart($pg)

This method is called when you have left another player's private chat
group.

=item pgclientjoin($pg, $player)

This method is called when a player joins your or another player's private
chat group.

=item pgclientpart($pg, $player)

This method is called when a player leaves your or another player's private
chat group.

=item pgmsg($pg, $player, $message, $blob)

This method is called when a player says something in a private chat group.

=item groupjoin($group)

This method is called when you join a message group.

=item groupmsg($group, $player, $message, $blob)

This method is called when a player says something in a message group.

=item lag($lag)

This method is called when a AO::Chat::ping() request returns. Note that the
system automatically calls ping() every now and then, so this method might
be called a lot.

=back

=head1 AUTHOR

Slicer, slicer@ethernalquest.org

=head1 SEE ALSO

AO::Chat, AO::Chat::Group, AO::Chat::Player, perl(1).

=cut
