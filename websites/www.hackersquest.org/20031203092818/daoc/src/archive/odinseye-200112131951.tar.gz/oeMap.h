/*
 * Copyright 2001 Slicer/HackersQuest (slicer@hackersquest.org)
 *
 * This file is part of Odin's Eye.
 *
 * Odin's Eye is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Odin's Eye is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 */

#ifndef _OEMAP_H
#define _OEMAP_H

#include <qgl.h>
#include <qfile.h>
#include "oeConnection.h"
#include "oeMapInfo.h"

class oeMap : public QGLWidget {
protected:
  bool is_dirty;
  bool map_load;
  GLuint listTriangle;
  GLuint listMap;
  GLuint listCircle;
  oeMapInfo *mi;
  bool simple_render;
  int objsize;
public:
  int range;
  oeConnection *c;
  bool group_players;
  
  bool smooth_lines, smooth_polygons, smooth_points;

  oeMap(QWidget *parent, const char *name);
  ~oeMap();
  void initializeGL();
  void resizeGL(int w, int h);
  void paintGL();
  void mousePressEvent(QMouseEvent *e);

  void dirty();
  void setConnection(oeConnection *nc);
  void objRotate(unsigned int daocheading);
  void setMap(oeMapInfo *m);
  void mapToGL();
  void textGL(QString text, int x, int y, int z);
  void setObjectSize(int nsize);
  int stringInt(QString s, int sec);
  oeMapInfo *getMap();
  void makeObjects(bool simple);
};


#else
class oeMap;
#endif
