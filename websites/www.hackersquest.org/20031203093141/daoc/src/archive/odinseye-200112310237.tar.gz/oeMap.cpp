/*
 * Copyright 2001 Slicer/HackersQuest (slicer@hackersquest.org)
 *
 * This file is part of Odin's Eye.
 *
 * Odin's Eye is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Odin's Eye is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 */


#include "oeMap.h"
#include "oeMob.h"
#include "oeLineSimplify.h"
#include <math.h>
#include <GL/glut.h>
#include <GL/glu.h>
#include <qaction.h>
#include <qinputdialog.h>
#include <qregexp.h>
#include <qmessagebox.h>
#include <qtextstream.h>
#include <qslider.h>

oeMap::oeMap(QWidget *parent, const char *name)
 : QGLWidget(QGLFormat(DoubleBuffer|DepthBuffer|Rgba|DirectRendering),parent,name) {
  objsize = 100; 
  range = 8000;
  c = NULL; 
  is_dirty = true; 
  map_load = false; 
  mobDarken = false;
  _lastDarken = 0;
  mi = NULL;
  edit_xofs = edit_yofs = 0;
  map.setAutoDelete(true);
}

oeMap::~oeMap() {
  if (mi)
    delete mi;
}

void oeMap::dirty() {
  if (! is_dirty) { 
    qApp->postEvent(this, new QPaintEvent(QRect(0,0,0,0)));
    is_dirty = true;
  }
}

void oeMap::setConnection(oeConnection *nc) {
  c=nc;
}

void oeMap::setMap(oeMapInfo *m) {
  if (mi)
    delete mi;
 
  mi=m;
  map_load=true;
  editelem = NULL;
  mode_edit = FALSE;
  c->oe->EditMode->setOn(FALSE);
}

void oeMap::setObjectSize(int nsize) {
  objsize=nsize;
  makeObjects(prefs.map_simple);
}

oeMapInfo *oeMap::getMap() {
   return mi;
}

void oeMap::makeObjects(bool simple) {
  int w=objsize;
  int l=w*2;

  glNewList(listTriangle, GL_COMPILE);

  glBegin(GL_TRIANGLES);

  if (simple) {
    glNormal3f(0.0,0.0,1.0);
    glVertex3i(w,-w,0);
    glVertex3i(-w,-w,0);
    glVertex3i(0,l,0);
  } else {
    glNormal3f(l+w,w,l);
    glVertex3i(w,-w,0);
    glVertex3i(0,0,w);
    glVertex3i(0,l,0);

    glNormal3f(-(l+w),w,l);
    glVertex3i(0,0,w);
    glVertex3i(-w,-w,0);
    glVertex3i(0,l,0);

    glNormal3f(0,-w,w);
    glVertex3i(w,-w,0);
    glVertex3i(-w,-w,0);
    glVertex3i(0,0,w);
  }

  glEnd();

  glEndList();

  glNewList(listCircle, GL_COMPILE);
  glBegin(GL_TRIANGLES);
  glNormal3f(0.0,0.0,1.0);

  glVertex3f(w*1.5,-w*1.5,-1);
  glVertex3f(-w*1.5,-w*1.5,-1);
  glVertex3f(0,l*1.5,-1);

  glEnd();
  glEndList();
}


void oeMap::initializeGL() {
  static GLfloat lightpos[4]={0.5,-1.0,1.0,0.0};
  static GLfloat diffuse[4]={0.5,0.5,0.5,1.0};
  static GLfloat ambient[4]={-0.0,-0.0,-0.0,1.0};
  static GLfloat material[4]={0.5,0.5,0.5,1.0};

  if (! format().doubleBuffer())
    qWarning("Single Buffer GL only - Flicker might happen");
  if (! format().depth())
    qWarning("NO GL DEPTH BUFFER - No polygon sorting");
  if (! format().directRendering()) 
    qWarning("No Direct Render - This will be SLOW");

  glClearColor(0.0,0.0,0.0,0.0);
  glDisable(GL_CULL_FACE);

  glShadeModel(GL_SMOOTH);
  glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);

  glEnable(GL_LIGHTING);
  glEnable(GL_LIGHT0);
  glEnable(GL_COLOR_MATERIAL);
  glEnable(GL_NORMALIZE);
  
  glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
  glLightfv(GL_LIGHT0, GL_POSITION, lightpos);
  glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
  glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
  glMaterialfv(GL_FRONT, GL_AMBIENT, material);
  glMaterialfv(GL_FRONT, GL_DIFFUSE, material);

  listTriangle=glGenLists(1);
  listCircle=glGenLists(1);

  makeObjects(prefs.map_simple);
}

void oeMap::resizeGL(int w, int h) {
  glViewport(0,0,w,h);
}

void oeMap::paintGL() {
  const QPtrDict<oeMob> mobs=c->getMobs();
  QPtrDictIterator<oeMob> mobi(mobs);
  oeMapElement *mapel;
  oeMob *m;
  int quanta, ldif;
  int l;
  double playerhead;
  double playerrad;
  int minx, maxx, miny,maxy;

  if (map_load) {
    map_load=false;
    if (mi) {
      mapRead();
    }
  }
  
  if (prefs.map_simple) {
    glClear(GL_COLOR_BUFFER_BIT);
    glDisable(GL_BLEND);
  } else {
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    glEnable(GL_BLEND);
  }

  if (prefs.gl_smooth_lines)
    glEnable(GL_LINE_SMOOTH);
  else
    glDisable(GL_LINE_SMOOTH);
  
  if (prefs.gl_smooth_points)
    glEnable(GL_POINT_SMOOTH);
  else
    glDisable(GL_POINT_SMOOTH);

  if (prefs.gl_smooth_polygons)
    glEnable(GL_POLYGON_SMOOTH);
  else
    glDisable(GL_POLYGON_SMOOTH);

  glDisable(GL_LIGHTING);

  playerhead=(c->playerhead * 360.0) / 4096.0;
  playerrad=playerhead * M_PI / 180.0;

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  if (mi)
    glRotatef(mi->getRotate() * 1.0,0.0,0.0,1.0);
  if (prefs.map_rotate)
    glRotatef(180.0+playerhead, 0.0, 0.0, 1.0);
  glRotatef(180.0,1.0,0.0,0.0);

  minx=c->playerx - range + edit_xofs;
  maxx=c->playerx + range + edit_xofs;
  miny=c->playery - range + edit_yofs;
  maxy=c->playery + range + edit_yofs;
  glOrtho(minx, maxx, miny, maxy,0.0,-25000.0);
// (c->playerx-range) + edit_xofs,(c->playerx+range) + edit_xofs,(c->playery-range) + edit_yofs,(c->playery+range)+edit_yofs,0.0,-25000.0);

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

  if (! mode_edit)
    editelem = NULL;

  glLineWidth(1.0);
  glPointSize(3.0);

  for (mapel=map.first(); mapel; mapel=map.next()) {
     if (mapel->visible(minx, maxx, miny, maxy))
       mapel->cached_draw(this);
  }

  if (prefs.map_rulers) {
    qglColor( darkGray );
    glLineWidth ( 1.0 );
    glBegin(GL_LINES);
    glVertex3i(c->playerx - range * 2, c->playery, 500);
    glVertex3i(c->playerx + range * 2, c->playery, 500);
    glVertex3i(c->playerx, c->playery - range * 2, 500);
    glVertex3i(c->playerx, c->playery + range * 2, 500);
    glVertex3f(c->playerx * 1.0, c->playery * 1.0, 500.0);
    glVertex3f(c->playerx + cos(playerrad + M_PI_2) * range * 2, c->playery + sin(playerrad + M_PI_2) * range * 2, 500.0);
    glEnd();
  }

  if (! prefs.map_simple ) {
    glEnable(GL_LIGHTING);
    glEnable(GL_DEPTH_TEST);
  } else {
    glDisable(GL_DEPTH_TEST);
  }

  qglColor( white );

  glPushMatrix();
  glTranslated(c->playerx,c->playery,c->playerz);
  objRotate(c->playerhead);
  glCallList(listTriangle);
  glPopMatrix();

  if ((oeTick - _lastDarken) > 250) {
    mobDarken = ! mobDarken;
    _lastDarken = oeTick;
  }

  for(;mobi.current();++mobi) {
    m=mobi.current();

    if (m->isCurrent()) {
      glPushMatrix();
      glTranslated(m->getX(),m->getY(),m->getZ());
      objRotate(m->getHead());

      if (! m->isMob()) {
        if (m->isDead()) {
          setGLColor (m->getColor().dark(160), m->getZ());
        } else if (! m->isInvader()) {
          setGLColor (m->getColor(), m->getZ());
        } else {
          setGLColor ( (mobDarken) ? m->getColor().dark(150) : m->getColor().light(150), m->getZ());
        }
        glCallList(listCircle);
      }

      if (c->playerlevel <= 10)
        quanta=1;
      else if (c->playerlevel <= 20)
        quanta=2;
      else if (c->playerlevel <= 35)
        quanta=3;
      else
        quanta=5;
      ldif=quanta;
      l=m->getLevel();
      if (l <= (c->playerlevel - ldif * 3)) 
        setGLColor(0.5,0.5,0.5,m->getZ());
      else if (l <= (c->playerlevel - ldif * 2))
        setGLColor(0.0,1.0,0.0,m->getZ());
      else if (l <= (c->playerlevel - ldif * 1))
        setGLColor(0.0,0.0,1.0,m->getZ());
      else if (l <= c->playerlevel)
        setGLColor(1.0,1.0,0.0,m->getZ());
      else if (l <= (c->playerlevel + ldif * 1))
        setGLColor(1.0,0.5,0.0,m->getZ());
      else if (l <= (c->playerlevel + ldif * 2))
        setGLColor(1.0,0.0,0.0,m->getZ());
      else 
        setGLColor(1.0,0.0,1.0,m->getZ());

      glCallList(listTriangle);
      glPopMatrix();
    }
    m->stale();
  }

  m=mobs.find((void *)c->selectedid);
  if (m && m->isCurrent()) {
    qglColor( white );
    glLineWidth ( 2.0 );
    glBegin(GL_LINES);
    glVertex3i(c->playerx,c->playery,c->playerz);
    glVertex3i(m->getX(),m->getY(),m->getZ());
    glEnd();
  }

  is_dirty = false;

  glFlush();
}

void oeMap::mousePressEvent(QMouseEvent *e) {
  oeMob *m;
  unsigned int bestid = 0;
  double bestdist=0.0;
  double xdif;
  double ydif;
  GLdouble cx;
  GLdouble cy;
  GLdouble cz;
  double thisdist;
  GLdouble projmatrix[16];
  GLdouble modmatrix[16];
  GLint viewport[4];
  oeMapElement *mapel;

  const QPtrDict<oeMob> mobs=c->getMobs();
  QPtrDictIterator<oeMob> mobi(mobs);

  makeCurrent();

  glGetDoublev(GL_PROJECTION_MATRIX, projmatrix);
  glGetDoublev(GL_MODELVIEW_MATRIX, modmatrix);
  glGetIntegerv(GL_VIEWPORT, viewport);
  
  gluUnProject(e->x(), size().height()-e->y(), 100, modmatrix, projmatrix, viewport, &cx, &cy, &cz);

  if (mode_edit) {
    c->selectID(0);
    editelem=NULL;
    bestdist = -1.0;
    for(mapel=map.first();mapel;mapel=map.next()) {
      thisdist=mapel->clickAt((int)cx,(int)cy,0);
      if ((thisdist > 0.0) && ((bestdist < 0.0) || (thisdist < bestdist))) {
        bestdist=thisdist;
        editelem=mapel;
      }
    }
    if (editelem) {
      QAction *act=(QAction *) c->oe->EditColors->child(QString("color_").append(editelem->getColor()));
      if (act) 
        act->setOn(TRUE);
      if (editelem->getElemType() == oeMapElement::Line) {
        c->oe->EditLineFilled->setOn(((oeMapElementLine *)editelem)->filled);
        ((oeMapElementLine *)editelem)->dirty = TRUE;
      }
    }
  } else {
    for(; mobi.current(); ++mobi) {
      m=mobi.current();
      if (m->isCurrent()) {
        xdif=m->getX()-cx;
        ydif=m->getY()-cy;
        thisdist=sqrt(xdif*xdif+ydif*ydif);
        if (! bestid || (thisdist < bestdist)) {
          bestid=m->getInfoID();
          bestdist=thisdist;
        }
      }
    }

    if (bestid) {
      c->selectID(bestid);
    }
  }
}

void oeMap::keyPressEvent(QKeyEvent *e) {
  double angle=0.0;
  double dist=c->oe->MapSlider->value();

  switch( e->key() ) {
    case Qt::Key_Right:
      angle=0.0;
      break;
    case Qt::Key_Up:
      angle=1.0;
      break;
    case Qt::Key_Left:
      angle=2.0;
      break;
    case Qt::Key_Down:
      angle=3.0;
      break;
    case Qt::Key_Home:
      edit_xofs = 0;
      edit_yofs = 0;
      dirty();
      return;
      break;
    case Qt::Key_Next:
      c->oe->MapSlider->setValue((int)(dist * 1.5));
      return;
      break;
    case Qt::Key_Prior:
      c->oe->MapSlider->setValue((int)(dist / 1.5));
      return;
      break;
    default:
      e->ignore();
      return;
      break;
  }
  if (mi)
    angle = (mi->getRotate() / 90.0 ) + angle;
  angle = angle * M_PI / 2.0;
  edit_xofs += (int)(cos(angle)*dist / 2.0);
  edit_yofs -= (int)(sin(angle)*dist / 2.0);
  dirty();
}

void oeMap::setGLColor(double r, double g, double b, int z) {
  double col[4];
  
  col[0]=r;
  col[1]=g;
  col[2]=b;
  setGLColor(col, (double) z);
  glColor4d(col[0],col[1],col[2],col[3]);
}

void oeMap::setGLColor(GLdouble *col, double z) {
  double darken;

  if (! prefs.map_fade) {
     col[3]=1.0;
     return;
  }
  
  darken=fabs(c->playerz - z) / 500.0;
  if (darken < 0.60) {
    darken=1.0 - darken;
  } else {
    darken=0.40;
  }

  if (prefs.map_simple) {
    col[3]=1.0;
    col[0]=col[0] * darken;
    col[1]=col[1] * darken;
    col[2]=col[2] * darken;
  } else {
    col[3]=darken;
  }
}

void oeMap::setGLColor(QColor col, int z) {
  setGLColor(col.red() / 255.0, col.green() / 255.0, col.blue() / 255.0, z);
}


void oeMap::objRotate(unsigned int daocheading) {
  double r=daocheading;
  r*=360;
  r/=0x1000;
  glRotatef(r,0.0,0.0,1.0);
}

int oeMap::stringInt(QString s, int sec) {
  bool ok;
  int v=s.section(",",sec,sec).toInt(&ok, 10);
  if (!ok) {
    qWarning("Line %s contains nonnumber %s",(const char *)s, (const char *)s.section(",",sec,sec));
    return 0;
  }
  return v;
}


#define SEC(x) (line.section(",",x,x))

void oeMap::mapRead() {
  QString line;
  QString cmd;
  QString color;
  QString title;
  oeMapElementPoint *mappoint;
  oeMapElementLine *mapline;
  int xadd;
  int yadd;
  int num;
  int x;
  int y;
  int z;
  int i;

  editelem=NULL;

  map.clear();

  QFile f(mi->getName());
  if (! f.open(IO_ReadOnly)) {
    qWarning("Failed to open map named %s",(const char *) mi->getName());
    return;
  }

  f.readLine(line, 0x10000);

  xadd=mi->getBaseX();
  yadd=mi->getBaseY();


  while (f.readLine(line, 0x10000)!=-1) {
    line=line.simplifyWhiteSpace().stripWhiteSpace();
    cmd=line.section(",",0,0);
    if (cmd.length() != 1) {
      qWarning("MapRead: %s is not a command",(const char *)cmd);
    }
    switch (cmd[0].latin1()) {
      case 'M':
      case 'F':
        title=SEC(1);
        color=SEC(2).lower();
        mapline=new oeMapElementLine(color, (cmd[0].latin1() == 'M') ? FALSE : TRUE);
        mapline->setText(title);
        num=stringInt(line,3);
        for(i=0;i<num;i++) {
          x=stringInt(line, i*3+4);
          y=stringInt(line, i*3+5);
          z=stringInt(line, i*3+6);
          mapline->addPoint(abs(x) + xadd, abs(y) + yadd, z);
        }
        if (prefs.map_autosimplify)
          mapline->DouglasPeucker(prefs.map_autosimplifyrange);
        map.append(mapline);

        break;
      case 'P':
        title=SEC(1);
        color=SEC(2).lower();
        x=stringInt(line,3);
        y=stringInt(line,4);
        z=stringInt(line,5);
        x=abs(x)+xadd;
        y=abs(y)+yadd;

        mappoint=new oeMapElementPoint(x,y,z,color,title);
        map.append(mappoint);

        break;
      default:
        qWarning("Unhandled command %c",cmd[0].latin1());
        break;
    }
  }
}

void oeMap::editLineNew() {
  editelem=new oeMapElementLine(editcolor, FALSE);
  map.append(editelem);
}

void oeMap::editLinePoint() {
  if (! editelem || (editelem->getElemType() != oeMapElement::Line))
    return;
  ((oeMapElementLine *)editelem)->addPoint(c->playerx, c->playery, c->playerz);
  dirty();
}

void oeMap::editPointNew() {
  bool ok = FALSE;
  QString text;

  text=QInputDialog::getText("Point information", "What text should appear at the point?", QLineEdit::Normal, QString::null, &ok, this);
  if (ok) {
    editelem=new oeMapElementPoint(c->playerx,c->playery,c->playerz,editcolor,text);
    map.append(editelem);
  }
  dirty();
}

void oeMap::editDelete() {
  if (! editelem)
    return;
  if (editelem->getElemType() == oeMapElement::Point) {
    map.remove(editelem);
    editelem=NULL;
  } else {
    ((oeMapElementLine *)editelem)->deletePoint();
  }
  dirty();
}

void oeMap::editRename() {
  bool ok;
  QString text;

  if (! editelem) 
    return;

  text=QInputDialog::getText("New Name", "What's the new name?", QLineEdit::Normal, editelem->getText(), &ok, this);
  if (ok) {
    editelem->setText(text);
    dirty();
  }
}

void oeMap::editClean() {
  QStringList lst;
  QString str;
  oeMapElement *elem;
  bool wipe;
  editelem = NULL;

  do {
    lst.clear();
    wipe=false;
    for(elem=map.first(); elem && ! wipe; elem=map.next()) {
      if (! elem->valid()) {
        qWarning("Element named %s was invalid",(const char *) elem->getText());
        wipe=true;
      } else {
        str=elem->getString(0,0);
        for ( QStringList::Iterator it = lst.begin(); !wipe && (it != lst.end()); ++it ) {
          if (str.compare(*it)==0) {
            qWarning("Found identical objects in map named %s -- Last one removed",(const char *)elem->getText());
            wipe=true;
          }
        }
        if (! wipe)
          lst+=str;
      }
      if (wipe) {
        map.remove(elem);
      }
    }
  } while (wipe);

  dirty();
}

double oeMap::editSimplify() {
  double worstw;
  double w;
  oeMapElement *elem;

  editClean();

  worstw=-1.0;

  for(elem=map.first(); elem; elem=map.next()) {
    if (elem->getElemType() == oeMapElement::Line) {
      w=((oeMapElementLine *)elem)->weight();
      if ((w >= 0.0) && ((worstw < 0.0) || (w<worstw))) {
        editelem=elem;
        worstw=w;
      }
    }
  }
  editMovePoint();
  return worstw;
}

void oeMap::editMovePoint() {
  if (!editelem)
    return;
  edit_xofs=editelem->x() - c->playerx;
  edit_yofs=editelem->y() - c->playery;
}

void oeMap::editSave() {
  if (! mi)
    return;

  editClean();

  QStringList firstline;
  QStringList lst;
  QStringList filename;
  QString fname, oriname;
  oeMapElement *elem;

  filename=QStringList::split("/",mi->getName());
  fname=filename.last().replace(QRegExp("\\.map$"),"");
  oriname=fname.append("");
  fname=fname.replace(QRegExp("_")," ");

  firstline+=fname;
  firstline+=oriname;
  firstline+=QString::number(0);  
  firstline+=QString::number(0);  
  firstline+=QString::number(0);  
  firstline+=QString::number(0);  
  firstline+=QString::number(0);  
  firstline+=QString::number(0);  

  for(elem=map.first(); elem; elem=map.next()) {
   lst+=elem->getString(mi->getBaseX(),mi->getBaseY());
  }

  lst.sort();
  lst.prepend(firstline.join(","));

  fname=lst.join("\n");

  QFile f(mi->getName());
  if (! f.open(IO_WriteOnly)) {
    qWarning("Could not open %s for writing",(const char *)mi->getName());
    return;
  }
  QTextStream ts(&f);
  ts << fname;
  QMessageBox::information(this, "Odin's Eye Map", "Map saved successfully");
}

void oeMap::editSetColor(QString col) {
  if (mode_edit && editelem) {
    editelem->setColor(col);
  }
  editcolor=col;
}

void oeMap::editSetFilled(bool nfilled) {
  if (mode_edit && editelem && editelem->getElemType() == oeMapElement::Line) {
    ((oeMapElementLine *)editelem)->filled=nfilled;
    ((oeMapElementLine *)editelem)->dirty=TRUE;
    dirty();
  }
}

void oeMap::editGotoFirst() {
  if (mode_edit && editelem && editelem->getElemType() == oeMapElement::Line) {
    ((oeMapElementLine *)editelem)->gotoFirst();
    dirty();
  }
}

void oeMap::editGotoLast() {
  if (mode_edit && editelem && editelem->getElemType() == oeMapElement::Line) {
    ((oeMapElementLine *)editelem)->gotoLast();
    dirty();
  }
}


oeMapElement::oeMapElement() {
  lastz = 0;
  lastfade = FALSE;
  displist = -1;
}

oeMapElement::~oeMapElement() {
  uncache();
}

void oeMapElement::uncache() {
  if (displist != -1) {
    glDeleteLists(displist, 1);
    displist = -1;
  }
}  

void oeMapElement::cached_draw(oeMap *map) {

  if ((displist != -1) && (lastedmode == map->mode_edit) && (lastedit != this) && (map->editelem != this) && (lastfade == prefs.map_fade) && (lastfill == prefs.map_fill) && (! prefs.map_fade || (map->c->playerz == lastz))) {
    glCallList(displist);
    return;
  }

  lastfade = prefs.map_fade;
  lastfill = prefs.map_fill;
  lastedit = map->editelem;
  lastedmode = map->mode_edit;
  lastz=map->c->playerz;

  if (displist == -1) {
    glGetError();
    displist = glGenLists(1);
    if (glGetError() != GL_NO_ERROR) {
      qWarning("Failed to allocate display lists!");
      displist = -1;
    }
  }

  if (displist != -1) {
    glNewList(displist, GL_COMPILE_AND_EXECUTE);
  }

  draw(map);

  if (displist != -1) {
    glEndList();
  }
}


void oeMapElement::setColor(QString col) {
  colorstring=col;
  color=QColor(col);
  r=color.red() / 255.0;
  g=color.green() / 255.0;
  b=color.blue() / 255.0;
}

QString oeMapElement::getColor() {
  return colorstring;
}

void oeMapElement::setText(QString ntext) {
  text=ntext;
}

QString oeMapElement::getText() {
  return text;
}

bool oeMapElement::valid() {
  int h,s,v;

  color.hsv(&h,&s,&v);
  if (text.length() == 0) {
    return FALSE;
  } else if (v < 10) {
    return FALSE;
  }
  return TRUE;
}

oeMapElementPoint::oeMapElementPoint(int nx, int ny, int nz, QString col, QString txt) {
  xpos=nx;
  ypos=ny;
  zpos=nz;
  setColor(col);
  text=txt;
}

oeMapElement::ElementType oeMapElementPoint::getElemType() {
  return Point;
}

void oeMapElementPoint::draw(oeMap *map) {
  unsigned int i;

  map->setGLColor(color, zpos);

  if ((! map->mode_edit) || (map->editelem != this)) {
   glBegin(GL_POINTS);
   glVertex3i(xpos,ypos,zpos);
   glEnd();
  } else {
   glPointSize(8.0);
   glBegin(GL_POINTS);
   glVertex3i(xpos,ypos,zpos);
   glEnd();
   glPointSize(3.0);
  }
  map->setGLColor(1.0,1.0,1.0,zpos);

  glRasterPos3i(xpos+50,ypos+20,zpos);
  for (i=0;i<text.length();i++) 
    glutBitmapCharacter(GLUT_BITMAP_HELVETICA_10, text[i].latin1());
}

double oeMapElementPoint::clickAt(int xv, int yv, int) {
  double xd, yd;
  xd=xpos-xv;
  yd=ypos-yv;
  return sqrt(xd*xd+yd*yd);
}

QString oeMapElementPoint::getString(int basex, int basey) {
  QStringList lst;
  lst+="P";
  lst+=text;
  lst+=colorstring;
  lst+=QString::number(xpos - basex);
  lst+=QString::number(ypos - basey);
  lst+=QString::number(zpos);
  return lst.join(",");
}

int oeMapElementPoint::x() {
  return xpos;
}

int oeMapElementPoint::y() {
  return ypos;
}

bool oeMapElementPoint::visible(int minx, int maxx, int miny, int maxy) {
  return ((xpos > minx) && (xpos < maxx) && (ypos > miny) && (ypos < maxy));
}

oeMapElementLinePoint::oeMapElementLinePoint(int nx, int ny, int nz) {
  x=nx;
  y=ny;
  z=nz;
}


oeMapElementLine::oeMapElementLine(QString col, bool nfilled) {
  setColor(col);
  selnode=0;
  points.setAutoDelete(TRUE);
  text="Line";
  filled=nfilled;
  dirty = TRUE;
}

oeMapElement::ElementType oeMapElementLine::getElemType() {
  return Line;
}

void oeMapElementLine::addPoint(int x, int y, int z) {
  selnode++;
  if (selnode>=points.count())
    selnode=points.count();
  points.insert(selnode,new oeMapElementLinePoint(x, y, z));
  dirty = TRUE;
}

void oeMapElementLine::deletePoint() {
  if (points.count() == 0)
    return;
  points.remove(selnode);
  if (selnode > (points.count()-1))
    selnode=points.count()-1;
  dirty = TRUE;
}

void oeMapElementLine::changed() {
  oeMapElementLinePoint *p;

  bounds_minx = bounds_maxx = bounds_miny = bounds_maxy = 0;
  for (p=points.first(); p; p=points.next()) { 
    if (! bounds_minx || (p->x < bounds_minx)) 
      bounds_minx = p->x;
    if (! bounds_maxx || (p->x > bounds_maxx)) 
      bounds_maxx = p->x;
    if (! bounds_miny || (p->y < bounds_miny)) 
      bounds_miny = p->y;
    if (! bounds_maxy || (p->y > bounds_maxy)) 
      bounds_maxy = p->y;
  }

  uncache();

  dirty = FALSE;
}

bool oeMapElementLine::visible(int minx, int maxx, int miny, int maxy) {
  if (dirty)
    changed();

  return ( ( ((bounds_minx > minx) && (bounds_minx < maxx)) || ((bounds_maxx > minx) && (bounds_maxx < maxx)) || ((bounds_minx < minx) && (bounds_maxx > maxx))) &&
           ( ((bounds_miny > miny) && (bounds_miny < maxy)) || ((bounds_maxy > miny) && (bounds_maxy < maxy)) || ((bounds_miny < miny) && (bounds_maxy > maxy))));
}

void oeMapElementLine::DouglasPeucker(double sigma) {
  oeLineSimplify s;
  oeMapElementLinePoint *p;
  oeLineSimplifyPoint *ps;

  for(p=points.first(); p ; p=points.next()) {
    s.add(p->x,p->y,p->z);
  }
  s.DouglasPeucker(sigma);
  points.clear();
  for(ps=s.points.first(); ps ; ps=s.points.next()) {
    addPoint((int) ps->x, (int) ps->y, (int) ps->z);
  }
  dirty = TRUE;
}

bool oeMapElementLine::tessError;

void oeMapElementLine::ErrorCallback(GLenum err) {
  qWarning("Tesselation failed with error %s",gluErrorString(err));
  tessError = TRUE;
}

void oeMapElementLine::VertexCallback(void *vertex_data) {
  double *glpos=(double *)vertex_data;
  glColor4d(glpos[3],glpos[4],glpos[5],glpos[6]);
  glVertex3d(glpos[0],glpos[1],glpos[2]);
}

void oeMapElementLine::CombineCallback(GLdouble coords[3], void *vertex_data[4], GLfloat weight[4], void **outData) {
  int i, j;

  double **vpos=(double **)vertex_data;

  oeMapElementLinePoint *p=new oeMapElementLinePoint((int) coords[0], (int) coords[1], (int) coords[2]);
  p->deleteLater();

  p->glpos[0]=coords[0];
  p->glpos[1]=coords[1];
  p->glpos[2]=coords[2];

  for(i=0;i<4;i++) 
    p->glpos[3+i]=0.0;

  for(i=0;i<4;i++) {
    for(j=0;j<4;j++) {
      p->glpos[3+i]+=vpos[j][3+i]*weight[j];
    }
  }
  *outData = (void *) p->glpos;
}

void oeMapElementLine::draw(oeMap *map) {
  oeMapElementLinePoint *p;
  GLUtriangulatorObj *tess;

  if (map->mode_edit && map->editelem == this)
    glLineWidth(2.0);

  if (filled && prefs.map_fill) {
    tess=gluNewTess();
    tessError = FALSE;
    gluTessCallback(tess, (GLenum) GLU_TESS_BEGIN, (void (*)()) glBegin);
    gluTessCallback(tess, (GLenum) GLU_TESS_VERTEX, (void (*)()) oeMapElementLine::VertexCallback);
    gluTessCallback(tess, (GLenum) GLU_TESS_ERROR, (void (*)()) oeMapElementLine::ErrorCallback);
    gluTessCallback(tess, (GLenum) GLU_TESS_COMBINE, (void (*)()) oeMapElementLine::CombineCallback);
    gluTessCallback(tess, (GLenum) GLU_TESS_END, (void (*)()) glEnd);

    gluBeginPolygon(tess);
    for (p=points.first(); p; p=points.next()) { 
      p->glpos[0]=p->x;
      p->glpos[1]=p->y;
      p->glpos[2]=p->z / 10.0;
      p->glpos[3]=r / 2.0;
      p->glpos[4]=g / 2.0;
      p->glpos[5]=b / 2.0;
      p->glpos[6]=1.0;
      map->setGLColor(& p->glpos[3], p->z);
      gluTessVertex(tess, p->glpos, p->glpos);
    }
    gluEndPolygon(tess);
    gluDeleteTess(tess);

    if (tessError) {
      filled=false;
      if (map->editelem == this) {
        map->c->oe->EditLineFilled->setOn(FALSE);
        QMessageBox::warning(map, "Tesselation failed", "The current line failed tesselation.\nFilling has been disabled");
      }
    }
  }

  glBegin(GL_LINE_STRIP);
  for (p=points.first(); p; p=points.next()) { 
    map->setGLColor(r,g,b, p->z);
    glVertex3i(p->x,p->y,p->z);
  }
  glEnd();  
  if (map->mode_edit) {
    glLineWidth(1.0);
    glPointSize((map->editelem == this) ? 4.0 : 3.0);
    glBegin(GL_POINTS);
    for (p=points.first(); p; p=points.next()) { 
      map->setGLColor(r,g,b, p->z);
      glVertex3i(p->x,p->y,p->z);
    }
    glEnd();  
    if ((map->editelem == this) && (points.count() > 0)) {
      p=points.at(selnode);
      if (p) {
        glPointSize(8.0);
        glBegin(GL_POINTS);
        map->setGLColor(r,g,b, p->z);
        glVertex3i(p->x,p->y,p->z);
        glEnd();
        if (selnode != 0) {
          p=points.at(0);
          glPointSize(6.0);
          glBegin(GL_POINTS);
          map->setGLColor(r,g,b,p->z);
          glVertex3i(p->x,p->y,p->z);
          glEnd();
        }
      }
    }
    glPointSize(3.0);
  }
}

double oeMapElementLine::clickAt(int xv, int yv, int) {
  double best;
  double xd, yd;
  double dist;
  int i;
  oeMapElementLinePoint *p;

  best = -1.0;
  selnode = 0;
  i=0;
  for(p=points.first(); p ; p=points.next()) {
    xd=p->x-xv;
    yd=p->y-yv;
    dist=sqrt(xd*xd+yd*yd);
    if ((best < 0.0) || (dist < best)) {
      best=dist;
      selnode=i;
    }    
    i++;
  }
  return best;
}

QString oeMapElementLine::getString(int basex, int basey) {
  QStringList lst;
  oeMapElementLinePoint *p;
  lst+=(filled) ? "F" : "M";
  lst+=text;
  lst+=colorstring;
  lst+=QString::number(points.count());
  for(p=points.first(); p ; p=points.next()) {
    lst+=QString::number(p->x - basex);
    lst+=QString::number(p->y - basey);
    lst+=QString::number(p->z);
  }
  return lst.join(",");
}

bool oeMapElementLine::valid() {
  if (! oeMapElement::valid()) 
    return FALSE;
  if (points.count() < 2) {
    return FALSE;
  }
  return TRUE;
}

double oeMapElementLine::weight() {
  double w;
  double worstw;
  unsigned int i;

  oeMapElementLinePoint *p;
  oeMapElementLinePoint *t;
  oeMapElementLinePoint *n;

  if (points.count() < 3) 
    return -1.0;

  worstw=-1.0;

  for(i=1;i<points.count()-1;i++) {
    p=points.at(i-1);
    t=points.at(i);
    n=points.at(i+1);

    oeLineSimplifyPoint p1(p->x,p->y,p->z);
    oeLineSimplifyPoint p2(n->x,n->y,n->z);
    oeLineSimplifyPoint p3(t->x,t->y,t->z);

    w=p3.distLine(&p1,&p2);

    if ((worstw == -1.0) || (w < worstw)) {
      selnode=i;
      worstw=w;
    }
  }
  return worstw;
}

int oeMapElementLine::x() {
  oeMapElementLinePoint *p=points.at(selnode);
  return p->x;
}

int oeMapElementLine::y() {
  oeMapElementLinePoint *p=points.at(selnode);
  return p->y;
}

void oeMapElementLine::gotoFirst() {
  selnode=0;
}

void oeMapElementLine::gotoLast() {
  selnode=points.count();
  if (selnode != 0)
    selnode--;
}
 