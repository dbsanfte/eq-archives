package AO::Chat;

require 5.004;
use strict;
use warnings;
use IO::Socket::INET;
use AO::Chat::Packet;
use AO::Chat::Character;
use AO::Chat::Player;
use AO::Chat::Group;
use Carp qw(cluck confess);


require Exporter;
require DynaLoader;

our @ISA = qw(Exporter DynaLoader);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration	use AO::Chat ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
	
) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
	
);

our $VERSION = '0.08';

our $MathClass = 'Math::BigInt';
our $MathLibrary = 'Math::BigInt';
my $mathok=0;

eval {
  require Crypt::Random;
  import Crypt::Random;
};


eval {
  require Math::BigInt;
  import Math::BigInt lib => 'Pari,GMP';
  my $mathtest=new $MathClass(0);
  my $cfg=$mathtest->config;
  if (($$cfg{'lib'} eq 'Math::BigInt::GMP') || ($$cfg{'lib'} eq 'Math::BigInt::Pari')) {
    $mathok=1;
  }    
  $MathLibrary=$$cfg{'lib'};
};

if (! $mathok) {
  eval {
    require Math::Pari;
    import Math::Pari;
    $MathClass = 'Math::Pari';
    $MathLibrary = 'Math::Pari';
    $mathok=1;
  };
}

if (! $mathok) {
  eval {
    require Math::BigInt;
    import Math::BigInt;
    $mathok=1;
    warn 'Failed to find either of Math::BigInt::GMP, Math::BigInt::Pari or Math::Pari, calculating the authentication will take a long time';
  }
}

if (! $mathok) {
  die "Couldn't load ANY math libraries, not even Math::BigInt";
}

our @colors = (
  [24, 'Red',       0xFF0000],
  [ 9, 'Pink',      0xFF009C],
  [31, 'Violet',    0xFF00FF],
  [ 8, 'Lime',      0x08F708],
  [19, 'AtazGreen', 0x00DE42],
  [ 6, 'Forest',    0x00A552],
  [ 7, 'Ocean',     0x63E78C],
  [20, 'Leaf',      0x63AD63],
  [14, 'TakrelBlue',0x0000FF],
  [ 4, 'Sky',       0x00FFFF],
  [ 1, 'Blue',      0x3EDAF9],
  [27, 'Purply',    0x8CB5FF],
  [22, 'Teal',      0x9CD6DE],
  [16, 'Yellow',    0xFFFF00],
  [ 5, 'Yellowish', 0xFFFF42],
  [18, 'Yellowy',   0xDEDE42],
  [29, 'LightTan',  0xFFE7A5],
  [17, 'Tan',       0xCEAD42],
  [ 3, 'Ivory',     0xFFFFCE],
  [10, 'Camo',      0x9C9C21],
  [11, 'DurxBlack', 0x000000],
  [15, 'White',     0xFFFFFF],
  [25, 'Grey',      0xDEDED6]
);

# Preloaded methods go here.

sub hexToBigInt($) {
  my ($v)=@_;
  my $r=new $MathClass(0);
  my $one=new $MathClass(1);
  foreach my $char (split(//,$v)) {
    $r=$r << new $MathClass(4);
    my $part=int(hex $char);
    $r=$r+($part*$one);
  }
  return $r;
}

sub bigIntToHex($) {
  my ($v)=@_;
  my $val=$v;
  my $r='';
  while ($val > 0) {
    my $idx=($val % 16);
    $r=sprintf('%x',$idx).$r;
    $val=new $MathClass($val >> new $MathClass(4));
  }
  return $r;
}

# I originally used Math::Pari's lift() function to do this, but my testers
# had problems getting Math::Pari to compile :(
# So.. This new exp_mod has been
# shamelessly ripped from http://www.xs4all.nl/~johnpc/Talks/Anon-Electronics/

sub mod_exp {
    my($i, $j, $n) = @_;

    if ($MathLibrary eq 'Math::Pari') {
      my $m=Math::Pari::Mod($i,$n);
      return Math::Pari::lift($m ** $j);
    } elsif (($MathLibrary eq 'Math::BigInt::GMP') || ($MathLibrary eq 'Math::BigInt::Pari')) {
      return $i->bmodpow($j,$n);
    }

    my $result = $i - $i + 1; # 1, but in the same type as $i
    return $result unless $j;

    my $pow2 = $i;

    while ( 1 ) {
        if ( $j % 2 ) {
            $result = ($pow2 * $result) % $n;
            return $result unless --$j;
        }
        $j /= 2;
        $pow2 = ($pow2 * $pow2) % $n;
    }
}

sub randoctet($) {
  my ($length)=@_;

  my $s;

  eval {
    $s=Crypt::Random::makerandom_octet(Length=>$length, Strength=>0);
  };
  if ($@) {
    for (my $i=0;$i<$length;$i++) {
      $s.=pack('C',rand(0x100));
    }
  }
  return $s;
}

sub permute(\@\@) {
  my ($key,$source)=@_;
  if (($#{$key} != 1) || ($#{$source} != 3)) {
    confess 'Wrong keylength or sourcelength';
  }

  use integer;

  my $i1=$$key[0];
  my $j1=$$key[1];
  my $k=0;
  my $i2=0x9e3779b9;
  for (my $j2 = 32; $j2-- > 0;) {
     $k += $i2;
     $i1 += (($j1 << 4) + $$source[0]) ^ ($j1 + $k) ^ (($j1 >> 5 & 0x07ffffff) + $$source[1]);
     $j1 += (($i1 << 4) + $$source[2]) ^ ($i1 + $k) ^ (($i1 >> 5 & 0x07ffffff) + $$source[3]);
  }
  $$key[0]=$i1;
  $$key[1]=$j1;
}

sub encrypt($$) {
  my ($key,$text)=@_;
  if (length($key) != 32) {
    confess "Key isn''t 32 characters";
  }
  if ((length($text) % 8) != 0) {
    confess "Text isn't 8-byte aligned";
  }
  my @key;
  for (my $i=0;$i<4;$i++) {
    $key[$i]=unpack('V',pack('N',hex substr($key,8*$i,8)));
  }

  my $length=length($text);
  my @input=unpack('V*',$text);

  my @prev;
  $prev[0]=0;
  $prev[1]=0;

  my $crypted='';

  for (my $i=0;$i<($length/4);$i+=2) {
    my @now;
    $now[0]=$input[$i];
    $now[1]=$input[$i+1];
    $now[0] ^= $prev[0];
    $now[1] ^= $prev[1];
    permute(@now,@key);
    $prev[0] = $now[0];
    $prev[1] = $now[1];    
    $crypted.=sprintf('%08x%08x',unpack('V',pack('N',$now[0])),unpack('V',pack('N',$now[1])));
  }
  return $crypted;
}

sub genLoginKey($$$) {
  my ($servkey, $uname, $pw)=@_;

  my $n = hexToBigInt('eca2e8c85d863dcdc26a429a71a9815ad052f6139669dd659f98ae159d313d13c6bf2838e10a69b6478b64a24bd054ba8248e8fa778703b418408249440b2c1edd28853e240d8a7e49540b76d120d3b1ad2878b1b99490eb4a2a5e84caa8a91cecbdb1aa7c816e8be343246f80c637abc653b893fd91686cf8d32d6cfe5f2a6f');
  my $othermod = hexToBigInt('9c32cc23d559ca90fc31be72df817d0e124769e809f936bc14360ff4bed758f260a0d596584eacbbc2b88bdd410416163e11dbf62173393fbc0c6fefb2d855f1a03dec8e9f105bbad91b3437d8eb73fe2f44159597aa4053cf788d2f9d7012fb8d7c4ce3876f7d6cd5d0c31754f4cd96166708641958de54a6def5657b9f2e92');
  my $modulus = hexToBigInt('5');

  my $clientkey = unpack('H32',randoctet(16));

  my $clikey = hexToBigInt($clientkey);

  my $crypted_key=mod_exp($modulus, $clikey, $n);

  my $secret=$uname.'|'.$servkey.'|'.$pw;
  my $cryptkey=unpack('A32',pack('A*',bigIntToHex(mod_exp($othermod, $clikey, $n))));

  my $tocrypt=pack('a8N/a*',randoctet(8),$secret);

  my $len=length($tocrypt);
  my $left=8-($len % 8);
  if ($left != 8) {
    $tocrypt.=' ' x $left;
  }

  my $crypted=encrypt($cryptkey,$tocrypt);

  return bigIntToHex($crypted_key).'-'.$crypted;
}

sub groupname {
  deprecated('AO::Chat::groupname');
  my ($self,$lookup)=@_;
  my $group=${$self->{GID}}{$lookup};
  if ($group) {
    return $group->{ID};
  } else {
    return undef;
  }
}

sub group {
  my ($self,$lookup)=@_;
  return ${$self->{GID}}{$lookup};
}  

sub player {
  my ($self,$lookup)=@_;
  if (ref $lookup && $lookup->isa('AO::Chat::Player')) {
    return $lookup;
  }
  my $val=${$self->{ID}}{$lookup};
  if (defined $val) {
    return $val;
  }
  if (! $lookup) {
    cluck('Missing $lookup!');
  }
  if (${$self->{NID}}{$lookup}) {
    if ((time - ${$self->{NID}}{$lookup}) > 5) {
       ${$self->{NID}}{$lookup}=undef;
    } else {
      return undef;
    }
  }
  if (($lookup =~ /^[0-9]+$/) || $self->{STATE} ne 'OK') {
    return undef;
  }
  $self->send(new AO::Chat::Packet(21,$lookup));
  my $p;
  do {
    $p=$self->packet();
  } while ($p && ! ${$self->{ID}}{$lookup} && ! ${$self->{NID}}{$lookup});
  return ${$self->{ID}}{$lookup};
}

sub username {
  deprecated('AO::Chat::username');
  my ($self,$lookup)=@_;
  if (ref $lookup && $lookup->isa('AO::Chat::Player')) {
    return $lookup->{ID};
  }
  my $player=$self->player($lookup);
  if ($player) {
    if ($lookup =~ /^[0-9]+$/) {
      return $player->{NAME};
    } else {
      return $player->{ID};
    }
  } else {
    return undef;
  }
}

sub deprecated {
  my ($what)=(@_);
  if (! $AO::Chat::deprecatedwarn{$what}) {
    $AO::Chat::deprecatedwarn{$what}=1;
    cluck "$what is deprecated";
  }
}

sub privmsg {
  deprecated('AO::Chat::privmsg');
  my ($self,$id,$msg,$blob)=@_;
  if ($#_ < 2) {
    cluck 'Wrong # of args!\n';
    return undef;
  }
  my $player=$self->player($id);
  if ($player) {
    $player->tell($msg,$blob);
  }
}
  
sub addbuddy {
  deprecated('AO::Chat::addbuddy');
  my ($self,$id,$list)=@_;
  my $player=$self->player($id);
  if ($player) {
    $player->buddyadd($list);
  }
}

sub delbuddy {
  deprecated('AO::Chat::delbuddy');
  my ($self,$id)=@_;
  my $player=$self->player($id);
  if ($player) {
    $player->buddyrem();
  }
}

sub kickall {
  my ($self)=@_;
  $self->send(new AO::Chat::Packet(54));
}

sub setafk {
  my ($self,$afk)=@_;
  $self->send(new AO::Chat::Packet(42, ($afk ? 2 : 1)));
}

sub ping {
  my ($self)=@_;
  my $time=time;
  $self->send(new AO::Chat::Packet(100,$time));
  $self->{LASTPING}=$time;
  push @{$self->{PINGQUEUE}},$time;
}

sub packet {
  my $self = shift;
  my ($head,$data);

  my $rin='';
  vec($rin,fileno($self->{SOCKET}),1)=1;
  my $nfound=0;
  do {
    if ($self->{STATE} eq 'OK' && ($self->lastping() > 60)) {
      $self->ping();
    }

    my $timeout=15;

    while (($self->queuelength > 0) && (time - ${$self->{TELLTIME}}[0] >= 12)) {
      my $packet=shift @{$self->{TELLQUEUE}};
      $self->send($packet);
      shift @{$self->{TELLTIME}};
      push @{$self->{TELLTIME}},time;
    }
    if ($self->queuelength > 0) {
      $timeout=12 - (time - ${$self->{TELLTIME}}[0]);
    }
     
    my $rout=$rin;
    my $eout=$rin;
    my $timeleft;
    ($nfound,$timeleft)=select($rout,undef,$eout,$timeout);
    if (! $nfound) {
      $self->ping();
    }
  } while (! $nfound && (time - $self->{LASTMSG}) < 120);

  if ((time - $self->{LASTMSG}) >= 120) {
    cluck 'Timeout';
    $self->{SOCKET}->shutdown(2);
    return undef;
  }  

  $self->{LASTMSG}=time;

  my $rlen=$self->{SOCKET}->sysread($head,4);
  if ($rlen != 4) {
    cluck "Stream disconnected -- rlen $rlen";
    return undef;
  }

  my ($type,$len)=unpack('nn',$head);
  $rlen=$self->{SOCKET}->sysread($data,$len);
  if ($rlen!=$len) {
    return undef;
  }

  my $p=new AO::Chat::Packet($type,\$data);

  my @args=@{$p->{param}};

  if ($type == 0 ) {
    $self->{SERVERSEED}=$args[0];
  } elsif (($type == 20) || ($type == 21)) {
    my ($id,$name)=@args;
    my $player=new AO::Chat::Player($self,$id,$name);
    if (! $player) {
      ${$self->{NID}}{$name}=time;
    } else {
      ${$self->{ID}}{$id}=$player;
      ${$self->{ID}}{$name}=$player;
      if ($id == $self->{ME}->{ID}) {
        $self->{ME}=$player;
      }
    }
  } elsif ($type == 60) {
    my ($gid,$name,$flags)=@args;
    my $group=new AO::Chat::Group($self,$gid,$name,$flags);
    ${$self->{GID}}{$gid}=$group;
    ${$self->{GID}}{$name}=$group;
  } elsif ($type == 100) {
    my ($time)=@args;
    shift @{$self->{PINGQUEUE}};
    $self->{LAG}=time-$time;
  }

  if (defined($self->{SUB})) {
    $self->{SUB}($type,@args);
  }
  if (defined($self->{CB})) {
    if ($type == 30) {
      my ($playerid,$msg,$blob)=@args;
      $self->{CB}->tell($self->player($playerid),$msg,AO::Chat::Blob->parsemsg($msg,$blob,1));
    } elsif ($type == 34) {
      my ($playerid,$msg,$blob)=@args;
      $self->{CB}->say($self->player($playerid),$msg,AO::Chat::Blob->parsemsg($msg,$blob));
    } elsif ($type == 35) {
      my ($player, $msg, $blob)=@args;
      $self->{CB}->anonsay($player, $msg, AO::Chat::Blob->parsemsg($msg,$blob));
    } elsif ($type == 36) {
      my ($msg)=@args;
      $self->{CB}->system($msg);
    } elsif ($type == 40) {
      my ($playerid, $online, $listed)=@args;
      $listed=($listed eq "\0") ? 0 : 1;
      $self->{CB}->addbuddy($self->player($playerid),$online,$listed);
    } elsif ($type == 41) {
      my ($playerid)=@args;
      $self->{CB}->rembuddy($self->player($playerid));
    } elsif ($type == 50) {
      my ($privplayerid)=@args;
      $self->{CB}->pginvited($self->player($privplayerid));
    } elsif ($type == 51) {
      my ($privplayerid)=@args;
      $self->{CB}->pgkicked($self->player($privplayerid));
    } elsif ($type == 53) {
      my ($privplayerid)=@args;
      $self->{CB}->pgpart($self->player($privplayerid));
    } elsif ($type == 55) {
      my ($privplayerid, $playerid)=@args;
      $self->{CB}->pgclientjoin($self->player($privplayerid),$self->player($playerid));
    } elsif ($type == 56) {
      my ($privplayerid, $playerid)=@args;
      $self->{CB}->pgclientpart($self->player($privplayerid),$self->player($playerid));
    } elsif ($type == 57) {
      my ($privplayerid, $playerid, $msg, $blob)=@args;
      $self->{CB}->pgmsg($self->player($privplayerid),$self->player($playerid),$msg, AO::Chat::Blob->parsemsg($msg,$blob));
    } elsif ($type == 60) {
      my ($groupid)=@args;
      $self->{CB}->groupjoin($self->group($groupid));
    } elsif ($type == 61) {
      my ($groupid)=@args;
      $self->{CB}->grouppart($self->group($groupid));
    } elsif ($type == 65) {
      my ($groupid,$playerid, $msg, $blob)=@args;
      $self->{CB}->groupmsg($self->group($groupid),$self->player($playerid),$msg,AO::Chat::Blob->parsemsg($msg,$blob));
    } elsif ($type == 100) {
      $self->{CB}->lag($self->{LAG});
    } elsif ($type == 0 || $type == 5 || $type == 6 || $type == 7 || $type == 20 || $type == 21) {
      # Internal packets for login and character ID lookups
    } else {
      warn "Unhandled packet type $type in AO::Chat::packet(), please contact the author";
    }
  }
  return $p;
}

sub lag {
  my ($self)=@_;
  my $a=$self->{LAG};
  if ($#{$self->{PINGQUEUE}} != -1) {
    my $b=time-${$self->{PINGQUEUE}}[0];
    if ($b > $a) {
      return $b;
    }
  }
  return $a;
}

sub lastping {
  my ($self)=@_;
  return time - $self->{LASTPING};
}

sub me {
  my ($self)=@_;
  return $self->{ME};
}

sub groups {
  my ($self)=@_;
  my %grp;
  foreach my $grp (values %{$self->{GID}}) {
    $grp{$grp->{ID}}=$grp;
  }
  return (values %grp);
}

sub send {
  my ($self,$packet) = @_;
  if (! $packet->isa('AO::Chat::Packet') || ($$packet{'dir'} ne 'OUT')) {
    cluck "Can't send nonpackets";
    return undef;
  }
  use bytes;
  my $data=pack('nn/a*',$packet->{type},$packet->{data}); 
  my $written=$self->{SOCKET}->syswrite($data,length($data));
  return $packet;
}

sub queue {
  my ($self,$packet) = @_;
  push @{$self->{TELLQUEUE}},$packet;
}

sub queuelength {
  my ($self)=@_;
  return $#{$self->{TELLQUEUE}} + 1;
}

sub color {  
  my ($self,$color)=@_;
  if (! defined $color) {
    return undef;
  }
  if (($color =~ /^[0-9]+/) && ($color >= 0) && ($color <=255)) {
    return pack('CC',16,$color);
  }
  if ($color =~ /^\#([0-9A-Fa-f]{6})$/) {
    my $col=hex $1;
    my $r=($col >> 16) & 0xFF;
    my $g=($col >> 8 ) & 0xFF;
    my $b=$col & 0xFF;
    my $bestdelta=0xFF * 0xFF * 3;
    my $bestcol=-1;
    foreach my $c (@colors) {
      $col=$$c[2];
      my $cr=($col >> 16) & 0xFF;
      my $cg=($col >> 8 ) & 0xFF;
      my $cb=$col & 0xFF;
      my $deltar=($cr - $r);
      my $deltag=($cg - $g);
      my $deltab=($cb - $b);
      my $delta=$deltar * $deltar + $deltag * $deltag + $deltab * $deltab;
      if ($delta < $bestdelta) {
         $bestcol=$$c[0];
         $bestdelta = $delta;
      }
    }
    return pack('CC',16,$bestcol);
  }
  $color=lc $color;
  foreach my $c (@colors) {
    if (lc $$c[1] eq $color) {
      return pack('CC',16,$$c[0]);
    }
  }
  return undef;
}

sub new {
  my ($proto, %params) = @_;
  %params=('Server'=>'chat2.d1.funcom.com','Port'=>'7012',%params);
  my $class = ref($proto) || $proto;
  my $self = {};
  $self->{SERVER}=$params{'Server'};
  $self->{PORT}=$params{'Port'};
  $self->{SUB}=$params{'Sub'};
  $self->{CB}=$params{'Callback'};
  if (! ref $self->{CB} || ! $self->{CB}->isa('AO::Chat::Callback')) {
    $self->{CB}=undef;
  } else {
    $self->{CB}->{CHAT}=$self;
  }
  $self->{SOCKET}=new IO::Socket::INET(PeerAddr=>$self->{SERVER},PeerPort=>$self->{PORT},Proto=>'tcp') or return undef;
  $self->{ID}={};
  $self->{GID}={};
  $self->{LAG}=3600;
  $self->{LASTPING}=0;
  $self->{PINGQUEUE}=[];
  $self->{TELLTIME}=[0,0,0];
  $self->{TELLQUEUE}=[];
  $self->{STATE}='Connect';
  $self->{LASTMSG}=time;
  bless($self,$class);
  my $p=$self->packet();
  if ($$p{'type'} != 0) {
    cluck 'GreetPacket not 0';
    return undef;
  }
  $self->{STATE}='Auth';
  return $self;
}

sub authenticate {
  my ($self, $uname, $pw) = @_;
  if (! defined($uname) || ! defined($pw)) {
    cluck 'Missing username or password';
    return undef;
  }
  if ($self->{STATE} ne 'Auth') {
    cluck 'Not expecting authentication';
    return undef;
  }
  my $p=new AO::Chat::Packet(2,0,$uname,genLoginKey($self->{SERVERSEED},$uname,$pw));
  $self->send($p);
  $self->{LASTMSG}=time;
  my $rp=$self->packet();
  if ($$rp{'type'} == 7) {
    my @params=@{$rp->{param}};
    my @chars;
    for (my $i=0;$i<=$#{$params[0]};$i++) {
      my $c=new AO::Chat::Character('id'=>${$params[0]}[$i],'name'=>${$params[1]}[$i],'level'=>${$params[2]}[$i],'online'=>${$params[3]}[$i]);
      push @chars,$c;
    }
    $self->{STATE}='Login';
    return @chars;
  } else {
    return undef;
  }
}

sub login {
  my ($self, $char) = @_;
  if ($self->{STATE} ne 'Login') {
    cluck 'Not expecting a login';
    return undef;
  }
  if (! $char->isa('AO::Chat::Character')) {
    cluck "Can't logon noncharacters";
    return undef;
  }
  my $p=new AO::Chat::Packet(3,$$char{'id'});
  $self->send($p);
  my $rp=$self->packet();
  if ($$rp{'type'} != 5) {
    return undef;
  }
  $self->{STATE}='OK';
  $self->{ME}=new AO::Chat::Player($self, $$char{'id'},$$char{'name'});
  return 1;
}

1;
__END__
# Below is stub documentation for your module. You better edit it!

=head1 NAME

AO::Chat - Perl extension for the AO Chat Server

=head1 SYNOPSIS

  use AO::Chat;

  package MyCallback;

  use base qw(AO::Chat::Callback);

  sub tell {
    my ($self,$player,$message,$blob)=@_;
    print "Private Message :: $message\n";
    $player->tell('Hi');
  }

  sub groupmsg {
    my ($self,$group,$player,$message,$blob)=@_;
    print "Group Message :: $message\n";
    $group->msg('Hi');
  }

  package main;

  my $callback=new MyCallback;
  my $chat=new AO::Chat(Callback=>$cb);
  die 'No Chat Connection' if (! defined $chat);

  my @characters=$chat->authenticate("username","password");
  die 'Wrong username or password' if ($#characters==0 && ! defined $characters[0]);

  foreach my $char (@characters) {
    print "Character $$char{'name'} - $$char{'level'} - $$char{'online'} - $$char{'id'}\n";
  }
  die 'No characters' if ($#characters == -1);

  die 'Failed login' if (! $chat->login($char[0]));

  do {
  } while (defined($chat->packet()));

  die 'Stream disconnected';

=head1 DESCRIPTION

This small and mostly unfinished module allows interaction with the AO Chat
server - the same server used by the AO Java Chat Client. Functionality at
the moment is "limited", but it will be expanded soon.

=head2 NOTES

Usage of Crypt::Random for random octects and Math::BigInt::GMP,
Math::BigInt::Pari or just Math::Pari for biginteger calculation
is prefered, and it's really recommended you install these
modules.
Lacking either of these will make AO::Chat fall back to rand(), which
compromises the security of the password by allowing a rand()-prediction
attack, and it will use Math::BigInt for RSA calculations, which is very
very slow.

=head1 VARIABLES

=over 4

=item AO::Chat::MathLibrary

Contains the name of the used Math Library. If this isn't one of the
accelerated ones, a warning will be given when importing AO::Chat, and be
warned that calculating login will take forever.

=back

=head1 METHODS

=over 4
 
=item new(Server=>"chat2.d1.funcom.com",Port=>7012,Sub=>\&callback)

This creates a new AO::Chat object. The callback function (explained below)
is called each time a packet arrives, and is the primary means of processing
input packets.

=item authenticate("username","password")

This method will attempt to authenticate to the server, and will return
an array of AO::Chat::Character objects which are associated with the
account.
If authentication fails, the method returns undef.
If there are no characters on the account, the method returns an empty
array.

=item login($character)

This method tries to log in the selected character after successfull
authentication. The $character must be a valid AO::Chat::Character object,
as returned by authenticate().
The method returns 1 if successfull, and undef if not.

=item packet()

This method returns the next AO::Chat::Packet from the server. While it
was previously possible to loop around this function to process packets,
such behaviour is now strictly discouraged, as other functions will call
this method internally when waiting for response from asynchronous
network messages.
The method returns undef if there was a stream error.

=item player("Playername")

This method returns an AO::Chat::Player object representing the player. This
method will block until a reply has been received from the server, possibly
causing other callback functions to be called as packets are processed.
If the player can't be found, this method will return undef.

=item group("Groupname")

This method returns an AO::Chat::Group object representing the group, if the
group is know. Otherwise it returns undef.

=item me()

This returns the AO::Chat::Player object representing yourself.

=item pgkickall()

This method will kick all users from your own private chat group.

=item setafk($afk)

This method will set your online status to either 'Online' ($afk is 0) or
'AFK' ($afk is 1).

=item lag()

This method returns the last measured lag in seconds. This is the larger of
either the reported lag on the last ping packet, or the number of seconds
since the last unacknowledged ping packet was sent.

=item ping()

Sends a ping packet to the server. You normally don't need to call this,
as packet() will call it automatically once a minute.

=item lastping()

Returns the number of seconds since the last valid ping packet was sent.

=item queuelength()

To avoid messages being dropped, /tell messages are added to a queue that's
slowly being sent to the server during the packet() loop.
This method returns the number of entries in the queue.

=item color($colorcode)

This will return a byte-sequence you can insert into a message or textblob
to change the color of the text. $colorcode is either the color number
(which is odd), the color name, or a color in web-style formatting.

If given a color number, it will return the bytesequence for that color
without checking the number. If given a color name it will return either the
bytesequence or undef, and if given a web-style color it will return the
nearest color.

Thanks go to Kuren (http://www.kuren.org) for his work on writing down
which code is what color.

=item send($packet)

=item username($lookup_key) 

=item groupname($lookup_key) 

=item privmsg($playerid, $message, $blob)

These methods are deprecated in favor of the new OO style of programming,
and are currently implemented as just wrappers around objects.

=back

=head1 AUTHOR

Slicer, slicer@ethernalquest.org

=head1 SEE ALSO

AO::Chat::Callback, AO::Chat::Character, AO::Chat::Group, AO::Chat::Blob,
perl(1).

=cut
