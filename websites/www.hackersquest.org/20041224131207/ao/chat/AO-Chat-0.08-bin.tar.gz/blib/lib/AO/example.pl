#! /usr/bin/perl -w

use ExtUtils::testlib;
use AO::Chat;
use AO::Chat::Blob;
use strict;

# Extensive example of AO::Chat, this example overrides
# all the methods of AO::Chat::Callback
# Note that this isn't at all necesarry, but has been
# done here for complete reference.

# The first thing to do is define our own class, or package,
# which we'll later pass to AO::Chat.
# The package has to be an extention of AO::Chat::Callback.
# In this example, all the methods are overriden, but that
# is not at all necesarry.

package MyCallback;

use base qw(AO::Chat::Callback);

sub tell {
  my ($self,$player,$message,$blob)=@_;
  
  # Log message to standard output
  print "[" . $player->name() . "]: $message\n";

  # Do different actions depending on what the message was.
  if ($message eq "spamtest") {
    # Test the spam protection
    for (my $i=1;$i<10;$i++) {
      $player->tell("Spam Test Line $i");
    }
  } elsif ($message eq "texttest") {
    # Send an example blob with a text info behind it.
    my $blob=new AO::Chat::Blob("text link","With lots of info behind it");
    my $msg="This has a ".$blob->link()." in it";
    $player->tell($msg,$blob);
  } elsif ($message eq "itemtest") {
    # Send an example blob with a item link behind it.
    my $blob=new AO::Chat::Blob("item link",0x17520,0x17520,200);
    my $msg="This has a ".$blob->link()." in it";
    $player->tell($msg,$blob);
  } elsif ($message =~ /^colortest (.+)$/) {
    my $color=AO::Chat->color($1);
    $player->tell("Test of $color Color");
  }
  # If a blob came with the message, print it's contents to stdout.
  if ($blob) {
     if ($blob->istextblob()) {
       print "Text Blob: ".$blob->blobtext()."\n";
     } else {
       printf("Blob Item: %d<->%d (QL %d)\n",$blob->fromitem(),$blob->toitem(),$blob->ql());
     }
  }
}

sub say {
  my ($self,$player,$message,$blob)=@_;
  print $player->name() . ": $message\n";
}

sub anonsay {
  my ($self, $who, $message, $blob)=@_;
  print "ANON [$who] $message\n";
}

sub system {
  my ($self, $message)=@_;
  print "SYSTEM $message\n";
}

sub addbuddy {
  my ($self, $player, $online, $listed)=@_;

  $online=($online) ? "Online" : "Offline";
  $listed=($listed) ? "Listed" : "Unlisted";
  print "BUDDY ".$player->name(). "($listed) is now $online\n";
}

sub rembuddy {
  my ($self, $player)=@_;
  print "BUDDY ".$player->name() . " removed\n";
}


# When someone invites the script to join their private chat

sub pginvited {
  my ($self, $pg)=@_;
  
  # Log to standard output
  print "PGroup You are invited to ".$pg->name() . "\n";

  # Join the private chat group.
  $pg->pgjoin();

  # Send a message.
  $pg->pgmsg("Hi, thanks for the invite, but I'd much rather you joined my own chat group.");

  # A PlayerGroup is actually a player, so we send a invite to the player
  # to join our private chat group.
  $pg->pginvite();
}

sub pgkicked {
  my ($self, $pg)=@_;
  print "PGroup You were kicked from ".$pg->name() . "\n";
}

sub pgpart {
  my ($self, $pg)=@_;
  print "PGroup You left ".$pg->name() . "\n";
}

# Someone joined a private chat group.
sub pgclientjoin {
  my ($self, $pg, $player)=@_;

  # Log to standard output.
  print "PGroup ".$player->name()." joined group ".$pg->name() . "\n";

  # If someone joins my chat group, kick them.
  if ($pg == $self->chat()->me()) {
    $pg->pgmsg("Go away");
    $player->pgkick();
  }
}

sub pgclientpart {
  my ($self, $pg, $player)=@_;
  print "PGroup ".$player->name()." left group ".$pg->name() . "\n";
}

# Someone said something in a private chat group we're listening on.
sub pgmsg {
  my ($self, $pg, $player, $message, $blob)=@_;
  print "PGroup ".$pg->name()." [".$player->name()."]: $message\n";

  # Do different actions depending on what was said.
  if ($message eq "add") {
    # Add the player as a unlisted buddy.
    $player->addbuddy();
  } elsif ($message eq "addlist") {
    # Add the player as a listed buddy.
    $player->addbuddy(1);
  } elsif ($message eq "rem") {
    # Remove the player as a buddy.
    $player->rembuddy();
  } elsif ($message eq "spamtest") {
    # Run a spam test.
    for (my $i=1;$i<10;$i++) {
      $pg->pgmsg("Spam Test Line $i");
    }
  } elsif ($message eq "status") {
    # Report status. Status is both the lag, the queue length,
    # and any channels the bot is on.
    $pg->pgmsg("AO::Chat example.pl for AO::Chat version ".$AO::Chat::VERSION);
    $pg->pgmsg("AO::Chat is using math library ".$AO::Chat::MathLibrary);
    $pg->pgmsg("Current lag is ".$self->chat()->lag()." and tell queue length is ".$self->chat()->queuelength());
    my @groups=$self->chat()->groups();
    my @grp;
    foreach my $grp (@groups) {
      push @grp,$grp->name() . ($grp->muted() ? "(M)" : "(L)");
    }
    $pg->pgmsg("I'm on groups ".join(", ",@grp));
  }
}

# Joined a group
sub groupjoin {
  my ($self, $group)=@_;
  my $muted=$group->muted() ? "Muted" : "Listening";
  print "Group ".$group->name()." joined ($muted)\n";

  # If it's a shopping group, mute it.
  if (! $group->muted() && $group->name() =~ /shopping/) {
    $group->mute(1);
  }
}

sub grouppart {
  my ($self, $group)=@_;
  print "Group ".$group->name()." left\n";
}

sub groupmsg {
  my ($self, $group, $player, $message, $blob)=@_;
  print "Group ".$group->name()." [".$player->name()."]: $message\n";
}

sub lag {
  my ($self, $lag)=@_;
  print "Measured lag is now $lag seconds\n";
}


# Main program
# Connects to the server, then starts processing packets.
# If the stream should close, it will wait 5 minutes then
# automatically reconnect
  
package main;

my ($username,$pw,$character)=@ARGV;

if (! $username || ! $pw) {
  die("Arguments must be username and password");
}

while (1) {

  # First, create an instance of our new Callback package.
  my $cb=new MyCallback();

  # And pass that instance to the Chat object.
  my $chat=new AO::Chat(Callback=>$cb);

  # Then connect, authenticate and login.

  print "Connecting...\n";
  if (! defined $chat) {
    warn "Connection failed";
  } else {
    print "Authenticating...\n";
    my @chars=$chat->authenticate($username,$pw);
    if (@chars && ! defined $chars[0]) {
      warn "Wrong username or password";
    } else {
      print "Logging in...\n";
      my $char;
 
      # If a character was specified on the command line,
      # try to find that character object, otherwise
      # just use the first one.
      if ($character) {
        foreach my $c (@chars) {
          if ($$c{'name'} eq $character) {
            $char=$c;
          }
        }
      } else {
        $char=$chars[0];
      }
      if (! $char) {
        warn "Character Not Found";
      } elsif ($$char{'online'}) {
        warn "Chacter already logged on";
      } elsif (! $chat->login($char)) {
        warn "Failed Login";
      } else {
        # Loop through packets as they arrive.
        print "Looping...\n";
        do {
        } while ($chat->packet());
        warn "Stream disconnected";
      }
    }
  }
  print "Sleeping 5 minutes...\n";
  sleep(300);
}
