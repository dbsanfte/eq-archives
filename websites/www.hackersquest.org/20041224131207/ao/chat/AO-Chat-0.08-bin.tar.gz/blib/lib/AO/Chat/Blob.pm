package AO::Chat::Blob;

require 5.004;
use strict;
use warnings;
use Carp qw(cluck);

sub new {
  my ($proto,$text, @args) = @_;
  my $class = ref($proto) || $proto;
  my $self = {};
  bless($self,$class);
  $self->{TEXT}=$text;
  if ($#args == 0) {
    $self->{FROMITEM}=0xc350;
    $self->{TOITEM}=1;
    $self->{QL}=0;
    if (length($args[0]) < 1) {
      cluck "Zerolength blobtext in AO::Chat::Blob->new";
      return undef;
    }
    $self->{BLOBTEXT}=$args[0];
  } elsif ($#args == 2) {
    if (($args[0] !~ /^\d+$/) || ($args[1] !~ /^\d+$/) || ($args[2] !~ /^\d+$/)) {
      cluck "All arguments must be numbers for itemblob in AO::Chat::Blob->new";
      return undef;
    }
    $self->{FROMITEM}=$args[0];
    $self->{TOITEM}=$args[1];
    $self->{QL}=$args[2];
    $self->{BLOBTEXT}="";
  } else {
    cluck "Invalid # of arguments to AO::Chat::Blob->new";
    return undef;
  }
  return $self;
}

sub parsemsg {
  my ($proto,$message,$blob,$privmsg)=@_;

  if ($privmsg) {
    ($blob)=unpack("xa*",$blob);
  }

  if (length($blob) < 16) {
    return undef;
  }

  if ($message !~ /\x11/ || $message !~ /\x12/) {
    return undef;
  }

  my $class = ref($proto) || $proto;
  my $self = {};
  bless($self,$class);

  $message =~ s/^.*\x11//g;
  $message =~ s/\x12.*$//g; 
  $self->{TEXT}=$message;
  $self->{BLOBTEXT}="";
  my ($msglen);
  ($self->{FROMITEM},$self->{TOITEM},$self->{QL},$self->{BLOBTEXT})=unpack("NNNN/a*",$blob);
  return $self;
}

sub link {
  my ($self)=@_;
  return sprintf("%c%s%c",0x11,$self->reftext(),0x12);
}

sub blob {
  my ($self,$privmsg)=@_;
  return pack(($privmsg ? 'x' : '') . "NNNN/a*",$self->{FROMITEM},$self->{TOITEM},$self->{QL},$self->{BLOBTEXT});
}

sub reftext {
  my ($self)=@_;
  return $self->{TEXT};
}

sub istextblob {
  my ($self)=@_;
  if ($self->{FROMITEM} == 0xc350 && $self->{TOITEM} == 1 && $self->{QL} == 0) {
    return 1;
  } else {
    return 0;
  }
}

sub blobtext {
  return $_[0]->{BLOBTEXT};
}

sub fromitem {
  return $_[0]->{FROMITEM};
}

sub toitem {
  return $_[0]->{TOITEM};
}

sub ql {
  return $_[0]->{QL};
}

1;

__END__

# Below is stub documentation for your module. You better edit it!

=head1 NAME

AO::Chat::Blob - Methods dealing with embedded objects in text messages.

=head1 SYNOPSIS

  use AO::Chat;
  use AO::Chat::Blob;

  package MyCallback;

  use base qw(AO::Chat::Callback);

  sub tell {
    my ($self,$player,$message,$blob)=@_;
    my $blob=new AO::Chat::Blob("Underlined clickable text",
             "Contents of big popup window");

    $player->tell("Here's some ".$blob->link(),$blob);
  }

=head1 DESCRIPTION

This module handles the embedded objects that are possible to send through
messages, and appear as underlined blue text players can shift-click to
view. The module is used both for creating and reading blobs.

At the moment two types of blobs are supported; textblobs and itemblobs.
Calling methods related to textblobs in itemblobs and vice versa has
undefined results.

=head1 METHODS

=over 4

=item new("Link contents", "Long message to display")

Creates a new textblob, "Link Contents" will be the contents of the
underlined blue text, and "Long message to display" will be what appears in
the window if the user leftclicks.

=item new("Link contents", StartItem, EndItem, QL)

Creates an item link. As actual items are interpolated between 2 items in
the database of different QL, you need to fill in both here, and they had
better be correct.

=item link()

Returns the encoded text string with the blue underlining. Include the
result of this function in the message you send to the player.

=item reftext() 

Returns the contents inside the underlined blue text.

=item istextblob()

Returns 1 if this is a text blob. If more blobs appear in the future, this
method will be deprecated.

=item blobtext()

The long message inside the blob, if any.

=item fromitem()

The start item for item interpolation.

=item toitem()

The end item for item interpolation.

=item ql()

The QL of the item.

=back

=head1 AUTHOR

Slicer, slicer@ethernalquest.org

=head1 SEE ALSO

AO::Chat, AO::Chat::Callback, AO::Chat::Player, AO::Chat::Group, perl(1).

=cut

