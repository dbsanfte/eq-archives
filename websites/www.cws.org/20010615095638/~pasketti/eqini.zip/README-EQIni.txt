
Just drop the EQINI.EXE and (optionally) EQINI.INI files into your 
EQ directory.

Run the EQINI.EXE program to edit your colors.

The program will show you how your color looks against white, black, grey,
and the EQ chat window background.

The EQINI.INI file can be used to change the color descriptions used
by the program, or to add new colors to the list should Verant include
them.  Edit the EQINI.INI file to change the color descriptions.

If the EQINI.INI file is there, the program will get the descriptions.
If not, it no big deal, it knows the default names.

You can also define color names in the EQINI.INI file.  It should be
obvious how and where to do it.

Any problems or questions, contact pasketti@cws.org

http://www.cws.org/~pasketti

Pasketti of Povar
