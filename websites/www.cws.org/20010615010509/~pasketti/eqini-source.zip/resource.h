//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by EQIni.rc
//
#define IDD_MAIN                        101
#define IDI_MAIN                        102
#define IDB_BLACK                       104
#define IDB_CHAT                        105
#define IDB_GREY                        106
#define IDB_WHITE                       107
#define IDM_MAIN                        108
#define IDD_HELPABOUT                   109
#define IDD_HELP                        110
#define IDC_WHITE                       1001
#define IDC_GREY                        1002
#define IDC_BLACK                       1003
#define IDC_PAPER                       1004
#define IDC_RUN                         1005
#define IDC_SCREEN                      1006
#define IDC_LIST1                       1007
#define IDC_COLORS                      1007
#define IDC_SLIDER1                     1009
#define IDS_RED                         1009
#define IDC_CHAT                        1010
#define IDS_GREEN                       1011
#define IDS_BLUE                        1012
#define IDC_RED                         1013
#define IDC_GREEN                       1014
#define IDC_BLUE                        1015
#define IDC_RESET                       1016
#define IDC_LOG                         1017
#define IDC_ABOUTVERSION                1018
#define IDC_COLORCHART                  1019
#define IDC_CLIST                       1021
#define IDC_ATTACK                      1025
#define IDC_INSPECT                     1026
#define IDM_HELPABOUT                   40003
#define IDM_HELP                        40004
#define IDM_RESETOLD                    40005
#define IDM_RESETCOLOR                  40005
#define IDM_RESETNEW                    40006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40007
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
