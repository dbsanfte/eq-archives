//
//  EQ Ini File Editor
//

#include <windows.h>
#include <commctrl.h>
//#include <string.h>
#include <stdio.h>
#include <colordlg.h>
#include "resource.h"

#define UM_INIT (WM_USER+1)
#define UM_REDRAW (WM_USER+2)

#define BM_XSIZE 222
#define BM_YSIZE 84

#define MAX_COLOR 64

const char szAppName[] = "EQIni";
const char szAppTitle[] = "EQ INI File Editor";
char szAppPath[MAX_PATH];
char ProgramVersion[] = "Version 00000.00000.00000.00000";


HANDLE hThisInstance = NULL;
HWND hwndMain = NULL;

int SettingsChanged = FALSE;

char ClientININame[MAX_PATH];
char INIFileName[MAX_PATH];

char SampleString[255] = "LOADING, PLEASE WAIT...";
int SampleSize;

int ColorCount;
int CurrentColor = 0;

char **ColorNames;

char *DefaultColorName[] = {
  "",
  "Say",
  "Tell",
  "Group",
  "Guild",
  "OOC",
  "Auction",
  "Shout",
  "Emote",
  "Spells",
  "You hit other",
  "Other hits you",
  "You miss other",
  "Other misses you",
  "Duel broadcasts",
  "Skills",
  "Disciplines",
  "Unused (17)",
  "Default text and stuff you type",
  "Unused (19)",
  "Merchant Offer Price",
  "Merchant Buy/Sell",
  "Your death message",
  "Others death message",
  "Other damage other",
  "Other miss other",
  "/who command",
  "Yell for help",
  "Hit for non-melee",
  "Spell worn off",
  "Money splits",
  "Loot message",
  "Dice roll (/random)",
  "Other people's spells",
  "Spell resists/failures",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  ""
};

COLORREF *Colors;

COLORREF ColorBlack = RGB(0,0,0);
COLORREF ColorWhite = RGB(255,255,255);

int ChatRed = 206;
int ChatGreen = 197;
int ChatBlue = 175;

COLORREF ChatBackground = RGB(206,197,175);

COLORREF ColorDefaults[MAX_COLOR+1] = {
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(128,0,128),
  RGB(0,255,255),
  RGB(40,240,40),
  RGB(0,128,0),
  RGB(0,128,0),
  RGB(255,0,0),
  RGB(0,0,128),
  RGB(0,0,128),
  RGB(255,255,255),
  RGB(255,0,0),
  RGB(255,255,255),
  RGB(255,255,255),
  RGB(255,255,0),
  RGB(0,0,128),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(240,240,0),
  RGB(240,240,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(128,0,128),
  RGB(0,0,0),
  RGB(0,0,128),
  RGB(240,240,0),
  RGB(0,140,0),
  RGB(0,0,128),
  RGB(255,0,0),
  RGB(0,0,128),
  RGB(255,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0),
  RGB(0,0,0)
};

HDC hdcBlack;
HDC hdcGrey;
HDC hdcWhite;
HDC hdcChat;

WNDPROC OldBlackProc;
WNDPROC OldGreyProc;
WNDPROC OldWhiteProc;
WNDPROC OldChatProc;

HFONT hfArial = NULL;

void SelectFont(void)
{
  LOGFONT lf;
  HDC hdc = GetDC(hwndMain);

  ZeroMemory(&lf, sizeof(lf));

  lf.lfHeight = -MulDiv(10, GetDeviceCaps(hdc, LOGPIXELSY), 72);
  lf.lfCharSet = ANSI_CHARSET;
  lf.lfItalic = 0;
  lf.lfWeight = FW_NORMAL;
  lf.lfPitchAndFamily = DEFAULT_PITCH;

  strcpy(lf.lfFaceName, "Arial");
  if (hfArial) {
    DeleteObject(hfArial);
  }
  hfArial = CreateFontIndirect(&lf);
  ReleaseDC(hwndMain, hdc);
}

char *GetVersionNumber(char *FName, char *Version, long *ms, long *ls)
{
  long size = 0;
  void *buff;
  VS_FIXEDFILEINFO *vsffi;
  
  *Version = 0;
  
  size = GetFileVersionInfoSize(FName, &size);
  if (size) {
    buff = malloc(size);
    GetFileVersionInfo(FName, 0, size, buff);
    VerQueryValue(buff, "\\", &vsffi, &size);
    if (vsffi->dwSignature == 0xFEEF04BD) {
      *ms = vsffi->dwFileVersionMS;
      *ls = vsffi->dwFileVersionLS;
      wsprintf(Version, "Version %u.%u.%u.%u", HIWORD(vsffi->dwFileVersionMS), 
        LOWORD(vsffi->dwFileVersionMS), HIWORD(vsffi->dwFileVersionLS),
        LOWORD(vsffi->dwFileVersionLS));
    }
    free(buff);
  }
  return Version;
}

void CreateBitmaps(void)
{
  char *bmBits;
  char *b;
  int bmlen;
  int xfudge;
  int x;
  int y;
  HWND hwnd;
  HDC hdc;
  HBITMAP hb;
	BITMAPINFO bmi;

  bmlen = BM_XSIZE * 3;
  bmlen += (bmlen % 4);
  xfudge = bmlen;
  bmlen *= BM_YSIZE;

  bmBits = malloc(bmlen);
  FillMemory(bmBits, bmlen, 0);

  hwnd = GetDlgItem(hwndMain, IDC_BLACK);
  hdc = GetDC(hwnd);

  //hb = CreateBitmap(BM_XSIZE, BM_YSIZE, 1, 24, bmBits);
  bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
  bmi.bmiHeader.biWidth = BM_XSIZE; 
  bmi.bmiHeader.biHeight = BM_YSIZE; 
  bmi.bmiHeader.biPlanes = 1; 
  bmi.bmiHeader.biBitCount = 24; 
  bmi.bmiHeader.biCompression = BI_RGB; 
  bmi.bmiHeader.biSizeImage = bmlen; 
  bmi.bmiHeader.biXPelsPerMeter = 0; 
  bmi.bmiHeader.biYPelsPerMeter = 0; 
  bmi.bmiHeader.biClrUsed = 0; 
  bmi.bmiHeader.biClrImportant = 0; 

	hb = CreateDIBitmap(hdc, &bmi.bmiHeader, CBM_INIT, bmBits, &bmi, DIB_RGB_COLORS);
  hdcBlack = CreateCompatibleDC(hdc);
  SelectObject(hdcBlack, hb);
  DeleteObject(hb);

  FillMemory(bmBits, bmlen, 255);
  
	hb = CreateDIBitmap(hdc, &bmi.bmiHeader, CBM_INIT, bmBits, &bmi, DIB_RGB_COLORS);
  hdcWhite = CreateCompatibleDC(hdc);
  SelectObject(hdcWhite, hb);
  DeleteObject(hb);
  
  FillMemory(bmBits, bmlen, 192);
  
	hb = CreateDIBitmap(hdc, &bmi.bmiHeader, CBM_INIT, bmBits, &bmi, DIB_RGB_COLORS);
  hdcGrey = CreateCompatibleDC(hdc);
  SelectObject(hdcGrey, hb);
  DeleteObject(hb);

  FillMemory(bmBits, bmlen, 0);
  for (y = 0; y < BM_YSIZE; y++) {
    b = bmBits + (y * xfudge);
    for (x = 0; x < BM_XSIZE; x++) {
      *b++ = GetBValue(ChatBackground);
      *b++ = GetGValue(ChatBackground);
      *b++ = GetRValue(ChatBackground);
    }
  }
  
	hb = CreateDIBitmap(hdc, &bmi.bmiHeader, CBM_INIT, bmBits, &bmi, DIB_RGB_COLORS);
  hdcChat = CreateCompatibleDC(hdc);
  SelectObject(hdcChat, hb);
  DeleteObject(hb);

  ReleaseDC(hwnd, hdc);


}

void ShowSampleWindow(int item, int c)
{
  HWND hwnd;
  HDC hdc;
  int cyChar;
  TEXTMETRIC tm;
  RECT rc;
  int cxClient;
  int cyClient;
  int lines;
  int l;
  int ypos;

  hwnd = GetDlgItem(hwndMain, item);
  hdc = GetDC(hwnd);

  GetClientRect(hwnd, &rc);
  cxClient = rc.right - rc.left;
  cyClient = rc.bottom - rc.top;

  switch (item) {
    case IDC_BLACK :
      BitBlt(hdc, 0, 0, BM_XSIZE, BM_YSIZE, hdcBlack, 0, 0, SRCCOPY);
      break;
    case IDC_WHITE :
      BitBlt(hdc, 0, 0, BM_XSIZE, BM_YSIZE, hdcWhite, 0, 0, SRCCOPY);
      break;
    case IDC_GREY :
      BitBlt(hdc, 0, 0, BM_XSIZE, BM_YSIZE, hdcGrey, 0, 0, SRCCOPY);
      break;
    case IDC_CHAT :
      BitBlt(hdc, 0, 0, BM_XSIZE, BM_YSIZE, hdcChat, 0, 0, SRCCOPY);
      break;
  }

  SelectObject(hdc, hfArial);
  GetTextMetrics(hdc, &tm);
  cyChar = tm.tmHeight + tm.tmExternalLeading;
  lines = cyClient / cyChar;

  SetBkMode(hdc, TRANSPARENT);
  if (item != IDC_CHAT) {
    if (Colors[c] == ColorBlack)
      SetTextColor(hdc, ColorWhite);
    else if (Colors[c] == ColorWhite)
      SetTextColor(hdc, ColorBlack);
    else
      SetTextColor(hdc, Colors[c]);
  }
  else
    SetTextColor(hdc, Colors[c]);
  ypos = 0;
  for (l = 0; l < lines; l++) {
    TextOut(hdc, 2, ypos, SampleString, SampleSize);
    ypos += cyChar;
  }

  ReleaseDC(hwnd, hdc);
}

void ShowSampleString(int c)
{
  int cursel;
  int i;
  int lmax;
  COLORREF lc;
  HWND hwndList;

  if (c < 1)
    return;
  if (c >= ColorCount)
    return;

  ShowSampleWindow(IDC_BLACK, c);
  ShowSampleWindow(IDC_WHITE, c);
  ShowSampleWindow(IDC_GREY, c);
  ShowSampleWindow(IDC_CHAT, c);

  hwndList = GetDlgItem(hwndMain, IDC_CLIST);
  cursel = SendMessage(hwndList, CB_GETCURSEL, 0, 0);
  lc = (COLORREF) SendMessage(hwndList, CB_GETITEMDATA, cursel, 0);

  if (lc != Colors[c]) {
    lmax = SendMessage(hwndList, CB_GETCOUNT, 0, 0);
    for (i = 0; i < lmax; i++) {
      lc = (COLORREF) SendMessage(hwndList, CB_GETITEMDATA, i, 0);
      if (lc == Colors[c]) {
        SendDlgItemMessage(hwndMain, IDC_CLIST, CB_SETCURSEL, i, 0);
        break;
      }
    }
    if (i == lmax)
      SendDlgItemMessage(hwndMain, IDC_CLIST, CB_SETCURSEL, -1, 0);
  }

}

void SetCurrentColor(int c)
{
  int r = GetRValue(Colors[c]);
  int g = GetGValue(Colors[c]);
  int b = GetBValue(Colors[c]);

  SetDlgItemInt(hwndMain, IDC_RED, r, FALSE);
  SetDlgItemInt(hwndMain, IDC_GREEN, g, FALSE);
  SetDlgItemInt(hwndMain, IDC_BLUE, b, FALSE);

  //SendDlgItemMessage(hwndMain, IDS_RED, TBM_SETPOS, TRUE, (BYTE) ~r);
  //SendDlgItemMessage(hwndMain, IDS_GREEN, TBM_SETPOS, TRUE, (BYTE) ~g);
  //SendDlgItemMessage(hwndMain, IDS_BLUE, TBM_SETPOS, TRUE, (BYTE) ~b);

  ShowSampleString(c);
}

void ChangeTextColor(int idItem)
{
  int cval = -1;
  int oldval;
  int success = FALSE;
  int r = GetRValue(Colors[CurrentColor]);
  int g = GetGValue(Colors[CurrentColor]);
  int b = GetBValue(Colors[CurrentColor]);

  cval = GetDlgItemInt(hwndMain, idItem, &success, FALSE);
  if (!success)
    return;
  if (cval < 0 || cval > 255)
    return;

  switch (idItem) {
    case IDC_RED :
      oldval = r;
      r = cval;
      SendDlgItemMessage(hwndMain, IDS_RED, TBM_SETPOS, TRUE, (BYTE) ~r);
      break;
    case IDC_GREEN :
      oldval = g;
      g = cval;
      SendDlgItemMessage(hwndMain, IDS_GREEN, TBM_SETPOS, TRUE, (BYTE) ~g);
      break;
    case IDC_BLUE :
      oldval = b;
      b = cval;
      SendDlgItemMessage(hwndMain, IDS_BLUE, TBM_SETPOS, TRUE, (BYTE) ~b);
      break;
  }
  Colors[CurrentColor] = RGB(r, g, b);
  ShowSampleString(CurrentColor);
  if (oldval != cval)
    SettingsChanged = TRUE;
}

void ResetDefaultColors(void)
{
  int i;

  for (i = 1; i <= MAX_COLOR; i++) {
    Colors[i] = ColorDefaults[i];
  }
  SetCurrentColor(CurrentColor);
  SettingsChanged = TRUE;
}

int ParseColors(char *buff)
{
  int r = 0;
  int g = 0;
  int b = 0;

  while (isdigit(*buff)) {
    r = (r * 10) + (*buff++ - '0');
  }
  if (*buff != ',')
    return -1;
  buff++;
  while (isdigit(*buff)) {
    g = (g * 10) + (*buff++ - '0');
  }
  if (*buff != ',')
    return -1;
  buff++;
  while (isdigit(*buff)) {
    b = (b * 10) + (*buff++ - '0');
  }
  if (*buff != 0)
    return -1;

  if (r < 0 || r > 255 || g < 0 || g > 255 || b < 0 || b > 255)
    return -1;

  return RGB(r,g,b);
}

void LoadCustomColors(void)
{
  char *Names;
  char *n;
  char buff[25];
  int cr;
  int i;
  int items = 0;

  HWND hwndList = GetDlgItem(hwndMain, IDC_CLIST);

  SendMessage(hwndList, CB_RESETCONTENT, 0, 0);

  Names = malloc(65536);
  GetPrivateProfileString("Custom", NULL, "", Names, 65535, INIFileName);
  
  n = Names;

  while (*n) {
    GetPrivateProfileString("Custom", n, "", buff, sizeof(buff), INIFileName);
    cr = ParseColors(buff);
    if (cr != -1) {
      i = SendMessage(hwndList, CB_ADDSTRING, 0, (LPARAM) n);
      SendMessage(hwndList, CB_SETITEMDATA, i, cr);
      items++;
    }
    while (*n)
      n++;
    n++;
  }

  free(Names);
  if (!items)
    ShowWindow(hwndList, SW_HIDE);
}

void LoadINIFile(void)
{
  int i;
  char col[5];
  char setting[255];
  HWND hwndItem;
  char defname[20];
  char *ch;
  int rval;
  int gval;
  int bval;
  int item;

  GetModuleFileName(hThisInstance, szAppPath, sizeof(szAppPath));
  strcpy(ClientININame, szAppPath);
  ch = strrchr(ClientININame, '\\');
  if (ch != NULL) 
    *++ch = 0;                           
  strcat(ClientININame, "EQClient.INI");

  strcpy(INIFileName, szAppPath);
  ch = strrchr(INIFileName, '\\');
  if (ch != NULL) 
    *++ch = 0;                           
  strcat(INIFileName, "EQIni.INI");

  GetPrivateProfileString("EQINI", "Sample", SampleString, SampleString, sizeof(SampleString), INIFileName);
  SampleSize = strlen(SampleString);

  ChatRed = GetPrivateProfileInt("EQINI", "ChatRed", ChatRed, INIFileName);
  ChatGreen = GetPrivateProfileInt("EQINI", "ChatGreen", ChatGreen, INIFileName);
  ChatBlue = GetPrivateProfileInt("EQINI", "ChatBlue", ChatBlue, INIFileName);
  ChatBackground = RGB(ChatRed, ChatGreen, ChatBlue);

  ColorCount = GetPrivateProfileInt("EQINI", "ColorCount", MAX_COLOR, INIFileName);
  if (ColorCount < MAX_COLOR)
    ColorCount = MAX_COLOR;
  else if (ColorCount > 255)
    ColorCount = 255;

  ColorCount++;

  ColorNames = malloc(ColorCount * sizeof(char *));
  Colors = malloc(ColorCount * sizeof(COLORREF));

  hwndItem = GetDlgItem(hwndMain, IDC_COLORS);
  SendMessage(hwndItem, LB_RESETCONTENT, 0, 0);
  for (i = 1; i < ColorCount; i++) {
    itoa(i, col, 10);
    GetPrivateProfileString("ColorNames", col, (i > MAX_COLOR ? "" : DefaultColorName[i]), setting, sizeof(setting), INIFileName);
    ColorNames[i] = strdup(setting);
    if (setting[0]) {
      item = SendMessage(hwndItem, LB_ADDSTRING, 0, (LPARAM) ColorNames[i]);
      SendMessage(hwndItem, LB_SETITEMDATA, item, i);
    }
  }

  GetPrivateProfileString("Defaults", "RunMode", "FALSE", setting, sizeof(setting), ClientININame);
  if (stricmp(setting, "FALSE") != 0)
    SendDlgItemMessage(hwndMain, IDC_RUN, BM_SETCHECK, BST_CHECKED, 0);

  GetPrivateProfileString("Defaults", "ScreenMode", "NORMAL", setting, sizeof(setting), ClientININame);
  if (stricmp(setting, "NORMAL") != 0)
    SendDlgItemMessage(hwndMain, IDC_SCREEN, BM_SETCHECK, BST_CHECKED, 0);

  GetPrivateProfileString("Defaults", "Log", "FALSE", setting, sizeof(setting), ClientININame);
  if (stricmp(setting, "FALSE") != 0)
    SendDlgItemMessage(hwndMain, IDC_LOG, BM_SETCHECK, BST_CHECKED, 0);

  GetPrivateProfileString("Defaults", "AttackOnAssist", "TRUE", setting, sizeof(setting), ClientININame);
  if (stricmp(setting, "FALSE") != 0)
    SendDlgItemMessage(hwndMain, IDC_ATTACK, BM_SETCHECK, BST_CHECKED, 0);

  GetPrivateProfileString("Defaults", "ShowInspectMessage", "TRUE", setting, sizeof(setting), ClientININame);
  if (stricmp(setting, "FALSE") != 0)
    SendDlgItemMessage(hwndMain, IDC_INSPECT, BM_SETCHECK, BST_CHECKED, 0);

  for (i = 1; i < ColorCount; i++) {
    if (ColorNames[i][0]) {
      itoa(i, col, 10);
      strcpy(defname, "User_");
      strcat(defname, col);
      strcat(defname, "_Red");
      rval = GetPrivateProfileInt("TextColors", defname, -1, ClientININame);
      strcpy(defname, "User_");
      strcat(defname, col);
      strcat(defname, "_Green");
      gval = GetPrivateProfileInt("TextColors", defname, -1, ClientININame);
      strcpy(defname, "User_");
      strcat(defname, col);
      strcat(defname, "_Blue");
      bval = GetPrivateProfileInt("TextColors", defname, -1, ClientININame);

      if (rval == -1 && gval == -1 && bval == -1) {
        if (i <= MAX_COLOR)
          Colors[i] = ColorDefaults[i];
        else
          Colors[i] = ColorBlack;
      }
      else {
        if (rval == -1)
          rval = 0;
        if (gval == -1)
          gval = 0;
        if (bval == -1)
          bval = 0;
        Colors[i] = RGB(rval, gval, bval);
      }
    }
  }
  PostMessage(hwndMain, UM_INIT, 0, 0);
  SettingsChanged = FALSE;
}

void WriteDefaultSetting(int id, char *setting, char *tval, char *fval)
{
  int v;

  v = (SendDlgItemMessage(hwndMain, id, BM_GETCHECK, 0, 0) == BST_CHECKED);
  WritePrivateProfileString("Defaults", setting, (v ? tval : fval), ClientININame);
}

void WriteINIFile(void)
{
  char r[5];
  char g[5];
  char b[5];
  char col[5];
  char defname[20];
  int i;

  WriteDefaultSetting(IDC_RUN, "RunMode", "TRUE", "FALSE");
  WriteDefaultSetting(IDC_SCREEN, "ScreenMode", "FULL", "NORMAL");
  WriteDefaultSetting(IDC_LOG, "Log", "TRUE", "FALSE");
  WriteDefaultSetting(IDC_ATTACK, "AttackOnAssist", "TRUE", "FALSE");
  WriteDefaultSetting(IDC_INSPECT, "ShowInspectMessage", "TRUE", "FALSE");

  for (i = 1; i < ColorCount; i++) {
    if (ColorNames[i][0]) {
      itoa(GetRValue(Colors[i]), r, 10);
      itoa(GetGValue(Colors[i]), g, 10);
      itoa(GetBValue(Colors[i]), b, 10);
      itoa(i, col, 10);
      strcpy(defname, "User_");
      strcat(defname, col);
      strcat(defname, "_Red");
      WritePrivateProfileString("TextColors", defname, r, ClientININame);
      strcpy(defname, "User_");
      strcat(defname, col);
      strcat(defname, "_Green");
      WritePrivateProfileString("TextColors", defname, g, ClientININame);
      strcpy(defname, "User_");
      strcat(defname, col);
      strcat(defname, "_Blue");
      WritePrivateProfileString("TextColors", defname, b, ClientININame);
    }
  }
  SettingsChanged = FALSE;
}

void ShowColorChart(int CurColor)
{
  CHOOSECOLOR cc;
  int Result;

  cc.lStructSize = sizeof(cc);
  cc.hwndOwner = hwndMain;
  cc.hInstance = hThisInstance;
  cc.rgbResult = Colors[CurColor]; 
  cc.lpCustColors = Colors; 
  cc.Flags = CC_ANYCOLOR | CC_FULLOPEN | CC_PREVENTFULLOPEN | CC_RGBINIT | CC_ENABLETEMPLATE; 
  cc.lCustData = 0; 
  cc.lpfnHook = NULL; 
  cc.lpTemplateName = "CHOOSECOLOR"; 

  Result = ChooseColor(&cc);
  if (!Result)
    return;

  if (Colors[CurColor] != cc.rgbResult) {
    Colors[CurColor] = cc.rgbResult;
    SetCurrentColor(CurColor);
    SettingsChanged = TRUE;
  }
}

BOOL CALLBACK HelpProc(HWND hDlg, UINT message, WPARAM wParam, LONG lParam)
{
  switch (message) {
    case WM_INITDIALOG : 
      SendDlgItemMessage(hDlg, IDC_ABOUTVERSION, WM_SETTEXT, 0, (LPARAM) (LPSTR) ProgramVersion);
      return TRUE;
    case WM_COMMAND :
      switch (LOWORD(wParam)) {
        case IDCANCEL :
        case IDOK : EndDialog(hDlg, 0);
                    return TRUE;
      }
      break;
  }   
  return FALSE;
}

void ShowHelpDialog(int id)
{
  int result;

  result = DialogBox(hThisInstance, MAKEINTRESOURCE(id), hwndMain, HelpProc);

  if (result == -1) 
    MessageBox(hwndMain, "Can't create dialog box", szAppTitle, MB_OK);
}

LRESULT CALLBACK WndProcBlackSubclass(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  int rvalue;

  rvalue = CallWindowProc(OldBlackProc, hwnd, message, wParam, lParam);
  if (message == WM_PAINT)
    ShowSampleString(CurrentColor);
  return rvalue;
}

LRESULT CALLBACK WndProcWhiteSubclass(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  int rvalue;

  rvalue = CallWindowProc(OldWhiteProc, hwnd, message, wParam, lParam);
  if (message == WM_PAINT)
    ShowSampleString(CurrentColor);
  return rvalue;
}

LRESULT CALLBACK WndProcGreySubclass(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  int rvalue;

  rvalue = CallWindowProc(OldGreyProc, hwnd, message, wParam, lParam);
  if (message == WM_PAINT)
    ShowSampleString(CurrentColor);
  return rvalue;
}

LRESULT CALLBACK WndProcChatSubclass(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  int rvalue;

  rvalue = CallWindowProc(OldChatProc, hwnd, message, wParam, lParam);
  if (message == WM_PAINT)
    ShowSampleString(CurrentColor);
  return rvalue;
}

void InitMain(HWND hwnd)
{
  HANDLE hi;
  long result;

  hwndMain = hwnd;

  hi = LoadIcon(hThisInstance, MAKEINTRESOURCE(IDI_MAIN));
  SendMessage(hwnd, WM_SETICON, ICON_BIG, (LPARAM) hi);

  hi = LoadImage(hThisInstance, MAKEINTRESOURCE(IDI_MAIN), IMAGE_ICON, 16, 16, LR_DEFAULTCOLOR);
  SendMessage(hwnd, WM_SETICON, ICON_SMALL, (LPARAM) hi);

  SendMessage(hwnd, WM_SETTEXT, 0, (LPARAM) szAppTitle);

  GetModuleFileName(hThisInstance, szAppPath, sizeof(szAppPath));
  GetVersionNumber(szAppPath, ProgramVersion, &result, &result);

  LoadINIFile();

  SelectFont();

  OldBlackProc = (WNDPROC) GetWindowLong(GetDlgItem(hwnd, IDC_BLACK), GWL_WNDPROC);
  SetWindowLong(GetDlgItem(hwnd, IDC_BLACK), GWL_WNDPROC, (LONG) WndProcBlackSubclass);

  OldWhiteProc = (WNDPROC) GetWindowLong(GetDlgItem(hwnd, IDC_WHITE), GWL_WNDPROC);
  SetWindowLong(GetDlgItem(hwnd, IDC_WHITE), GWL_WNDPROC, (LONG) WndProcWhiteSubclass);

  OldGreyProc = (WNDPROC) GetWindowLong(GetDlgItem(hwnd, IDC_GREY), GWL_WNDPROC);
  SetWindowLong(GetDlgItem(hwnd, IDC_GREY), GWL_WNDPROC, (LONG) WndProcGreySubclass);

  OldChatProc = (WNDPROC) GetWindowLong(GetDlgItem(hwnd, IDC_CHAT), GWL_WNDPROC);
  SetWindowLong(GetDlgItem(hwnd, IDC_CHAT), GWL_WNDPROC, (LONG) WndProcChatSubclass);

  CreateBitmaps();

  LoadCustomColors();

  SendDlgItemMessage(hwnd, IDS_RED, TBM_SETRANGE, TRUE, MAKELONG(0, 255));
  SendDlgItemMessage(hwnd, IDS_RED, TBM_SETLINESIZE, 0, 1);
  SendDlgItemMessage(hwnd, IDS_RED, TBM_SETPAGESIZE, 0, 0);
  SendDlgItemMessage(hwnd, IDS_RED, TBM_SETTICFREQ, 5, 0);
 
  SendDlgItemMessage(hwnd, IDS_GREEN, TBM_SETRANGE, TRUE, MAKELONG(0, 255));
  SendDlgItemMessage(hwnd, IDS_GREEN, TBM_SETLINESIZE, 0, 1);
  SendDlgItemMessage(hwnd, IDS_GREEN, TBM_SETPAGESIZE, 0, 0);
  SendDlgItemMessage(hwnd, IDS_GREEN, TBM_SETTICFREQ, 5, 0);
 
  SendDlgItemMessage(hwnd, IDS_BLUE, TBM_SETRANGE, TRUE, MAKELONG(0, 255));
  SendDlgItemMessage(hwnd, IDS_BLUE, TBM_SETLINESIZE, 0, 1);
  SendDlgItemMessage(hwnd, IDS_BLUE, TBM_SETPAGESIZE, 0, 0);
  SendDlgItemMessage(hwnd, IDS_BLUE, TBM_SETTICFREQ, 5, 0);

  SendDlgItemMessage(hwnd, IDC_RED, EM_SETLIMITTEXT, 3, 0);
  SendDlgItemMessage(hwnd, IDC_GREEN, EM_SETLIMITTEXT, 3, 0);
  SendDlgItemMessage(hwnd, IDC_BLUE, EM_SETLIMITTEXT, 3, 0);
 
}

LRESULT WndProcMainInit2(HWND hwnd, UINT message, WPARAM wParam, LONG lParam)
{
  SendDlgItemMessage(hwnd, IDC_COLORS, LB_SETCURSEL, 0, 0);
  CurrentColor = SendDlgItemMessage(hwnd, IDC_COLORS, LB_GETITEMDATA, 0, 0);
  SetCurrentColor(CurrentColor);
  SettingsChanged = FALSE;
  return 0;
}

LRESULT WndProcMainCommand(HWND hwnd, UINT message, WPARAM wParam, LONG lParam)
{
  UINT idItem = LOWORD(wParam);
  UINT wNotifyCode = HIWORD(wParam);
  HWND hwndCtl = (HWND) lParam;
  int ListItem;

  switch (idItem) {
    case IDC_COLORS :
      if (wNotifyCode == LBN_SELCHANGE) {
        ListItem = SendMessage(hwndCtl, LB_GETCURSEL, 0, 0);
        CurrentColor = SendMessage(hwndCtl, LB_GETITEMDATA, ListItem, 0);
        SetCurrentColor(CurrentColor);
      }
      return TRUE;
    case IDC_CLIST :
      if (wNotifyCode == CBN_SELCHANGE) {
        ListItem = SendMessage(hwndCtl, CB_GETCURSEL, 0, 0);
        Colors[CurrentColor] = SendMessage(hwndCtl, CB_GETITEMDATA, ListItem, 0);
        SetCurrentColor(CurrentColor);
      }
      return TRUE;
    case IDC_RED :
    case IDC_GREEN :
    case IDC_BLUE :
      if (wNotifyCode == EN_CHANGE)
        ChangeTextColor(idItem);
      return TRUE;
    case IDC_COLORCHART:
      ShowColorChart(CurrentColor);
      return TRUE;
    case IDOK :
      WriteINIFile();
      return TRUE;
    case IDCANCEL :
      PostMessage(hwnd, WM_CLOSE, 0, 0);
      return TRUE;
    case IDC_RESET :
      if (SettingsChanged) {
        if (MessageBox(hwnd, "Discard all changes since last save?", "Confirm", MB_YESNO | MB_ICONSTOP) != IDYES)
          return TRUE;
      }
      LoadINIFile();
      SendDlgItemMessage(hwnd, IDC_COLORS, LB_SETCURSEL, 0, 0);
      CurrentColor = SendDlgItemMessage(hwnd, IDC_COLORS, LB_GETITEMDATA, 0, 0);
      SetCurrentColor(CurrentColor);
      return TRUE;
    case IDC_RUN :
    case IDC_SCREEN :
    case IDC_LOG :
    case IDC_ATTACK :
    case IDC_INSPECT :
      if (wNotifyCode == BN_CLICKED)
        SettingsChanged = TRUE;
      return TRUE;
    case IDM_HELPABOUT :
      ShowHelpDialog(IDD_HELPABOUT);
      break;
    case IDM_HELP :
      ShowHelpDialog(IDD_HELP);
      break;
    case IDM_RESETCOLOR :
      ResetDefaultColors();
      break;
  }   
  return FALSE;
}

LRESULT WndProcMainVScroll(HWND hwnd, UINT message, WPARAM wParam, LONG lParam)
{
   char cval[10];
   int nScrollCode = LOWORD(wParam); // scroll bar value 
   int nPos = (BYTE) ~(HIWORD(wParam));  // scroll box position 
   HWND hwndScrollBar = (HWND) lParam;      // handle to scroll bar
   int idItem = (int) GetMenu(hwndScrollBar);
   int r;
   int g;
   int b;
   int oldval;

   if (!CurrentColor)
     return 0;
//   if (nScrollCode != SB_LINEUP && nScrollCode != SB_LINEDOWN)
//     return 0;
   nPos = SendMessage(hwndScrollBar, TBM_GETPOS, 0, 0);
   nPos = (BYTE) ~nPos;
   oldval = nPos;
   r = GetRValue(Colors[CurrentColor]);
   g = GetGValue(Colors[CurrentColor]);
   b = GetBValue(Colors[CurrentColor]);
   switch (idItem) {
     case IDS_RED :
       oldval = r;
       r = nPos;
       itoa(nPos, cval, 10);
       SendDlgItemMessage(hwndMain, IDC_RED, WM_SETTEXT, 0, (LPARAM) cval);
       break;
     case IDS_GREEN :
       oldval = g;
       g = nPos;
       itoa(nPos, cval, 10);
       SendDlgItemMessage(hwndMain, IDC_GREEN, WM_SETTEXT, 0, (LPARAM) cval);
       break;
     case IDS_BLUE :
       oldval = b;
       b = nPos;
       itoa(nPos, cval, 10);
       SendDlgItemMessage(hwndMain, IDC_BLUE, WM_SETTEXT, 0, (LPARAM) cval);
       break;
  }
  Colors[CurrentColor] = RGB(r, g, b);
  ShowSampleString(CurrentColor);
  if (oldval != nPos)
    SettingsChanged = TRUE;

  return 0;
}

LRESULT WndProcMainClose(HWND hwnd, UINT message, WPARAM wParam, LONG lParam)
{
  if (SettingsChanged) {
    switch (MessageBox(hwnd, "Save changes before exiting?", "Save or not?", MB_YESNOCANCEL | MB_ICONSTOP)) {
      case IDYES :
        // save changes and exit
        WriteINIFile();
        break;
      case IDNO :
        // do not save changes, just exit
        break;
      case IDCANCEL :  
        // ack, I didn't mean to do that!
        return TRUE;
    }

  }
  DestroyWindow(hwnd);
  hwndMain = NULL;
  PostQuitMessage(0);
  return FALSE;
}

LRESULT CALLBACK WndProcMain(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  switch (message) {
    case WM_INITDIALOG :
      InitMain(hwnd);
      return TRUE;
    case WM_COMMAND :
      return WndProcMainCommand(hwnd, message, wParam, lParam);
    case WM_VSCROLL :
      return WndProcMainVScroll(hwnd, message, wParam, lParam);
    case WM_CLOSE :
      return WndProcMainClose(hwnd, message, wParam, lParam);
    case UM_INIT :
      return WndProcMainInit2(hwnd, message, wParam, lParam);
  }   
  return FALSE;
}

int PASCAL WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    LPSTR lpszCmdLine, int nCmdShow)
{
  MSG	  msg;
  int result = 0;

  hThisInstance = hInstance;

  InitCommonControls();
  
  hwndMain = CreateDialog(hThisInstance, MAKEINTRESOURCE(IDD_MAIN), NULL, WndProcMain);

  if (!hwndMain) {
    MessageBox(NULL, "Can't create dialog box", szAppTitle, MB_OK);
    return FALSE;
  }
    
  while (GetMessage (&msg, NULL, 0, 0)) 
    if ((!hwndMain) || !IsDialogMessage(hwndMain, &msg)) {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
    }
  return (msg.wParam);
}
