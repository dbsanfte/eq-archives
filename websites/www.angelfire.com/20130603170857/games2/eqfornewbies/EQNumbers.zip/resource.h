//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by EQNumbers.rc
//
#define IDC_GRAPHBUT                    3
#define IDC_RESIM                       4
#define IDC_ADD2GRAPH                   5
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define ID_MYWND                        101
#define IDD_EQNUMBERS_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDD_SIMDLG                      130
#define IDD_README                      131
#define IDD_WPICK                       132
#define IDC_CLASS                       1001
#define IDC_BASETITLE                   1002
#define IDC_BASESTAT                    1003
#define IDC_MANAMOD                     1007
#define IDC_LEVM2TITLE                  1010
#define IDC_LEVM1TITLE                  1011
#define IDC_LEVTITLE                    1012
#define IDC_LEVP1TITLE                  1013
#define IDC_LEVP2TITLE                  1014
#define IDC_LEVM2                       1015
#define IDC_LEVM1                       1016
#define IDC_LEV                         1017
#define IDC_LEVP1                       1019
#define IDC_LEVP2                       1020
#define IDC_CALCBUT                     1021
#define IDC_CALCBUTW                    1022
#define IDC_WDMG1                       1023
#define IDC_WDEL1                       1024
#define IDC_WDMG2                       1025
#define IDC_WDEL2                       1026
#define IDC_WDMG3                       1027
#define IDC_WDEL3                       1028
#define IDC_SIMBUT                      1030
#define IDC_WDMG4                       1031
#define IDC_WDEL4                       1032
#define IDC_DPS3                        1035
#define IDC_DPS4                        1036
#define IDC_BESTWEAP                    1037
#define IDC_ABOUTBUT                    1038
#define IDC_NOTES                       1039
#define IDC_DACK                        1040
#define IDC_DASKILL                     1041
#define IDC_DWCK                        1042
#define IDC_DWSKILL                     1043
#define IDC_LHTEXT                      1044
#define IDC_ACTION                      1047
#define IDC_FIVESP                      1048
#define IDC_FOURSP                      1049
#define IDC_CTH                         1050
#define IDC_LVLSPIN                     1051
#define IDC_ROUNDS                      1052
#define IDC_SMIN                        1052
#define IDC_LVLST                       1053
#define IDC_AVTD                        1054
#define IDC_SSEC                        1054
#define IDC_AVPD                        1055
#define IDC_THREESP                     1055
#define IDC_AVDW                        1056
#define IDC_AVDA                        1057
#define IDC_TLTL                        1058
#define IDC_TLPD                        1059
#define IDC_TLWD                        1060
#define IDC_TLATK                       1060
#define IDC_TLDA                        1061
#define IDC_README                      1062
#define IDC_TLPDA                       1062
#define IDC_DACAP                       1063
#define IDC_TLSD                        1063
#define IDC_DWCAP                       1064
#define IDC_TLSDA                       1064
#define IDC_WLIST                       1064
#define IDC_WPICK1                      1065
#define IDC_WPICK2                      1066
#define IDC_DMGMULT                     1067
#define IDC_WPICK3                      1068
#define IDC_WPICK4                      1069
#define IDC_SHOWTIME                    1070
#define IDC_1HSLASH                     1071
#define IDC_2HSLASH                     1072
#define IDC_MAILME                      1072
#define IDC_PIERCING                    1073
#define IDC_1HBLUNT                     1074
#define IDC_2HBLUNT                     1075
#define IDC_BOWS                        1076
#define IDC_ITERATIONS                  1076
#define IDC_TOTALDAMAGE                 1078
#define IDC_TAB1                        1079
#define IDC_ADD                         32771
#define IDC_UPDATE                      65535

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1080
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
