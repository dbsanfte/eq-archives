// WPicker.cpp : implementation file
// By Strom Stillwater

#include "stdafx.h"
#include "EQNumbers.h"
#include "WPicker.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// WPicker dialog
extern int gDamage, gDelay, gHands;

WPicker::WPicker(CWnd* pParent /*=NULL*/)
	: CDialog(WPicker::IDD, pParent)
{
	//{{AFX_DATA_INIT(WPicker)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

void WPicker::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(WPicker)
	DDX_Control(pDX, IDC_WLIST, m_wlist);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(WPicker, CDialog)
	//{{AFX_MSG_MAP(WPicker)
	ON_LBN_DBLCLK(IDC_WLIST, OnDblclkWlist)
	ON_BN_CLICKED(IDC_1HBLUNT, On1hblunt)
	ON_BN_CLICKED(IDC_1HSLASH, On1hslash)
	ON_BN_CLICKED(IDC_2HBLUNT, On2hblunt)
	ON_BN_CLICKED(IDC_2HSLASH, On2hslash)
	ON_BN_CLICKED(IDC_BOWS, OnBows)
	ON_BN_CLICKED(IDC_PIERCING, OnPiercing)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// WPicker message handlers

// Initialize stuff
BOOL WPicker::OnInitDialog() 
{
	CDialog::OnInitDialog();
	FILE *wfile;
	char tmpstr[101], *sptr;
	int ta[4];
	ta[0] = 25; ta[1] = 45; ta[2] = 75;
	CString name, damage, delay, hands;
	wfile = fopen("weapons.dat","r");
	m_wlist.SetTabStops(3, ta);
	while(fgets(tmpstr, 100, wfile) != NULL) {
		if(tmpstr[0] != ';' && tmpstr[0] != '\n') {
			if(tmpstr[0] == '*') {
				sptr = strtok(tmpstr,"\n");
				m_wlist.AddString(sptr);
				sptr = NULL;
			} else {
				sptr = strtok(tmpstr,",");
				name.Format("%s",sptr);
				sptr = strtok(NULL,", ");
				damage.Format("%s\t",sptr);
				sptr = strtok(NULL,", ");
				delay.Format("%s\t",sptr);
				sptr = strtok(NULL,"\n");
				hands.Format("%s\t",sptr);
				m_wlist.AddString(damage+delay+hands+name);
			}
		}
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

// User double clicked on a weapon
void WPicker::OnDblclkWlist() 
{
	char *sptr, tmpstr[300];
	m_wlist.GetText(m_wlist.GetCurSel(),tmpstr);
	if(tmpstr[0] != '*') {
		sptr = strtok(tmpstr," \t");
		gDamage = atoi(sptr);
		sptr = strtok(NULL," \t");
		gDelay = atoi(sptr);
		sptr = strtok(NULL," \t");
		gHands = atoi(sptr);
		sptr = NULL;
	} else {
		gDamage = 0; gDelay = 0; gHands = 0;
	}
	CDialog::OnOK();
}

// The next few functions handle the quick jump buttons
// Very badly done because it looks for a specific string in
// the weapons.dat file and if it's not there, the buttons don't 
// work.

void WPicker::On1hblunt() 
{
	int i = 0;
	CString tmpstr;
	bool found = FALSE;
	while(i<m_wlist.GetCount() && !found) {
		m_wlist.GetText(i,tmpstr);
		if(tmpstr == "* 1-Handed Blunt Weapons") {
			m_wlist.SetTopIndex(i-1);
			found = TRUE;
		}
		i++;
	}
	UpdateData(FALSE);
}

void WPicker::On1hslash() 
{
	int i = 0;
	CString tmpstr;
	bool found = FALSE;
	while(i<m_wlist.GetCount() && !found) {
		m_wlist.GetText(i,tmpstr);
		if(tmpstr == "* 1-Handed Slashing Weapons") {
			m_wlist.SetTopIndex(i-1);
			found = TRUE;
		}
		i++;
	}
	UpdateData(FALSE);
}

void WPicker::On2hblunt() 
{
	int i = 0;
	CString tmpstr;
	bool found = FALSE;
	while(i<m_wlist.GetCount() && !found) {
		m_wlist.GetText(i,tmpstr);
		if(tmpstr == "* 2-Handed Blunt Weapons") {
			m_wlist.SetTopIndex(i-1);
			found = TRUE;
		}
		i++;
	}
	UpdateData(FALSE);
}

void WPicker::On2hslash() 
{
	int i = 0;
	CString tmpstr;
	bool found = FALSE;
	while(i<m_wlist.GetCount() && !found) {
		m_wlist.GetText(i,tmpstr);
		if(tmpstr == "* 2-Handed Slashing Weapons") {
			m_wlist.SetTopIndex(i-1);
			found = TRUE;
		}
		i++;
	}
	UpdateData(FALSE);
}

void WPicker::OnBows() 
{
	int i = 0;
	CString tmpstr;
	bool found = FALSE;
	while(i<m_wlist.GetCount() && !found) {
		m_wlist.GetText(i,tmpstr);
		if(tmpstr == "* Bows") {
			m_wlist.SetTopIndex(i-1);
			found = TRUE;
		}
		i++;
	}
	UpdateData(FALSE);
}

void WPicker::OnPiercing() 
{
	int i = 0;
	CString tmpstr;
	bool found = FALSE;
	while(i<m_wlist.GetCount() && !found) {
		m_wlist.GetText(i,tmpstr);
		if(tmpstr == "* Piercing Weapons") {
			m_wlist.SetTopIndex(i-1);
			found = TRUE;
		}
		i++;
	}
	UpdateData(FALSE);
}
