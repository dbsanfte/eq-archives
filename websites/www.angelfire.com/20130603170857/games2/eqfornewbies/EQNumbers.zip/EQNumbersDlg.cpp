// EQNumbersDlg.cpp : implementation file
// By Strom Stillwater

// The majority of the program is in this file.
// If you're new to MFC, get used to the ClassWizard.
// It's very helpful when dealing with dialog controls

#include "stdafx.h"
#include "EQNumbers.h"
#include "EQNumbersDlg.h"
#include "SimDlg.h"
#include "WPicker.h"
#include "ReadMe.h"
#include <stdlib.h>
#include <time.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CEQNumbersApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About
int gDamage = 0, gDelay = 0, gHands = 0;

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEQNumbersDlg dialog

CEQNumbersDlg::CEQNumbersDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEQNumbersDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEQNumbersDlg)
	m_basestat = 0;
	m_basetitle = _T("");
	m_manamod = 0;
	m_levm1 = _T("");
	m_levm1title = _T("");
	m_levm2 = _T("");
	m_levm2title = _T("");
	m_levp1 = _T("");
	m_levp1title = _T("");
	m_levp2 = _T("");
	m_levp2title = _T("");
	m_levtitle = _T("");
	m_lev = _T("");
	m_note = _T("");
	m_wdel1 = 0;
	m_wdel2 = 0;
	m_wdel3 = 0;
	m_wdel4 = 0;
	m_wdmg1 = 0;
	m_wdmg2 = 0;
	m_wdmg3 = 0;
	m_wdmg4 = 0;
	m_dps3 = _T("");
	m_dps4 = _T("");
	m_bestweap = _T("");
	m_daskill = 0;
	m_dwskill = 0;
	m_dack = FALSE;
	m_dwck = FALSE;
	m_cth = 0;
	m_foursp = _T("");
	m_fivesp = _T("");
	m_lvl = _T("");
	m_dacap = _T("");
	m_dwcap = _T("");
	m_smin = 0;
	m_ssec = 0;
	m_dmgmult = 0;
	m_showtime = FALSE;
	m_threesp = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CEQNumbersDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEQNumbersDlg)
	DDX_Control(pDX, IDC_LVLSPIN, m_lvlspin);
	DDX_Control(pDX, IDC_CLASS, m_class);
	DDX_Text(pDX, IDC_BASESTAT, m_basestat);
	DDX_Text(pDX, IDC_BASETITLE, m_basetitle);
	DDX_Text(pDX, IDC_MANAMOD, m_manamod);
	DDX_Text(pDX, IDC_LEVM1, m_levm1);
	DDX_Text(pDX, IDC_LEVM1TITLE, m_levm1title);
	DDX_Text(pDX, IDC_LEVM2, m_levm2);
	DDX_Text(pDX, IDC_LEVM2TITLE, m_levm2title);
	DDX_Text(pDX, IDC_LEVP1, m_levp1);
	DDX_Text(pDX, IDC_LEVP1TITLE, m_levp1title);
	DDX_Text(pDX, IDC_LEVP2, m_levp2);
	DDX_Text(pDX, IDC_LEVP2TITLE, m_levp2title);
	DDX_Text(pDX, IDC_LEVTITLE, m_levtitle);
	DDX_Text(pDX, IDC_LEV, m_lev);
	DDX_Text(pDX, IDC_WDEL1, m_wdel1);
	DDX_Text(pDX, IDC_WDEL2, m_wdel2);
	DDX_Text(pDX, IDC_WDEL3, m_wdel3);
	DDX_Text(pDX, IDC_WDEL4, m_wdel4);
	DDX_Text(pDX, IDC_WDMG1, m_wdmg1);
	DDX_Text(pDX, IDC_WDMG2, m_wdmg2);
	DDX_Text(pDX, IDC_WDMG3, m_wdmg3);
	DDX_Text(pDX, IDC_WDMG4, m_wdmg4);
	DDX_Text(pDX, IDC_DPS3, m_dps3);
	DDX_Text(pDX, IDC_DPS4, m_dps4);
	DDX_Text(pDX, IDC_BESTWEAP, m_bestweap);
	DDX_Text(pDX, IDC_DASKILL, m_daskill);
	DDX_Text(pDX, IDC_DWSKILL, m_dwskill);
	DDX_Check(pDX, IDC_DACK, m_dack);
	DDX_Check(pDX, IDC_DWCK, m_dwck);
	DDX_Text(pDX, IDC_CTH, m_cth);
	DDV_MinMaxInt(pDX, m_cth, 1, 100);
	DDX_Text(pDX, IDC_FOURSP, m_foursp);
	DDX_Text(pDX, IDC_FIVESP, m_fivesp);
	DDX_Text(pDX, IDC_LVLST, m_lvl);
	DDX_Text(pDX, IDC_DACAP, m_dacap);
	DDX_Text(pDX, IDC_DWCAP, m_dwcap);
	DDX_Text(pDX, IDC_SMIN, m_smin);
	DDX_Text(pDX, IDC_SSEC, m_ssec);
	DDX_Text(pDX, IDC_DMGMULT, m_dmgmult);
	DDX_Check(pDX, IDC_SHOWTIME, m_showtime);
	DDX_Text(pDX, IDC_THREESP, m_threesp);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CEQNumbersDlg, CDialog)
	//{{AFX_MSG_MAP(CEQNumbersDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_CBN_SELCHANGE(IDC_CLASS, OnSelchangeClass)
	ON_BN_CLICKED(IDC_CALCBUT, OnCalcbut)
	ON_BN_CLICKED(IDC_CALCBUTW, OnCalcbutw)
	ON_BN_CLICKED(IDC_ABOUTBUT, OnAboutbut)
	ON_BN_CLICKED(IDC_NOTES, OnNotes)
	ON_BN_CLICKED(IDC_DACK, OnDack)
	ON_BN_CLICKED(IDC_DWCK, OnDwck)
	ON_BN_CLICKED(IDC_SIMBUT, OnSimbut)
	ON_NOTIFY(UDN_DELTAPOS, IDC_LVLSPIN, OnDeltaposLvlspin)
	ON_EN_KILLFOCUS(IDC_DWSKILL, OnKillfocusDwskill)
	ON_EN_KILLFOCUS(IDC_DASKILL, OnKillfocusDaskill)
	ON_BN_CLICKED(IDC_WPICK1, OnWpick1)
	ON_BN_CLICKED(IDC_WPICK2, OnWpick2)
	ON_BN_CLICKED(IDC_WPICK3, OnWpick3)
	ON_BN_CLICKED(IDC_WPICK4, OnWpick4)
	ON_EN_UPDATE(IDC_WDEL1, OnUpdateWdel1)
	ON_EN_UPDATE(IDC_WDMG1, OnUpdateWdmg1)
	ON_BN_CLICKED(IDC_MAILME, OnMailme)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEQNumbersDlg message handlers

BOOL CEQNumbersDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	theApp.mainIcon = &m_hIcon;

	// Initialize Stuff
	simdlg = NULL;
	m_levm1 = "";
	m_levm1title = "";
	m_levm2 = "";
	m_levm2title = "";
	m_levp1 = "";
	m_levp1title = "";
	m_levp2 = "";
	m_levp2title = "";
	m_levtitle = "";
	m_lev = "";
	m_foursp = "104";
	m_fivesp = "130";
	m_threesp = "78";
	m_smin = 2;
	m_ssec = 0;
	m_cth = 55;
	m_dmgmult = 2;
	theApp.iterations = 1;
	theApp.graphWnd = NULL;
	theApp.curGraph = -1;
	m_lvlspin.SetRange(1,50);
	GetDlgItem(IDC_DWCK)->EnableWindow(FALSE);
	GetDlgItem(IDC_DWSKILL)->EnableWindow(FALSE);
	GetDlgItem(IDC_DACK)->EnableWindow(FALSE);
	GetDlgItem(IDC_DASKILL)->EnableWindow(FALSE);
	GetDlgItem(IDC_BASESTAT)->EnableWindow(FALSE);
	GetDlgItem(IDC_MANAMOD)->EnableWindow(FALSE);
	GetDlgItem(IDC_CALCBUT)->EnableWindow(FALSE);
	GetDlgItem(IDC_WDMG1)->EnableWindow(FALSE);
	GetDlgItem(IDC_WDEL1)->EnableWindow(FALSE);
	GetDlgItem(IDC_WDMG2)->EnableWindow(FALSE);
	GetDlgItem(IDC_WDEL2)->EnableWindow(FALSE);
	UpdateData(FALSE);
	m_lvlspin.SetPos(25);
	m_lvl = "25"; // Default Starting Level
	SetWindowText("EQNumbers 2.2b"); // Yes this is hardcoded =)
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CEQNumbersDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CEQNumbersDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CEQNumbersDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

// Handles graying of items.. Don't remember what the parameters are =)
void CEQNumbersDlg::GreyStuff(int dwflag, int daflag, int mflag)
{
	GetDlgItem(IDC_DWSKILL)->EnableWindow(FALSE);
	GetDlgItem(IDC_DASKILL)->EnableWindow(FALSE);
	GetDlgItem(IDC_WDMG1)->EnableWindow(TRUE);
	GetDlgItem(IDC_WDEL1)->EnableWindow(TRUE);
	if(mflag) {
		GetDlgItem(IDC_BASESTAT)->EnableWindow(TRUE);
		GetDlgItem(IDC_MANAMOD)->EnableWindow(TRUE);
		GetDlgItem(IDC_CALCBUT)->EnableWindow(TRUE);
	} else {
		GetDlgItem(IDC_BASESTAT)->EnableWindow(FALSE);
		GetDlgItem(IDC_MANAMOD)->EnableWindow(FALSE);
		GetDlgItem(IDC_CALCBUT)->EnableWindow(FALSE);
	}

	if(dwflag) {
		GetDlgItem(IDC_DWCK)->EnableWindow(TRUE);
	} else {
		GetDlgItem(IDC_DWCK)->EnableWindow(FALSE);
		GetDlgItem(IDC_WDMG2)->EnableWindow(FALSE);
		GetDlgItem(IDC_WDEL2)->EnableWindow(FALSE);
	}

	if(daflag) GetDlgItem(IDC_DACK)->EnableWindow(TRUE);
		else GetDlgItem(IDC_DACK)->EnableWindow(FALSE);
}

// This happens when the user changes class
// See Formulas.txt in the project.
void CEQNumbersDlg::OnSelchangeClass() 
{
	m_dwck = FALSE;
	m_dack = FALSE;
	m_dwskill = 0;
	m_daskill = 0;
	switch(m_class.GetCurSel()) {
		case 0 : 
			if(atoi(m_lvl) > 16) GreyStuff(1, 0, 0);
				else {
					GreyStuff(0,0,0);
					m_dwcap = "Cap: N/A";
					m_dacap = "Cap: N/A";
					break;
				}
			if(atoi(m_lvl)*5+5 < 201)
				m_dwcap.Format("Cap: %d",atoi(m_lvl)*5+5);
			else m_dwcap = "Cap: 200";
			m_dacap = "Cap: N/A";
			break;
		case 1 : m_basetitle = "Total WIS";
			GreyStuff(0,0,1);
			m_dwcap = "Cap: N/A";
			m_dacap = "Cap: N/A";
			break;
		case 2 : m_basetitle = "Total WIS";
			GreyStuff(0,0,1);
			m_dwcap = "Cap: N/A";
			m_dacap = "Cap: N/A";
			break;
		case 3 : m_basetitle = "Total INT";
			GreyStuff(0,0,1);
			m_dwcap = "Cap: N/A";
			m_dacap = "Cap: N/A";
			break;
		case 4 : m_basetitle = "Total INT";
			GreyStuff(0,0,1);
			m_dwcap = "Cap: N/A";
			m_dacap = "Cap: N/A";
			break;
		case 5 : 
			if(atoi(m_lvl) > 14) GreyStuff(1,1,0);
				else {
					GreyStuff(1,0,0);
					m_dacap = "Cap: N/A";
					if(atoi(m_lvl)*7+5 < 251)
						m_dwcap.Format("Cap: %d",atoi(m_lvl)*7+5);
					else m_dwcap = "Cap: 250";
					break;
				}
			if(atoi(m_lvl)*7+5 < 251)
				m_dwcap.Format("Cap: %d",atoi(m_lvl)*7+5);
			else m_dwcap = "Cap: 250";
			if(atoi(m_lvl)*5+5 < 201)
				m_dacap.Format("Cap: %d",atoi(m_lvl)*5+5);
			else m_dacap = "Cap: 200";
			break;
		case 6 : m_basetitle = "Total INT";
			GreyStuff(0,0,1);
			m_dwcap = "Cap: N/A";
			m_dacap = "Cap: N/A";
			break;
		case 7 : 
			if(atoi(m_lvl) > 19) {
				GreyStuff(0,1,1);
				m_dwcap = "Cap: N/A";
				if(atoi(m_lvl)*5+5 < 201)
					m_dacap.Format("Cap: %d",atoi(m_lvl)*5+5);
				else m_dacap = "Cap: 200";
				m_basetitle = "Total WIS";
				break;
			} else {
					if(atoi(m_lvl) < 9) GreyStuff(0,0,0);
						else {
							GreyStuff(0,0,1);
							m_basetitle = "Total WIS";
						}
					m_dwcap = "Cap: N/A";
					m_dacap = "Cap: N/A";
				}
			break;
		case 8 : 
			if(atoi(m_lvl) > 16 && atoi(m_lvl) < 20) {
				GreyStuff(1,0,1);
				m_dacap = "N/A";
				if(atoi(m_lvl)*5+5 < 201)
					m_dwcap.Format("Cap: %d",atoi(m_lvl)*5+5);
				else m_dwcap = "Cap: 200";
				m_basetitle = "Total WIS";
				break;
			} else if(atoi(m_lvl) > 19) {
					GreyStuff(1,1,1);
					if(atoi(m_lvl)*5+5 < 201)
						m_dwcap.Format("Cap: %d",atoi(m_lvl)*5+5);
					else m_dwcap = "Cap: 200";
					if(atoi(m_lvl)*5+5 < 201)
						m_dacap.Format("Cap: %d",atoi(m_lvl)*5+5);
					else m_dacap = "Cap: 200";
					m_basetitle = "Total WIS";
					break;
			} else if(atoi(m_lvl) < 17 && atoi(m_lvl) > 8) {
					GreyStuff(0,0,1);
					m_dwcap = "N/A";
					m_dacap = "N/A";
					m_basetitle = "Total WIS";
					break;
			} else if(atoi(m_lvl) < 9) {
					GreyStuff(0,0,0);
					m_dwcap = "N/A";
					m_dacap = "N/A";
					break;
			}
			break;
		case 9 : 
			if(atoi(m_lvl) > 12 && atoi(m_lvl) < 16) {
				GreyStuff(1,0,0);
				if(atoi(m_lvl)*6+5 < 211)
					m_dwcap.Format("Cap: %d",atoi(m_lvl)*6+5);
				else m_dwcap = "Cap: 210";
				m_dacap = "N/A";
				break;
			} else if(atoi(m_lvl) > 15) {
					GreyStuff(1,1,0);
					if(atoi(m_lvl)*6+5 < 211)
						m_dwcap.Format("Cap: %d",atoi(m_lvl)*6+5);
					else m_dwcap = "Cap: 210";
					if(atoi(m_lvl)*5+5 < 201)
						m_dacap.Format("Cap: %d",atoi(m_lvl)*5+5);
					else m_dacap = "Cap: 200";
					break;
			} else if(atoi(m_lvl) < 13) {
				GreyStuff(0,0,0);
				m_dwcap = "N/A";
				m_dacap = "N/A";
				break;
			}
		case 10 : 
			if(atoi(m_lvl) < 9) {
				GreyStuff(0,0,0);
				m_dwcap = "N/A";
				m_dacap = "N/A";
				break;
			} else if(atoi(m_lvl) > 8 && atoi(m_lvl) < 20) {
					GreyStuff(0,0,1);
					m_basetitle = "Total INT";
					m_dwcap = "N/A";
					m_dacap = "N/A";
					break;
			} else {
					GreyStuff(0,1,1);
					m_dwcap = "Cap: N/A";
					if(atoi(m_lvl)*5+5 < 201)
						m_dacap.Format("Cap: %d",atoi(m_lvl)*5+5);
					else m_dacap = "Cap: 200";
					m_basetitle = "Total INT";
					break;
			}
		case 11: m_basetitle = "Total WIS";
			GreyStuff(0,0,1);
			m_dwcap = "Cap: N/A";
			m_dacap = "Cap: N/A";
			break;
		case 12: 
			if(atoi(m_lvl) < 13) {
				GreyStuff(0,0,0);
				m_dwcap = "Cap: N/A";
				m_dacap = "Cap: N/A";
				break;
			} else if(atoi(m_lvl) > 12 && atoi(m_lvl) < 15) {
					GreyStuff(1,0,0);
					if(atoi(m_lvl)*5+5 < 201)
						m_dwcap.Format("Cap: %d",atoi(m_lvl)*5+5);
					else m_dwcap = "Cap: 200";
					m_dacap = "N/A";
					break;
			} else {
					GreyStuff(1,1,0);
					if(atoi(m_lvl)*5+5 < 201)
						m_dwcap.Format("Cap: %d",atoi(m_lvl)*5+5);
					else m_dwcap = "Cap: 200";
					if(atoi(m_lvl)*5+5 < 201)
						m_dacap.Format("Cap: %d",atoi(m_lvl)*5+5);
					else m_dacap = "Cap: 200";
					break;
			}
		case 13: m_basetitle = "Total INT";
			GreyStuff(0,0,1);
			m_dwcap = "Cap: N/A";
			m_dacap = "Cap: N/A";
			break;
	}
	m_levm1 = ""; m_levm1title = "";
	m_levm2 = ""; m_levm2title = "";
	m_levp1 = ""; m_levp1title = "";
	m_levp2 = ""; m_levp2title = "";
	m_lev = ""; m_levtitle = "";
	UpdateData(FALSE);
}

// Return Mana amount for given level
int CEQNumbersDlg::manaCalc(int level)
{
	int mana; float tmp;
	tmp = float(m_basestat)/5+2;
	// Depending on class, the calculation varies.
	switch(m_class.GetCurSel()) {
		case 7 : case 8 :
		case 10 : mana = int(tmp*(level-8)+m_manamod+20); break;
		default : mana = int(tmp*level+m_manamod); break;
	}
	return mana;
}

// User hit the calculate button
void CEQNumbersDlg::OnCalcbut() 
{
	UpdateData(TRUE);
	if(!GetDlgItem(IDC_BASESTAT)->IsWindowEnabled()) return;
	int m_level = atoi(m_lvl);
	if(m_level > 0 && m_level < 51) {
	if(m_level > 2)
		m_levm2title.Format("%d",m_level - 2);
	else m_levm2title = "";
	if(m_level > 1)
		m_levm1title.Format("%d",m_level - 1);
	else m_levm1title = "";
	m_levtitle.Format("%d",m_level);
	if(m_level < 50)
		m_levp1title.Format("%d",m_level + 1);
	else m_levp1title = "";
	if(m_level < 49)
		m_levp2title.Format("%d",m_level + 2);
	else m_levp2title = "";
	if(m_level > 2)
		m_levm2.Format("%d",manaCalc(m_level - 2));
	else m_levm2 = "";
	if(m_level > 1) 
		m_levm1.Format("%d",manaCalc(m_level - 1));
	else {
		m_levm1 = "";
		m_levm2 = "";
	}
	if((m_class.GetCurSel()==7 || m_class.GetCurSel()==8 || 
		m_class.GetCurSel()==10) && m_level<=9) {
		m_levm1 = "";
		m_levm2 = "";
	}
	if((m_class.GetCurSel()==7 || m_class.GetCurSel()==8 || 
		m_class.GetCurSel()==10) && m_level==10) {
		m_levm2 = "";
	}
	m_lev.Format("%d",manaCalc(m_level));
	if(m_level < 50)
		m_levp1.Format("%d",manaCalc(m_level + 1));
	else m_levp1 = "";
	if(m_level < 49)
		m_levp2.Format("%d",manaCalc(m_level + 2));
	else m_levp2 = "";
	UpdateData(FALSE);
	}
}

// User hit the calculate button in the Weapon compare section
void CEQNumbersDlg::OnCalcbutw() 
{
	double tmp, max = 0.0;
	int count = 0, best = 0;
	UpdateData(TRUE);
	if(m_wdel3 != 0 && m_wdmg3 != 0) {
		tmp = double(m_wdmg3)/double(m_wdel3);
		m_dps3.Format("%.4f",tmp); count++;
		if(tmp > max) {
			max = tmp; best = 3;
		}
	} else m_dps3 = "";
	if(m_wdel4 != 0 && m_wdmg4 != 0) {
		tmp = double(m_wdmg4)/double(m_wdel4);
		m_dps4.Format("%.4f",tmp); count++;
		if(tmp > max) {
			max = tmp; best = 4;
		}
	} else m_dps4 = "";
	if(count > 1) {
		switch(best) {
			case 3: m_bestweap = "The best weapon is the first one."; break;
			case 4: m_bestweap = "The best weapon is the second one."; break;
		}
	} else m_bestweap = "";
	UpdateData(FALSE);
}

// About button...
void CEQNumbersDlg::OnAboutbut() 
{
	CAboutDlg *dlg = new CAboutDlg;
	dlg->DoModal();
}

// Notes button...
void CEQNumbersDlg::OnNotes() 
{
	ReadMe *dlg = new ReadMe;
	dlg->DoModal();
}

// Double attack check button
void CEQNumbersDlg::OnDack() 
{
	UpdateData(TRUE);
	char tmpstr[20], *sptr;
	if(m_dack) {
		GetDlgItem(IDC_DASKILL)->EnableWindow(TRUE);
		strcpy(tmpstr,m_dacap);
		sptr = strtok(tmpstr," ");
		sptr = strtok(NULL,"");
		m_daskill = atoi(sptr);
	} else {
		GetDlgItem(IDC_DASKILL)->EnableWindow(FALSE);
		m_daskill = 0;
	}
	UpdateData(FALSE);
}

// Dual Weld check button
void CEQNumbersDlg::OnDwck() 
{
	UpdateData(TRUE);
	char tmpstr[20], *sptr;
	if(m_dwck) {
		GetDlgItem(IDC_DWSKILL)->EnableWindow(TRUE);
		GetDlgItem(IDC_WDMG2)->EnableWindow(TRUE);
		GetDlgItem(IDC_WDEL2)->EnableWindow(TRUE);
		strcpy(tmpstr,m_dwcap);
		sptr = strtok(tmpstr," ");
		sptr = strtok(NULL,"");
		m_dwskill = atoi(sptr);
		if(gHands == 2) {
			AfxMessageBox("Warning: You are enabling Dual Wield with\na known 2h weapon in your right hand.", MB_OK | MB_ICONEXCLAMATION);
		}
	} else {
		GetDlgItem(IDC_DWSKILL)->EnableWindow(FALSE);
		GetDlgItem(IDC_WDMG2)->EnableWindow(FALSE);
		GetDlgItem(IDC_WDEL2)->EnableWindow(FALSE);
		m_dwskill = 0;
	}
	UpdateData(FALSE);
}

// Uhh... not sure what this is =)
void CEQNumbersDlg::SimDone()
{
	simdlg = NULL;	
}

// Massive simulate function
void CEQNumbersDlg::Simulate() 
{
	UpdateData(TRUE);
	if(simdlg != NULL) {
		simdlg->SetActiveWindow();
		simdlg->m_listbox.ResetContent();
	}else {
		simdlg = new SimDlg(this);
		simdlg->Create();
		simdlg->ShowWindow(SW_SHOWNORMAL);
	}

	int dap, dwp, dam, m_level, t1, t2;
	long int tlpd = 0, tlpda = 0, tlsd = 0, tlsda = 0, tlatk = 0, gtotal = 0;
	double stime = 0.0, w1speed, w2speed, w1Time = 0.0, w2Time = 0.0;
	double tmpf;
	bool ev = FALSE, timep = FALSE, pflag = FALSE;
	CString tmp;
	
	// Graph Variables
	int gsecs = 0, gpos = 0, gdam = 0;
	double gtime = 0.0;
	gsecs = m_smin*60 + m_ssec;
	theApp.curGraph++; if(theApp.curGraph > 9) theApp.curGraph = 9;
	theApp.ginc[theApp.curGraph] = float(gsecs)/200.0;
	m_level = atoi(m_lvl);
	srand((unsigned)time(NULL));
	w1speed = double(m_wdel1)/10;
	w2speed = double(m_wdel2)/10;
	theApp.sectime[theApp.curGraph] = m_ssec + m_smin*60;
	if(m_dack) {
		tmpf = (m_daskill + m_level) / 500.0;
		tmpf *= 100.0;
		dap = int(tmpf);
	}
	if(m_dwck) {
		tmpf = (m_dwskill + m_level) / 600.0;
		tmpf *= 100.0;
		dwp = int(tmpf);
	}
	for(int k = 0; k < theApp.iterations; k++) {
	if(k == theApp.iterations - 1) pflag = TRUE;
		else pflag = FALSE;
	tlpd = 0; tlpda = 0; tlsd = 0; tlsda = 0; tlatk = 0;
	stime = 0.0; w1Time = 0.0; w2Time = 0.0;
	gpos = 0; gdam = 0;
	gtime = 0.0;
	ev = FALSE; timep = FALSE;
	while(stime < (double(m_smin * 60.0)+double(m_ssec))) {	
		t1 = int(w1Time*10+0.00001);
		t2 = int(stime*10+0.00001);
		if(t1 == t2) {
			// Primary Attack W1
			if(m_showtime && pflag) {
				if(stime - (int(stime)/60)*60 < 10.0)
					tmp.Format("Time: %2d:0%.1f",int(stime)/60,stime - (int(stime)/60)*60);
				else tmp.Format("Time: %2d:%.1f",int(stime)/60,stime - (int(stime)/60)*60);
				timep = TRUE;
				simdlg->m_listbox.AddString(tmp);
			}
			if(rand()%100 < m_cth) {
				dam = rand()%(m_wdmg1*m_dmgmult+1)+1;
				tlpd += dam; gdam += dam;
				tmp.Format("You hit an enemy for %d damage. (P)",dam);
			} else tmp = "You missed! (P)";

			if(pflag) simdlg->m_listbox.AddString(tmp); ev = TRUE;
			
			// Check for Double Attack W1
			if(m_dack && (rand()%100 < dap)) {
				if(rand()%100 < m_cth) {
					dam = rand()%(m_wdmg1*m_dmgmult+1)+1;
					tlpda += dam; gdam += dam;
					tmp.Format("You hit an enemy for %d damage. (PDA)",dam);	
				}
				else tmp = "You missed! (PDA)";
				if(pflag) simdlg->m_listbox.AddString(tmp); ev = TRUE;
			}
			w1Time += w1speed;
		}
		t1 = int(w2Time*10+0.00001);
		t2 = int(stime*10+0.00001);
		if(t1==t2 && m_dwck) {	
			if(rand()%100 < dwp) {
				// Secondary Attack W2
				if(!timep && m_showtime && pflag) {
					if(stime - (int(stime)/60)*60 < 10.0)
						tmp.Format("Time: %2d:0%.1f",int(stime)/60,stime - (int(stime)/60)*60);
					else tmp.Format("Time: %2d:%.1f",int(stime)/60,stime - (int(stime)/60)*60);
					simdlg->m_listbox.AddString(tmp);
				}
				if(rand()%100 < m_cth) {
					dam = rand()%(m_wdmg2*m_dmgmult+1)+1;
					tlsd += dam; gdam += dam;
					tmp.Format("You hit an enemy for %d damage. (S)",dam);
				} else tmp = "You missed! (S)";
				if(pflag) simdlg->m_listbox.AddString(tmp); ev = TRUE;
			
				// Check for Double Attack W2
				if(m_dack && (rand()%100 < dap) && m_dwskill > 149) {
					if(rand()%100 < m_cth) {
						dam = rand()%(m_wdmg2*m_dmgmult+1)+1;
						tlsda += dam; gdam += dam;
						tmp.Format("You hit an enemy for %d damage. (SDA)",dam);	
					}
					else tmp = "You missed! (SDA)";
					if(pflag) simdlg->m_listbox.AddString(tmp); ev = TRUE;
				}
			}
			w2Time += w2speed;
		}
		stime += 0.01;
		if(stime >= gtime) {
			gtime += theApp.ginc[theApp.curGraph];
			if(k==0) theApp.graphArray[gpos][theApp.curGraph] = gdam;
				else theApp.graphArray[gpos][theApp.curGraph] += gdam;
			gpos++;  // gdam = 0;
		}
		if(ev) {
			if(pflag) simdlg->m_listbox.AddString("");	
			tlatk++;
			ev = FALSE; 
		}
		timep = FALSE;
	}
	gtotal = gtotal + tlpd + tlpda + tlsd + tlsda;
	}
	if(gpos < 201)
		for(int k = gpos; k<201; k++)
			theApp.graphArray[k][theApp.curGraph]=theApp.graphArray[gpos-1][theApp.curGraph];
	for(k = 0; k < 201; k++)
		theApp.graphArray[k][theApp.curGraph] = theApp.graphArray[k][theApp.curGraph]/theApp.iterations;
	simdlg->m_listbox.AddString("");
	simdlg->m_listbox.AddString("End of Simulation.");
	simdlg->m_tlatk.Format("%d",tlatk);
	if(theApp.iterations == 1) {
		simdlg->m_totaldamage = "Total Damage:";
		simdlg->m_tltl.Format("%d",tlpd+tlpda+tlsd+tlsda);
	} else {
		simdlg->m_totaldamage = "Average Total Damage:";
		simdlg->m_tltl.Format("%d",gtotal/theApp.iterations);
	}
	simdlg->m_tlpd.Format("%d",tlpd);
	simdlg->m_tlpda.Format("%d",tlpda);
	simdlg->m_tlsd.Format("%d",tlsd);
	simdlg->m_tlsda.Format("%d",tlsda);
	simdlg->UpdateData(FALSE);
}

// Simulate button
void CEQNumbersDlg::OnSimbut() 
{
	Simulate();
}

// The spin buttons on the level
void CEQNumbersDlg::OnDeltaposLvlspin(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	
	if(pNMUpDown->iPos+pNMUpDown->iDelta > 0) {
		UpdateData(TRUE);
		if(pNMUpDown->iPos+pNMUpDown->iDelta < 51) {
			m_fivesp.Format("%d",(pNMUpDown->iPos+pNMUpDown->iDelta)*5+5);
			m_foursp.Format("%d",(pNMUpDown->iPos+pNMUpDown->iDelta)*4+4);
			m_threesp.Format("%d",(pNMUpDown->iPos+pNMUpDown->iDelta)*3+3);
			if(atoi(m_fivesp) > 255) m_fivesp = "255";
			if(atoi(m_foursp) > 255) m_foursp = "255";
			m_lvl.Format("%d",pNMUpDown->iPos+pNMUpDown->iDelta);
		}
		if((m_class.GetCurSel()==7 || m_class.GetCurSel()==8 || 
			m_class.GetCurSel()==10) && pNMUpDown->iPos+pNMUpDown->iDelta < 9) {
			GetDlgItem(IDC_BASESTAT)->EnableWindow(FALSE);
			GetDlgItem(IDC_MANAMOD)->EnableWindow(FALSE);
			GetDlgItem(IDC_CALCBUT)->EnableWindow(FALSE);
			UpdateData(FALSE);
			OnSelchangeClass();
		} else if((m_class.GetCurSel()==7 || m_class.GetCurSel()==8 || 
			m_class.GetCurSel()==10) && pNMUpDown->iPos+pNMUpDown->iDelta > 8){
				GetDlgItem(IDC_BASESTAT)->EnableWindow(TRUE);
				GetDlgItem(IDC_MANAMOD)->EnableWindow(TRUE);
				GetDlgItem(IDC_CALCBUT)->EnableWindow(TRUE);
				UpdateData(FALSE);
				OnSelchangeClass();
				if(m_basestat > 0) OnCalcbut();
			} else {
				OnSelchangeClass();
				UpdateData(FALSE);
				if(m_basestat > 0) OnCalcbut();
			}
	}
	*pResult = 0;
}

// Called after the focus moves away from the Dual Weld check box
void CEQNumbersDlg::OnKillfocusDwskill() 
{
	UpdateData(TRUE);
	bool warn = FALSE;
	if(m_dwskill > 200 && m_class.GetCurSel()!=5 && m_class.GetCurSel()!=9) warn = TRUE; 
	else if(m_dwskill > 250 && m_class.GetCurSel()==5) warn = TRUE;
	else if(m_dwskill > 210 && m_class.GetCurSel()==9) warn = TRUE;
	else if(m_dwskill > atoi(m_lvl)*7+5 && m_class.GetCurSel()==5) warn = TRUE;
	else if(m_dwskill > atoi(m_lvl)*6+5 && m_class.GetCurSel()==9) warn = TRUE;
	else if(m_dwskill > atoi(m_lvl)*5+5 && m_class.GetCurSel()!=5 &&
		m_class.GetCurSel()!=9) warn = TRUE;

	if(warn) AfxMessageBox("Warning: Dual Wield Skill is greater than the current cap for your level.", MB_OK | MB_ICONEXCLAMATION);
}

// Called after the focus moves away from the Double Attack check box
void CEQNumbersDlg::OnKillfocusDaskill() 
{
	UpdateData(TRUE);
	bool warn = FALSE;
	if(m_daskill > 200) warn = TRUE; 
		else if(m_daskill > atoi(m_lvl)*5+5) warn = TRUE;

	if(warn) AfxMessageBox("Warning: Double Attack Skill is greater than the current cap for your level.", MB_OK | MB_ICONEXCLAMATION);
}

// Pick weapon one button (for sim)
void CEQNumbersDlg::OnWpick1() 
{
	FILE *wfile;
	wfile = fopen("weapons.dat","r");
	if(wfile == NULL) {
		AfxMessageBox("Error: weapons.dat file not found in the\nsame directory with EQNumbers.exe", MB_OK | MB_ICONSTOP);
	} else {
		WPicker *dlg = new WPicker;
		if(dlg->DoModal()==IDOK) {
			m_wdmg1 = gDamage;
			m_wdel1 = gDelay;
			if(gHands==2) {
				m_dwck = FALSE;
				GetDlgItem(IDC_WDMG2)->EnableWindow(FALSE);
				GetDlgItem(IDC_WDEL2)->EnableWindow(FALSE);
			}
		}
	}
	UpdateData(FALSE);
}

// Pick weapon two button (for sim)
void CEQNumbersDlg::OnWpick2() 
{
	FILE *wfile;
	wfile = fopen("weapons.dat","r");
	if(wfile == NULL) {
		AfxMessageBox("Error: weapons.dat file not found in the\nsame directory with EQNumbers.exe", MB_OK | MB_ICONSTOP);
	} else {
		WPicker *dlg = new WPicker;
		if(dlg->DoModal()==IDOK) {
			if(gHands==2) {
				AfxMessageBox("You cannot hold a 2h weapon in your left hand.", MB_OK | MB_ICONINFORMATION);
			} else {
				m_wdmg2 = gDamage;
				m_wdel2 = gDelay;
			}
		}
	}
	UpdateData(FALSE);
}

// First pick weapon button in the compare section
void CEQNumbersDlg::OnWpick3() 
{
	FILE *wfile;
	wfile = fopen("weapons.dat","r");
	if(wfile == NULL) {
		AfxMessageBox("Error: weapons.dat file not found in the\nsame directory with EQNumbers.exe", MB_OK | MB_ICONSTOP);
	} else {
		WPicker *dlg = new WPicker;
		if(dlg->DoModal()==IDOK) {
			m_wdmg3 = gDamage;
			m_wdel3 = gDelay;
		}
	}
	UpdateData(FALSE);
}

// Second pick weapon button in the compare section
void CEQNumbersDlg::OnWpick4() 
{
	FILE *wfile;
	wfile = fopen("weapons.dat","r");
	if(wfile == NULL) {
		AfxMessageBox("Error: weapons.dat file not found in the\nsame directory with EQNumbers.exe", MB_OK | MB_ICONSTOP);
	} else {
		WPicker *dlg = new WPicker;
		if(dlg->DoModal()==IDOK) {
			m_wdmg4 = gDamage;
			m_wdel4 = gDelay;
		}
	}
	UpdateData(FALSE);
}

void CEQNumbersDlg::OnUpdateWdel1() 
{
	gHands = 0; gDamage = 0; gDelay = 0;	
}

void CEQNumbersDlg::OnUpdateWdmg1() 
{
	gHands = 0; gDamage = 0; gDelay = 0;	
}

// Link for webpage button... change this to whatever you want
void CEQNumbersDlg::OnMailme() 
{
	// This page has been removed!
	ShellExecute(NULL, "open", "http://eq.stratics.com/eqnumbers", NULL, NULL, SW_SHOWNORMAL);
}
