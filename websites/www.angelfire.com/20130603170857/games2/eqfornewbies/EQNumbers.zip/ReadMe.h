#if !defined(AFX_README_H__F23AC8D4_4F90_11D3_94F6_004033A056DE__INCLUDED_)
#define AFX_README_H__F23AC8D4_4F90_11D3_94F6_004033A056DE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// ReadMe.h : header file
// By Strom Stillwater

/////////////////////////////////////////////////////////////////////////////
// ReadMe dialog

class ReadMe : public CDialog
{
// Construction
public:
	ReadMe(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(ReadMe)
	enum { IDD = IDD_README };
	CListBox	m_text;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(ReadMe)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(ReadMe)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_README_H__F23AC8D4_4F90_11D3_94F6_004033A056DE__INCLUDED_)
