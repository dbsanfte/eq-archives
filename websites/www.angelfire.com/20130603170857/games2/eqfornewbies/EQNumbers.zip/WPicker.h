#if !defined(AFX_WPICKER_H__165385E0_5137_11D3_94F6_004033A056DE__INCLUDED_)
#define AFX_WPICKER_H__165385E0_5137_11D3_94F6_004033A056DE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// WPicker.h : header file
// Strom Stillwater

/////////////////////////////////////////////////////////////////////////////
// WPicker dialog

class WPicker : public CDialog
{
// Construction
public:
	WPicker(CWnd* pParent = NULL);   // standard constructor
	BOOL Create();
// Dialog Data
	//{{AFX_DATA(WPicker)
	enum { IDD = IDD_WPICK };
	CListBox	m_wlist;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(WPicker)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(WPicker)
	virtual BOOL OnInitDialog();
	afx_msg void OnDblclkWlist();
	afx_msg void On1hblunt();
	afx_msg void On1hslash();
	afx_msg void On2hblunt();
	afx_msg void On2hslash();
	afx_msg void OnBows();
	afx_msg void OnPiercing();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WPICKER_H__165385E0_5137_11D3_94F6_004033A056DE__INCLUDED_)
