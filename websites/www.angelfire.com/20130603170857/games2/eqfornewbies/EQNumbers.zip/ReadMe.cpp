// ReadMe.cpp : implementation file
// By Strom Stillwater

#include "stdafx.h"
#include "EQNumbers.h"
#include "ReadMe.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// ReadMe dialog


ReadMe::ReadMe(CWnd* pParent /*=NULL*/)
	: CDialog(ReadMe::IDD, pParent)
{
	//{{AFX_DATA_INIT(ReadMe)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void ReadMe::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(ReadMe)
	DDX_Control(pDX, IDC_README, m_text);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(ReadMe, CDialog)
	//{{AFX_MSG_MAP(ReadMe)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// ReadMe message handlers

BOOL ReadMe::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// This stuff is commented, you can either delete and put in your own readme info
	// or whatever.  This is what is displayed when the user hits the Read Me button

	/*m_text.AddString("EQNumbers Version 2.2b By Strom Stillwater - Povar Server");
	m_text.AddString("");
	m_text.AddString("Disclaimer: If this program tells you your level 5 monk can");
	m_text.AddString("solo a sand giant, and you die trying, it's not my fault!");
	m_text.AddString("Most of the calculations used in this program are 'rumored'");
	m_text.AddString("to be the correction formulas.  They're accuracy can always");
	m_text.AddString("be questioned or corrected... send email to efowler@jove.acs.unt.edu");
	m_text.AddString("");
	m_text.AddString("Parts of the Program");
	m_text.AddString("");
	m_text.AddString("Weapon Picker - Don't remember the delay on your Dragoon Dirk?");
	m_text.AddString("Just hit the PICK buttons that are between the delay and damage fields.");
	m_text.AddString("A box will pop up with ALL the weapons listed on the EQ'lizer web site ");
	m_text.AddString("(http://gameznet.com/eq)");
	m_text.AddString("You may also manually add to or edit this list be editing the file called");
	m_text.AddString("weapons.dat in the same directory with the program.  Just use any text editor");
	m_text.AddString("The format is specified in the comments of that file. I did not include");
	m_text.AddString("the classes that could use the weapon because there were just way too many");
	m_text.AddString("and I don't have the time.  You can always check the EQ'lizer web site");
	m_text.AddString("for more weapon info including stat changes, magic effects, and what classes");
	m_text.AddString("can use the weapon.  Also, you will see buttons that are called Quick Jump Buttons.");
	m_text.AddString("These buttons will jump immediately to the section for the button you pushed.");
	m_text.AddString("");
	m_text.AddString("Skill Caps - Gaining 5 points per level in a skill is the normal");
	m_text.AddString("gain for most skills, however, some only gain 4. The general caps");
	m_text.AddString("are listed beside your level.  The caps for double attack and dual wield");
	m_text.AddString("skills are listed below their skill box.  They are turned on if you are ");
	m_text.AddString("high enough level to attain them.");
	m_text.AddString("");
	m_text.AddString("Mana Calculation - This is pretty straight foward as in the pervious");
	m_text.AddString("version of EQNumbers. I removed the +INT/WIS Items field because it");
	m_text.AddString("isn't needed.  Now just put your total INT or WIS in the box.");
	m_text.AddString("Note: There may be problems with the hybrid classes (RAG, PAL, SHD) mana");
	m_text.AddString("calculations, the number may be too low... There must be some part of the");
	m_text.AddString("the formula we are missing if this is true. Only Verant knows =)");
	m_text.AddString("");
	m_text.AddString("Weapon Compare - Enter your damage and delay values and hit calculate.");
	m_text.AddString("This has been changed since the last version, it now shows the damage");
	m_text.AddString("ratio instead of damage per second (which turned out to be not very");
	m_text.AddString("accurate).");
	m_text.AddString("");
	m_text.AddString("Dual Wield and Double Attack - If your class gains these skills");
	m_text.AddString("you will be able to check either/or to be used in a simulation");
	m_text.AddString("Check the box, and put your skill value in the box below it.");
	m_text.AddString("");
	m_text.AddString("Simulation - This has been upgraded since version 2.0a, it");
	m_text.AddString("is now much more accurate, AND is time-based instead of round-based (which made no");
	m_text.AddString("sense). All the formulas are now correct and the statistics only show total");
	m_text.AddString("damage done by each part.  Since it is time-based, put in how long you'd like");
	m_text.AddString("the combat to last.  This is very accurate, if you put in 5 seconds, you won't");
	m_text.AddString("get but 2 or 3 swings at most.  More importantly it illustrates that faster");
	m_text.AddString("weapons dual wielded tend to do better over a longer period of time than hefty");
	m_text.AddString("high damage, slow, 2 handed weapons.  Play around with it, you'll be surprised.");
	m_text.AddString("Notice since it is now time-based, weapon delay counts!");
	m_text.AddString("");
	m_text.AddString("Chance to Hit and Damage Multiplier, what are these?");
	m_text.AddString("The chance to hit you can look at as the 'abilities of the enemy'.  Meaning");
	m_text.AddString("if you are a level 30 Paladin, you're going to hit a fire beetle almost every");
	m_text.AddString("swing, so boost the chance to hit to around 90%.  If you're level 20 and you're");
	m_text.AddString("trying to hack on a sand giant, better make chance to hit about 20%.");
	m_text.AddString("The Damage Multipier is in because we do not currently know the formulas for ");
	m_text.AddString("melee classes' damage at higher levels.  For non-melee classes, this number should");
	m_text.AddString("remain 2. If you are a high level fighter and the damage the simulator is showing");
	m_text.AddString("is way too low, boost this number up a point or two until you see your usual max");
	m_text.AddString("damage showing up. Use integers only (no decimals).  As an example to head you in");
	m_text.AddString("the right direction, A level 45 Ranger's mulitipier is 'most likely' 5.  You may");
	m_text.AddString("see a point or two less than your maximum damage, but this is because STR isn't a");
	m_text.AddString("factor.");
	m_text.AddString("");
	m_text.AddString("Graphing - New to version 2.2, you can now see graphs of weapons performace");
	m_text.AddString("in the simulator.  Once you run a simulation, there are a set of 3 buttons at the");
	m_text.AddString("bottom of the simulation window.  These are 'Graph', 'Resimulate', and");
	m_text.AddString("'Add to Graph'. The Graph button will take the current simulation and put it on");
	m_text.AddString("the graph, erasing any previous graphs.  The Resimulate button works the same way");
	m_text.AddString("as the Simulate button in the main window, just more convenient.  The Add to Graph");
	m_text.AddString("button will take the current simulation and add it to the graph in a different color.");
	m_text.AddString("It's up to you to remember which color lines represent which weapon set you choose.");
	m_text.AddString("There is a limit of 10 lines on the graph, but I wouldn't suggest doing more than 3");
	m_text.AddString("because you will quickly forget which color means what :)  You can change weapons");
	m_text.AddString("or skills at any time with the graph and simulation windows up.  The graph will");
	m_text.AddString("will automatically 'adjust' to fit the weapon that did the highest damage.  As");
	m_text.AddString("a result, the other lines will seem to shift downward, but the results are still");
	m_text.AddString("accurate; only the scale changed.");
	m_text.AddString("Note: Changing time length of the simulation and putting simulations on the same");
	m_text.AddString("graph produces strange and WRONG results. Don't change to times for one graph.");
	m_text.AddString("The Update and Add buttons on the graph window operate the same as the Graph and Add");
	m_text.AddString("to Graph buttons in the simulation window.");
	m_text.AddString("");
	m_text.AddString("To all you monks out there, I'm sorry, but at the moment I STILL don't have");
	m_text.AddString("the correct formula for your damage. It pratically changes every level. When");
	m_text.AddString("I found out these formulas, it WILL be included!  We know your punch delay is 30");
	m_text.AddString("but the damage varies by level (we don't know how exactly).");
	m_text.AddString("");
	m_text.AddString("Regarding special attacks... Kicks, bashes, slams, and other special attacks are ");
	m_text.AddString("not factored in.  The simulation is mainly for comparing weapons.  However, I would");
	m_text.AddString("put these factors in if I get the formulas.");
	m_text.AddString("");
	m_text.AddString("Here are the other factors that are NOT considered are the simulation:");
	m_text.AddString(" - Character STR and DEX");
	m_text.AddString(" - Any high level damage bonuses and modifiers (working on this one)");
	m_text.AddString(" - The Weapon skill (damage is truely random)");
	m_text.AddString(" - The defense abilities of the enemy");
	m_text.AddString(" - Special Weapon powers (does not know spell effects)");
	m_text.AddString(" - Chance to Critical Hit (warriors)");
	m_text.AddString(" - Lag :)");
	m_text.AddString("");
	m_text.AddString("I would be more than willing to include these variables if I had");
	m_text.AddString("ANY clue as to the formulas for the calculations.");
	m_text.AddString("");
	m_text.AddString("I believe that's all for this version.  As always if you find");
	m_text.AddString("bugs or errors, or just want to chat about the formulas, send");
	m_text.AddString("me and email at");
	m_text.AddString("");
	m_text.AddString("efowler@jove.acs.unt.edu");
	m_text.AddString("");
	m_text.AddString("Known Problems/Bugs:");
	m_text.AddString(" - Mana is automatically updated (if you have a WIS or INT value");
	m_text.AddString(" put in).  If you hold down the level spin button going from level");
	m_text.AddString(" 25 down to level 1, the mana calculation will seem to 'stick'");
	m_text.AddString(" at one of the lower levels.  Just change your level from 1 to 2 then");
	m_text.AddString(" back to 1 to get the correct calculation.");
	m_text.AddString("");
	m_text.AddString("Thanks for trying out EQNumbers! And... Good Hunting.");
	m_text.AddString("");
	m_text.AddString("Strom Stillwater - Povar Server");
	m_text.AddString("");
	m_text.AddString("");
	m_text.AddString("By the way... like to send BIG thanks out to Sam Schlansky for providing");
	m_text.AddString("me with valuable formulas and accurate information to the best of his knowledge.");
	m_text.AddString("He's the one that made the simulator possible.  Thanks Sam!");*/
		return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
