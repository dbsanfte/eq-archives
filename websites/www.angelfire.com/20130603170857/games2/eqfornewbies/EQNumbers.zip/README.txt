EQNumbers Source Code - By Strom Stillwater

Compiler: Visual C++ 6.0
Language: Duh, C++ of course, but uses MFC.
Notes: If you have VC++ 6.0, you should be able to just open
  the project file and hit build all and it should get no errors
  and no warnings.  The real meat of the code is in EQNumbersDlg.cpp

Install Notes:
  Just unzip the .zip file in a an EQNumbers folder where you'd normally 
store your projects.  There is a subdirectory called "Executable" which is
simply the compiled version with the weapons.dat... this is what I'd release
to the public for example.

  Here it is... the source code for EQNumbers.  The only reason I'm
releasing it to the public is because I have no more time to work
on it and I'm hoping people will work off this code to create
better versions or use it as inspiration to make a new one from scratch.

First a small disclaimer:

  I'm definitely NOT claiming that this is my most beautiful piece of code
ever.  It was written without intent to release it to the public.  Because
of that, it's not well commented, and the logic might be kinda strange in
some places. If I planned for it to be released to the public, it would
look much better =)  Because of this, I highly recommend that you have some basic
MFC knowledge or good C++ knowledge with a desire to figure out MFC.

I will answer emails with questions ABOUT the code, not HOW to code.

If you plan to release your own modification to EQNumbers to the public
the only thing I ask is that I'm given credit somewhere (preferably the
About box). 

If you plan to do a public release the FIRST thing I'd look into doing
is increasing the max level to 60 since EQNumbers is pre-Kunark program.
You'd also have to tweak all the skill caps accordingly.

Long Live Norrath!!

Strom Stillwater - Povar (well, not much anymore hehe)
efowler@jove.acs.unt.edu


