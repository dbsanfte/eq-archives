SilverDeth & Sepolevne's DAoC User Interface - Ver. 1.5a


User Interface Version: 1.5b
User Interface File Size: 7.89 MB
User Interface Last Updated: June 22, 2006


User Interface Newest Features:

- The Master Level Window has been improved.


Getting Started:

Once you have downloaded the Deth Guild user interface, there are a few 
things you need to follow to before you can get it running:

- Step 1: Open the Dark Age Of Camelot folder that contains whatever 
version of DAoC you are currently playing. There is a folder located 
here Called "ui." Open that folder as well. In it should be several 
more sub-folders, with names like atlantis, midgard, albion, 
classic, isles, and so forth. 

- Step 2: Create a folder in the "ui" directory titled "Custom." If 
this folder already exists, open this directory, and move all of it's 
contents into a different folder. The "Custom" folder needs to be empty.

- Step 3: Decompress the dethguildui.zip file and place it on your 
desktop.

- Step 4: Cut and paste the contents of the "Custom" directory in the 
"dethguildui" folder on your desktop into the "Custom" directory you 
just created or cleaned out on your hard drive in UI folder on your Hard�Disk.

- Step 5: Launch Dark age of Camelot: Trials of Atlantis. Select "no thank you" 
for a character type, so you can adjust your game options.

- Step 6: Once you have loaded the character select screen, choose the options 
window. Set the Interface type to "Custom." Accept these change.

- Step 7: Press the "PLAY" button to enter the game environment. You will 
need to adjust the positions of your new windows when you log in.


If you have more questions, check out our website at: http://www.dethguild.com
