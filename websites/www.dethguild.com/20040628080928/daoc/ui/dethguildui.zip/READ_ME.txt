Welcome to SilverDeth's 1.69c Arwin's Trails of Atlantis User Interface READ ME.


Once you have downloaded the Deth Guild user interface, there are a few things you 
need to follow to before you can get it running:

- Step 1: Open the Dark Age Of Camelot folder that contains your Trials 
of Atlantis expansion pack. There is a folder located here Called "ui." 
Open that folder as well. In it should include several more sub-folders, 
with names like midgard, albion, classic, isles, and so forth. 

- Step 2: Create a folder in the "ui" directory titled "Custom." If this 
folder already exists, open this directory, and move all of it's contents 
into a different folder. The "Custom" folder needs to be empty.

- Step 3: Copy the contents of the "dethguildui" folder into the "Custom" 
directory you just created or cleaned out.

- Step 4: Launch Dark age of Camelot: Trials of Atlantis. Select "no thank 
you" for a character type, so you can adjust your game options.

- Step 5: Once you have loaded the character select screen, choose the 
options window. Set the Interface type to "Custom." Accept these change.

- Step 6: Press the "PLAY" button to enter the game environment. 
You will need to adjust the positions of your new windows when you log in. 

If you need more assistance, please go to the following link:
http://www.dethguild.com/daoc/ui/uiinfo.html