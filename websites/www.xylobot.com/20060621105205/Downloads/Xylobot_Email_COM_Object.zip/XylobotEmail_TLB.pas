unit XylobotEmail_TLB;

// ************************************************************************ //
// WARNING                                                                    
// -------                                                                    
// The types declared in this file were generated from data read from a       
// Type Library. If this type library is explicitly or indirectly (via        
// another type library referring to this type library) re-imported, or the   
// 'Refresh' command of the Type Library Editor activated while editing the   
// Type Library, the contents of this file will be regenerated and all        
// manual modifications will be lost.                                         
// ************************************************************************ //

// PASTLWTR : $Revision:   1.130.1.0.1.0.1.6  $
// File generated on 5/21/2002 8:09:13 AM from Type Library described below.

// ************************************************************************  //
// Type Lib: G:\BenSource\Delphi6\COM Email\XylobotEmail.tlb (1)
// LIBID: {529B2F68-99F6-48C4-8656-418D5B67B1A9}
// LCID: 0
// Helpfile: 
// DepndLst: 
//   (1) v2.0 stdole, (G:\WINNT\System32\stdole2.tlb)
//   (2) v4.0 StdVCL, (G:\WINNT\System32\stdvcl40.dll)
// ************************************************************************ //
{$TYPEDADDRESS OFF} // Unit must be compiled without type-checked pointers. 
{$WARN SYMBOL_PLATFORM OFF}
{$WRITEABLECONST ON}
{$VARPROPSETTER ON}
interface

uses Windows, ActiveX, Classes, Graphics, StdVCL, Variants;
  

// *********************************************************************//
// GUIDS declared in the TypeLibrary. Following prefixes are used:        
//   Type Libraries     : LIBID_xxxx                                      
//   CoClasses          : CLASS_xxxx                                      
//   DISPInterfaces     : DIID_xxxx                                       
//   Non-DISP interfaces: IID_xxxx                                        
// *********************************************************************//
const
  // TypeLibrary Major and minor versions
  XylobotEmailMajorVersion = 1;
  XylobotEmailMinorVersion = 0;

  LIBID_XylobotEmail: TGUID = '{529B2F68-99F6-48C4-8656-418D5B67B1A9}';

  IID_IEmailEngine: TGUID = '{B0535E08-0814-48AC-AB0B-FC2F6BB1BCD3}';
  CLASS_EmailEngine: TGUID = '{9B4751C2-76D5-45FF-8580-6DF270DE12BA}';
type

// *********************************************************************//
// Forward declaration of types defined in TypeLibrary                    
// *********************************************************************//
  IEmailEngine = interface;
  IEmailEngineDisp = dispinterface;

// *********************************************************************//
// Declaration of CoClasses defined in Type Library                       
// (NOTE: Here we map each CoClass to its Default Interface)              
// *********************************************************************//
  EmailEngine = IEmailEngine;


// *********************************************************************//
// Interface: IEmailEngine
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {B0535E08-0814-48AC-AB0B-FC2F6BB1BCD3}
// *********************************************************************//
  IEmailEngine = interface(IDispatch)
    ['{B0535E08-0814-48AC-AB0B-FC2F6BB1BCD3}']
    function SendEmail(const Recipient: WideString; const Subject: WideString; 
                       const Body: WideString): Integer; safecall;
  end;

// *********************************************************************//
// DispIntf:  IEmailEngineDisp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {B0535E08-0814-48AC-AB0B-FC2F6BB1BCD3}
// *********************************************************************//
  IEmailEngineDisp = dispinterface
    ['{B0535E08-0814-48AC-AB0B-FC2F6BB1BCD3}']
    function SendEmail(const Recipient: WideString; const Subject: WideString; 
                       const Body: WideString): Integer; dispid 1;
  end;

// *********************************************************************//
// The Class CoEmailEngine provides a Create and CreateRemote method to          
// create instances of the default interface IEmailEngine exposed by              
// the CoClass EmailEngine. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoEmailEngine = class
    class function Create: IEmailEngine;
    class function CreateRemote(const MachineName: string): IEmailEngine;
  end;

implementation

uses ComObj;

class function CoEmailEngine.Create: IEmailEngine;
begin
  Result := CreateComObject(CLASS_EmailEngine) as IEmailEngine;
end;

class function CoEmailEngine.CreateRemote(const MachineName: string): IEmailEngine;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_EmailEngine) as IEmailEngine;
end;

end.
