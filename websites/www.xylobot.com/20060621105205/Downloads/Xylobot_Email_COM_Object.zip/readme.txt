**********************************************************************
                      Xylobot Email COM Object
**********************************************************************


INSTALLATION

Copy the XylobotEmail.dll file to your Xylobot directory.  Then open 
up a DOS prompt and type regsvr32 XylobotEmail.dll.  You should see
a message that the dll was successfully registered.


EXAMPLE SCRIPT

//      Script:  Demo_SendEmail
// Description:  Send an email using MAPI
//     Created:  4/5/2002 9:44:20 AM

// Note - if you use Outlook, make sure Outlook is already open
// and you are logged in.

var EmailEngine : ComVariant;

EmailEngine := CreateOleObject('XylobotEmail.EmailEngine');

var Recip : string = 'youremail@somwhere.com';
var Subj  : string = 'Test from Xylobot';
var Body  : string = 'This is the email';

var rc : integer;
rc := EmailEngine.SendEmail(Recip, Subj, Body);
Debug('Send Email Result = ' + IntToStr(rc));

// Return code of zero is success
// End of script


COPYRIGHT (c) 2002 - Released to public domain
written by Ben Ziegler
http://www.xylobot.com


