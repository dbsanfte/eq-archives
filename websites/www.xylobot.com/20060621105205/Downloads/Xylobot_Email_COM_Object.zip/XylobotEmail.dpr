library XylobotEmail;

uses
  ComServ,
  XylobotEmail_TLB in 'XylobotEmail_TLB.pas',
  Mail in 'Mail.pas' {EmailEngine: CoClass};

exports
  DllGetClassObject,
  DllCanUnloadNow,
  DllRegisterServer,
  DllUnregisterServer;

{$R *.TLB}

{$R *.RES}

begin
end.
