unit Mail;

{$WARN SYMBOL_PLATFORM OFF}

interface

uses
  ComObj, ActiveX, XylobotEmail_TLB, StdVcl;

type
  TEmailEngine = class(TAutoObject, IEmailEngine)
  protected
    function SendEmail(const Recipient, Subject, Body: WideString): Integer;
      safecall;
    { Protected declarations }
  end;

implementation

uses ComServ, Mapi;

function TEmailEngine.SendEmail(const Recipient, Subject,
  Body: WideString): Integer;
var
   pRecip, pSubj, pBody : string;
   MapiMessage : TMapiMessage;
   Recip       : TMapiRecipDesc;
begin
   pRecip := Recipient;
   pSubj  := Subject;
   pBody  := Body;

   FillChar(Recip, sizeof(Recip), 0);
   Recip.ulRecipClass := MAPI_TO;
   Recip.lpszName     := PChar(pRecip);
   Recip.lpszAddress  := PChar(pRecip);

   with MapiMessage do begin
      ulReserved := 0;
      lpszSubject := PChar(pSubj);
      lpszNoteText := PChar(pBody);
      lpszMessageType := nil;
      lpszDateReceived := nil;
      lpszConversationID := nil;
      flFlags := 0;
      lpOriginator := nil;
      nRecipCount := 1;
      lpRecips := @Recip;
      nFileCount := 0;
      lpFiles := nil;
   end;

   Result := MapiSendMail(0, 0, MapiMessage,
    { MAPI_DIALOG or MAPI_LOGON_UI or } MAPI_NEW_SESSION, 0);
end;


initialization
  TAutoObjectFactory.Create(ComServer, TEmailEngine, Class_EmailEngine,
    ciMultiInstance, tmApartment);
end.
