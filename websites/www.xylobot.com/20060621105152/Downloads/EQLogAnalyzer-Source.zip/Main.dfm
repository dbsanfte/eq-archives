object MainForm: TMainForm
  Left = 231
  Top = 107
  Width = 555
  Height = 440
  Caption = 'EQ Log Analyzer'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  OnHide = FormHide
  PixelsPerInch = 96
  TextHeight = 13
  object TopPanel: TPanel
    Left = 0
    Top = 0
    Width = 547
    Height = 41
    Align = alTop
    BevelInner = bvRaised
    BevelOuter = bvLowered
    TabOrder = 0
    object BrowseBut: TSpeedButton
      Left = 424
      Top = 9
      Width = 23
      Height = 22
      Caption = '...'
      OnClick = BrowseButClick
    end
    object AnalyzeBut: TButton
      Left = 8
      Top = 8
      Width = 75
      Height = 25
      Caption = 'A&nalyze'
      TabOrder = 0
      OnClick = AnalyzeButClick
    end
    object FileNameEdit: TEdit
      Left = 96
      Top = 10
      Width = 321
      Height = 21
      TabOrder = 1
      Text = 'c:\Program Files\EverQuest\eqlog.txt'
    end
    object AboutBut: TButton
      Left = 460
      Top = 8
      Width = 75
      Height = 25
      Anchors = [akTop, akRight]
      Caption = '&About...'
      TabOrder = 2
      OnClick = AboutButClick
    end
  end
  object PageControl1: TPageControl
    Left = 0
    Top = 57
    Width = 547
    Height = 337
    ActivePage = TabSheet1
    Align = alClient
    TabOrder = 1
    object SkillSheet: TTabSheet
      Caption = 'Skills'
      object SkillGrid: TDBGrid
        Left = 0
        Top = 0
        Width = 583
        Height = 309
        Align = alClient
        DataSource = SkillSource
        PopupMenu = GridPopup
        TabOrder = 0
        TitleFont.Charset = DEFAULT_CHARSET
        TitleFont.Color = clWindowText
        TitleFont.Height = -11
        TitleFont.Name = 'MS Sans Serif'
        TitleFont.Style = []
        OnTitleClick = GridTitleClick
      end
    end
    object ZoneSheet: TTabSheet
      Caption = 'Zones'
      ImageIndex = 3
      object ZoneGrid: TDBGrid
        Left = 0
        Top = 0
        Width = 583
        Height = 309
        Align = alClient
        DataSource = ZoneSource
        PopupMenu = GridPopup
        TabOrder = 0
        TitleFont.Charset = DEFAULT_CHARSET
        TitleFont.Color = clWindowText
        TitleFont.Height = -11
        TitleFont.Name = 'MS Sans Serif'
        TitleFont.Style = []
        OnTitleClick = GridTitleClick
      end
    end
    object PlayerSheet: TTabSheet
      Caption = 'Players'
      ImageIndex = 2
      object DBGrid1: TDBGrid
        Left = 0
        Top = 0
        Width = 583
        Height = 309
        Align = alClient
        DataSource = PlayerSource
        PopupMenu = GridPopup
        TabOrder = 0
        TitleFont.Charset = DEFAULT_CHARSET
        TitleFont.Color = clWindowText
        TitleFont.Height = -11
        TitleFont.Name = 'MS Sans Serif'
        TitleFont.Style = []
        OnTitleClick = GridTitleClick
      end
    end
    object TabSheet1: TTabSheet
      Caption = 'Buy Items'
      ImageIndex = 3
      object DBGrid2: TDBGrid
        Left = 0
        Top = 0
        Width = 539
        Height = 309
        Align = alClient
        DataSource = BuySource
        PopupMenu = GridPopup
        TabOrder = 0
        TitleFont.Charset = DEFAULT_CHARSET
        TitleFont.Color = clWindowText
        TitleFont.Height = -11
        TitleFont.Name = 'MS Sans Serif'
        TitleFont.Style = []
        OnTitleClick = GridTitleClick
      end
    end
  end
  object StatusBar1: TStatusBar
    Left = 0
    Top = 394
    Width = 547
    Height = 19
    Panels = <
      item
        Width = 50
      end>
    SimplePanel = False
  end
  object ProgressBar1: TProgressBar
    Left = 0
    Top = 41
    Width = 547
    Height = 16
    Align = alTop
    Min = 0
    Max = 100
    TabOrder = 3
  end
  object OpenDialog1: TOpenDialog
    Filter = 'Text Files|*.txt|All Files|*.*'
    Options = [ofHideReadOnly, ofFileMustExist, ofEnableSizing]
    Left = 260
    Top = 129
  end
  object FormSettings1: TFormSettings
    SavePosition = True
    SaveValues = True
    LoadValues = True
    SaveValueOptions = [svEdit, svMemo, svCheckBox, svRadioButton, svListBox, svComboBox, svFontDialog, svMenuItem, svHotKey]
    Left = 332
    Top = 129
  end
  object SkillsTab: TkbmMemTable
    Active = True
    AttachedAutoRefresh = True
    EnableIndexes = True
    IndexDefs = <>
    RecalcOnIndex = False
    RecalcOnFetch = True
    SortFields = 'Name'
    SortOptions = []
    AllDataOptions = [mtfSaveData, mtfSaveNonVisible, mtfSaveBlobs, mtfSaveFiltered, mtfSaveIgnoreRange, mtfSaveIgnoreMasterDetail, mtfSaveDeltas]
    StoreDataOnForm = False
    CommaTextOptions = [mtfSaveData]
    PersistentSaveOptions = [mtfSaveData, mtfSaveNonVisible]
    PersistentSaveFormat = mtsfBinary
    EnableJournal = False
    EnableVersioning = False
    VersioningMode = mtvm1SinceCheckPoint
    FilterOptions = []
    Version = '2.35'
    Left = 44
    Top = 129
    object SkillsTabName: TStringField
      DisplayLabel = 'Skill Name'
      DisplayWidth = 20
      FieldName = 'Name'
      Size = 32
    end
    object SkillsTabMax: TIntegerField
      DisplayWidth = 6
      FieldName = 'Max'
    end
    object SkillsTabMin: TIntegerField
      DisplayWidth = 6
      FieldName = 'Min'
    end
    object SkillsTabNumIncrease: TIntegerField
      DisplayLabel = 'Num +'
      DisplayWidth = 6
      FieldName = 'NumIncrease'
    end
    object SkillsTabLastIncrease: TDateTimeField
      DisplayLabel = 'Last Increase'
      DisplayWidth = 22
      FieldName = 'LastIncrease'
      DisplayFormat = 'mm/dd/yyyy  hh:nn am/pm'
    end
  end
  object SkillSource: TDataSource
    DataSet = SkillsTab
    Left = 132
    Top = 129
  end
  object ZoneTab: TkbmMemTable
    Active = True
    AttachedAutoRefresh = True
    EnableIndexes = True
    IndexDefs = <>
    RecalcOnIndex = False
    RecalcOnFetch = True
    SortOptions = []
    AllDataOptions = [mtfSaveData, mtfSaveNonVisible, mtfSaveBlobs, mtfSaveFiltered, mtfSaveIgnoreRange, mtfSaveIgnoreMasterDetail, mtfSaveDeltas]
    StoreDataOnForm = False
    CommaTextOptions = [mtfSaveData]
    PersistentSaveOptions = [mtfSaveData, mtfSaveNonVisible]
    PersistentSaveFormat = mtsfBinary
    EnableJournal = False
    EnableVersioning = False
    VersioningMode = mtvm1SinceCheckPoint
    FilterOptions = []
    Version = '2.35'
    Left = 44
    Top = 177
    object ZoneTabName: TStringField
      DisplayLabel = 'Zone Name'
      DisplayWidth = 20
      FieldName = 'Name'
      Size = 32
    end
    object ZoneTabLastEnter: TDateTimeField
      DisplayLabel = 'Last Enter'
      DisplayWidth = 22
      FieldName = 'LastEnter'
      DisplayFormat = 'mm/dd/yyyy  hh:nn am/pm'
    end
    object ZoneTabNumEnter: TIntegerField
      DisplayLabel = 'Num Enter'
      FieldName = 'NumEnter'
    end
  end
  object ZoneSource: TDataSource
    DataSet = ZoneTab
    Left = 132
    Top = 177
  end
  object PlayerTab: TkbmMemTable
    Active = True
    AttachedAutoRefresh = True
    EnableIndexes = True
    IndexDefs = <>
    RecalcOnIndex = False
    RecalcOnFetch = True
    SortOptions = []
    AllDataOptions = [mtfSaveData, mtfSaveNonVisible, mtfSaveBlobs, mtfSaveFiltered, mtfSaveIgnoreRange, mtfSaveIgnoreMasterDetail, mtfSaveDeltas]
    StoreDataOnForm = False
    CommaTextOptions = [mtfSaveData]
    PersistentSaveOptions = [mtfSaveData, mtfSaveNonVisible]
    PersistentSaveFormat = mtsfBinary
    EnableJournal = False
    EnableVersioning = False
    VersioningMode = mtvm1SinceCheckPoint
    FilterOptions = []
    Version = '2.35'
    Left = 44
    Top = 225
    object PlayerTabName: TStringField
      DisplayWidth = 20
      FieldName = 'Name'
      Size = 32
    end
    object PlayerTabLastSeen: TDateTimeField
      DisplayLabel = 'Last Seen'
      DisplayWidth = 22
      FieldName = 'LastSeen'
      DisplayFormat = 'mm/dd/yyyy  hh:nn am/pm'
    end
    object PlayerTabNumSeen: TIntegerField
      DisplayLabel = 'Num Seen'
      DisplayWidth = 6
      FieldName = 'NumSeen'
    end
    object PlayerTabMaxLevel: TIntegerField
      DisplayLabel = 'Max Level'
      FieldName = 'MaxLevel'
    end
    object PlayerTabMinLevel: TIntegerField
      DisplayLabel = 'Min Level'
      FieldName = 'MinLevel'
    end
    object PlayerTabClass: TStringField
      DisplayWidth = 10
      FieldName = 'Class'
      Size = 32
    end
    object PlayerTabRace: TStringField
      DisplayWidth = 10
      FieldName = 'Race'
      Size = 32
    end
    object PlayerTabGuild: TStringField
      DisplayWidth = 15
      FieldName = 'Guild'
      Size = 32
    end
    object PlayerTabAnonymous: TBooleanField
      DisplayLabel = 'Anon'
      FieldName = 'Anonymous'
    end
  end
  object PlayerSource: TDataSource
    DataSet = PlayerTab
    Left = 132
    Top = 225
  end
  object GridPopup: TPopupMenu
    Left = 276
    Top = 209
    object ExporttoExcel1: TMenuItem
      Caption = '&Export to Excel...'
      OnClick = ExporttoExcel1Click
    end
  end
  object BuyTab: TkbmMemTable
    Active = True
    AttachedAutoRefresh = True
    EnableIndexes = True
    IndexDefs = <>
    RecalcOnIndex = False
    RecalcOnFetch = True
    SortOptions = []
    AllDataOptions = [mtfSaveData, mtfSaveNonVisible, mtfSaveBlobs, mtfSaveFiltered, mtfSaveIgnoreRange, mtfSaveIgnoreMasterDetail, mtfSaveDeltas]
    StoreDataOnForm = False
    CommaTextOptions = [mtfSaveData]
    PersistentSaveOptions = [mtfSaveData, mtfSaveNonVisible]
    PersistentSaveFormat = mtsfBinary
    EnableJournal = False
    EnableVersioning = False
    VersioningMode = mtvm1SinceCheckPoint
    FilterOptions = []
    Version = '2.35'
    Left = 44
    Top = 273
    object BuyTabItem: TStringField
      FieldName = 'Item'
      Size = 32
    end
    object BuyTabLastBuy: TDateTimeField
      DisplayLabel = 'Last Buy'
      FieldName = 'LastBuy'
      DisplayFormat = 'mm/dd/yyyy  hh:nn am/pm'
    end
    object BuyTabNumBuy: TIntegerField
      DisplayLabel = 'Num Buy'
      FieldName = 'NumBuy'
    end
    object BuyTabTotCopper: TIntegerField
      DisplayLabel = 'Total Copper'
      FieldName = 'TotCopper'
      DisplayFormat = ',0'
    end
    object BuyTabLastVendor: TStringField
      DisplayLabel = 'Last Vendor'
      DisplayWidth = 20
      FieldName = 'LastVendor'
      Size = 64
    end
  end
  object BuySource: TDataSource
    DataSet = BuyTab
    Left = 132
    Top = 273
  end
  object StartTimer: TTimer
    Interval = 1
    OnTimer = StartTimerTimer
    Left = 460
    Top = 129
  end
end
