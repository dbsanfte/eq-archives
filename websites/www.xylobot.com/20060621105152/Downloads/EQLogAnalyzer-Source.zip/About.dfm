object AboutForm: TAboutForm
  Left = 290
  Top = 174
  ActiveControl = OKBut
  BorderStyle = bsDialog
  Caption = 'About'
  ClientHeight = 152
  ClientWidth = 383
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 55
    Top = 8
    Width = 301
    Height = 45
    Alignment = taCenter
    Caption = 'EQ Log Analyzer'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -32
    Font.Name = 'Arial Black'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Image1: TImage
    Left = 8
    Top = 16
    Width = 32
    Height = 32
    AutoSize = True
    Picture.Data = {
      055449636F6E0000010001002020100000000000E80200001600000028000000
      2000000040000000010004000000000080020000000000000000000000000000
      0000000000000000000080000080000000808000800000008000800080800000
      C0C0C000808080000000FF0000FF000000FFFF00FF000000FF00FF00FFFF0000
      FFFFFF0000000007777777777777777770000000000000077777000000000000
      00000000000000077770FFF0FF0FF0FF00000000000000077770000000000000
      00000000000000077770FFF0FF0FF0FF00000000000000077770000000000000
      00000000000000077770FFF0FF0FF0FF00000000000000077777000000000000
      0000000000000007777777777777777770000000000000077777777777777777
      7000000000000007777770000000000000000000000000077777077777777777
      7777000000000007777077000000000000077000000000077770700FFFFF0FFF
      FF00700000000007777070FF00FF0FF00FF0070000000007777070FF00FF0FF0
      0FF0070000000007777070FFFFFF0FFFFF007700000000077770700FFFF000FF
      F007700000000007777077000000000000770000000000077777077777777777
      7770000000000007777770000000000000000000000000077777777777777777
      7000000000000007777777777777777770000000000000007777777777777777
      0000000000000000777777777777777700000000000000000777777777777770
      0000000000000000000777000077700000000000000000000000007777000000
      0000000000000000000000777700000000000000000000000000000000000000
      0000000000000000000000077000000000000000000000000000000770000000
      00000000FC00003FFC00003FFC00007FFC00007FFC00007FFC00007FFC00007F
      FC00007FFC00003FFC00003FFC00000FFC000007FC000003FC000001FC000001
      FC000001FC000001FC000003FC000007FC00000FFC00001FFC00003FFC00003F
      FE00007FFE00007FFF0000FFFF8001FFFFE007FFFFF81FFFFFFC3FFFFFFC3FFF
      FFFC3FFF}
  end
  object VersionLabel1: TVersionLabel
    Left = 144
    Top = 64
    Width = 217
    Height = 13
    VersionResource = vrFileVersion
    VersionResourceKey = 'FileVersion'
    InfoPrefix = 'File Version:'
    ShowInfoPrefix = True
    LangCharset = '040904E4'
    AutoSize = False
    Alignment = taCenter
  end
  object VersionLabel2: TVersionLabel
    Left = 144
    Top = 80
    Width = 217
    Height = 13
    VersionResource = vrLegalCopyright
    VersionResourceKey = 'LegalCopyright'
    InfoPrefix = 'Legal Copyright:'
    ShowInfoPrefix = False
    LangCharset = '040904E4'
    AutoSize = False
    Alignment = taCenter
  end
  object VersionLabel3: TVersionLabel
    Left = 144
    Top = 96
    Width = 217
    Height = 13
    VersionResource = vrComments
    VersionResourceKey = 'Comments'
    InfoPrefix = 'Comments:'
    ShowInfoPrefix = False
    LangCharset = '040904E4'
    AutoSize = False
    Alignment = taCenter
  end
  object InternetLabel1: TInternetLabel
    Left = 8
    Top = 64
    Width = 125
    Height = 13
    Cursor = crHandPoint
    Hint = 'http://www.uorobot.com/eqmacros.htm'
    Alignment = taCenter
    AutoSize = False
    Caption = 'EQ Macros Home Page'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clBlue
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = [fsUnderline]
    ParentFont = False
    ParentShowHint = False
    ShowHint = True
    URL = 'http://www.uorobot.com/eqmacros.htm'
  end
  object InternetLabel2: TInternetLabel
    Left = 8
    Top = 80
    Width = 125
    Height = 13
    Cursor = crHandPoint
    Hint = 'http://www.uorobot.com'
    Alignment = taCenter
    AutoSize = False
    Caption = 'UO Robot Home Page'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clBlue
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = [fsUnderline]
    ParentFont = False
    ParentShowHint = False
    ShowHint = True
    URL = 'http://www.uorobot.com'
  end
  object InternetLabel3: TInternetLabel
    Left = 8
    Top = 96
    Width = 125
    Height = 13
    Cursor = crHandPoint
    Hint = 'http://www.radix.net/~bziegler/Delphi/'
    Alignment = taCenter
    AutoSize = False
    Caption = 'Ben'#39's Delphi Page'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clBlue
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = [fsUnderline]
    ParentFont = False
    ParentShowHint = False
    ShowHint = True
    URL = 'http://www.radix.net/~bziegler/Delphi/'
  end
  object StatLabel: TLabel
    Left = 8
    Top = 136
    Width = 30
    Height = 13
    Caption = 'Status'
  end
  object OKBut: TButton
    Left = 296
    Top = 120
    Width = 75
    Height = 25
    Caption = 'OK'
    Default = True
    ModalResult = 1
    TabOrder = 0
    OnClick = OKButClick
  end
  object CloseTimer: TTimer
    Enabled = False
    Interval = 100
    OnTimer = CloseTimerTimer
    Left = 160
    Top = 104
  end
end
