unit About;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, ExtCtrls, verslab, InternetLabel;

type
  TAboutForm = class(TForm)
    Label1: TLabel;
    Image1: TImage;
    OKBut: TButton;
    VersionLabel1: TVersionLabel;
    VersionLabel2: TVersionLabel;
    VersionLabel3: TVersionLabel;
    InternetLabel1: TInternetLabel;
    InternetLabel2: TInternetLabel;
    InternetLabel3: TInternetLabel;
    CloseTimer: TTimer;
    StatLabel: TLabel;
    procedure CloseTimerTimer(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure OKButClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
    ShowTime : DWORD;
  end;

var
  AboutForm: TAboutForm;

implementation

{$R *.DFM}

procedure TAboutForm.CloseTimerTimer(Sender: TObject);
var
   Remain : double;
begin
   Remain := 5.0 - ((GetTickCount - ShowTime) / 1000.0);
   if Remain < 0 then begin
      CloseTimer.Enabled := False;
      Close;
   end;

   StatLabel.Caption := Format('Closing in %1.1n', [Remain]);
end;


procedure TAboutForm.FormShow(Sender: TObject);
begin
   ShowTime := GetTickCount;
   StatLabel.Caption := '';
end;


procedure TAboutForm.OKButClick(Sender: TObject);
begin
   CloseTimer.Enabled := False;
end;


end.
