unit Main;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, ExtCtrls, ComCtrls, FormSettings, Db, kbmMemTable, Grids,
  DBGrids, ParseTypes, Menus, Buttons;

type
  TMainForm = class(TForm)
    TopPanel: TPanel;
    AnalyzeBut: TButton;
    PageControl1: TPageControl;
    SkillSheet: TTabSheet;
    PlayerSheet: TTabSheet;
    StatusBar1: TStatusBar;
    OpenDialog1: TOpenDialog;
    FormSettings1: TFormSettings;
    ProgressBar1: TProgressBar;
    SkillsTab: TkbmMemTable;
    SkillsTabName: TStringField;
    SkillsTabMax: TIntegerField;
    SkillsTabMin: TIntegerField;
    SkillsTabNumIncrease: TIntegerField;
    SkillsTabLastIncrease: TDateTimeField;
    SkillGrid: TDBGrid;
    SkillSource: TDataSource;
    ZoneSheet: TTabSheet;
    ZoneTab: TkbmMemTable;
    ZoneTabName: TStringField;
    ZoneTabLastEnter: TDateTimeField;
    ZoneTabNumEnter: TIntegerField;
    ZoneSource: TDataSource;
    ZoneGrid: TDBGrid;
    PlayerTab: TkbmMemTable;
    PlayerSource: TDataSource;
    DBGrid1: TDBGrid;
    PlayerTabName: TStringField;
    PlayerTabLastSeen: TDateTimeField;
    PlayerTabNumSeen: TIntegerField;
    PlayerTabMaxLevel: TIntegerField;
    PlayerTabMinLevel: TIntegerField;
    PlayerTabClass: TStringField;
    PlayerTabRace: TStringField;
    PlayerTabGuild: TStringField;
    PlayerTabAnonymous: TBooleanField;
    GridPopup: TPopupMenu;
    ExporttoExcel1: TMenuItem;
    TabSheet1: TTabSheet;
    BuyTab: TkbmMemTable;
    BuyTabItem: TStringField;
    BuyTabLastBuy: TDateTimeField;
    BuyTabNumBuy: TIntegerField;
    BuyTabTotCopper: TIntegerField;
    BuySource: TDataSource;
    DBGrid2: TDBGrid;
    BuyTabLastVendor: TStringField;
    FileNameEdit: TEdit;
    BrowseBut: TSpeedButton;
    AboutBut: TButton;
    StartTimer: TTimer;
    procedure FormCreate(Sender: TObject);
    procedure AnalyzeButClick(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure GridTitleClick(Column: TColumn);
    procedure FormHide(Sender: TObject);
    procedure ExporttoExcel1Click(Sender: TObject);
    procedure BrowseButClick(Sender: TObject);
    procedure AboutButClick(Sender: TObject);
    procedure StartTimerTimer(Sender: TObject);
  protected
    CurLine    : string;
    Order      : integer;
    procedure  SetStat(i: integer; s: string);
  public
    { Public declarations }
    Skills     : TSkillList;
    Zones      : TZoneList;
    Players    : TPlayerList;
    BuyItems   : TBuyList;
    procedure  Process_Line(const s: string);
    function   CurDateTime: TDateTime;
    procedure  Fill_Tables;
    property   Stat[i: integer]: string write SetStat;
  end;


var
  MainForm: TMainForm;

implementation

uses TableUtils, About;

{$R *.DFM}

procedure TMainForm.FormCreate(Sender: TObject);
begin
   PageControl1.ActivePage := SkillSheet;

   Skills := TSkillList.Create;
   Zones := TZoneList.Create;
   Players := TPlayerList.Create;
   BuyItems := TBuyList.Create;
end;


procedure TMainForm.FormDestroy(Sender: TObject);
begin
   Skills.Free;
   Zones.Free;
   Players.Free;
   BuyItems.Free;
end;


procedure TMainForm.AnalyzeButClick(Sender: TObject);
var
   sl : TStringList;
   i  : integer;
   t1, t2 : DWORD;
begin
   t1 := GetTickCount;
   Skills.Clear;

   if not FileExists(FileNameEdit.Text) then
      if OpenDialog1.Execute then
         FileNameEdit.Text := OpenDialog1.FileName
      else
         exit;

   Stat[0] := 'Loading EQ Log';
   Screen.Cursor := crHourGlass;
   sl := TStringList.Create;
   sl.LoadFromFile(FileNameEdit.Text);

   Stat[0] := 'Analyzing EQ Log';
   ProgressBar1.Max := sl.Count;
   for i := 0 to sl.Count-1 do begin
      if (i and 63) = 0 then ProgressBar1.Position := i+1;
      CurLine := sl[i];
      Process_Line(CurLine);
   end;

   sl.Free;
   Screen.Cursor := crDefault;

   Fill_Tables;

   t2 := GetTickCount;
   Stat[0] := Format('Elapsed Time = %1.2n sec', [(t2-t1)/1000.0]);
end;


procedure TMainForm.Process_Line(const s: string);
var
   Line : string;
begin
   Line := Copy(s, 28, Length(s));

   Skills.ProcessLine(Line);
   Zones.ProcessLine(Line);
   Players.ProcessLine(Line);
   BuyItems.ProcessLine(Line);
end;


function TMainForm.CurDateTime: TDateTime;
var
   s, s2 : string;
   ms    : string;
   ds    : string;
   ys    : string;
   ts    : string;
   i     : integer;
   mn    : integer;
begin
   s := Copy(CurLine, 6, 20);
   ms := Copy(s, 1, 3);
   ds := Copy(s, 5, 2);
   ys := Copy(s, 17, 4);
   ts := Copy(s, 8, 8);

   mn := -1;
   for i := 1 to 12 do begin
      if AnsiCompareText(ShortMonthNames[i], ms) = 0 then mn := i;
   end;

   s2 := Format('%d/%s/%s %s', [mn, ds, ys, ts]);

   Result := StrToDateTime(s2);
end;


procedure TMainForm.GridTitleClick(Column: TColumn);
var
   fn : string;
   mt : TkbmMemTable;
begin
   fn := Column.Field.FieldName;
   mt := Column.Field.DataSet as TkbmMemTable;
   fn := fn + ';' + mt.Fields[0].FieldName;

   if mt.SortFields = fn then begin
      Order := -Order;
   end else begin
      Order := 1;
      mt.SortFields := fn;
   end;

   if Order = 1 then begin
      mt.Sort([]);
   end else begin
      mt.Sort([mtcoDescending]);
   end;
end;


procedure TMainForm.Fill_Tables;
var
   i  : integer;
   si : TSkillItem;
   zi : TZoneItem;
   pi : TPlayerItem;
   bi : TBuyItem;
begin
   SkillsTab.EmptyTable;
   for i := 0 to Skills.Count-1 do with SkillsTab do begin
      si := Skills.Objects[i] as TSkillItem;
      Append;
      FieldValues['Name'] := si.Name;
      FieldValues['Max'] := si.Max;
      FieldValues['Min'] := si.Min;
      FieldValues['NumIncrease'] := si.NumIncrease;
      FieldValues['LastIncrease'] := si.LastIncrease;
      Post;
   end;
   SkillsTab.First;

   ZoneTab.EmptyTable;
   for i := 0 to Zones.Count-1 do with ZoneTab do begin
      zi := Zones.Objects[i] as TZoneItem;
      Append;
      FieldValues['Name'] := zi.Name;
      FieldValues['NumEnter'] := zi.NumEnter;
      FieldValues['LastEnter'] := zi.LastEnter;
      Post;
   end;
   ZoneTab.First;

   PlayerTab.EmptyTable;
   for i := 0 to Players.Count-1 do with PlayerTab do begin
      pi := Players.Objects[i] as TPlayerItem;
      Append;
      FieldValues['Name'] := pi.Name;
      FieldValues['MaxLevel'] := pi.MaxLevel;
      FieldValues['MinLevel'] := pi.MinLevel;
      FieldValues['NumSeen'] := pi.NumSeen;
      FieldValues['LastSeen'] := pi.LastSeen;
      FieldValues['Race'] := pi.Race;
      FieldValues['Guild'] := pi.Guild;
      FieldValues['Class'] := pi.PlayClass;
      FieldValues['Anonymous'] := pi.Anon;
      Post;
   end;
   PlayerTab.First;

   BuyTab.EmptyTable;
   for i := 0 to BuyItems.Count-1 do with BuyTab do begin
      bi := BuyItems.Objects[i] as TBuyItem;
      Append;
      FieldValues['Item'] := bi.Item;
      FieldValues['LastBuy'] := bi.LastBuy;
      FieldValues['NumBuy'] := bi.NumBuy;
      FieldValues['TotCopper'] := bi.TotCopper;
      FieldValues['LastVendor'] := bi.Vendor;
      Post;
   end;
   BuyTab.First;
end;


procedure TMainForm.FormHide(Sender: TObject);
begin
   FormSettings1.SaveSettings;
end;


procedure TMainForm.SetStat(i: integer; s: string);
begin
   StatusBar1.Panels[i].Text := s;
   Update;
end;



procedure TMainForm.ExporttoExcel1Click(Sender: TObject);
var
   ds : TDataSet;
begin
   ds := (GridPopup.PopupComponent as TDBGrid).DataSource.DataSet;
   ExportTableToExcel(ds);
end;


procedure TMainForm.BrowseButClick(Sender: TObject);
begin
   if OpenDialog1.Execute then
      FileNameEdit.Text := OpenDialog1.FileName
end;


procedure TMainForm.AboutButClick(Sender: TObject);
begin
   AboutForm.ShowModal;
end;


procedure TMainForm.StartTimerTimer(Sender: TObject);
begin
   StartTimer.Enabled := False;
   AboutForm.CloseTimer.Enabled := True;
   AboutForm.ShowModal;
end;

end.
