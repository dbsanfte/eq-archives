program EQLogAnalyzer;

uses
  Forms,
  Main in 'Main.pas' {MainForm},
  ParseTypes in 'ParseTypes.pas',
  TableUtils in '..\..\Lib\TableUtils.pas',
  About in 'About.pas' {AboutForm};

{$R *.RES}

begin
  Application.Initialize;
  Application.Title := 'EQ Log Analyzer';
  Application.CreateForm(TMainForm, MainForm);
  Application.CreateForm(TAboutForm, AboutForm);
  Application.Run;
end.
