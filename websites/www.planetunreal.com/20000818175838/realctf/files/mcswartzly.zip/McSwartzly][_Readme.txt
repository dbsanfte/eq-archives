====================================================================
Forword:

Hi all!

Well, let me start off by saying thanks for all the support in the past
that you guys showed with Real CTF.

I have had alot of requests to get this map out to you guys with the UT 
conversions.  Originally I was going to just port the map but it was one
of the shorter maps and the scale was just to small, so i decided that it 
is a simple enough map to just redo.  

With that said i want everyone to know that i really would rather not have
the map rated or what not due to the fact that i am really busy with a 
"special project" and i didnt spend much time on the map.  About 3-4 hours
so its not architectually stunning, but it does play well with bots, and in
my opinion is about the best damn CTF map that is out there.... PERIOD!


================================================================

Title                   : McSwartzly Base ][
Version                 : 1.0
Filename                : CTF-Mcswartzly][.unr
Author                  : Eric Evans (Swartz)
Email Address           : daswartz@hotmail.com
Web Pages               : http://www.planetunreal.com/RealCTF
                        : http://www.actionxtreme.com/swartz
Description             : remake of a remake of a damn nice q1 ctf map
			  
Other levels by author  
Unreal:                 : DMSanctuary1 & 2 (learnen unreal ed)
			  Real_Caverns
			  Real_Underdwellers
			  Real_DarkKeep
			  Real_Milk
			  Real_Shrines
			  Real_McSwartzly
			  RealDM_Dementia
			  RealDM-Manitue
			  The Gate
			  Level 4, for Peril on Mars map pack
			  More but cant say ;0)

Quake 2			: Roundup
			  NetTown
			  Swartz's End
			  Bainard Syndrom
			  Ebon Fortress 2 (remake)
			  Claustrophobopolis2

Misc			: I wont waste time with naming all the maps, but
			  if there is a first person engine game out there
			  i have probably made a map or 2 starting with 
			  were it all began!... DOOM.

Additional Credits	: The Real CTF Team, who without, i can safely
			  say that I would have quit mapping 2 years ago.

=================================================================

--- Play Information ---
Game                    : Unreal Tournament
Level Name              : Mcswartzly's Base ][
Single Player           : No
Cooperative             : YES
Deathmatch              : No
Dark Match              : No
Difficulty Settings     : No

Known bugs              : I think i have found them all. But please 
			  let me know if you find something i missed.
			  

--- Construction ---
Editor(s) used          : UnrealED 402 Beta
Base                    : layout after Q1 CTF McKinley Base
Work Dates	        : December 27-28, 1999
Construction Time       : 3-4 hours (ish).

Installation
--------------------------
	Copy into your $/UnrealTournament/maps/ directory and enjoy.

Author's Notes
--------------------------
	None this time.. im tired.


Copyright / Permissions
-----------------------

Level designers may "ask" my permission to use particular structures from this level.

You are NOT allowed to commercially exploit this level, i.e. put it on a CD
or any other electronic medium that is sold for money without my explicit
permission!  

You MAY distribute this level through any electronic network (internet,
FIDO, local BBS etc.), provided you include this file and leave the archive
intact.

----------------------
UNREAL (c)1998 Epic Megagames, Inc.  All Rights Reserved.  Distributed by
GT Interactive Software, Inc. under license.  UNREAL and the UNREAL logo are
registered trademarks of Epic Megagames, Inc. All other trademarks and trade
names are properties of their respective owners.