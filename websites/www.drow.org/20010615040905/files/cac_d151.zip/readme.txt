Clan Arena Source
-----------------------

To anyone who was waiting for this ... I apologize.
There's a couple reasons for the late release.  Primarily, it was because
of the move.  Right after version 1.2 was released, I made a huge move from
Virginia to California.  I wasnt hooked up for a good month after that,
and when I did get hooked back up, Rocket Arena 2 took most of my remaining
spare time.  This also explains why the bugs in v1.2 werent addressed
earlier.
I'm hoping version 1.3 is the last for Clan Arena.  Enjoy!

                                                        Mungo
                                                        (bml@netwiz.net)

