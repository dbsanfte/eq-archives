#!/bin/sh
# PGP 5.0 BeOS Installer Version 1.0

# Modify these variables if needed
homedir="/boot/home"
bindir="/boot/beos/bin"

# Check for homedirectory and start installation
if [ -d $homedir ]; then
	echo "Installation started. Lay back and relax..."
	echo
else
	echo Fatal error: $homedir not found. Please edit the script
	exit
fi

# Check for bin-directory
if [ -d $bindir ]; then

# directory found. Now copy binaries...
	echo Installing Binaries
	if [ -f $bindir/pgp ]; then
		echo  Old pgp found. File was renamed to pgp.old
		mv $bindir/pgp $bindir/pgp.old
	fi
	cp ./files/pgp $bindir/pgp
	echo  pgp: done 
	if [ -f $bindir/pgpk ]; then
		echo  Old pgpk found. File was renamed to pgpk.old
		mv $bindir/pgpk $bindir/pgpk.old
	fi
	cp ./files/pgpk $bindir/pgpk
	echo  pgpk: done
	echo

# ...and create the symbolic links
	echo Creating symbolic links
	if [ -f $bindir/pgpe ]; then
		echo  Old pgpe found. File was renamed to pgpe.old
		mv $bindir/pgpe $bindir/pgpe.old
	fi
	ln -s $bindir/pgp $bindir/pgpe
	echo  pgpe: done 
	if [ -f $bindir/pgps ]; then
		echo  Old pgps found. File was renamed to pgps.old
		mv $bindir/pgps $bindir/pgps.old
	fi
	ln -s $bindir/pgp $bindir/pgps
	echo  pgps: done 
	if [ -f $bindir/pgpv ]; then
		echo  Old pgpv found. File was renamed to pgpv.old
		mv $bindir/pgpv $bindir/pgpv.old
	fi
	ln -s $bindir/pgp $bindir/pgpv
	echo  pgpv: done 
	if [ -f $bindir/pgpo ]; then
		echo  Old pgpo found. File was renamed to pgpo.old
		mv $bindir/pgpo $bindir/pgpo.old
	fi
	ln -s $bindir/pgp $bindir/pgpo
	echo  pgpo: done 
else
	echo Fatal error: $bindir not found. Pleas edit the script
fi

echo
echo -n Creating directory for key and configuration files...
if [ -d $homedir/.pgp ]; then
	echo failure: Configuration and Keydirectory allready there.
else
	mkdir $homedir/.pgp
	echo done
fi
echo
echo Copying key and configuration files

echo -n Copying Secret Keyring...
if [ -f $homedir/.pgp/secring.skr ]; then
	echo failure: Secret Keyring allready there.
else
	cp files/secring.skr $homedir/.pgp
	echo done
fi
echo -n Copying Public Keyring...
if [ -f $homedir/.pgp/pubrink.pkr ]; then
	echo failure: Public Keyring allready there.
else
	cp files/pubring.pkr $homedir/.pgp
	echo done
fi

echo -n Copying configuration file...
if [ -f $homedir/.pgp/pgp.cfg ]; then
	cp files/pgp.cfg $homedir/.pgp/pgp.cfg-sample
	echo failure: Configuration file allready there. File saved as 
pgp.cfg-sample
else
	cp files/pgp.cfg $homedir/.pgp
	echo done
fi

echo -n Copying Language file...
if [ -f $homedir/.pgp/language50.txt ]; then
	echo failure: Language file allready there.
else
	cp files/language50.txt $homedir/.pgp
	echo done
fi
echo
echo ...Installation finished. Have fun!
