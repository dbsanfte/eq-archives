Offline Mana Calculator for EverQuest
-------------------------------------
  Kyle Paulette
  v1.5 FINAL(7/21/99)

This little program is for use when you can't quite get ahold of the mana
calculator on EQ Enchanters.

NOTE* I've been given reports on some invalidility with wisdom users.  This
is becuase there are two formulas that are used for caclculating wisdom. One
is exactly like the intelligence formula, while another is different.  I use
the intelligence-like formula becuase I don't believe that Verant would give
a wisdom user a bounus or penalty (the second formula gives less mana).  See
formula section for the formulas I use.

This is the last version of this program due to better ones pending.  I've
included the source for your enjoyment.


INSTRUCTIONS ON USE
-------------------
*I highly recommend you type CLS and hit enter at the command prompt before
 use.  The program doesn't clear the screen beforehand.

TO INSTALL: Copy manacalc.exe to any place you wish.  Keep the readme.txt with
 it.

 1. Start her up by typing MANACALC at the DOS prompt or at the Run... box.
    
 2. Simply find your class and enter the group number (the number in brackets),
    and hit enter.  Follow the onscreen questions and you'll get your final
    mana for your current level/intelligence (wisdom) combo.
    
BUGS/QUIRKS
-----------
 - Formula use.  See below.

FORMULAS
--------
INTELLIGENCE: ((INTELLIGENCE/5)+2)*(LEVEL)  -*-
WISDOM      : ((WISDOM/5)+2)*(LEVEL-(STARTING CASTING LEVEL - 1))   -*-
				or
WISDOM (2)  : ((WISDOM/8)+8)*(LEVEL-(STARTING CASTING LEVEL - 1))

-*- Indicates formulas I use.

REVISION HISTORY
----------------
*--- v.1.5 (FINAL)
 -Final release version
 -Added source to zip
 -Fixed formulas
 -Added a "Do you wish to quit" message.

*--- v.1.4 (SPELLING FIX, CLASS ADDITION)
 -<slaps himself hard in the face>
 -Spelled wizard right, sigh...
 -Fixed SK duplication.
 -Fixed Druid appearing twice.
   -Changed second Druid to Ranger like it was meant to be
 -Put up a sticky note on monitor reminding me never to program at 5 AM again.

*--- v.1.3 (INITIAL RELEASE VERSION)
 -Made the code a bit neater
 -Eleminated all GOTO statements (nearly a sin in C++ to use GOTO)
 -Added better error checking code.

*--- v.1.2.1 (NOT RELEASED, INTERNAL TESTING)
 -Redid the entire code, literally, again.  I tried to get simple yes/no
  prompts, but I couldn't get the variable right for some reason (probably
  my lack of knowledge in C++)
 -Added simple error checking code.

*--- v1.2 (NOT RELEASED, INTERNAL TESTING)
 -Redid the entire code from scratch.  I eleminated nearly all my previous
  errors by reworking my structure, but created a whole new slew of ones.
 -Hybrid classes (paladins, etc.) now use a separate formula (less thinking
  on the user's part, if it weren't already low enough).
 -Figured out I knew less than I thought about C++...

*--- v1.1 (NOT RELEASED, NOT TESTED)
 -I just pretend that this mistake never existed...
  You'd be wise to do the same...

*--- v1.0 (NOT RELEASED, INTERNAL & EXTERNAL TESTING)
 -It worked, crudely.
 -It never went past the intelligence users (enchanters, etc.).  But that
  wasn't so severe, as both wisdom users and intel users use the same formula.
 -You had to do some math to figure out level to enter for hybrids (paladin,
  etc.).  That kinda defeated the purpose of this program to keep everything
  simple and away from the user.

PLANS
-----
Well, none really, besides further code improvements leading to simpler,
smaller code.  I do have some plans to stick in a Skill Cap calculator so
users can get those elusive skills caps *snickers*.

CREDITS/DISTRIBUTION
--------------------
I'd like to thank Verant and 989 for making a leap forward in mass online
gaming by making a game that looked and played better than UO (IMHO).

I'd also like to than EverQuest Enchanters for giving me the idea of the
offline version of their mana calculator.

I'd also like to thank all those that scrounged up the knowledge of the
formulas used in this program.

Feel free to make programs inspired by this, improving on my design.  All
I ask is that you include my name, Kyle Paulette, and the name of this
program, Offline Mana Calculator, as your inspiration somewhere in the
credits.  Also include a link (www.castersrealm.com) somewhere in there as
that is the future home of EverQuest Enchanters, those who inspired me.
I'd also like if you just tell me if you're making a program based on this
and I'll help you any way I can.

CONTACT INFO/MISC
-----------------
e-mail address: omggrt@lynchburg.net
Caster's Ream (future site of Everquest Enchanters): www.castersrealm.com