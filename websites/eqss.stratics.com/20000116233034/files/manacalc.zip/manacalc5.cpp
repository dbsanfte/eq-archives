#include <iostream.h>

short int Intelligence;
short int Wisdom;
short int Mana;
short int Level;
short int quit;

int main ()
{
Beginning:
	enum eqClasses {Intel=1, Wis, WisH, IntelH};
	int eqClass;
	cout << "\n";
	cout << "Offline Mana Calculaator\n";
	cout << "========================\n";
	cout << "          v.1.5\n";
	cout << "\n";
	cout << "Select your class group...\n";
	cout << "[1]Enchanter, Necromancer, Magician, Wizard\n";
	cout << "[2]Cleric, Druid, Shaman\n";
	cout << "[3]Ranger, Paladin\n";
	cout << "[4]Shadow Knight\n";
	cout << "\n";
	cout << "Group? ";
	cin >> eqClass;
		if (eqClass == Intel )
		{
			cout << "\n";
			cout << "[1]Enter your intelligence: ";
			cin >> Intelligence;
			cout << "Enter your current level: ";
			cin >> Level;
			if (Level < 1)
			{
				cout << "Entered level is less than one.  Please enter a valid level.";
				goto Quit;
			}
			else if (Level > 50)
			{
				cout << "Entered level is above the level cap (50).  Please enter a valid level.";
				goto Quit;
			}
			else
			{
			}
			Mana=((Intelligence/5)+2)*(Level);
			cout << "Your current mana is: "<< Mana;
			goto Quit;
		}
		else if (eqClass == Wis )
		{
			cout << "\n";
			cout << "[2]Enter your wisdom: ";
			cin >> Wisdom;
			cout << "Enter your current level: ";
			cin >> Level;
			if (Level < 1)
			{
				cout << "Entered level is less than one.  Please enter a valid level.";
				goto Quit;
			}
			else if (Level > 50)
			{
				cout << "Entered level is above the level cap (50).  Please enter a valid level.";
				goto Quit;
			}
			else
			{
			}
			Mana=((Wisdom/5)+2)*(Level);
			cout << "Your current mana is: "<< Mana;
			goto Quit;
		}
		else if (eqClass == WisH)
		{
			cout << "\n";
			cout << "[3]Enter your wisdom: ";
			cin >> Wisdom;
			cout << "Enter your current level: ";
			cin >> Level;
			if (Level < 9)
			{
				cout << "You cannot cast spells at this level.  Wait until level 9.";
				goto Quit;
			}
			else if (Level > 50)
			{
				cout << "Entered level is above the level cap (50).  Please enter a valid level.";
				goto Quit;
			}
			else
			{
			}
			Mana=((Wisdom/5)+2)*(Level-8);
			cout << "Your current mana is: "<< Mana;
			goto Quit;
		}
		else if (eqClass == IntelH)
		{
				cout << "\n";
			cout << "[4]Enter your intelligence: ";
			cin >> Intelligence;
			cout << "Enter your current level: ";
			cin >> Level;
			if (Level < 9)
			{
				cout << "You cannot cast spells at this level.  Wait until level 9.";
				goto Quit;
			}
			else if (Level > 50)
			{
				cout << "Entered level is above the level cap (50).  Please enter a valid level.";
				goto Quit;
			}
			else
			{
			}
			Mana=((Intelligence/5)+2)*(Level-8);
			cout << "Your current mana is: "<< Mana;
			goto Quit;
		}
		else
		{
			cout << "Error.  Invalid entry.  Enter a number from 1 to 4.";
				goto Quit;
		}
Quit:
		enum QUITVAR { YesQuit=1, NoReturn};
		cout << "\nDo you wish to [1]Quit or [2]Return to main menu? ";
		cin >> quit;
		if (quit==YesQuit)
			return 0;
		else if (quit==NoReturn)
			cout << "\n";
			cout << "\n";
			cout << "\n";
			goto Beginning;
		//else if (quit != NoReturn || quit != YesQuit)
		    //goto Quit;
}