7/27/99

General Information
-------------------
Please read the copyright notice at the beginning of mana.c

This UI was inspired by EQMana which I believe was written by Arn Cota.
He has a webpage for it at http://www.ipass.net/~arncota/EQ/EQ.html


Purpose
-------
I decided to write this little app as an alternative to the VB version.
This was a 'quickie' for me - don't expect stellar code.  I am not a Win32 API guru.
Hopefully I've produced something both useable, and tiny.  Enjoy :)


Build Notes
-----------
I've included the source code, and a pre-built executable.  This program is
strictly for Win32.  I used VC++ 6.0 to create this.  You can probably compile
on Borland or Watcom but you're on your own for that stuff.

For VC++, create an empty Win32 executable project, add the files, set your build
settings to Retail or Debug and compile it.


Known problems
--------------
* Tab between textboxes is not implemented


Updates
-------
7/30/99: Fixed roundoff problem to be more in line with the other mana calculators.
         This was done with a modulus - if you prefer floating point, well, tough ;)


Final note
----------
I am probably not going to spend more time on this.  The source code is included.
If you want to improve it and send changes back to me, I'll try to add them in.


Thanks,

Speed <speed@rumblefish.net>