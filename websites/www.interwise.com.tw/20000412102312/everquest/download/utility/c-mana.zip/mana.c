/*  EQ Mana Calculator - C version.
	Copyright (c) 1999 Speed_D <speed@rumblefish.net>

	This program is free to use and distribute, as long as this
	copyright notice remains intact.  You may modify the program,
	as long as my name is credited for the original work.

	Please submit improvements back to me and I will be happy to
	add them.  After all, it is a _really_ simple little hack.

	This notice applies to the following files:

	mana.exe
	mana.c
	ui.rc
	resource.h
*/

#include <windows.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "resource.h"


LRESULT CALLBACK WindowFunc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK DialogFunc(HWND, UINT, WPARAM, LPARAM);

char szWinName[] = "EQ Mana Calculator";
HWND hwnd = NULL;
HWND hdwnd = NULL;
int nMode = 0;

HINSTANCE hInst;
HINSTANCE hInstTemp;

int WINAPI WinMain(HINSTANCE hThisInst, HINSTANCE hPrevInstance,
				   LPSTR lpszArgs, int nWinMode)
{
	MSG msg;
	WNDCLASS wcl;

	hInstTemp = hThisInst;
	nMode = nWinMode;

	/* Define a window class */
	wcl.hInstance = hThisInst;
	wcl.lpszClassName = szWinName;
	wcl.lpfnWndProc = WindowFunc;
	wcl.style = 0;
	wcl.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wcl.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcl.lpszMenuName = NULL;
	wcl.cbClsExtra = 0;
	wcl.cbWndExtra = 0;
	wcl.hbrBackground = GetStockObject(WHITE_BRUSH);

	if (!RegisterClass (&wcl)) return 0;

	hwnd = CreateWindow(
		szWinName,
		"EQ Mana Calculator",
		WS_OVERLAPPEDWINDOW,
		(GetSystemMetrics(SM_CXFULLSCREEN) / 2),
		(GetSystemMetrics(SM_CYFULLSCREEN) / 2),
		0,
		0,
		NULL,
		NULL,
		hThisInst,
		NULL
	);

	hInst = hThisInst;

	ShowWindow(hwnd, SW_SHOWNORMAL);
	UpdateWindow(hwnd);

	while (GetMessage(&msg, NULL, 0, 0))
	{
		if (IsIconic(hdwnd))
		{
			ShowWindow(hwnd, SW_MINIMIZE);
		}
		
		if (!IsIconic(hwnd))
		{
			ShowWindow(hwnd, SW_HIDE);
			ShowWindow(hdwnd, SW_RESTORE);
		}

		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return msg.wParam;
}

LRESULT CALLBACK WindowFunc(HWND hwnd, UINT message,
							WPARAM wParam, LPARAM lParam)
{
	DWORD dwStyle;

	dwStyle = WS_OVERLAPPED; 
	switch (message)
	{
		case WM_CREATE:
			hdwnd = CreateDialog(hInst, MAKEINTRESOURCE(IDD_DIALOG1), hwnd, DialogFunc);
			break;

		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				// don't really need to do this right now since
				// we are more concerned with the dialog box
			}
			break;
			
		case WM_DESTROY:
			PostQuitMessage(0);
			break;
		
		default:
			return DefWindowProc(hwnd, message, wParam, lParam);
	}
	return 0;
}

BOOL CALLBACK DialogFunc(HWND hdwnd, UINT message,
						 WPARAM wParam, LPARAM lParam)
{
	UINT stat, modifier, level, hybrid, base, adjusted, remainder;

	hybrid = 0;

	switch(message)
	{
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDOK:
					hybrid = SendDlgItemMessage(hdwnd, IDC_HYBRID, BM_GETCHECK, 0, 0);
					stat = GetDlgItemInt(hdwnd, IDC_STAT, NULL, 1);
					modifier = GetDlgItemInt(hdwnd, IDC_MODIFIER, NULL, 1);
					level = GetDlgItemInt(hdwnd, IDC_LEVEL, NULL, 1);
					
					// The actual calculations...
					if (hybrid)
					{
						level -= 8;
					}
					base = (stat/5 + 2) * level;
					remainder = stat % 5;
					base = remainder * (level / 5) + base;

					adjusted = ((stat+modifier) / 5 + 2) * level;
					remainder = (stat+modifier) % 5;
					adjusted = remainder * (level / 5) + adjusted;

					SetDlgItemInt(hdwnd, IDC_BASE, base, 1);
					SetDlgItemInt(hdwnd, IDC_ADJUSTED, adjusted, 1);

					break;
					
				case IDEXIT:
					PostQuitMessage(0);
					break;
			}
		
		case WM_INITDIALOG:
			return 1;

		case WM_CLOSE:
			PostQuitMessage(0);

	}
	return 0;
}