GroupExp v1.0

This program calculates the experience share of each group member, and determines
approximately how many kills Player 1 needs to level in his current group. Note that 
the program works for Players level 2 and up - this is because Players start at Level 
1, rather than Level 0, and so are considered to have 0xp when they first start out 
(exp share = player exp/total group exp).

List of Files:

GroupExp.exe	Group Experience Calculator
MFC42D.DLL*	Microsoft Foundation Class 4.2 DLL (Debug version)
MSVCRTD.DLL*	Microsoft Visual C Run-Time DLL (Debug version)
Readme.txt	This File

* only included in GrpXpFul.zip

Installation:

GroupExp v1.0 is still compiled as a "debug build" to help isolate any
potential bugs which may still exist. Because of this, the program
uses the Microsoft Foundation Class (MFC) 4.2 and Microsoft Visual C 
Runtime DLLs (Debug versions). These files are available separately on
the web site in the event you downloaded the program only, and still need
them. Once you get them, they must be copied into your \Windows\System or 
\Winnt\System directory in order for GroupExp to operate at all.

If you still cannot get it to run, contact GroupExp@hotmail.com with 
details of the error received and Operting System used. Thank you.

Revision History
-------------------------
v 1.0 - 25 May 2000

This is the first "production" release. I think the majority of the kinks
are now worked out.

Improvements and Fixes:
1. All valid Race/Class combinations should now be properly recognized.
2. Default action for the <Enter> key is now Calculate, vice Exit.
3. Kills remaining to Level is now adjusted for % Level Complete (e.g. if
   you are two bubs into level 30, and need X experience, your experience 
   remaining reflects the fact that you are about 40% thru the level).
4. GroupExp now re-calculates all numbers each time you make changes to 
   group composition (you no longer have to make all your changes, then hit
   the Calculate button).
5. Added the ability to view Current xp, Next Level xp, and xp Remaining for 
   each player in the group.
6. Added Labels at the top to make the interface more clear.
7. Added the ability to minimize the window if desired.

Known Issues:
1. GroupExp does not enforce level restrictions (i.e., you can group with 
   anybody, and anything you kill will give you experience). I may fix this
   at a later date, but I am fairly certain the players know who they can
   group with, and what they can kill. =)

-------------------------
0.99b Beta - 23 May 2000:

This version corrects the following issues:
1. Correctly calculates the approximate exp remaining from level 60 to 61.
2. Corrects a problem with the level multipliers used for levels 54 - 60.

-------------------------
0.99a Beta - 23 May 2000:

This version corrected the following issues:
1. Included labels at the top of each column to make things a bit more clear.
2. Made the popup dialog for invalid Race/Class Combinations a little more
	user-friendly.
3. Corrected an issue that caused Gnome Race/Class combinations to be incorrectly
	reported as invalid.
4. Corrected the display of player Exp share for Level 1 Players (note, however,
	that it is still displayed as zero).
5. Included all necessary DLLs this time =)

------------------------
0.99 Beta - 22 May 2000:
Initial version.

Known Bugs:

% Level Complete disabled in this release, to be activated in a future release.