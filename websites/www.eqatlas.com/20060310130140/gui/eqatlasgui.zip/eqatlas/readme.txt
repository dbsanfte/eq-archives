readme.txt
EQ Atlas GUI XML Creator

Version 1.3 available - updated 9/22/2002

The EQ Atlas GUI XML Creator is a Java program that will allow you to create a GUI component to display maps (or really any .jpg image) within Everquest's new User Interface.  The program looks at the images you have in the install directory and creates a EQUI_HelpWnd.xml file, which will replace your existing Help window in the game.

What you need before you begin:

1)  EqAtlasGUI.jar (the executable java program that does this)

2)  Java VM 1.4.0 (can be obtained from http://java.sun.com, look for Java VM under downloads -- currently in upper right corner of page).  Windows XP does not come with a VM installed, and the VM's on older Windows versions are probably not 1.4.0.  This download is about 9 MB.

3)  .jpg or .jpeg image files (doesn't matter what they are, as long as they are jpg files)


Steps:

1)  Unzip the .zip file containing the files: readme.txt and EqAtlasGUI.jar into the uifiles folder in your Everquest install directory.  For example, when selecting the directory in WinZip, you would choose c:\Everquest\uifiles as the directory (replacing c:\Everquest with the directory you have EQ installed in).  The zip file will then unzip into c:\Everquest\uifiles\eqatlas directory.

2)  Place all .jpg image files you want to use within the uifiles\eqatlas directory.  They cannot be anywhere else for this to work correctly!  You cannot "trick" it and rename a png a jpg and expect it to work, it will not.

3)  Double-click on EqAtlasGUI.jar.  This will run the java program.  Yes, it's ugly.

4) At this point, choose from among the options listed. Leave it on Normal Textures the first time through, this will likely work. If you have a Voodoo3 card or have problems with maps appearing crunched or deformed, you can try the Voodoo3 Textures selection (this is beta code, I have no way to test it so let me know if it works). If you want to have a screen with fixed sizes for the tabs (for instance, if you have a lot of maps) then choose Scrollable Tabs. Then enter the width in the space (it must be a number) and then you must hit Enter! If you don't you will get an error when you go to create the file.

5) Click on the "Create XML" button. This will open up a file chooser where you can select which jpg images to include in the file. Do NOT choose images outside of this directory. This will cause it to fail when you go to run it in EQ. Use shift-click and ctrl-click to select more than one. All the images you want to use must be selected at this time.

6) When you're done selecting images, click the "Create XML" button. The program will run, and this takes a few seconds. It will create the EQUI_HelpWnd.xml file.

7) Close the program. If you don't trust me, check that the EQUI_HelpWnd.xml file is in the uifiles\eqatlas folder.

8) Now you enter Everquest normally. If you have never used the new User Interface before, you need to add the line "NewUI=TRUE" to the [Defaults] section of the eqclient.ini file. This will activate the new UI in all your characters.

9) Once in the game, you will see the new UI. Type "/loadskin eqatlas 1" which will load the file you created above. It should work correctly, if not, see below in the 'Errors' section. The "1" in that is to maintain the location of all your current windows when you load the different skin.

10) You're now using the program correctly! If you wish to add new images or remove old ones, simply run the program again. I recommend choosing less than 20 images, since the tabs get so small you have a hard time telling which is which. You do not need to rerun the program every time you play EQ, only if you want to change the images you've selected.

Errors:

This is beta software, meaning there are probably errors in it.  If you followed the above instructions exactly, it *should* work correctly.  If you did not follow them, I can guarantee you that's why it didn't work.

If you followed the above and it still didn't work, do the following: send me an email at muse@eqatlas.com and include the following: the EQUI_HelpWnd.xml file that you were using, the UIErrors.txt file from the Everquest directory, and a description of what happened.

You can also check out the GUI Mod section of the Forums at www.eqatlas.com.


Frequently Asked Questions:

Q: Does this violate the EULA?
A: No. SOE representatives have specifically said that maps in the GUI are fine.

Q: Do you have a way to download all your maps at once?
A: No, in fact I don't allow that. I want people who use this to go to my pages and download the maps individually, so that the site can make at least a small amount of money and continue to exist.

Q: How do I download maps then?
A: Go to the page that has the image you want. Right-click on the image. This will pop up a menu that, depending on your operating system and browser, will say something like Save Image As... Select that and save it in the uifiles/eqatlas directory. Just make sure it's a jpg file.

Q: I am not using the default UI.  How do I use this and that at the same time?
A: You can copy the EqAtlasGUI.jar file and the images you are using to the other directory and run it there.  It doesn't care where it's located, as long as the images are in the same directory.  It will, however, overwrite your EQUI_HelpWnd.xml file in that folder (if it exists), so you will lose access to that original file.

Q: Can I make this replace any other window (like the Pet Window)?
A:  No.  Due to limitations in the way the new GUI works, specific files have to contain certain components.  If you look at the XML created, the top contains components that are never even used in this modification.  If these are removed, the Help Window won't work.  This is true for all the other windows as well, so I would need to write one of these programs for each one of those.

Q:  Can I rename this file something else and use it?
A:  No.  See the above Q/A.

Q: It says "Could not find the main class.  Program will exit!" when I try and run it, what's wrong?
A: You probably have an old VM.  See above in requirements.

Q: When I try to load, nothing seems to happen, and the Help window is the normal one.  What's going on?
or When I try to load, I get an error like: "eqatlas error, loading default skin."  What's going on?
A: Check the installation directory.  It should be <EQ Install Dir>\uifiles\eqatlas and the file EQUI_HelpWnd.xml should be in there.  If that's wrong, it needs to be.  If that's correct, send me the information I mention above in the Errors section.

Q: I can only get one image to load, what's going on?
A: You need to select all the images you want to use at the same time using shift-click and ctrl-click in order to load them all in the file.

Q: When I try to run the EqAtlasGUI.jar, my unzipping program starts up and tries to extract it. How do I get it to run correctly?
A: The problem is that .jar files are .zip files with a different name and some special coding to run under Java. You need to set up the .jar files to be run by the program javaw that came with the Java VM. This is located in the \bin directory of the java installation. On Windows 98, the way to do this is to go under View in a desktop menu and choose Folder Options... Then choose File Types and find the jar files, it should be under Executable Jar File. If you can't find it, you'll need to make a new one. If you can find it, edit it so that it uses javaw. This is a bit complicated, but make a new action or edit the open action, and choose javaw as the program.

Version History

version 1.3 (9/22/2002):
-- Significant changes to basic interface
-- Added beta code to test for old Voodoo3 devices
-- Added ability to make tabs a fixed size
-- Fixed image size checking code
version 1.2 (9/10/2002):
-- Fixed screen so it's resizable. 
-- Added code to correctly show images sized in factors of 512 pixels.
version 1.1 -- Fixed maps so they show up as actual size.
version 1.0 -- First release. 