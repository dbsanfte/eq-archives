readme.txt
EQ Atlas GUI XML Creator

Version 1.2 available - updated 9/10/2002

Version History

version 1.2 -- Fixed screen so it's resizable. Added code to correctly show images sized in factors of 512 pixels.
version 1.1 -- Fixed maps so they show up as actual size.
version 1.0 -- First release.

The EQ Atlas GUI XML Creator is a Java program that will allow you to create a GUI component to display maps (or really any .jpg image) within Everquest's new User Interface.  The program looks at the images you have in the install directory and creates a EQUI_HelpWnd.xml file, which will replace your existing Help window in the game.

What you need before you begin:

1)  EqAtlasGUI.jar (the executable java program that does this)

2)  Java VM 1.4.0 (can be obtained from http://java.sun.com, look for Java VM under downloads -- currently in upper right corner of page).  Windows XP does not come with a VM installed, and the VM's on older Windows versions are probably not 1.4.0.  This download is about 9 MB.

3)  .jpg or .jpeg image files (doesn't matter what they are, as long as they are jpg files)


Steps:

1)  Unzip the .zip file containing the files: readme.txt and EqAtlasGUI.jar into the uifiles folder in your Everquest install directory.  For example, when selecting the directory in WinZip, you would choose c:\Everquest\uifiles as the directory (replacing c:\Everquest with the directory you have EQ installed in).  The zip file will then unzip into c:\Everquest\uifiles\eqatlas directory.

2)  Place all .jpg image files you want to use within the uifiles\eqatlas directory.  They cannot be anywhere else for this to work correctly!  You cannot "trick" it and rename a png a jpg and expect it to work, it will not.

3)  Double-click on EqAtlasGUI.jar.  This will run the java program.  Yes, it's ugly.

4)  Click on the "Create XML" button (right now it's the whole screen).  This will open up a file chooser where you can select which jpg images to include in the file.  Do NOT choose images outside of this directory.  This will cause it to fail when you go to run it in EQ.

5)  When you're done selecting images, click the "Create XML" button.  The program will run, and this takes a few seconds.  It will create the EQUI_HelpWnd.xml file.

6)  Close the program.  If you don't trust me, check that the EQUI_HelpWnd.xml file is in the uifiles\eqatlas folder.

7)  Now you enter Everquest normally.  If you have never used the new User Interface before, you need to add the line "NewUI=TRUE" to the [Defaults] section of the eqclient.ini file.  This will activate the new UI in all your characters.

8)  Once in the game, you will see the new UI.  Type "/loadskin eqatlas 1" which will load the file you created above.  It should work correctly, if not, see below in the 'Errors' section.  The "1" in that is to maintain the location of all your current windows when you load the different skin.

9)  You're now using the program correctly!  If you wish to add new images or remove old ones, simply run the program again.  I recommend choosing less than 20 images, since the tabs get so small you have a hard time telling which is which.  You do not need to rerun the program every time you play EQ, only if you want to change the images you've selected.


Errors:

This is beta software, meaning there are probably errors in it.  If you followed the above instructions exactly, it *should* work correctly.  If you did not follow them, I can guarantee you that's why it didn't work.

If you followed the above and it still didn't work, do the following: send me an email at muse@eqatlas.com and include the following: the EQUI_HelpWnd.xml file that you were using, the UIErrors.txt file from the Everquest directory, and a description of what happened.

You can also check out the GUI Mod section of the Forums at www.eqatlas.com.


Frequently Asked Questions:

Q: Does this violate the EULA?
A: No. SOE representatives have specifically said that maps in the GUI are fine.

Q: I am not using the default UI.  How do I use this and that at the same time?
A: You can copy the EqAtlasGUI.jar file and the images you are using to the other directory and run it there.  It will, however, overwrite your EQUI_HelpWnd.xml file in that folder (if it exists), so you will lose access to that file.

Q: Can I make this replace any other window (like the Pet Window)?
A:  No.  Due to limitations in the way the new GUI works, specific files have to contain certain components.  If you look at the XML created, the top contains components that are never even used in this modification.  If these are removed, the Help Window won't work.  This is true for all the other windows as well, so I would need to write one of these programs for each one of those.

Q:  Can I rename this file something else and use it?
A:  No.  See the above Q/A.

Q: It says "Could not find the main class.  Program will exit!" when I try and run it, what's wrong?
A: You probably have an old VM.  See above in requirements.

Q: When I try to load, nothing seems to happen, and the Help window is the normal one.  What's going on?
or When I try to load, I get an error like: "eqatlas error, loading default skin."  What's going on?
A: Check the installation directory.  It should be <EQ Install Dir>\uifiles\eqatlas and the file EQUI_HelpWnd.xml should be in there.  If that's wrong, it needs to be.  If that's correct, send me the information I mention above in the Errors section.